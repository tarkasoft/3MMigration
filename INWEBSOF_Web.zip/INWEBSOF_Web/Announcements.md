# Announcements (header megaphone)

Customer-facing notices from table `ia_announcement`, shown in the MainPage header megaphone dropdown.

## Data (`ia_announcement`)

| Column | Use |
| --- | --- |
| `a_user_type` | Audience: `All` or a login user type (`Customer`, `Admin`, … from `ia_user_master.u_user_type`). |
| `title` | List title |
| `description` | Short text / list snip; also popup body if `full_desc` is empty |
| `full_desc` | HTML body for the popup (preferred) |
| `sequence` | Sort order (numeric when possible) |
| `from_date` / `to_date` | Active window (inclusive); null = open-ended |

**Who sees what:** rows where `a_user_type = 'All'` **or** `a_user_type` equals the logged-in user type. Ordered by `sequence`.

## Server

One class (no separate controller/service):

- `com.mmm.system.Announcements`
- Endpoint: `GET/POST system/getAnnouncements (client: $host_url + "system/getAnnouncements"; $host_url already ends with titpl/)`
- Uses session `loginUserType`

## Client

Filled after MenuLoad in `MainPage.js`:

```js
Common.FillAnnouncementsData();
```

| Function | Role |
| --- | --- |
| `Common.FillAnnouncementsData()` | `$.ajax` → `system/getAnnouncements`, then render list |
| `Common._renderAnnouncementsList(rows)` | jQuery: `$("#…").empty()`, `$("<button/>")`, `$.each`, `.append` / `.text` / `.show` / `.hide`. Rows use **`onclick="Common.OpenAnnouncementPopup(id)"`** (no `.on` bind). |
| `Common.OpenAnnouncementPopup(id)` | jQuery fills modal title / user type / body / dates; body = `full_desc` or fallback `description` |

Header markup lives in `MainPage.html` (`#inpc_announce_*`). Admin module HTML: `html_files/INPC/ia_announcement.html` (LOV includes **All**).

## Admin tip

After adding announcements, hard-refresh MainPage (or re-login) so MenuLoad runs `FillAnnouncementsData` again.