# INPCV2

Spring Boot 3.5 WAR (Java 21) — base for EAP 8 / Eclipse Tomcat 10.1 / OpenShift.

Project handoff and topic docs: [doc/README.md](doc/README.md) (start with [doc/CURSOR_PROJECT_GUIDE.md](doc/CURSOR_PROJECT_GUIDE.md)).

## URLs
- Eclipse / embedded Tomcat: `http://localhost:8080/INPCV2/`
- JBoss EAP 8 (local `standalone.xml`): `http://localhost:8090/INPCV2/`
- Smoke: `http://localhost:8080/INPCV2/api/info` (use port 8090 on EAP)

## Auth
- v1: local/dev (IMEXT off)
- Later: set `security.imext.enabled=true` and use `application-imext.yml`

## Build
```bash
mvn -DskipTests package
```

## Run locally (embedded Tomcat for smoke)
`spring-boot-starter-tomcat` is `provided` for EAP. For a quick local smoke test temporarily set scope to compile or use:
```bash
mvn -DskipTests spring-boot:run
```
(May need tomcat starter without provided for bootRun — see note in pom.)

## Datasources
Configured under `insba.datasources` in `application.yml`:
- `system` — eager
- `as400`, `cir`, `csd`, `pos`… — lazy / menu-driven (`insba.menu-datasources`; `INPC` → `system`)