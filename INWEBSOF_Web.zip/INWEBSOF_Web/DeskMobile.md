# DeskMobile Load Type

Load Type **DeskMobile** opens different HTML for desktop vs mobile viewports, while keeping one shared JS path for data logic.

## When to use

| Load Type | Behavior |
| --- | --- |
| **Internal** | One HTML for all devices: `html_files/{app}/{file_name}.html` |
| **FrameWork** | Schema-driven module open (`getModulesDetailsNew`) |
| **DeskMobile** | Desktop HTML from `file_name`; mobile HTML from `mobile_file_name` |

Use DeskMobile when the layout differs by device but APIs and save/load logic stay the same (typically **2 HTML + 1 JS**).

## Menu Options setup

1. Set **Load Type** = `DeskMobile`.
2. **File Name** = desktop page without `.html` (example: `app_web_test`).
3. **Mobile File Name** = mobile page without `.html` (example: `mobile_app_web_test`).
4. **JS Path** (optional) = one shared script used for both HTML files.

Place files under:

- `src/main/resources/static/html_files/INPC/{file_name}.html`
- `src/main/resources/static/html_files/INPC/{mobile_file_name}.html`

### Test menu (MobDesk)

| Field | Value |
| --- | --- |
| Display / module | MobDesk |
| File Name | `app_web_test` |
| Mobile File Name | `mobile_app_web_test` |
| Load Type | DeskMobile |

Desktop test page is blue; mobile test page is orange so you can tell them apart quickly.

## How selection works

On menu click:

1. Read viewport width (`window.innerWidth`).
2. If width **≤ 767px** → load `mobile_file_name` HTML (when set).
3. Otherwise → load `file_name` HTML.
4. If **Mobile File Name is empty** → always use `file_name` (desktop), even on a narrow window.

Detection is **width-based** (works in a resized browser or Chrome DevTools device mode). It does not require a physical phone.

Shared helpers in `custom_js/common.js`:

```js
Common.IsMobile();      // true when width <= Common.MOBILE_MAX_WIDTH (default 767)
Common.IsDesktop();     // !IsMobile()
Common.GetDeviceType(); // "mobile" | "desktop"
```

Override breakpoint if needed: `Common.MOBILE_MAX_WIDTH = 991;`

## Runtime pieces

| Piece | Role |
| --- | --- |
| `MainPage.js` → `onMenuClick` / `LoadHtmlFilesForDevice` | Picks file by width; DeskMobile leaf clicks go through `onMenuClick` |
| `MainPage.js` → `inpcIsMobileWidth` | Same width rule as `Common.IsMobile` |
| `AuthService` menus query | Returns `mobile_file_name` for side-menu `data-mobile-file-name` |
| DB `ia_menu_options.mobile_file_name` | Stores mobile file (varchar 50) |
| Schema element `mobile_file_name` on Menu Options (schema 117) | Lets FrameWork save the field from the Menu Options form |

## Fallback rules

- Mobile + `mobile_file_name` set → mobile HTML.
- Mobile + `mobile_file_name` empty → **desktop** `file_name`.
- Desktop → always `file_name`.
- Shared `js_path` is registered for both file keys so either HTML can load the same JS.

## Quick check

1. Hard-refresh MainPage (Ctrl+F5).
2. Wide window (≥ 768px) → open MobDesk → blue desktop page (`app_web_test.html`).
3. Narrow window (≤ 767px) or DevTools device mode → reopen MobDesk → orange mobile page (`mobile_app_web_test.html`).

After changing Menu Options, refresh so the side menu rebuilds with updated `data-mobile-file-name`.
