# INPCV2 Project Instructions

## Working Directory

This is the local INPCV2 project.

Always work within the currently opened workspace.

Do not:
- Create another copy of the project
- Clone another repository
- Create an isolated worktree
- Move the project to another directory

## Development Rules

- Inspect existing code before making changes.
- Preserve the existing project architecture.
- Make changes directly to the existing source files.
- Do not rewrite working modules unnecessarily.
- Follow the existing coding style.
- Before changing a database query, inspect related DAO/service code.
- After changes, report the files modified and explain the changes.

## Testing

After making changes:
- Check for compilation errors.
- Run appropriate tests if available.
- Do not run a full production build after every small change unless required.
