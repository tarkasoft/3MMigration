# Auto-deploy to JBoss (exploded WAR)

See **[doc/AutoDeploy-JBoss.md](doc/AutoDeploy-JBoss.md)** for the current setup.

**Summary (2026-10-04):** Eclipse Ant builder `deploy-to-jboss` runs **once after m2e**. The Maven `m2e` profile sets `inpc.jboss.deploy.skip=true` so `process-classes` does not touch `INPCV2.war.dodeploy` inside Eclipse (avoids double redeploy on refresh). CLI `mvn compile` still deploys via antrun.
