@echo off
REM Batch helper to initialize, commit and optionally push the INPCV2 project.
REM Run this from the project folder or double-click it. It will prompt for a remote URL.

SETLOCAL ENABLEDELAYEDEXPANSION
cd /d "%~dp0"
echo Project directory: %CD%

where git >nul 2>nul || (
  echo ERROR: git not found in PATH. Install Git for Windows and rerun.
  pause
  exit /b 1
)

if not exist .git (
  echo Initializing git repository...
  git init
  git branch -M main
) else (
  echo Git repository already initialized.
)

echo Preparing commit (will respect existing .gitignore)...
git add .
git commit -m "Initial commit (add .gitignore)" 2>nul || (
  echo Nothing to commit or commit failed.
)

REM Preconfigured remote for user 'tarkasoft' (embedded per user request).
set "REMOTE_URL=https://github.com/tarkasoft/INPCV2.git"
echo Remote set to %REMOTE_URL%
git remote remove origin 2>nul
git remote add origin %REMOTE_URL%
echo Pushing to origin main. You may be prompted to authenticate.
git push -u origin main
if errorlevel 1 (
  echo Push failed. Check authentication and remote URL.
) else (
  echo Push succeeded.
)

pause
