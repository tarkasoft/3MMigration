package com.mmm.system;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;

/**
 * Generates module HTML under html_files/INPC for generate_html='Yes'.
 * Same approach as {@link CreateGridFiles}. One mapping; no service class.
 *
 * Call: GET/POST titpl/system/createHtmlFiles
 */
@RestController
@RequestMapping("titpl/system")
public class CreateHtmlFiles {

	private static final Logger logger = LogManager.getLogger(CreateHtmlFiles.class);
	private static final String HTML_RELATIVE = "src/main/resources/static/html_files/INPC";

	private final SessionFactory sessionFactory;
	private final String projectBasePath;
	private final String projectDeployPath;
	private final Gson gson = new Gson();

	public CreateHtmlFiles(
			@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory,
			@Value("${inpc.project.base-path:}") String projectBasePath,
			@Value("${inpc.project.deploy-path:}") String projectDeployPath) {
		this.sessionFactory = sessionFactory;
		this.projectBasePath = projectBasePath == null ? "" : projectBasePath.trim();
		this.projectDeployPath = projectDeployPath == null ? "" : projectDeployPath.trim();
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@RequestMapping(value = "createHtmlFiles", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String createHtmlFiles(HttpServletRequest request) {
		Map<String, Object> result = new LinkedHashMap<>();
		List<Map<String, Object>> created = new ArrayList<>();
		List<Map<String, Object>> skipped = new ArrayList<>();

		try {
			List<Path> outDirs = resolveHtmlOutDirs();
			for (Path outDir : outDirs) {
				Files.createDirectories(outDir);
			}

			List<Map<String, Object>> modules = loadModulesForHtml();
			if (modules == null || modules.isEmpty()) {
				result.put("error_code", 0);
				result.put("status", "success");
				result.put("message", "No modules with generate_html=Yes");
				result.put("out_dirs", outDirs.stream().map(p -> p.toAbsolutePath().toString()).toList());
				result.put("created", created);
				result.put("skipped", skipped);
				return gson.toJson(result);
			}

			for (Map<String, Object> mod : modules) {
				String internalCode = str(mod.get("internal_code"));
				String fileName = sanitizeFileName(str(mod.get("file_name")));
				String displayName = str(mod.get("display_name"));
				if (displayName.isEmpty()) {
					displayName = fileName;
				}

				Map<String, Object> row = new LinkedHashMap<>();
				row.put("internal_code", internalCode);
				row.put("display_name", displayName);
				row.put("file_name", fileName);

				if (fileName.isEmpty()) {
					row.put("reason", "empty file_name");
					skipped.add(row);
					continue;
				}

				List<Map<String, Object>> elements = loadElements(sanitizeSchemaCode(internalCode));
				if (elements == null || elements.isEmpty()) {
					row.put("reason", "no schema elements");
					skipped.add(row);
					continue;
				}

				String html = buildModuleHtml(mod, fileName, displayName, elements);
				List<String> paths = new ArrayList<>();
				for (Path outDir : outDirs) {
					Path outFile = outDir.resolve(fileName + ".html");
					Files.writeString(outFile, html, StandardCharsets.UTF_8);
					paths.add(outFile.toAbsolutePath().toString());
					logger.info("Created HTML file: {}", outFile.toAbsolutePath());
				}

				row.put("path", paths.isEmpty() ? "" : paths.get(0));
				row.put("paths", paths);
				row.put("fields", elements.size());
				created.add(row);
			}

			result.put("error_code", 0);
			result.put("status", "success");
			result.put("message", "HTML files generated");
			result.put("out_dirs", outDirs.stream().map(p -> p.toAbsolutePath().toString()).toList());
			result.put("created", created);
			result.put("skipped", skipped);
			result.put("created_count", created.size());
			result.put("skipped_count", skipped.size());
		} catch (Exception ex) {
			logger.error("createHtmlFiles failed: {}", ex.getMessage(), ex);
			result.put("error_code", -1);
			result.put("status", "failure");
			result.put("message", "createHtmlFiles failed: " + ex.getMessage());
			result.put("created", created);
			result.put("skipped", skipped);
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadModulesForHtml() {
		String sql = "select mo.internal_code,"
				+ " isnull(mo.display_name,'') as display_name,"
				+ " isnull(mo.file_name,'') as file_name,"
				+ " isnull(mo.field_position,'TopBottom') as field_position,"
				+ " isnull(mo.grid_position,'Bottom') as grid_position,"
				+ " isnull(mo.html_width,6) as html_width,"
				+ " isnull(mo.grid_width,6) as grid_width,"
				+ " isnull(convert(varchar(20), mo.grid_height),'250') as grid_height,"
				+ " isnull(mg.menu_name,'') as menu_name,"
				+ " isnull(sg.sub_menu_name,'') as sub_menu_name"
				+ " from dbo.ia_menu_options mo"
				+ " left join dbo.ia_menu_groups mg on mg.internal_code = mo.ref_menu_group_code"
				+ " left join dbo.ia_menu_sub_groups sg on sg.internal_code = mo.ref_menu_subgroup_code"
				+ " where mo.generate_html = 'Yes'"
				+ " and mo.active = 'Yes'"
				+ " order by mo.display_name, mo.file_name";
		return NativeQuerySupport.executeQuery(session(), sql);
	}

	private List<Map<String, Object>> loadElements(String schemaCode) {
		String sql = "select isnull(s.name,'') as name,"
				+ " isnull(s.system_name,'') as system_name,"
				+ " isnull(s.field_position,'Next Line') as field_position,"
				+ " isnull(s.field_width,2) as field_width,"
				+ " isnull(s.data_type,'Text') as data_type,"
				+ " isnull(s.text_area_rows,0) as text_area_rows,"
				+ " isnull(s.list_of_values,'') as list_of_values,"
				+ " isnull(convert(varchar(10), s.is_ref_module_code_lov),'0') as is_ref_module_code_lov,"
				+ " isnull(convert(varchar(10), s.populate_lov),'1') as populate_lov,"
				+ " isnull(convert(varchar(20), s.optional),'') as optional,"
				+ " isnull(convert(varchar(30), ref_data.internal_code),'') as ref_module_code,"
				+ " isnull(ref_data.file_name,'') as ref_module_name,"
				+ " isnull(ref_data.display_name,'') as ref_module_display_name"
				+ " from dbo.ia_s_user_schema_elements s"
				+ " left join dbo.ia_menu_options ref_data on s.ref_module_code = ref_data.internal_code"
				+ " where s.ref_s_user_schema_code = " + schemaCode
				+ " and isnull(s.is_multiple_group, 0) = 0"
				+ " order by isnull(s.sequence, 9999), s.internal_code";
		return NativeQuerySupport.executeQuery(session(), sql);
	}

	/**
	 * Write to Eclipse static folder and, when configured, the exploded WAR static folder
	 * so CreateHtmlFiles works without a full rebuild for the running server.
	 */
	private List<Path> resolveHtmlOutDirs() throws IOException {
		if (projectBasePath == null || projectBasePath.isBlank()) {
			throw new IOException(
					"Missing inpc.project.base-path. Set it in portal.properties to the local project root.");
		}
		List<Path> dirs = new ArrayList<>();
		Path baseOut = Paths.get(projectBasePath).toAbsolutePath().normalize().resolve(HTML_RELATIVE).normalize();
		dirs.add(baseOut);
		logger.info("HTML out dir (base): {}", baseOut);

		if (projectDeployPath != null && !projectDeployPath.isBlank()) {
			Path deployRoot = Paths.get(projectDeployPath).toAbsolutePath().normalize();
			Path deployOut = deployRoot.resolve("WEB-INF/classes/static/html_files/INPC").normalize();
			if (!deployOut.equals(baseOut)) {
				dirs.add(deployOut);
				logger.info("HTML out dir (deploy): {}", deployOut);
			}
		}
		return dirs;
	}

	private String buildModuleHtml(Map<String, Object> mod, String fileName, String displayName,
			List<Map<String, Object>> elements) {
		String labelLayout = normalizeModuleFieldPosition(str(mod.get("field_position")));
		String gridPos = normalizeGridPosition(str(mod.get("grid_position")));
		int htmlWidth = clampCol(mod.get("html_width"), 6);
		int gridWidth = clampCol(mod.get("grid_width"), 6);
		String minH = normalizeMinHeight(str(mod.get("grid_height")));
		boolean sideBySide = "Right".equals(gridPos) || "Left".equals(gridPos);

		String formBlock = buildFormSection(fileName, displayName, labelLayout, elements, sideBySide, minH);
		/* Same top spacing for Top/Bottom and Left/Right â€” no extra mt on first block */
		String gridBlock = "\t<div class=\"mt-2\" id=\"grid_" + esc(fileName) + "\"></div>\r\n";
		String crumb = buildBreadcrumb(fileName, displayName, str(mod.get("menu_name")), str(mod.get("sub_menu_name")));

		StringBuilder body = new StringBuilder();
		if (sideBySide) {
			/* Stretch columns so form card min-height matches grid column.
			 * grid_position = where the GRID sits: Right → form|grid ; Left → grid|form */
			body.append("\t<div class=\"row gx-3 gy-0 align-items-stretch mt-0\">\r\n");
			if ("Right".equals(gridPos)) { /* form left, grid right */
				body.append("\t\t<div class=\"col-md-").append(htmlWidth).append(" d-flex\">\r\n");
				body.append(indent(formBlock, 1));
				body.append("\t\t</div>\r\n");
				body.append("\t\t<div class=\"col-md-").append(gridWidth).append(" d-flex flex-column\">\r\n");
				body.append("\t\t\t<div id=\"grid_").append(esc(fileName)).append("\" class=\"w-100 flex-grow-1\" style=\"min-height:")
						.append(esc(minH)).append(";\"></div>\r\n");
				body.append("\t\t</div>\r\n");
			} else {
				body.append("\t\t<div class=\"col-md-").append(gridWidth).append(" d-flex flex-column\">\r\n");
				body.append("\t\t\t<div id=\"grid_").append(esc(fileName)).append("\" class=\"w-100 flex-grow-1\" style=\"min-height:")
						.append(esc(minH)).append(";\"></div>\r\n");
				body.append("\t\t</div>\r\n");
				body.append("\t\t<div class=\"col-md-").append(htmlWidth).append(" d-flex\">\r\n");
				body.append(indent(formBlock, 1));
				body.append("\t\t</div>\r\n");
			}
			body.append("\t</div>\r\n");
		} else if ("Top".equals(gridPos)) {
			body.append(gridBlock);
			body.append(formBlock);
		} else {
			/* Bottom (default): HTML top, grid bottom */
			body.append(formBlock);
			body.append(gridBlock);
		}

		StringBuilder sb = new StringBuilder();
		sb.append("<!-- This file is created by Framework System -->\r\n");
		sb.append("<div class=\"container-fluid px-0 inpc-gen-module\">\r\n");
		sb.append(crumb);
		sb.append("\t<div class=\"inpc-gen-body\">\r\n");
		sb.append(indent(body.toString(), 1));
		sb.append("\t</div>\r\n");
		sb.append("</div>");
		return sb.toString();
	}

	/** Unique breadcrumb host per module page (id includes file_name). */
	private String buildBreadcrumb(String fileName, String displayName, String menuName, String subMenuName) {
		StringBuilder sb = new StringBuilder();
		sb.append("\t<nav id=\"breadcrumb_").append(esc(fileName))
				.append("\" class=\"inpc-module-breadcrumb mb-2\" aria-label=\"breadcrumb\">\r\n");
		sb.append("\t\t<ol class=\"breadcrumb mb-0 py-0 px-0\">\r\n");
		sb.append("\t\t\t<li class=\"breadcrumb-item\"><a href=\"javascript:void(0);\" onclick=\"LoadHtmlFiles(window.inpcHomeModuleForUserType ? window.inpcHomeModuleForUserType(window.inpcGetLoginUserType ? window.inpcGetLoginUserType() : '') : 'home_customer','Home','Home','0');\">Home</a></li>\r\n");
		if (menuName != null && !menuName.isBlank()) {
			sb.append("\t\t\t<li class=\"breadcrumb-item\">").append(esc(menuName.trim())).append("</li>\r\n");
		}
		if (subMenuName != null && !subMenuName.isBlank()) {
			sb.append("\t\t\t<li class=\"breadcrumb-item\">").append(esc(subMenuName.trim())).append("</li>\r\n");
		}
		sb.append("\t\t\t<li class=\"breadcrumb-item active\" aria-current=\"page\">").append(esc(displayName))
				.append("</li>\r\n");
		sb.append("\t\t</ol>\r\n");
		sb.append("\t</nav>\r\n");
		return sb.toString();
	}

	private String buildFormSection(String fileName, String displayName, String labelLayout,
			List<Map<String, Object>> elements, boolean sideBySide, String minHeight) {
		StringBuilder sb = new StringBuilder();
		sb.append("\t<div id=\"m_").append(esc(fileName)).append("\" class=\"w-100");
		if (sideBySide) {
			sb.append(" h-100");
		}
		sb.append("\">\r\n");
		sb.append("\t\t<div class=\"card border-0 shadow-sm");
		if (sideBySide) {
			sb.append(" h-100");
		}
		sb.append("\"");
		if (sideBySide) {
			sb.append(" style=\"min-height:").append(esc(minHeight)).append(";\"");
		}
		sb.append(">\r\n");
		sb.append("\t\t\t<div class=\"card-body p-3 d-flex flex-column\">\r\n");
		sb.append("\t\t\t\t<div class=\"d-flex align-items-center gap-2 mb-3\">\r\n");
		sb.append("\t\t\t\t\t<span class=\"d-inline-flex align-items-center justify-content-center rounded-circle bg-primary bg-opacity-10 text-primary\" style=\"width:2.25rem;height:2.25rem;\">\r\n");
		sb.append("\t\t\t\t\t\t<i class=\"ri-file-list-3-line\"></i>\r\n");
		sb.append("\t\t\t\t\t</span>\r\n");
		sb.append("\t\t\t\t\t<div>\r\n");
		sb.append("\t\t\t\t\t\t<h6 class=\"mb-0 fw-semibold\">").append(esc(displayName)).append("</h6>\r\n");
		sb.append("\t\t\t\t\t\t<small class=\"text-muted\">Fields marked <span style=\"color:#FC4170;\">*</span> are required.</small>\r\n");
		sb.append("\t\t\t\t\t</div>\r\n");
		sb.append("\t\t\t\t</div>\r\n");
		sb.append(buildFieldsHtml(fileName, labelLayout, elements));
		sb.append("\t\t\t\t<div id=\"page_main_actions_div\" class=\"d-flex justify-content-end align-items-center flex-wrap gap-2 mt-auto pt-3 border-top\"></div>\r\n");
		sb.append("\t\t\t</div>\r\n");
		sb.append("\t\t</div>\r\n");
		sb.append("\t</div>\r\n");
		return sb.toString();
	}

	private String buildFieldsHtml(String fileName, String labelLayout, List<Map<String, Object>> elements) {
		StringBuilder sb = new StringBuilder();
		boolean rowOpen = false;
		int colSum = 0;

		for (Map<String, Object> el : elements) {
			String sys = sanitizeJsIdent(str(el.get("system_name")));
			if (sys.isEmpty()) {
				continue;
			}
			String name = str(el.get("name"));
			if (name.isEmpty()) {
				name = sys;
			}
			int fw = clampCol(el.get("field_width"), 2);
			String ePos = normalizeElementFieldPosition(str(el.get("field_position")));
			boolean nextLine = "NextLine".equals(ePos);

			if (!rowOpen || nextLine || colSum + fw > 12) {
				if (rowOpen) {
					sb.append("\t\t\t\t</div>\r\n");
				}
				sb.append("\t\t\t\t<div class=\"row g-4\">\r\n");
				rowOpen = true;
				colSum = 0;
			}

			sb.append(buildOneField(fileName, name, sys, fw, labelLayout, el));
			colSum += fw;
		}
		if (rowOpen) {
			sb.append("\t\t\t\t</div>\r\n");
		}
		return sb.toString();
	}

	private String buildOneField(String fileName, String name, String sys, int fw, String labelLayout,
			Map<String, Object> el) {
		boolean required = isRequired(str(el.get("optional")));
		String dataType = str(el.get("data_type")).trim();
		String star = required ? "<span style=\"color:#FC4170;\">*</span>" : "";
		String control = buildControl(fileName, name, sys, dataType, el);

		StringBuilder sb = new StringBuilder();
		sb.append("\t\t\t\t\t<div class=\"col-md-").append(fw).append(" col-xl-").append(fw).append(" mb-3\">\r\n");
		if ("LeftRight".equals(labelLayout)) {
			sb.append("\t\t\t\t\t\t<div class=\"row g-2 align-items-center\">\r\n");
			sb.append("\t\t\t\t\t\t\t<div class=\"col-sm-4\">\r\n");
			sb.append("\t\t\t\t\t\t\t\t<label class=\"form-label mb-0\" for=\"").append(labelFor(sys, dataType, el))
					.append("\">").append(esc(name)).append(star).append("</label>\r\n");
			sb.append("\t\t\t\t\t\t\t</div>\r\n");
			sb.append("\t\t\t\t\t\t\t<div class=\"col-sm-8\">\r\n");
			sb.append(indent(control, 2));
			sb.append("\t\t\t\t\t\t\t</div>\r\n");
			sb.append("\t\t\t\t\t\t</div>\r\n");
		} else {
			if (!"Checkbox".equalsIgnoreCase(dataType)) {
				sb.append("\t\t\t\t\t\t<label class=\"form-label mb-1\" for=\"").append(labelFor(sys, dataType, el))
						.append("\">").append(esc(name)).append(star).append("</label>\r\n");
			}
			sb.append(indent(control, 1));
		}
		sb.append("\t\t\t\t\t</div>\r\n");
		return sb.toString();
	}

	private static String labelFor(String sys, String dataType, Map<String, Object> el) {
		/* Popup ref field labels the search box. LOV ref field labels the select. */
		if ("Reference Data".equalsIgnoreCase(dataType) && !isRefModuleCodeLov(el)) {
			return "txt_ref_schema_" + sys;
		}
		return sys;
	}

	private String buildControl(String fileName, String name, String sys, String dataType, Map<String, Object> el) {
		String dt = dataType == null ? "Text" : dataType.trim();
		StringBuilder sb = new StringBuilder();

		if ("List Of Values".equalsIgnoreCase(dt)) {
			sb.append("<select tabindex=\"1\" data-placeholder=\"Choose a ").append(esc(name))
					.append("\" class=\"form-select form-select-sm\" id=\"").append(esc(sys)).append("\">\r\n");
			String lov = str(el.get("list_of_values"));
			if (!lov.isEmpty()) {
				String[] parts = lov.split("\\|");
				for (String p : parts) {
					String v = p == null ? "" : p.trim();
					if (v.isEmpty()) {
						continue;
					}
					sb.append("\t<option value=\"").append(esc(v)).append("\">").append(esc(v)).append("</option>\r\n");
				}
			}
			sb.append("</select>\r\n");
			return sb.toString();
		}

		if ("Reference Data".equalsIgnoreCase(dt) && isRefModuleCodeLov(el)) {
			/* Options are filled at runtime by AssignRefModuleLovValues. */
			sb.append("<select tabindex=\"1\" data-placeholder=\"Choose a ").append(esc(name))
					.append("\" class=\"form-select form-select-sm\" id=\"").append(esc(sys)).append("\">\r\n");
			sb.append("</select>\r\n");
			return sb.toString();
		}

		if ("Reference Data".equalsIgnoreCase(dt)) {
			String refMod = sanitizeFileName(str(el.get("ref_module_name")));
			if (refMod.isEmpty()) {
				refMod = "ia_menu_options";
			}
			sb.append("<div class=\"input-group input-group-sm position-relative\">\r\n");
			sb.append("\t<input class=\"form-control form-control-sm\" id=\"").append(esc(sys))
					.append("\" type=\"hidden\" value=\"0\" />\r\n");
			sb.append("\t<input placeholder=\"Search for...\" class=\"form-control form-control-sm\" on_exit=\"0\" id=\"txt_ref_schema_")
					.append(esc(sys)).append("\" onblur=\"all_obj.ClearReferenceData('").append(esc(fileName))
					.append("','").append(esc(sys)).append("')\">\r\n");
			sb.append("\t<span id=\"").append(esc(sys)).append("_ac_spinner\" class=\"inpc-ac-spinner\" role=\"status\" aria-hidden=\"true\" hidden>\r\n");
			sb.append("\t\t<span class=\"spinner-border spinner-border-sm text-primary\" aria-hidden=\"true\"></span>\r\n");
			sb.append("\t</span>\r\n");
			String refDisplay = str(el.get("ref_module_display_name"));
			if (refDisplay.isEmpty()) {
				refDisplay = refMod;
			}
			sb.append("\t<button type=\"button\" class=\"btn btn-outline-secondary btn-sm\" onclick=\"POPUP.OpenFWPopup('")
					.append(esc(refMod)).append("','").append(esc(fileName)).append("' ,'").append(esc(sys))
					.append("','").append(esc(refDisplay)).append("');\"><i class=\"ri-search-line\"></i></button>\r\n");
			sb.append("</div>\r\n");
			return sb.toString();
		}

		if ("Checkbox".equalsIgnoreCase(dt)) {
			sb.append("<div class=\"form-check mt-1\">\r\n");
			sb.append("\t<input class=\"form-check-input\" type=\"checkbox\" id=\"").append(esc(sys)).append("\">\r\n");
			sb.append("\t<label class=\"form-check-label\" for=\"").append(esc(sys)).append("\">")
					.append(esc(name)).append("</label>\r\n");
			sb.append("</div>\r\n");
			return sb.toString();
		}

			if ("Date".equalsIgnoreCase(dt)) {
			/* Input-group + calendar icon → all_obj.CallTarkaDatePickerNew (MainPageNew.js) */
			String mOpt = isRequired(str(el.get("optional"))) ? "0" : "1";
			sb.append("<div class=\"input-group input-group-sm\" data-date-format=\"dd/mm/yyyy\" data-date-viewmode=\"years\">\r\n");
			sb.append("\t<input m_optional=\"").append(mOpt)
					.append("\" type=\"text\" class=\"form-control form-control-sm date date-picker\" value=\"00/00/0000\" placeholder=\"dd/mm/yyyy\" id=\"")
					.append(esc(sys)).append("\">\r\n");
			sb.append("\t<span class=\"input-group-text\"><i class=\"ri-calendar-2-line text-primary fs-15\" style=\"cursor:pointer;\" onclick=\"all_obj.CallTarkaDatePickerNew('")
					.append(esc(fileName)).append("','").append(esc(sys)).append("')\"></i></span>\r\n");
			sb.append("</div>\r\n");
			return sb.toString();
		}

		if ("Month".equalsIgnoreCase(dt)) {
			String mOptM = isRequired(str(el.get("optional"))) ? "0" : "1";
			sb.append("<div class=\"input-group input-group-sm\" data-date-format=\"mm/yyyy\" data-date-viewmode=\"years\">\r\n");
			sb.append("\t<input m_optional=\"").append(mOptM)
					.append("\" type=\"text\" class=\"form-control form-control-sm date date-picker\" value=\"\" placeholder=\"mm/yyyy\" id=\"")
					.append(esc(sys)).append("\">\r\n");
			sb.append("\t<span class=\"input-group-text\"><i class=\"ri-calendar-2-line text-primary fs-15\" style=\"cursor:pointer;\" onclick=\"all_obj.CallTarkaDatePickerNew('")
					.append(esc(fileName)).append("','").append(esc(sys)).append("')\"></i></span>\r\n");
			sb.append("</div>\r\n");
			return sb.toString();
		}

		if ("Number".equalsIgnoreCase(dt)) {
			sb.append("<input type=\"text\" inputmode=\"decimal\" placeholder=\"").append(esc(name))
					.append("\" class=\"form-control form-control-sm\" id=\"").append(esc(sys)).append("\">\r\n");
			return sb.toString();
		}

		if (isTextAreaType(dt)) {
			/* ia_s_user_schema_elements.text_area_rows; empty / 0 / null → 3 */
			int rows = textAreaRows(el);
			sb.append("<textarea rows=\"").append(rows).append("\" placeholder=\"").append(esc(name))
					.append("\" class=\"form-control form-control-sm\" id=\"").append(esc(sys)).append("\"></textarea>\r\n");
			return sb.toString();
		}

		/* Text (default) */
		sb.append("<input type=\"text\" placeholder=\"").append(esc(name))
				.append("\" class=\"form-control form-control-sm\" id=\"").append(esc(sys)).append("\">\r\n");
		return sb.toString();
	}

	/** is_ref_module_code_lov = 1 → dropdown, not the reference popup. */
	private static boolean isRefModuleCodeLov(Map<String, Object> el) {
		String v = str(el.get("is_ref_module_code_lov")).trim();
		return "1".equals(v) || "1.0".equals(v);
	}

	/** TextArea, Text Area, and Large Text all render a textarea. */
	private static boolean isTextAreaType(String dataType) {
		if (dataType == null) {
			return false;
		}
		String dt = dataType.trim();
		return "TextArea".equalsIgnoreCase(dt)
				|| "Text Area".equalsIgnoreCase(dt)
				|| "Large Text".equalsIgnoreCase(dt);
	}

	/**
	 * Rows from elements.text_area_rows. Blank, null, or 0 (form default) uses 3.
	 */
	private static int textAreaRows(Map<String, Object> el) {
		String raw = str(el.get("text_area_rows")).trim();
		if (raw.isEmpty()) {
			return 3;
		}
		try {
			int r = (int) Math.round(Double.parseDouble(raw));
			if (r > 0) {
				return r;
			}
		} catch (Exception ignore) { /* keep default 3 */ }
		return 3;
	}

	/** optional Yes/1 = not required; 0/No/blank = required (FW style). */
	private static boolean isRequired(String optional) {
		String o = optional == null ? "" : optional.trim();
		if (o.isEmpty()) {
			return true;
		}
		return !(o.equalsIgnoreCase("Yes") || o.equals("1") || o.equalsIgnoreCase("true") || o.equalsIgnoreCase("Y"));
	}

	private static String normalizeModuleFieldPosition(String raw) {
		String s = raw == null ? "" : raw.replace(" ", "").trim();
		if (s.equalsIgnoreCase("LeftRight")) {
			return "LeftRight";
		}
		return "TopBottom";
	}

	private static String normalizeElementFieldPosition(String raw) {
		String s = raw == null ? "" : raw.replace(" ", "").trim();
		if (s.equalsIgnoreCase("NextColumn")) {
			return "NextColumn";
		}
		return "NextLine";
	}

	private static String normalizeGridPosition(String raw) {
		String s = raw == null ? "" : raw.trim();
		if (s.equalsIgnoreCase("Top")) {
			return "Top";
		}
		if (s.equalsIgnoreCase("Left")) {
			return "Left"; // grid on the left, form on the right
		}
		if (s.equalsIgnoreCase("Right")) {
			return "Right"; // form on the left, grid on the right
		}
		return "Bottom"; // form on top, grid below
	}

	/** grid_height from menu â†’ CSS min-height (px if bare number). */
	private static String normalizeMinHeight(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty() || "null".equalsIgnoreCase(s)) {
			return "250px";
		}
		if (s.matches("\\d+(\\.\\d+)?")) {
			return s + "px";
		}
		return s;
	}

	private static int clampCol(Object raw, int def) {
		try {
			int n = (int) Math.round(Double.parseDouble(String.valueOf(raw)));
			if (n < 1) {
				return 1;
			}
			if (n > 12) {
				return 12;
			}
			return n;
		} catch (Exception e) {
			return def;
		}
	}

	private static String indent(String block, int extraTabs) {
		if (block == null || block.isEmpty()) {
			return "";
		}
		String pad = "\t".repeat(Math.max(0, extraTabs));
		String[] lines = block.split("\\r?\\n", -1);
		StringBuilder sb = new StringBuilder();
		for (String line : lines) {
			if (line.isEmpty()) {
				sb.append("\r\n");
			} else {
				sb.append(pad).append(line).append("\r\n");
			}
		}
		return sb.toString();
	}

	private static String sanitizeSchemaCode(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty() || !s.matches("\\d+")) {
			return "0";
		}
		return s;
	}

	private static String sanitizeFileName(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty()) {
			return "";
		}
		s = s.replace('\\', '/');
		int slash = s.lastIndexOf('/');
		if (slash >= 0) {
			s = s.substring(slash + 1);
		}
		if (s.toLowerCase(Locale.ROOT).endsWith(".html")) {
			s = s.substring(0, s.length() - 5);
		}
		if (s.toLowerCase(Locale.ROOT).endsWith(".js")) {
			s = s.substring(0, s.length() - 3);
		}
		s = s.replaceAll("[^A-Za-z0-9_\\-]", "");
		return s;
	}

	private static String sanitizeJsIdent(String raw) {
		return str(raw).trim().replaceAll("[^A-Za-z0-9_]", "");
	}

	private static String esc(String s) {
		if (s == null) {
			return "";
		}
		return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
				.replace("'", "&#39;");
	}

	private static String str(Object o) {
		if (o == null) {
			return "";
		}
		String s = String.valueOf(o);
		return "null".equalsIgnoreCase(s) ? "" : s;
	}
}