package com.mmm.system;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jakarta.persistence.PersistenceException;
import jakarta.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.FWValidation;
import com.mmm.titpl.Format;

/**
 * jqGrid data + delete for user-schema modules (ServiceBilling DisplayGrid port).
 * Spring TX + getCurrentSession; SELECT via NativeQuerySupport.executeQuery.
 */
@RestController
@RequestMapping("titpl/display_grid")
public class DisplayGrid {

	private final SessionFactory sessionFactory;
	static Logger logger = LogManager.getLogger(DisplayGrid.class);
	String loginId = "";

	public DisplayGrid(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "viewUserSchemaModuleDetails", method = RequestMethod.GET)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String viewUserSchemaModuleDetails(HttpServletRequest request,
			@RequestParam("rows") int limit, @RequestParam("page") int page,
			@RequestParam("sidx") String sidx, @RequestParam("sord") String sord,
			@RequestParam("_search") String search, @RequestParam("table_name") String table_name)
			throws SQLException, ClassNotFoundException {

		loginId = Format.GetSessonUserId(request);
		ArrayList fields_arr = new ArrayList();
		String filter_cond = "";
		int count = 0;
		int total_pages = 0;
		List<Map<String, Object>> query_data_obj = null;
		Gson gson = new Gson();

		Session session = session();
		try {
			JSONObject qry_obj = new JSONObject();
			JSONObject s_field_obj = new JSONObject();
			qry_obj = GetGridQuery(session, table_name, "include_in_grid", "");

			fields_arr = (ArrayList) qry_obj.get("fields_arr");

			String full_qry = (String) qry_obj.get("full_qry");
			String cnt_qry = (String) qry_obj.get("cnt_qry");
			s_field_obj = (JSONObject) qry_obj.get("s_field_obj");
			String sort_detail = " ORDER BY " + table_name + ".internal_code " + sord;
			if (!sidx.equals("id") && s_field_obj != null && s_field_obj.containsKey(sidx)) {
				sort_detail = " ORDER BY " + s_field_obj.get(sidx) + " " + sord;
			}
			if (search.equals("true")) {
				filter_cond = GetGridFilterConditions(request, s_field_obj);
			}
			System.out.println("filter_cond---" + filter_cond);
			cnt_qry = "select " + full_qry + " where 1=1 " + filter_cond;
			count = GetCountFromQry(session, cnt_qry);
			total_pages = 0;

			if (count > 0) {
				total_pages = (int) Math.ceil(count / limit);
			}
			if (total_pages == 0)
				total_pages = 1;
			System.out.println("total_pagessssss--" + total_pages);
			if (page > total_pages)
				page = total_pages;
			int start = limit * page - limit;
			if (start < 0)
				start = 0;

			String e_qry = " select * from ( SELECT ROW_NUMBER() OVER (" + sort_detail + ") as row ," + full_qry;
			e_qry += " where 1=1 " + filter_cond + ")  a WHERE row > " + start + " and row <= " + limit * page;
			logger.info("*******Final s Qry==>" + e_qry);
			List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session, e_qry);
			if (rows != null && rows.size() > 0) {
				query_data_obj = rows;
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("viewUserSchemaModuleDetails PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("viewUserSchemaModuleDetails RuntimeException: " + ex.getMessage(), ex);
		}

		JSONObject grid_data_obj = new JSONObject();
		grid_data_obj.put("page", page);
		grid_data_obj.put("total", total_pages);
		grid_data_obj.put("records", count);
		grid_data_obj.put("rows", query_data_obj);

		return gson.toJson(grid_data_obj);
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "viewUserSchemaSrefDataDetails", method = RequestMethod.GET)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String viewUserSchemaSrefDataDetails(HttpServletRequest request,
			@RequestParam("rows") int limit, @RequestParam("page") int page,
			@RequestParam("sidx") String sidx, @RequestParam("sord") String sord,
			@RequestParam("_search") String search, @RequestParam("pop_up_table_name") String table_name,
			@RequestParam("calling_table_name") String calling_table_name,
			@RequestParam("clicked_id_system_name") String clicked_id_system_name,
			@RequestParam Map<String, String> param_map) throws SQLException, ClassNotFoundException {

		loginId = Format.GetSessonUserId(request);
		ArrayList fields_arr = new ArrayList();
		String filter_cond = "";
		int count = 0;
		int total_pages = 0;
		List<Map<String, Object>> query_data_obj = null;
		Gson gson = new Gson();

		Session session = session();
		try {
			JSONObject qry_obj = new JSONObject();
			JSONObject s_field_obj = new JSONObject();
			qry_obj = GetGridQuery(session, table_name, "include_in_popup", "");

			fields_arr = (ArrayList) qry_obj.get("fields_arr");

			String full_qry = (String) qry_obj.get("full_qry");
			s_field_obj = (JSONObject) qry_obj.get("s_field_obj");
			String sort_detail = " ORDER BY " + table_name + ".internal_code " + sord;
			String new_filter_cond = FWValidation.GetAutoCompleteExtraCond(request, session, "Popup", calling_table_name,
					clicked_id_system_name);
			String pop_up_cond = "";
			if (param_map != null && param_map.containsKey("all_data_obj")) {
				String all_data_obj_str = param_map.get("all_data_obj");
				if (all_data_obj_str != null && !all_data_obj_str.equals("[object Object]")) {
					pop_up_cond = FWValidation.GetPopUpFilerData(session, calling_table_name, table_name,
							all_data_obj_str, clicked_id_system_name);
				}
			}

			if (!sidx.equals("id") && s_field_obj != null && s_field_obj.containsKey(sidx)) {
				sort_detail = " ORDER BY " + s_field_obj.get(sidx) + " " + sord;
			}
			if (search.equals("true")) {
				filter_cond = GetGridFilterConditions(request, s_field_obj);
			}
			// Same count approach as viewUserSchemaModuleDetails (list.size of data select)
			String cnt_qry = "select " + full_qry + " where 1=1 " + filter_cond + new_filter_cond + pop_up_cond;
			count = GetCountFromQry(session, cnt_qry);
			total_pages = 0;

			if (count > 0) {
				total_pages = (int) Math.ceil(count / limit);
			}
			if (total_pages == 0)
				total_pages = 1;

			if (page > total_pages)
				page = total_pages;
			int start = limit * page - limit;
			if (start < 0)
				start = 0;

			String e_qry = " select * from ( SELECT ROW_NUMBER() OVER (" + sort_detail + ") as row ," + full_qry;
			e_qry += " where 1=1  " + filter_cond + new_filter_cond + pop_up_cond + " )  a WHERE row > " + start
					+ " and row <= " + limit * page;
			logger.info("*******viewUserSchemaSrefDataDetails Final s Qry==>" + e_qry);
			List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session, e_qry);
			if (rows != null && rows.size() > 0) {
				query_data_obj = rows;
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("viewUserSchemaSrefDataDetails PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("viewUserSchemaSrefDataDetails RuntimeException: " + ex.getMessage(), ex);
		} catch (Exception ex) {
			logger.error("viewUserSchemaSrefDataDetails Exception: " + ex.getMessage(), ex);
		}

		JSONObject grid_data_obj = new JSONObject();
		grid_data_obj.put("page", page);
		grid_data_obj.put("total", total_pages);
		grid_data_obj.put("records", count);
		grid_data_obj.put("rows", query_data_obj);

		return gson.toJson(grid_data_obj);
	}

	@SuppressWarnings("unchecked")
	String GetGridFilterConditions(HttpServletRequest request, JSONObject field_arr) {
		String filter_cond = "";
		if (field_arr == null) {
			return filter_cond;
		}
		for (Map.Entry<String, String[]> entry : ((Map<String, String[]>) request.getParameterMap()).entrySet()) {
			String key_name = entry.getKey();
			String[] value = entry.getValue();
			if (field_arr.containsKey(key_name)) {
				filter_cond += " and " + field_arr.get(key_name) + " like '" + value[0] + "%'";
			}
		}
		logger.info("Grid Filter cond==" + filter_cond);
		return filter_cond;
	}

	int GetCountFromQry(Session session, String cnt_qry) {
		List<Map<String, Object>> list = new ArrayList<>();
		System.out.println(cnt_qry);
		try {
			list = NativeQuerySupport.executeQuery(session, cnt_qry);
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("GetCountFromQry PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("GetCountFromQry RuntimeException: " + ex.getMessage(), ex);
		}
		return list == null ? 0 : list.size();
	}

	@SuppressWarnings("unchecked")
	public JSONObject GetGridQuery(Session session, String table_name, String type, String extra_cond) {
		String type_cond = " ";
		if (!type.isEmpty())
			type_cond = " and  su." + type + "=1 ";
		String join_qry = GetRefModuleJoinQuery(session, table_name, type);
		logger.info(" grid join qry-->" + join_qry);
		JSONObject qry_obj = new JSONObject();
		JSONObject s_field_obj = new JSONObject();
		ArrayList fields_arr = new ArrayList();
		qry_obj.put("full_qry", "");
		qry_obj.put("cnt_qry", "");
		qry_obj.put("fields_arr", fields_arr);
		qry_obj.put("s_field_obj", "");

		String qry = "select ";
		qry += "		case when data_type='Reference Data' then 'isnull('+f1+f2 +','''') as '+field_name	 ";
		qry += "		when data_type='Date' then 'convert(varchar(10),'+table_name+'.'+field_name+ ',103) as '+ field_name ";
		qry += "		when data_type='Number' then 'isnull('+table_name+'.'+field_name+',''0'') as '+ field_name    ";
		qry += "		else 'isnull('+table_name+'.'+field_name+','''') as '+ field_name  ";
		qry += "	end as field_name,field_name as u_field_name, ";
		qry += " case when data_type='Reference Data' then 'isnull('+f1+f2 +','''')   '";
		qry += " when data_type='Date' then 'convert(varchar(10),'+table_name+'.'+field_name+ ',103)  '";
		qry += "	when data_type='Number' then 'isnull('+table_name+'.'+field_name+',''0'') '    ";
		qry += "	else 'isnull('+table_name+'.'+field_name+','''') '    	end as s_field_name  ";
		qry += " from  ";
		qry += " (select  su.sequence su_seq,s.internal_code, su.internal_code as ele_id, ";
		qry += " ref_module_code, s.file_name as table_name ,s.display_name, ";
		qry += " field_id,";
		qry += " case when isnull(field_id1,'')<>'' then table_name+'_'+convert(varchar(10),su.internal_code)+'.'+field_id1 else '' end as f1, ";
		qry += " case when isnull(field_id2,'')<>'' then '+'' -''+ '+table_name+'_'+convert(varchar(10),su.internal_code)+'.'+field_id2 else '' end  as f2, ";

		qry += "  isnull(is_multiple_group,0) as multiple , ";
		qry += " system_name as field_name , data_type ";
		qry += " from ia_menu_options s inner join ia_s_user_schema_elements su on ";
		qry += " su.ref_s_user_schema_code=s.internal_code ";
		qry += "  left join ia_module_meta_columns mmc on mmc.module_id=su.ref_module_code ";
		qry += " where s.file_name='" + table_name + "' " + type_cond + " " + extra_cond;
		qry += " and su.is_multiple_group=0 ";
		qry += " ) l  ";
		qry += " where   multiple=0  order by su_seq ";

		logger.info("*******Display Field s Qry==>" + qry);
		int field_records_found = 0;
		String field_name = "";
		try {
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, qry);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				field_records_found = 1;
				for (Map<String, Object> map : query_data_obj) {
					String t_field_name = map.get("field_name") == null ? "" : map.get("field_name").toString();
					field_name += t_field_name + ",";

					Object ufn = map.get("u_field_name");
					Object sfn = map.get("s_field_name");
					if (ufn != null) {
						fields_arr.add(ufn.toString());
						s_field_obj.put(ufn.toString(), sfn == null ? "" : sfn.toString());
					}
				}
				if (field_name.length() > 0) {
					field_name = field_name.substring(0, field_name.length() - 1);
				}
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("GetGridQuery PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("GetGridQuery RuntimeException: " + ex.getMessage(), ex);
		}

		if (field_records_found == 1) {
			String full_qry = table_name + ".internal_code as id," + field_name;
			full_qry += "  from ";
			full_qry += table_name + join_qry;

			String cnt_qry = " select count(1) as cnt ";
			cnt_qry += " from ";
			cnt_qry += table_name + " as " + table_name;

			qry_obj.put("full_qry", full_qry);
			qry_obj.put("cnt_qry", cnt_qry);
			qry_obj.put("fields_arr", fields_arr);
			qry_obj.put("s_field_obj", s_field_obj);
		}

		return qry_obj;
	}

	String GetRefModuleJoinQuery(Session session, String table_name, String type) {
		String type_cond = " ";
		if (!type.isEmpty())
			type_cond = " and  sus." + type + "=1 ";

		String join_qry = " ";
		String qry = "select ' left join '+s.file_name+ ' as '+s.file_name+'_'+convert(varchar(10),sus.internal_code)+' on '+s.file_name+'_'+convert(varchar(10),sus.internal_code)+'.internal_code ='+ sch.file_name +'.'+ system_name  as join_table_name ";
		qry += "	from ia_s_user_schema_elements  sus";
		qry += " inner join ia_menu_options sch on sus.ref_s_user_schema_code=sch.internal_code";
		qry += " inner join ia_menu_options s on sus.ref_module_code=s.internal_code ";

		qry += " where sch.file_name='" + table_name + "' " + type_cond;
		qry += " and is_multiple_group=0 and ref_module_code>0;";

		try {
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, qry);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				for (Map<String, Object> map : query_data_obj) {
					Object jtn = map.get("join_table_name");
					if (jtn != null) {
						join_qry += jtn.toString() + " ";
					}
				}
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("GetRefModuleJoinQuery PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("GetRefModuleJoinQuery RuntimeException: " + ex.getMessage(), ex);
		}

		return join_qry;
	}

	@RequestMapping("deleteUserSchemaModuleDetails.demo")
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String deleteUserSchemaModuleDetails(HttpServletRequest request,
			@RequestParam("id") String id, @RequestParam("table_name") String table_name)
			throws SQLException, ClassNotFoundException {
		Gson gson = new Gson();
		JSONObject qry_obj = new JSONObject();
		Session session = session();

		try {
			CreateTablesAndElements.dropOnDelete(session, table_name, id);
			String del_qry = "delete from " + table_name + " where internal_code in (" + id + ") ";
			Query query = session.createNativeQuery(del_qry);
			query.executeUpdate();

			DeleteUserSchemaMouduleGroupDetails(session, id, table_name);

			qry_obj.put("msg", "deleted Successfully");
			qry_obj.put("internal_code", id);
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			qry_obj.put("msg", cause != null ? cause.toString() : ex.toString());
			qry_obj.put("internal_code", id);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			logger.error("deleteUserSchemaModuleDetails PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			qry_obj.put("msg", ex.getCause() != null ? ex.getCause().toString() : ex.toString());
			qry_obj.put("internal_code", id);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			logger.error("deleteUserSchemaModuleDetails RuntimeException: " + ex.getMessage(), ex);
		}

		return gson.toJson(qry_obj);
	}

	private void DeleteUserSchemaMouduleGroupDetails(Session session, String id, String table_name)
			throws PersistenceException {
		String select_qry = "select file_name+'_'+system_group_table_name+'_group' as grp_table  "
				+ "from ia_menu_options u "
				+ "inner join ia_s_user_schema_group g on g.ref_s_user_schema_code=u.internal_code "
				+ "where u.file_name='" + table_name + "' ";

		logger.info("DeleteUserSchemaMouduleGroupDetails- select_qry: " + select_qry);
		try {
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, select_qry);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				for (Map<String, Object> map : query_data_obj) {
					Object gt = map.get("grp_table");
					if (gt == null) {
						continue;
					}
					String grp_table = gt.toString();
					String del_qry = "delete from " + grp_table + " where ref_s_ref_data_code in (" + id + ") ";
					logger.info("DeleteUserSchemaMouduleGroupDetails- delete_qry: " + del_qry);
					Query query = session.createNativeQuery(del_qry);
					query.executeUpdate();
				}
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			throw ex;
		} catch (RuntimeException ex) {
			logger.error("DeleteUserSchemaMouduleGroupDetails RuntimeException: " + ex.getMessage(), ex);
			throw ex;
		}
	}
}
