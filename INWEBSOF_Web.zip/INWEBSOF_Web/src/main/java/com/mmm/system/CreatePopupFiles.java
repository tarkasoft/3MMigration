package com.mmm.system;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;

/**
 * Generates popup jqGrid JS files under grid_display_files/INPC
 * (pop_up_{file_name}.js), same module set as {@link CreateGridFiles}, but
 * schema elements filtered by include_in_popup=1 (grid uses include_in_grid).
 *
 * Template matches existing files such as pop_up_ia_menu_options.js
 * (#table_grid1 / #sub_grid_div1, viewUserSchemaSrefDataDetails).
 *
 * Call: GET/POST titpl/system/createPopupFiles
 */
@RestController
@RequestMapping("titpl/system")
public class CreatePopupFiles {

	private static final Logger logger = LogManager.getLogger(CreatePopupFiles.class);
	private static final String DEFAULT_GRID_HEIGHT = "250";
	private static final String GRID_RELATIVE = "src/main/resources/static/grid_display_files/INPC";

	private final SessionFactory sessionFactory;
	private final String projectBasePath;
	private final String projectDeployPath;
	private final Gson gson = new Gson();

	public CreatePopupFiles(
			@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory,
			@Value("${inpc.project.base-path:}") String projectBasePath,
			@Value("${inpc.project.deploy-path:}") String projectDeployPath) {
		this.sessionFactory = sessionFactory;
		this.projectBasePath = projectBasePath == null ? "" : projectBasePath.trim();
		this.projectDeployPath = projectDeployPath == null ? "" : projectDeployPath.trim();
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@RequestMapping(value = "createPopupFiles", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String createPopupFiles(HttpServletRequest request) {
		Map<String, Object> result = new LinkedHashMap<>();
		List<Map<String, Object>> created = new ArrayList<>();
		List<Map<String, Object>> skipped = new ArrayList<>();

		try {
			List<Path> outDirs = resolvePopupOutDirs();
			for (Path d : outDirs) {
				Files.createDirectories(d);
			}

			List<Map<String, Object>> modules = loadModulesForPopup();
			if (modules == null || modules.isEmpty()) {
				result.put("error_code", 0);
				result.put("status", "success");
				result.put("message", "No modules with generate_grid=Yes");
				result.put("out_dirs", outDirs.stream().map(p -> p.toAbsolutePath().toString()).toList());
				result.put("created", created);
				result.put("skipped", skipped);
				return gson.toJson(result);
			}

			for (Map<String, Object> mod : modules) {
				String internalCode = str(mod.get("internal_code"));
				String fileName = sanitizeFileName(str(mod.get("file_name")));
				String displayName = str(mod.get("display_name"));
				String gridHeight = str(mod.get("grid_height"));
				if (gridHeight.isEmpty() || "null".equalsIgnoreCase(gridHeight)) {
					gridHeight = DEFAULT_GRID_HEIGHT;
				}

				Map<String, Object> row = new LinkedHashMap<>();
				row.put("internal_code", internalCode);
				row.put("display_name", displayName);
				row.put("file_name", fileName);

				if (fileName.isEmpty()) {
					row.put("reason", "empty file_name");
					skipped.add(row);
					continue;
				}

				List<Map<String, Object>> elements = loadPopupElements(sanitizeSchemaCode(internalCode));
				if (elements == null || elements.isEmpty()) {
					row.put("reason", "no include_in_popup elements");
					skipped.add(row);
					continue;
				}

				String js = buildPopupJs(fileName, displayName, gridHeight, elements);
				String outName = "pop_up_" + fileName + ".js";
				List<String> written = new ArrayList<>();
				for (Path outDir : outDirs) {
					Path outFile = outDir.resolve(outName);
					Files.writeString(outFile, js, StandardCharsets.UTF_8);
					written.add(outFile.toAbsolutePath().toString());
					logger.info("Created popup file: {}", outFile.toAbsolutePath());
				}

				row.put("paths", written);
				row.put("out_name", outName);
				row.put("columns", elements.size());
				created.add(row);
			}

			result.put("error_code", 0);
			result.put("status", "success");
			result.put("message", "Popup files generated");
			result.put("out_dirs", outDirs.stream().map(p -> p.toAbsolutePath().toString()).toList());
			result.put("created", created);
			result.put("skipped", skipped);
			result.put("created_count", created.size());
			result.put("skipped_count", skipped.size());
		} catch (Exception ex) {
			logger.error("createPopupFiles failed: {}", ex.getMessage(), ex);
			result.put("error_code", -1);
			result.put("status", "failure");
			result.put("message", "createPopupFiles failed: " + ex.getMessage());
			result.put("created", created);
			result.put("skipped", skipped);
		}
		return gson.toJson(result);
	}

	/** Same module set as CreateGridFiles. */
	private List<Map<String, Object>> loadModulesForPopup() {
		String sql = "select mo.internal_code,"
				+ " isnull(mo.display_name,'') as display_name,"
				+ " isnull(mo.file_name,'') as file_name,"
				+ " isnull(convert(varchar(20), mo.grid_height),'') as grid_height"
				+ " from dbo.ia_menu_options mo"
				+ " where mo.generate_grid = 'Yes'"
				+ " and mo.active = 'Yes'"
				+ " order by mo.display_name, mo.file_name";
		return NativeQuerySupport.executeQuery(session(), sql);
	}

	/**
	 * Same element query as CreateGridFiles, but include_in_popup=1
	 * (DisplayGrid popup path; grid uses include_in_grid).
	 */
	private List<Map<String, Object>> loadPopupElements(String schemaCode) {
		String sql = "select isnull(su.name,'') as name,"
				+ " isnull(su.system_name,'') as system_name,"
				+ " isnull(su.width, 85) as width"
				+ " from dbo.ia_s_user_schema_elements su"
				+ " where su.ref_s_user_schema_code = " + schemaCode
				+ " and isnull(su.is_multiple_group, 0) = 0"
				+ " and isnull(su.include_in_popup, 0) = 1"
				+ " order by isnull(su.sequence, 9999), su.internal_code";
		return NativeQuerySupport.executeQuery(session(), sql);
	}

	private List<Path> resolvePopupOutDirs() throws IOException {
		if (projectBasePath == null || projectBasePath.isBlank()) {
			throw new IOException(
					"Missing inpc.project.base-path. Set it in portal.properties (or application.yml) "
							+ "to the local project root.");
		}
		List<Path> dirs = new ArrayList<>();
		Path baseOut = Paths.get(projectBasePath).toAbsolutePath().normalize().resolve(GRID_RELATIVE).normalize();
		dirs.add(baseOut);
		logger.info("Popup out dir (base): {}", baseOut);

		if (projectDeployPath != null && !projectDeployPath.isBlank()) {
			Path deployRoot = Paths.get(projectDeployPath).toAbsolutePath().normalize();
			Path warRoot = deployRoot.resolve("grid_display_files/INPC").normalize();
			Path warClasses = deployRoot.resolve("WEB-INF/classes/static/grid_display_files/INPC").normalize();
			for (Path d : new Path[] { warRoot, warClasses }) {
				if (!dirs.contains(d)) {
					dirs.add(d);
					logger.info("Popup out dir (deploy): {}", d);
				}
			}
		}
		return dirs;
	}

	/**
	 * Builds popup grid JS matching pop_up_ia_menu_options.js /
	 * pop_up_ia_division.js (shared #table_grid1 / #sub_grid_div1).
	 */
	private String buildPopupJs(String tableName, String displayName, String gridHeight,
			List<Map<String, Object>> elements) {
		StringBuilder colNames = new StringBuilder();
		StringBuilder colModel = new StringBuilder();
		for (int i = 0; i < elements.size(); i++) {
			Map<String, Object> el = elements.get(i);
			String label = str(el.get("name"));
			String sys = sanitizeJsIdent(str(el.get("system_name")));
			if (sys.isEmpty()) {
				continue;
			}
			if (label.isEmpty()) {
				label = sys;
			}
			double width = 85.0;
			try {
				Object w = el.get("width");
				if (w != null) {
					width = Double.parseDouble(String.valueOf(w));
				}
			} catch (Exception ignore) {
				width = 85.0;
			}
			if (!Double.isFinite(width) || width <= 1.0) {
				width = 85.0;
			}
			if (colNames.length() > 0) {
				colNames.append(",\r\n\t ");
				colModel.append(",\r\n\t ");
			}
			colNames.append("'").append(escapeJs(label)).append("'");
			colModel.append("{name:'").append(escapeJs(sys)).append("',index:'")
					.append(escapeJs(sys)).append("', align:'left',  width:'")
					.append(String.format(java.util.Locale.US, "%.0f", width)).append("'}");
		}

		String height = escapeJs(gridHeight);
		String tn = escapeJs(tableName);
		String title = escapeJs(displayName.isEmpty() ? tableName : displayName);
		String pgVar = "pg_" + tn;

		StringBuilder sb = new StringBuilder();
		sb.append("/* This file is created by Framework System */\r\n");
		sb.append("var ").append(pgVar).append(" =  jQuery('#table_grid1').jqGrid \r\n");
		sb.append("({\r\n");
		sb.append("\turl:$host_url+\"display_grid/viewUserSchemaSrefDataDetails?pop_up_table_name=\"+pop_up_table_name+\"&calling_table_name=\"+calling_table_name+\"&clicked_id_system_name=\"+clicked_id_system_name,\r\n");
		sb.append("\tdatatype: 'json', \r\n");
		sb.append("\tcolNames:[\r\n\t ").append(colNames).append("],\t\r\n");
		sb.append("\tcolModel:[\r\n\t ").append(colModel).append("],\t\r\n");
		sb.append("\t\trowNum:50, \r\n");
		sb.append("\trowList:[50,100,200,500], \r\n");
		sb.append("\tpager: jQuery('#sub_grid_div1'), \r\n");
		sb.append("\tsortname: 'id', \r\n");
		sb.append("\theight:'").append(height).append("',\r\n");
		sb.append("\t\twidth:'600',\r\n");
		sb.append("\tviewrecords: true, \r\n");
		sb.append("\tsortorder: 'desc', \r\n");
		sb.append("\tmultiselect: false, \r\n");
		sb.append(" \r\n");
		sb.append("\tcellsubmit: 'clientArray', \r\n");
		sb.append("\tcellEdit: true,\r\n");
		sb.append("\t forceFit : true, \r\n");
		sb.append("\t\t\t \r\n");
		sb.append("\t\t\r\n");
		sb.append("\tloadComplete:function() \r\n");
		sb.append("\t{\r\n");
		sb.append("\t\t$('.ui-jqgrid-htable').css('border-collapse','separate');\r\n");
		sb.append("\t},\r\n");
		sb.append("\tondblClickRow: function(rowid)\r\n");
		sb.append("\t{\r\n");
		sb.append("\t},\r\n");
		sb.append("})\r\n");
		sb.append(".navGrid('#sub_grid_div1',{edit:false,add:false,del:false,search:false},{},{},{},{multipleSearch:false})\r\n");
		sb.append(".navButtonAdd('#sub_grid_div1',{caption:'Search', buttonicon :'ui-icon-search', onClickButton:function(){")
				.append(pgVar).append("[0].toggleToolbar() } }) ; \r\n");
		sb.append("\r\n");
		sb.append(pgVar).append(".filterToolbar(); \r\n");
		sb.append("// ").append(pgVar).append("[0].toggleToolbar();\r\n");
		sb.append("$('.ui-search-toolbar').bind('keydown',function(evt)\r\n");
		sb.append("{\r\n");
		sb.append("\tvar kC  = (evt.which) ? evt.which : evt.keyCode;\r\n");
		sb.append("\tif(kC==40)\r\n");
		sb.append("\t\tjQuery('#table_grid1').editCell(1,1,false);\r\n");
		sb.append("\tif(kC==39) \r\n");
		sb.append("\t\t$('#'+evt.target.id).focusNextInputField(); \r\n");
		sb.append("\tif(kC==37) \r\n");
		sb.append("\t\t$('#'+evt.target.id).focusPreviousInputField(); \r\n");
		sb.append("});\r\n");
		sb.append("$('#ref_display_popup_title').html('").append(title).append("');\r\n");
		return sb.toString();
	}

	private static String sanitizeSchemaCode(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty() || !s.matches("\\d+")) {
			return "0";
		}
		return s;
	}

	private static String sanitizeFileName(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty()) {
			return "";
		}
		s = s.replace('\\', '/');
		int slash = s.lastIndexOf('/');
		if (slash >= 0) {
			s = s.substring(slash + 1);
		}
		if (s.toLowerCase().startsWith("pop_up_")) {
			s = s.substring("pop_up_".length());
		}
		if (s.toLowerCase().endsWith(".html")) {
			s = s.substring(0, s.length() - 5);
		}
		if (s.toLowerCase().endsWith(".js")) {
			s = s.substring(0, s.length() - 3);
		}
		s = s.replaceAll("[^A-Za-z0-9_\\-]", "");
		return s;
	}

	private static String sanitizeJsIdent(String raw) {
		return str(raw).trim().replaceAll("[^A-Za-z0-9_]", "");
	}

	private static String escapeJs(String s) {
		if (s == null) {
			return "";
		}
		return s.replace("\\", "\\\\").replace("'", "\\'").replace("\r", "").replace("\n", " ");
	}

	private static String str(Object o) {
		if (o == null) {
			return "";
		}
		String s = String.valueOf(o);
		return "null".equalsIgnoreCase(s) ? "" : s;
	}
}