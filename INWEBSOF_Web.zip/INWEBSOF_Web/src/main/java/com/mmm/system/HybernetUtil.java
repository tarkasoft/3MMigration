package com.mmm.system;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.config.SystemHibernateConfig;

import jakarta.annotation.PostConstruct;

/**
 * Base / system Hibernate facade for legacy-style callers.
 * Preferred for new code: inject SessionFactory + @Transactional + getCurrentSession().
 */
@Component
public class HybernetUtil {

    private static SessionFactory systemFactory;
    private static HibernateFactoryRegistry registry;

    private final SessionFactory injectedSystem;
    private final HibernateFactoryRegistry injectedRegistry;

    public HybernetUtil(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory injectedSystem,
                        HibernateFactoryRegistry injectedRegistry) {
        this.injectedSystem = injectedSystem;
        this.injectedRegistry = injectedRegistry;
    }

    @PostConstruct
    void init() {
        systemFactory = injectedSystem;
        registry = injectedRegistry;
    }

    /** Shared singleton — never close this from request code. */
    public static SessionFactory GetHyberNetSessionFactory() {
        if (systemFactory == null) {
            throw new IllegalStateException("HybernetUtil not initialized by Spring yet");
        }
        return systemFactory;
    }

    public static SessionFactory getAS400Factory() {
        if (registry == null) {
            throw new IllegalStateException("HybernetUtil not initialized by Spring yet");
        }
        return registry.getAs400SessionFactory();
    }
}