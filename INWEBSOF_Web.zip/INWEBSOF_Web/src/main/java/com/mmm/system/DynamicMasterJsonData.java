package com.mmm.system;

import org.json.simple.JSONObject;

public class DynamicMasterJsonData {
	 
  
    public String internal_code;
    public String system_module_table_name;
    public String FW_login_Id;

    public JSONObject save_schema_details_arr=new JSONObject();
    public JSONObject header_data_type_arr=new JSONObject();
    public JSONObject group_details_arr=new JSONObject();
}
