package com.mmm.system;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jakarta.persistence.PersistenceException;
import jakarta.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.FWValidation;

/**
 * Framework autocomplete / ref-module LOV endpoints (ServiceBilling AutoComplete port).
 * SYSTEM_TX + getCurrentSession; SELECT via NativeQuerySupport.executeQuery.
 * Legacy JSON shape: error_code / data (compatible with MainPageNew / popup_new).
 */
@RestController
@RequestMapping("titpl/auto_complete")
public class AutoComplete {

	private final SessionFactory sessionFactory;
	static Logger logger = LogManager.getLogger(AutoComplete.class);
	private final Gson gson = new Gson();

	String calling_table_name = "";
	String pop_up_table_name = "";
	String system_name = "";
	String value = "";

	public AutoComplete(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	private String legacySuccess(Object data) {
		Map<String, Object> result = new LinkedHashMap<>();
		result.put("error_code", 0);
		result.put("status", "success");
		result.put("data", data);
		return gson.toJson(result);
	}

	@RequestMapping(value = "AssignRefModuleLovValues", method = RequestMethod.POST)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String AssignRefModuleLovValues(HttpServletRequest request,
			@RequestParam("schema_id") String schema_id,
			@RequestParam("system_module_table_name") String system_module_table_name)
			throws SQLException, ClassNotFoundException {

		List<Map<String, Object>> query_data_obj = new ArrayList<>();
		Session session = session();
		JSONObject final_data_obj = new JSONObject();
		try {
			String e_qry = " select su.internal_code,su.ref_module_code, su.system_name, ";
			e_qry += " isnull(su.populate_lov,1) as populate_lov  ";
			e_qry += " from ia_s_user_schema_elements su";
			e_qry += " inner join ia_menu_options s on s.internal_code=su.ref_module_code";
			e_qry += " where su.is_ref_module_code_lov=1 ";
			e_qry += " and su.ref_s_user_schema_code=" + schema_id;
			e_qry += "  and su.ref_module_code<>0 and su.is_multiple_group=0 ";

			logger.info("*******AssignRefModuleLovValues Qry==>" + e_qry);
			query_data_obj = NativeQuerySupport.executeQuery(session, e_qry);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				for (Map<String, Object> map : query_data_obj) {
					String ref_module_code = map.get("ref_module_code") == null ? ""
							: map.get("ref_module_code").toString().trim();
					String system_name_col = map.get("system_name") == null ? ""
							: map.get("system_name").toString().trim();
					JSONObject meta_colmn_obj = GetValuesFromMetaColumns(session, ref_module_code);
					if (!meta_colmn_obj.get("field_id").toString().equals("")) {
						List<Map<String, Object>> query_data_obj1 = GetRefModuleLoveValues(session,
								meta_colmn_obj.get("field_id").toString(),
								meta_colmn_obj.get("table_name").toString());
						final_data_obj.put(system_name_col, query_data_obj1);
					}
				}
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("AssignRefModuleLovValues PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("AssignRefModuleLovValues RuntimeException: " + ex.getMessage(), ex);
		}

		return legacySuccess(final_data_obj);
	}

	private JSONObject GetValuesFromMetaColumns(Session session, String ref_module_code) {
		JSONObject return_obj = new JSONObject();
		return_obj.put("table_name", "");
		return_obj.put("field_id", "");
		String query = "select  field_id,table_name from ia_module_meta_columns	where module_id="
				+ ref_module_code;

		logger.info("GetValuesFromMetaColumns Sql =" + query);
		try {
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, query);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				for (Map map2 : query_data_obj) {
					Object fid = map2.get("field_id");
					Object tname = map2.get("table_name");
					return_obj.put("field_id", fid == null ? "" : fid.toString());
					return_obj.put("table_name", tname == null ? "" : tname.toString());
				}
			}
		} catch (PersistenceException e) {
			logger.info("Error in GetValuesFromMetaColumns Sql=" + query);
		} catch (RuntimeException e) {
			logger.info("Error in GetValuesFromMetaColumns Sql=" + query + " : " + e.getMessage());
		}

		return return_obj;
	}

	private List<Map<String, Object>> GetRefModuleLoveValues(Session session, String field_id, String table_name) {
		List<Map<String, Object>> query_data_obj = new ArrayList<>();
		String query = "select  internal_code," + field_id + " as value from " + table_name;

		logger.info("GetRefModuleLoveValues Sql =" + query);
		try {
			query_data_obj = NativeQuerySupport.executeQuery(session, query);
			if (query_data_obj == null) {
				query_data_obj = new ArrayList<>();
			}
		} catch (PersistenceException e) {
			logger.info("Error in GetRefModuleLoveValues Sql=" + query);
		} catch (RuntimeException e) {
			logger.info("Error in GetRefModuleLoveValues Sql=" + query + " : " + e.getMessage());
		}

		return query_data_obj;
	}

	@RequestMapping(value = "GetModuleKeyDataForElement", method = RequestMethod.POST)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String GetModuleKeyDataForElement(HttpServletRequest request,
			@RequestParam("calling_table_name") String t_calling_table_name,
			@RequestParam("internal_code") String internal_code,
			@RequestParam("pop_up_table_name") String t_pop_up_table_name,
			@RequestParam("system_name") String t_system_name) throws SQLException, ClassNotFoundException {

		calling_table_name = t_calling_table_name;
		pop_up_table_name = t_pop_up_table_name;
		system_name = t_system_name;

		List<Map<String, Object>> query_data_obj = null;
		Session session = session();
		try {
			JSONObject meta_col_obj = GetModuleMetaColumnsData(session, t_pop_up_table_name);
			String field_id = meta_col_obj.get("field_id") == null ? "" : meta_col_obj.get("field_id").toString();

			String e_qry = "select  internal_code," + field_id + " as name ";
			e_qry += "	from  " + t_pop_up_table_name + "  where internal_code=" + internal_code;
			logger.info("*******GetModuleKeyDataForElement Final s Qry==>" + e_qry);
			List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session, e_qry);
			if (rows != null && rows.size() > 0) {
				query_data_obj = rows;
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("GetModuleKeyDataForElement PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("GetModuleKeyDataForElement RuntimeException: " + ex.getMessage(), ex);
		}

		return legacySuccess(query_data_obj);
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "getAutoCompleteFromFrameWorkNew", method = RequestMethod.GET)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String getAutoCompleteFromFrameWorkNew(HttpServletRequest request,
			@RequestParam("calling_table_name") String t_calling_table_name,
			@RequestParam("pop_up_table_name") String t_pop_up_table_name,
			@RequestParam("system_name") String t_system_name,
			@RequestParam("value") String t_value) throws SQLException, ClassNotFoundException, IOException {

		calling_table_name = t_calling_table_name;
		pop_up_table_name = t_pop_up_table_name;
		value = t_value == null ? "" : t_value.trim();
		system_name = t_system_name;
		List<Map<String, Object>> query_data_obj = null;

		Session session = session();
		try {
			query_data_obj = GetAutoCompleteQrySet(request, session);
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
			}
			logger.error("getAutoCompleteFromFrameWorkNew PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("getAutoCompleteFromFrameWorkNew RuntimeException: " + ex.getMessage(), ex);
		}
		return legacySuccess(query_data_obj);
	}

	@SuppressWarnings("unchecked")
	List<Map<String, Object>> GetAutoCompleteQrySet(HttpServletRequest request, Session session) {
		List<Map<String, Object>> query_data_obj = null;
		JSONObject meta_col_obj = GetModuleMetaColumnsData(session, pop_up_table_name);
		String field_id1 = meta_col_obj.get("field_id1") == null ? "" : meta_col_obj.get("field_id1").toString();
		String field_id2 = meta_col_obj.get("field_id2") == null ? "" : meta_col_obj.get("field_id2").toString();

		String new_filter_cond = FWValidation.GetAutoCompleteExtraCond(request, session, "AutoComplete",
				calling_table_name, system_name);

		String field_id1_val = field_id1;
		if (!(field_id2).isEmpty())
			field_id1_val = "   isnull(" + field_id1 + ",'') +' - '+ isnull(" + field_id2 + ",'')";

		String field_id2_val = field_id2;
		if (!(field_id1).isEmpty())
			field_id2_val = "   isnull(" + field_id2 + ",'') +' - '+ isnull(" + field_id1 + ",'')";
		String qry1 = " select top 50 internal_code," + field_id1_val + " as value from ";
		qry1 += pop_up_table_name + " where " + field_id1 + " like '%" + value + "%' ";
		qry1 += " " + new_filter_cond + " ";
		qry1 += " order by " + field_id1;

		String qry2 = " select top 50 internal_code," + field_id2_val + " as value from ";
		qry2 += pop_up_table_name + " where " + field_id2 + " like '%" + value + "%' ";
		qry2 += " " + new_filter_cond + " ";
		qry2 += " order by " + field_id2;
		JSONObject query_data_obj1 = GetResultSet(session, qry1);
		int list_size = Integer.parseInt(query_data_obj1.get("list_size").toString());
		if (list_size == 0) {
			query_data_obj1 = GetResultSet(session, qry2);
		}

		list_size = Integer.parseInt(query_data_obj1.get("list_size").toString());
		if (list_size > 0)
			return (List<Map<String, Object>>) query_data_obj1.get("query_data_obj");
		else
			return query_data_obj;

	}

	JSONObject GetResultSet(Session session, String Sql) {
		JSONObject data_set = new JSONObject();

		List<Map<String, Object>> query_data_obj = null;
		data_set.put("list_size", 0);
		data_set.put("query_data_obj", "");
		try {
			logger.info("Sql----" + Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				data_set.put("list_size", query_data_obj.size());
				data_set.put("query_data_obj", query_data_obj);
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
				ex.printStackTrace();
			}
			logger.error("GetResultSet PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("GetResultSet RuntimeException: " + ex.getMessage(), ex);
		}

		return data_set;
	}

	public JSONObject GetModuleMetaColumnsData(Session session, String t_pop_up_table_name) {
		JSONObject meta_col_obj = new JSONObject();
		meta_col_obj.put("field_id1", "");
		meta_col_obj.put("field_id2", "");
		meta_col_obj.put("field_id", "");
		try {
			String Sql = " select field_id,field_id1,field_id2 from ia_module_meta_columns where table_name='"
					+ t_pop_up_table_name + "'";
			logger.info(Sql);
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, Sql);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				for (Map<String, Object> map : query_data_obj) {
					String field_id1 = map.get("field_id1") == null ? "" : map.get("field_id1").toString();
					String field_id2 = map.get("field_id2") == null ? "" : map.get("field_id2").toString();
					String field_id = map.get("field_id") == null ? "" : map.get("field_id").toString();
					meta_col_obj.put("field_id1", field_id1);
					meta_col_obj.put("field_id2", field_id2);
					meta_col_obj.put("field_id", field_id);
				}
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
				ex.printStackTrace();
			}
			logger.error("GetModuleMetaColumnsData PersistenceException: " + ex.getMessage(), ex);
		} catch (RuntimeException ex) {
			logger.error("GetModuleMetaColumnsData RuntimeException: " + ex.getMessage(), ex);
		}
		return meta_col_obj;
	}
}
