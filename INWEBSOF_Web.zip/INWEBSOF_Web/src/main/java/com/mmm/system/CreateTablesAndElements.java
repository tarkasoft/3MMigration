package com.mmm.system;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;

import com.mmm.titpl.NativeQuerySupport;

/**
 * Creates or updates the business table for a framework module.
 * Called only for ia_menu_options and ia_s_user_schema_elements.
 * Group rows (is_multiple_group = 1) and group tables are ignored.
 */
public final class CreateTablesAndElements {

	private static final Logger logger = LogManager.getLogger(CreateTablesAndElements.class);
	private static final Pattern IDENT = Pattern.compile("[A-Za-z][A-Za-z0-9_]*");
	private static final Set<String> RESERVED = Set.of(
			"internal_code", "created_by", "created_date", "modified_by", "modified_date");
	/** Never drop the framework catalog tables, even if a menu row uses that file_name. */
	private static final Set<String> PROTECTED_TABLES = Set.of(
			"ia_menu_options", "ia_menu_groups", "ia_menu_sub_groups",
			"ia_s_user_schema_elements", "ia_s_user_schema_group",
			"ia_module_meta_columns", "ia_user_master", "ia_user_type",
			"ia_roles", "ia_role_rights");

	private CreateTablesAndElements() {
	}

	/** Values read before insert/update. Empty on a new row. */
	public static final class Snapshot {
		public String fileName = "";
		public String systemName = "";
		public String dataType = "";
	}

	private static boolean isFrameWork(Object loadType) {
		return "framework".equalsIgnoreCase(text(loadType));
	}

	public static boolean isSchemaTable(String savedTable) {
		if (savedTable == null) {
			return false;
		}
		String t = savedTable.trim();
		return "ia_menu_options".equalsIgnoreCase(t) || "ia_s_user_schema_elements".equalsIgnoreCase(t);
	}

	/**
	 * Read the current row before it is overwritten.
	 * Menu option: file_name. Element: system_name and data_type.
	 */
	public static Snapshot PreSaveData(Session session, String savedTable, String internalCode) {
		Snapshot snap = new Snapshot();
		if (!isSchemaTable(savedTable)) {
			return snap;
		}
		int id = parseId(internalCode);
		if (id <= 0) {
			return snap;
		}
		if ("ia_menu_options".equalsIgnoreCase(savedTable.trim())) {
			List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session,
					"select isnull(file_name,'') as file_name from dbo.ia_menu_options where internal_code = :id",
					Map.of("id", id), NativeQuerySupport.stringScalars("file_name"));
			if (!rows.isEmpty()) {
				snap.fileName = text(rows.get(0).get("file_name"));
			}
			return snap;
		}
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session,
				"select isnull(system_name,'') as system_name, isnull(data_type,'') as data_type"
						+ " from dbo.ia_s_user_schema_elements where internal_code = :id",
				Map.of("id", id), NativeQuerySupport.stringScalars("system_name", "data_type"));
		if (!rows.isEmpty()) {
			snap.systemName = text(rows.get(0).get("system_name"));
			snap.dataType = text(rows.get(0).get("data_type"));
		}
		return snap;
	}

	/**
	 * Before the grid delete runs. Element delete drops that column.
	 * Menu-option delete drops that module table. FrameWork load type only.
	 */
	public static void dropOnDelete(Session session, String tableName, String idCsv) {
		String ids = idList(idCsv);
		if (ids.isEmpty() || tableName == null) {
			return;
		}
		String table = tableName.trim();
		if ("ia_menu_options".equalsIgnoreCase(table)) {
			dropModuleTables(session, ids);
		} else if ("ia_s_user_schema_elements".equalsIgnoreCase(table)) {
			dropElementColumns(session, ids);
		}
	}

	private static void dropModuleTables(Session session, String ids) {
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session,
				"select isnull(file_name,'') as file_name, isnull(load_type,'') as load_type"
						+ " from dbo.ia_menu_options where internal_code in (" + ids + ")",
				Map.of(), NativeQuerySupport.stringScalars("file_name", "load_type"));
		for (Map<String, Object> row : rows) {
			if (!isFrameWork(row.get("load_type"))) {
				continue;
			}
			String fileName = text(row.get("file_name"));
			if (!isIdent(fileName) || PROTECTED_TABLES.contains(fileName.toLowerCase())) {
				logger.info("Skip drop table: {}", fileName);
				continue;
			}
			if (!tableExists(session, fileName)) {
				continue;
			}
			exec(session, "DROP TABLE dbo." + q(fileName));
			logger.info("Dropped table dbo.{}", fileName);
		}
	}

	private static void dropElementColumns(Session session, String ids) {
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session,
				"select isnull(s.system_name,'') as system_name,"
						+ " isnull(convert(varchar(20), s.ref_s_user_schema_code),'0') as ref_s_user_schema_code,"
						+ " isnull(convert(varchar(10), s.is_multiple_group),'0') as is_multiple_group,"
						+ " isnull(mo.file_name,'') as file_name, isnull(mo.load_type,'') as load_type"
						+ " from dbo.ia_s_user_schema_elements s"
						+ " left join dbo.ia_menu_options mo on mo.internal_code = s.ref_s_user_schema_code"
						+ " where s.internal_code in (" + ids + ")",
				Map.of(),
				NativeQuerySupport.stringScalars("system_name", "ref_s_user_schema_code", "is_multiple_group", "file_name", "load_type"));
		for (Map<String, Object> row : rows) {
			if (!isFrameWork(row.get("load_type"))) {
				continue;
			}
			if ("1".equals(text(row.get("is_multiple_group")))) {
				continue;
			}
			String fileName = text(row.get("file_name"));
			String systemName = text(row.get("system_name"));
			String moduleId = text(row.get("ref_s_user_schema_code"));
			if (!isIdent(fileName) || PROTECTED_TABLES.contains(fileName.toLowerCase())) {
				continue;
			}
			if (!isIdent(systemName) || RESERVED.contains(systemName.toLowerCase())) {
				continue;
			}
			if (!columnExists(session, fileName, systemName)) {
				continue;
			}
			if (otherElementUsesColumn(session, moduleId, systemName, ids)) {
				logger.info("Skip drop column {}.{}; another element still uses it", fileName, systemName);
				continue;
			}
			exec(session, "ALTER TABLE dbo." + q(fileName) + " DROP COLUMN " + q(systemName));
			logger.info("Dropped column {}.{}", fileName, systemName);
		}
	}

	private static boolean otherElementUsesColumn(Session session, String moduleId, String systemName, String ids) {
		int module = parseId(moduleId);
		if (module <= 0) {
			return false;
		}
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session,
				"select convert(varchar(20), count(1)) as flag from dbo.ia_s_user_schema_elements"
						+ " where ref_s_user_schema_code = " + module
						+ " and lower(system_name) = lower('" + systemName + "')"
						+ " and internal_code not in (" + ids + ")"
						+ " and isnull(is_multiple_group,0) = 0",
				Map.of(), NativeQuerySupport.stringScalars("flag"));
		if (rows.isEmpty()) {
			return false;
		}
		return parseId(text(rows.get(0).get("flag"))) > 0;
	}

	private static String idList(String idCsv) {
		if (idCsv == null || idCsv.isBlank()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (String part : idCsv.split(",")) {
			int id = parseId(part);
			if (id <= 0) {
				continue;
			}
			if (sb.length() > 0) {
				sb.append(',');
			}
			sb.append(id);
		}
		return sb.toString();
	}

	/** Compare the saved row with the pre-save snapshot and create, rename, or retype. */
	public static void apply(Session session, String savedTable, String rowId, Snapshot before) {
		if (!isSchemaTable(savedTable)) {
			return;
		}
		int id = parseId(rowId);
		if (id <= 0) {
			return;
		}
		Snapshot prior = before == null ? new Snapshot() : before;
		if ("ia_menu_options".equalsIgnoreCase(savedTable.trim())) {
			applyModuleTable(session, id, prior.fileName);
		} else {
			applyElementColumn(session, id, prior.systemName, prior.dataType);
		}
	}

	private static void applyModuleTable(Session session, int id, String oldFileName) {
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session,
				"select isnull(file_name,'') as file_name, isnull(load_type,'') as load_type"
						+ " from dbo.ia_menu_options where internal_code = :id",
				Map.of("id", id), NativeQuerySupport.stringScalars("file_name", "load_type"));
		if (rows.isEmpty()) {
			return;
		}
		if (!isFrameWork(rows.get(0).get("load_type"))) {
			return;
		}
		String fileName = text(rows.get(0).get("file_name"));
		if (!isIdent(fileName)) {
			logger.info("Skip table create, file_name is not a plain name: {}", fileName);
			return;
		}
		String previous = text(oldFileName);
		if (!isIdent(previous) || previous.equalsIgnoreCase(fileName)) {
			createTable(session, fileName);
			return;
		}
		if (!tableExists(session, previous)) {
			createTable(session, fileName);
			return;
		}
		if (tableExists(session, fileName)) {
			throw new IllegalStateException("Table dbo." + fileName + " already exists. file_name was not renamed.");
		}
		exec(session, "EXEC sp_rename 'dbo." + previous + "', '" + fileName + "'");
		logger.info("Renamed table dbo.{} to dbo.{}", previous, fileName);
	}

	private static void applyElementColumn(Session session, int id, String oldSystemName, String oldDataType) {
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session,
				"select isnull(s.system_name,'') as system_name, isnull(s.data_type,'Text') as data_type,"
						+ " isnull(convert(varchar(10), s.is_multiple_group),'0') as is_multiple_group,"
						+ " isnull(mo.file_name,'') as file_name, isnull(mo.load_type,'') as load_type"
						+ " from dbo.ia_s_user_schema_elements s"
						+ " left join dbo.ia_menu_options mo on mo.internal_code = s.ref_s_user_schema_code"
						+ " where s.internal_code = :id",
				Map.of("id", id),
				NativeQuerySupport.stringScalars("system_name", "data_type", "is_multiple_group", "file_name", "load_type"));
		if (rows.isEmpty()) {
			return;
		}
		Map<String, Object> row = rows.get(0);
		if (!isFrameWork(row.get("load_type"))) {
			return;
		}
		if ("1".equals(text(row.get("is_multiple_group")))) {
			return;
		}
		String fileName = text(row.get("file_name"));
		String systemName = text(row.get("system_name"));
		String dataType = text(row.get("data_type"));
		if (!isIdent(fileName)) {
			logger.info("Skip column, module file_name is not a plain name: {}", fileName);
			return;
		}
		if (!isIdent(systemName) || RESERVED.contains(systemName.toLowerCase())) {
			logger.info("Skip column, system_name cannot be a table column: {}", systemName);
			return;
		}
		createTable(session, fileName);
		String previous = text(oldSystemName);
		String column = systemName;
		boolean previousOk = isIdent(previous) && !RESERVED.contains(previous.toLowerCase());
		if (previousOk && !previous.equalsIgnoreCase(systemName)) {
			if (columnExists(session, fileName, previous)) {
				if (columnExists(session, fileName, systemName)) {
					throw new IllegalStateException(
							"Column " + systemName + " already exists on dbo." + fileName + ".");
				}
				exec(session, "EXEC sp_rename 'dbo." + fileName + "." + previous + "', '" + systemName + "', 'COLUMN'");
				logger.info("Renamed {}.{} to {}", fileName, previous, systemName);
			}
		}
		String sqlType = sqlType(dataType);
		if (!columnExists(session, fileName, column)) {
			exec(session, "ALTER TABLE dbo." + q(fileName) + " ADD " + q(column) + " " + sqlType + " NULL");
			logger.info("Added {}.{} {}", fileName, column, sqlType);
			return;
		}
		String priorType = text(oldDataType);
		if (!priorType.isEmpty() && !sqlType(priorType).equalsIgnoreCase(sqlType)) {
			exec(session, "ALTER TABLE dbo." + q(fileName) + " ALTER COLUMN " + q(column) + " " + sqlType + " NULL");
			logger.info("Altered {}.{} to {}", fileName, column, sqlType);
		}
	}

	private static void createTable(Session session, String fileName) {
		if (tableExists(session, fileName)) {
			return;
		}
		String sql = "CREATE TABLE dbo." + q(fileName) + " ("
				+ " internal_code int IDENTITY(1,1) NOT NULL,"
				+ " created_by int NULL,"
				+ " created_date datetime NULL,"
				+ " modified_by int NULL,"
				+ " modified_date datetime NULL,"
				+ " CONSTRAINT " + q("PK_" + fileName) + " PRIMARY KEY CLUSTERED (internal_code ASC)"
				+ ")";
		exec(session, sql);
		logger.info("Created table dbo.{}", fileName);
	}

	private static boolean tableExists(Session session, String name) {
		return flag(session, "select case when object_id(N'dbo." + name + "', N'U') is null then '0' else '1' end as flag");
	}

	private static boolean columnExists(Session session, String table, String column) {
		return flag(session, "select case when col_length(N'dbo." + table + "', N'" + column + "') is null then '0' else '1' end as flag");
	}

	private static boolean flag(Session session, String sql) {
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session, sql, Map.of(),
				NativeQuerySupport.stringScalars("flag"));
		return !rows.isEmpty() && "1".equals(text(rows.get(0).get("flag")));
	}

	private static String sqlType(String dataType) {
		String dt = dataType == null ? "" : dataType.trim();
		if ("Number".equalsIgnoreCase(dt)) {
			return "decimal(18,4)";
		}
		if ("Checkbox".equalsIgnoreCase(dt)) {
			return "int";
		}
		if ("Date".equalsIgnoreCase(dt)) {
			return "date";
		}
		if ("DateTime".equalsIgnoreCase(dt)) {
			return "datetime";
		}
		if ("Reference Data".equalsIgnoreCase(dt)) {
			return "int";
		}
		if ("List Of Values".equalsIgnoreCase(dt)) {
			return "varchar(100)";
		}
		if ("Large Text".equalsIgnoreCase(dt) || "TextArea".equalsIgnoreCase(dt) || "Text Area".equalsIgnoreCase(dt)) {
			return "varchar(max)";
		}
		return "varchar(200)";
	}

	private static boolean isIdent(String name) {
		return name != null && IDENT.matcher(name).matches();
	}

	private static String q(String ident) {
		return "[" + ident + "]";
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static int parseId(String raw) {
		if (raw == null) {
			return 0;
		}
		String t = raw.trim();
		if (t.isEmpty() || "null".equalsIgnoreCase(t)) {
			return 0;
		}
		int dot = t.indexOf('.');
		if (dot >= 0) {
			t = t.substring(0, dot);
		}
		try {
			return Integer.parseInt(t);
		} catch (NumberFormatException ex) {
			return 0;
		}
	}

	private static void exec(Session session, String sql) {
		logger.info("CreateTablesAndElements: {}", sql);
		session.createNativeMutationQuery(sql).executeUpdate();
	}
}
