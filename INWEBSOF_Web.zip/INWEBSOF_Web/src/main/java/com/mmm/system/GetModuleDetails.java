package com.mmm.system;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jakarta.persistence.PersistenceException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.json.simple.JSONObject;

import com.mmm.titpl.NativeQuerySupport;

/** Schema load (ServiceBilling). Uses Spring TX getCurrentSession — do not close. */
public class GetModuleDetails {
	private final SessionFactory sessionFactory;
	static Logger logger = LogManager.getLogger(GetModuleDetails.class);
	JSONObject jsn_obj = new JSONObject();

	public GetModuleDetails(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	public JSONObject getGeneralUserSchemaDetails(String module_id) {
		jsn_obj = new JSONObject();
		Session session = session();
		try {
			logger.info("*****getGeneralUserSchemaDetails");
			GetSUSerSchemaElementDetailsData(session, module_id);
			GetSUSerSchemaHeaderDetails(session, module_id);
			GetSUSerSchemaGroupDetails(session, module_id);
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
		return jsn_obj;
	}

	public void GetSUSerSchemaElementDetailsData(Session session, String module_id) {
		try {
			String final_qry = "select  name,system_name,data_type as Type,isnull(list_of_values,'') as list_of_values,";
			final_qry += " isnull(ref_s_user_schema_group_code,'0') as ref_s_user_schema_group_code, ";
			final_qry += " isnull(default_value,'0') as default_value, ";
			final_qry += " isnull(optional,'0') as optional, ";
			final_qry += " isnull(is_ref_module_code_lov,'0') as is_ref_module_code_lov  ,isnull(populate_lov,'1') as populate_lov,  ";
			final_qry += " isnull(su.ref_module_code,0) as ref_module_code,isnull(ref.file_name,'') as ref_module_table_name ";
			final_qry += " from ia_s_user_schema_elements su inner join ia_menu_options s ";
			final_qry += " on s.internal_code=su.ref_s_user_schema_code ";
			final_qry += "  left join ia_menu_options ref on ref.internal_code=su.ref_module_code ";
			final_qry += " where ref_s_user_schema_code=" + module_id + "  and is_multiple_group=0  order by su.sequence";
			logger.info("********* Elements final_qry--------" + final_qry);
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, final_qry);
			System.out.println("query_data_obj size....." + (query_data_obj == null ? 0 : query_data_obj.size()));
			if (query_data_obj != null && query_data_obj.size() > 0) {
				System.out.println("query_data_obj...." + query_data_obj);
				jsn_obj.put("1", query_data_obj);
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { ex.printStackTrace(); }
		} catch (RuntimeException ex) { ex.printStackTrace(); }
	}

	public void GetSUSerSchemaHeaderDetails(Session session, String module_id) {
		try {
			String Sql = "select   isnull(mo.file_name,'') as system_module_table_name,mo.internal_code,mg.menu_name,mg.menu_type,isnull(sg.sub_menu_name,'') as sub_menu_name,mo.module_name,";
			Sql += "  mo.display_name, isnull(load_type,'Internal') as  load_type,isnull(view_type,'EntryScreen') as  view_type ,isnull(js_path,'') as js_path ";
			Sql += ",isnull(include_generate,'0') as include_generate  ,isnull(include_download,'0') as include_download ,isnull(include_save,0) as include_save,isnull(include_view,0) as include_view,isnull(include_close,0) as include_close,isnull(include_clear,0) as include_clear,isnull(custom_links,'') as custom_links";
			Sql += " from ia_menu_groups mg ";
			Sql += " inner join ia_menu_options mo on mo.ref_menu_group_code=mg.internal_code";
			Sql += " left join ia_menu_sub_groups sg on sg.internal_code=mo.ref_menu_subgroup_code";
			Sql += " where mo.internal_code=" + module_id;
			logger.info("********* GetSUSerSchemaHeaderDetails -------" + Sql);
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, Sql);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				jsn_obj.put("header_details", query_data_obj);
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { ex.printStackTrace(); }
		} catch (RuntimeException ex) { ex.printStackTrace(); }
	}

	public void GetSUSerSchemaGroupDetails(Session session, String module_id) {
		JSONObject multi_group = new JSONObject();
		try {
			String Sql = "select name as group_name,sug.internal_code, group_id as div_group_id,"
					+ " s.file_name+'_'+system_group_table_name+'_group' as table_name  "
					+ " from ia_s_user_schema_group sug inner join ia_menu_options s on s.internal_code=sug.ref_s_user_schema_code"
					+ " where multiple=1 and  ref_s_user_schema_code=" + module_id;
			logger.info("********* GetSUSerSchemaGroupDetails -------" + Sql);
			List<Map<String, Object>> query_data_obj = NativeQuerySupport.executeQuery(session, Sql);
			if (query_data_obj != null && query_data_obj.size() > 0) {
				for (Map<String, Object> map : query_data_obj) {
					String internal_code = map.get("internal_code").toString().trim();
					String div_group_id = map.get("div_group_id").toString().trim();
					String table_name = map.get("table_name").toString().trim();
					JSONObject grp_local_obj = new JSONObject();
					grp_local_obj.put("div_group_id", div_group_id);
					grp_local_obj.put("table_name", table_name);
					grp_local_obj.put("group_id", internal_code);
					grp_local_obj.put("is_add_row", 1);
					grp_local_obj.put("is_delete_row", 1);
					grp_local_obj.put("parent_group", 0);
					List<Map<String, Object>> query_data_elements = GetSUSerSchemaGroupElementsForGroup(session, module_id, internal_code);
					grp_local_obj.put("elements", query_data_elements);
					multi_group.put(table_name, grp_local_obj);
				}
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { ex.printStackTrace(); }
		} catch (RuntimeException ex) { ex.printStackTrace(); }
		jsn_obj.put("multi_group", multi_group);
	}

	public List<Map<String, Object>> GetSUSerSchemaGroupElementsForGroup(Session session, String module_id, String group_id) {
		List<Map<String, Object>> query_data_obj = null;
		try {
			String Sql = "select su.internal_code,su.name,su.system_name, ";
			Sql += " isnull(us.file_name,'') AS ref_module_table, ";
			Sql += " isnull(us.display_name,'') as ref_module_dis_name,  ";
			Sql += " su.data_type as Type,isnull(su.on_enter,'') as on_enter,'Meta' as meta_data, ";
			Sql += " isnull(su.text_area_rows,2) as text_area_rows, isnull(su.grid_width,0) as grid_width,";
			Sql += " su.is_read_only,isnull(su.is_ref_module_code_lov,0) as is_ref_module_code_lov, ";
			Sql += " isnull(su.optional,0) as optional ,isnull(su.ref_module_code,0) as ref_module_code, ";
			Sql += " isnull(su.list_of_values,0) as list_of_values,su.system_name as db_field,isnull(su.on_exit,'') as  on_exit ";
			Sql += " from ia_s_user_schema_elements su left join  ia_menu_options us on us.internal_code=su.ref_module_code ";
			Sql += " where su.ref_s_user_schema_code=" + module_id + " and su.ref_s_user_schema_group_code=" + group_id + " ";
			Sql += " order by su.sequence";
			logger.info("********* GetSUSerSchemaGroupDetails -------" + Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);
			if (query_data_obj != null && query_data_obj.size() == 0) {
				query_data_obj = null;
			}
		} catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { ex.printStackTrace(); }
		} catch (RuntimeException ex) { ex.printStackTrace(); }
		return query_data_obj;
	}
}
