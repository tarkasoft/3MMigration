package com.mmm.system;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;

/**
 * Rebuilds {@code ia_module_meta_columns} from FrameWork menu schemas
 * ({@code ia_menu_options} + {@code ia_s_user_schema_elements}).
 *
 * <p>Ported from legacy insba {@code CreateModuleMetaColumns} (Java 8 / openSession)
 * to INPCV2 Spring Boot 3 / Java 21 / Hibernate 6 ({@code getCurrentSession} +
 * {@code @Transactional}).
 *
 * <p>Call: {@code GET/POST /INPCV2/titpl/metacolumns/createModuleMetaColumns}
 */
@RestController
@RequestMapping("titpl/metacolumns")
public class CreateModuleMetaColumns {

	private static final Logger logger = LogManager.getLogger(CreateModuleMetaColumns.class);

	private final SessionFactory sessionFactory;
	private final Gson gson = new Gson();

	public CreateModuleMetaColumns(
			@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@RequestMapping(value = "createModuleMetaColumns", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String createModuleMetaColumns() {
		Map<String, Object> result = new LinkedHashMap<>();
		List<Map<String, Object>> processed = new ArrayList<>();
		List<Map<String, Object>> skipped = new ArrayList<>();

		try {
			List<Map<String, Object>> schemaIdList = getSchemaIds();
			if (schemaIdList == null || schemaIdList.isEmpty()) {
				result.put("error_code", 0);
				result.put("status", "success");
				result.put("message", "No FrameWork schemas found");
				result.put("processed", processed);
				result.put("skipped", skipped);
				return gson.toJson(result);
			}

			for (Map<String, Object> schemaIdMap : schemaIdList) {
				String schemaId = str(schemaIdMap.get("schema_id"));
				Map<String, Object> row = new LinkedHashMap<>();
				row.put("schema_id", schemaId);

				if (schemaId.isEmpty()) {
					row.put("reason", "empty schema_id");
					skipped.add(row);
					continue;
				}

				List<Map<String, Object>> displayCols = getDisplayColsWithKey(schemaId);
				if (displayCols == null || displayCols.isEmpty()) {
					displayCols = getDisplayColsWithoutKey(schemaId);
				}
				if (displayCols == null || displayCols.isEmpty()) {
					row.put("reason", "no display columns");
					skipped.add(row);
					continue;
				}

				String moduleId;
				String moduleName;
				String tableName;
				String fieldName;
				String fieldId;

				if (displayCols.size() == 1) {
					moduleId = str(displayCols.get(0).get("module_id"));
					moduleName = str(displayCols.get(0).get("module_name"));
					tableName = str(displayCols.get(0).get("table_name"));
					fieldName = str(displayCols.get(0).get("field_name"));
					fieldId = str(displayCols.get(0).get("field_id"));
				} else {
					moduleId = str(displayCols.get(0).get("module_id"));
					moduleName = str(displayCols.get(0).get("module_name"));
					tableName = str(displayCols.get(0).get("table_name"));
					fieldName = str(displayCols.get(0).get("field_name")) + "-ele-"
							+ str(displayCols.get(1).get("field_name"));
					fieldId = str(displayCols.get(0).get("field_id")) + "+'-'+"
							+ str(displayCols.get(1).get("field_id"));
				}

				logger.info("meta columns: {}\t{}\t{}\t{}\t{}", moduleId, moduleName, tableName, fieldName, fieldId);

				deleteMetaColumns(moduleId);
				insertIntoMetaColumn(moduleId, moduleName, tableName, fieldName, fieldId);

				String extraCond = " and is_key_field=1 ";
				List<Map<String, Object>> fieldNames = getFieldNames(schemaId, extraCond);
				if (fieldNames == null || fieldNames.isEmpty()) {
					fieldNames = getFieldNames(schemaId, " ");
				}
				if (fieldNames == null || fieldNames.isEmpty()) {
					row.put("reason", "inserted display cols but no field names for update");
					row.put("module_id", moduleId);
					skipped.add(row);
					continue;
				}

				String fieldName1;
				String fieldName2 = "";
				String fieldId1;
				String fieldId2 = "";

				if (fieldNames.size() == 1) {
					fieldName1 = str(fieldNames.get(0).get("field"));
					fieldId1 = str(fieldNames.get(0).get("field_name"));
				} else {
					fieldName1 = str(fieldNames.get(0).get("field"));
					fieldName2 = str(fieldNames.get(1).get("field"));
					fieldId1 = str(fieldNames.get(0).get("field_name"));
					fieldId2 = str(fieldNames.get(1).get("field_name"));
				}

				updateMetaColumns(fieldName1, fieldName2, fieldId1, fieldId2, schemaId);

				row.put("module_id", moduleId);
				row.put("module_name", moduleName);
				row.put("table_name", tableName);
				row.put("field_name", fieldName);
				row.put("field_id", fieldId);
				row.put("field_name1", fieldName1);
				row.put("field_name2", fieldName2);
				processed.add(row);
			}

			result.put("error_code", 0);
			result.put("status", "success");
			result.put("message", "Module meta columns rebuilt");
			result.put("processed", processed);
			result.put("skipped", skipped);
			return gson.toJson(result);
		} catch (Exception ex) {
			logger.error("createModuleMetaColumns failed", ex);
			result.put("error_code", -1);
			result.put("status", "failure");
			result.put("message", ex.getMessage());
			result.put("processed", processed);
			result.put("skipped", skipped);
			return gson.toJson(result);
		}
	}

	private void updateMetaColumns(String fieldName1, String fieldName2, String fieldId1, String fieldId2,
			String schemaId) {
		String sql = """
				update ia_module_meta_columns
				set field_name1 = :fieldName1,
				    field_name2 = :fieldName2,
				    field_id1 = :fieldId1,
				    field_id2 = :fieldId2
				where module_id = :schemaId
				""";
		logger.info("Update Meta columns schemaId={} field_name1={} field_name2={}", schemaId, fieldName1, fieldName2);
		session().createNativeQuery(sql)
				.setParameter("fieldName1", fieldName1)
				.setParameter("fieldName2", fieldName2)
				.setParameter("fieldId1", fieldId1)
				.setParameter("fieldId2", fieldId2)
				.setParameter("schemaId", schemaId)
				.executeUpdate();
	}

	private List<Map<String, Object>> getFieldNames(String schemaId, String extraCond) {
		// extraCond is a fixed fragment from this class only (" and is_key_field=1 " or " ")
		String sql = """
				select top 2 ref_s_user_schema_code as schema_id,
				       module_name,
				       name as field,
				       system_name as field_name
				from ia_s_user_schema_elements s
				inner join ia_menu_options su on su.internal_code = ref_s_user_schema_code
				where ref_s_user_schema_code = :schemaId
				""" + extraCond + """
				order by ref_s_user_schema_group_code, isnull(s.sequence,0), su.internal_code desc
				""";
		logger.info("get_field_names schemaId={} extraCond={}", schemaId, extraCond.trim());
		return NativeQuerySupport.listAsMaps(session(), sql,
				Map.of("schemaId", schemaId),
				NativeQuerySupport.stringScalars("schema_id", "module_name", "field", "field_name"));
	}

	private void insertIntoMetaColumn(String moduleId, String moduleName, String tableName, String fieldName,
			String fieldId) {
		String sql = """
				insert into ia_module_meta_columns (
				    module_id, module_name, table_name, field_name, field_id
				) values (
				    :moduleId, :moduleName, :tableName, :fieldName, :fieldId
				)
				""";
		logger.info("insert Meta columns moduleId={} table={}", moduleId, tableName);
		session().createNativeQuery(sql)
				.setParameter("moduleId", moduleId)
				.setParameter("moduleName", moduleName)
				.setParameter("tableName", tableName)
				.setParameter("fieldName", fieldName)
				.setParameter("fieldId", fieldId)
				.executeUpdate();
	}

	private void deleteMetaColumns(String moduleId) {
		String sql = "delete from ia_module_meta_columns where module_id = :moduleId";
		logger.info("delete Meta columns moduleId={}", moduleId);
		session().createNativeQuery(sql)
				.setParameter("moduleId", moduleId)
				.executeUpdate();
	}

	private List<Map<String, Object>> getSchemaIds() {
		String sql = "select distinct internal_code as schema_id from ia_menu_options where load_type = 'FrameWork'";
		logger.info("getSchemaIds");
		return NativeQuerySupport.listAsMaps(session(), sql, Map.of(),
				NativeQuerySupport.stringScalars("schema_id"));
	}

	/** get_display_cols_WK — with key field */
	private List<Map<String, Object>> getDisplayColsWithKey(String schemaId) {
		String sql = """
				select top 2 ref_s_user_schema_code as module_id,
				       module_name,
				       name as field_name,
				       system_name as field_id,
				       su.file_name as table_name,
				       isnull(s.sequence,0) as s,
				       su.internal_code as b
				from ia_s_user_schema_elements s
				inner join ia_menu_options su on su.internal_code = ref_s_user_schema_code
				where is_key_field = 1 and ref_s_user_schema_code = :schemaId
				order by ref_s_user_schema_group_code, isnull(s.sequence,0), su.internal_code
				""";
		logger.info("get_display_cols_WK schemaId={}", schemaId);
		Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
		scalars.put("module_id", StandardBasicTypes.STRING);
		scalars.put("module_name", StandardBasicTypes.STRING);
		scalars.put("field_name", StandardBasicTypes.STRING);
		scalars.put("field_id", StandardBasicTypes.STRING);
		scalars.put("table_name", StandardBasicTypes.STRING);
		scalars.put("s", StandardBasicTypes.STRING);
		scalars.put("b", StandardBasicTypes.STRING);
		return NativeQuerySupport.listAsMaps(session(), sql, Map.of("schemaId", schemaId), scalars);
	}

	/** get_display_cols_WOK — without key filter */
	private List<Map<String, Object>> getDisplayColsWithoutKey(String schemaId) {
		String sql = """
				select top 2 ref_s_user_schema_code as module_id,
				       module_name,
				       name as field_name,
				       system_name as field_id,
				       su.file_name as table_name,
				       isnull(s.sequence,0) as s,
				       su.internal_code as b
				from ia_s_user_schema_elements s
				inner join ia_menu_options su on su.internal_code = ref_s_user_schema_code
				where ref_s_user_schema_code = :schemaId
				order by ref_s_user_schema_group_code, isnull(s.sequence,0), su.internal_code
				""";
		logger.info("get_display_cols_WOK schemaId={}", schemaId);
		Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
		scalars.put("module_id", StandardBasicTypes.STRING);
		scalars.put("module_name", StandardBasicTypes.STRING);
		scalars.put("field_name", StandardBasicTypes.STRING);
		scalars.put("field_id", StandardBasicTypes.STRING);
		scalars.put("table_name", StandardBasicTypes.STRING);
		scalars.put("s", StandardBasicTypes.STRING);
		scalars.put("b", StandardBasicTypes.STRING);
		return NativeQuerySupport.listAsMaps(session(), sql, Map.of("schemaId", schemaId), scalars);
	}

	private static String str(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}
}
