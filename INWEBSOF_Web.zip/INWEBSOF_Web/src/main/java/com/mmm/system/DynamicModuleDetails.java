package com.mmm.system;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.persistence.PersistenceException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.titpl.NativeQuerySupport;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mmm.titpl.FWValidation;
import com.mmm.titpl.Format;
 

public class DynamicModuleDetails {
	private final SessionFactory sessionFactory;
	public DynamicModuleDetails(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	private Session session() {
		return sessionFactory.getCurrentSession();
	}  
		static Logger logger = LogManager.getLogger(DynamicModuleDetails.class);  
		String final_insert_qry="";
		String final_update_qry="";
		String login_user_int_code="0";
		String internal_code="0";
		String system_module_table_name="";
		String save_type="New";
		JSONObject group_details_arr= new JSONObject();
	public JSONObject AddUserSchemaGeneralDetailsNew(DynamicMasterJsonData dyn_json_data,String n_login_user_int_code) throws ParseException
	{
		System.out.println("dyn_json_data....."+dyn_json_data);
		
		final_insert_qry="";
		group_details_arr = null;
		login_user_int_code=n_login_user_int_code;
		JSONObject return_obj = new JSONObject();
		
		  system_module_table_name=dyn_json_data.system_module_table_name;
		  String FW_login_Id=dyn_json_data.FW_login_Id;
		  internal_code=dyn_json_data.internal_code;		 
		  FormInsertUpdateCommands(dyn_json_data.save_schema_details_arr,dyn_json_data.header_data_type_arr);
		 
		  group_details_arr=dyn_json_data.group_details_arr;
			  
			  
		  		//factory=HybernetUtil.GetHyberNetSessionFactory(); 
				Session session = session();
				  if(login_user_int_code.equals("0")|| login_user_int_code.isEmpty())
				  {
					  login_user_int_code= Format.GetUserIntForEnlId(session,FW_login_Id);
					  System.out.println("login_user_int_code......."+login_user_int_code);
				  }
				CreateTablesAndElements.Snapshot beforeSave = CreateTablesAndElements.PreSaveData(
						session, system_module_table_name, internal_code);
	 
			try
			{
				 if(internal_code.equals("0"))
				  {
					 save_type="New";
					  return_obj=InsertIntoHeaderTable(session,final_insert_qry);
					 
					  
					  

					   
					  System.out.println("return_obj.."+return_obj);
				  }
				 else 
				  {
					 save_type="Edit";
					  return_obj=UpdateHeaderTable(session,final_update_qry);
					  HandleGroupDetails(session,internal_code);
				  }
				 Object lastIdObj = return_obj.get("last_id");
				 String last_id_to_str = lastIdObj == null ? "0" : lastIdObj.toString();
				 	if(!last_id_to_str.equals("0") && CreateTablesAndElements.isSchemaTable(system_module_table_name))
				 	{
				 		FWValidation.PostSaveModuleDetails(session, system_module_table_name, internal_code, last_id_to_str, beforeSave);
				 	}

			}
			catch (PersistenceException ex) {
				Throwable cause = ex.getCause();
				if (cause instanceof SQLException) { }
			}

		return return_obj;	 
			
		 
	}
	
	public JSONObject InsertIntoHeaderTable(Session session,String t_final_insert_qry)
	{
		 JSONObject return_obj = new JSONObject();
		 
		 try
			{
				logger.info("t_final_insert_qry------"+t_final_insert_qry);
				Query query = session.createNativeQuery(t_final_insert_qry);
				query.executeUpdate();
				List<Map<String,Object>> idRows = NativeQuerySupport.executeQuery(session, "SELECT @@identity as last_id");
				String lastId = (idRows==null || idRows.isEmpty() || idRows.get(0).get("last_id")==null) ? "0" : idRows.get(0).get("last_id").toString();
				if(lastId.equals("0"))
				{
					return_obj.put("msg", "Insertion failed");
					return_obj.put("last_id", lastId);
					
				}
				else
				{
					
					HandleGroupDetails(session,lastId);
					return_obj.put("msg", "inserted successfully");
					return_obj.put("last_id", lastId);
				}

			}
			catch (PersistenceException ex) {
				Throwable cause = ex.getCause();
				return_obj.put("msg", ex.getCause()==null?ex.toString():ex.getCause().toString());
				return_obj.put("last_id", "0");
				if (cause instanceof SQLException) { }
				} 
		return return_obj;
	}
	ArrayList  GetExistingGroupIntCodeForGroupTable(Session session,String group_table_name)
	{
		ArrayList existing_group_int_codes = new ArrayList();
		String sql=" select internal_code from "+group_table_name+"  where ref_s_ref_data_code="+internal_code;
		logger.info(" get_existing_grp_int_codes_qry==>"+sql);
		try
		{
			List<Map<String,Object>> query_data_obj=NativeQuerySupport.executeQuery(session, sql);
			if(query_data_obj!=null && query_data_obj.size()>0)
			{
	    		  for (Map<String, Object> map : query_data_obj) {
	    			    String internal_code=map.get("internal_code").toString();
	    			    existing_group_int_codes.add(internal_code);
	    		  }
			}
		}catch (PersistenceException ex) 
		{
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {}
		}catch (RuntimeException ex) {}
		logger.info(" get_existing_grp_int_codes list==>"+existing_group_int_codes);
		return existing_group_int_codes;
	}
	void  HandleGroupDetails(Session session,String lastId)
	{
		String json_string=group_details_arr.toJSONString();
		JSONObject grp_json_data_obj= new JSONObject();
		 JSONParser parser = new JSONParser();
		  try {
			grp_json_data_obj=(JSONObject) parser.parse(json_string);
			
			if(grp_json_data_obj.size()>0)
			  {
					//gor each group_table_name
				  for (Object key : grp_json_data_obj.keySet()) 
				  {
						 String group_table_name = (String)key;
						 
						 JSONObject tmp_group_details_arr = new JSONObject();
						 tmp_group_details_arr=(JSONObject) grp_json_data_obj.get(group_table_name);
						 ArrayList existing_group_int_codes = new ArrayList();
						 ArrayList ui_group_int_codes = new ArrayList();
						 if(save_type.equals("Edit"))
						 {
							 existing_group_int_codes=GetExistingGroupIntCodeForGroupTable(session,group_table_name);
						 }
						  //loop each row in group
						 for (Object row_id_key : tmp_group_details_arr.keySet()) {
							 String row_id = (String)row_id_key;
							 JSONObject group_row_obj = new JSONObject();
						 
							 group_row_obj = (JSONObject) tmp_group_details_arr.get(row_id);
							 
							 String group_int_code=group_row_obj.get("group_int_code").toString();
							 ui_group_int_codes.add(group_int_code);
							 
							 ForGroupInsertUpdateCommands(session,group_table_name,lastId,group_row_obj);
							 //System.out.println(keyvalue);
						 } 
						 if(save_type.equals("Edit") && existing_group_int_codes.size()>0)
						 DeleteMissingGroupRowDetails(session, group_table_name, existing_group_int_codes, ui_group_int_codes);
						 
					}
					        
			  }
			
			
			 
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		
		/*
		 if(group_details_arr.size()>0)
		  {
			  for (Object key : group_details_arr.keySet()) {
					 String group_table_name = (String)key;
					 System.out.println(group_table_name);
					 JSONObject tmp_group_details_arr = new JSONObject();
					 System.out.println(group_details_arr.get(group_table_name));
					  tmp_group_details_arr=(JSONObject) group_details_arr.get(group_table_name);
					  System.out.println("main loop");
					  System.out.println(tmp_group_details_arr);
					 
					 System.out.println(tmp_group_details_arr.keySet());
					 for(Iterator iterator = tmp_group_details_arr.keySet().iterator(); iterator.hasNext();) {
						    String keya = (String) iterator.next();
						    System.out.println(tmp_group_details_arr.get(keya));
						    JSONObject tmp_group_details_row_arr = new JSONObject();
						   
						   
						   // ForGroupInsertUpdateCommands(session,group_table_name,lastId,tmp_group_details_arr.get(keya));
						}

							 
								
								 
 
				 }*/
		   
		  
	}
	public void DeleteMissingGroupRowDetails(Session session,String group_table_name,ArrayList existing_group_code,ArrayList ui_group_code)
	{
		 
		 Set<String> set1 = new HashSet<String>();
		    Set<String> set2 = new HashSet<String>();

		    set1.addAll(existing_group_code);
		    set2.addAll(ui_group_code);

		    set1.removeAll(set2);
		  
		    Iterator iter = set1.iterator();
		    String int_codes="";
		    while (iter.hasNext()) {
		    	int_codes+=iter.next()+",";
		    }
		    if(!int_codes.isEmpty())
		    {
		    	int_codes=int_codes.substring(0,int_codes.length()-1);
		    	 String db_qry="delete from "+group_table_name+" where ref_s_ref_data_code="+internal_code;
		    	 db_qry+=" and internal_code in("+int_codes+")";
				 logger.info("delete group qryyyyyyyyy->"+db_qry);
						 try
					{
								Query query = session.createNativeQuery(db_qry);
						query.executeUpdate();
				 
						 

					}
					catch (PersistenceException ex) {
						Throwable cause = ex.getCause();
						logger.info(" ERROR WHILE In Delete Group Qry="+ex.getCause()+"==>"+db_qry);
						
						if (cause instanceof SQLException) {
								}
						} 
		    }
		    
	}
	public void ForGroupInsertUpdateCommands(Session session,String group_table_name,String ref_s_ref_data_code,JSONObject group_row_obj)
	{
		 
	//this will be called for each group row
		String insert_cols="";
		String  insert_col_values="";
		String update_cond=""; 
		String group_int_code=group_row_obj.get("group_int_code").toString();
	 
	 
		 for (Object key : group_row_obj.keySet()) {
			 String keyStr = (String)key;
			 String keyvalue = java.net.URLDecoder.decode(group_row_obj.get(keyStr).toString());
			 keyvalue = keyvalue.replace("'","''");
			 
			 if(keyStr.equals("group_int_code")) continue;
			 insert_cols+=keyStr+",";
			 String cell_val="'"+keyvalue+"'";
			  
			 insert_col_values+=cell_val+",";		
			 update_cond+=keyStr+"= "+cell_val+",";
				
		        
		 }
		 insert_cols=insert_cols.substring(0,insert_cols.length()-1);
		 insert_col_values=insert_col_values.substring(0,insert_col_values.length()-1);
		 String db_qry="";
		 if(group_int_code.equals("0"))
		 {
			 db_qry="insert into "+group_table_name;
			 db_qry+="(   ref_s_ref_data_code,"+insert_cols+",created_by, ";
			 db_qry+="created_date,modified_by,modified_date)  values ";
			 db_qry+=" ("+ref_s_ref_data_code+","+insert_col_values+","+login_user_int_code+"," + UserSessionSupport.sessionDate() + ","+login_user_int_code+"," + UserSessionSupport.sessionDate() + ")";	
			logger.info(" grp insert qry=="+db_qry);
			 
		 }
		 else
		 {
			 	update_cond+=" modified_by="+login_user_int_code+", modified_date=" + UserSessionSupport.sessionDate() + " ";
			 	db_qry=" update "+group_table_name+" set "+update_cond+" where internal_code="+group_int_code;
			logger.info(" grp update qry=="+db_qry);
		 
		 }
		 
		 try
			{
				Query query = session.createNativeQuery(db_qry);
				query.executeUpdate();
 
				 

			}
			catch (PersistenceException ex) {
				Throwable cause = ex.getCause();
				logger.info(" ERROR WHILE INSERT/UPDATE GROUP QRY="+ex.getCause()+"==>"+db_qry);
				
				if (cause instanceof SQLException) { 
				}
				}
			 
			
	}
	public JSONObject UpdateHeaderTable(Session session,String t_final_update_qry)
	{
		 JSONObject return_obj = new JSONObject();
		logger.info("final_update_qry---"+final_update_qry);
		 
	        
		 try
			{
				Query query = session.createNativeQuery(t_final_update_qry);
				query.executeUpdate();

				 
					return_obj.put("msg", "Updated Successfully");
					return_obj.put("last_id", internal_code);
				 

			}
			catch (PersistenceException ex) {
				Throwable cause = ex.getCause();
				return_obj.put("msg", ex.getCause().toString());
				return_obj.put("last_id", "0");
				
				if (cause instanceof SQLException) {
				}
				} 
		 
		 
		
		 
		return return_obj;
	}
	public void  FormInsertUpdateCommands(JSONObject save_schema_details_arr ,JSONObject header_data_type_arr )
	{
		String insert_cols="";
		String  insert_col_values="";
		String update_cond=""; 
		 System.out.println("save_schema_details_arr==>"+save_schema_details_arr);
		 for (Object key : save_schema_details_arr.keySet()) {
			 String keyStr = (String)key;
			 String data_type=header_data_type_arr.get(keyStr).toString();
			 String keyvalue = java.net.URLDecoder.decode(save_schema_details_arr.get(keyStr).toString());
			 keyvalue = keyvalue.replace("'","''");
			 
			 insert_cols+=keyStr+",";
			 String cell_val="'"+keyvalue+"'";
			 /* Empty date or reference code must be NULL. '' cannot join to ia_user_type.internal_code. */
			 if(keyvalue.isEmpty() && ("Date".equals(data_type) || "Reference Data".equals(data_type)))
				 cell_val="NULL"; 
			
			  
			 insert_col_values+=cell_val+",";		
			 update_cond+=keyStr+"= "+cell_val+",";
				
		        
		 }
		 insert_cols=insert_cols.substring(0,insert_cols.length()-1);
		 insert_col_values=insert_col_values.substring(0,insert_col_values.length()-1);
		 
		 String insert_qry="insert into "+system_module_table_name;
				 insert_qry+="(   "+insert_cols+",created_by, ";
				 insert_qry+="created_date,modified_by,modified_date)  values ";
				 insert_qry+=" ("+insert_col_values+","+login_user_int_code+"," + UserSessionSupport.sessionDate() + ","+login_user_int_code+"," + UserSessionSupport.sessionDate() + ")";	
		 final_insert_qry=insert_qry;
		 
		 update_cond+=" modified_by="+login_user_int_code+", modified_date=" + UserSessionSupport.sessionDate() + " ";
			final_update_qry=" update "+system_module_table_name+" set "+update_cond+" where internal_code="+internal_code;
			
			
					 

	}
	
	public JSONObject GetSchemaModuleDetailsForUpdateNew(String internal_code,String table_name)  throws ParseException
	 {
		 
			
		 
			JSONObject return_obj = new JSONObject();
			return_obj.put("internal_code",internal_code);
			return_obj.put("details",""); 
			  //  factory=HybernetUtil.GetHyberNetSessionFactory(); 
				Session session = session();
				try
				{
						JSONObject qry_obj = new JSONObject();
					  
						qry_obj=GetEditQuery(session,table_name,internal_code);
						JSONObject fields_arr = new JSONObject();
						String full_qry=(String) qry_obj.get("full_qry");
						fields_arr= (JSONObject) qry_obj.get("fields_arr");
						List<Map<String,Object>> query_data_obj=null;
						
						query_data_obj=GetDetailsRowDataSet(session,full_qry,fields_arr); 
						return_obj.put("details",query_data_obj); 
						JSONObject grp_details = new JSONObject();
						grp_details=GetGroupDetailsForUpdate(session,table_name,internal_code);
						return_obj.put("grp_details",grp_details); 
				}
				catch (PersistenceException ex) {
					Throwable cause = ex.getCause();
					if (cause instanceof SQLException) { }
				}

			return return_obj;	
	 }
	List<Map<String,Object>> GetDetailsRowDataSet(Session session,String full_qry,JSONObject fields_arr)
	{
		List<Map<String,Object>> query_data_obj=null;
		  try{
				// fields_arr kept for signature parity; NativeQuerySupport reads ResultSet labels
				if(full_qry!=null && !full_qry.isBlank())
				{
					query_data_obj=NativeQuerySupport.executeQuery(session, full_qry);
					if(query_data_obj!=null && query_data_obj.size()==0)
						query_data_obj=null;
				}
			   }
	      		catch (PersistenceException ex) {
			        Throwable cause = ex.getCause();
			        if (cause instanceof SQLException) { }
			 }catch (RuntimeException ex) { }
		return query_data_obj;
		
	}
	JSONObject GetEditQuery(Session session,String table_name,String internal_code)
	{
		String join_qry= GetRefModuleJoinQueryForEdit(session,table_name);
 
		JSONObject qry_obj = new JSONObject();
		JSONObject s_field_obj = new JSONObject();
		JSONObject fields_arr = new JSONObject();
		 qry_obj.put("full_qry","");
		 qry_obj.put("fields_arr",fields_arr);
		String qry="select data_type,";
		qry+="		  		case when data_type='Reference Data' then 'isnull('+f1+f2 +','''') as txt_ref_schema_'+field_name+',isnull('+table_name+'.'+field_name+',0) as '+field_name	 	 ";
		qry+="		when data_type='Date' then 'convert(varchar(10),'+table_name+'.'+field_name+ ',103) as '+ field_name ";
		qry+="		when data_type='Number' then 'isnull('+table_name+'.'+field_name+',''0'') as '+ field_name ";
		qry+="		else 'isnull('+table_name+'.'+field_name+','''') as '+ field_name  ";
		qry+="	end as field_name,field_name as u_field_name  ";
		 
		qry+=" from  ";
		qry+=" (select  su.sequence su_seq,s.internal_code, su.internal_code as ele_id, ";
		qry+=" ref_module_code, s.file_name as table_name ,s.display_name, ";
		qry+=" field_id,";
		qry+=" case when isnull(field_id1,'')<>'' then table_name+'_'+convert(varchar(10),su.internal_code)+'.'+field_id1 else '' end as f1, ";
		qry+=" case when isnull(field_id2,'')<>'' then '+'' -''+ '+table_name+'_'+convert(varchar(10),su.internal_code)+'.'+field_id2 else '' end  as f2, ";
		 
		qry+="  isnull(is_multiple_group,0) as multiple , ";
		qry+=" system_name as field_name , data_type ";
		qry+=" from ia_menu_options s inner join ia_s_user_schema_elements su on ";
		qry+=" su.ref_s_user_schema_code=s.internal_code ";
		qry+="  left join ia_module_meta_columns mmc on mmc.module_id=su.ref_module_code ";
		qry+=" where s.file_name='"+table_name+"'   ";
		qry+=" and su.is_multiple_group=0 ";
		qry+=" ) l  ";
		qry+=" where   multiple=0  order by su_seq ";

		 logger.info("*******Edit Display Field s Qry==>"+qry);
	     //System.out.println(Sql);
	    	 int field_records_found=0;
	    	 String field_name="";
			try
			{
				List<Map<String,Object>> query_data_obj=NativeQuerySupport.executeQuery(session, qry);
				if(query_data_obj!=null && query_data_obj.size()>0)
				{
					field_records_found=1;
		    		  for (Map<String, Object> map : query_data_obj) {
		    			    String t_field_name=map.get("field_name").toString();
		    			    field_name+=t_field_name +",";
		    			    fields_arr.put(map.get("u_field_name").toString(),map.get("data_type").toString());
		    			   
		    		  }
		    		  field_name=field_name.substring(0,field_name.length()-1);
		    		  
				}
			}catch (PersistenceException ex) 
			{
				Throwable cause = ex.getCause();
				if (cause instanceof SQLException) {}
			}catch (RuntimeException ex) {}
			
			 		
					String full_qry =  "select "+table_name +".internal_code as id,"+field_name; 
					full_qry+=" from ";
					full_qry+= table_name + join_qry;
					full_qry+="	where "+table_name+".internal_code="+internal_code;
					logger.info("FInal Edit Qry=="+full_qry);
				 
						 
 
					qry_obj.put("full_qry",full_qry);
					qry_obj.put("fields_arr",fields_arr);

		 		 
		 
			
		return qry_obj;
	}
	 
	String GetRefModuleJoinQueryForEdit(Session session,String table_name)
	{
		String join_qry=" ";
		String qry="select ' left join '+s.file_name+ ' as '+s.file_name+'_'+convert(varchar(10),sus.internal_code)+' on '+s.file_name+'_'+convert(varchar(10),sus.internal_code)+'.internal_code ='+ sch.file_name +'.'+ system_name  as join_table_name ";
		qry+="	from ia_s_user_schema_elements  sus";
		qry+=" inner join ia_menu_options sch on sus.ref_s_user_schema_code=sch.internal_code";
		qry+=" inner join ia_menu_options s on sus.ref_module_code=s.internal_code ";
		
		qry+=" where sch.file_name='"+table_name+"' ";
		qry+=" and is_multiple_group=0 and ref_module_code>0;";
	  
		 logger.info("*******GetRefModuleJoinQuery s Qry==>"+qry);
	     //System.out.println(Sql);
	    	 
			try
			{
				List<Map<String,Object>> query_data_obj=NativeQuerySupport.executeQuery(session, qry);
				if(query_data_obj!=null && query_data_obj.size()>0)
				{
		    		  for (Map<String, Object> map : query_data_obj) {
		    			  String join_table_name=map.get("join_table_name").toString();
		    			  join_qry+=join_table_name +" ";
		    		  }
		    		  
				}
			}catch (PersistenceException ex) 
			{
				Throwable cause = ex.getCause();
				if (cause instanceof SQLException) {}
			}catch (RuntimeException ex) {}
			        
		return join_qry;
	}
	//Group Details for Update
	JSONObject GetGroupDetailsForUpdate(Session session,String table_name,String header_internal_code)
	{
		JSONObject group_details = new JSONObject();
		 
		try{
	   
	         String Sql = "select name as group_name,sug.internal_code, "
	         	   		+ " s.file_name+'_'+system_group_table_name+'_group' as table_name  "
	         		 + " from ia_s_user_schema_group sug inner join ia_menu_options s on s.internal_code=sug.ref_s_user_schema_code"
	         		+ " where multiple=1 and  s.file_name='"+table_name+"'";
		  
	     System.out.println("********* GetGroupDetailsForUpdate -------"+Sql);
	    		  List<Map<String,Object>> query_data_obj=NativeQuerySupport.executeQuery(session, Sql);
				 if(query_data_obj!=null && query_data_obj.size()>0)
	    		 { 
		    		  for (Map<String, Object> map : query_data_obj)
			  		    {
			    			   	 
		    			  String group_internal_code= map.get("internal_code").toString().trim();
		    		 
		    			  String group_table_name= map.get("table_name").toString().trim();
		    			  
		    			  List<Map<String,Object>> grp_query_data_obj=  new ArrayList<Map<String,Object>>();
		    			  grp_query_data_obj=GetGroupTableDataForEachGroup(session,table_name,header_internal_code,group_table_name,group_internal_code);
		    			  System.out.println("group_table_name---"+group_table_name);
		    			  group_details.put(group_table_name,grp_query_data_obj);
		    			  
		    			  
			  		    }
	    		 }
				 
	    					  
			   }catch (PersistenceException ex) {
			        Throwable cause = ex.getCause();
			        if (cause instanceof SQLException) {
			        	 ex.printStackTrace();
			        }
			   } 
		
		
		return group_details;
	}
	List<Map<String,Object>> GetGroupTableDataForEachGroup(Session session,String table_name,String header_internal_code,String  group_table_name,
			String  group_internal_code)
	{
		  List<Map<String,Object>> grp_query_data_obj= new ArrayList<Map<String,Object>>();;
		
		  
		  JSONObject qry_obj = new JSONObject();
		  
			qry_obj=  GetEditQueryForEachGroup(session,group_table_name,header_internal_code,group_internal_code);
			JSONObject fields_arr = new JSONObject();
			String full_qry=(String) qry_obj.get("full_qry");
			fields_arr= (JSONObject) qry_obj.get("fields_arr");
			  try{
					if(full_qry!=null && !full_qry.isBlank())
					{
						grp_query_data_obj=NativeQuerySupport.executeQuery(session, full_qry);
					}
				   }
		      		catch (PersistenceException ex) {
				        Throwable cause = ex.getCause();
				        if (cause instanceof SQLException) { }
				 }catch (RuntimeException ex) { }
			 
		  return grp_query_data_obj;
	}
	JSONObject GetEditQueryForEachGroup(Session session,String group_table_name,String header_internal_code,String group_internal_code)
	{
		 
	 
		 String join_qry=GetRefModuleJoinQueryForGroupId(session,group_internal_code);
		JSONObject qry_obj = new JSONObject();
		JSONObject s_field_obj = new JSONObject();
		JSONObject fields_arr = new JSONObject();
		 
		String qry="select data_type,";
		qry+="		  		case when data_type='Reference Data' then 'isnull('+f1+f2 +','''') as txt_ref_schema_'+field_name+',isnull('+table_name+'.'+field_name+',0) as '+field_name	 	 ";
		qry+="		when data_type='Date' then 'convert(varchar(10),'+table_name+'.'+field_name+ ',103) as '+ field_name ";
		qry+="		when data_type='Number' then 'isnull('+table_name+'.'+field_name+',''0'') as '+ field_name ";
		qry+="		else 'isnull('+table_name+'.'+field_name+','''') as '+ field_name  ";
		qry+="	end as field_name,field_name as u_field_name  ";
		 
		qry+=" from  ";
		qry+=" (select  su.sequence su_seq,s.internal_code, su.internal_code as ele_id, ";
		qry+=" ref_module_code, s.file_name+'_'+g.system_group_table_name+'_group' as table_name ,s.display_name, ";
		qry+=" field_id,";
		qry+=" case when isnull(field_id1,'')<>'' then table_name+'_'+convert(varchar(10),su.internal_code)+'.'+field_id1 else '' end as f1, ";
		qry+=" case when isnull(field_id2,'')<>'' then '+'' -''+ '+table_name+'_'+convert(varchar(10),su.internal_code)+'.'+field_id2 else '' end  as f2, ";
		 
		qry+="  isnull(is_multiple_group,0) as multiple , ";
		qry+=" system_name as field_name , data_type ";
		qry+=" from ia_menu_options s inner join ia_s_user_schema_elements su on ";
		qry+=" su.ref_s_user_schema_code=s.internal_code ";
		qry+="  inner join ia_s_user_schema_group g on g.internal_code=su.ref_s_user_schema_group_code ";
		qry+="  left join ia_module_meta_columns mmc on mmc.module_id=su.ref_module_code ";
		qry+=" where g.internal_code='"+group_internal_code+"'   ";
		qry+=" and su.is_multiple_group=1";
		qry+=" ) l  ";
		qry+=" where   multiple=1  order by su_seq ";

		 logger.info("*******GRoup Edit Display Field s Qry==>"+qry);
	     System.out.println("*******GRoup Edit Display Field s Qry==>"+qry);
	    	 int field_records_found=0;
	    	 String field_name="";
			try
			{
				List<Map<String,Object>> query_data_obj=NativeQuerySupport.executeQuery(session, qry);
				if(query_data_obj!=null && query_data_obj.size()>0)
				{
					field_records_found=1;
		    		  for (Map<String, Object> map : query_data_obj) {
		    			    String t_field_name=map.get("field_name").toString();
		    			    field_name+=t_field_name +",";
		    			    fields_arr.put(map.get("u_field_name").toString(),map.get("data_type").toString());
		    			   
		    		  }
		    		  field_name=field_name.substring(0,field_name.length()-1);
		    		  
				}
			}catch (PersistenceException ex) 
			{
				Throwable cause = ex.getCause();
				if (cause instanceof SQLException) {}
			}catch (RuntimeException ex) {}
			
			 		
					String full_qry =  "select "+group_table_name +".internal_code as group_int_code, "+field_name; 
					full_qry+=" from ";
					full_qry+= group_table_name + join_qry;
					full_qry+="	where "+group_table_name+".ref_s_ref_data_code="+header_internal_code+ " order by  "+group_table_name +".row_sequence" ;
					logger.info("FInal Group Edit Qry=="+full_qry);
				 
						 
 
					qry_obj.put("full_qry",full_qry);
					qry_obj.put("fields_arr",fields_arr);

		 		 
		 
			
		return qry_obj;
	}
	
	String GetRefModuleJoinQueryForGroupId(Session session,String group_int_code)
	{
		String join_qry=" ";
		String qry="select ' left join '+s.file_name+ ' as '+s.file_name+'_'+convert(varchar(10),sus.internal_code)+' on '+s.file_name+'_'+convert(varchar(10),sus.internal_code)+'.internal_code ='+ sch.file_name+'_'+system_group_table_name+'_group' +'.'+ system_name  as join_table_name "; 
					qry+=" from ia_s_user_schema_elements  sus ";
					qry+=" inner join ia_s_user_schema_group g on g.internal_code=sus.ref_s_user_schema_group_code ";
					qry+=" inner join ia_menu_options sch on sus.ref_s_user_schema_code=sch.internal_code ";
					qry+=" inner join ia_menu_options s on sus.ref_module_code=s.internal_code ";
					qry+=" where g.internal_code="+group_int_code;
					qry+=" and is_multiple_group=1 and ref_module_code>0 ";
	  
		 logger.info("*******GetRefModuleJoinQueryForGroupId s Qry==>"+qry);
	     //System.out.println(Sql);
	    	 
			try
			{
				List<Map<String,Object>> query_data_obj=NativeQuerySupport.executeQuery(session, qry);
				if(query_data_obj!=null && query_data_obj.size()>0)
				{
		    		  for (Map<String, Object> map : query_data_obj) {
		    			  String join_table_name=map.get("join_table_name").toString();
		    			  join_qry+=join_table_name +" ";
		    		  }
		    		  
				}
			}catch (PersistenceException ex) 
			{
				Throwable cause = ex.getCause();
				if (cause instanceof SQLException) {}
			}catch (RuntimeException ex) {}
			        
		return join_qry;
	}
}
