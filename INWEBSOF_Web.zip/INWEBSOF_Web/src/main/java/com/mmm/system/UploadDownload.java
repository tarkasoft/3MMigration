package com.mmm.system;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jakarta.persistence.PersistenceException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.mmm.authentication.UserSessionSupport;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import com.mmm.titpl.Format;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/**
 * Excel upload/download for user-schema modules (insba UploadDownload port).
 * System Hibernate: Spring {@code @Transactional} + {@code getCurrentSession};
 * SELECT via {@link NativeQuerySupport#executeQuery(Session, String)}.
 */
@RestController
@RequestMapping("titpl/system")
public class UploadDownload 
{
	private final SessionFactory sessionFactory;
	static Logger logger = LogManager.getLogger(UploadDownload.class); 
	String return_html = "";
	String module_id = "";
	String system_module_table_name = "";  
	String login_user_int_code = "";
	LinkedHashMap<String,LinkedHashMap<String,String>> full_element_details = new LinkedHashMap<String, LinkedHashMap<String,String>>();
	LinkedHashMap<String,LinkedHashMap<String,String>> ref_module_list_final = new LinkedHashMap<String, LinkedHashMap<String,String>>();
	Map<String, String> system_name_data_type_arr= new LinkedHashMap<String, String>();
	public UploadDownload(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	private Session session() {
		return sessionFactory.getCurrentSession();
	}
	public void ReAssignVariables()
	{
		return_html = "";
		login_user_int_code="0";
		full_element_details = new LinkedHashMap<String, LinkedHashMap<String,String>>();
		ref_module_list_final = new LinkedHashMap<String, LinkedHashMap<String,String>>();
		system_name_data_type_arr= new LinkedHashMap<String, String>();
	}
	@RequestMapping(value="DownloadExcelFormatForUpload", method = RequestMethod.GET)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody void DownloadFormat(@RequestParam("schema_id") String t_module_id,
			@RequestParam("system_module_table_name")  String s_system_module_table_name ,HttpServletRequest request, HttpServletResponse response) 
					throws IOException 
	{
		module_id = t_module_id;
		system_module_table_name = s_system_module_table_name;
		ReAssignVariables();
		Session session = session();
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); 	
		response.setHeader("Content-Disposition", "attachment; filename="+system_module_table_name+".xlsx");
		List<Map<String,Object>> data_set=null;
		try
		{
			data_set= GetHeaderData(session,"");
		}
		catch (PersistenceException ex) 
		{
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
		Workbook wworkbook = new XSSFWorkbook();
		Sheet wsheet = wworkbook.createSheet("Sheet1");
		int row=0;
		int col=0;
		if(data_set!=null)
		{
			logger.info("start for loop at="+Format.getCurrentTimeStamp());
			setXlsxCell(wsheet, col++, row, "internal_code");
			for (Map<String, Object> map : data_set) 
			{
				try
				{
					setXlsxCell(wsheet, col++, row, map.get("name").toString());
				}
				catch(NullPointerException e)
				{
					System.out.print("NullPointerException caught"+e.getMessage());
				}
			}
		}
		logger.info("Ended for loop at="+Format.getCurrentTimeStamp());
		wworkbook.write(response.getOutputStream());
		wworkbook.close();
	}
	@RequestMapping(value="DownloadExcelFormatFullData", method = RequestMethod.GET)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody void DownloadExcelFormatFullData(@RequestParam("schema_id") String t_module_id,
			@RequestParam("system_module_table_name")  String s_system_module_table_name,
			@RequestParam("filter_cond")  String filter_cond,
			@RequestParam("selected_db_fields_arr")  String selected_db_fields_arr,
			@RequestParam("is_filter")  String is_filter,
			HttpServletRequest request, HttpServletResponse response) 
					throws IOException, ParseException 
	{
		JSONObject json =new JSONObject();
		String system_names="";
		String module_qry_cond="";
		String extra_cond="";
		String col_cond="";
		if(is_filter.equals("1"))
		{
			json = (JSONObject) new JSONParser().parse(filter_cond);
			Map<?,?> filter_cond_map=  json;
			logger.info("filter_cond_map: "+filter_cond_map);
			logger.info("selected_db_fields_arr: "+selected_db_fields_arr);
			logger.info("filter_cond: "+filter_cond);
			logger.info("is_filter: "+is_filter);
			logger.info("s_system_module_table_name: "+s_system_module_table_name);
			logger.info("t_module_id: "+t_module_id);
			String system_name_arr[]=selected_db_fields_arr.split(",");
			for(int i=0;i<system_name_arr.length;i++)
			{
				system_names+=" '"+system_name_arr[i]+"',";
			}
			logger.info("system_names: "+system_names);
			system_names=system_names.substring(0, system_names.length()-1);
			logger.info("system_names: "+system_names);
			if(!system_names.isEmpty())
				col_cond=" and su.system_name in ("+system_names+") ";
			int j=1;
			logger.info("filter_cond_map.size(): "+filter_cond_map.size());
			for(int k=0; k<filter_cond_map.size();k++)
			{
				Map value_map=(Map) filter_cond_map.get(Integer.toString(k));
				String db_filed =value_map.get("db_filed").toString().trim();
				String oper =value_map.get("oper").toString().trim();
				String val =value_map.get("val").toString().trim();
				String cond =value_map.get("cond").toString().trim();
				if(oper.equals("like"))
					val="%"+val+"%";
				module_qry_cond+= " "+db_filed+" "+ oper+" '"+val+"' ";
				if(filter_cond_map.size()!=j)
					module_qry_cond+=cond;
				j++;
			}
			if(!module_qry_cond.isEmpty())
				extra_cond=" and ("+module_qry_cond+") "; 
		}
		module_id = t_module_id;
		system_module_table_name = s_system_module_table_name;
		ReAssignVariables();
		Session session = session(); 
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); 	
		response.setHeader("Content-Disposition", "attachment; filename="+system_module_table_name+".xlsx");
		List<Map<String,Object>> data_set=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> query_data_obj=new ArrayList<Map<String,Object>>();
		try
		{
			JSONObject qry_obj = new JSONObject();
			JSONObject s_field_obj = new JSONObject();
			ArrayList fields_arr = new ArrayList();
			DisplayGrid grid_obj=new DisplayGrid(sessionFactory);
			data_set= GetHeaderData(session, col_cond); 
			qry_obj= grid_obj.GetGridQuery( session, system_module_table_name, "include_in_grid", col_cond); 
			fields_arr=(ArrayList) qry_obj.get("fields_arr"); 
			String full_qry=(String) qry_obj.get("full_qry"); 
			s_field_obj=(JSONObject) qry_obj.get("s_field_obj");
			String sort_detail=" ORDER BY "+system_module_table_name+".internal_code desc" ;
			String e_qry="  SELECT  "+full_qry;
			e_qry+= " where 1=1  "+extra_cond;
			query_data_obj = NativeQuerySupport.executeQuery(session, e_qry);
		}
		catch (PersistenceException ex) 
		{
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
		Workbook wworkbook = new XSSFWorkbook();
		Sheet wsheet = wworkbook.createSheet("Sheet1");
		int row=0;
		int col=0;
		Map<String, String> data_type_arr = new LinkedHashMap<String, String>();
		if(data_set.size()>0)
		{
			logger.info("start for loop at="+Format.getCurrentTimeStamp());
			setXlsxCell(wsheet, col++, row, "internal_code");
			for (Map<String, Object> map : data_set) 
			{
				try
				{
					setXlsxCell(wsheet, col++, row, map.get("name").toString());
					data_type_arr.put(map.get("system_name").toString(),map.get("data_type").toString());
				}
				catch(NullPointerException e)
				{
					logger.info("NullPointerException caught: "+e.getMessage());
				}
			}
		}
		row++;
		col=0;
		if(query_data_obj.size()>0)
		{
			for (Map<String, Object> map : query_data_obj)
			{
				col=0;
				String id=map.get("id").toString();
				setXlsxCell(wsheet, col++, row, id);
				for(String system_name : data_type_arr.keySet()) 
				{
					String data_type = data_type_arr.get(system_name);
					setXlsxCell(wsheet, col++, row, Format.GetObjectValueFromMap(map.get(system_name)).toString());
				}
				row++;
			}
		}
		else
		{
			wsheet.addMergedRegion(new CellRangeAddress(1, 2, 0, 4));
			setXlsxCell(wsheet, 0, 1, "Data not found", getCellFormat(wworkbook, IndexedColors.LIGHT_YELLOW, IndexedColors.BLACK, HorizontalAlignment.CENTER));  
		}
		logger.info("Ended for loop at="+Format.getCurrentTimeStamp());
		wworkbook.write(response.getOutputStream());
		wworkbook.close();
	}
	@SuppressWarnings({ "deprecation", "unchecked" })
	private List<Map<String, Object>> GetHeaderData( Session session, String col_cond) 
	{
		List<Map<String,Object>> query_data_obj=new ArrayList<Map<String,Object>>();
		try
		{		
			String Sql="select name,system_name,data_type from ia_s_user_schema_elements su where ref_s_user_schema_code='"+module_id+"' "+col_cond+"  and is_multiple_group=0  order by sequence ";
			logger.info(" schema_elements query ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);
		}
		catch (PersistenceException ex) 
		{
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		} 
		return query_data_obj;
	}	
	@RequestMapping(value="UploadModuleDetailsIntoDB", method = RequestMethod.POST)
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String UploadModuleDetailsIntoDB(@RequestParam("schema_id") String t_module_id,
			@RequestParam("system_module_table_name")  String s_system_module_table_name ,
			MultipartHttpServletRequest request, HttpServletResponse response) throws IOException 
	{   
		ReAssignVariables();
		module_id = t_module_id;
		system_module_table_name = s_system_module_table_name;
		login_user_int_code=Format.GetSessonUserIntCode(request);;
		Session session = session();
		try
		{
			ReadExcelData(session,request,response);
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
		//2. send it back to the client as <img> that calls get method
		//we are using getTimeInMillis to avoid server cached image 
		return return_html+"<br><span style='color:green'>Uploaded Successfully</span>";  
	}
	public void ReadExcelData(Session session,MultipartHttpServletRequest request, HttpServletResponse response ) throws IOException
	{
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); 	
		return_html="";
		String err_status="_error_while_uploading";
		Iterator<String> itr =  request.getFileNames(); 
		MultipartFile mpf = request.getFile(itr.next()); 
		InputStream uploadedStream = mpf.getInputStream(); 
		Workbook workbook = WorkbookFactory.create(uploadedStream); 
		logger.info("File Name==>"+mpf.getOriginalFilename() );
		Workbook wworkbook = new XSSFWorkbook();
		Sheet wsheet = wworkbook.createSheet("Sheet1");
		int row1=0;
		int col1=0;
		Map<String, String> db_field_values_arr= new LinkedHashMap<String, String>();
		Map<String, String> db_field_values_arr_err= new LinkedHashMap<String, String>();
		try {
			/*  byte[] bytes = mpf.getBytes();
			          String completeData = new String(bytes);
			          System.out.println(completeData);
			               //just temporary save file info into ufile
			       ufile.length = mpf.getBytes().length;
			       ufile.bytes= mpf.getBytes();
			       ufile.type = mpf.getContentType();
			       ufile.name = mpf.getOriginalFilename();*/
			Sheet sheet = workbook.getSheetAt(0);
			Cell rows = null;
			int columnsCount = sheet.getRow(0) == null ? 0 : sheet.getRow(0).getLastCellNum();
			int rowsCount = sheet.getLastRowNum() + 1;
			Map<String, Integer> cell_index_arr_txt_num = new LinkedHashMap<String, Integer>();
			Map<Integer,String> cell_index_arr_num_txt = new LinkedHashMap<Integer,String> ();
			int first_row_indx=0;
			for (int first_row_col = 0;  first_row_col < columnsCount;  first_row_col++) 
			{	//Iterating sheet
				String cell_val = getXlsxCellString(sheet, first_row_col, first_row_indx).trim();
				setXlsxCell(wsheet, col1++, row1, cell_val.toString());
				cell_index_arr_txt_num.put(cell_val, first_row_col);
				cell_index_arr_num_txt.put(first_row_col,cell_val);
			}
			row1++;
			int is_internal_code_error=0;
			if(!cell_index_arr_txt_num.containsKey(("internal_code"))) 
			{
				is_internal_code_error=1;
				return_html=" <span class='upload_red'> Internal Code Field not present in excel file</>";
				wsheet.addMergedRegion(new CellRangeAddress(1, 1, 0, columnsCount));
				setXlsxCell(wsheet, 0, 1, "Internal Code Field not present in excel file", getCellFormat(wworkbook, IndexedColors.LEMON_CHIFFON, IndexedColors.BLACK, HorizontalAlignment.CENTER));
			}
			int is_error=0;
			String row_html="";
			SimpleDateFormat year_month_fmt = new SimpleDateFormat("yyyy-MM-dd");
			if(is_internal_code_error==0)
			{
				GetSUSerSchemaElementDetailsData(session);
				for (int row = 1;  row <rowsCount;  row++) 
				{	
					col1=columnsCount;
					 is_error=0;
					 row_html="";
					String internal_code=getXlsxCellString(sheet, cell_index_arr_txt_num.get("internal_code"), row).trim();
					//db_field_values_arr.put("internal_code", internal_code);
					int i=1;
					for(String element_name : cell_index_arr_txt_num.keySet()) 
					{
						Integer cell_indx= cell_index_arr_txt_num.get(element_name);
						String cell_val = getXlsxCellString(sheet, cell_indx, row).trim();
						Map<String, String> elements_list= new LinkedHashMap<String, String>();
						String final_cell_val=cell_val;
						if(full_element_details.containsKey(element_name))
						{
							elements_list=full_element_details.get(element_name);
							String system_name=elements_list.get("system_name").toString();
							String Type=elements_list.get("Type").toString();
							String optional=elements_list.get("optional").toString();
							String ref_module_code=elements_list.get("ref_module_code").toString();
							String ref_module_table_name=elements_list.get("ref_module_table_name").toString();
							final_cell_val=cell_val;
							db_field_values_arr_err.put(system_name, cell_val);
							if(optional.equals("0") && cell_val.isEmpty())
							{
								is_error=1;
								row_html+="<span  class='upload_orange'>"+element_name+" is Mandatory </span></br>";  
								setXlsxCell(wsheet, col1++, row1, element_name+" is Mandatory".toString() , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
							}
							if(Type.equals("Date") && !cell_val.isEmpty())
							{
								try
								{
									Cell cell1 = getXlsxCell(sheet, cell_indx, row);
									//									logger.info("cell1 style : "+cell1.getCellStyle());
									//									logger.info("cell1.getType : "+cell1.getType());
									//									logger.info("cell1.getCellFeatures : "+cell1.getCellFeatures());
									//									logger.info("cell1.getContents : "+cell1.getContents());
									//									logger.info("cell1.toString().trim() : "+cell1.toString().trim());
									//									 
									if (cell1 != null && DateUtil.isCellDateFormatted(cell1)) {
										final_cell_val = year_month_fmt.format(cell1.getDateCellValue());
									} else {
										final_cell_val = getXlsxCellString(cell1);
									}
									db_field_values_arr.put(system_name, final_cell_val);
								}
								catch(Exception e)
								{
									is_error=1; 
									setXlsxCell(wsheet, col1++, row1, "Date exception - Cause: "+e.getCause()+" Msg: "+e.getMessage()+ "Date Format should be ex:1-Apr-2016 " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
								}
							}
							else if(Type.equals("Reference Data") )
							{
								final_cell_val="0";
								//logger.info("ref_module_list_final.get(ref_module_table_name)"+ref_module_list_final.get(ref_module_table_name));
								if(!cell_val.isEmpty())
								{
									if(ref_module_list_final.containsKey(ref_module_table_name))
									{
										String check_cell_val=cell_val.toLowerCase();
										if(ref_module_list_final.get(ref_module_table_name).containsKey(check_cell_val))
										{
											final_cell_val=ref_module_list_final.get(ref_module_table_name).get(check_cell_val);
										}
										else
										{
											is_error=1;
											row_html+="<span  class='upload_orange'>"+element_name+"--"+cell_val+" is not found in "+ref_module_table_name+" </span></br>";
											setXlsxCell(wsheet, col1++, row1, element_name+": "+cell_val+" is not found in "+ref_module_table_name.toString() , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
										}
									}
								}
								db_field_values_arr.put(system_name, final_cell_val);
							}
							else if(Type.equals("Number") )
							{
								if(!cell_val.isEmpty())
								{
									try
									{
										Double.parseDouble(final_cell_val); 
										//final_cell_val=ref_module_list_final.get(ref_module_table_name).get(cell_val.trim());
										db_field_values_arr.put(system_name, final_cell_val);
									}
									catch(NumberFormatException n)
									{
										is_error=1;
										setXlsxCell(wsheet, col1++, row1, n.getMessage()+"-"+n.getCause() , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
									}
								}
							}
							else
							{
								db_field_values_arr.put(system_name, final_cell_val);
							}
						}
						i++;
					}//end of column loop 
					if(system_module_table_name.equals("tk_customer_master"))
					{
						String code=db_field_values_arr_err.get("code");
						String name=db_field_values_arr_err.get("name");
						String address1=db_field_values_arr_err.get("address1");
						String address2=db_field_values_arr_err.get("address2");
						String city=db_field_values_arr_err.get("city");
						String state=db_field_values_arr_err.get("state");
						String s_sate=state.split("-")[0];
						int count=ValidateCompanyCode(session,code);
						if(count==0)
						{
							return_html+=" Customer Code is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Customer code: "+code+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " Customer code:"+code+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
						int name_count=ValidateCustomerName(session,code,name);
						if(name_count==0)
						{
							return_html+=" Customer Name Not Matching For customer : "+code+"";
							is_error=1;
							row_html+="<span  class='upload_orange'>Customer Name Not Matching For customer : "+code+" </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " Customer Name Not Matching For customer : "+code+" " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
						int state_count=ValidateStateInCuStomerMaster(session,code,s_sate);
						if(state_count==0)
						{
							return_html+=" Customer State Not Matching For customer : "+code+"";
							is_error=1;
							row_html+="<span  class='upload_orange'>Customer State Not Matching For customer : "+code+" </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " Customer State Not Matching For customer : "+code+" " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
					}
					if(system_module_table_name.equals("tk_btl_customer"))
					{
						String code=db_field_values_arr_err.get("code");
						String name=db_field_values_arr_err.get("name");
						int count=ValidateCompanyCode(session,code);
						if(count==0)
						{
							return_html+=" Customer Code is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Customer code: "+code+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " Customer code:"+code+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
						int name_count=ValidateCustomerName(session,code,name);
						if(name_count==0)
						{
							return_html+=" Customer Name Not Matching For customer : "+code+"";
							is_error=1;
							row_html+="<span  class='upload_orange'>Customer Name Not Matching For customer : "+code+" </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " Customer Name Not Matching For customer : "+code+" " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
					}
					if(system_module_table_name.equals("tk_converter_master"))
					{
						String vendor_code=db_field_values_arr_err.get("vendor_code");
						String converters=db_field_values_arr_err.get("converters");
						String pan_no=db_field_values_arr_err.get("pan_no");
						String state=db_field_values_arr_err.get("state");
						int count=ValidateVendorCode(session,vendor_code);
						if(count==0)
						{
							return_html+=" Vendor Code is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Vendor code: "+vendor_code+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, "Vendor code:"+vendor_code+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
						int pan_count=ValidatePanForVendor(session,vendor_code,pan_no);
						if(pan_count==0)
						{
							return_html+=" PAN  Not Matching For Vendor : "+vendor_code+"";
							is_error=1;
							row_html+="<span  class='upload_orange'>PAN  Not Matching For Vendor : "+vendor_code+" </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " PAN  Not Matching For Vendor : "+vendor_code+" " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
					}
					if(system_module_table_name.equals("tk_branch_master"))
					{
						String stl_code=db_field_values_arr_err.get("stl_code");
						String btl_customer=db_field_values_arr_err.get("btl_customer");
						String Ship_to_code=stl_code.split("-")[0];
						String bill_to_code=btl_customer.split("-")[0];
						System.out.println(" stl_code............."+Ship_to_code);
						System.out.println(" btl_customer............."+bill_to_code);
						int count=ValidateShipToCustomer(session,bill_to_code,Ship_to_code);
						if(count==0)
						{
							return_html+=" Ship To code is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Ship To code: "+stl_code+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " Ship To codee:"+stl_code+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
					}
					if(system_module_table_name.equals("tk_item_master"))
					{
						String code=db_field_values_arr_err.get("item_code");
						String type=db_field_values_arr_err.get("type");
						String item_type=db_field_values_arr_err.get("item_type");
						String invoice_type=db_field_values_arr_err.get("invoice_type");
						String splitted_code=code.substring(0,2);
						System.out.println("splitted_code.........."+splitted_code);
						String val_type="";
						String val_item_type="";
						String val_invoice_type="";
						if(splitted_code.equals("IF"))
						{
							val_type="Raw Material";
							val_item_type="Inventory";
							val_invoice_type=splitted_code;
						}
						else if(splitted_code.equals("IS"))
						{
							val_type="Finished Goods";
							val_item_type="Non Inventory";
							val_invoice_type=splitted_code;
						}
						else if(splitted_code.equals("SS"))
						{
							val_type="Service";
							val_item_type="Non Inventory";
							val_invoice_type=splitted_code;
						}
						if(!val_type.equals(type))
						{
							return_html+="Type is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Type: "+val_type+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, "Type: "+val_type+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
						if(!val_item_type.equals(item_type))
						{
							return_html+="Item Type is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Item Type: "+val_type+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, "Item Type: "+val_type+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
						if(!val_invoice_type.equals(invoice_type))
						{
							return_html+="Invoice Type is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Invoice Type: "+invoice_type+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, "Invoice Type: "+invoice_type+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
						int count=ValidateItemCode(session,code);
						if(count==0)
						{
							return_html+=" Item Code is Invalid";
							is_error=1;
							row_html+="<span  class='upload_orange'>Item code: "+code+" is Invalid </span></br>";  
							setXlsxCell(wsheet, col1++, row1, " Item code:"+code+" is Invalid " , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.CENTER));
						}
					}
					if(is_error==1)
					{
						String row_err="<span class='upload_red'> Error Found for Row No==>"+row +"</span></br>";
						return_html+="</br>"+row_err+row_html;
						wsheet.addMergedRegion(new CellRangeAddress(0, 0, columnsCount, --col1));
						setXlsxCell(wsheet, columnsCount, 0 , "Error found for the following records" , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.LEFT));
						col1=0;
						if(!db_field_values_arr_err.isEmpty())
						{
							setXlsxCell(wsheet, col1++, row1, internal_code.toString());
							for (Object key : db_field_values_arr_err.keySet())
							{
								String keyStr = (String)key; 
								String keyvalue = (db_field_values_arr_err.get(keyStr).toString());
								setXlsxCell(wsheet, col1++, row1, keyvalue.toString());
							} 
						}
						row1++;
					}
					else
					{
						String sql_err="";
						if(!db_field_values_arr.isEmpty())
							sql_err=FrameWorkInsertUpdateData(session,row,internal_code,db_field_values_arr);
						if(!sql_err.isEmpty())
						{
							setXlsxCell(wsheet, columnsCount, row1 , sql_err , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.LEFT)); 
							setXlsxCell(wsheet, columnsCount, 0 , "Error found for the following records" , getCellFormat(wworkbook, IndexedColors.YELLOW, IndexedColors.ORANGE, HorizontalAlignment.LEFT));
							col1=0;
							if(!db_field_values_arr.isEmpty())
							{
								setXlsxCell(wsheet, col1++, row1, internal_code.toString());
								for (Object key : db_field_values_arr.keySet())
								{
									String keyStr = (String)key; 
									String keyvalue = (db_field_values_arr_err.get(keyStr).toString());
									setXlsxCell(wsheet, col1++, row1, keyvalue.toString());
								}
							}
							row1++;
						}
					}
				}//end of row loop
				if(return_html.isEmpty())
				{
					err_status="_succcessfully_uploaded";
					wsheet.addMergedRegion(new CellRangeAddress(1, 1, 0, columnsCount));
					setXlsxCell(wsheet, 0, 1, "Successfully Uploaded", getCellFormat(wworkbook, IndexedColors.LIGHT_GREEN, IndexedColors.DARK_GREEN, HorizontalAlignment.CENTER));
				}
			}
			response.setHeader("Content-Disposition", "attachment; filename="+system_module_table_name+err_status+".xlsx");
			wworkbook.write(response.getOutputStream());
			wworkbook.close();
			//System.out.println(cell_index_arr);
		}
		catch (Exception  e) {
			e.printStackTrace();
		}	
	}
	private int ValidatePanForVendor(Session session, String vendor_code,
			String pan_no) {
		int roleCount=0;
		List<Map<String,Object>> query_data_obj= new ArrayList<Map<String,Object>>();
		try
		{
			String Sql = "select count(*) as roleCount  from VendorMasterX   "
					+ " where ltrim(VAVEND)='"+vendor_code+"' and  substring([VFUSR3],3,10)='"+pan_no+"' ";
			System.out.println("ValidateVendorCode Sql ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);  
				for (Map<String, Object> map : query_data_obj) 
				{
					roleCount=(int) map.get("roleCount");
				}
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
	return roleCount;
	}
	private int ValidateVendorCode(Session session, String vendor_code) {
		int roleCount=0;
		List<Map<String,Object>> query_data_obj= new ArrayList<Map<String,Object>>();
		try
		{
			String Sql = "select count(*) as roleCount  from VendorMasterX   "
					+ " where ltrim(VAVEND)='"+vendor_code+"'  ";
			System.out.println("ValidateVendorCode Sql ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);  
				for (Map<String, Object> map : query_data_obj) 
				{
					roleCount=(int) map.get("roleCount");
				}
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
	return roleCount;
	}
	private int ValidateStateInCuStomerMaster(Session session, String code,String state) 
	{
		int roleCount=0;
		List<Map<String,Object>> query_data_obj= new ArrayList<Map<String,Object>>();
		try
		{
			String Sql = "select count(*) as roleCount  from SO_CustomerMaster   "
					+ " where CSTE='"+state+"' and cast(CCUST as varchar)='"+code+"' ";
			System.out.println("ValidateItemCode Sql ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);  
				for (Map<String, Object> map : query_data_obj) 
				{
					roleCount=(int) map.get("roleCount");
				}
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
	return roleCount;
	}
	private int ValidateItemCode(Session session, String code) {
		int roleCount=0;
		List<Map<String,Object>> query_data_obj= new ArrayList<Map<String,Object>>();
		try
		{
			String Sql = "select count(*) as roleCount  from SO_ItemMaster   "
					+ " where IPROD='"+code+"' ";
			System.out.println("ValidateItemCode Sql ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);  
				for (Map<String, Object> map : query_data_obj) 
				{
					roleCount=(int) map.get("roleCount");
				}
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
	return roleCount;
	}
	private int ValidateShipToCustomer(Session session, String btl_customer,
String stl_code) {
		int roleCount=0;
		List<Map<String,Object>> query_data_obj= new ArrayList<Map<String,Object>>();
		try
		{
			String Sql = "select count(*) as roleCount  from tk_btl_customer tbl  "
					+ "inner join EST e on cast(e.TCUST as varchar)=tbl.code   "
					+ " where cast(TSHIP as varchar)='"+btl_customer+"' and tbl.code='"+btl_customer+"' ";
			System.out.println("ValidateShipToCustomer Sql ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);  
				for (Map<String, Object> map : query_data_obj) 
				{
					roleCount=(int) map.get("roleCount");
				}
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
	return roleCount;
	}
	private int ValidateCustomerName(Session session, String code, String name) {
		int roleCount=0;
		List<Map<String,Object>> query_data_obj= new ArrayList<Map<String,Object>>();
		try
		{
			String Sql = "select count(*) as roleCount from SO_CustomerMaster  "
					+ "where CCUST='"+code+"' and CNME like '%"+name+"%' ";
			System.out.println("ValidateCustomerName Sql ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);  
				for (Map<String, Object> map : query_data_obj) 
				{
					roleCount=(int) map.get("roleCount");
				}
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
	return roleCount;
	}
	private int ValidateCompanyCode(Session session, String code) 
	{
		int roleCount=0;
		List<Map<String,Object>> query_data_obj= new ArrayList<Map<String,Object>>();
		try
		{
			String Sql = "select count(*) as roleCount from SO_CustomerMaster  "
					+ "where CCUST='"+code+"' ";
			System.out.println("ValidateCompanyCode Sql ="+Sql);
			query_data_obj = NativeQuerySupport.executeQuery(session, Sql);  
				for (Map<String, Object> map : query_data_obj) 
				{
					roleCount=(int) map.get("roleCount");
				}
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) { }
		}
	return roleCount;
	}
	public String FrameWorkInsertUpdateData(Session session,int row_id,String internal_code,Map<String, String> db_field_values_arr)
	{
		String sql_err="";
		if(internal_code.isEmpty())
			internal_code="0";
		String insert_cols="";
		String  insert_col_values="";
		String update_cond=""; 
		logger.info("db_field_values_arr==>"+db_field_values_arr);
		for (Object key : db_field_values_arr.keySet()) {
			String keyStr = (String)key;
			String data_type=system_name_data_type_arr.get(keyStr).toString();
			logger.info("--"+db_field_values_arr.get(keyStr).toString());
			String keyvalue = (db_field_values_arr.get(keyStr).toString());
			keyvalue = keyvalue.replace("'","''");
			insert_cols+=keyStr+",";
			String cell_val="'"+keyvalue+"'";
			if(data_type.equals("Date") && keyvalue.isEmpty())
				cell_val="NULL"; 
			insert_col_values+=cell_val+",";		
			update_cond+=keyStr+"= "+cell_val+",";
		}
		insert_cols=insert_cols.substring(0,insert_cols.length()-1);
		insert_col_values=insert_col_values.substring(0,insert_col_values.length()-1);
		String final_qry="";
		String insert_qry="insert into "+system_module_table_name;
		insert_qry+="(   "+insert_cols+",created_by, ";
		insert_qry+="created_date,modified_by,modified_date)  values ";
		insert_qry+=" ("+insert_col_values+","+login_user_int_code+"," + UserSessionSupport.sessionDate() + ","+login_user_int_code+"," + UserSessionSupport.sessionDate() + ")";	
		final_qry=insert_qry;
		update_cond+=" modified_by="+login_user_int_code+", modified_date=" + UserSessionSupport.sessionDate() + " ";
		String update_qry=" update "+system_module_table_name+" set "+update_cond+" where internal_code="+internal_code;
		if(internal_code.equals("0"))
		{
			final_qry=insert_qry;
		}
		else
		{
			final_qry=update_qry;
		}
		logger.info("t_final_insert_update_qry------"+final_qry);
		try
		{
			Query query = session.createNativeQuery(final_qry);
			query.executeUpdate();
		}
		catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			return_html+=" <span class='upload_red'> Error while inserting/updating records for row id "+row_id+" </br>" +ex.getCause().toString()+"</span><br>";
			sql_err="Error while inserting/updating records "+ex.getCause().toString();
			if (cause instanceof SQLException) { }
		} 
		return sql_err;
	}
	public void GetSUSerSchemaElementDetailsData(Session session)
	{
		Map<String, String> ref_module_code_lists_int_code_arr = new LinkedHashMap<String, String>();
		try{
			String final_qry = "select  name,system_name,data_type as Type,";
			final_qry+=" isnull(optional,'0') as optional, ";
			final_qry+=" isnull(su.ref_module_code,0) as ref_module_code,isnull(ref.file_name,'') as ref_module_table_name ";
			final_qry+=" from ia_s_user_schema_elements su inner join ia_menu_options s ";
			final_qry+=" on s.internal_code=su.ref_s_user_schema_code ";
			final_qry+="  left join ia_menu_options ref on ref.internal_code=su.ref_module_code ";
			final_qry+=" where ref_s_user_schema_code="+module_id +"  and is_multiple_group=0  order by su.sequence";
			//logger.info("********* Elements final_qry--------"+final_qry);
			@SuppressWarnings("rawtypes")
			List<Map<String,Object>> query_data_obj = NativeQuerySupport.executeQuery(session, final_qry); 
				for (Map<String, Object> map : query_data_obj) {
					Map<String, String> elements_list= new LinkedHashMap<String, String>();
					String name=map.get("name").toString();
					String system_name=map.get("system_name").toString();
					String Type=map.get("Type").toString();
					String optional=map.get("optional").toString();
					String ref_module_code=map.get("ref_module_code").toString();
					String ref_module_table_name=map.get("ref_module_table_name").toString();
					elements_list.put("system_name", system_name);
					elements_list.put("Type", Type);
					elements_list.put("optional", optional);
					elements_list.put("ref_module_code", ref_module_code);
					elements_list.put("ref_module_table_name", ref_module_table_name);
					system_name_data_type_arr.put(system_name,Type);
					full_element_details.put(name, (LinkedHashMap<String, String>) elements_list);
					if(!ref_module_table_name.isEmpty())
					{
						ref_module_code_lists_int_code_arr.put(ref_module_code, ref_module_table_name);
					}
				}
		}catch (PersistenceException ex) {
			Throwable cause = ex.getCause();
			if (cause instanceof SQLException) {
				ex.printStackTrace();
			}
		}
		if(ref_module_code_lists_int_code_arr.size()>0)
		{
			System.out.println("coming to llopp");
			GetRefModuleDataSet(session,ref_module_code_lists_int_code_arr);
		}
		//logger.info("full_element_details="+full_element_details);
		//logger.info("full_element_details="+full_element_details);
		// logger.info("ref_module_code_lists_int_code_arr="+ref_module_code_lists_int_code_arr);
	}
	public void GetRefModuleDataSet(Session session,Map<String, String> ref_module_code_lists_int_code_arr)
	{
		AutoComplete ao_obj=new AutoComplete(sessionFactory);
		for(String module_code : ref_module_code_lists_int_code_arr.keySet()) {
			String poup_module_name = ref_module_code_lists_int_code_arr.get(module_code);
			JSONObject meta_col_obj = new JSONObject();
			meta_col_obj=ao_obj.GetModuleMetaColumnsData(session,poup_module_name);
			if(meta_col_obj==null) continue;
			String field_id=Format.GetObjectValueFromMap(meta_col_obj.get("field_id"));
			String field_id1=Format.GetObjectValueFromMap(meta_col_obj.get("field_id1"));
			String field_id2=Format.GetObjectValueFromMap(meta_col_obj.get("field_id2"));
			if(field_id.isEmpty()) continue;
			String extra_columns=" '' as field_id1,'' as field_id2 ";
			if(!field_id2.isEmpty())
			{
				extra_columns=field_id1+" as field_id1,"+field_id2+" as field_id2 ";
			}
			try{
				String f_query="select internal_code, "+field_id+" as field_id, "+extra_columns +" from "+poup_module_name ;	
				logger.info("f_query=="+f_query);
				@SuppressWarnings("rawtypes")
				List<Map<String,Object>> query_data_obj = NativeQuerySupport.executeQuery(session, f_query); 
					Map<String, String> local_ref_module_data_set = new LinkedHashMap<String, String>();
					if(query_data_obj!=null) {
					for (Map<String, Object> map : query_data_obj) {
						String internal_code=Format.GetObjectValueFromMap(map.get("internal_code"));
						String qfield_id1=Format.GetObjectValueFromMap(map.get("field_id1")).toLowerCase();
						String qfield_id2=Format.GetObjectValueFromMap(map.get("field_id2")).toLowerCase();
						String qfield_id=Format.GetObjectValueFromMap(map.get("field_id")).toLowerCase();
						local_ref_module_data_set.put(qfield_id,internal_code);
						if(!qfield_id1.isEmpty())
							local_ref_module_data_set.put(qfield_id1,internal_code);
						if(!qfield_id2.isEmpty())
							local_ref_module_data_set.put(qfield_id2,internal_code);
					}
					}
				ref_module_list_final.put(poup_module_name,(LinkedHashMap<String, String>) local_ref_module_data_set);
				// logger.info("ref_module_list_final=="+ref_module_list_final);
			}catch (PersistenceException ex) {
				Throwable cause = ex.getCause();
				if (cause instanceof SQLException) {
					ex.printStackTrace();
				}
			}
		}
	}
	public static CellStyle getCellFormat(Workbook wb, IndexedColors bg, IndexedColors fontColor, HorizontalAlignment align)
	{
		CellStyle cellFormat = wb.createCellStyle();
		Font cellFont = wb.createFont();
		cellFont.setBold(true);
		cellFont.setColor(fontColor.getIndex());
		cellFormat.setFont(cellFont);
		cellFormat.setFillForegroundColor(bg.getIndex());
		cellFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		cellFormat.setAlignment(align);
		cellFormat.setBorderTop(BorderStyle.THIN);
		cellFormat.setBorderBottom(BorderStyle.THIN);
		cellFormat.setBorderLeft(BorderStyle.THIN);
		cellFormat.setBorderRight(BorderStyle.THIN);
		return cellFormat;
	}

	private static final DataFormatter XLSX_FMT = new DataFormatter();

	private static Row getOrCreateRow(Sheet sheet, int rowIdx) {
		Row r = sheet.getRow(rowIdx);
		if (r == null) r = sheet.createRow(rowIdx);
		return r;
	}

	private static void setXlsxCell(Sheet sheet, int col, int row, Object value) {
		setXlsxCell(sheet, col, row, value, null);
	}

	private static void setXlsxCell(Sheet sheet, int col, int row, Object value, CellStyle style) {
		Row r = getOrCreateRow(sheet, row);
		Cell c = r.getCell(col);
		if (c == null) c = r.createCell(col);
		c.setCellValue(value == null ? "" : String.valueOf(value));
		if (style != null) c.setCellStyle(style);
	}

	private static Cell getXlsxCell(Sheet sheet, int col, int row) {
		Row r = sheet.getRow(row);
		if (r == null) return null;
		return r.getCell(col);
	}

	private static String getXlsxCellString(Sheet sheet, int col, int row) {
		return getXlsxCellString(getXlsxCell(sheet, col, row));
	}

	private static String getXlsxCellString(Cell cell) {
		if (cell == null) return "";
		return XLSX_FMT.formatCellValue(cell).trim();
	}
}
