package com.mmm.system;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import jakarta.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;

/**
 * Role rights Excel download — ported from insba RoleRightsUploadDownload,
 * jxl replaced with Apache POI XSSF (.xlsx).
 */
@RestController
@RequestMapping("titpl/role_rights_upload_dowload")
public class RoleRightsUploadDownload {

	private static final Logger logger = LogManager.getLogger(RoleRightsUploadDownload.class);
	private static final int MAX_UPLOAD_ROWS = 5000;

	private final SessionFactory sessionFactory;
	private final Gson gson = new Gson();

	public RoleRightsUploadDownload(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@GetMapping("userRoleRightsDownlaod")
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public void userRoleRightsDownlaod(HttpServletResponse response) throws IOException {
		Session session = session();
		List<Map<String, Object>> role_rights_data_set = getRoleRightsDataSet(session);
		List<Map<String, Object>> user_master_data_set = getUserMasterDataSet(session);

		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=user_master_role.xlsx");

		Workbook wworkbook = new XSSFWorkbook();
		Sheet sh_role_module = wworkbook.createSheet("Role Modules");
		Sheet sh_user_master = wworkbook.createSheet("User Master");
		CellStyle headerStyle = headerStyle(wworkbook);

		int col = 0;
		sh_role_module.setColumnWidth(col, 13 * 256);
		setCell(sh_role_module, col++, 0, "Application", headerStyle);
		sh_role_module.setColumnWidth(col, 38 * 256);
		setCell(sh_role_module, col++, 0, "Display Name", headerStyle);
		sh_role_module.setColumnWidth(col, 12 * 256);
		setCell(sh_role_module, col++, 0, "Role Name", headerStyle);

		col = 0;
		sh_user_master.setColumnWidth(col, 10 * 256);
		setCell(sh_user_master, col++, 0, "Enl ID", headerStyle);
		sh_user_master.setColumnWidth(col, 15 * 256);
		setCell(sh_user_master, col++, 0, "Name", headerStyle);
		sh_user_master.setColumnWidth(col, 12 * 256);
		setCell(sh_user_master, col++, 0, "Role Name", headerStyle);
		sh_user_master.setColumnWidth(col, 12 * 256);
		setCell(sh_user_master, col, 0, "Action", headerStyle);

		if (role_rights_data_set != null) {
			int row = 1;
			for (Map<String, Object> map : role_rights_data_set) {
				col = 0;
				setCell(sh_role_module, col++, row, str(map, "app_type"));
				setCell(sh_role_module, col++, row, str(map, "display_name"));
				setCell(sh_role_module, col++, row, str(map, "role_name"));
				row++;
			}
		}

		if (user_master_data_set != null) {
			int row = 1;
			for (Map<String, Object> map : user_master_data_set) {
				col = 0;
				setCell(sh_user_master, col++, row, str(map, "enl_id"));
				setCell(sh_user_master, col++, row, str(map, "name"));
				setCell(sh_user_master, col++, row, str(map, "role_name"));
				setCell(sh_user_master, col, row, "");
				row++;
			}
		}

		wworkbook.write(response.getOutputStream());
		wworkbook.close();
	}

	@GetMapping("downloadUserRoleUploadFormat")
	public void downloadUserRoleUploadFormat(HttpServletResponse response) throws IOException {
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=user_role_upload_format.xlsx");

		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("User Role Upload");
			CellStyle headerStyle = headerStyle(workbook);
			sheet.setColumnWidth(0, 22 * 256);
			sheet.setColumnWidth(1, 30 * 256);
			sheet.setColumnWidth(2, 14 * 256);
			setCell(sheet, 0, 0, "ENL ID", headerStyle);
			setCell(sheet, 1, 0, "Role Name", headerStyle);
			setCell(sheet, 2, 0, "Action", headerStyle);
			setCell(sheet, 0, 1, "YOUR_ENL_ID");
			setCell(sheet, 1, 1, "YOUR_ROLE_NAME");
			setCell(sheet, 2, 1, "I");
			workbook.write(response.getOutputStream());
		}
	}

	@RequestMapping(value = "downloadExistingUserRoles", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public void downloadExistingUserRoles(
			@RequestParam(value = "enl_ids", required = false, defaultValue = "") String enlIds,
			@RequestParam(value = "role_code", required = false, defaultValue = "") String roleCode,
			HttpServletResponse response) throws IOException {
		List<String> selectedEnlIds = parseEnlIds(enlIds);
		boolean filterByUsers = enlIds != null && !enlIds.isBlank();
		boolean filterByRole = roleCode != null && !roleCode.isBlank();
		if (selectedEnlIds.size() > 500) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Select no more than 500 users per download.");
			return;
		}
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		String filename = !filterByUsers && !filterByRole
				? "existing_user_roles.xlsx"
				: "existing_user_roles_filtered.xlsx";
		response.setHeader("Content-Disposition", "attachment; filename=" + filename);

		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("User Role Upload");
			CellStyle headerStyle = headerStyle(workbook);
			sheet.setColumnWidth(0, 22 * 256);
			sheet.setColumnWidth(1, 18 * 256);
			sheet.setColumnWidth(2, 30 * 256);
			sheet.setColumnWidth(3, 30 * 256);
			sheet.setColumnWidth(4, 30 * 256);
			sheet.setColumnWidth(5, 22 * 256);
			sheet.setColumnWidth(6, 14 * 256);
			sheet.setColumnWidth(7, 14 * 256);
			setCell(sheet, 0, 0, "ENL ID", headerStyle);
			setCell(sheet, 1, 0, "cust_code", headerStyle);
			setCell(sheet, 2, 0, "Customer Name", headerStyle);
			setCell(sheet, 3, 0, "Name", headerStyle);
			setCell(sheet, 4, 0, "Role Name", headerStyle);
			setCell(sheet, 5, 0, "Last Login Time", headerStyle);
			setCell(sheet, 6, 0, "Status", headerStyle);
			setCell(sheet, 7, 0, "Action", headerStyle);

			int row = 1;
			List<Map<String, Object>> mappings = filterByUsers && selectedEnlIds.isEmpty()
					? List.of()
					: getUserRoleAssignments(session(), selectedEnlIds, filterByUsers, roleCode);
			for (Map<String, Object> mapping : mappings) {
				setCell(sheet, 0, row, str(mapping, "enl_id"));
				setCell(sheet, 1, row, str(mapping, "cust_code"));
				setCell(sheet, 2, row, str(mapping, "cust_name"));
				setCell(sheet, 3, row, str(mapping, "name"));
				setCell(sheet, 4, row, str(mapping, "role_name"));
				setCell(sheet, 5, row, str(mapping, "last_login_time"));
				setCell(sheet, 6, row, str(mapping, "status"));
				setCell(sheet, 7, row, "");
				row++;
			}
			workbook.write(response.getOutputStream());
		}
	}

	@GetMapping("getUserRoleAssignments")
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String getUserRoleAssignments(
			@RequestParam(value = "role_code", required = false, defaultValue = "") String roleCode,
			@RequestParam(value = "enl_ids", required = false, defaultValue = "") String enlIds) {
		List<String> selectedEnlIds = parseEnlIds(enlIds);
		boolean filterByUsers = enlIds != null && !enlIds.isBlank();
		Map<String, Object> result = new HashMap<>();
		if (selectedEnlIds.size() > 500) {
			result.put("success", false);
			result.put("message", "Select no more than 500 users.");
			result.put("data", List.of());
		} else if ((roleCode == null || roleCode.isBlank()) && !filterByUsers) {
			result.put("success", true);
			result.put("data", List.of());
		} else {
			List<Map<String, Object>> assignments = filterByUsers && selectedEnlIds.isEmpty()
					? List.of()
					: getUserRoleAssignments(session(), selectedEnlIds, filterByUsers, roleCode);
			result.put("success", true);
			result.put("data", assignments);
		}
		return gson.toJson(result);
	}

	private static List<String> parseEnlIds(String enlIds) {
		if (enlIds == null || enlIds.isBlank()) return List.of();
		Set<String> uniqueIds = new LinkedHashSet<>();
		for (String value : enlIds.split(",")) {
			String enlId = value.trim();
			if (!enlId.isEmpty()) uniqueIds.add(enlId);
		}
		return new ArrayList<>(uniqueIds);
	}

	private List<Map<String, Object>> getUserMasterDataSet(Session session, List<String> enlIds) {
		String sql = "select um.enl_id as enl_id, um.name as name, r.role_name as role_name "
				+ "from ia_user_master_roles_group umrg "
				+ "inner join ia_user_master um on umrg.ref_s_ref_data_code=um.internal_code "
				+ "inner join ia_roles r on umrg.ref_role_code=r.internal_code "
				+ "where um.enl_id in (";
		Map<String, Object> params = new HashMap<>();
		List<String> placeholders = new ArrayList<>();
		for (int i = 0; i < enlIds.size(); i++) {
			String key = "enlId" + i;
			placeholders.add(":" + key);
			params.put(key, enlIds.get(i));
		}
		sql += String.join(",", placeholders) + ") order by um.enl_id, r.role_name";
		return NativeQuerySupport.listAsMaps(session, sql, params,
				NativeQuerySupport.stringScalars("enl_id", "name", "role_name"));
	}

	private List<Map<String, Object>> getUserRoleAssignments(
			Session session, List<String> enlIds, boolean filterByUsers, String roleCode) {
		StringBuilder sql = new StringBuilder(
				"select um.enl_id as enl_id, isnull(um.cust_code,'') as cust_code, "
						+ "isnull(um.cust_name,'') as cust_name, um.name as name, r.role_name as role_name, "
						+ "isnull(convert(varchar(19), um.last_login_date, 120),'') as last_login_time, "
						+ "isnull(um.active,'Yes') as status "
						+ "from ia_user_master_roles_group umrg "
						+ "inner join ia_user_master um on umrg.ref_s_ref_data_code=um.internal_code "
						+ "inner join ia_roles r on umrg.ref_role_code=r.internal_code where 1=1 ");
		Map<String, Object> params = new HashMap<>();
		if (filterByUsers) {
			List<String> placeholders = new ArrayList<>();
			for (int i = 0; i < enlIds.size(); i++) {
				String key = "enlId" + i;
				placeholders.add(":" + key);
				params.put(key, enlIds.get(i));
			}
			sql.append("and um.enl_id in (").append(String.join(",", placeholders)).append(") ");
		}
		if (roleCode != null && !roleCode.isBlank()) {
			sql.append("and cast(r.internal_code as varchar(50)) = :roleCode ");
			params.put("roleCode", roleCode.trim());
		}
		sql.append("order by um.enl_id, r.role_name");
		return NativeQuerySupport.listAsMaps(session, sql.toString(), params,
				NativeQuerySupport.stringScalars(
						"enl_id", "cust_code", "cust_name", "name", "role_name", "last_login_time", "status"));
	}

	@PostMapping("uploadUserRoles")
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String previewUserRoles(@RequestParam("file") MultipartFile file) {
		UploadPreview preview = readAndValidateUpload(file);
		return gson.toJson(preview.response());
	}

	@PostMapping("applyUserRoles")
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String applyUserRoles(@RequestParam("file") MultipartFile file) {
		UploadPreview preview = readAndValidateUpload(file);
		if (!preview.errors.isEmpty()) {
			return gson.toJson(preview.response());
		}

		int added = 0;
		int deleted = 0;
		int unchanged = 0;
		Session session = session();
		for (UploadRow row : preview.rows) {
			String key = row.userCode + ":" + row.roleCode;
			boolean exists = preview.existingAssignments.contains(key);
			if ("D".equals(row.action)) {
				if (exists) {
					session.createNativeQuery("delete from ia_user_master_roles_group "
							+ "where ref_s_ref_data_code = :userCode and ref_role_code = :roleCode")
							.setParameter("userCode", row.userCode)
							.setParameter("roleCode", row.roleCode)
							.executeUpdate();
					deleted++;
				} else {
					unchanged++;
				}
			} else if (!exists) {
				session.createNativeQuery("insert into ia_user_master_roles_group "
						+ "(ref_s_ref_data_code, ref_role_code) values (:userCode, :roleCode)")
						.setParameter("userCode", row.userCode)
						.setParameter("roleCode", row.roleCode)
						.executeUpdate();
				added++;
			} else {
				unchanged++;
			}
		}

		Map<String, Object> result = new HashMap<>();
		result.put("success", true);
		result.put("message", "User-role upload applied successfully.");
		result.put("added", added);
		result.put("deleted", deleted);
		result.put("unchanged", unchanged);
		return gson.toJson(result);
	}

	private UploadPreview readAndValidateUpload(MultipartFile file) {
		UploadPreview preview = new UploadPreview();
		if (file == null || file.isEmpty()) {
			preview.errors.add("Select a non-empty Excel workbook.");
			return preview;
		}

		try (InputStream input = file.getInputStream(); Workbook workbook = WorkbookFactory.create(input)) {
			Sheet sheet = workbook.getSheet("User Master");
			if (sheet == null) {
				sheet = workbook.getSheet("User Role Upload");
			}
			if (sheet == null && workbook.getNumberOfSheets() > 0) {
				sheet = workbook.getSheetAt(0);
			}
			if (sheet == null || sheet.getPhysicalNumberOfRows() == 0) {
				preview.errors.add("The workbook does not contain a worksheet with user-role rows.");
				return preview;
			}

			DataFormatter formatter = new DataFormatter();
			Map<String, Integer> headers = new HashMap<>();
			Row header = sheet.getRow(sheet.getFirstRowNum());
			if (header != null) {
				for (Cell cell : header) {
					headers.put(normalizeHeader(formatter.formatCellValue(cell)), cell.getColumnIndex());
				}
			}
			Integer userCol = headers.get("enl id");
			Integer roleCol = headers.get("role name");
			Integer actionCol = headers.get("action");
			if (userCol == null || roleCol == null || actionCol == null) {
				preview.errors.add("Required columns are ENL ID, Role Name, and Action. Download the current User Role Details workbook for the correct format.");
				return preview;
			}

			Map<String, String> users = new HashMap<>();
			Map<String, String> roles = new HashMap<>();
			for (Map<String, Object> map : NativeQuerySupport.executeQuery(session(),
					"select internal_code, enl_id from ia_user_master where enl_id is not null")) {
				String enlId = str(map, "enl_id").trim().toUpperCase(Locale.ROOT);
				if (!enlId.isEmpty()) users.put(enlId, str(map, "internal_code"));
			}
			for (Map<String, Object> map : NativeQuerySupport.executeQuery(session(),
					"select internal_code, role_name from ia_roles where role_name is not null")) {
				String roleName = str(map, "role_name").trim().toUpperCase(Locale.ROOT);
				if (!roleName.isEmpty()) roles.put(roleName, str(map, "internal_code"));
			}
			for (Map<String, Object> map : NativeQuerySupport.executeQuery(session(),
					"select ref_s_ref_data_code, ref_role_code from ia_user_master_roles_group")) {
				preview.existingAssignments.add(str(map, "ref_s_ref_data_code") + ":"
						+ str(map, "ref_role_code"));
			}

			Set<String> seenAssignments = new HashSet<>();
			int dataRows = 0;
			for (int index = sheet.getFirstRowNum() + 1; index <= sheet.getLastRowNum(); index++) {
				Row excelRow = sheet.getRow(index);
				if (excelRow == null) continue;
				String enlId = cellValue(formatter, excelRow, userCol).trim();
				String roleName = cellValue(formatter, excelRow, roleCol).trim();
				String action = cellValue(formatter, excelRow, actionCol).trim().toUpperCase(Locale.ROOT);
				if (enlId.isEmpty() && roleName.isEmpty() && action.isEmpty()) continue;
				dataRows++;
				if (dataRows > MAX_UPLOAD_ROWS) {
					preview.errors.add("The workbook exceeds the maximum of " + MAX_UPLOAD_ROWS + " assignment rows.");
					break;
				}

				UploadRow parsed = new UploadRow(index + 1, enlId, roleName, action.isEmpty() ? "I" : action);
				if (enlId.isEmpty()) parsed.errors.add("ENL ID is required.");
				if (roleName.isEmpty()) parsed.errors.add("Role Name is required.");
				if (!"I".equals(parsed.action) && !"D".equals(parsed.action)) {
					parsed.errors.add("Action must be blank, I, or D.");
				}

				String userKey = enlId.toUpperCase(Locale.ROOT);
				String roleKey = roleName.toUpperCase(Locale.ROOT);
				parsed.userCode = users.get(userKey);
				parsed.roleCode = roles.get(roleKey);
				if (!enlId.isEmpty() && parsed.userCode == null) parsed.errors.add("ENL ID was not found.");
				if (!roleName.isEmpty() && parsed.roleCode == null) parsed.errors.add("Role Name was not found.");
				if (parsed.userCode != null && parsed.roleCode != null) {
					String assignmentKey = parsed.userCode + ":" + parsed.roleCode;
					if (!seenAssignments.add(assignmentKey)) {
						parsed.errors.add("Duplicate user-role assignment in this workbook.");
					}
					boolean exists = preview.existingAssignments.contains(assignmentKey);
					parsed.operation = "D".equals(parsed.action)
							? (exists ? "Remove mapping" : "No change (not assigned)")
							: (exists ? "No change (already assigned)" : "Add mapping");
				}
				if (!parsed.errors.isEmpty()) {
					preview.errors.add("Row " + parsed.rowNumber + ": " + String.join(" ", parsed.errors));
				}
				preview.rows.add(parsed);
			}
			if (dataRows == 0) preview.errors.add("No user-role assignment rows were found.");
		} catch (IOException | EncryptedDocumentException | IllegalArgumentException ex) {
			logger.warn("Unable to read user-role Excel upload", ex);
			preview.errors.add("Could not read the Excel workbook. Upload a valid .xlsx file.");
		}
		return preview;
	}

	private static String normalizeHeader(String value) {
		return value == null ? "" : value.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
	}

	private static String cellValue(DataFormatter formatter, Row row, int column) {
		Cell cell = row.getCell(column, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
		return cell == null ? "" : formatter.formatCellValue(cell);
	}

	private static class UploadPreview {
		private final List<UploadRow> rows = new ArrayList<>();
		private final List<String> errors = new ArrayList<>();
		private final Set<String> existingAssignments = new HashSet<>();

		private Map<String, Object> response() {
			Map<String, Object> result = new HashMap<>();
			result.put("success", errors.isEmpty());
			result.put("rows", rows);
			result.put("errors", errors);
			return result;
		}
	}

	private static class UploadRow {
		private final int rowNumber;
		private final String enlId;
		private final String roleName;
		private final String action;
		private String userCode;
		private String roleCode;
		private String operation = "";
		private final List<String> errors = new ArrayList<>();

		private UploadRow(int rowNumber, String enlId, String roleName, String action) {
			this.rowNumber = rowNumber;
			this.enlId = enlId;
			this.roleName = roleName;
			this.action = action;
		}
	}

	private List<Map<String, Object>> getUserMasterDataSet(Session session) {
		String Sql = "select um.enl_id as enl_id, um.name as name, r.role_name as role_name "
				+ "from ia_user_master_roles_group umrg "
				+ "inner join ia_user_master um "
				+ "on umrg.ref_s_ref_data_code=um.internal_code "
				+ "inner join ia_roles r "
				+ "on umrg.ref_role_code=r.internal_code  "
				+ "order by role_name ";
		logger.info("getUserMasterDataSet Sql={}", Sql);
		return NativeQuerySupport.executeQuery(session, Sql);
	}

	private List<Map<String, Object>> getRoleRightsDataSet(Session session) {
		String Sql = "select r.role_name as role_name , mg.app_type as app_type, mo.display_name as display_name  "
				+ "from ia_role_rights rr "
				+ "inner join ia_roles r "
				+ "on rr.ref_role_code=r.internal_code "
				+ "inner join ia_menu_options mo "
				+ "on rr.ref_menu_code=mo.internal_code "
				+ "inner join ia_menu_groups mg "
				+ "on mo.ref_menu_group_code=mg.internal_code "
				+ "order by role_name,app_type, display_name ";
		logger.info("getRoleRightsDataSet Sql={}", Sql);
		return NativeQuerySupport.executeQuery(session, Sql);
	}

	private static String str(Map<String, Object> map, String key) {
		Object v = map.get(key);
		if (v == null) {
			for (Map.Entry<String, Object> e : map.entrySet()) {
				if (e.getKey() != null && e.getKey().equalsIgnoreCase(key)) {
					v = e.getValue();
					break;
				}
			}
		}
		return v == null ? "" : String.valueOf(v);
	}

	private static CellStyle headerStyle(Workbook wb) {
		CellStyle style = wb.createCellStyle();
		Font font = wb.createFont();
		font.setBold(true);
		font.setColor(IndexedColors.WHITE.getIndex());
		style.setFont(font);
		style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		style.setAlignment(HorizontalAlignment.LEFT);
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		return style;
	}

	private static void setCell(Sheet sheet, int col, int row, Object value) {
		setCell(sheet, col, row, value, null);
	}

	private static void setCell(Sheet sheet, int col, int row, Object value, CellStyle style) {
		Row r = sheet.getRow(row);
		if (r == null) r = sheet.createRow(row);
		Cell c = r.getCell(col);
		if (c == null) c = r.createCell(col);
		c.setCellValue(value == null ? "" : String.valueOf(value));
		if (style != null) c.setCellStyle(style);
	}
}
