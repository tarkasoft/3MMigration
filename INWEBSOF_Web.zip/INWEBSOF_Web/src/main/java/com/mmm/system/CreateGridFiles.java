package com.mmm.system;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;

/**
 * Generates jqGrid JS files under grid_display_files/INPC for modules with
 * generate_grid='Yes'. One mapping; no separate service class.
 *
 * Call: GET/POST titpl/system/createGridFiles
 */
@RestController
@RequestMapping("titpl/system")
public class CreateGridFiles {

	private static final Logger logger = LogManager.getLogger(CreateGridFiles.class);
	private static final String DEFAULT_GRID_HEIGHT = "250";

	private static final String GRID_RELATIVE = "src/main/resources/static/grid_display_files/INPC";

	private final SessionFactory sessionFactory;
	private final String projectBasePath;
	private final String projectDeployPath;
	private final Gson gson = new Gson();

	public CreateGridFiles(
			@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory,
			@Value("${inpc.project.base-path:}") String projectBasePath,
			@Value("${inpc.project.deploy-path:}") String projectDeployPath) {
		this.sessionFactory = sessionFactory;
		this.projectBasePath = projectBasePath == null ? "" : projectBasePath.trim();
		this.projectDeployPath = projectDeployPath == null ? "" : projectDeployPath.trim();
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@RequestMapping(value = "createGridFiles", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String createGridFiles(HttpServletRequest request) {
		Map<String, Object> result = new LinkedHashMap<>();
		List<Map<String, Object>> created = new ArrayList<>();
		List<Map<String, Object>> skipped = new ArrayList<>();

		try {
			List<Path> outDirs = resolveGridOutDirs();
			for (Path d : outDirs) {
				Files.createDirectories(d);
			}

			List<Map<String, Object>> modules = loadModulesForGrid();
			if (modules == null || modules.isEmpty()) {
				result.put("error_code", 0);
				result.put("status", "success");
				result.put("message", "No modules with generate_grid=Yes");
				result.put("out_dirs", outDirs.stream().map(p -> p.toAbsolutePath().toString()).toList());
				result.put("created", created);
				result.put("skipped", skipped);
				return gson.toJson(result);
			}

			for (Map<String, Object> mod : modules) {
				String internalCode = str(mod.get("internal_code"));
				String fileName = sanitizeFileName(str(mod.get("file_name")));
				String displayName = str(mod.get("display_name"));
				String gridHeight = str(mod.get("grid_height"));
				if (gridHeight.isEmpty() || "null".equalsIgnoreCase(gridHeight)) {
					gridHeight = DEFAULT_GRID_HEIGHT;
				}

				Map<String, Object> row = new LinkedHashMap<>();
				row.put("internal_code", internalCode);
				row.put("display_name", displayName);
				row.put("file_name", fileName);

				if (fileName.isEmpty()) {
					row.put("reason", "empty file_name");
					skipped.add(row);
					continue;
				}

				List<Map<String, Object>> elements = loadElements(sanitizeSchemaCode(internalCode));
				if (elements == null || elements.isEmpty()) {
					row.put("reason", "no schema elements");
					skipped.add(row);
					continue;
				}

				String js = buildGridJs(fileName, gridHeight, elements);
				List<String> written = new ArrayList<>();
				for (Path outDir : outDirs) {
					Path outFile = outDir.resolve(fileName + ".js");
					Files.writeString(outFile, js, StandardCharsets.UTF_8);
					written.add(outFile.toAbsolutePath().toString());
					logger.info("Created grid file: {}", outFile.toAbsolutePath());
				}

				row.put("paths", written);
				row.put("columns", elements.size());
				created.add(row);
			}

			result.put("error_code", 0);
			result.put("status", "success");
			result.put("message", "Grid files generated");
			result.put("out_dirs", outDirs.stream().map(p -> p.toAbsolutePath().toString()).toList());
			result.put("created", created);
			result.put("skipped", skipped);
			result.put("created_count", created.size());
			result.put("skipped_count", skipped.size());
		} catch (Exception ex) {
			logger.error("createGridFiles failed: {}", ex.getMessage(), ex);
			result.put("error_code", -1);
			result.put("status", "failure");
			result.put("message", "createGridFiles failed: " + ex.getMessage());
			result.put("created", created);
			result.put("skipped", skipped);
		}
		return gson.toJson(result);
	}

	/** Modules that need a generated grid JS file. */
	private List<Map<String, Object>> loadModulesForGrid() {
		String sql = "select mo.internal_code,"
				+ " isnull(mo.display_name,'') as display_name,"
				+ " isnull(mo.file_name,'') as file_name,"
				+ " isnull(convert(varchar(20), mo.grid_height),'') as grid_height"
				+ " from dbo.ia_menu_options mo"
				+ " where mo.generate_grid = 'Yes'"
				+ " and mo.active = 'Yes'"
				+ " order by mo.display_name, mo.file_name";
		return NativeQuerySupport.executeQuery(session(), sql);
	}

	/**
	 * Schema elements for one module. ref_s_user_schema_code = ia_menu_options.internal_code
	 * (same linkage as GetModuleDetails).
	 */
	private List<Map<String, Object>> loadElements(String schemaCode) {
		// Same linkage as GetModuleDetails: ref_s_user_schema_code = ia_menu_options.internal_code
		String sql = "select isnull(su.name,'') as name,"
				+ " isnull(su.system_name,'') as system_name,"
				+ " isnull(su.width, 85) as width"
				+ " from dbo.ia_s_user_schema_elements su"
				+ " where su.ref_s_user_schema_code = " + schemaCode
				+ " and isnull(su.is_multiple_group, 0) = 0"
				+ " and isnull(su.include_in_grid, 0) = 1"
				+ " order by isnull(su.sequence, 9999), su.internal_code";
		return NativeQuerySupport.executeQuery(session(), sql);
	}

	/**
	 * Eclipse static folder plus exploded WAR copies (war root and WEB-INF/classes/static)
	 * so CreateGridFiles is visible without a full rebuild.
	 */
	private List<Path> resolveGridOutDirs() throws IOException {
		if (projectBasePath == null || projectBasePath.isBlank()) {
			throw new IOException(
					"Missing inpc.project.base-path. Set it in portal.properties (or application.yml) "
							+ "to the local project root.");
		}
		List<Path> dirs = new ArrayList<>();
		Path baseOut = Paths.get(projectBasePath).toAbsolutePath().normalize().resolve(GRID_RELATIVE).normalize();
		dirs.add(baseOut);
		logger.info("Grid out dir (base): {}", baseOut);

		if (projectDeployPath != null && !projectDeployPath.isBlank()) {
			Path deployRoot = Paths.get(projectDeployPath).toAbsolutePath().normalize();
			Path warRoot = deployRoot.resolve("grid_display_files/INPC").normalize();
			Path warClasses = deployRoot.resolve("WEB-INF/classes/static/grid_display_files/INPC").normalize();
			for (Path d : new Path[] { warRoot, warClasses }) {
				if (!dirs.contains(d)) {
					dirs.add(d);
					logger.info("Grid out dir (deploy): {}", d);
				}
			}
		}
		return dirs;
	}
	private String buildGridJs(String tableName, String gridHeight, List<Map<String, Object>> elements) {
		StringBuilder colNames = new StringBuilder();
		StringBuilder colModel = new StringBuilder();
		for (int i = 0; i < elements.size(); i++) {
			Map<String, Object> el = elements.get(i);
			String label = str(el.get("name"));
			String sys = sanitizeJsIdent(str(el.get("system_name")));
			if (sys.isEmpty()) {
				continue;
			}
			if (label.isEmpty()) {
				label = sys;
			}
			double width = 85.0;
			try {
				Object w = el.get("width");
				if (w != null) {
					width = Double.parseDouble(String.valueOf(w));
				}
			} catch (Exception ignore) {
				width = 85.0;
			}
			if (!Double.isFinite(width) || width <= 1.0) {
				width = 85.0;
			}
			if (colNames.length() > 0) {
				colNames.append(",");
				colModel.append(", \r\n");
			}
			colNames.append("'").append(escapeJs(label)).append("'");
			colModel.append("{name:'").append(escapeJs(sys)).append("',index:'")
					.append(escapeJs(sys)).append("' ,  align:'left',  width:")
					.append(String.format(java.util.Locale.US, "%.2f", width)).append("}");
		}

		String height = escapeJs(gridHeight);
		String tn = escapeJs(tableName);

		StringBuilder sb = new StringBuilder();
		sb.append("/* This file is created by Framework System */\r\n");
		sb.append("\r\n");
		sb.append("\t\t\tvar table_grid_").append(tn).append(" = jQuery('#table_grid_").append(tn).append("').jqGrid(\r\n");
		sb.append("\t\t\t{\r\n");
		sb.append("\t\t\turl:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=").append(tn).append("',\r\n");
		sb.append("\t\t\tdatatype: 'json',\r\n");
		sb.append("\t\t\t\tcolNames:[").append(colNames).append("],\r\n");
		sb.append("\t\t\tcolModel:[").append(colModel).append("],\r\n");
		sb.append("\t\t\trowNum:50,\r\n");
		sb.append("\t\t\trowList:[50,100,200,500],\r\n");
		sb.append("\t\t \r\n");
		sb.append("\t\t\tpager: jQuery('#sub_grid_div_").append(tn).append("'),\r\n");
		sb.append("\t\t\tsortname: 'id',\r\n");
		sb.append("\t\t\theight:'").append(height).append("',autowidth:true, \r\n");
		sb.append("\t\t\tviewrecords: true,\r\n");
		sb.append("\t\t\tsortorder: 'desc',\r\n");
		sb.append("\t\t\tmultiselect: false,\r\n");
		sb.append("\t\t\tautowidth: true,\r\n");
		sb.append("\t\t\tcellsubmit: 'clientArray',\r\n");
		sb.append("\t\t\tcellEdit: true,\r\n");
		sb.append("\t\t\tloadComplete:function() {\r\n");
		sb.append("                $('.ui-jqgrid-htable').css('border-collapse','separate');\r\n");
		sb.append("                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }\r\n");
		sb.append("                               },\r\n");
		sb.append("\t\t\tondblClickRow: function(rowid)\r\n");
		sb.append("\t\t\t\t{\r\n");
		sb.append("\t\t\t\tall_obj.EditRecords(rowid,'").append(tn).append("');\r\n");
		sb.append("\t\t\t\treturn;\r\n");
		sb.append("\t\t\t\t},\r\n");
		sb.append("\t\t\tshrinkToFit: true,\r\n");
		sb.append("\t\t\tediturl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=").append(tn).append("'\r\n");
		sb.append("\t\t\t}\r\n");
		sb.append("\t\t\t).navGrid('#sub_grid_div_").append(tn).append("',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})\r\n");
		sb.append("\t\t\t.navButtonAdd('#sub_grid_div_").append(tn).append("',{caption:'Search',\r\n");
		sb.append("\t\t\tbuttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_").append(tn).append("[0].toggleToolbar() } }) ;\t\r\n");
		sb.append("\r\n");
		sb.append("\r\n");
		sb.append("\t\t\t table_grid_").append(tn).append(".filterToolbar(); \r\n");
			sb.append("\t\t\tif (window.Common && Common.EnableJqGridMobileHScroll) {\r\n");
			sb.append("\t\t\t\tCommon.EnableJqGridMobileHScroll(table_grid_").append(tn).append(");\r\n");
			sb.append("\t\t\t\tif (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_").append(tn).append("); }\r\n");
			sb.append("\t\t\t\tif (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }\r\n");
			sb.append("\t\t\t}\r\n");
		sb.append("\t\t\t// table_grid_").append(tn).append("[0].toggleToolbar();\r\n");
		sb.append("\r\n");
		sb.append("\t\t\t  \r\n");
		sb.append("\t\t\t   $('.ui-search-toolbar').bind('keydown',function(evt)\r\n");
		sb.append("\t\t\t\t{\r\n");
		sb.append("\t\t\t\t\tvar kC  = (evt.which) ? evt.which : evt.keyCode;\r\n");
		sb.append("\t\t\t\t\tif(kC==40)\r\n");
		sb.append("\t\t\t\t\tjQuery('#table_grid').editCell(1,1,false);\r\n");
		sb.append("\t\t\t\t\tif(kC==39)\r\n");
		sb.append("\t\t\t\t\t $('#'+evt.target.id).focusNextInputField();\r\n");
		sb.append("\t\t\t\t\t if(kC==37)\r\n");
		sb.append("\t\t\t\t\t $('#'+evt.target.id).focusPreviousInputField();\r\n");
		sb.append("\t\t\t\t} );\r\n");
		sb.append("\r\n");
		sb.append("\r\n");
		sb.append("\t\t\t  \r\n");
		return sb.toString();
	}

	/** Digits only so element SQL stays safe when concatenating (same style as GetModuleDetails). */
	private static String sanitizeSchemaCode(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty() || !s.matches("\\d+")) {
			return "0";
		}
		return s;
	}

	private static String sanitizeFileName(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty()) {
			return "";
		}
		s = s.replace('\\', '/');
		int slash = s.lastIndexOf('/');
		if (slash >= 0) {
			s = s.substring(slash + 1);
		}
		if (s.toLowerCase().endsWith(".html")) {
			s = s.substring(0, s.length() - 5);
		}
		if (s.toLowerCase().endsWith(".js")) {
			s = s.substring(0, s.length() - 3);
		}
		s = s.replaceAll("[^A-Za-z0-9_\\-]", "");
		return s;
	}

	/** Keep system_name usable as JS object keys / identifiers in jqGrid. */
	private static String sanitizeJsIdent(String raw) {
		return str(raw).trim().replaceAll("[^A-Za-z0-9_]", "");
	}

	private static String escapeJs(String s) {
		if (s == null) {
			return "";
		}
		return s.replace("\\", "\\\\").replace("'", "\\'").replace("\r", "").replace("\n", " ");
	}

	private static String str(Object o) {
		if (o == null) {
			return "";
		}
		String s = String.valueOf(o);
		return "null".equalsIgnoreCase(s) ? "" : s;
	}
}