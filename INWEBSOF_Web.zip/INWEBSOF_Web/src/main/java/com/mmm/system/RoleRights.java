package com.mmm.system;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;

/**
 * Role rights mapping — ported from insba RoleRights, adapted to
 * Spring @Transactional + system SessionFactory.
 */
@RestController
@RequestMapping("titpl/role_rights")
public class RoleRights {

	private static final Logger logger = LogManager.getLogger(RoleRights.class);

	private final SessionFactory sessionFactory;
	private final Gson gson = new Gson();

	public RoleRights(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	/** Gson-friendly legacy shape: error_code + data. */
	public static class RoleRightsResponse {
		@SerializedName("error_code")
		public int error_code;
		public String status;
		public String message;
		public Object data;

		public static RoleRightsResponse ok(Object data) {
			RoleRightsResponse r = new RoleRightsResponse();
			r.error_code = 0;
			r.status = "success";
			r.message = "success";
			r.data = data;
			return r;
		}

		public static RoleRightsResponse okMsg(String msg) {
			return ok(msg);
		}
	}

	@GetMapping("GetRoleNamesLov")
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String GetRoleNamesLov() {
		String sql = "select role_name as name, cast(internal_code as varchar) as val from ia_roles order by role_name";
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session(), sql);
		return gson.toJson(RoleRightsResponse.ok(rows));
	}

	@GetMapping("GetUsersForRoleDownloadLov")
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String GetUsersForRoleDownloadLov(
			@RequestParam(value = "term", required = false, defaultValue = "") String term) {
		String sql = "select top 25 enl_id as enl_id, name as name from ia_user_master "
				+ "where enl_id is not null and (enl_id like :term or name like :term) "
				+ "order by enl_id";
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(
				session(), sql,
				Map.of("term", "%" + (term == null ? "" : term.trim().replace("[", "[[]")
						.replace("%", "[%]").replace("_", "[_]")) + "%"),
				NativeQuerySupport.stringScalars("enl_id", "name"));
		return gson.toJson(RoleRightsResponse.ok(rows));
	}

	@GetMapping("GetMenuGroupNamesLov")
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String GetMenuGroupNamesLov(
			@RequestParam("app_type") String app_type,
			@RequestParam(value = "term", required = false, defaultValue = "") String term) {
		String sql = "select distinct menu_name as name from ia_menu_groups "
				+ "where app_type = :appType and menu_name like :term "
				+ "order by menu_name";
		List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(
				session(), sql,
				Map.of("appType", app_type == null ? "" : app_type.trim(),
						"term", "%" + (term == null ? "" : term.trim().replace("[", "[[]")
								.replace("%", "[%]").replace("_", "[_]")) + "%"),
				NativeQuerySupport.stringScalars("name"));
		return gson.toJson(RoleRightsResponse.ok(rows));
	}

	@GetMapping("GetModuleNamesforSelectedRoles")
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String GetModuleNamesforSelectedRoles(
			@RequestParam("app_type") String app_type,
			@RequestParam("role_name") String role_name,
			@RequestParam(value = "menu_group", required = false, defaultValue = "") String menu_group) {

		String safeApp = app_type == null ? "" : app_type.replace("'", "''");
		String safeRole = role_name == null ? "0" : role_name.replace("'", "''");
		String menu_grp_cond = "";
		if (menu_group != null && !menu_group.isEmpty()) {
			menu_grp_cond = " and menu_name='" + menu_group.replace("'", "''") + "'";
		}

		String sql = "select mo.internal_code as internal_code, menu_name as menu_name,"
				+ " isnull(sub_menu_name,'Others') as sub_menu_name, mo.display_name as display_name,"
				+ " isnull(rr.ref_menu_code,0) as ref_menu_code"
				+ " from ia_menu_groups mg"
				+ " inner join ia_menu_options mo on mg.internal_code=mo.ref_menu_group_code and mg.app_type='" + safeApp + "'"
				+ " left join ia_menu_sub_groups sg on sg.internal_code=ref_menu_subgroup_code"
				+ " left join ia_role_rights rr on rr.ref_menu_code=mo.internal_code and rr.ref_role_code=" + safeRole
				+ " where 1=1 and mo.active='Yes' " + menu_grp_cond
				+ " order by menu_name, sg.sequence, mo.display_name";

		logger.info("role_rights Qry->{}", sql);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session(), sql);
		return gson.toJson(RoleRightsResponse.ok(rows));
	}

	@GetMapping("SaveRoleDetails")
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String SaveRoleDetails(
			@RequestParam(value = "checkedVals", required = false, defaultValue = "") String checkedVals,
			@RequestParam(value = "NoncheckedVals", required = false, defaultValue = "") String NoncheckedVals,
			@RequestParam("role_name") String role_name) {

		Session session = session();
		String safeRole = role_name == null ? "0" : role_name.replace("'", "''");

		if (NoncheckedVals != null && !NoncheckedVals.isEmpty()) {
			String[] str_arr = NoncheckedVals.split(",");
			StringBuilder menu_ids = new StringBuilder();
			for (String ref_menu_code : str_arr) {
				if (ref_menu_code == null || ref_menu_code.isBlank()) continue;
				menu_ids.append(ref_menu_code.trim()).append(",");
			}
			menu_ids.append("0");
			deleteFromRoleRights(session, safeRole, menu_ids.toString());
		}

		if (checkedVals != null && !checkedVals.isEmpty()) {
			for (String ref_menu_code : checkedVals.split(",")) {
				if (ref_menu_code == null || ref_menu_code.isBlank()) continue;
				String code = ref_menu_code.trim();
				deleteFromRoleRights(session, safeRole, code);
				insertRoleRights(session, safeRole, code);
			}
		}

		return gson.toJson(RoleRightsResponse.okMsg("Mapped Successfully"));
	}

	private void insertRoleRights(Session session, String ref_role_code, String ref_menu_code) {
		String insert_qry = "insert into ia_role_rights(ref_role_code,ref_menu_code) values ("
				+ "'" + ref_role_code + "',"
				+ "'" + ref_menu_code + "'"
				+ ")";
		logger.info("role_insert_qry=={}", insert_qry);
		session.createNativeQuery(insert_qry).executeUpdate();
	}

	private void deleteFromRoleRights(Session session, String ref_role_code, String menu_ids) {
		String del_qry = "delete from ia_role_rights where ref_role_code=" + ref_role_code
				+ " and ref_menu_code in (" + menu_ids + ")";
		logger.info("role_del_qry=={}", del_qry);
		session.createNativeQuery(del_qry).executeUpdate();
	}
}
