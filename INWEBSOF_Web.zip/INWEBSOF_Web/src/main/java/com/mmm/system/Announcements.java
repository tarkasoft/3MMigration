package com.mmm.system;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.StandardBasicTypes;
import com.mmm.authentication.UserSessionSupport;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.AuthService;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

/**
 * Active announcements for All + logged-in user type, order by sequence.
 * One class (no separate controller/service).
 *
 * Call: GET/POST titpl/system/getAnnouncements
 */
@RestController
@RequestMapping("titpl/system")
public class Announcements {

	private final SessionFactory sessionFactory;
	private final Gson gson = new Gson();

	public Announcements(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@RequestMapping(value = "getAnnouncements", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String getAnnouncements(HttpServletRequest request) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}
		try {
			Object rawType = httpSession.getAttribute(UserSessionSupport.LOGIN_USER_TYPE);
			String userType = AuthService.normalizeLoginUserType(rawType);
			List<Map<String, Object>> rows = loadActiveForUserType(userType);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("userType", userType);
			data.put("announcements", rows);
			data.put("count", rows == null ? 0 : rows.size());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			result.SetError(-1, "failure", "Announcement load failed: " + ex.getMessage());
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadActiveForUserType(String loginUserType) {
		String ut = loginUserType == null ? "Customer" : loginUserType.trim();
		if (ut.isEmpty()) {
			ut = "Customer";
		}
		String sql = "select a.internal_code as internal_code,"
				+ " isnull(t.user_type_name, isnull(a.a_user_type,'')) as a_user_type,"
				+ " isnull(a.title,'') as title,"
				+ " isnull(a.description,'') as description,"
				+ " isnull(a.full_desc,'') as full_desc,"
				+ " isnull(a.sequence,'') as sequence,"
				+ " convert(varchar(10), a.from_date, 103) as from_date,"
				+ " convert(varchar(10), a.to_date, 103) as to_date"
				+ " from dbo.ia_announcement a"
				+ " left join dbo.ia_user_type t on t.internal_code = try_cast(a.a_user_type as int)"
				+ " where (a.from_date is null or convert(date, a.from_date) <= convert(date, " + UserSessionSupport.sessionDate() + "))"
				+ " and (a.to_date is null or convert(date, a.to_date) >= convert(date, " + UserSessionSupport.sessionDate() + "))"
				+ " and ("
				+ "   lower(ltrim(rtrim(isnull(t.user_type_name,'')))) = 'all'"
				+ "   or lower(ltrim(rtrim(isnull(a.a_user_type,'')))) = 'all'"
				+ "   or lower(ltrim(rtrim(isnull(t.user_type_name,'')))) = lower(:userType)"
				+ "   or lower(ltrim(rtrim(isnull(a.a_user_type,'')))) = lower(:userType)"
				+ " )"
				+ " order by try_cast(a.sequence as float), a.sequence, a.internal_code";

		Map<String, Object> params = new LinkedHashMap<>();
		params.put("userType", ut);

		Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
		scalars.put("internal_code", StandardBasicTypes.INTEGER);
		scalars.put("a_user_type", StandardBasicTypes.STRING);
		scalars.put("title", StandardBasicTypes.STRING);
		scalars.put("description", StandardBasicTypes.STRING);
		scalars.put("full_desc", StandardBasicTypes.STRING); 
		scalars.put("sequence", StandardBasicTypes.STRING);
		scalars.put("from_date", StandardBasicTypes.STRING);
		scalars.put("to_date", StandardBasicTypes.STRING);

		return NativeQuerySupport.listAsMaps(session(), sql, params, scalars);
	}
}