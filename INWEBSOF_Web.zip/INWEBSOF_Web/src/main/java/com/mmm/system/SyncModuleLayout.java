package com.mmm.system;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;

/**
 * One-module layout sync: update ia_menu_options from request params, then
 * update ia_s_user_schema_elements sequence / field_width / field_position /
 * list_of_values by reading the existing HTML under html_files/INPC.
 *
 * Call (GET/POST) titpl/system/syncModuleLayout
 * Params:
 *   file_name (required) — matches ia_menu_options.file_name (with or without .html)
 *   field_position — LeftRight | TopBottom (module label layout)
 *   grid_position — Top | Left | Right | Bottom
 *   grid_width, html_width — Bootstrap column spans (1–12)
 *   generate_html, generate_grid — Yes | No (default Yes if omitted)
 *   dry_run — 1/true to preview without writing
 *
 * Also: titpl/system/syncModuleLayoutFiles?value=term — autocomplete rows from ia_menu_options
 */
@RestController
@RequestMapping("titpl/system")
public class SyncModuleLayout {

	private static final Logger logger = LogManager.getLogger(SyncModuleLayout.class);
	private static final String HTML_RELATIVE = "src/main/resources/static/html_files/INPC";

	private static final Pattern COL_SPAN = Pattern.compile(
			"col-(?:xl|md|lg|sm)-(\\d+)", Pattern.CASE_INSENSITIVE);
	private static final Pattern FIELD_BLOCK = Pattern.compile(
			"(?is)<div\\b([^>]*\\bcol-(?:xl|md|lg|sm)-\\d+[^>]*)>(.*?)</div>");
	private static final Pattern CONTROL_ID = Pattern.compile(
			"(?is)<(input|select|textarea)\\b[^>]*\\bid\\s*=\\s*[\"']([A-Za-z0-9_]+)[\"'][^>]*>");
	private static final Pattern SELECT_BLOCK = Pattern.compile(
			"(?is)<select\\b[^>]*\\bid\\s*=\\s*[\"']([A-Za-z0-9_]+)[\"'][^>]*>(.*?)</select>");
	private static final Pattern OPTION_VALUE = Pattern.compile(
			"(?is)<option\\b[^>]*\\bvalue\\s*=\\s*[\"']([^\"']*)[\"'][^>]*>");

	private final SessionFactory sessionFactory;
	private final String projectBasePath;
	private final Gson gson = new Gson();

	public SyncModuleLayout(
			@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory,
			@Value("${inpc.project.base-path:}") String projectBasePath) {
		this.sessionFactory = sessionFactory;
		this.projectBasePath = projectBasePath == null ? "" : projectBasePath.trim();
	}

	private Session session() {
		return sessionFactory.getCurrentSession();
	}

	@RequestMapping(value = "syncModuleLayout", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String syncModuleLayout(HttpServletRequest request) {
		Map<String, Object> result = new LinkedHashMap<>();
		List<Map<String, Object>> elementUpdates = new ArrayList<>();

		try {
			String fileName = sanitizeFileName(param(request, "file_name"));
			if (fileName.isEmpty()) {
				result.put("error_code", -1);
				result.put("status", "failure");
				result.put("message", "file_name is required");
				return gson.toJson(result);
			}

			boolean dryRun = isTruthy(param(request, "dry_run"));
			String fieldPosition = normalizeModuleFieldPosition(param(request, "field_position"));
			String gridPosition = normalizeGridPosition(param(request, "grid_position"));
			int gridWidth = clampCol(param(request, "grid_width"), 6);
			int htmlWidth = clampCol(param(request, "html_width"), 6);
			String generateHtml = normalizeYesNo(param(request, "generate_html"), "Yes");
			String generateGrid = normalizeYesNo(param(request, "generate_grid"), "Yes");

			Map<String, Object> mod = loadModule(fileName);
			if (mod == null) {
				result.put("error_code", -1);
				result.put("status", "failure");
				result.put("message", "No ia_menu_options row for file_name=" + fileName);
				return gson.toJson(result);
			}

			String internalCode = str(mod.get("internal_code"));
			Path htmlPath = resolveHtmlPath(fileName);
			String html = "";
			if (htmlPath != null && Files.isRegularFile(htmlPath)) {
				html = Files.readString(htmlPath, StandardCharsets.UTF_8);
			}

			List<ParsedField> parsed = parseFieldsFromHtml(html, fieldPosition);

			Map<String, Object> menuBefore = new LinkedHashMap<>();
			menuBefore.put("generate_html", mod.get("generate_html"));
			menuBefore.put("generate_grid", mod.get("generate_grid"));
			menuBefore.put("field_position", mod.get("field_position"));
			menuBefore.put("grid_position", mod.get("grid_position"));
			menuBefore.put("html_width", mod.get("html_width"));
			menuBefore.put("grid_width", mod.get("grid_width"));

			Map<String, Object> menuAfter = new LinkedHashMap<>();
			menuAfter.put("generate_html", generateHtml);
			menuAfter.put("generate_grid", generateGrid);
			menuAfter.put("field_position", fieldPosition);
			menuAfter.put("grid_position", gridPosition);
			menuAfter.put("html_width", htmlWidth);
			menuAfter.put("grid_width", gridWidth);

			List<String> updateCommands = new ArrayList<>();
			updateCommands.add(buildMenuUpdateSql(fileName, generateHtml, generateGrid, fieldPosition, gridPosition,
					htmlWidth, gridWidth));

			int menuRows = 0;
			if (!dryRun) {
				menuRows = updateMenuOptions(fileName, generateHtml, generateGrid, fieldPosition, gridPosition,
						htmlWidth, gridWidth);
			}

			List<Map<String, Object>> dbElements = loadElements(sanitizeSchemaCode(internalCode));
			Map<String, Map<String, Object>> bySys = new LinkedHashMap<>();
			for (Map<String, Object> el : dbElements) {
				String sys = sanitizeJsIdent(str(el.get("system_name")));
				if (!sys.isEmpty()) {
					bySys.put(sys, el);
				}
			}

			int elemUpdated = 0;
			for (ParsedField pf : parsed) {
				Map<String, Object> el = bySys.get(pf.systemName);
				if (el == null) {
					Map<String, Object> miss = new LinkedHashMap<>();
					miss.put("system_name", pf.systemName);
					miss.put("status", "skipped");
					miss.put("reason", "not in ia_s_user_schema_elements");
					elementUpdates.add(miss);
					continue;
				}

				String elCode = str(el.get("internal_code"));
				String sqlCmd = buildElementUpdateSql(elCode, pf.sequence, pf.fieldWidth, pf.elementFieldPosition,
						pf.listOfValues);
				updateCommands.add(sqlCmd);

				Map<String, Object> row = new LinkedHashMap<>();
				row.put("system_name", pf.systemName);
				row.put("internal_code", elCode);
				row.put("sequence", pf.sequence);
				row.put("field_width", pf.fieldWidth);
				row.put("field_position", pf.elementFieldPosition);
				row.put("list_of_values", pf.listOfValues);
				row.put("list_of_values_before", str(el.get("list_of_values")));
				row.put("update_sql", sqlCmd);

				if (!dryRun) {
					int n = updateElement(elCode, pf.sequence, pf.fieldWidth, pf.elementFieldPosition, pf.listOfValues);
					row.put("rows", n);
					elemUpdated += n;
				} else {
					row.put("rows", 0);
				}
				row.put("status", dryRun ? "preview" : "updated");
				elementUpdates.add(row);
			}

			result.put("error_code", 0);
			result.put("status", "success");
			result.put("message", dryRun ? "Preview ready — review UPDATE commands" : "Module layout synced");
			result.put("dry_run", dryRun);
			result.put("file_name", fileName);
			result.put("internal_code", internalCode);
			result.put("html_path", htmlPath == null ? "" : htmlPath.toAbsolutePath().toString());
			result.put("html_found", htmlPath != null && Files.isRegularFile(htmlPath));
			result.put("menu_before", menuBefore);
			result.put("menu_after", menuAfter);
			result.put("menu_rows", menuRows);
			result.put("elements_parsed", parsed.size());
			result.put("elements_updated", elemUpdated);
			result.put("elements", elementUpdates);
			result.put("update_commands", updateCommands);
		} catch (Exception ex) {
			logger.error("syncModuleLayout failed: {}", ex.getMessage(), ex);
			result.put("error_code", -1);
			result.put("status", "failure");
			result.put("message", "syncModuleLayout failed: " + ex.getMessage());
		}
		return gson.toJson(result);
	}

	/**
	 * Autocomplete source for Sync Module Layout file_name.
	 * GET/POST titpl/system/syncModuleLayoutFiles?value=ia_
	 * Returns matching ia_menu_options rows (layout columns included).
	 */
	@RequestMapping(value = "syncModuleLayoutFiles", method = { RequestMethod.GET, RequestMethod.POST })
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX, readOnly = true)
	public @ResponseBody String syncModuleLayoutFiles(HttpServletRequest request) {
		Map<String, Object> result = new LinkedHashMap<>();
		try {
			String q = sanitizeFileName(param(request, "value"));
			if (q.isEmpty()) {
				q = sanitizeFileName(param(request, "q"));
			}
			String sql = "select top 40"
					+ " isnull(mo.file_name,'') as file_name,"
					+ " isnull(mo.generate_html,'') as generate_html,"
					+ " isnull(mo.generate_grid,'') as generate_grid,"
					+ " isnull(mo.field_position,'') as field_position,"
					+ " isnull(mo.grid_position,'') as grid_position,"
					+ " isnull(mo.html_width,6) as html_width,"
					+ " isnull(mo.grid_width,6) as grid_width"
					+ " from dbo.ia_menu_options mo"
					+ " where isnull(mo.file_name,'') <> ''";
			if (!q.isEmpty()) {
				sql += " and lower(replace(isnull(mo.file_name,''),'.html','')) like '%"
						+ sqlEscape(q.toLowerCase()) + "%'";
			}
			sql += " order by mo.file_name";
			List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session(), sql);
			List<Map<String, Object>> data = new ArrayList<>();
			if (rows != null) {
				for (Map<String, Object> r : rows) {
					String fn = str(r.get("file_name"));
					if (fn.toLowerCase().endsWith(".html")) {
						fn = fn.substring(0, fn.length() - 5);
					}
					fn = fn.trim();
					if (fn.isEmpty()) {
						continue;
					}
					Map<String, Object> item = new LinkedHashMap<>();
					item.put("label", fn);
					item.put("value", fn);
					item.put("file_name", fn);
					item.put("generate_html", r.get("generate_html"));
					item.put("generate_grid", r.get("generate_grid"));
					item.put("field_position", r.get("field_position"));
					item.put("grid_position", r.get("grid_position"));
					item.put("html_width", r.get("html_width"));
					item.put("grid_width", r.get("grid_width"));
					data.add(item);
				}
			}
			result.put("error_code", 0);
			result.put("status", "success");
			result.put("data", data);
		} catch (Exception ex) {
			logger.error("syncModuleLayoutFiles failed: {}", ex.getMessage(), ex);
			result.put("error_code", -1);
			result.put("status", "failure");
			result.put("message", "syncModuleLayoutFiles failed: " + ex.getMessage());
			result.put("data", new ArrayList<>());
		}
		return gson.toJson(result);
	}

	private Map<String, Object> loadModule(String fileName) {
		String sql = "select top 1 mo.internal_code,"
				+ " isnull(mo.file_name,'') as file_name,"
				+ " isnull(mo.generate_html,'') as generate_html,"
				+ " isnull(mo.generate_grid,'') as generate_grid,"
				+ " isnull(mo.field_position,'') as field_position,"
				+ " isnull(mo.grid_position,'') as grid_position,"
				+ " isnull(mo.html_width,6) as html_width,"
				+ " isnull(mo.grid_width,6) as grid_width"
				+ " from dbo.ia_menu_options mo"
				+ " where lower(replace(isnull(mo.file_name,''),'.html','')) = '"
				+ sqlEscape(fileName.toLowerCase()) + "'"
				+ " order by mo.internal_code";
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session(), sql);
		if (rows == null || rows.isEmpty()) {
			return null;
		}
		return rows.get(0);
	}

	private List<Map<String, Object>> loadElements(String schemaCode) {
		String sql = "select su.internal_code,"
				+ " isnull(su.system_name,'') as system_name,"
				+ " isnull(su.sequence,9999) as sequence,"
				+ " isnull(su.field_width,2) as field_width,"
				+ " isnull(su.field_position,'') as field_position,"
				+ " isnull(su.list_of_values,'') as list_of_values"
				+ " from dbo.ia_s_user_schema_elements su"
				+ " where su.ref_s_user_schema_code = " + schemaCode
				+ " and isnull(su.is_multiple_group, 0) = 0";
		return NativeQuerySupport.executeQuery(session(), sql);
	}

	private int updateMenuOptions(String fileName, String generateHtml, String generateGrid, String fieldPosition,
			String gridPosition, int htmlWidth, int gridWidth) {
		String sql = "update dbo.ia_menu_options set"
				+ " generate_html = ?,"
				+ " generate_grid = ?,"
				+ " field_position = ?,"
				+ " grid_position = ?,"
				+ " html_width = ?,"
				+ " grid_width = ?"
				+ " where lower(replace(isnull(file_name,''),'.html','')) = ?";
		int[] out = new int[1];
		session().doWork(conn -> {
			try (PreparedStatement ps = conn.prepareStatement(sql)) {
				ps.setString(1, generateHtml);
				ps.setString(2, generateGrid);
				ps.setString(3, fieldPosition);
				ps.setString(4, gridPosition);
				ps.setInt(5, htmlWidth);
				ps.setInt(6, gridWidth);
				ps.setString(7, fileName.toLowerCase());
				out[0] = ps.executeUpdate();
			}
		});
		return out[0];
	}

private static String buildMenuUpdateSql(String fileName, String generateHtml, String generateGrid,
			String fieldPosition, String gridPosition, int htmlWidth, int gridWidth) {
		return "UPDATE dbo.ia_menu_options SET"
				+ " generate_html = '" + sqlEscape(generateHtml) + "',"
				+ " generate_grid = '" + sqlEscape(generateGrid) + "',"
				+ " field_position = '" + sqlEscape(fieldPosition) + "',"
				+ " grid_position = '" + sqlEscape(gridPosition) + "',"
				+ " html_width = " + htmlWidth + ","
				+ " grid_width = " + gridWidth
				+ " WHERE lower(replace(isnull(file_name,''),'.html','')) = '"
				+ sqlEscape(fileName.toLowerCase()) + "';";
	}

	private static String buildElementUpdateSql(String internalCode, int sequence, int fieldWidth,
			String fieldPosition, String lov) {
		return "UPDATE dbo.ia_s_user_schema_elements SET"
				+ " sequence = " + sequence + ","
				+ " field_width = " + fieldWidth + ","
				+ " field_position = '" + sqlEscape(fieldPosition) + "',"
				+ " list_of_values = '" + sqlEscape(lov == null ? "" : lov) + "'"
				+ " WHERE internal_code = " + internalCode + ";";
	}

	private int updateElement(String internalCode, int sequence, int fieldWidth, String fieldPosition, String lov) {
		String sql = "update dbo.ia_s_user_schema_elements set"
				+ " sequence = ?,"
				+ " field_width = ?,"
				+ " field_position = ?,"
				+ " list_of_values = ?"
				+ " where internal_code = ?";
		int[] out = new int[1];
		session().doWork(conn -> {
			try (PreparedStatement ps = conn.prepareStatement(sql)) {
				ps.setInt(1, sequence);
				ps.setInt(2, fieldWidth);
				ps.setString(3, fieldPosition);
				ps.setString(4, lov == null ? "" : lov);
				ps.setLong(5, Long.parseLong(internalCode));
				out[0] = ps.executeUpdate();
			}
		});
		return out[0];
	}

	private Path resolveHtmlPath(String fileName) {
		if (projectBasePath == null || projectBasePath.isBlank()) {
			return null;
		}
		Path base = Paths.get(projectBasePath).toAbsolutePath().normalize().resolve(HTML_RELATIVE).normalize();
		Path p = base.resolve(fileName + ".html");
		if (Files.isRegularFile(p)) {
			return p;
		}
		return p;
	}

	private List<ParsedField> parseFieldsFromHtml(String html, String moduleFieldPosition) {
		List<ParsedField> out = new ArrayList<>();
		if (html == null || html.isBlank()) {
			return out;
		}

		Map<String, String> lovBySys = new LinkedHashMap<>();
		Matcher sm = SELECT_BLOCK.matcher(html);
		while (sm.find()) {
			String sys = sanitizeJsIdent(sm.group(1));
			if (sys.isEmpty() || sys.startsWith("txt_ref_schema_")) {
				continue;
			}
			String body = sm.group(2);
			List<String> opts = new ArrayList<>();
			Matcher om = OPTION_VALUE.matcher(body);
			while (om.find()) {
				String v = om.group(1) == null ? "" : om.group(1).trim();
				if (!v.isEmpty()) {
					opts.add(v);
				}
			}
			if (!opts.isEmpty()) {
				lovBySys.put(sys, String.join("|", opts));
			}
		}

		int seq = 10;
		boolean leftRight = "LeftRight".equalsIgnoreCase(moduleFieldPosition);
		boolean firstInRow = true;
		Matcher bm = FIELD_BLOCK.matcher(html);
		while (bm.find()) {
			String attrs = bm.group(1);
			String inner = bm.group(2);
						Matcher cm = CONTROL_ID.matcher(inner);
			String sys = "";
			while (cm.find()) {
				String id = sanitizeJsIdent(cm.group(2));
				String tag = cm.group(1).toLowerCase();
				if (id.isEmpty() || id.startsWith("txt_ref_schema_")) {
					continue;
				}
				if ("hidden".equalsIgnoreCase(attrValue(cm.group(0), "type")) && !lovBySys.containsKey(id)) {
					// keep hidden ref ids as fields (reference data)
				}
				sys = id;
				if ("select".equals(tag) || !"hidden".equalsIgnoreCase(attrValue(cm.group(0), "type"))) {
					if (!"hidden".equalsIgnoreCase(attrValue(cm.group(0), "type")) || tag.equals("select")) {
						break;
					}
				}
				// prefer visible control; if only hidden, still use it
			}
			if (sys.isEmpty()) {
				continue;
			}
			// skip duplicates (already seen)
			boolean dup = false;
			for (ParsedField existing : out) {
				if (existing.systemName.equals(sys)) {
					dup = true;
					break;
				}
			}
			if (dup) {
				continue;
			}

			ParsedField pf = new ParsedField();
			pf.systemName = sys;
			pf.sequence = seq;
			// Layout decides width (ignore HTML col span): TopBottom=full row 12; LeftRight=3 (4 per row)
			if (leftRight) {
				pf.fieldWidth = 3;
				pf.elementFieldPosition = firstInRow ? "NextLine" : "NextColumn";
				firstInRow = false;
				int used = 0;
				for (int i = out.size() - 1; i >= 0; i--) {
					ParsedField prev = out.get(i);
					used += prev.fieldWidth;
					if ("NextLine".equals(prev.elementFieldPosition)) {
						break;
					}
				}
				used += pf.fieldWidth;
				if (!out.isEmpty() && used > 12) {
					pf.elementFieldPosition = "NextLine";
					firstInRow = false;
				}
			} else {
				pf.fieldWidth = 12;
				pf.elementFieldPosition = "NextLine";
			}
			pf.listOfValues = lovBySys.getOrDefault(sys, "");
			out.add(pf);
			seq += 10;
		}

		// Fallback: any selects/inputs not captured in col blocks
		if (out.isEmpty()) {
			Matcher cm = CONTROL_ID.matcher(html);
			while (cm.find()) {
				String sys = sanitizeJsIdent(cm.group(2));
				if (sys.isEmpty() || sys.startsWith("txt_ref_schema_")) {
					continue;
				}
				if ("hidden".equalsIgnoreCase(attrValue(cm.group(0), "type")) && !lovBySys.containsKey(sys)) {
					continue;
				}
				boolean dup = false;
				for (ParsedField existing : out) {
					if (existing.systemName.equals(sys)) {
						dup = true;
						break;
					}
				}
				if (dup) {
					continue;
				}
				ParsedField pf = new ParsedField();
				pf.systemName = sys;
				pf.sequence = seq;
				pf.fieldWidth = leftRight ? 3 : 12;
				pf.elementFieldPosition = leftRight && !out.isEmpty() ? "NextColumn" : "NextLine";
				pf.listOfValues = lovBySys.getOrDefault(sys, "");
				out.add(pf);
				seq += 10;
			}
		}
		return out;
	}

	private static int extractColWidth(String attrs) {
		if (attrs == null) {
			return 2;
		}
		Matcher m = COL_SPAN.matcher(attrs);
		int best = 0;
		while (m.find()) {
			try {
				int n = Integer.parseInt(m.group(1));
				if (n > best) {
					best = n;
				}
			} catch (Exception ignore) {
				/* ignore */
			}
		}
		return best > 0 ? best : 2;
	}

	private static String attrValue(String tag, String name) {
		Matcher m = Pattern.compile("(?i)\\b" + Pattern.quote(name) + "\\s*=\\s*[\"']([^\"']*)[\"']").matcher(tag);
		if (m.find()) {
			return m.group(1);
		}
		return "";
	}

	private static String param(HttpServletRequest req, String name) {
		String v = req.getParameter(name);
		return v == null ? "" : v.trim();
	}

	private static boolean isTruthy(String v) {
		return "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v) || "y".equalsIgnoreCase(v);
	}

	private static String normalizeYesNo(String raw, String def) {
		if (raw == null || raw.isBlank()) {
			return def;
		}
		if ("No".equalsIgnoreCase(raw) || "0".equals(raw) || "false".equalsIgnoreCase(raw) || "N".equalsIgnoreCase(raw)) {
			return "No";
		}
		return "Yes";
	}

	private static String normalizeModuleFieldPosition(String raw) {
		String s = raw == null ? "" : raw.replace(" ", "").trim();
		if (s.equalsIgnoreCase("LeftRight") || s.equalsIgnoreCase("LefttoRight") || s.equalsIgnoreCase("LtoR")) {
			return "LeftRight";
		}
		return "TopBottom";
	}

	private static String normalizeGridPosition(String raw) {
		String s = raw == null ? "" : raw.trim();
		if (s.equalsIgnoreCase("Top")) {
			return "Top";
		}
		if (s.equalsIgnoreCase("Left")) {
			return "Left";
		}
		if (s.equalsIgnoreCase("Right")) {
			return "Right";
		}
		if (s.isEmpty()) {
			return "Bottom";
		}
		return "Bottom";
	}

	private static int clampCol(Object raw, int def) {
		try {
			int n = Integer.parseInt(String.valueOf(raw).trim());
			if (n < 1) {
				return def;
			}
			if (n > 12) {
				return 12;
			}
			return n;
		} catch (Exception e) {
			return def;
		}
	}

	private static String sanitizeFileName(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty()) {
			return "";
		}
		s = s.replace('\\', '/');
		int slash = s.lastIndexOf('/');
		if (slash >= 0) {
			s = s.substring(slash + 1);
		}
		if (s.toLowerCase().endsWith(".html")) {
			s = s.substring(0, s.length() - 5);
		}
		if (s.toLowerCase().endsWith(".js")) {
			s = s.substring(0, s.length() - 3);
		}
		s = s.replaceAll("[^A-Za-z0-9_\\-]", "");
		return s;
	}

	private static String sanitizeJsIdent(String raw) {
		return str(raw).trim().replaceAll("[^A-Za-z0-9_]", "");
	}

	private static String sanitizeSchemaCode(String raw) {
		String s = str(raw).trim();
		if (s.isEmpty() || !s.matches("\\d+")) {
			return "0";
		}
		return s;
	}

	private static String sqlEscape(String s) {
		return s == null ? "" : s.replace("'", "''");
	}

	private static String str(Object o) {
		if (o == null) {
			return "";
		}
		String s = String.valueOf(o);
		return "null".equalsIgnoreCase(s) ? "" : s;
	}

	private static final class ParsedField {
		String systemName;
		int sequence;
		int fieldWidth;
		String elementFieldPosition;
		String listOfValues;
	}
}