package com.mmm.system;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.hibernate.SessionFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.Format;

/**
 * Minimal SystemSetup — schema load / save / edit endpoints matching insba.
 * Uses SYSTEM_TX + getCurrentSession (via helpers). Legacy JSON shape: error_code.
 */
@RestController
@RequestMapping("titpl/system")
public class SystemSetup {

	private final SessionFactory sessionFactory;
	private final Gson gson = new Gson();

	public SystemSetup(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private String legacySuccess(Object data) {
		Map<String, Object> result = new LinkedHashMap<>();
		result.put("error_code", 0);
		result.put("status", "success");
		result.put("data", data);
		return gson.toJson(result);
	}

	private String legacyFailure(Object data) {
		Map<String, Object> result = new LinkedHashMap<>();
		result.put("error_code", -1);
		result.put("status", "failure");
		result.put("data", data);
		return gson.toJson(result);
	}

	private boolean isSaveFailed(JSONObject returnData) {
		if (returnData == null) return true;
		Object lastId = returnData.get("last_id");
		String last = lastId == null ? "0" : String.valueOf(lastId);
		if ("0".equals(last) || last.isBlank()) return true;
		Object msgObj = returnData.get("msg");
		if (msgObj != null) {
			String msg = String.valueOf(msgObj).toLowerCase();
			if (msg.contains("exception") || msg.contains("failed") || msg.contains("invalid object")) return true;
		}
		return false;
	}

	@RequestMapping(value = "getGeneralUserSchemaDetails", method = RequestMethod.POST)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String getGeneralUserSchemaDetails(HttpServletRequest request,
			@RequestParam("module_id") String module_id) throws SQLException, ClassNotFoundException {
		GetModuleDetails obj = new GetModuleDetails(sessionFactory);
		JSONObject data_obj = obj.getGeneralUserSchemaDetails(module_id);
		return legacySuccess(data_obj);
	}

	@RequestMapping(value = "AddUserSchemaGeneralDetailsNew", method = RequestMethod.POST)
	@Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String AddUserSchemaGeneralDetailsNew(HttpServletRequest request,
			@RequestParam("fw_save_obj") String jsonString)
			throws SQLException, ClassNotFoundException, ParseException {

		JSONObject json = (JSONObject) new JSONParser().parse(jsonString);
		System.out.println("json...." + json);

		DynamicMasterJsonData saveObj = new DynamicMasterJsonData();

		if (json.containsKey("FW_login_Id"))
			saveObj.FW_login_Id = json.get("FW_login_Id").toString();

		if (json.containsKey("internal_code"))
			saveObj.internal_code = json.get("internal_code").toString();

		if (json.containsKey("header_data_type_arr"))
			saveObj.header_data_type_arr = (JSONObject) json.get("header_data_type_arr");

		if (json.containsKey("save_schema_details_arr"))
			saveObj.save_schema_details_arr = (JSONObject) json.get("save_schema_details_arr");

		if (json.containsKey("group_details_arr"))
			saveObj.group_details_arr = (JSONObject) json.get("group_details_arr");

		if (json.containsKey("system_module_table_name"))
			saveObj.system_module_table_name = json.get("system_module_table_name").toString();

		String login_user_int_code = Format.GetSessonUserIntCode(request);
		DynamicModuleDetails obj = new DynamicModuleDetails(sessionFactory);
		JSONObject return_data_obj = obj.AddUserSchemaGeneralDetailsNew(saveObj, login_user_int_code);
		if (isSaveFailed(return_data_obj)) {
			return legacyFailure(return_data_obj);
		}
		return legacySuccess(return_data_obj);
	}

	@RequestMapping(value = "GetSchemaModuleDetailsForUpdateNew", method = RequestMethod.POST)
	@Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
	public @ResponseBody String GetSchemaModuleDetailsForUpdateNew(HttpServletRequest request,
			@RequestParam("internal_code") String internal_code, @RequestParam("table_name") String table_name)
			throws SQLException, ClassNotFoundException, ParseException {
		DynamicModuleDetails obj = new DynamicModuleDetails(sessionFactory);
		JSONObject return_data_obj = obj.GetSchemaModuleDetailsForUpdateNew(internal_code, table_name);
		return legacySuccess(return_data_obj);
	}
}
