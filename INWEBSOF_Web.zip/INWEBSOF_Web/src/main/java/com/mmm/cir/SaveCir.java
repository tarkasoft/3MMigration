package com.mmm.cir;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/**
 * Saves a customer CIR request in one transaction. A failure rolls the open
 * transaction back so a partial header or line is not left behind.
 */
final class SaveCir {
	private static final Logger logger = LoggerFactory.getLogger(SaveCir.class);
	private static final ThreadLocal<List<String>> SQL_LOG = new ThreadLocal<>();
	static final long MAX_DOCUMENT_BYTES = 5L * 1024 * 1024;

	private final HibernateFactoryRegistry registry;
	private final CirRequestsSql lookups;

	SaveCir(HibernateFactoryRegistry registry, CirRequestsSql lookups) {
		this.registry = registry;
		this.lookups = lookups;
	}

	Map<String, Object> save(String customerCode, String loginId, long editRequestId,
			Map<String, Object> header, List<Map<String, Object>> lines) {
		if (header == null) throw new IllegalArgumentException("Request details are required.");
		if (lines == null || lines.isEmpty()) {
			throw new IllegalArgumentException("Select at least one invoice line.");
		}
		String invoiceNo = text(header.get("invoiceNo"));
		String invoiceDate = text(header.get("invoiceDate"));
		String remarks = text(header.get("remarks"));
		String contact = text(header.get("contactName"));
		String email = text(header.get("email"));
		String phone = text(header.get("phone"));
		String creditDebit = text(header.get("creditDebit"));
		String materialReturn = text(header.get("materialReturn"));
		String amountType = text(header.get("amountType"));
		String customerReason = text(header.get("customerReason"));
		String complaintType = text(header.get("complaintType"));
		String causeCode = text(header.get("causeCode"));
		String reasonCode = text(header.get("reasonCode"));
		String stockCategory = text(header.get("stockCategory"));
		String sentSample = text(header.get("sentSample"));
		String sampleDocket = text(header.get("sampleDocket"));
		String cfrNumber = text(header.get("cfrNumber"));
		String outOfPolicy = text(header.get("outOfPolicy"));
		String oopJustification = text(header.get("oopJustification"));
		String groupName = namePart(text(header.get("group")));
		validate(invoiceNo, invoiceDate, remarks, contact, email, creditDebit, materialReturn, amountType,
				reasonCode, stockCategory, sentSample, sampleDocket, outOfPolicy, oopJustification,
				groupName, cfrNumber);
		Map<String, Object> cause = cause(causeCode, complaintType, customerReason);
		String editType = text(cause.get("edit_type"));
		boolean taxEditable = "Tax".equalsIgnoreCase(editType);
		String taxFlag = "No".equals(materialReturn)
				? text(cause.get("tax_for_non_material_return"))
				: text(cause.get("tax_for_material_return"));
		boolean taxApplies = !"No".equalsIgnoreCase(taxFlag);
		String savedStockCategory = "STOCK".equals(reasonCode) ? stockCategory : "";
		String savedSentSample = "PRDQUA".equals(reasonCode) ? sentSample : "";
		String savedSampleDocket = "Yes".equals(sentSample) && "PRDQUA".equals(reasonCode) ? sampleDocket : "";
		String savedCfrNumber = "PRDQUA".equals(reasonCode) && "HCBG".equalsIgnoreCase(groupName) ? cfrNumber : "";
		String savedOutOfPolicy = outOfPolicy.isBlank() ? "No" : outOfPolicy;
		String customerType = text(header.get("customerType"));
		List<CalculatedLine> calculatedLines = calculateLines(customerCode, invoiceNo, editRequestId, amountType,
				taxEditable, taxApplies, lines);
		BigDecimal runningTotal = BigDecimal.ZERO;
		String billedTaxType = "";
		String billedOrderNo = "";
		for (CalculatedLine line : calculatedLines) {
			runningTotal = runningTotal.add(line.claimAmount);
			if (billedTaxType.isBlank()) billedTaxType = text(line.billed.get("tax_type"));
			if (billedOrderNo.isBlank()) billedOrderNo = text(line.billed.get("order_no"));
		}
		if (runningTotal.signum() <= 0) {
			throw new IllegalArgumentException("Total Amount should be greater than zero.");
		}
		String division = codePart(text(header.get("division")));
		String group = codePart(text(header.get("group")));
		String warehouse = text(header.get("warehouse"));
		if (division.isBlank() || group.isBlank() || warehouse.isBlank()) {
			throw new IllegalArgumentException("Reselect the invoice so Group, Division, and Warehouse are filled.");
		}
		BigDecimal total = runningTotal;
		String taxType = billedTaxType.isBlank() ? "Both" : billedTaxType;
		String orderNo = billedOrderNo;
		SQL_LOG.set(new ArrayList<>());
		try {
			Map<String, Object> result = registry.withSession(HibernateFactoryRegistry.CIR, session -> {
				Transaction transaction = session.beginTransaction();
				try {
					long requestId = editRequestId;
					String ticket;
					if (editRequestId <= 0) {
						ticket = nextTicket(session);
						String insert = """
								insert into cc_customer_complaints(
									cfr_number, modified_date, resubmitted_date, cc_inv_cust_reason, cir_main_type,
									customer_contact_name, sample_docket_no, sent_sample, customer_email, request_src,
									qty_price_edit_type, original_total_amt, inv_order_no, tax_type, amount_type,
									requester, cust_phNo, type, complaint_status, cust_remarks, created_date, date,
									ticket_number, customer, invoice_date, invoice_no, complaint_type, category,
									failure_code, cause_code, wh_code, div_code, claim_amt, total_amt, assign_to,
									stage, claiming_fri_amt, freight_tot_amount, ship_to_code, group_code,
									sales_rep, sales_rep_name, cust_type, fright_type, fright_tax_perc,
									cc_f_tax1_perc, cc_f_tax2_perc, cc_f_tax1_name, cc_f_tax2_name,
									material_return, credit_debit, reason_category_code, out_of_policy,
									oop_justification, created_enl_id, ui_status, reassign_to_cust)
								values (?, getdate(), getdate(), ?, 'CIR', ?, ?, ?, ?, 'Customer', ?, ?, ?, ?, ?,
									'CUSTOMER', ?, 'CIR', 'New', ?, getdate(), getdate(), ?, ?, convert(date, ?, 23), ?,
									?, ?, '0', '0', ?, ?, ?, ?, '0', '0', '0', '0', '0', ?, '', '', ?,
									'0', '0', '0', '0', '0', '0', ?, ?, ?, ?, ?, ?, 'New', 'No')
								""";
						update(session, "CIR header insert", insert,
								savedCfrNumber,
								customerReason,
								contact,
								savedSampleDocket,
								savedSentSample,
								email,
								editType,
								total,
								orderNo,
								taxType,
								amountType,
								phone,
								remarks,
								ticket,
								customerCode,
								invoiceDate,
								invoiceNo,
								complaintType,
								causeCode,
								warehouse,
								division,
								total,
								total,
								group,
								customerType,
								materialReturn,
								creditDebit,
								savedStockCategory,
								savedOutOfPolicy,
								oopJustification,
								loginId);
						requestId = identity(session);
					} else {
						List<Map<String, Object>> existing = query(session, """
								select ticket_number from cc_customer_complaints
								where internal_code = ? and customer = ? and request_src = 'Customer'
									and reassign_to_cust = 'Yes'
								""", editRequestId, customerCode);
						if (existing.isEmpty()) {
							throw new IllegalArgumentException("This request is not open for rework.");
						}
						ticket = text(existing.get(0).get("ticket_number"));
						int updated = update(session, "CIR header rework", """
								update cc_customer_complaints
								set reassign_to_cust = 'No', customer_contact_name = ?, sent_sample = ?,
									sample_docket_no = ?, cfr_number = ?, qty_price_edit_type = ?, inv_order_no = ?,
									tax_type = ?, amount_type = ?, cust_phNo = ?, complaint_status = 'Resubmitted',
									cust_remarks = ?, customer = ?, invoice_date = convert(date, ?, 23),
									invoice_no = ?, complaint_type = ?, category = ?, wh_code = ?, div_code = ?,
									claim_amt = ?, total_amt = ?, group_code = ?, cust_type = ?,
									material_return = ?, credit_debit = ?, reason_category_code = ?,
									out_of_policy = ?, oop_justification = ?, cc_inv_cust_reason = ?,
									ui_status = 'Resubmitted',
									resubmitted_date = getdate(),
									modified_date = getdate()
								where internal_code = ? and customer = ? and request_src = 'Customer'
									and reassign_to_cust = 'Yes'
								""",
								contact,
								savedSentSample,
								savedSampleDocket,
								savedCfrNumber,
								editType,
								orderNo,
								taxType,
								amountType,
								phone,
								remarks,
								customerCode,
								invoiceDate,
								invoiceNo,
								complaintType,
								causeCode,
								warehouse,
								division,
								total,
								total,
								group,
								customerType,
								materialReturn,
								creditDebit,
								savedStockCategory,
								savedOutOfPolicy,
								oopJustification,
								customerReason,
								editRequestId,
								customerCode);
						if (updated != 1) {
							throw new IllegalArgumentException("This request is not open for rework.");
						}
						update(session, "CIR lot delete",
								"delete from cir_complaint_item_lot_group where header_int_code = ?", editRequestId);
						update(session, "CIR line delete",
								"delete from cc_customer_complaints_items_group where ref_s_ref_data_code = ?",
								editRequestId);
					}
					insertLines(session, requestId, calculatedLines);
					String historyStatus = editRequestId > 0 ? "Resubmitted" : "Submitted";
					update(session, "CIR history insert", """
							insert into cc_customer_complaints_history(
								ref_s_ref_data_code, updated_by, approver_status, approver_remarks,
								created_by, created_date, modified_by, modified_date, updated_date,
								approver_type, approver_role_status)
							values (?, ?, ?, ?, ?, getdate(), ?,
								getdate(),
								getdate(), 'Customer', ?)
							""",
							requestId,
							loginId,
							historyStatus,
							remarks,
							loginId,
							loginId,
							historyStatus);
					transaction.commit();
					Map<String, Object> saved = new LinkedHashMap<>();
					saved.put("internal_code", requestId);
					saved.put("ticket_number", ticket);
					saved.put("message", editRequestId > 0
							? "Request " + ticket + " was resubmitted."
							: "Request " + ticket + " was saved.");
					return saved;
				} catch (RuntimeException ex) {
					rollback(transaction);
					if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
						throw ex;
					}
					logger.error("CIR save rolled back for customer {}", customerCode, ex);
					throw new IllegalStateException("The request was not saved. Nothing was stored.");
				}
			});
			List<String> queries = SQL_LOG.get();
			result.put("queries", queries == null ? List.of() : List.copyOf(queries));
			return result;
		} finally {
			SQL_LOG.remove();
		}
	}

	private static void validate(String invoiceNo, String invoiceDate, String remarks, String contact, String email,
			String creditDebit, String materialReturn, String amountType, String reasonCode, String stockCategory,
			String sentSample, String sampleDocket, String outOfPolicy, String oopJustification,
			String groupName, String cfrNumber) {
		if (invoiceNo.isBlank() || invoiceDate.isBlank()) {
			throw new IllegalArgumentException("Select an invoice from the search list first.");
		}
		if (contact.isBlank()) throw new IllegalArgumentException("Customer Contact Name cannot be empty.");
		if (email.isBlank() || !email.matches("(?i)^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
			throw new IllegalArgumentException("Enter a valid customer email.");
		}
		if (remarks.isBlank()) throw new IllegalArgumentException("Please enter a description.");
		if (!creditDebit.equals("Credit") && !creditDebit.equals("Debit")) {
			throw new IllegalArgumentException("Please select Credit/Debit.");
		}
		if (!materialReturn.equals("Yes") && !materialReturn.equals("No")) {
			throw new IllegalArgumentException("Please select Material Return.");
		}
		if (!amountType.equals("Normal") && !amountType.equals("Flat")) {
			throw new IllegalArgumentException("Please select CIR Type.");
		}
		if ("Debit".equals(creditDebit) && "Yes".equals(materialReturn)) {
			throw new IllegalArgumentException("Material Return cannot be Yes for a Debit Note.");
		}
		if ("Yes".equals(materialReturn) && "Flat".equals(amountType)) {
			throw new IllegalArgumentException("CIR Type should be Normal when Material Return is Yes.");
		}
		if ("STOCK".equals(reasonCode) && stockCategory.isBlank()) {
			throw new IllegalArgumentException("Please select Stock Category.");
		}
		if ("PRDQUA".equals(reasonCode) && !"Yes".equals(sentSample) && !"No".equals(sentSample)) {
			throw new IllegalArgumentException("Please select Sent Samples.");
		}
		if ("PRDQUA".equals(reasonCode) && "Yes".equals(sentSample) && sampleDocket.isBlank()) {
			throw new IllegalArgumentException("Please enter Sent Docket No.");
		}
		if ("PRDQUA".equals(reasonCode) && "HCBG".equalsIgnoreCase(groupName) && cfrNumber.isBlank()) {
			throw new IllegalArgumentException("Please Enter CFR Number");
		}
		if ("Yes".equalsIgnoreCase(outOfPolicy)
				&& oopJustification.replaceAll("[^A-Za-z0-9]", "").length() < 20) {
			throw new IllegalArgumentException("Out of policy justification should be at least 20 characters.");
		}
	}

	private Map<String, Object> cause(String causeCode, String complaintType, String customerReason) {
		String causeSql = """
				select top 1 isnull(edit_type, '') as edit_type,
					isnull(tax_for_material_return, 'Yes') as tax_for_material_return,
					isnull(tax_for_non_material_return, 'Yes') as tax_for_non_material_return
				from cc_complaint_category
				where cast(internal_code as varchar(20)) = ?
				""";
		printSql("CIR cause lookup", causeSql, causeCode);
		List<Map<String, Object>> causeRows = NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.CIR,
				causeSql, causeCode);
		if (complaintType.isBlank() || causeRows.isEmpty() || customerReason.isBlank()) {
			throw new IllegalArgumentException("Please select Customer Reason.");
		}
		return causeRows.get(0);
	}

	private List<CalculatedLine> calculateLines(String customerCode, String invoiceNo, long editRequestId,
			String amountType, boolean taxEditable, boolean taxApplies, List<Map<String, Object>> lines) {
		Map<String, Map<String, Object>> billedByLine = new LinkedHashMap<>();
		for (Map<String, Object> billed : lookups.invoiceLineItems(customerCode, invoiceNo, editRequestId)) {
			billedByLine.put(text(billed.get("item_code")) + "|" + text(billed.get("line_no")), billed);
		}
		List<CalculatedLine> preparedLines = new ArrayList<>();
		for (Map<String, Object> line : lines) {
			Map<String, Object> billed = billedByLine.get(text(line.get("itemCode")) + "|" + text(line.get("lineNo")));
			if (billed == null) {
				throw new IllegalArgumentException("A selected line is no longer available on this invoice.");
			}
			BigDecimal balance = decimal(billed.get("balance_qty"));
			BigDecimal billRate = decimal(billed.get("bill_rate"));
			BigDecimal qty = "Flat".equals(amountType) ? BigDecimal.ZERO : decimal(line.get("quantity"));
			BigDecimal rate = "Flat".equals(amountType) ? BigDecimal.ZERO : decimal(line.get("differencePrice"));
			BigDecimal flat = "Flat".equals(amountType) ? decimal(line.get("flatAmount")) : BigDecimal.ZERO;
			if ("Flat".equals(amountType)) {
				if (flat.signum() <= 0) throw new IllegalArgumentException("Flat Amount should be greater than zero.");
			} else {
				if (qty.signum() <= 0) throw new IllegalArgumentException("Actual Return Qty should be greater than zero.");
				if (qty.compareTo(balance) > 0) {
					throw new IllegalArgumentException("Actual Return Qty cannot exceed the balance quantity.");
				}
				if (rate.compareTo(billRate) > 0) {
					throw new IllegalArgumentException("Difference Price cannot exceed the billed price.");
				}
			}
			BigDecimal cgst = taxEditable ? decimal(line.get("cgstRate")) : decimal(billed.get("cgst_rate"));
			BigDecimal sgst = taxEditable ? decimal(line.get("sgstRate")) : decimal(billed.get("sgst_rate"));
			BigDecimal igst = taxEditable ? decimal(line.get("igstRate")) : decimal(billed.get("igst_rate"));
			BigDecimal actual = money(qty.multiply(rate));
			BigDecimal tax = !taxApplies || "Flat".equals(amountType) ? BigDecimal.ZERO
					: money(actual.multiply(cgst.add(sgst).add(igst))
							.divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP));
			BigDecimal claim = "Flat".equals(amountType) ? money(flat) : money(actual.add(tax));
			preparedLines.add(new CalculatedLine(billed, qty, rate, flat, cgst, sgst, igst, actual, tax, claim));
		}
		return preparedLines;
	}

	private void insertLines(Session session, long requestId, List<CalculatedLine> preparedLines) {
		String sql = """
				insert into cc_customer_complaints_items_group(
					nine_mth_tax_applicable, original_qty, original_claim_amt, act_flat_amt,
					ref_s_ref_data_code, item_code, item_desc, bill_qty, bill_rate, bill_val,
					tax_rate1, tax_rate2, tax_rate3, tax1_val, tax2_val, tax3_val, bill_tax_val,
					item_val, act_qty, act_rate, act_val, act_tax_val, act_item_val, claim_amt,
					created_by, created_date, modified_by, modified_date, line_no, tax_name1,
					tax_name2, tax_name3, act_tax_rate1, act_tax_rate2, act_tax_rate3,
					is_lot_available, order_no)
				values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
					0, getdate(), 0,
					getdate(), ?, ?, ?, ?, ?, ?, ?, ?, ?)
				""";
		for (CalculatedLine line : preparedLines) {
			Map<String, Object> billed = line.billed;
			BigDecimal billedTax = money(decimal(billed.get("sgst"))
					.add(decimal(billed.get("cgst"))).add(decimal(billed.get("igst"))));
			update(session, "CIR line insert", sql,
					text(billed.get("nine_mth_tax_applicable")),
					line.quantity,
					line.claimAmount,
					line.flatAmount,
					requestId,
					text(billed.get("item_code")),
					text(billed.get("item_desc")),
					decimal(billed.get("bill_qty")),
					decimal(billed.get("bill_rate")),
					decimal(billed.get("bill_val")),
					line.cgstRate,
					line.sgstRate,
					line.igstRate,
					decimal(billed.get("cgst")),
					decimal(billed.get("sgst")),
					decimal(billed.get("igst")),
					billedTax,
					decimal(billed.get("bill_val")),
					line.quantity,
					line.differencePrice,
					line.actualValue,
					line.taxAmount,
					line.claimAmount,
					line.claimAmount,
					text(billed.get("line_no")),
					text(billed.get("cgst_name")),
					text(billed.get("sgst_name")),
					text(billed.get("igst_name")),
					line.cgstRate,
					line.sgstRate,
					line.igstRate,
					text(billed.get("lot_controlled")),
					text(billed.get("order_no")));
		}
	}

	private String nextTicket(Session session) {
		int updated = update(session, "CIR ticket number", """
				update cc_code_generator set last_no = last_no + 1
				where year_code = year(getdate())
				""");
		if (updated != 1) {
			throw new IllegalStateException("CIR ticket numbering is not configured for this year.");
		}
		List<Map<String, Object>> rows = query(session, """
				select cast(last_no as varchar(20)) as last_no,
					right(left(convert(varchar, getdate(), 112), 6), 4) as month_year
				from cc_code_generator
				where year_code = year(getdate())
				""");
		if (rows.isEmpty()) {
			throw new IllegalStateException("CIR ticket numbering is not configured for this year.");
		}
		String number = text(rows.get(0).get("last_no")).split("\\.")[0];
		String monthYear = text(rows.get(0).get("month_year"));
		return monthYear + "0".repeat(Math.max(0, 5 - number.length())) + number;
	}

	private long identity(Session session) {
		List<Map<String, Object>> rows = query(session, "select cast(scope_identity() as bigint) as internal_code");
		if (rows.isEmpty() || rows.get(0).get("internal_code") == null) {
			throw new IllegalStateException("The CIR request was not saved.");
		}
		return Long.parseLong(text(rows.get(0).get("internal_code")).split("\\.")[0]);
	}

	private int update(Session session, String label, String sql, Object... parameters) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		String rendered = printSql(label, sql, parameters);
		List<String> logged = SQL_LOG.get();
		if (logged != null) logged.add(label + ":\n" + rendered + ";");
		return NativeQuerySupport.executeUpdateInSession(session, sql, parameters);
	}

	private List<Map<String, Object>> query(Session session, String sql, Object... parameters) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		printSql("CIR select", sql, parameters);
		return NativeQuerySupport.executeQueryInSession(session, sql, parameters);
	}

	private static String printSql(String label, String sql, Object... parameters) {
		String rendered = SqlDebugFormatter.render(sql, parameters).replaceAll("[\\t ]+", " ")
				.replaceAll("\\s*\\n\\s*", " ").trim();
		System.out.println("CIR SQL [" + label + "]\n" + rendered + ";");
		logger.info("CIR {} SQL: {}", label, rendered);
		return rendered;
	}

	private static void rollback(Transaction transaction) {
		if (transaction != null && transaction.isActive()) {
			transaction.rollback();
		}
	}

	private static String codePart(String value) {
		String trimmed = value == null ? "" : value.trim();
		int split = trimmed.indexOf('-');
		return split < 0 ? trimmed : trimmed.substring(0, split).trim();
	}

	/** Name/code after the first hyphen, e.g. {@code 4-HCBG} → {@code HCBG}. */
	private static String namePart(String value) {
		String trimmed = value == null ? "" : value.trim();
		int split = trimmed.indexOf('-');
		return split < 0 ? trimmed : trimmed.substring(split + 1).trim();
	}

	private static BigDecimal decimal(Object value) {
		if (value == null || String.valueOf(value).isBlank()) return BigDecimal.ZERO;
		try {
			return new BigDecimal(String.valueOf(value).replace(",", "").replace("%", "").trim());
		} catch (NumberFormatException ex) {
			return BigDecimal.ZERO;
		}
	}

	private static BigDecimal money(BigDecimal value) {
		return value.setScale(2, RoundingMode.HALF_UP);
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static final class CalculatedLine {
		final Map<String, Object> billed;
		final BigDecimal quantity;
		final BigDecimal differencePrice;
		final BigDecimal flatAmount;
		final BigDecimal cgstRate;
		final BigDecimal sgstRate;
		final BigDecimal igstRate;
		final BigDecimal actualValue;
		final BigDecimal taxAmount;
		final BigDecimal claimAmount;

		CalculatedLine(Map<String, Object> billed, BigDecimal quantity, BigDecimal differencePrice,
				BigDecimal flatAmount, BigDecimal cgstRate, BigDecimal sgstRate, BigDecimal igstRate,
				BigDecimal actualValue, BigDecimal taxAmount, BigDecimal claimAmount) {
			this.billed = billed;
			this.quantity = quantity;
			this.differencePrice = differencePrice;
			this.flatAmount = flatAmount;
			this.cgstRate = cgstRate;
			this.sgstRate = sgstRate;
			this.igstRate = igstRate;
			this.actualValue = actualValue;
			this.taxAmount = taxAmount;
			this.claimAmount = claimAmount;
		}
	}
}
