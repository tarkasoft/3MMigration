package com.mmm.cir;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import com.mmm.config.HibernateFactoryRegistry;

import jakarta.annotation.PostConstruct;

/**
 * CIR Hibernate facade — lazy SessionFactory via registry (separate pool from system).
 */
@Component
public class CirHybernetUtil {

    private static HibernateFactoryRegistry registry;

    private final HibernateFactoryRegistry injectedRegistry;

    public CirHybernetUtil(HibernateFactoryRegistry injectedRegistry) {
        this.injectedRegistry = injectedRegistry;
    }

    @PostConstruct
    void init() {
        registry = injectedRegistry;
    }

    /** Builds CIR SessionFactory on first call (lazy). Do not close from request code. */
    public static SessionFactory getSessionFactory() {
        if (registry == null) {
            throw new IllegalStateException("CirHybernetUtil not initialized by Spring yet");
        }
        return registry.getCirSessionFactory();
    }
}