package com.mmm.cir;

import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;
import org.hibernate.Transaction;

final class CirRequestsSql {
	private static final Logger logger = LoggerFactory.getLogger(CirRequestsSql.class);
	private static final String REQUESTS_SQL = """
			select
				isnull(cc.credit_note_no, '') as credit_note_no,
				isnull(convert(varchar(10), cc.credit_note_date, 23), '') as credit_note_date,
				cast(scm.CCUST as varchar(10)) + '-' + scm.CNME as customer,
				cc.invoice_no as invoice_no,
				cc.invoice_date as invoice_date,
				cc.internal_code as internal_code,
				isnull(ct.type, '') as complaint_type,
				isnull(ct.code, '') as reason_short_code,
				isnull(cr.category, '-') as category,
				isnull(cr.sap_reason_code + '-' + cr.sap_reason_desc, '') as sap_reason,
				isnull(cr.sap_category, '-') as sap_category,
				isnull(ia.enl_id + '-' + ia.name, '') as pending_with,
				convert(varchar(10), cc.created_date, 103) as cir_date,
				cc.ticket_number as cir_no,
				cc.total_amt as total_amt,
				case
					when cc.reassign_to_cust = 'Yes' then 'Rework'
					when cc.ui_status = 'Rejected' then 'Rejected'
					when cc.ui_status = 'Closed' then 'Closed'
					else 'In Progress'
				end as ui_status,
				ccr.name as customer_reason
			from cc_customer_complaints cc
			left join cc_complaint_type ct on ct.internal_code = cc.complaint_type
			left join cc_customer_reason ccr on ccr.internal_code = cc.cc_inv_cust_reason
			left join cc_complaint_category cr on cr.internal_code = cc.category
			inner join SO_CustomerMaster scm on scm.CCUST = cc.customer
			left join ia_user_master ia on ia.enl_id = cc.pending_with
			where cc.customer = ?
				and cc.request_src = 'Customer'
			order by cc.ticket_number desc
			""";

	private final HibernateFactoryRegistry registry;

	CirRequestsSql(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	Map<String, Object> customer(String portalCustomerCode) {
		String sql = "select top 2 rtrim(cast(sc.CCUST as varchar(30))) as cust_code, "
				+ "isnull(rtrim(sc.CNME), '') as cust_name, "
				+ "isnull(case when ecom.cust_type is null then sc.CTYPE else ecom.cust_type end, '') as customer_type, "
				+ "isnull(rtrim(sc.CPHON), '') as customer_phone, "
				+ "isnull(rtrim(sc.CMDATN), '') as customer_email, "
				+ "isnull(rtrim(sc.CCON), '') as customer_contact_name, "
				+ "case when sc.CREF01='S' then 'South' when sc.CREF01='E' then 'East' "
				+ "when sc.CREF01='W' then 'West' when sc.CREF01='N' then 'North' else '' end as customer_region "
				+ "from SO_CustomerMaster sc left join cc_ecom_customers ecom "
				+ "on ecom.cust_code = cast(sc.CCUST as varchar(30)) "
				+ "where rtrim(cast(sc.CCUST as varchar(30))) = ?";
		logSql(HibernateFactoryRegistry.CIR, sql, portalCustomerCode.trim());
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(registry,
				HibernateFactoryRegistry.CIR, sql, portalCustomerCode.trim());
		if (rows.size() != 1) {
			throw new IllegalArgumentException(rows.isEmpty()
					? "The selected customer was not found in the customer master."
					: "The selected customer code is ambiguous in the customer master.");
		}
		return rows.get(0);
	}

	Map<String, Object> newRequestLookups(String customerCode, String loginId, String roles) {
		Map<String, Object> data = new LinkedHashMap<>();
		Map<String, Object> customer = customer(customerCode);
		data.put("Custcode", customer.get("cust_code"));
		data.put("loginId", loginId);
		data.put("loginName", sessionUserName(loginId));
		data.put("g_customer_details", List.of(Map.of(
				"value", text(customer.get("cust_code")) + "-" + text(customer.get("cust_name")),
				"CTYPE", text(customer.get("customer_type")),
				"CPHON", text(customer.get("customer_phone")),
				"email", text(customer.get("customer_email")),
				"customer_region", text(customer.get("customer_region")),
				"customer_contact_name", text(customer.get("customer_contact_name")))));

		int oopDays = scalarInt("select isnull(inpc_oop_days, 90) as oop_days from cir_setup", 90);
		String roleFilter = hasRole(roles, "CIR_ADMIN", "CIR_REQUESTOR_ALL_CATEGORY")
				? "" : " and role_type = 'Non-Restricted' ";
		String reasonSql = "select isnull(ticket_type, '') as ticket_type, " + oopDays
				+ " as oop_days, isnull(code, '') as code, type as reason_code, "
				+ "internal_code, isnull(role_type, '') as role_type "
				+ "from cc_complaint_type where ticket_type = 'CIR' "
				+ "and isnull(active, 'Yes') = 'Yes'" + roleFilter + " order by sequence";
		data.put("g_cir_reason_details", query(reasonSql));
		data.put("g_customer_reason_details", query("""
				select internal_code as reason_int_code, name as reason_code,
					sap_main_code as category, sap_sub_code as sub_categoty
				from cc_customer_reason
				where active = 'Yes'
				order by sequence
				"""));
		data.put("g_cir_cause_details", query("""
				select type as reason_int_code, internal_code as cause_int_code,
					category as cause_code, isnull(sap_reason_code, '') as sap_reason_code,
					isnull(c_amount_type_for_non_mat_return, '') as c_amount_type_for_non_mat_return,
					isnull(sap_reason_desc, '') as sap_reason_desc,
					isnull(sap_category, '') as sap_category,
					isnull(edit_type, '') as edit_type,
					isnull(c_amount_type, 'Normal') as amount_type,
					isnull(tax_appl_on_flat, 'No') as tax_appl_on_flat,
					isnull(sp_line_calc_type, '') as sp_line_calc_type,
					isnull(return_material, 'Both') as return_material,
					isnull(c_credit_debit, 'Both') as credit_debit,
					isnull(short_code, '') as short_code,
					isnull(usage_example, '') as usage_example,
					isnull(tax_for_non_material_return, '') as tax_for_non_material_return,
					isnull(tax_for_material_return, '') as tax_for_material_return,
					isnull(return_type, '') as return_type,
					isnull(einstien_report_category, '') as einstien_report_category
				from cc_complaint_category
				where isnull(active, 'Yes') = 'Yes'
				"""));
		data.put("g_cir_stock_category_details", query("""
				select cs.stock_category, cs.internal_code, cg.code as div_code
				from cc_rdm_reversal_nsm cr
				inner join cc_stock_reversal_category cs on cs.internal_code = cr.category
				inner join cc_accounting_division cg on cg.internal_code = cr.division
				where isnull(cs.stock_active, 'Yes') = 'Yes'
				"""));
		data.put("g_cir_closed_days",
				scalarText("select isnull(inpc_cir_closed_days, '') as cir_closed_days from cir_setup"));
		List<String> requesterWarehouses = hasRole(roles, "CIR_WAREHOUSE_REQUESTER")
				? requesterWarehouseCodes(loginId) : List.of();
		data.put("requester_wharehouse", requesterWarehouses.stream()
				.map(code -> "'" + code.replace("'", "''") + "'")
				.collect(java.util.stream.Collectors.joining(",")));
		data.put("edit_details", "");
		return data;
	}

	List<Map<String, Object>> invoiceSuggestions(String phrase, String customerCode,
			String loginId, String roles) {
		boolean warehouseRestricted = hasRole(roles, "CIR_WAREHOUSE_REQUESTER");
		List<String> warehouseCodes = warehouseRestricted
				? requesterWarehouseCodes(loginId) : List.of();
		if (warehouseRestricted && warehouseCodes.isEmpty()) {
			return List.of();
		}
		int oopDays = scalarInt("select isnull(inpc_oop_days, 90) as oop_days from cir_setup", 90);
		StringBuilder sql = new StringBuilder("""
				select distinct top 100 s.OBINV# as value,
					convert(varchar(10), convert(date, convert(varchar(8), s.OBINVD), 112), 23) as inv_date,
					rtrim(s.OBWHS) as warehouse,
					rtrim(g.GRDIVC) + '-' + rtrim(g.GRDIVD) as division,
					rtrim(g.GRGRPC) + '-' + rtrim(g.GRGRPD) as group_code,
					case when s.OBINVD <= convert(int, convert(varchar(8), dateadd(day, -?, getdate()), 112))
						then 'Yes' else 'No' end as out_of_policy,
					case when s.OBINVD > case when month(getdate()) > 9
						then (year(getdate()) * 10000) + 331
						else (year(dateadd(year, -1, getdate())) * 10000) + 331
						end then 'Yes' else 'No' end as nine_mth_tax_applicable,
					datediff(day, convert(date, convert(varchar(8), s.OBINVD), 112), getdate()) as inv_oop_days
				from SO_Sales s
				inner join SO_GrpdivX g on s.OBPDIV = g.GRDIVC
				where s.OBOTYP = 'O'
					and cast(s.OBMCUS as varchar(30)) = ?
					and s.OBINVD >= convert(int, convert(varchar(8), dateadd(day, -?, getdate()), 112))
					and s.OBINV# like ?
				""");
		List<Object> parameters = new java.util.ArrayList<>();
		parameters.add(oopDays);
		parameters.add(customerCode);
		parameters.add(oopDays);
		parameters.add("%" + (phrase == null ? "" : phrase.trim()) + "%");
		if (warehouseCodes != null && !warehouseCodes.isEmpty()) {
			sql.append(" and s.OBWHS in (")
					.append(String.join(",", java.util.Collections.nCopies(warehouseCodes.size(), "?")))
					.append(")");
			parameters.addAll(warehouseCodes);
		}
		sql.append(" order by s.OBINV#");
		return query(sql.toString(), parameters.toArray());
	}

	/** SKUs on this invoice that are lot-controlled but have no lot record yet. Loading must be blocked until these are fixed. */
	List<Map<String, Object>> missingLotDetails(String customerCode, String invoiceNo, int invoiceDateYyyyMmDd) {
		String sql = """
				select a.sales_item, a.items_desc
				from (
					select s.OBPROD as sales_item, s.OBORD as order_no, rtrim(s.OBMDSC) as items_desc
					from SO_Sales s
					inner join SO_ItemMaster si on si.IPROD = s.OBPROD
					where cast(s.OBMCUS as varchar(30)) = ?
						and s.OBOTYP in ('O', 'I')
						and s.OBPTYP not in ('O', '9', 'S')
						and s.OBINV# = ?
						and s.OBINVD = ?
				) a
				left join (
					select IORD, IPROD as eil_item, count(1) as lot_cnt
					from EIL
					where icust = ? and IINVN = substring(?, 3, 12)
					group by IORD, IPROD
				) b on a.sales_item = b.eil_item and a.order_no = b.IORD
				where isnull(b.eil_item, '') = ''
				""";
		return query(sql, customerCode, invoiceNo, invoiceDateYyyyMmDd, customerCode, invoiceNo);
	}

	/** Billed lines for the invoice, with quantities already claimed on other (non-rejected) requests excluded. */
	List<Map<String, Object>> invoiceLineItems(String customerCode, String invoiceNo) {
		return invoiceLineItems(customerCode, invoiceNo, 0);
	}

	List<Map<String, Object>> invoiceLineItems(String customerCode, String invoiceNo, long excludeRequestId) {
		String sql = """
				select
					a.item_code, a.item_desc, a.line_no, a.order_no, a.order_type,
					a.warehouse_code, a.division, a.bill_qty,
					(cast(a.bill_qty as decimal(18, 4)) - isnull(b.claimed_qty, 0)) as balance_qty,
					a.bill_rate, a.bill_val, a.freight_amt, a.lot_controlled,
					a.sgst, a.cgst, a.igst, a.sgst_name, a.cgst_name, a.igst_name,
					isnull(ct1.tax_rate, 0) as tax_rate1, isnull(ct2.tax_rate, 0) as tax_rate2,
					case when isnull(a.cgst_name, '') <> '' then isnull(ct2.tax_rate, 0) else 0 end as cgst_rate,
					case when isnull(a.sgst_name, '') not in ('', '0') then isnull(ct1.tax_rate, 0) else 0 end as sgst_rate,
					case when isnull(a.igst_name, '') <> '' then isnull(ct1.tax_rate, 0) else 0 end as igst_rate,
					a.tax_type, a.nine_mth_tax_applicable
				from (
					select rtrim(s.OBINV#) as inv_no, cast(s.OBMCUS as varchar(30)) as cust_code,
						s.OBORD as order_no, rtrim(s.OBWHS) as warehouse_code,
						rtrim(s.OBPTYP) as order_type, rtrim(s.OBPDIV) as division,
						rtrim(s.OBPROD) as item_code, rtrim(s.OBFRAMT) as freight_amt,
						rtrim(s.OBMDSC) as item_desc, rtrim(s.OBLQTY) as bill_qty, s.OBINVL as line_no,
						isnull(rtrim(si.SAFLG), '1') as lot_controlled,
						rtrim(s.OBLPRI) as bill_rate, rtrim(s.OBLAMT) as bill_val,
						case when s.OBTXA2 > 0 then s.OBTXA1 else 0 end as sgst,
						s.OBTXA2 as cgst,
						case when s.OBTXA2 <= 0 then s.OBTXA1 else 0 end as igst,
						case when s.OBTAX2 > '0' then rtrim(s.OBTAX1) else '0' end as sgst_name,
						rtrim(s.OBTAX2) as cgst_name,
						case when s.OBTXA2 <= 0 then s.OBTAX1 else '' end as igst_name,
						s.OBTAX1 as tax_code1, s.OBTAX2 as tax_code2,
						case when rtrim(sw.WMSTE) <> '' and rtrim(sc.CSTE) <> ''
							then case when sw.WMSTE = sc.CSTE then 'SCGST' else 'IGST' end
							else 'Both' end as tax_type,
						case when s.OBINVD > case when month(getdate()) > 9
								then (year(getdate()) * 10000) + 331
								else (year(dateadd(year, -1, getdate())) * 10000) + 331
							end then 'Yes' else 'No' end as nine_mth_tax_applicable
					from SO_Sales s
					left join SO_ItemMaster si on si.IPROD = s.OBPROD
					left join SO_CustomerMaster sc on sc.CCUST = s.OBMCUS
					left join SO_WarehouseMaster sw on sw.LWHS = s.OBWHS
					where s.OBPTYP not in ('O', '9', 'S')
						and s.OBINVD >= convert(int, convert(varchar(8), dateadd(day, -1110, getdate()), 112))
						and cast(s.OBMCUS as varchar(30)) = ?
						and s.OBINV# = ?
				) a
				left join cc_tax_rates ct1 on ct1.tax_code = a.tax_code1
				left join cc_tax_rates ct2 on ct2.tax_code = a.tax_code2
				left join (
					select cc.customer, cc.invoice_no, g.item_code, g.line_no,
						sum(g.act_qty) as claimed_qty
					from cc_customer_complaints cc
					inner join cc_customer_complaints_items_group g on cc.internal_code = g.ref_s_ref_data_code
					where cc.customer = ? and cc.invoice_no = ?
						and isnull(cc.ui_status, '') not in ('Rejected', 'Rectification Entry Passed')
						and (? = 0 or cc.internal_code <> ?)
					group by g.item_code, g.line_no, cc.customer, cc.invoice_no
				) b on b.customer = a.cust_code and a.inv_no = b.invoice_no
					and a.item_code = b.item_code and a.line_no = b.line_no
				order by a.line_no, a.item_code
				""";
		return query(sql, customerCode, invoiceNo, customerCode, invoiceNo,
				excludeRequestId, excludeRequestId);
	}

	/** Freight percent configured per accounting division for this invoice; shown for reference alongside the claim form. */
	List<Map<String, Object>> invoiceFreightDetails(String customerCode, String invoiceNo) {
		String sql = """
				select cf.div_code, cf.description, cf.perc
				from SO_Sales s
				inner join cc_frieght_div_codes cf on cf.div_code = s.OBPDIV
				where cast(s.OBMCUS as varchar(30)) = ? and s.OBINV# = ?
				""";
		return query(sql, customerCode, invoiceNo);
	}

	/** Distinct tax rates configured in the system, for reference when validating tax amounts entered on a claim. */
	List<Map<String, Object>> distinctTaxRates() {
		return query("select distinct tax_rate from cc_tax_rates order by tax_rate");
	}

	private String sessionUserName(String loginId) {
		List<Map<String, Object>> rows = query(
				"select top 1 isnull(name, '') as user_name from ia_user_master where enl_id = ?",
				loginId);
		return rows.isEmpty() ? "" : text(rows.get(0).get("user_name"));
	}

	private List<String> requesterWarehouseCodes(String loginId) {
		String sql = """
				select distinct rtrim(cw.code) as warehouse
				from inv_warehouse_approval_matrix iw
				inner join inv_warehouse_approval_matrix_warehouse_requester_group iwg
					on iw.internal_code = iwg.ref_s_ref_data_code
				inner join cc_warehouse_master cw on iw.warehouse = cw.internal_code
				inner join cc_employee_master ce on ce.internal_code = iwg.requester
				inner join ia_user_master ia on ia.enl_id = ce.employee_code
				where ce.employee_code = ?
				""";
		List<Map<String, Object>> rows = query(sql, loginId);
		return rows.stream().map(row -> text(row.get("warehouse")))
				.filter(value -> !value.isBlank()).toList();
	}

	private int scalarInt(String sql, int fallback) {
		List<Map<String, Object>> rows = query(sql);
		if (rows.isEmpty() || rows.get(0).get("oop_days") == null) return fallback;
		try {
			return Integer.parseInt(String.valueOf(rows.get(0).get("oop_days")));
		} catch (NumberFormatException ex) {
			return fallback;
		}
	}

	private String scalarText(String sql) {
		List<Map<String, Object>> rows = query(sql);
		return rows.isEmpty() ? "" : text(rows.get(0).get("cir_closed_days"));
	}

	private static boolean hasRole(String roles, String... allowed) {
		if (roles == null || roles.isBlank()) return false;
		String[] assigned = roles.toUpperCase(java.util.Locale.ROOT).split("[,;|\\s]+");
		for (String role : assigned) {
			for (String expected : allowed) {
				if (expected.equals(role)) return true;
			}
		}
		return false;
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	List<Map<String, Object>> requests(String cirCustomerCode) {
		logSql(HibernateFactoryRegistry.CIR, REQUESTS_SQL, cirCustomerCode);
		return NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.CIR,
				REQUESTS_SQL, cirCustomerCode);
	}

	Map<String, Object> request(long requestId, String cirCustomerCode) {
		List<Map<String, Object>> headers = query("""
				select cc.internal_code, isnull(cc.ticket_number, '') as cir_no,
					convert(varchar(10), cc.created_date, 103) as cir_date,
					isnull(ir.enl_id + '-' + ir.name, '') as requester,
					isnull(cast(scm.CCUST as varchar(10)) + '-' + scm.CNME, '') as customer_display,
					isnull(cc.cust_type, '') as customer_type,
					isnull(cc.customer_contact_name, '') as customer_contact_name,
					isnull(cc.cust_phNo, '') as customer_phone,
					isnull(cc.customer_email, '') as customer_email,
					isnull(cc.invoice_no, '') as invoice_no,
					isnull(convert(varchar(10), cc.invoice_date, 23), '') as invoice_date,
					isnull(cc.cust_remarks, '') as cust_remarks,
					isnull(cc.complaint_type, '') as complaint_type,
					cc.category, cc.failure_code, cc.cause_code, cc.cc_inv_cust_reason,
					isnull(ccr.name, '') as customer_reason,
					isnull(g.GRDIVC + '-' + g.GRDIVD, '') as business_division,
					isnull(g.GRGRPD, '') as business_group,
					isnull(cc.wh_code, '') as warehouse,
					cc.total_amt, cc.claim_amt, cc.credit_debit, cc.material_return,
					cc.amount_type, cc.tax_type, cc.out_of_policy, cc.oop_justification,
					isnull(cc.sent_sample, '') as sent_sample,
					isnull(cc.sample_docket_no, '') as sample_docket_no,
					isnull(cc.group_code, '') as group_code,
					isnull(cc.reason_category_code, '') as reason_category_code,
					isnull(cc.qty_price_edit_type, '') as edit_type,
					isnull(cc.reassign_to_cust, '') as reassign_to_cust,
					isnull(cc.ui_status, '') as ui_status,
					isnull(cc.pending_with, '') as pending_with,
					isnull(cc.pending_with_role, '') as pending_with_role,
					isnull(cc.rework_remarks, '') as rework_remarks,
					isnull(cc.credit_note_no, '') as credit_note_no,
					isnull(convert(varchar(10), cc.credit_note_date, 23), '') as credit_note_date,
					isnull(cc.debit_no, '') as debit_no,
					isnull(convert(varchar(10), cc.debit_date, 23), '') as debit_date,
					isnull(cc.cfr_number, '') as cfr_number, cc.request_src
				from cc_customer_complaints cc
				inner join SO_CustomerMaster scm on scm.CCUST = cc.customer
				left join ia_user_master ir on ir.enl_id = cc.requester
				left join cc_customer_reason ccr on ccr.internal_code = cc.cc_inv_cust_reason
				left join SO_GrpdivX g on g.GRDIVC = cc.div_code
				where cc.internal_code = ?
					and cc.customer = ?
					and cc.request_src = 'Customer'
				""", requestId, cirCustomerCode);
		if (headers.isEmpty()) {
			return null;
		}
		Map<String, Object> detail = new LinkedHashMap<>();
		detail.put("header", headers.get(0));
		detail.put("invoice_details", query("""
				select ci.item_code, ci.item_desc, ci.line_no, ci.bill_qty, ci.bill_rate,
					ci.bill_val, ci.tax_rate1, ci.tax_rate2, ci.tax_rate3,
					ci.tax1_val, ci.tax2_val, ci.tax3_val, ci.bill_tax_val, ci.item_val,
					ci.act_qty, ci.act_rate, ci.act_val, ci.act_tax_val, ci.act_item_val,
					ci.claim_amt, ci.remarks, ci.lot_no, ci.line_level_status,
					ci.wh_entered_qty, ci.original_qty, ci.original_claim_amt,
					ci.act_tax_rate1, ci.act_tax_rate2, ci.act_tax_rate3, ci.act_flat_amt,
					ci.tax_name1, ci.tax_name2, ci.tax_name3, ci.nine_mth_tax_applicable,
					ci.order_no, ci.is_lot_available
				from cc_customer_complaints_items_group ci
				where ci.ref_s_ref_data_code = ?
				order by ci.line_no, ci.item_code
				""", requestId));
		Object invoiceNo = headers.get(0).get("invoice_no");
		detail.put("billed_lines", invoiceLineItems(cirCustomerCode,
				invoiceNo == null ? "" : String.valueOf(invoiceNo), requestId));
		detail.put("lot_details", query("""
				select ci.item_code, ci.item_desc, ci.line_no as item_line_no,
					ci.bill_qty as billed_qty, ci.act_qty as approved_qty,
					isnull(ci.wh_entered_qty, 0) as wh_appr_qty,
					coalesce(nullif(cir_lot.lot_no, ''), nullif(cc_lot.lot_no, ''), '') as lot_no,
					coalesce(nullif(cir_lot.lot_wh_code, ''), nullif(cc_lot.lot_wh_code, ''), '') as lot_wh_code,
					coalesce(cir_lot.lot_qty, cc_lot.lot_qty, 0) as lot_qty,
					coalesce(cir_lot.lot_act_aty, cc_lot.lot_act_aty, 0) as lot_act_aty,
					coalesce(nullif(cir_lot.lot_location, ''), nullif(cc_lot.lot_location, ''), '') as lot_location,
					coalesce(nullif(cir_lot.sel_location, ''), nullif(cc_lot.sel_location, ''), '') as sel_location,
					isnull(ci.mismatch_type, 'No') as mismatch_type,
					isnull(ci.alternative_item, '') as alternative_item,
					isnull(ci.alternative_lot, '') as alternative_lot
				from cc_customer_complaints_items_group ci
				left join cir_complaint_item_lot_group cir_lot
					on ci.internal_code = cir_lot.item_int_code
					and cir_lot.header_int_code = ci.ref_s_ref_data_code
				left join cc_complaint_item_lot_group cc_lot
					on ci.internal_code = cc_lot.item_int_code
					and cc_lot.header_int_code = ci.ref_s_ref_data_code
				where ci.ref_s_ref_data_code = ?
				order by ci.line_no, ci.item_code, lot_no
				""", requestId));
		detail.put("approver_details", query("""
				select arh.internal_code, arh.approver_role,
					isnull(ia.name, '') as approver, isnull(iu.name, '') as mod_approver,
					arh.sequence, isnull(arh.approval_status, '') as approval_status,
					isnull(arh.approval_remarks, '') as approval_remarks,
					arh.modified_date,
					isnull(arh.approval_type, 'Business Approval') as approval_type
				from cc_customer_complaints_approval_matrix arh
				left join ia_user_master ia on ia.enl_id = arh.approver
				left join ia_user_master iu on iu.enl_id = arh.updated_by
				where arh.ref_s_ref_data_code = ?
				order by try_convert(int, arh.sequence), arh.internal_code
				""", requestId));
		detail.put("history_details", query("""
				select isnull(ia.name, '') as updated_by, arh.updated_date,
					arh.approver_status, arh.approver_remarks,
					case when arh.approver_role_status in
						('Appover1', 'Appover2', 'Appover3', 'Appover4', 'CIR Team')
						then arh.approver_role_status
						else isnull(arh.approver_type, '') end as approver_type
				from cc_customer_complaints_history arh
				left join ia_user_master ia on ia.enl_id = arh.updated_by
				where arh.ref_s_ref_data_code = ?
				order by arh.created_date desc
				""", requestId));
		detail.put("document_details", query("""
				select cd.internal_code as document_id,
					isnull(cc.document_type, '') as doc_name,
					isnull(cd.u_doc_name, '') as file_name,
					isnull(cd.mmm_u_doc_name, '') as mmm_file_name,
					case when coalesce(nullif(cd.u_doc_path, ''), nullif(cd.mmm_u_doc_path, '')) is null
						then 0 else 1 end as has_file,
					isnull(cd.cust_doc_remarks, '') as remarks,
					isnull(cd.re_upload_required, '') as re_upload_required
				from cc_customer_complaints_doc_group cd
				left join cc_document_type cc on cc.internal_code = cd.ref_doc_code
				where cd.ref_s_ref_data_code = ?
				order by cd.row_sequence, cd.internal_code
				""", requestId));
		detail.put("clarification_details", query("""
				select c.internal_code as clarification_id, c.type as clarification_type,
					isnull(ia.enl_id + '-' + ia.name, '') as clarification_given_by,
					c.question as clarification_question,
					isnull(iaa.enl_id + '-' + iaa.name, '') as clarification_raised_by,
					convert(varchar(10), c.request_date, 126) as raised_date,
					isnull(c.answer, '') as answer,
					isnull(ib.enl_id + '-' + ib.name, '') as answered_by,
					isnull(convert(varchar(10), c.answered_date, 126), '') as answered_date
				from cc_customer_complaints_clarifications c
				left join ia_user_master ia on ia.enl_id = c.user_id
				left join ia_user_master iaa on iaa.enl_id = c.clarification_raised_by
				left join ia_user_master ib on ib.enl_id = c.answered_by
				where c.ref_s_ref_data_code = ?
				order by c.row_sequence, c.internal_code
				""", requestId));
		detail.put("frieght_details", query("""
				select type, frieght_desc, gst_applicable, item_base_value,
					frieght_perc, item_tax_perx, item_tax_amount,
					total_frieght_amount, frieght_flat_amount
				from cc_customer_complaints_frieght_group
				where ref_s_ref_data_code = ?
				order by row_sequence, internal_code
				""", requestId));
		detail.put("additional_documents", query("""
				select a.internal_code as attachment_id,
					isnull(a.file_name, '') as file_name,
					case when isnull(a.file_path, '') <> ''
							or datalength(a.attached_file) > 0
						then 1 else 0 end as has_file,
					isnull(a.remarks, '') as remarks,
					case when isnull(a.created_by_enl_id, '') = '' then ''
						when isnull(iu.name, '') = '' then a.created_by_enl_id
						else a.created_by_enl_id + '-' + iu.name end as uploaded_by,
					isnull(convert(varchar(23), a.created_date, 121), '') as uploaded_date
				from cc_customer_complaints_add_atch a
				left join ia_user_master iu on iu.enl_id = a.created_by_enl_id
				where a.ref_s_ref_data_code = ?
				order by a.created_date desc, a.internal_code desc
				""", requestId));
		return detail;
	}

	/**
	 * Required / optional customer documents for a complaint type and cause,
	 * matching legacy {@code GetDocumentForSelectedData}.
	 */
	List<Map<String, Object>> requiredDocumentCatalog(long complaintTypeId, long causeCategoryId,
			long editRequestId) {
		if (complaintTypeId <= 0 || causeCategoryId <= 0) {
			return List.of();
		}
		return query("""
				select isnull(d.document_type, '') as document,
					d.internal_code as document_type_id,
					isnull(d.is_mandatory, 'No') as is_mandatory,
					isnull(cd.u_doc_path, '') as uploaded_path,
					isnull(cd.u_doc_name, '') as uploaded_name,
					isnull(cd.internal_code, 0) as uploaded_doc_id,
					isnull(d.extension, 'All') as extension,
					isnull(d.sequence, '') as sequence
				from cc_document_type d
				left join cc_customer_complaints_doc_group cd
					on cd.ref_doc_code = d.internal_code
					and cd.ref_s_ref_data_code = ?
				where d.category_type = ?
					and d.complaint_type = ?
					and d.document_for in ('Both', 'Customer')
				order by d.sequence
				""", editRequestId, causeCategoryId, complaintTypeId);
	}

	Map<String, Object> requiredDocument(long requestId, long documentId, String cirCustomerCode) {
		List<Map<String, Object>> rows = query("""
				select top 1
					coalesce(nullif(cd.u_doc_path, ''), nullif(cd.mmm_u_doc_path, '')) as file_path,
					case when nullif(cd.u_doc_path, '') is not null
						then coalesce(nullif(cd.u_doc_name, ''), cc.document_type, 'document')
						else coalesce(nullif(cd.mmm_u_doc_name, ''), cc.document_type, 'document')
					end as file_name
				from cc_customer_complaints_doc_group cd
				inner join cc_customer_complaints request
					on request.internal_code = cd.ref_s_ref_data_code
				left join cc_document_type cc on cc.internal_code = cd.ref_doc_code
				where cd.internal_code = ?
					and cd.ref_s_ref_data_code = ?
					and request.customer = ?
					and request.request_src = 'Customer'
				""", documentId, requestId, cirCustomerCode);
		return rows.isEmpty() ? null : rows.get(0);
	}

	Map<String, Object> additionalDocument(long requestId, long attachmentId, String cirCustomerCode) {
		List<Map<String, Object>> rows = query("""
				select top 1 isnull(attachment.file_path, '') as file_path,
					isnull(attachment.file_name, 'document') as file_name,
					attachment.attached_file
				from cc_customer_complaints_add_atch attachment
				inner join cc_customer_complaints request
					on request.internal_code = attachment.ref_s_ref_data_code
				where attachment.internal_code = ?
					and attachment.ref_s_ref_data_code = ?
					and request.customer = ?
					and request.request_src = 'Customer'
				""", attachmentId, requestId, cirCustomerCode);
		return rows.isEmpty() ? null : rows.get(0);
	}

	void answerClarification(long requestId, long clarificationId, String cirCustomerCode,
			String loginId, String answer) {
		registry.withSession(HibernateFactoryRegistry.CIR, session -> {
			Transaction transaction = session.beginTransaction();
			try {
				String answerSql = """
						update clarification
						set answer = ?, answered_by = ?,
							answered_date = getdate()
						from cc_customer_complaints_clarifications clarification
						inner join cc_customer_complaints request
							on request.internal_code = clarification.ref_s_ref_data_code
						where clarification.internal_code = ?
							and clarification.ref_s_ref_data_code = ?
							and clarification.type = 'Request'
							and isnull(clarification.answer, '') = ''
							and request.customer = ?
							and request.request_src = 'Customer'
						""".replace("getdate()", UserSessionSupport.sessionDate());
				logSql(HibernateFactoryRegistry.CIR, answerSql,
						answer, loginId, clarificationId, requestId, cirCustomerCode);
				int updated = NativeQuerySupport.executeUpdateInSession(session, answerSql,
						answer, loginId, clarificationId, requestId, cirCustomerCode);
				if (updated != 1) {
					throw new IllegalArgumentException(
							"That clarification is no longer available for this request.");
				}
				String pendingSql = """
						update cc_customer_complaints
						set clarification_pending_with = case
							when exists (
								select 1 from cc_customer_complaints_clarifications pending
								where pending.ref_s_ref_data_code = cc_customer_complaints.internal_code
									and pending.type = 'Request'
									and isnull(pending.answer, '') = ''
							) then clarification_pending_with else '' end,
							clrif_submitted_date = getdate()
						where internal_code = ? and customer = ? and request_src = 'Customer'
						""".replace("getdate()", UserSessionSupport.sessionDate());
				logSql(HibernateFactoryRegistry.CIR, pendingSql, requestId, cirCustomerCode);
				NativeQuerySupport.executeUpdateInSession(session, pendingSql, requestId, cirCustomerCode);
				String historySql = """
						insert into cc_customer_complaints_history
							(ref_s_ref_data_code, updated_by, approver_status, approver_remarks,
							 created_by, created_date, modified_by, modified_date, updated_date,
							 approver_type, approver_role_status)
						values (?, ?, 'Clarification Given', ?, ?, getdate(), ?, getdate(),
							getdate(), 'Customer', 'Clarification Given')
						""".replace("getdate()", UserSessionSupport.sessionDate());
				logSql(HibernateFactoryRegistry.CIR, historySql,
						requestId, loginId, answer, loginId, loginId);
				NativeQuerySupport.executeUpdateInSession(session, historySql,
						requestId, loginId, answer, loginId, loginId);
				transaction.commit();
				return null;
			} catch (RuntimeException ex) {
				if (transaction.isActive()) {
					transaction.rollback();
				}
				throw ex;
			}
		});
	}


	private List<Map<String, Object>> query(String sql, Object... parameters) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		logSql(HibernateFactoryRegistry.CIR, sql, parameters);
		return NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.CIR, sql, parameters);
	}

	private static void logSql(String datasource, String sql, Object... parameters) {
		String rendered = SqlDebugFormatter.render(sql, parameters).replaceAll("[\\t ]+", " ")
				.replaceAll("\\s*\\n\\s*", " ").trim();
		System.out.println("CIR SQL [" + datasource + "]\n" + rendered + ";");
		logger.info("CIR {} SQL: {}", datasource, rendered);
	}
}
