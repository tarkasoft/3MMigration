package com.mmm.cir;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;
import com.mmm.titpl.SqlDebugFormatter;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Uploads and downloads CIR documents after the request itself has been saved.
 * Each file is its own request because a single HTTP request is limited to 5 MB.
 */
@RestController
@RequestMapping("/api/customer/cir")
public class CirDocUpload {
	private static final Logger logger = LoggerFactory.getLogger(CirDocUpload.class);
	private static final Gson GSON = new Gson();

	private final HibernateFactoryRegistry registry;
	private final CirRequestsSql sql;
	private final CirFileStore files;

	public CirDocUpload(HibernateFactoryRegistry registry, CirFileStore files) {
		this.registry = registry;
		this.sql = new CirRequestsSql(registry);
		this.files = files;
	}

	@PostMapping(value = "/requests/{requestId}/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String uploadDocument(HttpServletRequest request, @PathVariable long requestId,
			@RequestParam("file") MultipartFile file,
			@RequestParam(value = "documentTypeId", defaultValue = "0") long documentTypeId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		String storedPath = "";
		try {
			if (requestId <= 0) throw new IllegalArgumentException("CIR request ID is invalid.");
			if (file == null || file.isEmpty()) throw new IllegalArgumentException("Select a document.");
			if (file.getSize() > SaveCir.MAX_DOCUMENT_BYTES) {
				throw new IllegalArgumentException(
						"Each document must be 5 MB or smaller. Upload documents one at a time.");
			}
			UserSessionSupport.ProcedureCustomerContext context =
					CirRequests.customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			String customerCode = String.valueOf(cirCustomer.get("cust_code"));
			String ticket = ticketFor(customerCode, requestId);
			storedPath = files.store(ticket, file.getOriginalFilename(), file.getBytes());
			attachDocument(customerCode, requestId, documentTypeId,
					CirFileStore.safeDisplayName(file.getOriginalFilename()), storedPath, "");
			result.SetSuccess("success", Map.of("message", "Document uploaded.", "fileName",
					CirFileStore.safeDisplayName(file.getOriginalFilename())));
		} catch (Exception ex) {
			if (!storedPath.isBlank()) files.remove(storedPath);
			return CirRequests.error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping(value = "/requests/{requestId}/attachments", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String uploadAdditionalDocument(HttpServletRequest request, @PathVariable long requestId,
			@RequestParam("file") MultipartFile file,
			@RequestParam(value = "fileName", required = false) String fileName,
			@RequestParam(value = "remarks", required = false) String remarks,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		String storedPath = "";
		try {
			if (requestId <= 0) throw new IllegalArgumentException("CIR request ID is invalid.");
			if (file == null || file.isEmpty()) throw new IllegalArgumentException("Select a document.");
			if (file.getSize() > SaveCir.MAX_DOCUMENT_BYTES) {
				throw new IllegalArgumentException(
						"Each document must be 5 MB or smaller. Upload documents one at a time.");
			}
			UserSessionSupport.ProcedureCustomerContext context =
					CirRequests.customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			String customerCode = String.valueOf(cirCustomer.get("cust_code"));
			String ticket = ticketFor(customerCode, requestId);
			String originalName = file.getOriginalFilename();
			String displayName = CirFileStore.nameWithExtension(
					text(fileName).isBlank() ? originalName : fileName, originalName);
			storedPath = files.store(ticket, originalName, file.getBytes());
			attachAdditional(customerCode, requestId, displayName, storedPath, text(remarks),
					context.loginId());
			System.out.println("CIR additional upload ended: requestId=" + requestId +
					" fileName=" + displayName + " path=" + storedPath);
			result.SetSuccess("success", Map.of("message", "Additional document uploaded.",
					"fileName", displayName));
		} catch (Exception ex) {
			if (!storedPath.isBlank()) files.remove(storedPath);
			System.out.println("CIR additional upload error: requestId=" + requestId +
					" -> " + ex.getMessage());
			return CirRequests.error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/requests/{requestId}/documents/{documentId}/download")
	public ResponseEntity<byte[]> downloadRequiredDocument(HttpServletRequest request,
			@PathVariable long requestId, @PathVariable long documentId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		printDownload("started", "required", requestId, documentId, null, null);
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					CirRequests.customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			Map<String, Object> document = sql.requiredDocument(requestId, documentId,
					String.valueOf(cirCustomer.get("cust_code")));
			ResponseEntity<byte[]> response = download(document);
			printDownload("ended", "required", requestId, documentId,
					response.getStatusCode().value(), bodyBytes(response));
			return response;
		} catch (Exception ex) {
			printDownload("ended-error", "required", requestId, documentId, null, ex.getMessage());
			return downloadError("Unable to download CIR document", ex);
		}
	}

	@GetMapping("/requests/{requestId}/attachments/{attachmentId}/download")
	public ResponseEntity<byte[]> downloadAdditionalDocument(HttpServletRequest request,
			@PathVariable long requestId, @PathVariable long attachmentId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		printDownload("started", "attachment", requestId, attachmentId, null, null);
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					CirRequests.customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			Map<String, Object> document = sql.additionalDocument(requestId, attachmentId,
					String.valueOf(cirCustomer.get("cust_code")));
			ResponseEntity<byte[]> response = download(document);
			printDownload("ended", "attachment", requestId, attachmentId,
					response.getStatusCode().value(), bodyBytes(response));
			return response;
		} catch (Exception ex) {
			printDownload("ended-error", "attachment", requestId, attachmentId, null, ex.getMessage());
			return downloadError("Unable to download CIR attachment", ex);
		}
	}

	private String ticketFor(String customerCode, long requestId) {
		String ticketSql = """
				select isnull(ticket_number, '') as ticket_number
				from cc_customer_complaints
				where internal_code = ? and customer = ? and request_src = 'Customer'
				""";
		printSql("CIR ticket lookup", ticketSql, requestId, customerCode);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.CIR,
				ticketSql, requestId, customerCode);
		if (rows.isEmpty() || text(rows.get(0).get("ticket_number")).isBlank()) {
			throw new IllegalArgumentException("CIR request was not found for this customer.");
		}
		return text(rows.get(0).get("ticket_number"));
	}

	private void attachDocument(String customerCode, long requestId, long documentTypeId, String fileName,
			String relativePath, String remarks) {
		registry.withSession(HibernateFactoryRegistry.CIR, session -> {
			Transaction transaction = session.beginTransaction();
			try {
				int updated = update(session, "CIR document insert", """
						insert into cc_customer_complaints_doc_group(
							ref_s_ref_data_code, row_sequence, ref_doc_code, u_doc_name, u_doc_path,
							created_by, created_date, modified_by, modified_date, re_upload_required,
							cust_doc_remarks)
						select request.internal_code,
							isnull((select max(existing.row_sequence)
								from cc_customer_complaints_doc_group existing
								where existing.ref_s_ref_data_code = request.internal_code), 0) + 1,
							?, ?, ?, 0, getdate(),
							0, getdate(), 'No', ?
						from cc_customer_complaints request
						where request.internal_code = ? and request.customer = ?
							and request.request_src = 'Customer'
						""", documentTypeId, fileName, relativePath, remarks, requestId, customerCode);
				if (updated != 1) {
					throw new IllegalArgumentException("CIR request was not found for this customer.");
				}
				transaction.commit();
				return null;
			} catch (RuntimeException ex) {
				if (transaction != null && transaction.isActive()) transaction.rollback();
				if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
					throw ex;
				}
				logger.error("CIR document row rolled back for request {}", requestId, ex);
				throw new IllegalStateException("The document was not saved.");
			}
		});
	}

	private void attachAdditional(String customerCode, long requestId, String fileName,
			String relativePath, String remarks, String loginId) {
		System.out.println("CIR additional upload started: requestId=" + requestId +
				" fileName=" + fileName);
		registry.withSession(HibernateFactoryRegistry.CIR, session -> {
			Transaction transaction = session.beginTransaction();
			try {
				int updated = update(session, "CIR additional attachment insert", """
						insert into cc_customer_complaints_add_atch(
							ref_s_ref_data_code, file_name, file_path, remarks,
							created_by_enl_id, created_date)
						select request.internal_code, ?, ?, ?, ?, getdate()
						from cc_customer_complaints request
						where request.internal_code = ? and request.customer = ?
							and request.request_src = 'Customer'
						""", fileName, relativePath, remarks, text(loginId), requestId, customerCode);
				if (updated != 1) {
					throw new IllegalArgumentException("CIR request was not found for this customer.");
				}
				transaction.commit();
				return null;
			} catch (RuntimeException ex) {
				if (transaction != null && transaction.isActive()) transaction.rollback();
				if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
					throw ex;
				}
				logger.error("CIR additional attachment rolled back for request {}", requestId, ex);
				throw new IllegalStateException("The additional document was not saved.");
			}
		});
	}

	private ResponseEntity<byte[]> download(Map<String, Object> document) throws Exception {
		if (document == null) {
			System.out.println("CIR download: document row missing");
			logger.warn("CIR download: document row missing");
			return ResponseEntity.notFound().build();
		}
		String path = document.get("file_path") == null ? "" : String.valueOf(document.get("file_path")).trim();
		String fileName = CirFileStore.nameWithExtension(
				String.valueOf(document.get("file_name")), path);
		byte[] bytes = null;
		if (!path.isBlank()) {
			System.out.println("CIR download: reading fileName=" + fileName + " path=" + path);
			logger.info("CIR download: reading fileName={} path={}", fileName, path);
			bytes = files.read(path);
		} else {
			Object blob = document.get("attached_file");
			if (blob instanceof byte[] raw && raw.length > 0) {
				bytes = raw;
				System.out.println("CIR download: reading fileName=" + fileName + " from attached_file bytes=" + raw.length);
				logger.info("CIR download: reading fileName={} from attached_file bytes={}", fileName, raw.length);
			} else if (blob instanceof java.sql.Blob sqlBlob) {
				bytes = sqlBlob.getBytes(1, (int) Math.min(sqlBlob.length(), Integer.MAX_VALUE));
				System.out.println("CIR download: reading fileName=" + fileName + " from SQL Blob bytes=" +
						(bytes == null ? 0 : bytes.length));
			}
		}
		if (bytes == null || bytes.length == 0) {
			System.out.println("CIR download: file path/blob missing for fileName=" + fileName);
			logger.warn("CIR download: file path/blob missing for fileName={}", fileName);
			return ResponseEntity.notFound().build();
		}
		String lower = fileName.toLowerCase(Locale.ROOT);
		MediaType contentType = lower.endsWith(".pdf")
				? MediaType.APPLICATION_PDF : MediaType.APPLICATION_OCTET_STREAM;
		System.out.println("CIR download Content-Disposition filename=" + fileName);
		return ResponseEntity.ok()
				.contentType(contentType)
				.header(HttpHeaders.CONTENT_DISPOSITION,
						ContentDisposition.attachment().filename(fileName).build().toString())
				.header("X-Content-Type-Options", "nosniff")
				.body(bytes);
	}

	private ResponseEntity<byte[]> downloadError(String operation, Exception ex) {
		System.out.println("CIR download error: " + operation + " -> " + ex.getMessage());
		if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
			HttpStatus status = UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())
					? HttpStatus.UNAUTHORIZED : HttpStatus.NOT_FOUND;
			return ResponseEntity.status(status).build();
		}
		logger.error(operation, ex);
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
	}

	private static void printDownload(String phase, String kind, long requestId, long fileId,
			Object statusOrNull, Object detailOrNull) {
		StringBuilder line = new StringBuilder("CIR download ")
				.append(phase)
				.append(": kind=").append(kind)
				.append(" requestId=").append(requestId)
				.append(" fileId=").append(fileId);
		if (statusOrNull != null) line.append(" status=").append(statusOrNull);
		if (detailOrNull != null) line.append(" detail=").append(detailOrNull);
		System.out.println(line);
		logger.info("{}", line);
	}

	private static Object bodyBytes(ResponseEntity<byte[]> response) {
		byte[] body = response.getBody();
		return body == null ? "0 bytes" : (body.length + " bytes");
	}

	private int update(Session session, String label, String sql, Object... parameters) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		printSql(label, sql, parameters);
		return NativeQuerySupport.executeUpdateInSession(session, sql, parameters);
	}

	private static void printSql(String label, String sql, Object... parameters) {
		String rendered = SqlDebugFormatter.render(sql, parameters).replaceAll("[\\t ]+", " ")
				.replaceAll("\\s*\\n\\s*", " ").trim();
		System.out.println("CIR SQL [" + label + "]\n" + rendered + ";");
		logger.info("CIR {} SQL: {}", label, rendered);
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}
}
