package com.mmm.cir;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Customer CIR dashboard summary API.
 * GET /api/customer/cir/dashboard
 */
@RestController
@RequestMapping("/api/customer/cir")
public class CirDashboard {
	private static final Logger logger = LoggerFactory.getLogger(CirDashboard.class);
	private static final Gson GSON = new Gson();

	private final CirDashboardSql sql;

	public CirDashboard(HibernateFactoryRegistry registry) {
		this.sql = new CirDashboardSql(registry);
	}

	@GetMapping("/dashboard")
	public String dashboard(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "year", required = false) Integer year) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					CirRequests.customer(request.getSession(false), custCode, loginId);
			Map<String, Object> data = sql.dashboard(context.custCode(), year);
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return CirRequests.error(result, ex);
		}
		return GSON.toJson(result);
	}
}
