package com.mmm.cir;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/customer/cir")
public class CirRequests {
	private static final Logger logger = LoggerFactory.getLogger(CirRequests.class);
	private static final Gson GSON = new Gson();

	private final CirRequestsSql sql;
	private final SaveCir saveCir;

	public CirRequests(HibernateFactoryRegistry registry) {
		this.sql = new CirRequestsSql(registry);
		this.saveCir = new SaveCir(registry, sql);
	}

	@GetMapping("/context")
	public String context(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					customer(request.getSession(false), custCode, loginId);
			Map<String, Object> customer = sql.customer(context.custCode());
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", customer.get("cust_code"));
			data.put("loginId", context.loginId());
			data.put("customerName", customer.get("cust_name"));
			data.put("customerType", customer.get("customer_type"));
			data.put("customerPhone", customer.get("customer_phone"));
			data.put("customerEmail", customer.get("customer_email"));
			data.put("customerContactName", customer.get("customer_contact_name"));
			data.put("overridden", context.overridden());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/new-request/lookups")
	public String newRequestLookups(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			HttpSession session = request.getSession(false);
			UserSessionSupport.ProcedureCustomerContext context =
					customer(session, custCode, loginId);
			Object roles = session.getAttribute(UserSessionSupport.LOGIN_USER_ROLES);
			Map<String, Object> data = sql.newRequestLookups(context.custCode(), context.loginId(),
					roles == null ? "" : String.valueOf(roles));
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/new-request/invoices")
	public String invoiceSuggestions(HttpServletRequest request,
			@RequestParam(value = "phrase", defaultValue = "") String phrase,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			HttpSession session = request.getSession(false);
			UserSessionSupport.ProcedureCustomerContext context =
					customer(session, custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			Object roleValue = session.getAttribute(UserSessionSupport.LOGIN_USER_ROLES);
			String roles = roleValue == null ? "" : String.valueOf(roleValue);
			result.SetSuccess("success", sql.invoiceSuggestions(phrase,
					String.valueOf(cirCustomer.get("cust_code")), context.loginId(), roles));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/new-request/invoice-items")
	public String invoiceItems(HttpServletRequest request,
			@RequestParam("invoiceNo") String invoiceNo,
			@RequestParam("invoiceDate") String invoiceDate,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			String customerCode = String.valueOf(cirCustomer.get("cust_code"));
			int invoiceDateNumber = invoiceDateAsNumber(invoiceDate);

			List<Map<String, Object>> missingLots =
					sql.missingLotDetails(customerCode, invoiceNo, invoiceDateNumber);
			if (!missingLots.isEmpty()) {
				throw new IllegalArgumentException("Lot details are missing for: " + missingLots.stream()
						.map(row -> row.get("sales_item") + " - " + row.get("items_desc"))
						.collect(java.util.stream.Collectors.joining("; ")) + ". Please contact administrator.");
			}

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("lines", sql.invoiceLineItems(customerCode, invoiceNo));
			data.put("freight", sql.invoiceFreightDetails(customerCode, invoiceNo));
			data.put("taxRates", sql.distinctTaxRates());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** Invoice date arrives from the UI as "YYYY-MM-DD"; the legacy invoice tables store it as a plain YYYYMMDD number. */
	private static int invoiceDateAsNumber(String invoiceDate) {
		String digitsOnly = invoiceDate == null ? "" : invoiceDate.replaceAll("[^0-9]", "");
		if (digitsOnly.length() != 8) {
			throw new IllegalArgumentException("Invoice date is invalid.");
		}
		return Integer.parseInt(digitsOnly);
	}

	@GetMapping("/new-request/required-documents")
	public String requiredDocuments(HttpServletRequest request,
			@RequestParam("reasonCode") String reasonCode,
			@RequestParam("causeCode") String causeCode,
			@RequestParam(value = "editRequestId", defaultValue = "0") String editRequestId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			customer(request.getSession(false), custCode, loginId);
			long complaintTypeId = parseId(reasonCode, "Complaint type");
			long causeCategoryId = parseId(causeCode, "Cause code");
			long editId = parseId(editRequestId, "Edit request");
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("documents", sql.requiredDocumentCatalog(complaintTypeId, causeCategoryId, editId));
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	private static long parseId(String value, String label) {
		String digits = value == null ? "" : value.trim().split("\\.")[0];
		if (digits.isBlank()) {
			return 0;
		}
		try {
			return Long.parseLong(digits);
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException(label + " is invalid.");
		}
	}

	@PostMapping("/requests")
	public String saveRequest(HttpServletRequest request,
			@RequestBody(required = false) Map<String, Object> body,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			Map<String, Object> header = body == null ? Map.of() : body;
			Object linesValue = header.get("lines");
			List<Map<String, Object>> lines = new java.util.ArrayList<>();
			if (linesValue instanceof List<?> source) {
				for (Object item : source) {
					if (item instanceof Map<?, ?> map) {
						Map<String, Object> line = new LinkedHashMap<>();
						map.forEach((key, value) -> line.put(String.valueOf(key), value));
						lines.add(line);
					}
				}
			}
			long editRequestId = 0;
			Object editValue = header.get("internalCode");
			if (editValue != null && !String.valueOf(editValue).isBlank()) {
				editRequestId = Long.parseLong(String.valueOf(editValue).split("\\.")[0]);
			}
			result.SetSuccess("success", saveCir.save(
					String.valueOf(cirCustomer.get("cust_code")), context.loginId(),
					editRequestId, header, lines));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/requests")
	public String requests(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext customer =
					customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(customer.custCode());
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("header_details", sql.requests(String.valueOf(cirCustomer.get("cust_code"))));
			data.put("customer", cirCustomer);
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/requests/{requestId}")
	public String request(HttpServletRequest request, @PathVariable long requestId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			if (requestId <= 0) {
				throw new IllegalArgumentException("CIR request ID is invalid.");
			}
			UserSessionSupport.ProcedureCustomerContext customer =
					customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(customer.custCode());
			Map<String, Object> data = sql.request(requestId, String.valueOf(cirCustomer.get("cust_code")));
			if (data == null) {
				throw new IllegalArgumentException("CIR request was not found for this customer.");
			}
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping("/requests/{requestId}/clarifications/{clarificationId}/answer")
	public String answerClarification(HttpServletRequest request,
			@PathVariable long requestId, @PathVariable long clarificationId,
			@RequestBody(required = false) Map<String, Object> body,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			if (requestId <= 0 || clarificationId <= 0) {
				throw new IllegalArgumentException("CIR request or clarification ID is invalid.");
			}
			UserSessionSupport.ProcedureCustomerContext context =
					customer(request.getSession(false), custCode, loginId);
			Map<String, Object> cirCustomer = sql.customer(context.custCode());
			Object answerValue = body == null ? null : body.get("answer");
			String answer = answerValue == null ? "" : String.valueOf(answerValue).trim();
			if (answer.isEmpty() || answer.length() > 4000) {
				throw new IllegalArgumentException("Enter an answer of up to 4,000 characters.");
			}
			sql.answerClarification(requestId, clarificationId,
					String.valueOf(cirCustomer.get("cust_code")), context.loginId(), answer);
			result.SetSuccess("success", Map.of("message", "Clarification answer submitted."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	static UserSessionSupport.ProcedureCustomerContext customer(
			HttpSession session, String custCode, String loginId) {
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(session, custCode, loginId);
		String userType = String.valueOf(session.getAttribute(UserSessionSupport.LOGIN_USER_TYPE));
		if (!isCustomer(userType) && !context.overridden()) {
			throw new IllegalArgumentException("CIR Requests is available to customer accounts only.");
		}
		if (context.custCode().isBlank()) {
			throw new IllegalArgumentException("No customer is selected for CIR Requests.");
		}
		return context;
	}

	static String error(ResponseDataGeneric result, Exception ex) {
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure", ex.getMessage());
		} else {
			if (!(ex instanceof IllegalArgumentException || ex instanceof IllegalStateException)) {
				logger.error("Unable to load CIR requests", ex);
			}
			result.SetError(-1, "failure",
					ex instanceof IllegalArgumentException || ex instanceof IllegalStateException
							? ex.getMessage() : "Unable to process the CIR request.");
		}
		return GSON.toJson(result);
	}

	private static boolean isCustomer(String value) {
		return "CUST".equalsIgnoreCase(value) || "Customer".equalsIgnoreCase(value)
				|| "Vendor".equalsIgnoreCase(value) || "VEND".equalsIgnoreCase(value);
	}
}
