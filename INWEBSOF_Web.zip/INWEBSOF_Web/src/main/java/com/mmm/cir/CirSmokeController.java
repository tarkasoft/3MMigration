package com.mmm.cir;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.ResponseDataGeneric;

/**
 * Smoke APIs to prove system (dINSBA) and cir (dINSBA) are separate connections.
 *
 * GET /api/cir/users?limit=5
 * GET /api/cir/compare?limit=3  — hits both DBs in one request
 */
@RestController
@RequestMapping("/api/cir")
public class CirSmokeController {

    private final CirUserService cirUserService;
    private final HibernateFactoryRegistry registry;
    private final SessionFactory systemSessionFactory;
    private final Gson gson = new Gson();

    public CirSmokeController(CirUserService cirUserService,
                              HibernateFactoryRegistry registry,
                              @Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory systemSessionFactory) {
        this.cirUserService = cirUserService;
        this.registry = registry;
        this.systemSessionFactory = systemSessionFactory;
    }

    @GetMapping("/users")
    public String users(@RequestParam(value = "limit", defaultValue = "5") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            long count = cirUserService.countUsers();
            List<Map<String, Object>> rows = cirUserService.listUsers(limit);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("datasource", HibernateFactoryRegistry.CIR);
            data.put("database", "dINSBA");
            data.put("totalUsers", count);
            data.put("sample", rows);
            data.put("systemSfHash", System.identityHashCode(systemSessionFactory));
            data.put("cirSfHash", System.identityHashCode(CirHybernetUtil.getSessionFactory()));
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "CIR query failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    /**
     * One HTTP call, two SessionFactories: system @Transactional + cir withSession.
     */
    @GetMapping("/compare")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String compare(@RequestParam(value = "limit", defaultValue = "3") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            Map<String, Object> data = new LinkedHashMap<>();

            Number systemCnt = systemSessionFactory.getCurrentSession()
                    .createNativeQuery("select count(*) from ia_user_master", Long.class)
                    .uniqueResult();
            data.put("systemDatabase", "dINSBA");
            data.put("systemUserCount", systemCnt);
            data.put("systemSfHash", System.identityHashCode(systemSessionFactory));

            long cirCnt = cirUserService.countUsers();
            List<Map<String, Object>> cirSample = cirUserService.listUsers(limit);
            data.put("cirDatabase", "dINSBA");
            data.put("cirUserCount", cirCnt);
            data.put("cirSample", cirSample);
            data.put("cirSfHash", System.identityHashCode(registry.getCirSessionFactory()));
            data.put("sameSessionFactory",
                    System.identityHashCode(systemSessionFactory)
                            == System.identityHashCode(registry.getCirSessionFactory()));

            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Compare failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }
}