package com.mmm.cir;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.share.DiskShare;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;

@Component
final class CirFileStore {
	/** CIRATTCH share uses SMB 3.1.1 (same as Ship & Debit docs). */
	private static final SMB2Dialect SMB3 = SMB2Dialect.SMB_3_1_1;

	private final HibernateFactoryRegistry registry;
	private final String appCode;
	private final String shareLogin;
	private final String shareSearch;
	private final String smbDomain;
	private final String fileTransport;
	private final String mountRoot;

	CirFileStore(HibernateFactoryRegistry registry,
			@Value("${inpc.cir.smb-app-code:CIR}") String appCode,
			@Value("${inpc.cir.smb-login:A2ARVZZ}") String shareLogin,
			@Value("${inpc.cir.smb-search:CIRATTCH}") String shareSearch,
			@Value("${inpc.cir.smb-domain:MMM}") String smbDomain,
			@Value("${inpc.cir.file-transport:smb}") String fileTransport,
			@Value("${inpc.cir.mount-root:}") String mountRoot) {
		this.registry = registry;
		this.appCode = appCode;
		this.shareLogin = shareLogin;
		this.shareSearch = shareSearch;
		this.smbDomain = smbDomain;
		this.fileTransport = fileTransport;
		this.mountRoot = mountRoot;
	}

	/** Stores one document on the CIRATTCH share via SMB3 and returns the relative path. */
	String store(String ticketNumber, String originalName, byte[] content) throws Exception {
		if (content == null || content.length == 0) {
			throw new IllegalArgumentException("Select a document.");
		}
		if (content.length > SaveCir.MAX_DOCUMENT_BYTES) {
			throw new IllegalArgumentException("Each document must be 5 MB or smaller.");
		}
		String relativePath = documentPath(ticketNumber, originalName);
		if (useMount()) {
			java.nio.file.Path target = mounted(relativePath);
			java.nio.file.Files.createDirectories(target.getParent());
			java.nio.file.Files.write(target, content);
			return relativePath;
		}
		System.out.println("CIR SMB3 store started: path=" + relativePath + " bytes=" + content.length);
		writeSmb(relativePath, content);
		System.out.println("CIR SMB3 store ended: path=" + relativePath);
		return relativePath;
	}

	void remove(String storedPath) {
		try {
			String relativePath = safeRelativePath(storedPath);
			if (useMount()) {
				java.nio.file.Files.deleteIfExists(mounted(relativePath));
				return;
			}
			Map<String, String> location = locateShare();
			withShare(location, share -> {
				String remotePath = join(location.get("folder"), relativePath);
				if (share.fileExists(remotePath)) share.rm(remotePath);
			});
		} catch (Exception ex) {
			org.slf4j.LoggerFactory.getLogger(CirFileStore.class)
					.warn("CIR document cleanup failed for {}", storedPath, ex);
		}
	}

	byte[] read(String storedPath) throws Exception {
		String relativePath = safeRelativePath(storedPath);
		if (useMount()) {
			return java.nio.file.Files.readAllBytes(mounted(relativePath));
		}
		Map<String, String> location = locateShare();
		byte[][] result = new byte[1][];
		withShare(location, share -> {
			try (com.hierynomus.smbj.share.File remoteFile = share.openFile(
					join(location.get("folder"), relativePath),
					EnumSet.of(AccessMask.GENERIC_READ),
					null,
					SMB2ShareAccess.ALL,
					SMB2CreateDisposition.FILE_OPEN,
					null);
					InputStream input = remoteFile.getInputStream();
					ByteArrayOutputStream output = new ByteArrayOutputStream()) {
				input.transferTo(output);
				result[0] = output.toByteArray();
			}
		});
		return result[0];
	}

	static String safeDisplayName(String fileName) {
		String name = fileName == null ? "document" : fileName.trim();
		name = name.replaceAll("[^A-Za-z0-9._ -]", "_");
		return name.isBlank() ? "document" : name.substring(Math.max(0, name.length() - 120));
	}

	/**
	 * Keeps a usable download/display name. If {@code preferred} has no extension,
	 * appends the extension from {@code sourceWithExtension} (original upload name or stored path).
	 */
	static String nameWithExtension(String preferred, String sourceWithExtension) {
		String name = safeDisplayName(preferred);
		String source = sourceWithExtension == null ? "" : sourceWithExtension.trim().replace('\\', '/');
		int slash = Math.max(source.lastIndexOf('/'), source.lastIndexOf('\\'));
		if (slash >= 0) source = source.substring(slash + 1);
		String sourceExt = extensionOf(source);
		if (sourceExt.isBlank()) return name;
		if (extensionOf(name).equalsIgnoreCase(sourceExt)) return name;
		if (!extensionOf(name).isBlank()) return name;
		String combined = name + sourceExt;
		return safeDisplayName(combined);
	}

	private static String extensionOf(String fileName) {
		if (fileName == null) return "";
		int dot = fileName.lastIndexOf('.');
		if (dot <= 0 || dot == fileName.length() - 1) return "";
		String ext = fileName.substring(dot).toLowerCase(java.util.Locale.ROOT);
		return ext.matches("\\.[a-z0-9]{1,10}") ? ext : "";
	}

	private void writeSmb(String relativePath, byte[] content) throws Exception {
		Map<String, String> location = locateShare();
		withShare(location, share -> {
			String remotePath = join(location.get("folder"), relativePath);
			int slash = remotePath.lastIndexOf('/');
			if (slash > 0) ensureFolder(share, remotePath.substring(0, slash));
			try (com.hierynomus.smbj.share.File remoteFile = share.openFile(
					remotePath,
					EnumSet.of(AccessMask.GENERIC_WRITE),
					null,
					SMB2ShareAccess.ALL,
					SMB2CreateDisposition.FILE_OVERWRITE_IF,
					null);
					java.io.OutputStream output = remoteFile.getOutputStream()) {
				output.write(content);
			}
		});
	}

	private void withShare(Map<String, String> location, ShareWork work) throws Exception {
		SmbConfig config = SmbConfig.builder()
				.withDialects(SMB3)
				.withEncryptData(true)
				.build();
		SMBClient client = new SMBClient(config);
		try (Connection connection = client.connect(location.get("host"))) {
			System.out.println("CIR SMB3 connect: host=" + location.get("host") +
					" share=" + location.get("share") + " dialect=SMB_3_1_1");
			var smbSession = connection.authenticate(new AuthenticationContext(
					location.get("username"), location.get("password").toCharArray(), smbDomain));
			try (DiskShare share = (DiskShare) smbSession.connectShare(location.get("share"))) {
				work.use(share);
			} finally {
				smbSession.close();
			}
		} finally {
			client.close();
		}
	}

	private static void ensureFolder(DiskShare share, String folder) {
		StringBuilder current = new StringBuilder();
		for (String part : folder.split("/")) {
			if (part.isBlank()) continue;
			if (current.length() > 0) current.append('/');
			current.append(part);
			String path = current.toString();
			if (!share.folderExists(path)) share.mkdir(path);
		}
	}

	private boolean useMount() {
		return "mount".equalsIgnoreCase(fileTransport);
	}

	private java.nio.file.Path mounted(String relativePath) {
		if (mountRoot == null || mountRoot.isBlank()) {
			throw new IllegalStateException("CIR document mount is not configured.");
		}
		java.nio.file.Path root = java.nio.file.Path.of(mountRoot).toAbsolutePath().normalize();
		java.nio.file.Path target = root.resolve(relativePath).normalize();
		if (!target.startsWith(root)) {
			throw new IllegalArgumentException("CIR document path is invalid.");
		}
		return target;
	}

	private static String documentPath(String ticketNumber, String originalName) {
		java.time.ZonedDateTime now = java.time.ZonedDateTime.now(java.time.ZoneId.of("Asia/Kolkata"));
		String ticket = ticketNumber == null ? "" : ticketNumber.replaceAll("[^A-Za-z0-9_-]", "");
		if (ticket.isBlank()) ticket = "request";
		return now.getYear() + "/" + String.format("%02d", now.getMonthValue()) + "/" + ticket + "/"
				+ System.currentTimeMillis() + "_" + safeDisplayName(originalName);
	}

	private Map<String, String> locateShare() {
		List<Map<String, Object>> rows = NativeQuerySupport.executeProcedure(
				registry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.CMW010S(?,?,?)}",
				appCode, shareLogin, shareSearch);
		for (Map<String, Object> row : rows) {
			String rawPath = text(cell(row, "NWPATH")).replace('\\', '/');
			if (rawPath.regionMatches(true, 0, "smb:", 0, 4)) rawPath = rawPath.substring(4);
			while (rawPath.startsWith("/")) rawPath = rawPath.substring(1);
			while (rawPath.endsWith("/")) rawPath = rawPath.substring(0, rawPath.length() - 1);
			String[] parts = rawPath.split("/", 3);
			String username = text(cell(row, "NWLID"));
			String password = text(cell(row, "NWPWD"));
			if (parts.length >= 2 && !parts[0].isBlank() && !parts[1].isBlank()
					&& !username.isBlank() && !password.isBlank()) {
				String host = parts[0];
				int port = host.indexOf(':');
				if (port > 0) host = host.substring(0, port);
				return Map.of(
						"host", host,
						"share", parts[1],
						"folder", parts.length > 2 ? safeRelativePath(parts[2]) : "",
						"username", username,
						"password", password);
			}
		}
		throw new IllegalStateException("CIR file share settings were not returned by CMW010S.");
	}

	private static String safeRelativePath(String path) {
		String value = path == null ? "" : path.trim().replace('\\', '/');
		if (value.isEmpty() || value.startsWith("/") || value.matches("^[A-Za-z]:.*")) {
			throw new IllegalArgumentException("CIR document path is invalid.");
		}
		String[] parts = value.split("/");
		for (String part : parts) {
			if (part.isBlank() || ".".equals(part) || "..".equals(part)
					|| part.matches(".*[<>:\"|?*\\p{Cntrl}].*")) {
				throw new IllegalArgumentException("CIR document path is invalid.");
			}
		}
		return String.join("/", parts);
	}

	private static String join(String folder, String relativePath) {
		return folder == null || folder.isBlank() ? relativePath : folder + "/" + relativePath;
	}

	private static Object cell(Map<String, Object> row, String key) {
		return row.entrySet().stream()
				.filter(entry -> entry.getKey() != null && entry.getKey().equalsIgnoreCase(key))
				.map(Map.Entry::getValue).findFirst().orElse(null);
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	@FunctionalInterface
	private interface ShareWork {
		void use(DiskShare share) throws Exception;
	}
}
