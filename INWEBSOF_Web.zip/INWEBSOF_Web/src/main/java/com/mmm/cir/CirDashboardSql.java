package com.mmm.cir;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/**
 * Dashboard aggregates for a customer CIR account, filtered by year.
 */
final class CirDashboardSql {
	private static final Logger logger = LoggerFactory.getLogger(CirDashboardSql.class);

	private final HibernateFactoryRegistry registry;
	private final CirRequestsSql requestsSql;

	CirDashboardSql(HibernateFactoryRegistry registry) {
		this.registry = registry;
		this.requestsSql = new CirRequestsSql(registry);
	}

	Map<String, Object> dashboard(String portalCustomerCode, Integer year) {
		Map<String, Object> customer = requestsSql.customer(portalCustomerCode);
		String custCode = String.valueOf(customer.get("cust_code"));
		int selectedYear = resolveYear(year);
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);

		Map<String, Object> summary = first(query("""
				select
					count(*) as total_count,
					sum(case
						when isnull(cc.reassign_to_cust, '') = 'Yes' then 0
						when isnull(cc.ui_status, '') = 'Rejected' then 0
						when isnull(cc.ui_status, '') = 'Closed' then 0
						else 1 end) as in_progress_count,
					sum(case when isnull(cc.ui_status, '') = 'Closed' then 1 else 0 end) as closed_count,
					sum(case when isnull(cc.reassign_to_cust, '') = 'Yes' then 1 else 0 end) as rework_count,
					sum(case when isnull(cc.ui_status, '') = 'Rejected' then 1 else 0 end) as rejected_count,
					sum(case
						when isnull(cc.ui_status, '') = 'Closed'
							and month(cc.created_date) = month(getdate())
						then 1 else 0 end) as closed_this_month,
					sum(case when isnull(rtrim(cc.credit_note_no), '') <> '' then 1 else 0 end) as credit_note_count,
					sum(case
						when isnull(cc.ui_status, '') in ('Rejected', 'Cancelled') then 0
						else isnull(cc.total_amt, 0) end) as ytd_claim_amt
				from cc_customer_complaints cc
				where cc.customer = ?
					and cc.request_src = 'Customer'
					and year(cc.created_date) = ?
				""", custCode, selectedYear));
		if (selectedYear != currentYear) {
			summary.put("closed_this_month", summary.get("closed_count"));
		}

		Number pendingClarifications = number(first(query("""
				select count(*) as pending_clarifications
				from cc_customer_complaints_clarifications c
				inner join cc_customer_complaints cc on cc.internal_code = c.ref_s_ref_data_code
				where cc.customer = ?
					and cc.request_src = 'Customer'
					and year(cc.created_date) = ?
					and isnull(c.type, '') = 'Request'
					and isnull(c.answer, '') = ''
				""", custCode, selectedYear)).get("pending_clarifications"));

		List<Map<String, Object>> actionItems = query("""
				select top 8
					cc.internal_code,
					cc.ticket_number as cir_no,
					convert(varchar(10), cc.created_date, 103) as cir_date,
					isnull(cc.invoice_no, '') as invoice_no,
					isnull(ccr.name, '') as customer_reason,
					isnull(cc.total_amt, 0) as total_amt,
					case
						when exists (
							select 1 from cc_customer_complaints_clarifications c
							where c.ref_s_ref_data_code = cc.internal_code
								and isnull(c.type, '') = 'Request'
								and isnull(c.answer, '') = ''
						) then 'Clarification'
						when isnull(cc.reassign_to_cust, '') = 'Yes' then 'Rework'
						else 'Action'
					end as action_type
				from cc_customer_complaints cc
				left join cc_customer_reason ccr on ccr.internal_code = cc.cc_inv_cust_reason
				where cc.customer = ?
					and cc.request_src = 'Customer'
					and year(cc.created_date) = ?
					and (
						isnull(cc.reassign_to_cust, '') = 'Yes'
						or exists (
							select 1 from cc_customer_complaints_clarifications c
							where c.ref_s_ref_data_code = cc.internal_code
								and isnull(c.type, '') = 'Request'
								and isnull(c.answer, '') = ''
						)
					)
				order by cc.ticket_number desc
				""", custCode, selectedYear);

		List<Map<String, Object>> recent = query("""
				select top 8
					cc.internal_code,
					cc.ticket_number as cir_no,
					convert(varchar(10), cc.created_date, 103) as cir_date,
					isnull(cc.invoice_no, '') as invoice_no,
					isnull(convert(varchar(10), cc.invoice_date, 23), '') as invoice_date,
					isnull(ccr.name, '') as customer_reason,
					isnull(cc.total_amt, 0) as total_amt,
					isnull(cc.credit_note_no, '') as credit_note_no,
					isnull(convert(varchar(10), cc.credit_note_date, 23), '') as credit_note_date,
					case
						when isnull(cc.reassign_to_cust, '') = 'Yes' then 'Rework'
						when isnull(cc.ui_status, '') = 'Rejected' then 'Rejected'
						when isnull(cc.ui_status, '') = 'Closed' then 'Closed'
						else 'In Progress'
					end as ui_status
				from cc_customer_complaints cc
				left join cc_customer_reason ccr on ccr.internal_code = cc.cc_inv_cust_reason
				where cc.customer = ?
					and cc.request_src = 'Customer'
					and year(cc.created_date) = ?
				order by cc.ticket_number desc
				""", custCode, selectedYear);

		long rework = number(summary.get("rework_count")).longValue();
		long needsAction = rework + pendingClarifications.longValue();

		Map<String, Object> data = new LinkedHashMap<>();
		data.put("customer", customer);
		data.put("year", selectedYear);
		data.put("current_year", currentYear);
		data.put("previous_year", currentYear - 1);
		data.put("summary", Map.of(
				"total_count", number(summary.get("total_count")),
				"in_progress_count", number(summary.get("in_progress_count")),
				"closed_count", number(summary.get("closed_count")),
				"rework_count", number(summary.get("rework_count")),
				"rejected_count", number(summary.get("rejected_count")),
				"closed_this_month", number(summary.get("closed_this_month")),
				"credit_note_count", number(summary.get("credit_note_count")),
				"pending_clarifications", pendingClarifications,
				"needs_action_count", needsAction,
				"ytd_claim_amt", number(summary.get("ytd_claim_amt"))
		));
		data.put("action_items", actionItems);
		data.put("recent_requests", recent);
		return data;
	}

	static int resolveYear(Integer year) {
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		if (year == null) return currentYear;
		if (year == currentYear || year == currentYear - 1) return year;
		throw new IllegalArgumentException("Year must be the current year or previous year.");
	}

	private List<Map<String, Object>> query(String sql, Object... params) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		String rendered = SqlDebugFormatter.render(sql, params).replaceAll("[\\t ]+", " ")
				.replaceAll("\\s*\\n\\s*", " ").trim();
		logger.info("CIR dashboard SQL: {}", rendered);
		return NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.CIR, sql, params);
	}

	private static Map<String, Object> first(List<Map<String, Object>> rows) {
		return rows == null || rows.isEmpty() ? Map.of() : rows.get(0);
	}

	private static Number number(Object value) {
		if (value instanceof Number n) return n;
		if (value == null || String.valueOf(value).isBlank()) return 0;
		try {
			return Double.parseDouble(String.valueOf(value));
		} catch (NumberFormatException ex) {
			return 0;
		}
	}
}
