package com.mmm.csd;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.mmm.titpl.NativeQuerySupport;
import com.mmm.config.HibernateFactoryRegistry;

/**
 * CSD DB access — NativeQuerySupport against lazy datasource "csd".
 */
@Service
public class CsdUserService {

    private static final Logger log = LoggerFactory.getLogger(CsdUserService.class);

    private final HibernateFactoryRegistry registry;

    public CsdUserService(HibernateFactoryRegistry registry) {
        this.registry = registry;
    }

    public List<Map<String, Object>> listUsers(int limit) {
        int n = Math.max(1, Math.min(limit, 50));
        String sql = """
                select top %d u.enl_id, u.name, isnull(u.active,'') as active,
                       isnull(u.email,'') as email
                from ia_user_master u
                order by u.enl_id
                """.formatted(n);

        List<Map<String, Object>> rows =
                NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.CSD, sql);
        log.info("CSD ia_user_master sample rows={}", rows.size());
        for (Map<String, Object> row : rows) {
            log.info("CSD user: {}", row);
        }
        return rows;
    }

    public long countUsers() {
        String sql = "select count(*) as cnt from ia_user_master";
        List<Map<String, Object>> rows =
                NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.CSD, sql);
        if (rows.isEmpty() || rows.get(0).get("cnt") == null) {
            return 0L;
        }
        long cnt = ((Number) rows.get(0).get("cnt")).longValue();
        log.info("CSD ia_user_master count={}", cnt);
        return cnt;
    }
}