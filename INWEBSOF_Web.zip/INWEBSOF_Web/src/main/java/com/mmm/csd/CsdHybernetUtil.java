package com.mmm.csd;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import com.mmm.config.HibernateFactoryRegistry;

import jakarta.annotation.PostConstruct;

/**
 * CSD Hibernate facade — lazy SessionFactory via registry (13.232.155.0 / dINSBA).
 */
@Component
public class CsdHybernetUtil {

    private static HibernateFactoryRegistry registry;

    private final HibernateFactoryRegistry injectedRegistry;

    public CsdHybernetUtil(HibernateFactoryRegistry injectedRegistry) {
        this.injectedRegistry = injectedRegistry;
    }

    @PostConstruct
    void init() {
        registry = injectedRegistry;
    }

    /** Builds CSD SessionFactory on first call (lazy). Do not close from request code. */
    public static SessionFactory getSessionFactory() {
        if (registry == null) {
            throw new IllegalStateException("CsdHybernetUtil not initialized by Spring yet");
        }
        return registry.getCsdSessionFactory();
    }
}