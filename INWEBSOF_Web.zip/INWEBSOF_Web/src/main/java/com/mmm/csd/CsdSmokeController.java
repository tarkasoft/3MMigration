package com.mmm.csd;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.ResponseDataGeneric;

/**
 * Smoke APIs for warranty datasource (PRODSQL445A / dINTWSYS — shared with TSD).
 *
 * GET /api/csd/users?limit=5
 * GET /api/csd/compare?limit=3  â€” system vs csd in one request
 * GET /api/csd/ping             â€” connection + SF identity only
 */
@RestController
@RequestMapping("/api/csd")
public class CsdSmokeController {

    private final CsdUserService csdUserService;
    private final HibernateFactoryRegistry registry;
    private final SessionFactory systemSessionFactory;
    private final Gson gson = new Gson();

    public CsdSmokeController(CsdUserService csdUserService,
                              HibernateFactoryRegistry registry,
                              @Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory systemSessionFactory) {
        this.csdUserService = csdUserService;
        this.registry = registry;
        this.systemSessionFactory = systemSessionFactory;
    }

    @GetMapping("/ping")
    public String ping() {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            Map<String, Object> data = new LinkedHashMap<>();
            SessionFactory csdSf = registry.getCsdSessionFactory();
            data.put("datasource", HibernateFactoryRegistry.CSD);
            data.put("host", "13.232.155.0");
            data.put("database", "dINSBA");
            data.put("csdSfHash", System.identityHashCode(csdSf));
            data.put("systemSfHash", System.identityHashCode(systemSessionFactory));
            data.put("sameSessionFactory",
                    System.identityHashCode(systemSessionFactory) == System.identityHashCode(csdSf));
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "CSD ping failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    @GetMapping("/users")
    public String users(@RequestParam(value = "limit", defaultValue = "5") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            long count = csdUserService.countUsers();
            List<Map<String, Object>> rows = csdUserService.listUsers(limit);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("datasource", HibernateFactoryRegistry.CSD);
            data.put("host", "13.232.155.0");
            data.put("database", "dINSBA");
            data.put("totalUsers", count);
            data.put("sample", rows);
            data.put("systemSfHash", System.identityHashCode(systemSessionFactory));
            data.put("csdSfHash", System.identityHashCode(CsdHybernetUtil.getSessionFactory()));
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "CSD query failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    /**
     * One HTTP call, two SessionFactories: system @Transactional + csd withSession.
     */
    @GetMapping("/compare")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String compare(@RequestParam(value = "limit", defaultValue = "3") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            Map<String, Object> data = new LinkedHashMap<>();

            Number systemCnt = systemSessionFactory.getCurrentSession()
                    .createNativeQuery("select count(*) from ia_user_master", Long.class)
                    .uniqueResult();
            data.put("systemHost", "13.232.155.0");
            data.put("systemDatabase", "dINSBA");
            data.put("systemUserCount", systemCnt);
            data.put("systemSfHash", System.identityHashCode(systemSessionFactory));

            long csdCnt = csdUserService.countUsers();
            List<Map<String, Object>> csdSample = csdUserService.listUsers(limit);
            data.put("csdHost", "PRODSQL445A\\SQL445A");
            data.put("csdDatabase", "dINTWSYS");
            data.put("csdUserCount", csdCnt);
            data.put("csdSample", csdSample);
            data.put("csdSfHash", System.identityHashCode(registry.getCsdSessionFactory()));
            data.put("sameSessionFactory",
                    System.identityHashCode(systemSessionFactory)
                            == System.identityHashCode(registry.getCsdSessionFactory()));

            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Compare failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }
}