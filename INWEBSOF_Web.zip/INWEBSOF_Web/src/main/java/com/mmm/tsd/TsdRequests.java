package com.mmm.tsd;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * TSD E-Warranty APIs. Working converter resolve order (every call):
 * Change Converter session → portal Change Customer → direct login.
 * Datasource: {@link HibernateFactoryRegistry#TSD}.
 */
@RestController
@RequestMapping("/api/customer/tsd")
public class TsdRequests {
	private static final Logger logger = LoggerFactory.getLogger(TsdRequests.class);
	private static final Gson GSON = new Gson();

	private final TsdRequestsSql sql;
	private final TsdContextResolver contextResolver;
	private final SaveTsdRequest saveTsdRequest;
	private final TsdDocUpload docUpload;

	public TsdRequests(HibernateFactoryRegistry registry, TsdDocUpload docUpload) {
		this.sql = new TsdRequestsSql(registry);
		this.contextResolver = new TsdContextResolver(sql);
		this.saveTsdRequest = new SaveTsdRequest(registry);
		this.docUpload = docUpload;
	}

	@GetMapping("/context")
	public String context(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					contextResolver.resolve(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", working.toMap());
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/requests")
	public String requests(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					requireConverter(request.getSession(false), custCode, loginId);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("header_details", sql.requests(working.convCode()));
			data.putAll(working.toMap());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** Full Request Details popup (legacy GetApprovalDetailsForPopup). */
	@GetMapping("/requests/{id}")
	public String requestDetail(HttpServletRequest request,
			@PathVariable("id") long id,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					requireConverter(request.getSession(false), custCode, loginId);
			Map<String, Object> header = sql.requestDetail(id, working.convCode());
			if (header == null) {
				throw new IllegalArgumentException("Request not found for this converter.");
			}
			List<Map<String, Object>> products = sql.requestProducts(id);
			for (Map<String, Object> product : products) {
				long productRowId = parseLong(product.get("internal_code"));
				product.put("signboard_rows",
						productRowId > 0 ? sql.requestSignboardRows(id, productRowId) : List.of());
			}
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("header", header);
			data.put("products", products);
			data.put("approvers", sql.requestApprovers(id));
			data.put("documents", sql.requestDocuments(id));
			data.put("history", sql.requestHistory(id));
			data.putAll(working.toMap());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/**
	 * Limited converter autocomplete for Change Converter
	 * (legacy {@code system_name=tsd_ovrride_con_code}).
	 */
	@GetMapping("/converters/autocomplete")
	public String converterAutocomplete(HttpServletRequest request,
			@RequestParam(value = "value", defaultValue = "") String value) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			HttpSession session = request.getSession(false);
			if (!UserSessionSupport.isLoggedIn(session)) {
				throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			}
			if (!TsdContextResolver.hasRolePublic(session, TsdContextResolver.ROLE_CHANGE_CONVERTER)) {
				throw new IllegalArgumentException("Change Converter is not permitted.");
			}
			String enlId = String.valueOf(session.getAttribute(UserSessionSupport.LOGIN_ID)).trim();
			result.SetSuccess("success", sql.converterAutocomplete(value, enlId));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** Set module Change Converter override (TSD only; does not change portal customer). */
	@PostMapping("/converter")
	public String setConverter(HttpServletRequest request,
			@RequestBody(required = false) Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			String code = body == null || body.get("convCode") == null
					? "" : String.valueOf(body.get("convCode"));
			TsdContextResolver.Working working =
					contextResolver.applyConverter(request.getSession(false), code);
			result.SetSuccess("success", working.toMap());
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** Clear module Change Converter; fall back to Change Customer / login. */
	@PostMapping("/converter/clear")
	public String clearConverter(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					contextResolver.clearConverter(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", working.toMap());
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/**
	 * New Request onload: distributor address/flags, states, product categories.
	 * Legacy: {@code getOnloadData} + {@code GetWarrantyTypesForSelectedDist} + state LOV.
	 */
	@GetMapping("/new-request/lookups")
	public String newRequestLookups(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					requireConverter(request.getSession(false), custCode, loginId);
			Map<String, Object> dist = sql.distributor(working.convCode());
			if (dist == null) {
				throw new IllegalArgumentException(
						"Converter " + working.convCode() + " is not registered in tsd_distributor.");
			}
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("distributor", dist);
			data.put("states", sql.states());
			data.put("productCategories", sql.productCategories());
			data.putAll(working.toMap());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** Product name autocomplete filtered by product category (legacy GetProductAutoComplete). */
	@GetMapping("/products/autocomplete")
	public String productAutocomplete(HttpServletRequest request,
			@RequestParam(value = "phrase", defaultValue = "") String phrase,
			@RequestParam(value = "categoryId", defaultValue = "") String categoryId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			HttpSession session = request.getSession(false);
			if (!UserSessionSupport.isLoggedIn(session)) {
				throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			}
			if (categoryId == null || categoryId.isBlank()) {
				throw new IllegalArgumentException("Product type is required.");
			}
			result.SetSuccess("success", sql.productAutocomplete(phrase, categoryId));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/**
	 * Approved PQ Warranty No autocomplete (legacy {@code TSDCommon/GetWarrantyAutoComplete}).
	 * Scoped to working converter.
	 */
	@GetMapping("/warranties/autocomplete")
	public String warrantyAutocomplete(HttpServletRequest request,
			@RequestParam(value = "phrase", defaultValue = "") String phrase,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					requireConverter(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", sql.warrantyAutocomplete(phrase, working.convCode()));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/**
	 * Legacy {@code TSDProductMaster/GetSavedProductMasterDynTableDetails}.
	 * Returns static product-master rows + signboard column metadata for New Request Product Details.
	 */
	@GetMapping("/products/{productId}/dyn-table")
	public String productDynTable(HttpServletRequest request,
			@PathVariable("productId") String productId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			HttpSession session = request.getSession(false);
			if (!UserSessionSupport.isLoggedIn(session)) {
				throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			}
			String id = text(productId);
			if (id.isBlank() || "0".equals(id)) {
				throw new IllegalArgumentException("Product is required.");
			}
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("query_data_obj", sql.productDynStaticRows(id));
			data.put("retro_query_data_obj", sql.productDynSignboardMeta(id));
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/**
	 * Approver matrix + document master + ASM/RSM/DM LOVs.
	 * Legacy: {@code GetDocumentList}.
	 */
	@GetMapping("/new-request/documents")
	public String newRequestDocuments(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "warrType", required = false) String warrType,
			@RequestParam(value = "custState", required = false) String custState,
			@RequestParam(value = "editIntCode", required = false, defaultValue = "0") String editIntCode) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					requireConverter(request.getSession(false), custCode, loginId);
			String type = text(warrType);
			if (type.isBlank()) {
				throw new IllegalArgumentException("Select a warranty type.");
			}
			String entity = text(working.warrantyObj().get("entity"));
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("query_docs_obj", sql.documentMaster(editIntCode, type));
			data.put("approval_matrix_obj", sql.approvalMatrix(entity, editIntCode, type));
			data.put("asm_obj", asmList(working, type, custState));
			data.put("rsm_nsm_obj", sql.rsmNsmList());
			data.put("approval_division_obj", sql.divisionList());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** ASM LOV refresh when customer state changes. Legacy: {@code GetASMListForCustomrState}. */
	@GetMapping("/new-request/asm")
	public String newRequestAsm(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "warrType", required = false) String warrType,
			@RequestParam(value = "custState", required = false) String custState) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working =
					requireConverter(request.getSession(false), custCode, loginId);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("asm_obj", asmList(working, text(warrType), custState));
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/**
	 * Draft / Submit New Request ({@code multipart/form-data}).
	 * Field {@code payload}: JSON {@code { header, products, approvers }}.
	 * Files: {@code header~{docIntCode}~{shortCode}}.
	 */
	@PostMapping(value = "/requests", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String saveRequest(MultipartHttpServletRequest request,
			@RequestParam("payload") String payloadJson,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		List<String> storedPaths = new ArrayList<>();
		try {
			HttpSession session = request.getSession(false);
			TsdContextResolver.Working working = requireConverter(session, custCode, loginId);
			Map<String, Object> payload = GSON.fromJson(payloadJson,
					new TypeToken<Map<String, Object>>() { }.getType());
			if (payload == null) {
				payload = Map.of();
			}
			Map<String, Object> header = payload.get("header") instanceof Map<?, ?> h
					? castMap(h) : castMap(payload);
			List<Map<String, Object>> products = toMapList(payload.get("products"));
			if (products.isEmpty()) {
				products = toMapList(header.get("products"));
			}
			List<Map<String, Object>> approvers = toMapList(payload.get("approvers"));
			String enlId = String.valueOf(session.getAttribute(UserSessionSupport.LOGIN_ID)).trim();
			String enlName = String.valueOf(
					session.getAttribute(UserSessionSupport.LOGIN_USER_NAME) == null
							? "" : session.getAttribute(UserSessionSupport.LOGIN_USER_NAME)).trim();
			result.SetSuccess("success",
					saveTsdRequest.save(working, enlId, enlName, header, products, approvers,
							(reqId, headerId) -> storeUploads(request, reqId, storedPaths)));
		} catch (Exception ex) {
			for (String path : storedPaths) {
				docUpload.remove(path);
			}
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	private List<Map<String, Object>> asmList(
			TsdContextResolver.Working working, String warrType, String custState) {
		if ("PPC for Retail Sale".equals(warrType)) {
			return sql.asmByDistributor(working.convCode());
		}
		return sql.asmByState(text(custState));
	}

	/**
	 * Multipart fields:
	 * {@code header~{docIntCode}~{shortCode}} — approver attachments;
	 * {@code signboard~{prodSlNo}~{rowSeq}} — per-row Product Details files.
	 */
	private SaveTsdRequest.UploadBundle storeUploads(
			MultipartHttpServletRequest request, String reqId, List<String> storedPaths)
			throws Exception {
		List<Map<String, Object>> documents = new ArrayList<>();
		List<Map<String, Object>> signboardFiles = new ArrayList<>();
		Iterator<String> names = request.getFileNames();
		while (names.hasNext()) {
			String field = names.next();
			MultipartFile file = request.getFile(field);
			if (file == null || file.isEmpty()) {
				continue;
			}
			String[] parts = field.split("~");
			if (parts.length < 2) {
				continue;
			}
			String original = file.getOriginalFilename();
			if (original == null || original.isBlank()) {
				original = "document";
			}
			String safeName = original.replaceAll("[^A-Za-z0-9._ -]", "_");
			if ("header".equalsIgnoreCase(parts[0])) {
				String docIntCode = text(parts[1]);
				String path = docUpload.store(reqId, "header_" + docIntCode, original, file.getBytes());
				storedPaths.add(path);
				Map<String, Object> row = new LinkedHashMap<>();
				row.put("doc_int_code", docIntCode);
				row.put("document_name", safeName);
				row.put("document_path", path);
				documents.add(row);
			} else if ("signboard".equalsIgnoreCase(parts[0]) && parts.length >= 3) {
				String prodSl = text(parts[1]);
				String rowSeq = text(parts[2]);
				String path = docUpload.store(reqId, "signboard_" + prodSl + "_" + rowSeq,
						original, file.getBytes());
				storedPaths.add(path);
				Map<String, Object> row = new LinkedHashMap<>();
				row.put("prod_sl", prodSl);
				row.put("row_seq", rowSeq);
				row.put("document_name", safeName);
				row.put("document_path", path);
				signboardFiles.add(row);
			}
		}
		return new SaveTsdRequest.UploadBundle(documents, signboardFiles);
	}

	private static Map<String, Object> castMap(Map<?, ?> source) {
		Map<String, Object> map = new LinkedHashMap<>();
		if (source != null) {
			source.forEach((key, value) -> map.put(String.valueOf(key), value));
		}
		return map;
	}

	private static List<Map<String, Object>> toMapList(Object value) {
		List<Map<String, Object>> list = new ArrayList<>();
		if (!(value instanceof List<?> source)) {
			return list;
		}
		for (Object item : source) {
			if (item instanceof Map<?, ?> map) {
				list.add(castMap(map));
			}
		}
		return list;
	}

	private TsdContextResolver.Working requireConverter(
			HttpSession session, String custCode, String loginId) {
		TsdContextResolver.Working working = contextResolver.resolve(session, custCode, loginId);
		if (working.needsConverterSelection() || working.convCode().isBlank()) {
			throw new IllegalArgumentException(
					"Select a TSD converter (Change Converter) before continuing.");
		}
		return working;
	}

	private static String error(ResponseDataGeneric result, Exception ex) {
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure", ex.getMessage());
		} else {
			/* Always print stack — validation messages still return to the client. */
			logger.error("Unable to process TSD request: {}", ex.getMessage(), ex);
			result.SetError(-1, "failure",
					ex instanceof IllegalArgumentException || ex instanceof IllegalStateException
							? ex.getMessage() : "Unable to process the TSD request.");
		}
		return GSON.toJson(result);
	}

	private static long parseLong(Object value) {
		if (value == null) {
			return 0L;
		}
		String text = String.valueOf(value).trim();
		if (text.isEmpty()) {
			return 0L;
		}
		try {
			return Long.parseLong(text.split("\\.")[0]);
		} catch (NumberFormatException ex) {
			return 0L;
		}
	}
}
