package com.mmm.tsd;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.html2pdf.resolver.font.DefaultFontProvider;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.event.AbstractPdfDocumentEvent;
import com.itextpdf.kernel.pdf.event.AbstractPdfDocumentEventHandler;
import com.itextpdf.kernel.pdf.event.PdfDocumentEvent;
import com.itextpdf.layout.Canvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Div;
import com.itextpdf.layout.element.IBlockElement;
import com.itextpdf.layout.element.IElement;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.font.FontProvider;
import com.itextpdf.layout.properties.AreaBreakType;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.VerticalAlignment;

/**
 * TSD warranty PDF (legacy {@code TSDPQWarrantyPDF} / {@code TSDPPCWarrantyPDF}).
 * <p>
 * Letterhead: absolute logo + Confidential + date on every page (top margin band).
 * Company address flows in the body (start + after each explicit page break), matching
 * legacy density (~5 pages) without overlapping Date / Warranty No / clauses.
 */
final class TsdWarrantyPdfBuilder {
	private static final Logger logger = LoggerFactory.getLogger(TsdWarrantyPdfBuilder.class);
	private static final String LOGO_RESOURCE = "tsd/images/3m.png";
	/** Optional signature images: {@code tsd/images/signatures/{enl_id}.png} (also .jpg). */
	private static final String SIGN_RESOURCE_DIR = "tsd/images/signatures/";

	/*
	 * iText Document.setMargins(top, right, bottom, left) — NOT left/right/top/bottom.
	 * Wrong order previously made top=25 (logo/body overlap) and bottom≈150 (~8 pages).
	 * Legacy TSDPQWarrantyPDF: left/right 25, top ~60 logo band, bottom 33.
	 * Use 70 top so logo (≈56pt) clears body with a few points of gap.
	 */
	private static final float MARGIN_LEFT = 25f;
	private static final float MARGIN_RIGHT = 25f;
	private static final float MARGIN_TOP = 70f;
	private static final float MARGIN_BOTTOM = 33f;

	/** Max chars per letterhead / HTML address line before soft-wrap. */
	private static final int ADDR_WRAP_CHARS = 52;

	/* Absolute header geometry — must fit entirely inside MARGIN_TOP. */
	private static final float LH_CONF_BAND = 14f;
	private static final float LH_LOGO_GAP = 2f;
	private static final float LH_LOGO_H = 40f;
	private static final float LH_LOGO_W = 60f;
	private static final float LH_LOGO_X = MARGIN_LEFT;

	private final TsdWarrantyPdfSql sql;

	TsdWarrantyPdfBuilder(TsdWarrantyPdfSql sql) {
		this.sql = sql;
	}

	record PdfResult(byte[] bytes, String fileName) {
	}

	PdfResult build(long requestId, long productMasterId, String converterCode) throws Exception {
		Map<String, Object> header = sql.header(requestId, converterCode);
		if (header == null) {
			throw new IllegalArgumentException("Request not found for this converter.");
		}
		String status = text(header.get("status"));
		if (!"Approved".equalsIgnoreCase(status)) {
			throw new IllegalArgumentException("Warranty certificate is available after approval.");
		}
		Map<String, Object> product = sql.product(requestId, productMasterId);
		if (product == null) {
			throw new IllegalArgumentException("Product was not found for this request.");
		}

		String warrantyType = text(header.get("wrty_type"));
		Map<String, Object> divMgr = sql.divisionManager(requestId);
		Map<String, String> tokens = tokens(header, product, warrantyType, divMgr);
		String templateId = resolveTemplateId(warrantyType, product);
		List<Map<String, Object>> templates = sql.templates(templateId);
		if (templates.isEmpty()) {
			throw new IllegalStateException("Warranty PDF template is not configured for this product.");
		}

		byte[] logoBytes = readLogo();
		String ticketDate = text(header.get("req_date"));
		String ticketNo = text(header.get("req_id")).toUpperCase(Locale.ROOT);
		String prodWarr = text(product.get("prod_warranty_code"));
		String fileName = (prodWarr.isBlank() ? ticketNo : ticketNo + "-" + prodWarr) + ".pdf";
		String[] addressLines = resolveAddressLines(sql.mmmAddress());

		ByteArrayOutputStream output = new ByteArrayOutputStream();
		PdfWriter writer = new PdfWriter(output);
		PdfDocument pdf = new PdfDocument(writer);
		/* immediateFlush=false helps margins stick across AreaBreak / html2pdf splits. */
		Document document = new Document(pdf, PageSize.A4, false);
		applyMargins(document);

		/*
		 * Absolute header on END_PAGE so logo/date paint above any stray body ink.
		 * Address is document-flow content so Date / Warranty No never collide with it.
		 */
		pdf.addEventHandler(PdfDocumentEvent.END_PAGE,
				new HeaderHandler(logoBytes, ticketDate));
		pdf.addEventHandler(PdfDocumentEvent.END_PAGE, new WatermarkHandler());

		addAddressBlock(document, addressLines);

		for (Map<String, Object> templateRow : templates) {
			String pdfText = text(templateRow.get("pdf_text"));
			if (pdfText.isBlank()) {
				continue;
			}
			boolean addBefore = hasControlToken(pdfText, "ADD_BEFORE_PAGE");
			boolean addAfter = hasAddPageToken(pdfText);
			boolean hasRetro = hasControlToken(pdfText, "{RETRO_TABLE}");
			boolean hasSignboard = hasControlToken(pdfText, "{SIGN_BOARD_TABLE}");

			if (addBefore) {
				newPage(document, addressLines);
			}
			String html = normalizeHtml(stripControlTokens(replaceTokens(pdfText, tokens)));
			/* Skip empty chunks left by {USAGE_CONFORMANCE_CERTIFICATE} / control tokens — avoids large gaps. */
			if (!isBlankHtml(html)) {
				addHtml(document, html);
			}

			if (addAfter) {
				newPage(document, addressLines);
			}
			if (hasRetro) {
				addDataTable(document,
						text(product.get("prod_table_name")),
						text(product.get("prod_table_columns")),
						sql.staticTableRows(text(product.get("product_master_int_code"))),
						false);
			}
			if (hasSignboard) {
				addDataTable(document,
						"Details of Sign Boards installed using 3M Reflective Sheeting",
						text(product.get("prod_sign_board_table_columns")),
						sql.signboardRows(requestId, text(product.get("internal_code"))),
						true);
			}
		}

		document.close();
		logger.info("TSD warranty PDF built: requestId={} productMasterId={} type={} pages~ margins={}/{}/{}/{} bytes={}",
				requestId, productMasterId, warrantyType,
				MARGIN_TOP, MARGIN_RIGHT, MARGIN_BOTTOM, MARGIN_LEFT, output.size());
		return new PdfResult(output.toByteArray(), fileName);
	}

	/** iText API order: top, right, bottom, left. */
	private static void applyMargins(Document document) {
		document.setMargins(MARGIN_TOP, MARGIN_RIGHT, MARGIN_BOTTOM, MARGIN_LEFT);
	}

	private static void newPage(Document document, String[] addressLines) throws Exception {
		document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		applyMargins(document);
		addAddressBlock(document, addressLines);
	}

	/** Company address under the logo band (flow), soft-wrapped. */
	private static void addAddressBlock(Document document, String[] addressLines) throws Exception {
		if (addressLines == null || addressLines.length == 0) {
			return;
		}
		PdfFont font = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);
		for (String line : addressLines) {
			if (line == null || line.isBlank()) {
				continue;
			}
			document.add(new Paragraph(line.trim())
					.setFont(font)
					.setFontSize(10)
					.setMargin(0)
					.setPadding(0)
					.setFixedLeading(11f)
					.setTextAlignment(TextAlignment.LEFT));
		}
		/* Small gap before Date / Warranty No from HTML template. */
		document.add(new Paragraph("\u00a0")
				.setFont(font)
				.setFontSize(6)
				.setMargin(0)
				.setPadding(0)
				.setFixedLeading(6f));
	}

	private static String[] resolveAddressLines(String mmmAddress) {
		String raw = text(mmmAddress)
				.replace("\r\n", "\n")
				.replace('\r', '\n');
		raw = raw.replaceAll("(?i)</?br\\s*/?>", "\n");
		List<String> lines = new ArrayList<>();
		if (!raw.isBlank()) {
			for (String part : raw.split("\n")) {
				String line = part.trim();
				if (!line.isEmpty()) {
					lines.addAll(wrapPlainLines(line, ADDR_WRAP_CHARS));
				}
			}
		}
		if (lines.isEmpty()) {
			/* Same default as legacy HeaderFooterPageEvent HTML. */
			lines.add("3M India Limited");
			lines.add("3M India Ltd, 5th floor, Mark Square,");
			lines.add("61, St Marks Road");
			lines.add("Bangalore-560001");
		}
		if (lines.size() > 6) {
			return lines.subList(0, 6).toArray(new String[0]);
		}
		return lines.toArray(new String[0]);
	}

	/** Soft-wrap long addresses for HTML body tokens ({@code <br/>} at commas/spaces). */
	private static String wrapAddressHtml(String address) {
		List<String> lines = wrapPlainLines(text(address), ADDR_WRAP_CHARS);
		if (lines.isEmpty()) {
			return "";
		}
		return String.join("<br/>", lines);
	}

	private static List<String> wrapPlainLines(String text, int maxChars) {
		List<String> out = new ArrayList<>();
		String s = text == null ? "" : text.trim().replaceAll("\\s+", " ");
		if (s.isEmpty()) {
			return out;
		}
		while (s.length() > maxChars) {
			int breakAt = -1;
			for (int i = Math.min(maxChars, s.length() - 1); i >= Math.max(20, maxChars / 2); i--) {
				char c = s.charAt(i);
				if (c == ',' || c == ' ' || c == '-' || c == '/') {
					breakAt = i + (c == ' ' ? 0 : 1);
					break;
				}
			}
			if (breakAt <= 0) {
				breakAt = maxChars;
			}
			String piece = s.substring(0, breakAt).trim();
			if (!piece.isEmpty()) {
				out.add(piece);
			}
			s = s.substring(breakAt).trim();
			if (s.startsWith(",")) {
				s = s.substring(1).trim();
			}
		}
		if (!s.isEmpty()) {
			out.add(s);
		}
		return out;
	}

	/** Fix legacy template quirks that break html2pdf wrapping / pull content into header. */
	private static String normalizeHtml(String html) {
		String out = html == null ? "" : html;
		/* DB templates often use invalid {@code </br>} — shows as literal text in pdfHTML. */
		out = out.replaceAll("(?i)</br\\s*>", "<br/>");
		out = out.replaceAll("(?i)<br\\s*>", "<br/>");
		out = out.replaceAll("(?i)<br\\s*/\\s*>", "<br/>");
		/*
		 * Collapse double/triple <br/> to one so DM name / title / division match legacy
		 * single-line spacing. Then restore a double break only before major section titles.
		 */
		out = out.replaceAll("(?i)(?:\\s*<br\\s*/?>\\s*){2,}", "<br/>");
		out = out.replaceAll(
				"(?i)(<br\\s*/?>)\\s*((?:<(?:u|b|strong|i|em|span|font)[^>]*>\\s*)*)"
						+ "(USAGE\\s+CONFORMANCE\\s+CERTIFICATE)",
				"<br/><br/>$2$3");
		out = out.replaceAll("(?i)<p[^>]*>\\s*(?:&nbsp;|&#160;|\\u00a0|\\s)*\\s*</p>", "");
		out = out.replaceAll("(?i)<div[^>]*>\\s*(?:&nbsp;|&#160;|\\u00a0|\\s)*\\s*</div>", "");
		out = out.replaceAll("(?i)<span[^>]*>\\s*(?:&nbsp;|&#160;|\\u00a0|\\s)*\\s*</span>", "");
		out = out.replaceAll("(?i)\\s+nowrap\\s*=\\s*(['\"]?)nowrap\\1", "");
		out = out.replaceAll("(?i)\\s+nowrap(?=[\\s>])", "");
		out = out.replaceAll("(?i)white-space\\s*:\\s*nowrap\\s*;?", "white-space:normal;");
		out = out.replaceAll("(?i)word-break\\s*:\\s*keep-all\\s*;?", "word-break:break-word;");
		/* Legacy XMLWorker used padding-top:-35px — pulls Date into letterhead in pdfHTML. */
		out = out.replaceAll("(?i)padding-top\\s*:\\s*-\\d+(\\.\\d+)?(px|pt|em)?\\s*;?", "padding-top:0;");
		out = out.replaceAll("(?i)margin-top\\s*:\\s*-\\d+(\\.\\d+)?(px|pt|em)?\\s*;?", "margin-top:0;");
		out = out.replaceAll("(?i)margin-left\\s*:\\s*-\\d+(\\.\\d+)?(px|pt|em)?\\s*;?", "margin-left:0;");
		out = out.replaceAll("(?i)top\\s*:\\s*-\\d+(\\.\\d+)?(px|pt|em)?\\s*;?", "top:auto;");
		/* Keep float left/right — setup HTML uses them for AUTHORISED SIGNATORY two-column block. */
		out = out.replaceAll("(?i)position\\s*:\\s*absolute\\s*;?", "position:static;");
		/* Oversized fixed widths clip the last table column on A4 (~545pt content). */
		out = out.replaceAll("(?i)\\swidth\\s*=\\s*['\"]?(?:5\\d{2}|[6-9]\\d{2}|\\d{4,})(?:px|pt)?['\"]?",
				" width=\"100%\"");
		out = out.replaceAll("(?i)width\\s*:\\s*(?:5\\d{2}|[6-9]\\d{2}|\\d{4,})(?:px|pt)?\\s*;?", "width:100%;");
		out = out.replaceAll("(?i)min-width\\s*:\\s*\\d+(\\.\\d+)?(px|pt)?\\s*;?", "");
		out = out.replaceAll("(?i)max-width\\s*:\\s*(?:5\\d{2}|[6-9]\\d{2}|\\d{4,})(?:px|pt)?\\s*;?", "max-width:100%;");
		/* pdfHTML float support is weak — convert float L/R signatory columns to a 2-col table. */
		out = convertFloatSignatoryToTable(out);
		return out;
	}

	/**
	 * Setup templates often use {@code float:left}/{@code float:right} for
	 * 3M INDIA LIMITED | M/S {CONV_NAME} AUTHORISED SIGNATORY columns.
	 * Rebuild as a table so both AUTHORISED SIGNATORY lines share one baseline.
	 */
	private static String convertFloatSignatoryToTable(String html) {
		if (html == null || html.isBlank()) {
			return html;
		}
		String upper = html.toUpperCase(Locale.ROOT);
		if (!upper.contains("AUTHORISED SIGNATORY") || !upper.contains("FLOAT")) {
			return html;
		}
		java.util.regex.Pattern pair = java.util.regex.Pattern.compile(
				"(?is)(<div[^>]*style\\s*=\\s*[\"'][^\"']*float\\s*:\\s*left[^\"']*[\"'][^>]*>)(.*?)</div>\\s*"
						+ "(<div[^>]*style\\s*=\\s*[\"'][^\"']*float\\s*:\\s*right[^\"']*[\"'][^>]*>)(.*?)</div>");
		java.util.regex.Matcher m = pair.matcher(html);
		StringBuffer sb = new StringBuffer();
		boolean any = false;
		while (m.find()) {
			any = true;
			String left = m.group(2) == null ? "" : m.group(2).trim();
			String right = m.group(4) == null ? "" : m.group(4).trim();
			String table = "<table width=\"100%\" style=\"width:100%;border:0;border-collapse:collapse;\">"
					+ "<tr>"
					+ "<td width=\"50%\" valign=\"top\" style=\"width:50%;vertical-align:top;text-align:left;"
					+ "border:0;padding:0 8px 0 0;\">" + left + "</td>"
					+ "<td width=\"50%\" valign=\"top\" style=\"width:50%;vertical-align:top;text-align:right;"
					+ "border:0;padding:0 0 0 8px;\">" + right + "</td>"
					+ "</tr></table>";
			m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(table));
		}
		if (!any) {
			return html;
		}
		m.appendTail(sb);
		return sb.toString();
	}

	/** True when HTML has no visible text (only tags / breaks / nbsp). */
	private static boolean isBlankHtml(String html) {
		if (html == null || html.isBlank()) {
			return true;
		}
		String plain = html
				.replaceAll("(?is)<style[^>]*>.*?</style>", "")
				.replaceAll("(?i)<br\\s*/?>", " ")
				.replaceAll("(?is)<[^>]+>", " ")
				.replace("&nbsp;", " ")
				.replace("&#160;", " ")
				.replace('\u00a0', ' ')
				.replaceAll("\\s+", " ")
				.trim();
		return plain.isEmpty();
	}

	private static String resolveTemplateId(String warrantyType, Map<String, Object> product) {
		if ("Actual Warranty".equals(warrantyType)) {
			return text(product.get("actual_template"));
		}
		if ("PPC for Retail Sale".equals(warrantyType)) {
			return text(product.get("ppc_template"));
		}
		return text(product.get("pq_template"));
	}

	private static Map<String, String> tokens(
			Map<String, Object> header, Map<String, Object> product, String warrantyType,
			Map<String, Object> divMgr) {
		Map<String, String> map = new LinkedHashMap<>();
		String ticket = text(header.get("req_id")).toUpperCase(Locale.ROOT);
		String prodWarr = text(product.get("prod_warranty_code"));
		String divName = text(divMgr == null ? null : divMgr.get("division_manager_name"));
		String divEnl = text(divMgr == null ? null : divMgr.get("div_manager_enl"));
		map.put("{PROD_NAME}", text(product.get("product_name")));
		map.put("{TICKET_NO}", prodWarr.isBlank() ? ticket : ticket + "-" + prodWarr);
		map.put("{TICKET_DATE}", text(header.get("req_date")));
		map.put("{DIST_NAME}", upper(header.get("ppc_distibutor")));
		map.put("{CUST_NAME}", upper(header.get("customer_name")));
		map.put("{CUST_ADDR}", wrapAddressHtml(upper(header.get("cust_address"))));
		map.put("{CUST_STATE}", upper(header.get("cust_state")));
		map.put("{CONV_NAME}", upper(header.get("distributor_name")));
		map.put("{CONV_ADDR}", wrapAddressHtml(upper(header.get("dist_address"))));
		map.put("{CONV_STATE}", upper(header.get("dist_state")));
		map.put("{CONTR_NAME}", upper(header.get("contract_name")));
		map.put("{CONTR_ADDR}", wrapAddressHtml(upper(header.get("contract_address"))));
		map.put("{CONTR_STATE}", upper(header.get("contract_state")));
		map.put("{WO_NO}", upper(header.get("tender_no")));
		map.put("{WO_DETAILS}", text(product.get("work_order_details")));
		map.put("{RETRO_TABLE}", "");
		map.put("{USAGE_CONFORMANCE_CERTIFICATE}", "");
		map.put("{SIGN_BOARD_TABLE}", "");
		map.put("{SIGN_BOARD_TABLE_NAME}", text(product.get("sign_board_table_label")));
		map.put("{BUYER_NAME}", upper(header.get("buyer_name")));
		map.put("{DATE_OF_SALE}", text(header.get("date_of_sale")));
		map.put("{W_YEARS}", text(product.get("no_of_warrnty_years")));
		map.put("{PPC_Qty}", text(product.get("ppc_qty")));
		map.put("{DOCUMENT_HEADING_NAME}", documentHeading(warrantyType));
		/* Template tokens for authorised signatory block (missing in earlier builder). */
		map.put("{DIVISION_MANAGER}", divName);
		map.put("{Division_Manager}", divName);
		map.put("{Div_manager_sign}", signatureImgHtml(divEnl));
		map.put("{DIV_MANAGER_SIGN}", signatureImgHtml(divEnl));
		String installDate = text(product.get("actual_date_of_instl"));
		map.put("{Actual_installation_date}", installDate);
		map.put("{ACTUAL_INSTALLATION_DATE}", installDate);
		map.put("{actual_installation_date}", installDate);
		return map;
	}

	/**
	 * Optional signature image for Division Manager. Looks under
	 * {@code classpath:tsd/images/signatures/{enl}.png|.jpg}. Empty if missing (never leave the token).
	 */
	private static String signatureImgHtml(String enlId) {
		String enl = text(enlId);
		if (enl.isBlank()) {
			return "";
		}
		String safe = enl.replaceAll("[^A-Za-z0-9._-]", "");
		if (safe.isBlank()) {
			return "";
		}
		for (String ext : new String[] { "png", "jpg", "jpeg", "gif" }) {
			String path = SIGN_RESOURCE_DIR + safe + "." + ext;
			try {
				ClassPathResource resource = new ClassPathResource(path);
				if (!resource.exists()) {
					continue;
				}
				byte[] bytes;
				try (InputStream in = resource.getInputStream()) {
					bytes = in.readAllBytes();
				}
				if (bytes.length == 0) {
					continue;
				}
				String mime = "image/" + ("jpg".equals(ext) || "jpeg".equals(ext) ? "jpeg" : ext);
				String b64 = Base64.getEncoder().encodeToString(bytes);
				return "<img src=\"data:" + mime + ";base64," + b64
						+ "\" alt=\"\" style=\"display:block;height:48px;max-width:160px;margin:0;padding:0;\"/>";
			} catch (Exception ex) {
				logger.debug("TSD warranty signature asset skip {}: {}", path, ex.toString());
			}
		}
		logger.info("TSD warranty PDF: no signature image for enl={} under {}", safe, SIGN_RESOURCE_DIR);
		return "";
	}

	private static String documentHeading(String warrantyType) {
		if (warrantyType != null && warrantyType.toUpperCase(Locale.ROOT).contains("PQ")) {
			return "PREQUALIFICATION WARRANTY CERTIFICATE";
		}
		if (warrantyType != null && warrantyType.toUpperCase(Locale.ROOT).contains("PPC")) {
			return "3M Product Performance Certificate";
		}
		if (warrantyType != null && warrantyType.toUpperCase(Locale.ROOT).contains("ACTUAL")) {
			return "WARRANTY CERTIFICATE";
		}
		return "WARRANTY CERTIFICATE";
	}

	private static String replaceTokens(String html, Map<String, String> tokens) {
		String out = html == null ? "" : html;
		for (Map.Entry<String, String> entry : tokens.entrySet()) {
			out = out.replace(entry.getKey(), entry.getValue() == null ? "" : entry.getValue());
		}
		return out;
	}

	private static boolean hasControlToken(String text, String token) {
		if (text == null || token == null || token.isBlank()) {
			return false;
		}
		return text.toUpperCase(Locale.ROOT).contains(token.toUpperCase(Locale.ROOT));
	}

	private static boolean hasAddPageToken(String text) {
		if (text == null || text.isBlank()) {
			return false;
		}
		String upper = text.toUpperCase(Locale.ROOT)
				.replace("{ADD_BEFORE_PAGE}", "")
				.replace("ADD_BEFORE_PAGE", "");
		return upper.contains("{ADD_PAGE}") || upper.contains("ADD_PAGE");
	}

	private static String stripControlTokens(String html) {
		String out = html == null ? "" : html;
		out = out.replaceAll("(?i)\\{ADD_BEFORE_PAGE\\}", "");
		out = out.replaceAll("(?i)ADD_BEFORE_PAGE", "");
		out = out.replaceAll("(?i)\\{ADD_PAGE\\}", "");
		out = out.replaceAll("(?i)ADD_PAGE", "");
		out = out.replaceAll("(?i)\\{RETRO_TABLE\\}", "");
		out = out.replaceAll("(?i)\\{SIGN_BOARD_TABLE\\}", "");
		out = out.replaceAll("(?i)\\{USAGE_CONFORMANCE_CERTIFICATE\\}", "");
		/* Never leave unresolved signatory / date tokens visible in the PDF. */
		out = out.replaceAll("(?i)\\{DIVISION_MANAGER\\}", "");
		out = out.replaceAll("(?i)\\{Div_manager_sign\\}", "");
		out = out.replaceAll("(?i)\\{DIV_MANAGER_SIGN\\}", "");
		out = out.replaceAll("(?i)\\{Actual_installation_date\\}", "");
		return out;
	}

	private static void addHtml(Document document, String html) {
		/*
		 * Legacy XMLWorker: Times / justify / line-height 20px.
		 * Do NOT force float:none — setup HTML uses float/table for
		 * left (3M + DM) / right (M/S {CONV_NAME}) AUTHORISED SIGNATORY columns.
		 */
		String body = html == null ? "" : html;
		boolean signatoryBlock = body.toUpperCase(Locale.ROOT).contains("AUTHORISED SIGNATORY")
				|| body.toUpperCase(Locale.ROOT).contains("DIVISION SALES MANAGER");
		String wrapped = "<style>"
				+ "html,body{margin:0;padding:0;}"
				+ "#pdf_div{font-family:'Times New Roman',Times,serif!important;"
				+ "text-align:justify;line-height:18px;font-size:11pt;margin:0;padding:0;"
				+ "word-wrap:break-word;overflow-wrap:anywhere;}"
				+ "#pdf_div p,#pdf_div li,#pdf_div h1,#pdf_div h2,#pdf_div h3,#pdf_div h4,"
				+ "#pdf_div center{margin:0!important;padding:0!important;"
				+ "white-space:normal!important;word-wrap:break-word;overflow-wrap:anywhere;}"
				+ "#pdf_div p{margin:0 0 2px 0!important;}"
				+ "#pdf_div br{line-height:14px;}"
				+ "#pdf_div ul,#pdf_div ol{margin:1px 0 1px 16px!important;padding:0;}"
				+ "#pdf_div table{border-collapse:collapse;width:100%!important;max-width:100%!important;}"
				+ "#pdf_div td,#pdf_div th{overflow-wrap:anywhere;word-wrap:break-word;"
				+ "vertical-align:top;padding:1px 2px!important;}"
				+ "#pdf_div img{max-width:160px;height:auto;}"
				/* Clear floats after signatory columns so following sections start clean. */
				+ "#pdf_div::after{content:'';display:table;clear:both;}"
				+ "</style>"
				+ "<div id=\"pdf_div\">" + body + "</div>";
		ConverterProperties props = new ConverterProperties();
		FontProvider fontProvider = new DefaultFontProvider(true, true, true);
		props.setFontProvider(fontProvider);
		List<IElement> elements = HtmlConverter.convertToElements(wrapped, props);
		Div container = new Div().setMargin(0).setPadding(0);
		if (signatoryBlock) {
			/* Keep two-column signatory block from splitting onto a nearly-empty last page. */
			container.setKeepTogether(true);
		}
		for (IElement element : elements) {
			if (element instanceof IBlockElement block) {
				container.add(block);
			} else if (element instanceof Image image) {
				container.add(image);
			}
		}
		document.add(container);
	}

	private static void addDataTable(Document document, String title, String columnsCsv,
			List<Map<String, Object>> rows, boolean skipDocumentColumn) throws Exception {
		if (columnsCsv == null || columnsCsv.isBlank()) {
			return;
		}
		String[] columns = columnsCsv.split(",");
		List<String> headers = new ArrayList<>();
		for (String column : columns) {
			String name = column.trim();
			if (skipDocumentColumn && "Document".equalsIgnoreCase(name)) {
				continue;
			}
			headers.add(name);
		}
		if (headers.isEmpty()) {
			return;
		}

		PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
		PdfFont normal = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);

		/* Legacy FormStaticTable / FormRetroTable: title height 20, header 40, rows 20. */
		Table titleTable = new Table(UnitValue.createPercentArray(new float[] { 1 }))
				.useAllAvailableWidth()
				.setMarginTop(2)
				.setMarginBottom(0);
		titleTable.addCell(new Cell()
				.add(new Paragraph(title == null || title.isBlank() ? "Details" : title)
						.setFont(bold).setFontSize(12).setTextAlignment(TextAlignment.CENTER)
						.setMargin(0))
				.setMinHeight(20)
				.setPadding(2)
				.setVerticalAlignment(VerticalAlignment.MIDDLE));
		document.add(titleTable);

		float[] widths = new float[headers.size()];
		for (int i = 0; i < headers.size(); i++) {
			widths[i] = 2f;
		}
		Table table = new Table(UnitValue.createPercentArray(widths)).useAllAvailableWidth()
				.setMarginTop(0).setMarginBottom(4)
				.setWidth(UnitValue.createPercentValue(100));
		for (String name : headers) {
			table.addHeaderCell(new Cell()
					.add(new Paragraph(name).setFont(bold).setFontSize(11)
							.setTextAlignment(TextAlignment.CENTER).setMargin(0))
					.setMinHeight(36)
					.setPadding(2)
					.setVerticalAlignment(VerticalAlignment.MIDDLE));
		}
		for (Map<String, Object> row : rows) {
			String[] cells = text(row.get("tr_data")).split("~", -1);
			for (int i = 0; i < headers.size(); i++) {
				String value = i < cells.length ? cells[i] : "";
				table.addCell(new Cell()
						.add(new Paragraph(value).setFont(normal).setFontSize(9)
								.setTextAlignment(TextAlignment.CENTER).setMargin(0))
						.setMinHeight(18)
						.setPadding(2)
						.setVerticalAlignment(VerticalAlignment.MIDDLE));
			}
		}
		document.add(table);
	}

	private static byte[] readLogo() throws Exception {
		ClassPathResource resource = new ClassPathResource(LOGO_RESOURCE);
		if (!resource.exists()) {
			throw new IllegalStateException("TSD logo resource missing: " + LOGO_RESOURCE);
		}
		try (InputStream in = resource.getInputStream()) {
			return in.readAllBytes();
		}
	}

	private static String upper(Object value) {
		return text(value).toUpperCase(Locale.ROOT);
	}

	/**
	 * Absolute letterhead inside the top margin band only (logo + Confidential + date).
	 * Address is not drawn here — it flows in the body under this band.
	 */
	private static final class HeaderHandler extends AbstractPdfDocumentEventHandler {
		private final byte[] logoBytes;
		private final String ticketDate;

		HeaderHandler(byte[] logoBytes, String ticketDate) {
			this.logoBytes = logoBytes;
			this.ticketDate = ticketDate == null ? "" : ticketDate;
		}

		@Override
		protected void onAcceptedEvent(AbstractPdfDocumentEvent event) {
			try {
				PdfDocumentEvent docEvent = (PdfDocumentEvent) event;
				PdfDocument pdf = docEvent.getDocument();
				PdfPage page = docEvent.getPage();
				Rectangle pageSize = page.getPageSize();
				float top = pageSize.getTop();
				PdfFont font = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);
				/* After body so Confidential / date / logo are never covered. */
				PdfCanvas pdfCanvas = new PdfCanvas(page.newContentStreamAfter(), page.getResources(), pdf);

				float logoY = top - LH_CONF_BAND - LH_LOGO_GAP - LH_LOGO_H;
				pdfCanvas.addImageFittedIntoRectangle(
						ImageDataFactory.create(logoBytes),
						new Rectangle(LH_LOGO_X, logoY, LH_LOGO_W, LH_LOGO_H), false);

				try (Canvas canvas = new Canvas(pdfCanvas, pageSize)) {
					canvas.setFont(font).setFontSize(10).setFontColor(ColorConstants.BLACK);
					canvas.showTextAligned("Confidential",
							pageSize.getWidth() / 2f, top - 11f, TextAlignment.CENTER);
					/* Full date top-right (RIGHT-aligned at inner margin). */
					if (!ticketDate.isBlank()) {
						canvas.showTextAligned(ticketDate,
								pageSize.getRight() - MARGIN_RIGHT, top - 11f, TextAlignment.RIGHT);
					}
				}
			} catch (Exception ex) {
				logger.warn("TSD warranty PDF header failed", ex);
			}
		}
	}

	private static final class WatermarkHandler extends AbstractPdfDocumentEventHandler {
		@Override
		protected void onAcceptedEvent(AbstractPdfDocumentEvent event) {
			try {
				PdfDocumentEvent docEvent = (PdfDocumentEvent) event;
				PdfDocument pdf = docEvent.getDocument();
				PdfPage page = docEvent.getPage();
				Rectangle pageSize = page.getPageSize();
				PdfFont font = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);
				PdfCanvas pdfCanvas = new PdfCanvas(page.newContentStreamBefore(), page.getResources(), pdf);
				try (Canvas canvas = new Canvas(pdfCanvas, pageSize)) {
					canvas.setFont(font).setFontSize(60).setFontColor(ColorConstants.LIGHT_GRAY);
					canvas.showTextAligned("Transportation Safety Division",
							300, 470, TextAlignment.CENTER, (float) Math.toRadians(53));
				}
			} catch (Exception ex) {
				logger.warn("TSD warranty PDF watermark failed", ex);
			}
		}
	}
}
