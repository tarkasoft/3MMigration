package com.mmm.tsd;

import static com.mmm.titpl.CommonFunctions.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/**
 * Draft / Submit TSD New Request in one transaction
 * (header + products + history + approvers + document metadata).
 * SMB bytes are stored via {@link TsdDocUpload#store} before document rows are written.
 */
final class SaveTsdRequest {
	private static final Logger logger = LoggerFactory.getLogger(SaveTsdRequest.class);

	private final HibernateFactoryRegistry registry;

	SaveTsdRequest(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	@FunctionalInterface
	interface DocumentUploader {
		UploadBundle store(String reqId, long headerId) throws Exception;
	}

	record UploadBundle(
			List<Map<String, Object>> documents,
			List<Map<String, Object>> signboardFiles) {
		static UploadBundle empty() {
			return new UploadBundle(List.of(), List.of());
		}
	}

	Map<String, Object> save(
			TsdContextResolver.Working working,
			String loginId,
			String loginName,
			Map<String, Object> header,
			List<Map<String, Object>> products,
			List<Map<String, Object>> approvers,
			DocumentUploader documentUploader) {
		if (header == null) {
			throw new IllegalArgumentException("Request details are required.");
		}
		if (products == null || products.isEmpty()) {
			throw new IllegalArgumentException("Enter at least one product.");
		}
		if (approvers == null || approvers.isEmpty()) {
			throw new IllegalArgumentException("Please enter Approver Details.");
		}

		String saveTypeRaw = text(header.get("save_type"));
		if (!"Draft".equalsIgnoreCase(saveTypeRaw) && !"Submit".equalsIgnoreCase(saveTypeRaw)) {
			throw new IllegalArgumentException("save_type must be Draft or Submit.");
		}
		String saveType = capitalize(saveTypeRaw);

		String warrType = text(header.get("warr_type"));
		boolean isPpc = "PPC for Retail Sale".equals(warrType);
		boolean isActual = "Actual Warranty".equals(warrType);
		if (!isPpc && !isActual && !"PQ Warranty".equals(warrType)) {
			throw new IllegalArgumentException("Select a warranty type.");
		}

		String custType = text(header.get("cust_type"));
		String firstPq = text(header.get("first_pq_warr"));
		String convRel = text(header.get("conv_relationship"));
		String pqCert = text(header.get("pq_cert_iss"));
		String agreement = text(header.get("agreement_signed"));
		String signedCurrent = text(header.get("signed_current"));
		String sopMcs = text(header.get("conv_sis_certified"));
		String remarks = text(header.get("customer_remarks"));
		String tenderNo = text(header.get("tender_no"));
		String customerName = text(header.get("customer_name"));
		String custAddr1 = text(header.get("customer_address1"));
		String custAddr2 = text(header.get("customer_address2"));
		String custState = text(header.get("cust_state"));
		String contractorName = text(header.get("contractor_name"));
		String contractorAddr1 = text(header.get("contractor_address1"));
		String contractorAddr2 = text(header.get("contractor_address2"));
		String contractorState = text(header.get("contractor_state"));
		String accOverdue = text(header.get("acc_overdue_status"));
		String dueDiligence = text(header.get("due_deligence_status"));
		String otherComments = text(header.get("other_comments"));
		String fyi = text(header.get("fyi"));
		String warrantyExists = text(header.get("warranty_exists"));
		String warrantyNo = text(header.get("warranty_no"));
		String firstPpc = text(header.get("first_ppc_cert"));
		String distAgrSigned = text(header.get("dist_agr_signed"));
		String buyerName = text(header.get("buyer_name"));
		/* UI is dd/mm/yyyy; SQL Server datetime needs yyyy-MM-dd (or null). */
		String dateOfSale = sqlDate(header.get("date_of_sale"), "Date of Sale");
		String ppcQtyRaw = text(header.get("ppc_quantity_produced"));
		String ppcQtyProduced = ppcQtyRaw.isEmpty() ? "0" : ppcQtyRaw;
		String roleCode = text(header.get("g_tsd_RoleCode"));
		long editIntCode = longVal(header.get("editIntCode"));

		String noOfProductsRaw = text(header.get("no_of_products"));
		String noOfProducts = noOfProductsRaw.isEmpty()
				? String.valueOf(products.size()) : noOfProductsRaw;
		int expected = intVal(noOfProducts, products.size());
		if (expected < 1 || expected > 10) {
			throw new IllegalArgumentException("No. of Products must be between 1 and 10.");
		}
		if (products.size() != expected) {
			throw new IllegalArgumentException("Product count does not match No. of Products.");
		}

		validateHeader(saveType, isPpc, isActual, custType, firstPq, convRel, pqCert, agreement,
				signedCurrent, sopMcs, remarks, tenderNo, customerName, custAddr1, custAddr2, custState,
				contractorName, contractorAddr1, contractorAddr2, contractorState, accOverdue,
				warrantyExists, warrantyNo, firstPpc, distAgrSigned, buyerName, dateOfSale);
		validateProducts(warrType, products);

		String reqDist = working.convCode();
		String distIntFromMaster = text(working.warrantyObj().get("dist_int_code"));
		String distIntCode = distIntFromMaster.isEmpty()
				? text(header.get("dist_int_code")) : distIntFromMaster;
		String distDisplayRaw = working.convDisplay();
		String distDisplay = distDisplayRaw.isEmpty()
				? text(header.get("dist_name")) : distDisplayRaw;
		/*
		 * Legacy PPC: header dist_name is filled from #dist_int_code (int), not
		 * the display "code-name". Column ppc_distibutor joins tsd_distributor.internal_code.
		 * Must be final/effectively final for the withSession lambda below.
		 */
		final String ppcDistributor;
		if (isPpc) {
			if (distIntCode.isBlank() || "0".equals(distIntCode)) {
				throw new IllegalArgumentException("Distributor is required for PPC.");
			}
			ppcDistributor = distIntCode;
		} else {
			ppcDistributor = "";
		}
		String reqEnlId = text(loginId);
		String reqEnlName = text(loginName);
		String status = "Submit".equals(saveType) ? "New" : "Draft";
		String updatedByName = distDisplay.isEmpty() ? reqEnlName : distDisplay;

		Map<String, Object> data = registry.withSession(HibernateFactoryRegistry.TSD, session -> {
			Transaction transaction = session.beginTransaction();
			try {
				String reqId;
				long headerId;
				if (editIntCode <= 0) {
					reqId = nextReqId(session);
					update(session, "TSD header insert", """
							insert into tsd_new_request (
								req_id, req_date, wrty_type, STATUS,
								is_conv_appl, is_first_pq_war, rel_with_exist_cust, pq_cert_issued,
								agreement_signed, certified_by_us, cust_remarks,
								acc_overdue_status, due_deli_status, other_comments, fyi,
								is_first_time_ppc, is_dist_signed_curr, ppc_distibutor, buyer_name, save_type,
								ref_dist_code, created_date, modified_by_enld, modified_date,
								reuqester_enl_id, reuqester_name, warranty_no, pq_warranty_exists, date_of_sale,
								req_dist, no_of_products, ppc_quantity_produced, tender_no, signed_current,
								tsd_RoleCode, cust_name, cust_addr1, cust_addr2, state,
								contractor_name, contractor_address1, contractor_address2, contractor_state
							) values (
								?, getdate(), ?, ?,
								?, ?, ?, ?,
								?, ?, ?,
								?, ?, ?, ?,
								?, ?, ?, ?, ?,
								?, getdate(), '', getdate(),
								?, ?, ?, ?, ?,
								?, ?, ?, ?, ?,
								?, ?, ?, ?, ?,
								?, ?, ?, ?
							)
							""",
							reqId, warrType, status,
							custType, firstPq, convRel, pqCert,
							agreement, sopMcs, remarks,
							accOverdue, dueDiligence, otherComments, fyi,
							firstPpc, distAgrSigned, ppcDistributor, buyerName, saveType,
							distIntCode,
							reqEnlId, reqEnlName, warrantyNo, warrantyExists, dateOfSale,
							reqDist, noOfProducts, ppcQtyProduced, tenderNo, signedCurrent,
							roleCode, customerName, custAddr1, custAddr2, custState,
							contractorName, contractorAddr1, contractorAddr2, contractorState);
					/* SCOPE_IDENTITY() is null across separate JDBC statements
					 * (NativeQuerySupport opens a new PreparedStatement each call). */
					headerId = identityByReqId(session, reqId);
				} else {
					headerId = editIntCode;
					reqId = existingReqId(session, headerId, reqDist);
					update(session, "TSD header update", """
							update tsd_new_request set
								cust_name = ?, cust_addr1 = ?, cust_addr2 = ?, state = ?,
								reuqester_enl_id = ?, reuqester_name = ?, tsd_RoleCode = ?, signed_current = ?,
								no_of_products = ?, date_of_sale = ?, wrty_type = ?,
								is_conv_appl = ?, is_first_pq_war = ?, rel_with_exist_cust = ?, pq_cert_issued = ?,
								agreement_signed = ?, certified_by_us = ?, cust_remarks = ?,
								acc_overdue_status = ?, due_deli_status = ?, fyi = ?, other_comments = ?,
								is_first_time_ppc = ?, is_dist_signed_curr = ?, buyer_name = ?,
								ref_dist_code = ?, save_type = ?, ppc_quantity_produced = ?,
								contractor_state = ?, contractor_name = ?, contractor_address1 = ?,
								contractor_address2 = ?, STATUS = ?, tender_no = ?,
								warranty_no = ?, pq_warranty_exists = ?, ppc_distibutor = ?,
								modified_date = getdate()
							where internal_code = ? and req_dist = ?
							""",
							customerName, custAddr1, custAddr2, custState,
							reqEnlId, reqEnlName, roleCode, signedCurrent,
							noOfProducts, dateOfSale, warrType,
							custType, firstPq, convRel, pqCert,
							agreement, sopMcs, remarks,
							accOverdue, dueDiligence, fyi, otherComments,
							firstPpc, distAgrSigned, buyerName,
							distIntCode, saveType, ppcQtyProduced,
							contractorState, contractorName, contractorAddr1,
							contractorAddr2, status, tenderNo,
							warrantyNo, warrantyExists, ppcDistributor,
							headerId, reqDist);
					update(session, "TSD signboard delete (edit)", """
							delete from tsd_new_request_signboard_table where ref_s_ref_data_code = ?
							""", headerId);
					update(session, "TSD product delete", """
							delete from tsd_new_request_product_table where ref_s_ref_data_code = ?
							""", headerId);
				}

				UploadBundle uploads = UploadBundle.empty();
				if (documentUploader != null) {
					uploads = documentUploader.store(reqId, headerId);
					if (uploads == null) {
						uploads = UploadBundle.empty();
					}
				}
				insertProducts(session, headerId, tenderNo, products, uploads.signboardFiles());
				updateProductWarrantyCodes(session, reqId, headerId);
				insertApprovers(session, headerId, editIntCode > 0, saveType, approvers);
				insertDocuments(session, headerId,
						uploads.documents() == null ? List.of() : uploads.documents());

				String histStatus = "Submit".equals(saveType) ? "New Request" : "Draft";
				String histRemarks = editIntCode <= 0
						? ("Submit".equals(saveType) ? "New Request Creation" : "Draft Creation")
						: "Resubmission";
				update(session, "TSD history insert", """
						insert into tsd_new_request_history (
							ref_s_ref_data_code, updated_by, updated_by_name, approver_status,
							approver_remarks, approver_role, approver_src, created_date
						) values (?, ?, ?, ?, ?, 'Distributor', 'Distributor', getdate())
						""",
						headerId, "Distributor", updatedByName, histStatus, histRemarks);

				transaction.commit();
				Map<String, Object> saved = new LinkedHashMap<>();
				saved.put("reqId", reqId);
				saved.put("internalCode", headerId);
				saved.put("saveType", saveType);
				saved.put("status", status);
				saved.put("message", "Submit".equals(saveType)
						? ("Warranty created successfully. Request No: " + reqId)
						: ("Warranty saved as Draft. Request No: " + reqId));
				return saved;
			} catch (RuntimeException ex) {
				logger.error("TSD save failed (rolled back): {}", ex.getMessage(), ex);
				rollback(transaction);
				throw ex;
			} catch (Exception ex) {
				logger.error("TSD save failed (rolled back): {}", ex.getMessage(), ex);
				rollback(transaction);
				throw new RuntimeException(ex.getMessage(), ex);
			}
		});

		/* Legacy SendApprovalMailsToFirstApprover — Submit only; after commit. */
		if ("Submit".equals(saveType)) {
			long headerId = longVal(data.get("internalCode"));
			new TsdMail(registry).sendApprovalMailToFirstApprover(headerId);
		}
		return data;
	}

	private void validateHeader(
			String saveType, boolean isPpc, boolean isActual,
			String custType, String firstPq, String convRel, String pqCert, String agreement,
			String signedCurrent, String sopMcs, String remarks, String tenderNo,
			String customerName, String custAddr1, String custAddr2, String custState,
			String contractorName, String contractorAddr1, String contractorAddr2, String contractorState,
			String accOverdue, String warrantyExists, String warrantyNo,
			String firstPpc, String distAgrSigned, String buyerName, String dateOfSale) {
		if (!isPpc) {
			require(custType, "Select Converter/Applicator.");
			require(firstPq, "Answer: first time PQ warranty.");
			require(convRel, "Answer: relationship with existing 3M converters.");
			if ("Sister Concern".equalsIgnoreCase(convRel)) {
				throw new IllegalArgumentException("You cannot raise the request for Sister Concern.");
			}
			require(pqCert, "Answer: PQ certificates by competition.");
			require(agreement, "Answer: converter/applicator agreement.");
			require(signedCurrent, "Answer: sister companies certified by us.");
			require(sopMcs, "Answer: signboards manufactured per 3M SOP/MCS.");
			require(customerName, "Enter Customer.");
			require(custAddr1, "Enter Customer Address 1.");
			require(custAddr2, "Enter Customer Address 2.");
			require(custState, "Select Customer State.");
			require(contractorName, "Enter Contractor.");
			require(contractorAddr1, "Enter Contractor Address 1.");
			require(contractorAddr2, "Enter Contractor Address 2.");
			require(contractorState, "Select Contractor State.");
			require(remarks, "Enter Remarks.");
			require(tenderNo, "Enter Tender/Ref No.");
		}
		if (isActual) {
			require(warrantyExists, "Select Does PQ Warranty Exists?");
			if ("Yes".equalsIgnoreCase(warrantyExists)) {
				require(warrantyNo, "Enter Warranty No.");
			}
		}
		if (isActual || isPpc) {
			require(accOverdue, "Select Account Overdue Status.");
			if ("Overdue".equalsIgnoreCase(accOverdue)) {
				throw new IllegalArgumentException(
						"You cannot raise the request when Account Overdue Status is Overdue.");
			}
		}
		if (isPpc) {
			require(firstPpc, "Answer: first time PPC certificate.");
			require(distAgrSigned, "Answer: distributor agreement signed and current.");
			require(buyerName, "Enter Buyer Details.");
			require(dateOfSale, "Select Date of Sale.");
		}
		/* Draft and Submit share the same field rules today (legacy). */
		if (saveType == null) {
			throw new IllegalArgumentException("save_type is required.");
		}
	}

	private void validateProducts(String warrType, List<Map<String, Object>> products) {
		boolean isPq = "PQ Warranty".equals(warrType);
		boolean isActual = "Actual Warranty".equals(warrType);
		boolean isPpc = "PPC for Retail Sale".equals(warrType);
		for (int i = 0; i < products.size(); i++) {
			Map<String, Object> p = products.get(i);
			int tab = i + 1;
			require(text(p.get("prod_type")), "Product " + tab + ": select Product Type.");
			require(text(p.get("prod_int_code")), "Product " + tab + ": select Product Name.");
			require(text(p.get("project_name")), "Product " + tab + ": enter Project Name.");
			if (!isPq) {
				require(text(p.get("work_order_details")),
						"Product " + tab + ": enter WorkOrder/PO Details.");
			}
			if (isActual) {
				require(text(p.get("actual_date_instal")),
						"Product " + tab + ": enter Actual Installation Date.");
			}
			if (isPpc) {
				require(text(p.get("ppc_uom")), "Product " + tab + ": enter PPC UOM.");
			}
		}
	}

	private void insertProducts(Session session, long headerId, String headerTender,
			List<Map<String, Object>> products, List<Map<String, Object>> signboardFiles) {
		String sql = """
				insert into tsd_new_request_product_table (
					ppc_qty_uom, ppc_qty, ref_s_ref_data_code, prod_sl_no, product_type, product_code,
					prod_sign_board_table_columns, prod_table_name, prod_table_columns,
					work_order_details, no_of_warrnty_years, tender_no, comments,
					tender_doc_name, tender_doc_path, actual_date_of_instl, project_name
				) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
				""";
		for (int i = 0; i < products.size(); i++) {
			Map<String, Object> p = products.get(i);
			String slNo = text(p.get("internal_code"));
			if (slNo.isEmpty()) {
				slNo = String.valueOf(i + 1);
			}
			String ppcQty = text(p.get("ppc_qty"));
			if (ppcQty.isEmpty()) {
				ppcQty = "0";
			}
			String tender = text(p.get("tender_no"));
			if (tender.isEmpty()) {
				tender = headerTender;
			}
			String prodMasterCode = text(p.get("prod_int_code"));
			update(session, "TSD product insert #" + slNo, sql,
					text(p.get("ppc_uom")),
					ppcQty,
					headerId,
					slNo,
					text(p.get("prod_type")),
					prodMasterCode,
					text(p.get("sign_board_table_columns")),
					text(p.get("table_name")),
					text(p.get("table_columns")),
					text(p.get("work_order_details")),
					text(p.get("warr_years")),
					tender,
					text(p.get("remarks")),
					text(p.get("tender_doc_name")),
					text(p.get("tender_doc_path")),
					sqlDate(p.get("actual_date_instal"), "Actual Installation Date"),
					text(p.get("project_name")));
			long productRowId = identityByProduct(session, headerId, slNo);
			insertSignboardRows(session, headerId, productRowId, prodMasterCode, slNo,
					p.get("signboard_rows"), signboardFiles);
		}
	}

	@SuppressWarnings("unchecked")
	private void insertSignboardRows(Session session, long headerId, long productRowId,
			String prodMasterCode, String prodSlNo, Object rowsObj,
			List<Map<String, Object>> signboardFiles) {
		if (!(rowsObj instanceof List<?> rows) || rows.isEmpty()) {
			return;
		}
		int seq = 1;
		for (Object rowObj : rows) {
			if (!(rowObj instanceof Map<?, ?> raw)) {
				continue;
			}
			Map<String, Object> row = new LinkedHashMap<>();
			raw.forEach((k, v) -> row.put(String.valueOf(k), v));
			String trData = text(row.get("data"));
			String fileName = text(row.get("signboard_filename"));
			String filePath = text(row.get("signboard_filepath"));
			Map<String, Object> uploaded = findSignboardFile(signboardFiles, prodSlNo, seq);
			if (uploaded != null) {
				fileName = text(uploaded.get("document_name"));
				filePath = text(uploaded.get("document_path"));
			}
			update(session, "TSD signboard insert #" + prodSlNo + "." + seq, """
					insert into tsd_new_request_signboard_table (
						unique_no, prod_internal_code, ref_product_code, ref_s_ref_data_code,
						row_sequence, tr_data, created_date, signboard_filename, signboard_filepath
					) values (?, ?, ?, ?, ?, ?, getdate(), ?, ?)
					""",
					seq, prodMasterCode, productRowId, headerId, seq, trData, fileName, filePath);
			seq++;
		}
	}

	private static Map<String, Object> findSignboardFile(
			List<Map<String, Object>> files, String prodSlNo, int rowSeq) {
		if (files == null || files.isEmpty()) {
			return null;
		}
		String wantProd = text(prodSlNo);
		String wantRow = String.valueOf(rowSeq);
		for (Map<String, Object> file : files) {
			if (wantProd.equals(text(file.get("prod_sl")))
					&& wantRow.equals(text(file.get("row_seq")))) {
				return file;
			}
		}
		return null;
	}

	private void updateProductWarrantyCodes(Session session, String reqId, long headerId) {
		update(session, "TSD product warranty codes", """
				update p
				set prod_warranty_code = cast(? as varchar(40)) + '-'
					+ isnull(cast(rp.prod_warr_code as varchar(20)), '1')
				from tsd_new_request_product_table p
				left join tsd_product_master rp with (nolock) on rp.internal_code = p.product_code
				where p.ref_s_ref_data_code = ?
				""", reqId, headerId);
	}

	private void insertApprovers(Session session, long headerId, boolean replace,
			String saveType, List<Map<String, Object>> approvers) {
		if (replace) {
			update(session, "TSD approver delete", """
					delete from tsd_new_request_approval_matrix where ref_s_ref_data_code = ?
					""", headerId);
		}
		for (Map<String, Object> row : approvers) {
			String sequence = text(row.get("sequence"));
			String role = text(row.get("approver_role"));
			String approverId = text(row.get("approver_id"));
			String source = text(row.get("approval_source"));
			String uiStatus = text(row.get("ui_status"));
			require(role, "Approver role is required.");
			require(approverId, "Please enter Approver Details.");
			require(sequence, "Approver sequence is required.");
			if ("Submit".equals(saveType) && isFirstSequence(sequence)) {
				update(session, "TSD header pending_with", """
						update tsd_new_request set
							sequence = ?, pending_with_role = ?, STATUS = ?,
							pending_with_src = ?, pending_with = ?
						where internal_code = ?
						""",
						sequence, role, uiStatus, source, approverId, headerId);
			}
			update(session, "TSD approver insert", """
					insert into tsd_new_request_approval_matrix (
						ref_s_ref_data_code, approval_role, pending_with_enl_id, sequence,
						created_enl_id, modified_enl_id, created_date, approval_src, ui_status
					) values (?, ?, ?, ?, '', '', getdate(), ?, ?)
					""",
					headerId, role, approverId, sequence, source, uiStatus);
		}
	}

	/**
	 * Replace document rows for codes that have a new upload in this save.
	 * Existing rows for other codes are left untouched (edit / re-upload partial).
	 */
	private void insertDocuments(Session session, long headerId, List<Map<String, Object>> documents) {
		if (documents == null || documents.isEmpty()) {
			return;
		}
		for (Map<String, Object> doc : documents) {
			String docIntCode = text(doc.get("doc_int_code"));
			String name = text(doc.get("document_name"));
			String path = text(doc.get("document_path"));
			if (docIntCode.isBlank() || name.isBlank() || path.isBlank()) {
				continue;
			}
			update(session, "TSD document delete #" + docIntCode, """
					delete from tsd_new_request_documents
					where ref_s_ref_data_code = ? and cast(doc_int_code as varchar(20)) = ?
					""", headerId, docIntCode);
			update(session, "TSD document insert #" + docIntCode, """
					insert into tsd_new_request_documents (
						ref_s_ref_data_code, document_name, document_path, doc_int_code
					) values (?, ?, ?, ?)
					""", headerId, name, path, docIntCode);
		}
	}

	private static boolean isFirstSequence(String sequence) {
		try {
			return Double.parseDouble(sequence) == 1.0d;
		} catch (NumberFormatException ex) {
			return "1".equals(sequence) || "1.00".equals(sequence);
		}
	}

	private String nextReqId(Session session) {
		int updated = update(session, "TSD ticket number", """
				update tsd_code_generator set last_no = last_no + 1
				where year_code = year(getdate())
				""");
		if (updated != 1) {
			throw new IllegalStateException("TSD request numbering is not configured for this year.");
		}
		List<Map<String, Object>> rows = query(session, """
				select cast(last_no as varchar(20)) as last_no,
					right(left(convert(varchar, getdate(), 112), 6), 4) as month_year
				from tsd_code_generator
				where year_code = year(getdate())
				""");
		if (rows.isEmpty()) {
			throw new IllegalStateException("TSD request numbering is not configured for this year.");
		}
		String number = text(rows.get(0).get("last_no")).split("\\.")[0];
		String monthYear = text(rows.get(0).get("month_year"));
		return monthYear + "0".repeat(Math.max(0, 5 - number.length())) + number;
	}

	private String existingReqId(Session session, long headerId, String reqDist) {
		List<Map<String, Object>> rows = query(session, """
				select isnull(req_id, '') as req_id, isnull(STATUS, '') as status
				from tsd_new_request with (nolock)
				where internal_code = ? and req_dist = ?
				""", headerId, reqDist);
		if (rows.isEmpty()) {
			throw new IllegalArgumentException("Request not found for update.");
		}
		String status = text(rows.get(0).get("status"));
		if (!"Draft".equalsIgnoreCase(status) && !"Rework".equalsIgnoreCase(status)) {
			throw new IllegalArgumentException("Only Draft or Rework requests can be updated.");
		}
		return text(rows.get(0).get("req_id"));
	}

	private long identityByReqId(Session session, String reqId) {
		List<Map<String, Object>> rows = query(session, """
				select cast(internal_code as bigint) as internal_code
				from tsd_new_request
				where req_id = ?
				""", reqId);
		if (rows.isEmpty() || rows.get(0).get("internal_code") == null) {
			throw new IllegalStateException(
					"The TSD request was not saved (no internal_code for req_id=" + reqId + ").");
		}
		return Long.parseLong(text(rows.get(0).get("internal_code")).split("\\.")[0]);
	}

	private long identityByProduct(Session session, long headerId, String prodSlNo) {
		List<Map<String, Object>> rows = query(session, """
				select cast(internal_code as bigint) as internal_code
				from tsd_new_request_product_table
				where ref_s_ref_data_code = ?
					and cast(prod_sl_no as varchar(20)) = ?
				""", headerId, prodSlNo);
		if (rows.isEmpty() || rows.get(0).get("internal_code") == null) {
			throw new IllegalStateException(
					"TSD product row was not saved (header=" + headerId + ", sl=" + prodSlNo + ").");
		}
		return Long.parseLong(text(rows.get(0).get("internal_code")).split("\\.")[0]);
	}

	private int update(Session session, String label, String sql, Object... parameters) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		printSql(label, sql, parameters);
		return NativeQuerySupport.executeUpdateInSession(session, sql, parameters);
	}

	private List<Map<String, Object>> query(Session session, String sql, Object... parameters) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		printSql("TSD select", sql, parameters);
		return NativeQuerySupport.executeQueryInSession(session, sql, parameters);
	}

	private static void printSql(String label, String sql, Object... parameters) {
		String rendered = SqlDebugFormatter.render(sql, parameters).replaceAll("[\\t ]+", " ")
				.replaceAll("\\s*\\n\\s*", " ").trim();
		logger.info("TSD {} SQL: {}", label, rendered);
	}

	private static void rollback(Transaction transaction) {
		if (transaction != null && transaction.isActive()) {
			transaction.rollback();
		}
	}

	private static void require(String value, String message) {
		if (value == null || value.isBlank()) {
			throw new IllegalArgumentException(message);
		}
	}
}
