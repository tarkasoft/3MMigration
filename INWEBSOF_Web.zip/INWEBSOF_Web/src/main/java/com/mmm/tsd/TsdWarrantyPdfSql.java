package com.mmm.tsd;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/** Bound SQL for on-demand TSD warranty certificate PDF generation. */
final class TsdWarrantyPdfSql {
	private static final Logger logger = LoggerFactory.getLogger(TsdWarrantyPdfSql.class);

	private static final String HEADER_SQL = """
			select
				cast(tn.internal_code as varchar(20)) as req_int_code,
				isnull(tn.req_id, '') as req_id,
				isnull(tn.wrty_type, '') as wrty_type,
				isnull(tn.status, '') as status,
				isnull(format(tn.req_date, 'dd/MM/yyyy'), '') as req_date,
				isnull(tn.tender_no, '') as tender_no,
				isnull(tn.warranty_no, '') as warranty_no,
				isnull(tn.buyer_name, '') as buyer_name,
				isnull(tn.buyer_statte, '') as buyer_statte,
				isnull(format(tn.date_of_sale, 'dd/MM/yyyy'), '') as date_of_sale,
				isnull(cast(ppc.code as varchar(20)) + '-' + isnull(ppc.name, ''), '') as ppc_distibutor,
				isnull(td.code, '') as distributor_code,
				isnull(td.name, '') as distributor_name,
				isnull(td.address1, '') + isnull(td.address2, '') as dist_address,
				isnull(td_st.name, '') as dist_state,
				isnull(tn.cust_name, '') as customer_name,
				isnull(tn.cust_addr1, '') + '-' + isnull(tn.cust_addr2, '') as cust_address,
				isnull(tc_st.name, '') as cust_state,
				isnull(tn.contractor_name, '') as contract_name,
				isnull(tn.contractor_address1, '') + '-' + isnull(tn.contractor_address2, '') as contract_address,
				isnull(tcc_st.name, '') as contract_state
			from tsd_new_request tn with (nolock)
			left join tsd_distributor td with (nolock) on td.code = tn.req_dist
			left join tk_state td_st with (nolock) on td_st.internal_code = td.state
			left join tsd_distributor ppc with (nolock) on ppc.internal_code = tn.ppc_distibutor
			left join tk_state tc_st with (nolock) on tc_st.internal_code = tn.state
			left join tk_state tcc_st with (nolock) on tcc_st.internal_code = tn.contractor_state
			where tn.internal_code = ?
				and cast(tn.req_dist as varchar(20)) = ?
			""";

	private static final String PRODUCT_SQL = """
			select
				isnull(cast(tp.ppc_template as varchar(20)), '') as ppc_template,
				isnull(cast(tp.pq_template as varchar(20)), '') as pq_template,
				isnull(cast(tp.actual_template as varchar(20)), '') as actual_template,
				cast(tp.internal_code as varchar(20)) as product_master_int_code,
				cast(tn.product_code as varchar(20)) as prod_int_code,
				cast(tn.internal_code as varchar(20)) as internal_code,
				isnull(cast(tn.prod_sl_no as varchar(20)), '') as prod_sl_no,
				isnull(tpc.category, '') as product_type,
				isnull(tp.product_name, '') as product_name,
				isnull(tn.prod_sign_board_table_columns, '') as prod_sign_board_table_columns,
				isnull(tn.prod_table_name, '') as prod_table_name,
				isnull(tn.prod_table_columns, '') as prod_table_columns,
				isnull(tn.work_order_details, '') as work_order_details,
				isnull(cast(tn.no_of_warrnty_years as varchar(20)), '') as no_of_warrnty_years,
				isnull(tn.tender_no, '') as tender_no,
				isnull(tn.comments, '') as comments,
				isnull(tp.sign_board_table_label, '') as sign_board_table_label,
				isnull(cast(tp.prod_warr_code as varchar(20)), '') as prod_warranty_code,
				isnull(cast(tn.ppc_qty as varchar(20)), '0') as ppc_qty,
				isnull(format(try_convert(datetime, tn.actual_date_of_instl), 'dd/MM/yyyy'),
					isnull(cast(tn.actual_date_of_instl as varchar(40)), '')) as actual_date_of_instl
			from tsd_new_request_product_table tn with (nolock)
			inner join tsd_product_master tp with (nolock) on tp.internal_code = tn.product_code
			inner join tsd_product_category tpc with (nolock) on tpc.internal_code = tp.category
			where tn.ref_s_ref_data_code = ?
				and tp.internal_code = ?
			""";

	private static final String TEMPLATE_SQL = """
			select
				isnull(ts.name, '') as template,
				isnull(tsd.pdf_text, '') as pdf_text,
				isnull(cast(tsd.sequence as varchar(20)), '') as sequence
			from tsd_template ts with (nolock)
			left join tsd_template_details tsd with (nolock) on ts.internal_code = tsd.template
			where ts.internal_code = ?
			order by tsd.sequence
			""";

	private static final String SIGNBOARD_SQL = """
			select
				cast(ref_s_ref_data_code as varchar(20)) as ref_s_ref_data_code,
				cast(ref_product_code as varchar(20)) as ref_product_code,
				isnull(tr_data, '') as tr_data
			from tsd_new_request_signboard_table with (nolock)
			where ref_s_ref_data_code = ?
				and cast(ref_product_code as varchar(20)) = ?
			order by row_sequence
			""";

	private static final String STATIC_TABLE_SQL = """
			select isnull(tr_data, '') as tr_data
			from tsd_product_master_tr_group with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String MMM_ADDR_SQL = """
			select isnull(mmm_address, '') as mmm_address
			from tsd_url_setup with (nolock)
			""";

	/** Division Manager on the request (approver role DM / Division*). */
	private static final String DIVISION_MANAGER_SQL = """
			select top 1
				isnull(ia.name, '') as division_manager_name,
				isnull(ia.enl_id, '') as div_manager_enl
			from tsd_new_request_approval_matrix arh with (nolock)
			left join ia_user_master ia with (nolock) on ia.enl_id = arh.pending_with_enl_id
			where arh.ref_s_ref_data_code = ?
				and (
					arh.ui_status like '%Division%'
					or arh.approval_role like '%Division%'
					or upper(isnull(arh.ui_status, '')) in ('DM', 'DIVISION MANAGER')
					or upper(isnull(arh.approval_role, '')) in ('DM', 'DIVISION MANAGER')
				)
			order by arh.sequence
			""";

	private final HibernateFactoryRegistry registry;

	TsdWarrantyPdfSql(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	Map<String, Object> header(long requestId, String converterCode) {
		logSql(HEADER_SQL, requestId, converterCode);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, HEADER_SQL, requestId, converterCode);
		return rows.isEmpty() ? null : rows.get(0);
	}

	Map<String, Object> product(long requestId, long productMasterId) {
		logSql(PRODUCT_SQL, requestId, productMasterId);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, PRODUCT_SQL, requestId, productMasterId);
		return rows.isEmpty() ? null : rows.get(0);
	}

	List<Map<String, Object>> templates(String templateId) {
		if (templateId == null || templateId.isBlank() || "0".equals(templateId.trim())) {
			return List.of();
		}
		logSql(TEMPLATE_SQL, templateId);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, TEMPLATE_SQL, templateId);
	}

	List<Map<String, Object>> signboardRows(long requestId, String productRowId) {
		logSql(SIGNBOARD_SQL, requestId, productRowId);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, SIGNBOARD_SQL, requestId, productRowId);
	}

	List<Map<String, Object>> staticTableRows(String productMasterId) {
		logSql(STATIC_TABLE_SQL, productMasterId);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, STATIC_TABLE_SQL, productMasterId);
	}

	String mmmAddress() {
		logSql(MMM_ADDR_SQL);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, MMM_ADDR_SQL);
		if (rows.isEmpty()) {
			return "";
		}
		Object value = rows.get(0).get("mmm_address");
		return value == null ? "" : String.valueOf(value).trim();
	}

	/** Name + ENL of Division Manager approver for the request (may be empty). */
	Map<String, Object> divisionManager(long requestId) {
		logSql(DIVISION_MANAGER_SQL, requestId);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, DIVISION_MANAGER_SQL, requestId);
		return rows.isEmpty() ? Map.of() : rows.get(0);
	}

	private static void logSql(String sql, Object... parameters) {
		String rendered = SqlDebugFormatter.render(sql, parameters).replaceAll("[\\t ]+", " ").trim();
		logger.info("TSD warranty-pdf SQL: {}", rendered);
	}
}
