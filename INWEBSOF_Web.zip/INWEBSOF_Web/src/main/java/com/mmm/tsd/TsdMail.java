package com.mmm.tsd;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

import jakarta.mail.Message;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

/**
 * Legacy-parity TSD submit mail ({@code SendTSDMail} /
 * {@code TSDCommon.SendApprovalMailsToFirstApprover}).
 * Customer portal sends mail on Submit only; approvals stay in the backend app.
 */
final class TsdMail {
	private static final Logger logger = LoggerFactory.getLogger(TsdMail.class);
	private static final String SMTP_HOST = "mailserv.mmm.com";
	private static final String MAIL_FROM = "3mindiagstcusthelpline@mmm.com";
	private static final String MAIL_TYPE_SUBMIT = "DISTRIBUTOR APPROVAL MAIL";

	private final HibernateFactoryRegistry registry;

	TsdMail(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	/**
	 * Notify first approver(s) after a successful Submit / resubmit.
	 * Mail failure is logged and recorded in {@code tsd_mail_history}; it does
	 * not fail the save.
	 */
	void sendApprovalMailToFirstApprover(long internalCode) {
		if (internalCode <= 0) {
			return;
		}
		try {
			Map<String, Object> header = loadHeader(internalCode);
			String ticketNumber = text(header.get("req_id"));
			String pendingWithName = text(header.get("pending_with_name"));
			String pendingWithEmail = text(header.get("pending_with_email"));
			String distributorName = text(header.get("distributor_name"));
			String fyi = text(header.get("fyi"));
			String matrixEmails = loadApproverEmails(internalCode);
			String backendUrl = loadBackendUrl();

			String to = joinEmails(pendingWithEmail, matrixEmails);
			if (to.isBlank()) {
				logger.warn("TSD submit mail skipped: no approver email for internal_code={}",
						internalCode);
				insertMailHistory(MAIL_TYPE_SUBMIT, "", fyi, "",
						"TSD WARRANTY REQUEST " + ticketNumber + " PENDING FOR YOUR APPROVAL ",
						"No approver email configured");
				return;
			}

			String subject = "TSD WARRANTY REQUEST " + ticketNumber
					+ " PENDING FOR YOUR APPROVAL ";
			String body = "Hi " + pendingWithName + " , "
					+ "\n\n TSD E-Warranty request number <b>" + ticketNumber
					+ "</b> requested by <b>" + distributorName
					+ "</b>;  and submitted for your review/approval.\r\n"
					+ "\r\n"
					+ "Please click on the link below and click on approve/reject button"
					+ " in the next 2 business days.\r\n"
					+ "\n<a href='" + backendUrl
					+ "'> Please click on this link to view the form </a>"
					+ "\n\n "
					+ "Regards,\r\n"
					+ "Transportation Safety Division\r\n"
					+ "3M India\r\n"
					+ "Transportation_safety.in@mmm.com\r\n";

			String result = sendMail(to, fyi, "", subject, body, MAIL_FROM);
			insertMailHistory(MAIL_TYPE_SUBMIT, to, fyi, "", subject, result);
			if (!"Mail Sent Successfully".equals(result)) {
				logger.error("TSD submit mail failed for {}: {}", ticketNumber, result);
			}
		} catch (Exception ex) {
			logger.error("TSD submit mail failed for internal_code={}: {}",
					internalCode, ex.getMessage(), ex);
			try {
				insertMailHistory(MAIL_TYPE_SUBMIT, "", "", "",
						"TSD WARRANTY REQUEST PENDING FOR YOUR APPROVAL ",
						ex.getMessage() == null ? "Mail failed" : ex.getMessage());
			} catch (Exception ignore) {
				/* history insert must not mask the original mail error */
			}
		}
	}

	private Map<String, Object> loadHeader(long internalCode) {
		List<Map<String, Object>> rows = query("""
				select top 1
					isnull(en.req_id, '') as req_id,
					isnull(en.fyi, '') as fyi,
					isnull(ec.code, '') + '-' + isnull(ec.name, '') as distributor_name,
					isnull(ia.name, '') as pending_with_name,
					isnull(ia.email, '') as pending_with_email
				from tsd_new_request en with (nolock)
				left join tsd_distributor ec with (nolock) on ec.code = en.req_dist
				left join ia_user_master ia with (nolock) on en.pending_with = ia.enl_id
				where en.internal_code = ?
				""", internalCode);
		if (rows.isEmpty()) {
			throw new IllegalStateException(
					"TSD request not found for mail (internal_code=" + internalCode + ").");
		}
		return rows.get(0);
	}

	private String loadApproverEmails(long internalCode) {
		List<Map<String, Object>> rows = query("""
				select isnull(stuff((
					select ',' + ia.email
					from tsd_new_request_approval_matrix tsd
					inner join ia_user_master ia on ia.enl_id = tsd.pending_with_enl_id
					where tsd.ref_s_ref_data_code = ?
					for xml path('')
				), 1, 1, ''), '') as email_ids
				""", internalCode);
		if (rows.isEmpty()) {
			return "";
		}
		return text(rows.get(0).get("email_ids"));
	}

	private String loadBackendUrl() {
		List<Map<String, Object>> rows = query("""
				select top 1 isnull(ew_backend_url, '') as ew_backend_url
				from tsd_url_setup with (nolock)
				""");
		if (rows.isEmpty()) {
			return "";
		}
		return text(rows.get(0).get("ew_backend_url"));
	}

	private String sendMail(String to, String cc, String bcc, String subject,
			String body, String fromEmail) {
		String msg = "Mail Sent Successfully";
		try {
			Properties props = new Properties();
			props.put("mail.smtp.host", SMTP_HOST);
			jakarta.mail.Session mailSession = jakarta.mail.Session.getInstance(props);
			MimeMessage message = new MimeMessage(mailSession);
			String from = fromEmail == null || fromEmail.isBlank() ? MAIL_FROM : fromEmail;
			message.setFrom(new InternetAddress(from));
			addRecipients(message, Message.RecipientType.TO, to);
			addRecipients(message, Message.RecipientType.CC, cc);
			addRecipients(message, Message.RecipientType.BCC, bcc);
			message.setSentDate(new Date());
			message.setSubject(subject);
			String html = body == null ? "" : body.replace("\n", "</br>");
			message.setContent(html, "text/html; charset=UTF-8");
			Transport.send(message);
		} catch (Exception ex) {
			msg = ex.getMessage() == null ? "Mail failed" : ex.getMessage();
			logger.error("TSD SMTP send failed", ex);
		}
		return msg;
	}

	private void insertMailHistory(String mailType, String to, String cc, String bcc,
			String subject, String response) {
		String dateSql = UserSessionSupport.sessionDate();
		String sql = """
				insert into tsd_mail_history (
					mail_type, mail_to, mail_cc, mail_bcc, created_date, mail_response, mail_subject
				) values (?, ?, ?, ?, %s, ?, ?)
				""".formatted(dateSql);
		printSql("mail history", sql, mailType, nullToEmpty(to), nullToEmpty(cc),
				nullToEmpty(bcc), trim(response, 500), trim(subject, 250));
		NativeQuerySupport.executeUpdate(
				registry,
				HibernateFactoryRegistry.TSD,
				sql,
				mailType,
				nullToEmpty(to),
				nullToEmpty(cc),
				nullToEmpty(bcc),
				trim(response, 500),
				trim(subject, 250));
	}

	private List<Map<String, Object>> query(String sql, Object... parameters) {
		printSql("mail select", sql, parameters);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, sql, parameters);
	}

	private static void addRecipients(MimeMessage message, Message.RecipientType type,
			String addresses) throws Exception {
		if (addresses == null || addresses.isBlank()) {
			return;
		}
		for (String address : addresses.split(",")) {
			if (address != null && !address.isBlank()) {
				message.addRecipient(type, new InternetAddress(address.trim()));
			}
		}
	}

	private static String joinEmails(String first, String second) {
		String a = first == null ? "" : first.trim();
		String b = second == null ? "" : second.trim();
		if (a.isBlank()) {
			return b;
		}
		if (b.isBlank()) {
			return a;
		}
		return a + "," + b;
	}

	private static String nullToEmpty(String value) {
		return value == null ? "" : value;
	}

	private static String trim(String value, int max) {
		String text = nullToEmpty(value);
		return text.length() <= max ? text : text.substring(0, max);
	}

	private static void printSql(String label, String sql, Object... parameters) {
		String rendered = SqlDebugFormatter.render(sql, parameters)
				.replaceAll("[\\t ]+", " ")
				.replaceAll("\\s*\\n\\s*", " ")
				.trim();
		logger.info("TSD {} SQL: {}", label, rendered);
	}
}
