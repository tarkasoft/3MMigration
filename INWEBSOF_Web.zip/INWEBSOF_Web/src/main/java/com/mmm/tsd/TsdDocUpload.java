package com.mmm.tsd;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.share.DiskShare;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;

import jakarta.servlet.http.HttpServletRequest;

/**
 * TSD document upload/download over encrypted SMB 3.1.1 (SMBJ).
 * Share: {@code CMW010S('TSD',…,'ATTACHMENT')}. No JCIFS; browser never gets {@code smb:} URLs.
 */
@RestController
@RequestMapping("/api/customer/tsd")
public class TsdDocUpload {
	private static final Logger logger = LoggerFactory.getLogger(TsdDocUpload.class);

	/** Only dialect allowed for TSD file I/O. */
	private static final SMB2Dialect SMB3 = SMB2Dialect.SMB_3_1_1;

	static final long MAX_DOCUMENT_BYTES = 5L * 1024 * 1024;

	private final HibernateFactoryRegistry registry;
	private final TsdRequestsSql sql;
	private final TsdContextResolver contextResolver;
	private final String appCode;
	private final String shareLogin;
	private final String shareSearch;
	private final String smbDomain;
	private final String fileTransport;
	private final String mountRoot;

	public TsdDocUpload(HibernateFactoryRegistry registry,
			@Value("${inpc.tsd.smb-app-code:TSD}") String appCode,
			@Value("${inpc.tsd.smb-login:A2ARVZZ}") String shareLogin,
			@Value("${inpc.tsd.smb-search:ATTACHMENT}") String shareSearch,
			@Value("${inpc.tsd.smb-domain:MMM}") String smbDomain,
			@Value("${inpc.tsd.file-transport:smb}") String fileTransport,
			@Value("${inpc.tsd.mount-root:}") String mountRoot) {
		this.registry = registry;
		this.sql = new TsdRequestsSql(registry);
		this.contextResolver = new TsdContextResolver(sql);
		this.appCode = appCode;
		this.shareLogin = shareLogin;
		this.shareSearch = shareSearch;
		this.smbDomain = smbDomain;
		this.fileTransport = fileTransport;
		this.mountRoot = mountRoot;
	}

	@GetMapping("/requests/{requestId}/documents/{documentId}/download")
	public ResponseEntity<byte[]> downloadDocument(HttpServletRequest request,
			@PathVariable long requestId,
			@PathVariable long documentId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			TsdContextResolver.Working working = requireConverter(request, custCode, loginId);
			Map<String, Object> document = sql.requestDocument(
					documentId, requestId, working.convCode());
			if (document == null) {
				return ResponseEntity.notFound().build();
			}
			String path = text(document.get("ftp_file_path"));
			String preferred = text(document.get("ftp_file_name"));
			if (preferred.isBlank()) {
				preferred = text(document.get("document_name"));
			}
			return bytesResponse(requestId, documentId, preferred, path);
		} catch (Exception ex) {
			return downloadError(ex, requestId, documentId);
		}
	}

	/**
	 * Download warranty certificate / signboard file by stored SMB path
	 * (must belong to this request + converter).
	 */
	@GetMapping("/requests/{requestId}/files/download")
	public ResponseEntity<byte[]> downloadStoredFile(HttpServletRequest request,
			@PathVariable long requestId,
			@RequestParam("fileName") String fileName,
			@RequestParam("filePath") String filePath,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			TsdContextResolver.Working working = requireConverter(request, custCode, loginId);
			String path = text(filePath);
			if (path.isBlank()) {
				return ResponseEntity.notFound().build();
			}
			if (!sql.fileOwnedByRequest(requestId, working.convCode(), path)) {
				throw new IllegalArgumentException("File was not found for this request.");
			}
			return bytesResponse(requestId, 0L, text(fileName), path);
		} catch (Exception ex) {
			return downloadError(ex, requestId, 0L);
		}
	}

	/**
	 * Upload one document via SMB 3.1.1. Returns relative path for DB storage.
	 * Used by New Request multipart save (and similar).
	 */
	String store(String requestKey, String kind, String originalName, byte[] content) throws Exception {
		if (content == null || content.length == 0) {
			throw new IllegalArgumentException("Select a document.");
		}
		if (content.length > MAX_DOCUMENT_BYTES) {
			throw new IllegalArgumentException("Each document must be 5 MB or smaller.");
		}
		String relativePath = documentPath(requestKey, kind, originalName);
		if (useMount()) {
			java.nio.file.Path target = mounted(relativePath);
			java.nio.file.Files.createDirectories(target.getParent());
			java.nio.file.Files.write(target, content);
			logger.info("TSD mount store: path={} bytes={}", relativePath, content.length);
			return relativePath;
		}
		logger.info("TSD SMB3 store started: dialect=SMB_3_1_1 encrypt=true path={} bytes={}",
				relativePath, content.length);
		writeSmb(relativePath, content);
		logger.info("TSD SMB3 store ended: path={}", relativePath);
		return relativePath;
	}

	/** Download document bytes via SMB 3.1.1 (same dialect/encrypt as upload). */
	byte[] read(String storedPath) throws Exception {
		String relativePath = safeRelativePath(storedPath);
		if (useMount()) {
			logger.info("TSD mount read: path={}", relativePath);
			return java.nio.file.Files.readAllBytes(mounted(relativePath));
		}
		logger.info("TSD SMB3 read started: dialect=SMB_3_1_1 encrypt=true path={}", relativePath);
		Map<String, String> location = locateShare();
		byte[][] result = new byte[1][];
		withShare(location, share -> {
			try (com.hierynomus.smbj.share.File remoteFile = share.openFile(
					join(location.get("folder"), relativePath),
					EnumSet.of(AccessMask.GENERIC_READ),
					null,
					SMB2ShareAccess.ALL,
					SMB2CreateDisposition.FILE_OPEN,
					null);
					InputStream input = remoteFile.getInputStream();
					ByteArrayOutputStream output = new ByteArrayOutputStream()) {
				input.transferTo(output);
				result[0] = output.toByteArray();
			}
		});
		logger.info("TSD SMB3 read ended: path={} bytes={}", relativePath,
				result[0] == null ? 0 : result[0].length);
		return result[0];
	}

	void remove(String storedPath) {
		try {
			String relativePath = safeRelativePath(storedPath);
			if (useMount()) {
				java.nio.file.Files.deleteIfExists(mounted(relativePath));
				return;
			}
			Map<String, String> location = locateShare();
			withShare(location, share -> {
				String remotePath = join(location.get("folder"), relativePath);
				if (share.fileExists(remotePath)) {
					share.rm(remotePath);
				}
			});
			logger.info("TSD SMB3 remove: path={}", relativePath);
		} catch (Exception ex) {
			logger.warn("TSD document cleanup failed for {}", storedPath, ex);
		}
	}

	private TsdContextResolver.Working requireConverter(HttpServletRequest request,
			String custCode, String loginId) {
		TsdContextResolver.Working working =
				contextResolver.resolve(request.getSession(false), custCode, loginId);
		if (working.needsConverterSelection() || working.convCode() == null
				|| working.convCode().isBlank()) {
			throw new IllegalArgumentException("Select a converter before downloading documents.");
		}
		return working;
	}

	private ResponseEntity<byte[]> bytesResponse(long requestId, long documentId,
			String preferred, String path) throws Exception {
		String fileName = nameWithExtension(preferred, path);
		if (path == null || path.isBlank()) {
			logger.warn("TSD download: path missing for documentId={}", documentId);
			return ResponseEntity.notFound().build();
		}
		logger.info("TSD download via SMB3: requestId={} documentId={} path={}",
				requestId, documentId, path);
		byte[] bytes = read(path);
		if (bytes == null || bytes.length == 0) {
			logger.warn("TSD download: empty file documentId={} path={}", documentId, path);
			return ResponseEntity.notFound().build();
		}
		String lower = fileName.toLowerCase(Locale.ROOT);
		MediaType contentType = lower.endsWith(".pdf")
				? MediaType.APPLICATION_PDF : MediaType.APPLICATION_OCTET_STREAM;
		return ResponseEntity.ok()
				.contentType(contentType)
				.header(HttpHeaders.CONTENT_DISPOSITION,
						ContentDisposition.attachment().filename(fileName).build().toString())
				.header("X-Content-Type-Options", "nosniff")
				.body(bytes);
	}

	private ResponseEntity<byte[]> downloadError(Exception ex, long requestId, long documentId) {
		if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
			HttpStatus status = UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())
					? HttpStatus.UNAUTHORIZED : HttpStatus.NOT_FOUND;
			return ResponseEntity.status(status).build();
		}
		logger.error("Unable to download TSD file requestId={} documentId={}",
				requestId, documentId, ex);
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
	}

	private static String safeDisplayName(String fileName) {
		String name = fileName == null ? "document" : fileName.trim();
		name = name.replaceAll("[^A-Za-z0-9._ -]", "_");
		return name.isBlank() ? "document" : name.substring(Math.max(0, name.length() - 120));
	}

	private static String nameWithExtension(String preferred, String sourceWithExtension) {
		String name = safeDisplayName(preferred);
		String source = sourceWithExtension == null ? "" : sourceWithExtension.trim().replace('\\', '/');
		int slash = Math.max(source.lastIndexOf('/'), source.lastIndexOf('\\'));
		if (slash >= 0) {
			source = source.substring(slash + 1);
		}
		String sourceExt = extensionOf(source);
		if (sourceExt.isBlank()) {
			return name;
		}
		if (extensionOf(name).equalsIgnoreCase(sourceExt)) {
			return name;
		}
		if (!extensionOf(name).isBlank()) {
			return name;
		}
		return safeDisplayName(name + sourceExt);
	}

	private static String extensionOf(String fileName) {
		if (fileName == null) {
			return "";
		}
		int dot = fileName.lastIndexOf('.');
		if (dot <= 0 || dot == fileName.length() - 1) {
			return "";
		}
		String ext = fileName.substring(dot).toLowerCase(Locale.ROOT);
		return ext.matches("\\.[a-z0-9]{1,10}") ? ext : "";
	}

	private void writeSmb(String relativePath, byte[] content) throws Exception {
		Map<String, String> location = locateShare();
		withShare(location, share -> {
			String remotePath = join(location.get("folder"), relativePath);
			int slash = remotePath.lastIndexOf('/');
			if (slash > 0) {
				ensureFolder(share, remotePath.substring(0, slash));
			}
			try (com.hierynomus.smbj.share.File remoteFile = share.openFile(
					remotePath,
					EnumSet.of(AccessMask.GENERIC_WRITE),
					null,
					SMB2ShareAccess.ALL,
					SMB2CreateDisposition.FILE_OVERWRITE_IF,
					null);
					java.io.OutputStream output = remoteFile.getOutputStream()) {
				output.write(content);
			}
		});
	}

	/** Always SMB 3.1.1 + data encryption — shared by store and read. */
	private void withShare(Map<String, String> location, ShareWork work) throws Exception {
		SmbConfig config = SmbConfig.builder()
				.withDialects(SMB3)
				.withEncryptData(true)
				.build();
		SMBClient client = new SMBClient(config);
		try (Connection connection = client.connect(location.get("host"))) {
			logger.info("TSD SMB3 connect: host={} share={} dialect=SMB_3_1_1 encrypt=true",
					location.get("host"), location.get("share"));
			System.out.println("TSD SMB3 connect: host=" + location.get("host")
					+ " share=" + location.get("share") + " dialect=SMB_3_1_1 encrypt=true");
			var smbSession = connection.authenticate(new AuthenticationContext(
					location.get("username"), location.get("password").toCharArray(), smbDomain));
			try (DiskShare share = (DiskShare) smbSession.connectShare(location.get("share"))) {
				work.use(share);
			} finally {
				smbSession.close();
			}
		} finally {
			client.close();
		}
	}

	private static void ensureFolder(DiskShare share, String folder) {
		StringBuilder current = new StringBuilder();
		for (String part : folder.split("/")) {
			if (part.isBlank()) {
				continue;
			}
			if (current.length() > 0) {
				current.append('/');
			}
			current.append(part);
			String path = current.toString();
			if (!share.folderExists(path)) {
				share.mkdir(path);
			}
		}
	}

	private boolean useMount() {
		return "mount".equalsIgnoreCase(fileTransport);
	}

	private java.nio.file.Path mounted(String relativePath) {
		if (mountRoot == null || mountRoot.isBlank()) {
			throw new IllegalStateException("TSD document mount is not configured.");
		}
		java.nio.file.Path root = java.nio.file.Path.of(mountRoot).toAbsolutePath().normalize();
		java.nio.file.Path target = root.resolve(relativePath).normalize();
		if (!target.startsWith(root)) {
			throw new IllegalArgumentException("TSD document path is invalid.");
		}
		return target;
	}

	private static String documentPath(String requestKey, String kind, String originalName) {
		java.time.ZonedDateTime now = java.time.ZonedDateTime.now(java.time.ZoneId.of("Asia/Kolkata"));
		String folder = requestKey == null ? "" : requestKey.replaceAll("[^A-Za-z0-9_-]", "");
		if (folder.isBlank()) {
			folder = "request";
		}
		String segment = kind == null || kind.isBlank() ? "header"
				: kind.replaceAll("[^A-Za-z0-9_-]", "").toLowerCase(Locale.ROOT);
		if (segment.isBlank()) {
			segment = "header";
		}
		return now.getYear() + "/" + String.format("%02d", now.getMonthValue()) + "/" + folder + "/"
				+ System.currentTimeMillis() + "_" + segment + "_" + safeDisplayName(originalName);
	}

	private Map<String, String> locateShare() {
		List<Map<String, Object>> rows = NativeQuerySupport.executeProcedure(
				registry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.CMW010S(?,?,?)}",
				appCode, shareLogin, shareSearch);
		for (Map<String, Object> row : rows) {
			String rawPath = text(cell(row, "NWPATH")).replace('\\', '/');
			if (rawPath.regionMatches(true, 0, "smb:", 0, 4)) {
				rawPath = rawPath.substring(4);
			}
			while (rawPath.startsWith("/")) {
				rawPath = rawPath.substring(1);
			}
			while (rawPath.endsWith("/")) {
				rawPath = rawPath.substring(0, rawPath.length() - 1);
			}
			String[] parts = rawPath.split("/", 3);
			String username = text(cell(row, "NWLID"));
			String password = text(cell(row, "NWPWD"));
			if (parts.length >= 2 && !parts[0].isBlank() && !parts[1].isBlank()
					&& !username.isBlank() && !password.isBlank()) {
				String host = parts[0];
				int port = host.indexOf(':');
				if (port > 0) {
					host = host.substring(0, port);
				}
				return Map.of(
						"host", host,
						"share", parts[1],
						"folder", parts.length > 2 ? safeRelativePath(parts[2]) : "",
						"username", username,
						"password", password);
			}
		}
		throw new IllegalStateException("TSD file share settings were not returned by CMW010S.");
	}

	private static String safeRelativePath(String path) {
		String value = path == null ? "" : path.trim().replace('\\', '/');
		if (value.isEmpty() || value.startsWith("/") || value.matches("^[A-Za-z]:.*")) {
			throw new IllegalArgumentException("TSD document path is invalid.");
		}
		String[] parts = value.split("/");
		for (String part : parts) {
			if (part.isBlank() || ".".equals(part) || "..".equals(part)
					|| part.matches(".*[<>:\"|?*\\p{Cntrl}].*")) {
				throw new IllegalArgumentException("TSD document path is invalid.");
			}
		}
		return String.join("/", parts);
	}

	private static String join(String folder, String relativePath) {
		return folder == null || folder.isBlank() ? relativePath : folder + "/" + relativePath;
	}

	private static Object cell(Map<String, Object> row, String key) {
		return row.entrySet().stream()
				.filter(entry -> entry.getKey() != null && entry.getKey().equalsIgnoreCase(key))
				.map(Map.Entry::getValue).findFirst().orElse(null);
	}

	@FunctionalInterface
	private interface ShareWork {
		void use(DiskShare share) throws Exception;
	}
}
