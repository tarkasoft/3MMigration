package com.mmm.tsd;

import static com.mmm.titpl.CommonFunctions.longVal;
import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;
import com.mmm.titpl.SqlDebugFormatter;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Signboard Excel download/upload from Request Details product tab.
 * Data only (no document files). Uses Apache POI (.xlsx; .xls also readable).
 */
@RestController
@RequestMapping("/api/customer/tsd")
public class TsdSignboardExcel {
	private static final Logger logger = LoggerFactory.getLogger(TsdSignboardExcel.class);
	private static final Gson GSON = new Gson();

	private final HibernateFactoryRegistry registry;
	private final TsdRequestsSql sql;
	private final TsdContextResolver contextResolver;

	public TsdSignboardExcel(HibernateFactoryRegistry registry) {
		this.registry = registry;
		this.sql = new TsdRequestsSql(registry);
		this.contextResolver = new TsdContextResolver(sql);
	}

	@GetMapping("/requests/{requestId}/products/{productRowId}/signboard/excel")
	public ResponseEntity<byte[]> download(HttpServletRequest request,
			@PathVariable long requestId,
			@PathVariable long productRowId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			TsdContextResolver.Working working = requireConverter(request, custCode, loginId);
			Map<String, Object> product = requireProduct(requestId, productRowId, working.convCode());
			List<Map<String, Object>> rows = sql.requestSignboardRows(requestId, productRowId);
			String columns = text(product.get("prod_sign_board_table_columns"));
			if (columns.isBlank() && !rows.isEmpty()) {
				columns = text(rows.get(0).get("table_columns"));
			}
			byte[] bytes = writeWorkbook(columns, rows);
			return ResponseEntity.ok()
					.contentType(MediaType.parseMediaType(
							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
					.header(HttpHeaders.CONTENT_DISPOSITION,
							ContentDisposition.attachment()
									.filename("signboard_details.xlsx").build().toString())
					.header("X-Content-Type-Options", "nosniff")
					.body(bytes);
		} catch (Exception ex) {
			if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
				HttpStatus status = UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())
						? HttpStatus.UNAUTHORIZED : HttpStatus.BAD_REQUEST;
				return ResponseEntity.status(status).build();
			}
			logger.error("TSD signboard excel download failed requestId={} productRowId={}",
					requestId, productRowId, ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	@PostMapping("/requests/{requestId}/products/{productRowId}/signboard/excel")
	public String upload(HttpServletRequest request,
			@PathVariable long requestId,
			@PathVariable long productRowId,
			@RequestParam("file") MultipartFile file,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			TsdContextResolver.Working working = requireConverter(request, custCode, loginId);
			Map<String, Object> product = requireProduct(requestId, productRowId, working.convCode());
			if (file == null || file.isEmpty()) {
				throw new IllegalArgumentException("Choose an Excel file to upload.");
			}
			String name = text(file.getOriginalFilename()).toLowerCase(Locale.ROOT);
			if (!name.endsWith(".xlsx") && !name.endsWith(".xls")) {
				throw new IllegalArgumentException("Upload an .xlsx or .xls Excel file.");
			}
			String columns = text(product.get("prod_sign_board_table_columns"));
			String[] headers = splitColumns(columns);
			int dataCols = Math.max(0, headers.length - 1);
			List<Map<String, String>> parsed = readWorkbook(file.getInputStream(), dataCols);
			String prodMasterCode = text(product.get("prod_int_code"));
			replaceRows(requestId, productRowId, prodMasterCode, parsed);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("rowCount", parsed.size());
			data.put("signboard_rows", sql.requestSignboardRows(requestId, productRowId));
			result.SetSuccess("Uploaded successfully.", data);
		} catch (Exception ex) {
			if (ex instanceof IllegalStateException
					&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
				result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
						ex.getMessage());
			} else {
				if (!(ex instanceof IllegalArgumentException || ex instanceof IllegalStateException)) {
					logger.error("TSD signboard excel upload failed", ex);
				}
				result.SetError(-1, "failure",
						ex instanceof IllegalArgumentException || ex instanceof IllegalStateException
								? ex.getMessage() : "Unable to upload signboard Excel.");
			}
		}
		return GSON.toJson(result);
	}

	private Map<String, Object> requireProduct(long requestId, long productRowId, String convCode) {
		Map<String, Object> header = sql.requestDetail(requestId, convCode);
		if (header == null) {
			throw new IllegalArgumentException("Request not found for this converter.");
		}
		for (Map<String, Object> product : sql.requestProducts(requestId)) {
			if (parseLong(product.get("internal_code")) == productRowId) {
				return product;
			}
		}
		throw new IllegalArgumentException("Product was not found on this request.");
	}

	private void replaceRows(long requestId, long productRowId, String prodMasterCode,
			List<Map<String, String>> rows) {
		registry.withSession(HibernateFactoryRegistry.TSD, session -> {
			Transaction tx = session.beginTransaction();
			try {
				update(session, "TSD signboard delete", """
						delete from tsd_new_request_signboard_table
						where ref_s_ref_data_code = ?
							and cast(ref_product_code as varchar(20)) = ?
						""", requestId, productRowId);
				int seq = 1;
				for (Map<String, String> row : rows) {
					update(session, "TSD signboard insert #" + seq, """
							insert into tsd_new_request_signboard_table (
								unique_no, prod_internal_code, ref_product_code, ref_s_ref_data_code,
								row_sequence, tr_data, created_date, signboard_filename, signboard_filepath
							) values (?, ?, ?, ?, ?, ?, getdate(), ?, ?)
							""",
							seq,
							prodMasterCode,
							productRowId,
							requestId,
							seq,
							row.get("tr_data"),
							row.get("signboard_filename"),
							row.get("signboard_filepath"));
					seq++;
				}
				tx.commit();
				return null;
			} catch (RuntimeException ex) {
				if (tx != null && tx.isActive()) {
					tx.rollback();
				}
				throw ex;
			} catch (Exception ex) {
				if (tx != null && tx.isActive()) {
					tx.rollback();
				}
				throw new RuntimeException(ex.getMessage(), ex);
			}
		});
	}

	private static byte[] writeWorkbook(String columns, List<Map<String, Object>> rows)
			throws Exception {
		String[] headers = splitColumns(columns);
		try (XSSFWorkbook wb = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			Sheet sheet = wb.createSheet("signboard_details");
			Row head = sheet.createRow(0);
			int col = 0;
			for (int i = 0; i < Math.max(0, headers.length - 1); i++) {
				head.createCell(col++).setCellValue(headers[i]);
			}
			head.createCell(col++).setCellValue("Signboard File Name");
			head.createCell(col++).setCellValue("Signboard File path");
			int r = 1;
			for (Map<String, Object> row : rows) {
				String tr = text(row.get("tr_data"));
				if (tr.isBlank()) {
					continue;
				}
				String[] cells = tr.split("~", -1);
				Row excelRow = sheet.createRow(r++);
				int c = 0;
				for (String cell : cells) {
					excelRow.createCell(c++).setCellValue(cell == null ? "" : cell);
				}
				excelRow.createCell(c++).setCellValue(text(row.get("signboard_filename")));
				excelRow.createCell(c++).setCellValue(text(row.get("signboard_filepath")));
			}
			if (r == 1) {
				Row empty = sheet.createRow(1);
				empty.createCell(0).setCellValue("Data not found");
			}
			wb.write(out);
			return out.toByteArray();
		}
	}

	private static List<Map<String, String>> readWorkbook(InputStream in, int dataCols)
			throws Exception {
		DataFormatter fmt = new DataFormatter();
		List<Map<String, String>> rows = new ArrayList<>();
		try (Workbook wb = WorkbookFactory.create(in)) {
			Sheet sheet = wb.getNumberOfSheets() > 0 ? wb.getSheetAt(0) : null;
			if (sheet == null) {
				throw new IllegalArgumentException("Excel sheet is empty.");
			}
			int last = sheet.getLastRowNum();
			for (int r = 1; r <= last; r++) {
				Row row = sheet.getRow(r);
				if (row == null) {
					continue;
				}
				List<String> cells = new ArrayList<>();
				boolean any = false;
				int max = Math.max(dataCols, row.getLastCellNum());
				for (int c = 0; c < max; c++) {
					Cell cell = row.getCell(c);
					String val = cell == null ? "" : fmt.formatCellValue(cell).trim();
					if (!val.isBlank()) {
						any = true;
					}
					cells.add(val);
				}
				if (!any) {
					continue;
				}
				List<String> data = new ArrayList<>();
				for (int c = 0; c < dataCols && c < cells.size(); c++) {
					data.add(cells.get(c));
				}
				while (data.size() < dataCols) {
					data.add("");
				}
				String fileName = cells.size() > dataCols ? cells.get(dataCols) : "";
				String filePath = cells.size() > dataCols + 1 ? cells.get(dataCols + 1) : "";
				Map<String, String> map = new LinkedHashMap<>();
				map.put("tr_data", String.join("~", data));
				map.put("signboard_filename", fileName);
				map.put("signboard_filepath", filePath);
				rows.add(map);
			}
		}
		if (rows.isEmpty()) {
			throw new IllegalArgumentException("No signboard rows found in the Excel file.");
		}
		return rows;
	}

	private int update(Session session, String label, String sql, Object... parameters) {
		sql = sql.replace("getdate()", UserSessionSupport.sessionDate());
		String rendered = SqlDebugFormatter.render(sql, parameters).replaceAll("[\\t ]+", " ")
				.trim();
		logger.info("TSD {} SQL: {}", label, rendered);
		return NativeQuerySupport.executeUpdateInSession(session, sql, parameters);
	}

	private TsdContextResolver.Working requireConverter(HttpServletRequest request,
			String custCode, String loginId) {
		TsdContextResolver.Working working =
				contextResolver.resolve(request.getSession(false), custCode, loginId);
		if (working.needsConverterSelection() || working.convCode().isBlank()) {
			throw new IllegalArgumentException(
					"Select a TSD converter (Change Converter) before continuing.");
		}
		return working;
	}

	private static String[] splitColumns(String columns) {
		if (columns == null || columns.isBlank()) {
			return new String[0];
		}
		return columns.split(",", -1);
	}

	private static long parseLong(Object value) {
		return longVal(value);
	}
}
