package com.mmm.tsd;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import com.mmm.authentication.UserSessionSupport;

import jakarta.servlet.http.HttpSession;

/**
 * Working converter for every TSD API.
 *
 * Resolve order:
 * <ol>
 *   <li>Module Change Converter (role {@code INPC_TSD_CHANGE_CONVERTER} + session)</li>
 *   <li>Portal Change Customer ({@link UserSessionSupport#resolveProcedureCustomerContext})</li>
 *   <li>Direct login {@code cust_code}</li>
 * </ol>
 * Candidate must exist in {@code tsd_distributor.code}.
 */
final class TsdContextResolver {

	static final String ROLE_CHANGE_CONVERTER = "INPC_TSD_CHANGE_CONVERTER";

	/** TSD-only session keys — do not reuse portal fw_override_cust_*. */
	static final String TSD_CONV_CODE = "tsd_conv_code";
	static final String TSD_CONV_NAME = "tsd_conv_name";
	static final String TSD_CONV_OVERRIDDEN = "tsd_conv_overridden";

	private final TsdRequestsSql sql;

	TsdContextResolver(TsdRequestsSql sql) {
		this.sql = sql;
	}

	Working resolve(HttpSession session, String requestedCustCode, String requestedLoginId) {
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}

		boolean canChangeConverter = hasRole(session, ROLE_CHANGE_CONVERTER);

		/* 1) Module Change Converter */
		if (canChangeConverter && isTsdOverrideActive(session)) {
			String code = text(session.getAttribute(TSD_CONV_CODE));
			Map<String, Object> dist = sql.distributor(code);
			if (dist != null) {
				return Working.fromDistributor(dist, loginId(session), "change_converter",
						true, canChangeConverter, false);
			}
			clearTsdOverride(session);
		}

		/* 2) Portal Change Customer, else 3) direct login */
		UserSessionSupport.ProcedureCustomerContext portal =
				UserSessionSupport.resolveProcedureCustomerContext(
						session, requestedCustCode, requestedLoginId);

		String userType = text(session.getAttribute(UserSessionSupport.LOGIN_USER_TYPE));
		boolean customerAccount = isCustomer(userType);
		if (!customerAccount && !portal.overridden() && !canChangeConverter) {
			throw new IllegalArgumentException("TSD E-Warranty is available to customer accounts only.");
		}

		String candidate = text(portal.custCode());
		if (candidate.isEmpty()) {
			if (canChangeConverter) {
				return Working.needsSelection(portal.loginId(), canChangeConverter);
			}
			throw new IllegalArgumentException("No customer / converter is selected for TSD.");
		}

		Map<String, Object> dist = sql.distributor(candidate);
		if (dist == null) {
			if (canChangeConverter) {
				return Working.needsSelection(portal.loginId(), canChangeConverter);
			}
			String sourceHint = portal.overridden() ? "Change Customer" : "login";
			throw new IllegalArgumentException(
					"Customer " + candidate + " (" + sourceHint
							+ ") is not registered as a TSD converter in tsd_distributor.");
		}

		String source = portal.overridden() ? "change_customer" : "login";
		return Working.fromDistributor(dist, portal.loginId(), source,
				portal.overridden(), canChangeConverter, false);
	}

	/** Apply module override — role + code must be in limited ASM list for login ENL. */
	Working applyConverter(HttpSession session, String convCode) {
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		if (!hasRole(session, ROLE_CHANGE_CONVERTER)) {
			throw new IllegalArgumentException("Change Converter is not permitted.");
		}
		String code = text(convCode);
		if (code.isEmpty()) {
			throw new IllegalArgumentException("Converter code is required.");
		}
		String enlId = loginId(session);
		if (!sql.isAllowedOverrideConverter(code, enlId)) {
			throw new IllegalArgumentException(
					"Converter " + code + " is not in your allowed TSD converter list.");
		}
		Map<String, Object> dist = sql.distributor(code);
		if (dist == null) {
			throw new IllegalArgumentException(
					"Converter " + code + " is not registered in tsd_distributor.");
		}
		session.setAttribute(TSD_CONV_CODE, code);
		session.setAttribute(TSD_CONV_NAME, text(dist.get("conv_name")));
		session.setAttribute(TSD_CONV_OVERRIDDEN, "Yes");
		return Working.fromDistributor(dist, enlId, "change_converter", true, true, false);
	}

	Working clearConverter(HttpSession session, String requestedCustCode, String requestedLoginId) {
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		if (!hasRole(session, ROLE_CHANGE_CONVERTER)) {
			throw new IllegalArgumentException("Change Converter is not permitted.");
		}
		clearTsdOverride(session);
		return resolve(session, requestedCustCode, requestedLoginId);
	}

	static void clearTsdOverride(HttpSession session) {
		if (session == null) {
			return;
		}
		session.removeAttribute(TSD_CONV_CODE);
		session.removeAttribute(TSD_CONV_NAME);
		session.removeAttribute(TSD_CONV_OVERRIDDEN);
	}

	private static boolean isTsdOverrideActive(HttpSession session) {
		return "yes".equalsIgnoreCase(text(session.getAttribute(TSD_CONV_OVERRIDDEN)))
				&& !text(session.getAttribute(TSD_CONV_CODE)).isEmpty();
	}

	static boolean hasRolePublic(HttpSession session, String role) {
		return hasRole(session, role);
	}

	private static boolean hasRole(HttpSession session, String role) {
		String roles = text(session.getAttribute(UserSessionSupport.LOGIN_USER_ROLES));
		if (roles.isEmpty() || role == null || role.isBlank()) {
			return false;
		}
		String needle = role.trim().toUpperCase(Locale.ROOT);
		for (String part : roles.split("[,;|]")) {
			if (needle.equals(part.trim().toUpperCase(Locale.ROOT))) {
				return true;
			}
		}
		return false;
	}

	private static boolean isCustomer(String value) {
		return "CUST".equalsIgnoreCase(value) || "Customer".equalsIgnoreCase(value)
				|| "Vendor".equalsIgnoreCase(value) || "VEND".equalsIgnoreCase(value);
	}

	private static String loginId(HttpSession session) {
		return text(session.getAttribute(UserSessionSupport.LOGIN_ID));
	}

	record Working(
			String convCode,
			String convName,
			String convDisplay,
			String loginId,
			String source,
			boolean portalOverridden,
			boolean canChangeConverter,
			boolean needsConverterSelection,
			Map<String, Object> warrantyObj) {

		static Working fromDistributor(
				Map<String, Object> dist,
				String loginId,
				String source,
				boolean portalOverridden,
				boolean canChangeConverter,
				boolean needsSelection) {
			Map<String, Object> warranty = new LinkedHashMap<>();
			warranty.put("is_pq_warranty", text(dist.get("is_pq_warranty")));
			warranty.put("is_actual_warranty", text(dist.get("is_actual_warranty")));
			warranty.put("is_ppc_for_retail_sale", text(dist.get("is_ppc_for_retail_sale")));
			warranty.put("address1", text(dist.get("address1")));
			warranty.put("address2", text(dist.get("address2")));
			warranty.put("state_name", text(dist.get("state_name")));
			warranty.put("dist_int_code", text(dist.get("dist_int_code")));
			warranty.put("entity", text(dist.get("entity")));
			warranty.put("distibutor", text(dist.get("conv_display")));
			return new Working(
					text(dist.get("conv_code")),
					text(dist.get("conv_name")),
					text(dist.get("conv_display")),
					loginId == null ? "" : loginId.trim(),
					source,
					portalOverridden,
					canChangeConverter,
					needsSelection,
					warranty);
		}

		static Working needsSelection(String loginId, boolean canChangeConverter) {
			return new Working("", "", "", loginId == null ? "" : loginId.trim(),
					"", false, canChangeConverter, true, Map.of());
		}

		Map<String, Object> toMap() {
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", convCode);
			data.put("convCode", convCode);
			data.put("convName", convName);
			data.put("convDisplay", convDisplay);
			data.put("loginId", loginId);
			data.put("source", source);
			data.put("overridden", "change_converter".equals(source) || portalOverridden);
			data.put("portalOverridden", portalOverridden);
			data.put("converterOverridden", "change_converter".equals(source));
			data.put("canChangeConverter", canChangeConverter);
			data.put("needsConverterSelection", needsConverterSelection);
			data.put("inTsdMaster", !needsConverterSelection && !convCode.isEmpty());
			data.put("warranty_obj", warrantyObj);
			return data;
		}
	}
}
