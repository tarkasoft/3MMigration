package com.mmm.tsd;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/**
 * TSD My Requests SQL against warranty DB {@code dINTWSYS}
 * ({@link HibernateFactoryRegistry#TSD}).
 */
final class TsdRequestsSql {
	private static final Logger logger = LoggerFactory.getLogger(TsdRequestsSql.class);

	private static final String DISTRIBUTOR_SQL = """
			select
				dist.code as conv_code,
				dist.name as conv_name,
				cast(dist.code as varchar(20)) + '-' + isnull(dist.name, '') as conv_display,
				isnull(dist.is_pq_warranty, '') as is_pq_warranty,
				isnull(dist.is_actual_warranty, '') as is_actual_warranty,
				isnull(dist.is_ppc_for_retail_sale, '') as is_ppc_for_retail_sale,
				isnull(dist.address1, '') as address1,
				rtrim(isnull(dist.address2, '') + ' ' + isnull(dist.city, '')) as address2,
				isnull(s.name, '') as state_name,
				cast(dist.internal_code as varchar(20)) as dist_int_code,
				isnull(dist.entity, '') as entity
			from tsd_distributor dist with (nolock)
			left join tk_state s with (nolock)
				on cast(s.internal_code as varchar(20)) = cast(dist.state as varchar(20))
			where cast(dist.code as varchar(20)) = ?
			""";

	private static final String STATES_SQL = """
			select
				cast(internal_code as varchar(20)) as internal_code,
				isnull(code, '') as code,
				isnull(name, '') as name
			from tk_state with (nolock)
			order by name
			""";

	private static final String PRODUCT_CATEGORIES_SQL = """
			select
				cast(internal_code as varchar(20)) as internal_code,
				isnull(category, '') as category,
				isnull(cast(sequence as varchar(20)), '') as sequence,
				isnull(active, '') as active
			from tsd_product_category with (nolock)
			order by sequence, category
			""";

	private static final String PRODUCT_AC_SQL = """
			select top 15
				cast(internal_code as varchar(20)) as internal_code,
				isnull(cast(category as varchar(20)), '') as category,
				isnull(product_name, '') as value,
				isnull(cast(sequence as varchar(20)), '') as sequence,
				isnull(active, '') as active,
				isnull(warranty_years, 1) as warranty_years,
				isnull(sign_board_table_columns, '') as sign_board_table_columns,
				isnull(table_name, '') as table_name,
				isnull(table_columns, '') as table_columns,
				isnull(sign_board_table_label, '') as sign_board_table_label,
				isnull(sign_board_table_remarks, '') as sign_board_table_remarks
			from tsd_product_master with (nolock)
			where product_name like ?
				and cast(category as varchar(20)) = ?
				and active = 'Yes'
			order by product_name
			""";

	/** Legacy {@code TSDCommon/GetWarrantyAutoComplete} — Approved PQ for working converter. */
	private static final String WARRANTY_AC_SQL = """
			select top 100
				isnull(req_id, '') as value,
				cast(internal_code as varchar(20)) as internal_code
			from tsd_new_request with (nolock)
			where req_id like ?
				and wrty_type = 'PQ Warranty'
				and ltrim(rtrim(isnull(status, ''))) = 'Approved'
				and cast(req_dist as varchar(20)) = ?
			order by internal_code desc
			""";

	private static final String REQUESTS_SQL = """
			select
				cast(dist.code as varchar(20)) + '-' + isnull(dist.name, '') as dist_name,
				tsd.internal_code as req_int_code,
				tsd.req_id as req_id,
				isnull(convert(varchar(10), tsd.req_date, 103), '') as req_date,
				isnull(tsd.wrty_type, '') as wrty_type,
				isnull(tsd.status, '') as wrr_status
			from tsd_new_request tsd with (nolock)
			inner join tsd_distributor dist with (nolock) on dist.code = tsd.req_dist
			where tsd.req_dist = ?
			order by tsd.internal_code desc
			""";

	/** Limited Change Converter list — mapped ASM for login ENL (legacy tsd_ovrride_con_code). */
	private static final String OVERRIDE_AC_SQL = """
			select distinct top 10
				cast(d.code as varchar(20)) + ' - ' + isnull(d.name, '') as value,
				d.code as code,
				isnull(d.name, '') as name,
				cast(d.internal_code as varchar(20)) as internal_code
			from tsd_distributor d with (nolock)
			where (d.code like ? or d.name like ?)
				and d.internal_code in (
					select td.distributor
					from tsd_distributor_asm_mapping td with (nolock)
					inner join ia_user_master ia with (nolock) on td.asm = ia.internal_code
					where ia.enl_id = ?
				)
			order by value
			""";

	private static final String OVERRIDE_ALLOWED_SQL = """
			select top 1 d.code as code
			from tsd_distributor d with (nolock)
			where d.code = ?
				and d.internal_code in (
					select td.distributor
					from tsd_distributor_asm_mapping td with (nolock)
					inner join ia_user_master ia with (nolock) on td.asm = ia.internal_code
					where ia.enl_id = ?
				)
			""";

	private static final String REQUEST_DETAIL_SQL = """
			select
				isnull(tn.tender_no, '') as p_tender_no,
				cast(tn.internal_code as varchar(20)) as internal_code,
				isnull(tn.agreement_signed, '') as agreement_signed,
				isnull(tn.req_id, '') as req_id,
				isnull(tn.wrty_type, '') as wrty_type,
				isnull(tn.status, '') as wrr_status,
				isnull(tn.is_conv_appl, '') as is_conv_appl,
				isnull(tn.is_first_pq_war, '') as is_first_pq_war,
				isnull(tn.rel_with_exist_cust, '') as rel_with_exist_cust,
				isnull(tn.pq_cert_issued, '') as pq_cert_issued,
				isnull(tn.signed_current, '') as signed_current,
				isnull(tn.certified_by_us, '') as certified_by_us,
				isnull(tn.cust_remarks, '') as cust_remarks,
				isnull(tn.acc_overdue_status, '') as acc_overdue_status,
				isnull(tn.due_deli_status, '') as due_deli_status,
				isnull(tn.other_comments, '') as other_comments,
				isnull(tn.is_first_time_ppc, '') as is_first_time_ppc,
				isnull(tn.is_dist_signed_curr, '') as is_dist_signed_curr,
				isnull(cast(ppc.code as varchar(20)) + '-' + isnull(ppc.name, ''), '') as ppc_distibutor,
				isnull(tn.buyer_name, '') as buyer_name,
				isnull(tn.buyer_address, '') as buyer_address,
				isnull(tn.buyer_statte, '') as buyer_statte,
				isnull(tn.warranty_no, '') as warranty_no,
				isnull(tn.pq_warranty_exists, '') as pq_warranty_exists,
				isnull(cast(td.code as varchar(20)) + ' - ' + isnull(td.name, ''), '') as distributor,
				cast(isnull(td.internal_code, 0) as varchar(20)) as dist_int_code,
				isnull(td.address1, '') + isnull(td.address2, '') as dist_address,
				isnull(td.city, '') as dist_city,
				isnull(cast(td.state as varchar(20)), '') as dist_state,
				isnull(td.phone_no, '') as dist_phone,
				isnull(td.email, '') as dist_email,
				isnull(tn.cust_name, '') as customer_name,
				isnull(tn.cust_addr1, '') as cust_addr1,
				isnull(tn.cust_addr2, '') as cust_addr2,
				isnull(tn.cust_addr1, '') + '-' + isnull(tn.cust_addr2, '') as cust_address,
				/* 103 = dd/mm/yyyy; never isnull(datetime,'') → 1900-01-01 */
				case
					when tn.date_of_sale is null then ''
					when convert(varchar(10), tn.date_of_sale, 126) like '1900-%' then ''
					else convert(varchar(10), tn.date_of_sale, 103)
				end as date_of_sale,
				isnull(tn.contractor_name, '') as contract_name,
				isnull(tn.contractor_address1, '') as contractor_address1,
				isnull(tn.contractor_address2, '') as contractor_address2,
				isnull(tn.contractor_address1, '') + '-' + isnull(tn.contractor_address2, '') as contract_address,
				isnull(cast(tn.state as varchar(20)), '') as cust_state_code,
				isnull(cast(tn.contractor_state as varchar(20)), '') as contract_state_code,
				isnull(tk.name, '') as cust_state,
				isnull(tkk.name, '') as contract_state,
				isnull(cast(tn.no_of_products as varchar(20)), '0') as no_of_products,
				isnull(tn.req_dist, '') as req_dist
			from tsd_new_request tn with (nolock)
			left join tsd_distributor td with (nolock) on td.code = tn.req_dist
			left join tsd_distributor ppc with (nolock) on ppc.internal_code = tn.ppc_distibutor
			left join tk_state tk with (nolock)
				on cast(tk.internal_code as varchar(20)) = cast(tn.state as varchar(20))
			left join tk_state tkk with (nolock)
				on cast(tkk.internal_code as varchar(20)) = cast(tn.contractor_state as varchar(20))
			where tn.internal_code = ?
				and cast(tn.req_dist as varchar(20)) = ?
			""";

	private static final String REQUEST_PRODUCTS_SQL = """
			select
				cast(tn.internal_code as varchar(20)) as internal_code,
				isnull(cast(tn.prod_sl_no as varchar(20)), '') as prod_sl_no,
				isnull(tpc.category, '') as product_type,
				isnull(nullif(cast(tn.product_type as varchar(20)), ''),
					cast(tp.category as varchar(20))) as product_type_code,
				cast(tn.product_code as varchar(20)) as product_code,
				isnull(tn.prod_sign_board_table_columns, '') as prod_sign_board_table_columns,
				isnull(tn.prod_table_name, '') as prod_table_name,
				isnull(tn.prod_table_columns, '') as prod_table_columns,
				isnull(tn.work_order_details, '') as work_order_details,
				isnull(cast(tn.no_of_warrnty_years as varchar(20)), '') as no_of_warrnty_years,
				isnull(tn.tender_no, '') as tender_no,
				isnull(tn.comments, '') as comments,
				isnull(tn.tender_doc_name, '') as tender_doc_name,
				isnull(tn.tender_doc_path, '') as tender_doc_path,
				isnull(tn.warranty_doc_name, '') as warranty_doc_name,
				isnull(tn.warranty_doc_path, '') as warranty_doc_path,
				isnull(tp.product_name, '') as product_name,
				cast(tp.internal_code as varchar(20)) as prod_int_code,
				isnull(tp.sign_board_table_label, '') as sign_board_table_label,
				isnull(tp.sign_board_table_remarks, '') as sign_board_table_remarks,
				isnull(cast(tn.ppc_qty as varchar(20)), '0') as ppc_qty,
				isnull(tn.ppc_qty_uom, '') as ppc_uom,
				isnull(tn.project_name, '') as project_name,
				/* Prefer dd/mm/yyyy for edit form / date picker */
				case
					when tn.actual_date_of_instl is null
						or ltrim(rtrim(cast(tn.actual_date_of_instl as varchar(40)))) = '' then ''
					when convert(varchar(10), try_convert(datetime, tn.actual_date_of_instl, 126), 126)
						like '1900-%' then ''
					when try_convert(datetime, tn.actual_date_of_instl, 103) is not null
						then convert(varchar(10),
							try_convert(datetime, tn.actual_date_of_instl, 103), 103)
					when try_convert(datetime, tn.actual_date_of_instl, 126) is not null
						then convert(varchar(10),
							try_convert(datetime, tn.actual_date_of_instl, 126), 103)
					else ltrim(rtrim(cast(tn.actual_date_of_instl as varchar(40))))
				end as actual_date_of_instl
			from tsd_new_request_product_table tn with (nolock)
			inner join tsd_product_master tp with (nolock) on tp.internal_code = tn.product_code
			inner join tsd_product_category tpc with (nolock)
				on cast(tpc.internal_code as varchar(20)) = cast(tp.category as varchar(20))
			where tn.ref_s_ref_data_code = ?
			order by tn.prod_sl_no
			""";

	private static final String REQUEST_SIGNBOARD_SQL = """
			select
				isnull(cast(s.row_sequence as varchar(20)), '') as row_sequence,
				isnull(s.tr_data, '') as tr_data,
				isnull(s.signboard_filename, '') as signboard_filename,
				isnull(s.signboard_filepath, '') as signboard_filepath,
				isnull(r.prod_sign_board_table_columns, '') as table_columns
			from tsd_new_request_product_table r with (nolock)
			inner join tsd_new_request_signboard_table s with (nolock)
				on cast(s.ref_s_ref_data_code as varchar(20)) = cast(r.ref_s_ref_data_code as varchar(20))
				and cast(s.ref_product_code as varchar(20)) = cast(r.internal_code as varchar(20))
			where r.ref_s_ref_data_code = ?
				and r.internal_code = ?
			order by s.row_sequence
			""";

	private static final String FILE_OWNED_BY_REQUEST_SQL = """
			select top 1 'ok' as ok
			from tsd_new_request tn with (nolock)
			where tn.internal_code = ?
				and cast(tn.req_dist as varchar(20)) = ?
				and (
					exists (
						select 1 from tsd_new_request_product_table p with (nolock)
						where p.ref_s_ref_data_code = tn.internal_code
							and isnull(p.warranty_doc_path, '') = ?
					)
					or exists (
						select 1 from tsd_new_request_signboard_table s with (nolock)
						where s.ref_s_ref_data_code = tn.internal_code
							and isnull(s.signboard_filepath, '') = ?
					)
					or exists (
						select 1 from tsd_new_request_documents d with (nolock)
						where d.ref_s_ref_data_code = tn.internal_code
							and isnull(d.document_path, '') = ?
					)
				)
			""";

	/** New Request document master (+ existing files when editing). */
	private static final String DOCUMENT_MASTER_SQL = """
			select
				cast(td.internal_code as varchar(20)) as doc_int_code,
				isnull(td.short_code, '') as short_code,
				isnull(td.document_name, '') as document_name,
				isnull(td.mandatory, '') as mandatory,
				isnull(cast(td.sequence as varchar(20)), '') as sequence,
				isnull(cast(tsd.internal_code as varchar(20)), '') as doc_row_id,
				isnull(tsd.document_name, '') as ftp_file_name,
				isnull(tsd.document_path, '') as ftp_file_path
			from tsd_document_master td with (nolock)
			left join tsd_new_request_documents tsd with (nolock)
				on cast(tsd.ref_s_ref_data_code as varchar(20)) = ?
				and cast(td.internal_code as varchar(20)) = cast(tsd.doc_int_code as varchar(20))
			where td.warranty_type = ?
			order by td.sequence, td.internal_code
			""";

	private static final String APPROVAL_MATRIX_NEW_SQL = """
			select
				isnull(ta.approval_role, '') as approver_role,
				isnull(cast(ta.sequence as varchar(20)), '') as sequence,
				isnull(ta.ui_status, '') as ui_status,
				'' as pending_with_enl_id,
				'' as approver,
				isnull(ta.approval_source, '') as approval_source
			from tsd_approval_matrix ta with (nolock)
			where ta.entity = ?
				and ta.warranty_type = ?
			order by ta.sequence
			""";

	private static final String APPROVAL_MATRIX_EDIT_SQL = """
			select
				isnull(ta.approval_role, '') as approver_role,
				isnull(cast(ta.sequence as varchar(20)), '') as sequence,
				isnull(ta.ui_status, '') as ui_status,
				isnull(tn.pending_with_enl_id, '') as pending_with_enl_id,
				isnull(ia.enl_id + '-' + ia.name, '') as approver,
				isnull(ta.approval_source, '') as approval_source
			from tsd_approval_matrix ta with (nolock)
			left join tsd_new_request_approval_matrix tn with (nolock)
				on ta.approval_role = tn.approval_role
				and ta.approval_source = tn.approval_src
				and cast(tn.ref_s_ref_data_code as varchar(20)) = ?
				and tn.sequence = ta.sequence
			left join ia_user_master ia with (nolock) on ia.enl_id = tn.pending_with_enl_id
			where ta.entity = ?
				and ta.warranty_type = ?
			order by ta.sequence
			""";

	private static final String ASM_BY_STATE_SQL = """
			select
				isnull(ia.enl_id, '') as asm,
				isnull(ia.name, '') as asm_name,
				cast(tas.asm as varchar(20)) as asm_int_code
			from tsd_asm_state_mapping tas with (nolock)
			inner join ia_user_master ia with (nolock) on ia.internal_code = tas.asm
			where cast(tas.state as varchar(20)) = ?
			order by ia.name
			""";

	private static final String ASM_BY_DIST_SQL = """
			select
				cast(td.asm as varchar(20)) as asm_int_code,
				isnull(ia.enl_id, '') as asm,
				isnull(ia.name, '') as asm_name
			from tsd_distributor_asm_mapping td with (nolock)
			inner join ia_user_master ia with (nolock) on td.asm = ia.internal_code
			left join tsd_distributor tdd with (nolock) on tdd.internal_code = td.distributor
			where cast(tdd.code as varchar(20)) = ?
			order by ia.name
			""";

	private static final String RSM_NSM_SQL = """
			select
				cast(td.asm as varchar(20)) as asm,
				isnull(ia.enl_id, '') as rsm,
				isnull(ia.name, '') as rsm_name,
				isnull(iaa.enl_id, '') as nsm,
				isnull(iaa.name, '') as nsm_name
			from tsd_asm_rsm_mapping td with (nolock)
			inner join ia_user_master ia with (nolock) on td.rsm = ia.internal_code
			inner join ia_user_master iaa with (nolock) on td.nsm = iaa.internal_code
			order by ia.name
			""";

	private static final String DIVISION_LIST_SQL = """
			select
				isnull(td.code, '') as code,
				isnull(td.name, '') as name,
				isnull(ia.enl_id, '') as div_manager_id,
				isnull(ia.name, '') as division_manager_name,
				isnull(iaa.enl_id, '') as grp_manager_id,
				isnull(iaa.name, '') as grp_manager_name
			from tsd_division_master td with (nolock)
			inner join ia_user_master ia with (nolock) on ia.internal_code = td.division_manager
			inner join tsd_group_master tg with (nolock) on tg.internal_code = td.group_code
			inner join ia_user_master iaa with (nolock) on iaa.internal_code = tg.group_manager
			order by td.name
			""";

	private static final String REQUEST_APPROVERS_SQL = """
			select
				cast(arh.internal_code as varchar(20)) as internal_code,
				isnull(arh.ui_status, '') as approver_role,
				isnull(ia.name, '') as approver,
				isnull(arh.approval_status, '') as approval_status,
				isnull(arh.approval_remarks, '') as approval_remarks,
				isnull(convert(varchar(30), arh.modified_date, 121), '') as modified_date
			from tsd_new_request_approval_matrix arh with (nolock)
			left join ia_user_master ia with (nolock) on ia.enl_id = arh.pending_with_enl_id
			where arh.ref_s_ref_data_code = ?
			order by arh.sequence
			""";

	private static final String REQUEST_HISTORY_SQL = """
			select
				isnull(approver_src, '') as approver_src,
				isnull(approver_role, '') as approver_role,
				isnull(updated_by_name, '') as updated_by_name,
				isnull(convert(varchar(30), created_date, 121), '') as created_date,
				isnull(approver_status, '') as approver_status,
				isnull(approver_remarks, '') as approver_remarks
			from tsd_new_request_history with (nolock)
			where ref_s_ref_data_code = ?
			order by created_date desc
			""";

	private static final String REQUEST_DOCUMENTS_SQL = """
			select
				cast(tsd.internal_code as varchar(20)) as doc_row_id,
				cast(isnull(td.internal_code, 0) as varchar(20)) as doc_int_code,
				isnull(td.document_name, '') as document_name,
				isnull(tsd.document_name, '') as ftp_file_name,
				isnull(tsd.document_path, '') as ftp_file_path
			from tsd_new_request_documents tsd with (nolock)
			left join tsd_document_master td with (nolock) on td.internal_code = tsd.doc_int_code
			where tsd.ref_s_ref_data_code = ?
			order by tsd.internal_code
			""";

	private static final String REQUEST_DOCUMENT_ONE_SQL = """
			select
				cast(tsd.internal_code as varchar(20)) as doc_row_id,
				isnull(td.document_name, '') as document_name,
				isnull(tsd.document_name, '') as ftp_file_name,
				isnull(tsd.document_path, '') as ftp_file_path
			from tsd_new_request_documents tsd with (nolock)
			inner join tsd_new_request tn with (nolock) on tn.internal_code = tsd.ref_s_ref_data_code
			left join tsd_document_master td with (nolock) on td.internal_code = tsd.doc_int_code
			where tsd.internal_code = ?
				and tsd.ref_s_ref_data_code = ?
				and cast(tn.req_dist as varchar(20)) = ?
			""";

	private final HibernateFactoryRegistry registry;

	TsdRequestsSql(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	Map<String, Object> distributor(String converterCode) {
		logSql(DISTRIBUTOR_SQL, converterCode);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, DISTRIBUTOR_SQL, converterCode);
		return rows.isEmpty() ? null : rows.get(0);
	}

	List<Map<String, Object>> requests(String converterCode) {
		logSql(REQUESTS_SQL, converterCode);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUESTS_SQL, converterCode);
	}

	List<Map<String, Object>> converterAutocomplete(String phrase, String loginEnlId) {
		String like = "%" + (phrase == null ? "" : phrase.trim()) + "%";
		logSql(OVERRIDE_AC_SQL, like, like, loginEnlId);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, OVERRIDE_AC_SQL, like, like, loginEnlId);
	}

	boolean isAllowedOverrideConverter(String converterCode, String loginEnlId) {
		logSql(OVERRIDE_ALLOWED_SQL, converterCode, loginEnlId);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, OVERRIDE_ALLOWED_SQL,
				converterCode, loginEnlId);
		return !rows.isEmpty();
	}

	List<Map<String, Object>> states() {
		logSql(STATES_SQL);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, STATES_SQL);
	}

	List<Map<String, Object>> productCategories() {
		logSql(PRODUCT_CATEGORIES_SQL);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, PRODUCT_CATEGORIES_SQL);
	}

	private static final String PRODUCT_DYN_STATIC_SQL = """
			select
				isnull(p.table_name, '') as table_name,
				isnull(p.table_columns, '') as table_columns,
				isnull(g.tr_data, '') as tr_data
			from tsd_product_master p with (nolock)
			inner join tsd_product_master_tr_group g with (nolock)
				on p.internal_code = g.ref_s_ref_data_code
			where p.internal_code = ?
			order by g.row_sequence
			""";

	private static final String PRODUCT_DYN_SIGNBOARD_SQL = """
			select
				'' as table_name,
				isnull(sign_board_table_columns, '') as table_columns,
				'' as tr_data,
				isnull(sign_board_table_label, '') as sign_board_table_label,
				isnull(sign_board_table_remarks, '') as sign_board_table_remarks
			from tsd_product_master with (nolock)
			where internal_code = ?
			""";

	List<Map<String, Object>> productDynStaticRows(String productId) {
		logSql(PRODUCT_DYN_STATIC_SQL, productId);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, PRODUCT_DYN_STATIC_SQL, productId);
	}

	List<Map<String, Object>> productDynSignboardMeta(String productId) {
		logSql(PRODUCT_DYN_SIGNBOARD_SQL, productId);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, PRODUCT_DYN_SIGNBOARD_SQL, productId);
	}

	List<Map<String, Object>> productAutocomplete(String phrase, String categoryId) {
		String like = "%" + (phrase == null ? "" : phrase.trim()) + "%";
		String category = categoryId == null ? "" : categoryId.trim();
		logSql(PRODUCT_AC_SQL, like, category);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, PRODUCT_AC_SQL, like, category);
	}

	List<Map<String, Object>> warrantyAutocomplete(String phrase, String converterCode) {
		String like = "%" + (phrase == null ? "" : phrase.trim()) + "%";
		String conv = converterCode == null ? "" : converterCode.trim();
		logSql(WARRANTY_AC_SQL, like, conv);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, WARRANTY_AC_SQL, like, conv);
	}

	Map<String, Object> requestDetail(long internalCode, String converterCode) {
		logSql(REQUEST_DETAIL_SQL, internalCode, converterCode);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUEST_DETAIL_SQL,
				internalCode, converterCode);
		return rows.isEmpty() ? null : rows.get(0);
	}

	List<Map<String, Object>> requestProducts(long internalCode) {
		logSql(REQUEST_PRODUCTS_SQL, internalCode);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUEST_PRODUCTS_SQL, internalCode);
	}

	List<Map<String, Object>> requestSignboardRows(long requestId, long productRowId) {
		logSql(REQUEST_SIGNBOARD_SQL, requestId, productRowId);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUEST_SIGNBOARD_SQL,
				requestId, productRowId);
	}

	boolean fileOwnedByRequest(long requestId, String converterCode, String filePath) {
		logSql(FILE_OWNED_BY_REQUEST_SQL, requestId, converterCode, filePath, filePath, filePath);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, FILE_OWNED_BY_REQUEST_SQL,
				requestId, converterCode, filePath, filePath, filePath);
		return !rows.isEmpty();
	}

	List<Map<String, Object>> requestApprovers(long internalCode) {
		logSql(REQUEST_APPROVERS_SQL, internalCode);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUEST_APPROVERS_SQL, internalCode);
	}

	List<Map<String, Object>> requestHistory(long internalCode) {
		logSql(REQUEST_HISTORY_SQL, internalCode);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUEST_HISTORY_SQL, internalCode);
	}

	List<Map<String, Object>> requestDocuments(long internalCode) {
		logSql(REQUEST_DOCUMENTS_SQL, internalCode);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUEST_DOCUMENTS_SQL, internalCode);
	}

	Map<String, Object> requestDocument(long documentId, long requestId, String converterCode) {
		logSql(REQUEST_DOCUMENT_ONE_SQL, documentId, requestId, converterCode);
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, REQUEST_DOCUMENT_ONE_SQL,
				documentId, requestId, converterCode);
		return rows.isEmpty() ? null : rows.get(0);
	}

	List<Map<String, Object>> documentMaster(String editIntCode, String warrantyType) {
		String editKey = editIntCode == null || editIntCode.isBlank() ? "0" : editIntCode.trim();
		logSql(DOCUMENT_MASTER_SQL, editKey, warrantyType);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, DOCUMENT_MASTER_SQL, editKey, warrantyType);
	}

	List<Map<String, Object>> approvalMatrix(String entity, String editIntCode, String warrantyType) {
		String editKey = editIntCode == null || editIntCode.isBlank() ? "0" : editIntCode.trim();
		if ("0".equals(editKey)) {
			logSql(APPROVAL_MATRIX_NEW_SQL, entity, warrantyType);
			return NativeQuerySupport.executeQuery(
					registry, HibernateFactoryRegistry.TSD, APPROVAL_MATRIX_NEW_SQL,
					entity, warrantyType);
		}
		logSql(APPROVAL_MATRIX_EDIT_SQL, editKey, entity, warrantyType);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, APPROVAL_MATRIX_EDIT_SQL,
				editKey, entity, warrantyType);
	}

	List<Map<String, Object>> asmByState(String stateCode) {
		if (stateCode == null || stateCode.isBlank()) {
			return List.of();
		}
		logSql(ASM_BY_STATE_SQL, stateCode);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, ASM_BY_STATE_SQL, stateCode);
	}

	List<Map<String, Object>> asmByDistributor(String distCode) {
		if (distCode == null || distCode.isBlank()) {
			return List.of();
		}
		logSql(ASM_BY_DIST_SQL, distCode);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, ASM_BY_DIST_SQL, distCode);
	}

	List<Map<String, Object>> rsmNsmList() {
		logSql(RSM_NSM_SQL);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, RSM_NSM_SQL);
	}

	List<Map<String, Object>> divisionList() {
		logSql(DIVISION_LIST_SQL);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.TSD, DIVISION_LIST_SQL);
	}

	/** Always print SQL with bound values (same pattern as CIR). */
	private static void logSql(String sql, Object... parameters) {
		String rendered = SqlDebugFormatter.render(sql, parameters).replaceAll("[\\t ]+", " ")
				.trim();
		logger.info("TSD {} SQL: {}", HibernateFactoryRegistry.TSD, rendered);
	}
}
