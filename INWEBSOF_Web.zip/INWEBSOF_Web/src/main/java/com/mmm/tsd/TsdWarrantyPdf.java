package com.mmm.tsd;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;

import jakarta.servlet.http.HttpServletRequest;

/**
 * On-demand TSD warranty certificate PDF (legacy {@code TSDGenerateWarrantyPDF}).
 * PQ / Actual → PQ template; PPC → PPC template. Assets: {@code classpath:tsd/images/}.
 */
@RestController
@RequestMapping("/api/customer/tsd")
public class TsdWarrantyPdf {
	private static final Logger logger = LoggerFactory.getLogger(TsdWarrantyPdf.class);

	private final TsdRequestsSql requestsSql;
	private final TsdContextResolver contextResolver;
	private final TsdWarrantyPdfBuilder builder;

	public TsdWarrantyPdf(HibernateFactoryRegistry registry) {
		this.requestsSql = new TsdRequestsSql(registry);
		this.contextResolver = new TsdContextResolver(requestsSql);
		this.builder = new TsdWarrantyPdfBuilder(new TsdWarrantyPdfSql(registry));
	}

	/**
	 * Generate warranty PDF for one product.
	 * {@code productMasterId} = {@code tsd_product_master.internal_code} (prod_int_code).
	 */
	@GetMapping("/requests/{requestId}/products/{productMasterId}/warranty-pdf")
	public ResponseEntity<byte[]> downloadWarrantyPdf(HttpServletRequest request,
			@PathVariable long requestId,
			@PathVariable long productMasterId,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			TsdContextResolver.Working working =
					contextResolver.resolve(request.getSession(false), custCode, loginId);
			if (working.needsConverterSelection() || working.convCode() == null
					|| working.convCode().isBlank()) {
				throw new IllegalArgumentException("Select a converter before downloading the certificate.");
			}
			TsdWarrantyPdfBuilder.PdfResult pdf =
					builder.build(requestId, productMasterId, working.convCode());
			return ResponseEntity.ok()
					.contentType(MediaType.APPLICATION_PDF)
					.header(HttpHeaders.CONTENT_DISPOSITION,
							ContentDisposition.attachment().filename(pdf.fileName()).build().toString())
					.header("X-Content-Type-Options", "nosniff")
					.body(pdf.bytes());
		} catch (IllegalArgumentException | IllegalStateException ex) {
			HttpStatus status = UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())
					? HttpStatus.UNAUTHORIZED : HttpStatus.BAD_REQUEST;
			logger.warn("TSD warranty PDF rejected: {}", ex.getMessage());
			return ResponseEntity.status(status).build();
		} catch (Exception ex) {
			logger.error("Unable to generate TSD warranty PDF requestId={} productMasterId={}",
					requestId, productMasterId, ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}
}
