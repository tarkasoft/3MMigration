package com.mmm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.mmm.authentication.SessionLoginInterceptor;
import com.mmm.shipanddebit.ShipAndDebitApiAuditInterceptor;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final SessionLoginInterceptor sessionLoginInterceptor;
    private final ShipAndDebitApiAuditInterceptor shipAndDebitApiAuditInterceptor;
    private final boolean sessionCheckEnabled;

    public WebMvcConfig(SessionLoginInterceptor sessionLoginInterceptor,
                        ShipAndDebitApiAuditInterceptor shipAndDebitApiAuditInterceptor,
                        @Value("${security.session-check.enabled:false}") boolean sessionCheckEnabled) {
        this.sessionLoginInterceptor = sessionLoginInterceptor;
        this.shipAndDebitApiAuditInterceptor = shipAndDebitApiAuditInterceptor;
        this.sessionCheckEnabled = sessionCheckEnabled;
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("forward:/index.html");
        registry.addViewController("/login").setViewName("forward:/login.html");
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(shipAndDebitApiAuditInterceptor)
                .addPathPatterns("/api/customer/ship-and-debit/**");
        if (!sessionCheckEnabled) {
            return;
        }
        registry.addInterceptor(sessionLoginInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns(
                        "/api/auth/login",
                        "/api/auth/bootstrap-by-enl-id",
                        "/api/auth/imext/**",
                        "/api/auth/logout",
                        "/api/info",
                        "/api/test/**",
                        "/api/cir/**",
                        "/api/csd/**"
                );
    }
}