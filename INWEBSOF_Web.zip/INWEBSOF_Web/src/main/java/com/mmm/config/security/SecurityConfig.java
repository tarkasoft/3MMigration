package com.mmm.config.security;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * v1: open local/dev access when IMEXT is off.
 * When security.imext.enabled=true, OAuth2 login (registration id {@code iamext}) is required.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Value("${security.imext.enabled:false}")
    private boolean imextEnabled;

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http,
                                            ObjectProvider<ImextOAuth2LoginSuccessHandler> imextSuccessHandler,
                                            ObjectProvider<ImextOAuth2LoginFailureHandler> imextFailureHandler)
            throws Exception {
        http.csrf(csrf -> csrf.disable());

        if (imextEnabled) {
            http.authorizeHttpRequests(auth -> auth
                            .requestMatchers(
                                    "/actuator/health",
                                    "/api/info",
                                    "/login",
                                    "/login.html",
                                    "/login1.html",
                                    "/api/auth/login",
                                    "/api/auth/bootstrap-by-enl-id",
                                    "/api/auth/imext/**",
                                    "/oauth2/**",
                                    "/login/oauth2/**",
                                    "/css/**",
                                    "/js/**",
                                    "/plugins/**",
                                    "/nuiassets/**",
                                    "/images/**",
                                    "/assets/**",
                                    "/fonts/**",
                                    "/favicon.ico"
                            ).permitAll()
                            .anyRequest().authenticated())
                    .oauth2Login(oauth2 -> {
                        oauth2.loginPage("/api/auth/imext/start");
                        ImextOAuth2LoginSuccessHandler success = imextSuccessHandler.getIfAvailable();
                        if (success != null) {
                            oauth2.successHandler(success);
                        }
                        ImextOAuth2LoginFailureHandler failure = imextFailureHandler.getIfAvailable();
                        if (failure != null) {
                            oauth2.failureHandler(failure);
                        }
                    });
        } else {
            http.authorizeHttpRequests(auth -> auth.anyRequest().permitAll());
        }
        return http.build();
    }
}
