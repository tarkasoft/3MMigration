package com.mmm.config.security;

import java.io.IOException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.mmm.authentication.AuthService;
import com.mmm.authentication.ImextErrorResponses;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * After Spring exchanges the auth code at {@code /login/oauth2/code/iamext}:
 * read {@code upin}, bootstrap portal session, redirect to {@code /api/auth/imext/response}.
 * Errors are written as plain text (no login.html).
 */
@Component
@ConditionalOnProperty(name = "security.imext.enabled", havingValue = "true")
public class ImextOAuth2LoginSuccessHandler implements AuthenticationSuccessHandler {

    private static final Logger log = LoggerFactory.getLogger(ImextOAuth2LoginSuccessHandler.class);

    private final AuthService authService;

    public ImextOAuth2LoginSuccessHandler(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        String enlId = resolveEnlId(authentication);
        if (enlId == null || enlId.isBlank()) {
            log.warn("IAMExt login succeeded but no upin/ENL_ID claim was present");
            ImextErrorResponses.write(response, HttpServletResponse.SC_UNAUTHORIZED, "missing_upin",
                    "OAuth user had no 'upin' claim (and no usable getName()). Check B2C token claims.");
            return;
        }

        Map<String, Object> user;
        try {
            user = authService.bootstrapSessionByEnlId(request, enlId);
        } catch (Exception ex) {
            log.error("IAMExt session bootstrap failed for enlId={}", enlId, ex);
            ImextErrorResponses.write(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "bootstrap_failed",
                    "enlId=" + enlId + " — " + ex.getMessage());
            return;
        }

        if (user == null) {
            log.warn("IAMExt user not found or inactive for enlId={}", enlId);
            ImextErrorResponses.write(response, HttpServletResponse.SC_UNAUTHORIZED, "user_not_found",
                    "enlId=" + enlId + " not found or inactive in ia_user_master.");
            return;
        }

        log.info("IAMExt login bootstrapped portal session for enlId={}", enlId);
        response.sendRedirect(request.getContextPath() + "/api/auth/imext/response");
    }

    private static String resolveEnlId(Authentication authentication) {
        if (authentication == null || !(authentication.getPrincipal() instanceof OAuth2User oauthUser)) {
            return null;
        }
        Object upin = oauthUser.getAttribute("upin");
        if (upin != null && !String.valueOf(upin).isBlank()) {
            return String.valueOf(upin).trim();
        }
        String name = oauthUser.getName();
        return name == null || name.isBlank() ? null : name.trim();
    }
}
