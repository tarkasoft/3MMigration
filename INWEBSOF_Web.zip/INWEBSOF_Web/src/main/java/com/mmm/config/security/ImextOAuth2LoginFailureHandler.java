package com.mmm.config.security;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.mmm.authentication.ImextErrorResponses;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * B2C / OAuth2 login failure → plain-text error only (no login.html).
 */
@Component
@ConditionalOnProperty(name = "security.imext.enabled", havingValue = "true")
public class ImextOAuth2LoginFailureHandler implements AuthenticationFailureHandler {

    private static final Logger log = LoggerFactory.getLogger(ImextOAuth2LoginFailureHandler.class);

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationException exception)
            throws IOException, ServletException {
        log.warn("IAMExt OAuth2 login failed: {}", exception.getMessage());
        String detail = exception.getClass().getSimpleName() + ": " + exception.getMessage();
        if (exception.getCause() != null) {
            detail = detail + " | cause: " + exception.getCause().getMessage();
        }
        ImextErrorResponses.write(response, HttpServletResponse.SC_UNAUTHORIZED, "oauth_failed", detail);
    }
}
