package com.mmm.config;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Portal / UI settings from {@code portal.properties} (prefix {@code portal}).
 * Exposed to the frontend on GET /api/auth/menus.
 */
@ConfigurationProperties(prefix = "portal")
public class PortalProperties {

    private String customerName = "";
    private String portalTitle = "3M Customer Portal";
    private String companyCode = "";
    private String supportEmail = "";
    private Map<String, String> extras = new LinkedHashMap<>();

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getPortalTitle() { return portalTitle; }
    public void setPortalTitle(String portalTitle) { this.portalTitle = portalTitle; }

    public String getCompanyCode() { return companyCode; }
    public void setCompanyCode(String companyCode) { this.companyCode = companyCode; }

    public String getSupportEmail() { return supportEmail; }
    public void setSupportEmail(String supportEmail) { this.supportEmail = supportEmail; }

    public Map<String, String> getExtras() { return extras; }
    public void setExtras(Map<String, String> extras) { this.extras = extras; }

    /** Flat map for JSON (menus payload). */
    public Map<String, Object> toClientMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("customerName", customerName == null ? "" : customerName);
        m.put("portalTitle", portalTitle == null ? "" : portalTitle);
        m.put("companyCode", companyCode == null ? "" : companyCode);
        m.put("supportEmail", supportEmail == null ? "" : supportEmail);
        if (extras != null && !extras.isEmpty()) {
            m.put("extras", new LinkedHashMap<>(extras));
        }
        return m;
    }
}