package com.mmm.config;

import java.io.IOException;
import java.util.regex.Pattern;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.SessionCookieConfig;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;
import jakarta.servlet.http.HttpSession;

/**
 * IP and localhost keep the session cookie on the webapp path (/inwebsof).
 * The public domain is served at the site root over HTTPS, so that host also
 * gets JSESSIONID with Path=/ and Secure. Otherwise the browser will not send
 * the cookie on https://cportal.tarka.in/api/...
 */
@Configuration
public class PortalSessionCookieConfig {

	private static final Pattern IPV4 = Pattern.compile("\\d{1,3}(?:\\.\\d{1,3}){3}");

	@Bean
	public ServletContextInitializer portalSessionCookie() {
		return servletContext -> {
			SessionCookieConfig cookie = servletContext.getSessionCookieConfig();
			String ctx = servletContext.getContextPath();
			if (ctx == null || ctx.isBlank()) {
				ctx = "/";
			}
			cookie.setPath(ctx);
			cookie.setHttpOnly(true);
			cookie.setSecure(false);
			cookie.setAttribute("SameSite", "Lax");
		};
	}

	@Bean
	public FilterRegistrationBean<DomainSessionCookieFilter> domainSessionCookieFilter() {
		FilterRegistrationBean<DomainSessionCookieFilter> reg = new FilterRegistrationBean<>();
		reg.setFilter(new DomainSessionCookieFilter());
		reg.addUrlPatterns("/*");
		reg.setOrder(Ordered.HIGHEST_PRECEDENCE);
		return reg;
	}

	static final class DomainSessionCookieFilter extends jakarta.servlet.http.HttpFilter {
		@Override
		protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
				throws IOException, ServletException {
			if (!isDomainHost(request)) {
				// Drop a Path=/ cookie left on the IP. It overrides the /inwebsof cookie.
				response.addHeader("Set-Cookie",
						"JSESSIONID=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=Lax");
				chain.doFilter(request, response);
				return;
			}
			RootPathCookieResponse wrapped = new RootPathCookieResponse(request, response);
			chain.doFilter(request, wrapped);
			wrapped.writeRootSessionCookie();
		}

		static boolean isDomainHost(HttpServletRequest request) {
			String host = firstHeader(request, "X-Forwarded-Host");
			if (host == null || host.isBlank()) {
				host = request.getHeader("Host");
			}
			if (host == null || host.isBlank()) {
				host = request.getServerName();
			}
			if (host == null) {
				return false;
			}
			host = host.split(",")[0].trim().toLowerCase();
			int colon = host.indexOf(':');
			if (colon > 0) {
				host = host.substring(0, colon);
			}
			if (host.isEmpty() || "localhost".equals(host) || IPV4.matcher(host).matches()) {
				return false;
			}
			return host.indexOf('.') > 0;
		}

		private static String firstHeader(HttpServletRequest request, String name) {
			String value = request.getHeader(name);
			if (value == null || value.isBlank()) {
				return null;
			}
			return value.split(",")[0].trim();
		}
	}

	/**
	 * Copy the live session id onto Path=/ so the domain root can send it.
	 * Mark it Secure when the browser connection is HTTPS.
	 */
	static final class RootPathCookieResponse extends HttpServletResponseWrapper {
		private final HttpServletRequest request;
		private boolean wroteRoot;

		RootPathCookieResponse(HttpServletRequest request, HttpServletResponse response) {
			super(response);
			this.request = request;
		}

		@Override
		public jakarta.servlet.ServletOutputStream getOutputStream() throws IOException {
			writeRootSessionCookie();
			return super.getOutputStream();
		}

		@Override
		public java.io.PrintWriter getWriter() throws IOException {
			writeRootSessionCookie();
			return super.getWriter();
		}

		@Override
		public void addCookie(Cookie cookie) {
			if (cookie != null && "JSESSIONID".equalsIgnoreCase(cookie.getName())) {
				cookie.setPath("/");
				cookie.setSecure(true);
				cookie.setHttpOnly(true);
			}
			super.addCookie(cookie);
		}

		@Override
		public void addHeader(String name, String value) {
			super.addHeader(name, rewrite(name, value));
		}

		@Override
		public void setHeader(String name, String value) {
			super.setHeader(name, rewrite(name, value));
		}

		void writeRootSessionCookie() {
			if (wroteRoot || isCommitted()) {
				return;
			}
			HttpSession session = request.getSession(false);
			if (session == null) {
				return;
			}
			// The public site is HTTPS. Secure is required or the browser drops the cookie.
			super.addHeader("Set-Cookie",
					"JSESSIONID=" + session.getId() + "; Path=/; HttpOnly; Secure; SameSite=Lax");
			wroteRoot = true;
		}

		private String rewrite(String name, String value) {
			if (name == null || value == null || !"Set-Cookie".equalsIgnoreCase(name)) {
				return value;
			}
			if (!value.regionMatches(true, 0, "JSESSIONID=", 0, "JSESSIONID=".length())) {
				return value;
			}
			if (value.toLowerCase().contains("max-age=0")) {
				return value;
			}
			String rewritten = value.replaceAll("(?i);\\s*Path=/(inwebsof|INPCV2)/?", "; Path=/");
			if (!rewritten.matches("(?i).*;\\s*Path=.*")) {
				rewritten = rewritten + "; Path=/";
			}
			if (!rewritten.toLowerCase().contains("secure")) {
				rewritten = rewritten + "; Secure";
			}
			wroteRoot = true;
			return rewritten;
		}
	}
}
