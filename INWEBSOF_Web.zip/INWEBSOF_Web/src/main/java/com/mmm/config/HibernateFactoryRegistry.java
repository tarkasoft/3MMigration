package com.mmm.config;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import jakarta.annotation.PreDestroy;

/**
 * Named SessionFactory registry.
 * - system: owned by SystemHibernateConfig (Spring TX) â€” injected here
 * - as400 / cir / csd / pos / …: lazy; use {@link #withSession(String, Function)} so Session is always closed
 */
@Component
public class HibernateFactoryRegistry {

    public static final String SYSTEM = "system";
    public static final String AS400 = "as400";
    public static final String CIR = "cir";
    /**
     * Warranty SQL Server {@code dINTWSYS} (legacy {@code hibernate_tws.cfg.xml}).
     * Shared by CSD smoke and TSD E-Warranty — same pool name in {@code application.yml}.
     */
    public static final String CSD = "csd";
    /** Alias for warranty DB — same SessionFactory as {@link #CSD}. Use from {@code com.mmm.tsd}. */
    public static final String TSD = CSD;
    /** SQL Server copy of the INPC system pool. Same host and database, separate Hikari pool. */
    public static final String INFOAPPS = "infoapps";
    /** POS SQL Server dINPOS. Legacy bean dataSource_pos. */
    public static final String POS = "pos";

    private static final Logger log = LoggerFactory.getLogger(HibernateFactoryRegistry.class);

    private final InpcDatasourceProperties props;
    private final SessionFactory systemSessionFactory;
    private final ConcurrentHashMap<String, SessionFactory> factories = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, DataSource> dataSources = new ConcurrentHashMap<>();

    public HibernateFactoryRegistry(InpcDatasourceProperties props,
                                    @Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory systemSessionFactory) {
        this.props = props;
        this.systemSessionFactory = systemSessionFactory;
        this.factories.put(SYSTEM, systemSessionFactory);
    }

    public void initializeEagerFactories() {
        // system already created by Spring; only eager non-system if any
        props.getDatasources().forEach((name, cfg) -> {
            if (cfg != null && !cfg.isLazy() && !SYSTEM.equals(name)) {
                getSessionFactory(name);
            }
        });
    }

    public SessionFactory getSystemSessionFactory() {
        return systemSessionFactory;
    }

    public SessionFactory getAs400SessionFactory() {
        return getSessionFactory(AS400);
    }

    public SessionFactory getCirSessionFactory() {
        return getSessionFactory(CIR);
    }

    public SessionFactory getCsdSessionFactory() {
        return getSessionFactory(CSD);
    }

    /** Same factory as {@link #getCsdSessionFactory()} (warranty {@code dINTWSYS}). */
    public SessionFactory getTsdSessionFactory() {
        return getSessionFactory(TSD);
    }

    public SessionFactory getInfoappsSessionFactory() {
        return getSessionFactory(INFOAPPS);
    }

    public SessionFactory getPosSessionFactory() {
        return getSessionFactory(POS);
    }

    public SessionFactory getSessionFactoryForMenu(String menuKey) {
        String dsName = props.getMenuDatasources().getOrDefault(menuKey, SYSTEM);
        return getSessionFactory(dsName);
    }

    public SessionFactory getSessionFactory(String name) {
        if (SYSTEM.equals(name)) {
            return systemSessionFactory;
        }
        return factories.computeIfAbsent(name, this::buildSessionFactory);
    }

    /**
     * Safe pattern for lazy (non-Spring-TX) factories: open â†’ work â†’ always close.
     * Prefer @Transactional + getCurrentSession() for system DB.
     */
    public <T> T withSession(String datasourceName, Function<Session, T> work) {
        SessionFactory sf = getSessionFactory(datasourceName);
        Session session = sf.openSession();
        try {
            return work.apply(session);
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }

    private SessionFactory buildSessionFactory(String name) {
        InpcDatasourceProperties.DbConfig cfg = props.getDatasources().get(name);
        if (cfg == null) {
            throw new IllegalArgumentException("No datasource configured for name='" + name + "'");
        }
        if (cfg.getUrl() == null || cfg.getUrl().isBlank()) {
            throw new IllegalStateException("Datasource '" + name + "' has empty jdbc url");
        }
        log.info("Building lazy Hibernate SessionFactory for datasource '{}'", name);

        DataSource ds = dataSources.computeIfAbsent(name, n -> createDataSource(n, cfg));

        Configuration configuration = new Configuration();
        configuration.setProperty(AvailableSettings.DIALECT, cfg.getDialect());
        configuration.setProperty(AvailableSettings.SHOW_SQL, "false");
        configuration.setProperty(AvailableSettings.STATEMENT_BATCH_SIZE, "50");

        ServiceRegistry registry = new StandardServiceRegistryBuilder()
                .applySetting(AvailableSettings.DATASOURCE, ds)
                .applySettings(configuration.getProperties())
                .build();

        return configuration.buildSessionFactory(registry);
    }

    private DataSource createDataSource(String name, InpcDatasourceProperties.DbConfig cfg) {
        HikariConfig hc = new HikariConfig();
        hc.setPoolName("inpcv2-" + name);
        hc.setJdbcUrl(cfg.getUrl());
        hc.setUsername(cfg.getUsername());
        hc.setPassword(cfg.getPassword());
        hc.setDriverClassName(cfg.getDriverClassName());
        int max = cfg.getMaxPoolSize() > 0 ? cfg.getMaxPoolSize() : 15;
        int min = cfg.getMinIdle() >= 0 ? cfg.getMinIdle() : 0;
        hc.setMaximumPoolSize(max);
        hc.setMinimumIdle(min);
        hc.setConnectionTimeout(30_000);
        hc.setIdleTimeout(600_000);
        hc.setMaxLifetime(1_800_000);
        return new HikariDataSource(hc);
    }

    public Map<String, String> menuDatasourceMap() {
        return props.getMenuDatasources();
    }

    @PreDestroy
    public void shutdownLazyFactories() {
        factories.forEach((name, sf) -> {
            if (SYSTEM.equals(name)) {
                return; // Spring closes system SF
            }
            try {
                if (sf != null && !sf.isClosed()) {
                    log.info("Closing SessionFactory '{}'", name);
                    sf.close();
                }
            } catch (Exception ex) {
                log.warn("Error closing SessionFactory '{}': {}", name, ex.getMessage());
            }
        });
        dataSources.values().forEach(ds -> {
            if (ds instanceof HikariDataSource h) {
                h.close();
            }
        });
    }
}