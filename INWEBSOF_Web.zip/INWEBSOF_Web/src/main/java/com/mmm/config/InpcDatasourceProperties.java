package com.mmm.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "insba")
public class InpcDatasourceProperties {

    private String appType = "INPC";
    private LocalAuth localAuth = new LocalAuth();

    /** Named JDBC configs: system, as400, cir, csd, infoapps, pos, … */
    private Map<String, DbConfig> datasources = new HashMap<>();

    /** Menu / module key -> datasource name (e.g. INPC→system, CIR→cir, TSD→csd) */
    private Map<String, String> menuDatasources = new HashMap<>();

    public String getAppType() { return appType; }
    public void setAppType(String appType) { this.appType = appType; }
    public LocalAuth getLocalAuth() { return localAuth; }
    public void setLocalAuth(LocalAuth localAuth) { this.localAuth = localAuth; }
    public Map<String, DbConfig> getDatasources() { return datasources; }
    public void setDatasources(Map<String, DbConfig> datasources) { this.datasources = datasources; }
    public Map<String, String> getMenuDatasources() { return menuDatasources; }
    public void setMenuDatasources(Map<String, String> menuDatasources) { this.menuDatasources = menuDatasources; }

    public static class LocalAuth {
        private String password = "";
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    public static class DbConfig {
        private String url;
        private String username;
        private String password;
        private String driverClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        private String dialect = "org.hibernate.dialect.SQLServerDialect";
        /** If true, SessionFactory is built on first use, not at startup. */
        private boolean lazy = false;
        /** Hikari max pool size (0 = use defaults in config classes). */
        private int maxPoolSize = 0;
        /** Hikari min idle (-1 = use defaults). */
        private int minIdle = -1;

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getDriverClassName() { return driverClassName; }
        public void setDriverClassName(String driverClassName) { this.driverClassName = driverClassName; }
        public String getDialect() { return dialect; }
        public void setDialect(String dialect) { this.dialect = dialect; }
        public boolean isLazy() { return lazy; }
        public void setLazy(boolean lazy) { this.lazy = lazy; }
        public int getMaxPoolSize() { return maxPoolSize; }
        public void setMaxPoolSize(int maxPoolSize) { this.maxPoolSize = maxPoolSize; }
        public int getMinIdle() { return minIdle; }
        public void setMinIdle(int minIdle) { this.minIdle = minIdle; }
    }
}