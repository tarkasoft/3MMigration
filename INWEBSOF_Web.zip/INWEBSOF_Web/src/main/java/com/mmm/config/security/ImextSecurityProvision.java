package com.mmm.config.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

/**
 * IMEXT (Microsoft CIAM / B2C_1A_3MA) provision hook.
 * Disabled by default. When enabled later, wire OAuth2 client + session bridge here.
 */
@Component
public class ImextSecurityProvision {

    private static final Logger log = LoggerFactory.getLogger(ImextSecurityProvision.class);

    @Value("${security.imext.enabled:false}")
    private boolean enabled;

    @Value("${security.imext.tenant-domain:mmmciam.onmicrosoft.com}")
    private String tenantDomain;

    @Value("${security.imext.policy:B2C_1A_3MA}")
    private String policy;

    @PostConstruct
    void logProvisionState() {
        if (enabled) {
            log.warn("IMEXT enabled — ensure oauth2 client registration is configured (tenant={}, policy={})",
                    tenantDomain, policy);
        } else {
            log.info("IMEXT provision present but disabled (security.imext.enabled=false). Using local/dev access.");
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String getTenantDomain() {
        return tenantDomain;
    }

    public String getPolicy() {
        return policy;
    }
}