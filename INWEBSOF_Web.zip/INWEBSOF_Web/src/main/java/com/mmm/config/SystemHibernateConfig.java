package com.mmm.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * Industry-standard Spring + Hibernate for the SYSTEM datasource:
 * - one pooled DataSource (HikariCP)
 * - one shared SessionFactory (singleton)
 * - Spring-managed transactions (@Transactional + getCurrentSession())
 *
 * Session is bound to the transaction and closed by Spring — do not close it yourself.
 */
@Configuration
@EnableTransactionManagement
public class SystemHibernateConfig {

    public static final String SYSTEM_DS = "systemDataSource";
    public static final String SYSTEM_SF = "systemSessionFactory";
    public static final String SYSTEM_TX = "systemTransactionManager";

    @Bean(name = SYSTEM_DS)
    @Primary
    public DataSource systemDataSource(InpcDatasourceProperties props) {
        InpcDatasourceProperties.DbConfig cfg = props.getDatasources().get(HibernateFactoryRegistry.SYSTEM);
        if (cfg == null || cfg.getUrl() == null || cfg.getUrl().isBlank()) {
            throw new IllegalStateException("insba.datasources.system is required");
        }
        HikariConfig hc = new HikariConfig();
        hc.setPoolName("inpcv2-system");
        hc.setJdbcUrl(cfg.getUrl());
        hc.setUsername(cfg.getUsername());
        hc.setPassword(cfg.getPassword());
        hc.setDriverClassName(cfg.getDriverClassName());
        // Sized for concurrency, NOT user count. ~1000 users with short requests:
        // typically 20–40 connections for system DB is enough; raise only if wait timeouts appear.
        hc.setMaximumPoolSize(cfg.getMaxPoolSize() > 0 ? cfg.getMaxPoolSize() : 30);
        hc.setMinimumIdle(cfg.getMinIdle() >= 0 ? cfg.getMinIdle() : 5);
        hc.setConnectionTimeout(30_000);
        hc.setIdleTimeout(600_000);
        hc.setMaxLifetime(1_800_000);
        hc.setPoolName("inpcv2-system");
        return new HikariDataSource(hc);
    }

    @Bean(name = SYSTEM_SF)
    @Primary
    public LocalSessionFactoryBean systemSessionFactory(
            @Qualifier(SYSTEM_DS) DataSource dataSource,
            InpcDatasourceProperties props) {
        InpcDatasourceProperties.DbConfig cfg = props.getDatasources().get(HibernateFactoryRegistry.SYSTEM);
        LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
        factoryBean.setDataSource(dataSource);
        factoryBean.setPackagesToScan("com.mmm"); // ready if entities appear later
        Properties hp = new Properties();
        hp.put("hibernate.dialect", cfg.getDialect());
        hp.put("hibernate.show_sql", "false");
        hp.put("hibernate.format_sql", "false");
        hp.put("hibernate.jdbc.batch_size", "50");
        // Critical: bind Session to Spring transaction
        hp.put("hibernate.current_session_context_class", "org.springframework.orm.hibernate5.SpringSessionContext");
        factoryBean.setHibernateProperties(hp);
        return factoryBean;
    }

    @Bean(name = SYSTEM_TX)
    @Primary
    public PlatformTransactionManager systemTransactionManager(
            @Qualifier(SYSTEM_SF) SessionFactory sessionFactory) {
        return new HibernateTransactionManager(sessionFactory);
    }
}