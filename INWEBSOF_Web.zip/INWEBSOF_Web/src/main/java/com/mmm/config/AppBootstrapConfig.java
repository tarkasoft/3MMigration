package com.mmm.config;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({ InpcDatasourceProperties.class, PortalProperties.class })
public class AppBootstrapConfig {

    @Bean
    ApplicationRunner eagerHibernateInit(HibernateFactoryRegistry registry) {
        return args -> registry.initializeEagerFactories();
    }
}