package com.mmm.authentication;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mmm.titpl.NativeQuerySupport;
import com.mmm.config.SystemHibernateConfig;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * System-DB auth/menus using Spring transaction-bound sessions.
 * Session is opened/closed by the transaction manager â€” safe under high concurrency.
 *
 * <p>Common entry once ENL_ID is known: {@link #bootstrapSessionByEnlId(HttpServletRequest, String)}
 * (local login and IMEXT both call this).
 */
@Service
public class AuthService {

    private final SessionFactory sessionFactory;

    @Value("${insba.app-type:INPC}")
    private String defaultAppType;

    public AuthService(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session() {
        // Bound to current @Transactional â€” do NOT close manually
        return sessionFactory.getCurrentSession();
    }

    /**
     * Load active user by ENL_ID including cust_name / cust_code / see_other_cust_data and roles CSV.
     * Returns null if not found / inactive.
     */
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public Map<String, Object> loadUserByEnlId(String enlId) {
        if (enlId == null || enlId.isBlank()) {
            return null;
        }
        enlId = enlId.trim().toUpperCase();
        Map<String, Object> user = findActiveUser(enlId);
        if (user == null) {
            return null;
        }
        user.put("roles", getUserRolesCsv(enlId));
        return user;
    }

    /**
     * Common bootstrap: validate ENL_ID, load profile, store session attributes.
     * Used by local login and by IMEXT after ENL_ID is known.
     *
     * @return user profile map, or null if user not found/inactive
     */
    @Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public Map<String, Object> bootstrapSessionByEnlId(HttpServletRequest request, String enlId) {
        Map<String, Object> user = loadUserByEnlId(enlId);
        if (user == null || user.get("name") == null || String.valueOf(user.get("name")).isBlank()) {
            return null;
        }
        HttpSession httpSession = request.getSession(true);
        UserSessionSupport.store(httpSession, user);
        int[] offset = loadInpcOffset();
        httpSession.setAttribute(UserSessionSupport.INPC_HH, offset[0]);
        httpSession.setAttribute(UserSessionSupport.INPC_MM, offset[1]);
        stampLastLogin(user.get("internal_code"));
        return user;
    }

    /** Successful login only. Menus and /me do not call this. */
    private void stampLastLogin(Object internalCode) {
        if (internalCode == null) {
            return;
        }
        String raw = String.valueOf(internalCode).trim();
        if (raw.isEmpty() || "null".equalsIgnoreCase(raw)) {
            return;
        }
        int id;
        try {
            id = Integer.parseInt(raw);
        } catch (NumberFormatException ex) {
            return;
        }
        String sql = "update dbo.ia_user_master set last_login_date = " + UserSessionSupport.sessionDate()
                + " where internal_code = :id";
        session().createNativeQuery(sql).setParameter("id", id).executeUpdate();
    }

    /** First row of dbo.inpc_configuration. Missing or blank values are 0 and 0. */
    private int[] loadInpcOffset() {
        try {
            List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session(), """
                    select top 1 cast(inpc_hh as varchar(20)) as inpc_hh,
                           cast(inpc_mm as varchar(20)) as inpc_mm
                    from dbo.inpc_configuration
                    order by internal_code
                    """, Map.of(), NativeQuerySupport.stringScalars("inpc_hh", "inpc_mm"));
            if (rows.isEmpty()) {
                return new int[] { 0, 0 };
            }
            return new int[] {
                    UserSessionSupport.number(rows.get(0).get("inpc_hh")),
                    UserSessionSupport.number(rows.get(0).get("inpc_mm"))
            };
        } catch (RuntimeException ex) {
            return new int[] { 0, 0 };
        }
    }

    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public Map<String, Object> findActiveUser(String loginId) {
        String sql = """
                select u.internal_code, u.name, isnull(u.email,'') as email,
                       isnull(u1.enl_id,'0') as supervisor,
                       isnull(u.reporting_head,0) as reporting_head_int_code,
                       isnull(u.theme_json,'') as theme_json,
                       isnull(u.cust_name,'') as cust_name,
                       isnull(u.cust_code,'') as cust_code,
                       isnull(u.see_other_cust_data,'') as see_other_cust_data,
                       isnull(ut.user_type_name, isnull(u.u_user_type,'')) as u_user_type
                from ia_user_master u
                left join ia_user_master u1 on u1.internal_code = u.reporting_head
                left join dbo.ia_user_type ut on ut.internal_code = try_cast(u.u_user_type as int)
                where u.enl_id = :loginId and isnull(u.active,'Yes') = 'Yes'
                """;
        Map<String, Object> params = Map.of("loginId", loginId);
        Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
        scalars.put("internal_code", StandardBasicTypes.STRING);
        scalars.put("name", StandardBasicTypes.STRING);
        scalars.put("email", StandardBasicTypes.STRING);
        scalars.put("supervisor", StandardBasicTypes.STRING);
        scalars.put("reporting_head_int_code", StandardBasicTypes.STRING);
        scalars.put("theme_json", StandardBasicTypes.STRING);
        scalars.put("cust_name", StandardBasicTypes.STRING);
        scalars.put("cust_code", StandardBasicTypes.STRING);
        scalars.put("see_other_cust_data", StandardBasicTypes.STRING);
        scalars.put("u_user_type", StandardBasicTypes.STRING);
        List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(session(), sql, params, scalars);
        if (rows.isEmpty()) {
            return null;
        }
        Map<String, Object> u = rows.get(0);
        u.put("loginId", loginId);
        u.put("loginUserType", normalizeLoginUserType(u.get("u_user_type")));
        return u;
    }

    
    /** Session login type name. Blank -> Customer. Typo Customser Service -> Customer Service. Other names pass through. */
    public static String normalizeLoginUserType(Object raw) {
        String t = raw == null ? "" : String.valueOf(raw).trim();
        if (t.isEmpty() || "null".equalsIgnoreCase(t)) {
            return "Customer";
        }
        if ("Customser Service".equalsIgnoreCase(t)) {
            return "Customer Service";
        }
        return t;
    }

    private static String str(Object value) {
        if (value == null) {
            return "";
        }
        String s = String.valueOf(value).trim();
        return "null".equalsIgnoreCase(s) ? "" : s;
    }

    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String getUserRolesCsv(String loginId) {
        String sql = """
                SELECT isnull(STUFF((
                    SELECT ',' + ir.role_name
                    FROM ia_user_master t1
                    inner join ia_user_master_roles_group u on u.ref_s_ref_data_code = t1.internal_code
                    inner join ia_roles ir on ir.internal_code = u.ref_role_code
                    where t1.enl_id = :loginId
                    FOR XML PATH('')
                ), 1, 1, ''), '0') as user_roles
                """;
        List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(
                session(), sql, Map.of("loginId", loginId),
                NativeQuerySupport.stringScalars("user_roles"));
        if (rows.isEmpty() || rows.get(0).get("user_roles") == null) {
            return "";
        }
        String roles = String.valueOf(rows.get(0).get("user_roles"));
        return "0".equals(roles) ? "" : roles;
    }

    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public List<Map<String, Object>> loadMenus(String loginId, String appType) {
        if (appType == null || appType.isBlank()) {
            appType = defaultAppType;
        }
        String rolesCsv = getUserRolesCsv(loginId);
        boolean isAdmin = containsRole(rolesCsv, "INPC_IT_ADMIN_ROLE");

        StringBuilder sql = new StringBuilder();
        sql.append("""
                select cast(mo.internal_code as varchar(50)) as internal_code,
                       mg.menu_name,
                       mg.menu_type,
                       mg.sequence as sequence,
                       isnull(sg.sub_menu_name,'Others') as sub_menu_name,
                       mo.module_name,
                       isnull(mo.file_name,'') as file_name,
                       mo.display_name,
                       isnull(mo.onclick,'') as onclick,
                       isnull(mo.load_type,'Internal') as load_type,
                       isnull(mg.icons,'') as group_icons,
                       isnull(mg.icons_color,'') as group_icons_color,
                       isnull(mo.icons,'') as icons,
                       isnull(mo.icons_color,'') as icons_color,
                       isnull(mg.direct_file_name,'') as direct_file_name,
                       isnull(mo.js_path,'') as js_path,
                       isnull(mo.mobile_file_name,'') as mobile_file_name
                from ia_menu_groups mg
                inner join ia_menu_options mo on mo.ref_menu_group_code = mg.internal_code
                left join ia_menu_sub_groups sg on sg.internal_code = mo.ref_menu_subgroup_code
                """);
        if (!isAdmin) {
            sql.append("""
                    inner join ia_role_rights rr on rr.ref_menu_code = mo.internal_code
                    inner join ia_user_master_roles_group ur on ur.ref_role_code = rr.ref_role_code
                    inner join ia_user_master um on ur.ref_s_ref_data_code = um.internal_code and um.enl_id = :loginId
                    """);
        }
        sql.append("""
                where mg.app_type = :appType and mg.active = 'Yes' and mo.active = 'Yes'
                order by mg.sequence, isnull(sg.sequence,0), isnull(mo.sequence,0)
                """);

        Map<String, Object> params = new LinkedHashMap<>();
        params.put("appType", appType);
        if (!isAdmin) {
            params.put("loginId", loginId);
        }

        Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
        scalars.put("internal_code", StandardBasicTypes.STRING);
        scalars.put("menu_name", StandardBasicTypes.STRING);
        scalars.put("menu_type", StandardBasicTypes.STRING);
        scalars.put("sequence", StandardBasicTypes.DOUBLE);
        scalars.put("sub_menu_name", StandardBasicTypes.STRING);
        scalars.put("module_name", StandardBasicTypes.STRING);
        scalars.put("file_name", StandardBasicTypes.STRING);
        scalars.put("display_name", StandardBasicTypes.STRING);
        scalars.put("onclick", StandardBasicTypes.STRING);
        scalars.put("load_type", StandardBasicTypes.STRING);
        scalars.put("group_icons", StandardBasicTypes.STRING);
        scalars.put("group_icons_color", StandardBasicTypes.STRING);
        scalars.put("icons", StandardBasicTypes.STRING);
        scalars.put("icons_color", StandardBasicTypes.STRING);
        scalars.put("direct_file_name", StandardBasicTypes.STRING);
        scalars.put("js_path", StandardBasicTypes.STRING);
        scalars.put("mobile_file_name", StandardBasicTypes.STRING);

        List<Map<String, Object>> menus = NativeQuerySupport.listAsMaps(session(), sql.toString(), params, scalars);

        // Direct menu groups (like Home): no options required - load direct_file_name into content pane
        String directSql = """
                select cast(mg.internal_code as varchar(50)) as internal_code,
                       mg.menu_name,
                       mg.menu_type,
                       mg.sequence as sequence,
                       'Others' as sub_menu_name,
                       mg.menu_name as module_name,
                       isnull(mg.direct_file_name,'') as file_name,
                       mg.menu_name as display_name,
                       '' as onclick,
                       'Internal' as load_type,
                       isnull(mg.icons,'') as group_icons,
                       isnull(mg.icons_color,'') as group_icons_color,
                       isnull(mg.icons,'') as icons,
                       isnull(mg.icons_color,'') as icons_color,
                       isnull(mg.direct_file_name,'') as direct_file_name,
                       '' as js_path,
                       '' as mobile_file_name
                from ia_menu_groups mg
                where mg.app_type = :appType
                  and mg.active = 'Yes'
                  and lower(isnull(mg.menu_type,'')) = 'direct'
                  and isnull(mg.direct_file_name,'') <> ''
                order by mg.sequence
                """;
        Map<String, Object> directParams = Map.of("appType", appType);
        Map<String, org.hibernate.type.BasicTypeReference<?>> directScalars = new LinkedHashMap<>();
        directScalars.put("internal_code", StandardBasicTypes.STRING);
        directScalars.put("menu_name", StandardBasicTypes.STRING);
        directScalars.put("menu_type", StandardBasicTypes.STRING);
        directScalars.put("sequence", StandardBasicTypes.DOUBLE);
        directScalars.put("sub_menu_name", StandardBasicTypes.STRING);
        directScalars.put("module_name", StandardBasicTypes.STRING);
        directScalars.put("file_name", StandardBasicTypes.STRING);
        directScalars.put("display_name", StandardBasicTypes.STRING);
        directScalars.put("onclick", StandardBasicTypes.STRING);
        directScalars.put("load_type", StandardBasicTypes.STRING);
        directScalars.put("group_icons", StandardBasicTypes.STRING);
        directScalars.put("group_icons_color", StandardBasicTypes.STRING);
        directScalars.put("icons", StandardBasicTypes.STRING);
        directScalars.put("icons_color", StandardBasicTypes.STRING);
        directScalars.put("direct_file_name", StandardBasicTypes.STRING);
        directScalars.put("js_path", StandardBasicTypes.STRING);
        directScalars.put("mobile_file_name", StandardBasicTypes.STRING);
        List<Map<String, Object>> directMenus =
                NativeQuerySupport.listAsMaps(session(), directSql, directParams, directScalars);
        if (directMenus != null && !directMenus.isEmpty()) {
            menus.addAll(directMenus);
        }
        return menus;
    }

    private static boolean containsRole(String rolesCsv, String role) {
        if (rolesCsv == null || rolesCsv.isBlank()) {
            return false;
        }
        for (String r : rolesCsv.split(",")) {
            if (role.equalsIgnoreCase(r.trim())) {
                return true;
            }
        }
        return false;
    }

    public String getDefaultAppType() {
        return defaultAppType;
    }

    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String getThemeJson(String loginId) {
        String sql = """
                select isnull(u.theme_json,'') as theme_json
                from ia_user_master u
                where u.enl_id = :loginId
                """;
        List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(
                session(), sql, Map.of("loginId", loginId),
                NativeQuerySupport.stringScalars("theme_json"));
        if (rows.isEmpty() || rows.get(0).get("theme_json") == null) {
            return "";
        }
        return String.valueOf(rows.get(0).get("theme_json"));
    }

    @Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public int saveThemeJson(String loginId, String themeJson) {
        if (loginId == null || loginId.isBlank()) {
            return 0;
        }
        String sql = """
                update ia_user_master
                   set theme_json = :themeJson
                 where enl_id = :loginId
                """;
        @SuppressWarnings("rawtypes")
        org.hibernate.query.NativeQuery q = session().createNativeQuery(sql);
        q.setParameter("themeJson", themeJson == null ? "" : themeJson);
        q.setParameter("loginId", loginId);
        return q.executeUpdate();
    }

    /**
     * Customer autocomplete for Change Customer Code UI.
     * Only the typed term is required from the client (matched against code and name).
     */
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public List<Map<String, Object>> searchCustomersByTerm(String term) {
        String q = term == null ? "" : term.trim();
        if (q.isEmpty()) {
            return List.of();
        }
        String like = "%" + q + "%";
        String sql = """
                select top 50
                       cast(internal_code as varchar(50)) as internal_code,
                       isnull(code,'') as code,
                       isnull(name,'') as name,
                       (isnull(code,'') + ' - ' + isnull(name,'')) as value
                from sb_customer_master
                where isnull(code,'') like :like
                   or isnull(name,'') like :like
                order by code
                """;
        Map<String, Object> params = Map.of("like", like);
        Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
        scalars.put("internal_code", StandardBasicTypes.STRING);
        scalars.put("code", StandardBasicTypes.STRING);
        scalars.put("name", StandardBasicTypes.STRING);
        scalars.put("value", StandardBasicTypes.STRING);
        return NativeQuerySupport.listAsMaps(session(), sql, params, scalars);
    }
}