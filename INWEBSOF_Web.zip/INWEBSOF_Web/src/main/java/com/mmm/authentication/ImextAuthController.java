package com.mmm.authentication;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Explicit IMEXT entry / response URLs for the portal.
 *
 * <p>On success → {@code MainPage.html}. On error → plain-text error only
 * (never {@code login.html}; that page is for local/dev login).
 */
@RestController
@RequestMapping("/api/auth/imext")
public class ImextAuthController {

    private final Gson gson = new Gson();

    @Value("${security.imext.enabled:false}")
    private boolean imextEnabled;

    /**
     * Start IMEXT login. Browser URL:
     * {@code http://localhost:8090/INPCV2/api/auth/imext/start}
     */
    @GetMapping("/start")
    public void start(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (!imextEnabled) {
            ImextErrorResponses.write(response, HttpServletResponse.SC_SERVICE_UNAVAILABLE,
                    "imext_disabled", "security.imext.enabled=false");
            return;
        }
        response.sendRedirect(request.getContextPath() + "/oauth2/authorization/iamext");
    }

    /**
     * After OAuth success handler bootstraps the session, confirm and go to MainPage.
     * Errors are shown as plain text — no redirect to login.html.
     */
    @GetMapping("/response")
    public void response(HttpServletRequest request, HttpServletResponse response,
                         @RequestParam(value = "error", required = false) String error)
            throws IOException {
        if (error != null && !error.isBlank()) {
            ImextErrorResponses.write(response, HttpServletResponse.SC_UNAUTHORIZED, error,
                    "IMEXT/OAuth step failed. See server logs for detail.");
            return;
        }
        HttpSession session = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(session)) {
            ImextErrorResponses.write(response, HttpServletResponse.SC_UNAUTHORIZED,
                    "imext_session_missing",
                    "No portal session after IMEXT. Bootstrap may have failed or cookie was dropped.");
            return;
        }
        response.sendRedirect(request.getContextPath() + "/MainPage.html");
    }

    /** JSON smoke: {@code GET /api/auth/imext/status} */
    @GetMapping("/status")
    public String status(HttpServletRequest request) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("imextEnabled", imextEnabled);
        data.put("startUrl", request.getContextPath() + "/api/auth/imext/start");
        data.put("oauthAuthorizeUrl", request.getContextPath() + "/oauth2/authorization/iamext");
        data.put("oauthCallbackPath", request.getContextPath() + "/login/oauth2/code/iamext");
        data.put("responseUrl", request.getContextPath() + "/api/auth/imext/response");
        HttpSession session = request.getSession(false);
        data.put("loggedIn", UserSessionSupport.isLoggedIn(session));
        if (UserSessionSupport.isLoggedIn(session)) {
            data.put("loginId", session.getAttribute(UserSessionSupport.LOGIN_ID));
        }
        result.SetSuccess("success", data);
        return gson.toJson(result);
    }
}
