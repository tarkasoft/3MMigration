package com.mmm.authentication;

import java.io.IOException;

import jakarta.servlet.http.HttpServletResponse;

/**
 * IMEXT errors are shown as plain text for troubleshooting.
 * Do not redirect to {@code login.html} (that page is for local/dev login only).
 */
public final class ImextErrorResponses {

    private ImextErrorResponses() {
    }

    public static void write(HttpServletResponse response, int httpStatus, String code, String detail)
            throws IOException {
        response.resetBuffer();
        response.setStatus(httpStatus);
        response.setContentType("text/plain;charset=UTF-8");
        response.setHeader("Cache-Control", "no-store");
        StringBuilder body = new StringBuilder();
        body.append("IMEXT error: ").append(code == null ? "unknown" : code);
        if (detail != null && !detail.isBlank()) {
            body.append('\n').append(detail.trim());
        }
        response.getWriter().write(body.toString());
        response.getWriter().flush();
    }
}
