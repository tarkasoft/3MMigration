/**
 * User authentication for INPCV2.
 *
 * <p>Local login ({@code login.html}) and Microsoft IMEXT both resolve an ENL_ID,
 * then call {@link com.mmm.authentication.AuthService#bootstrapSessionByEnlId} so session
 * population stays in one place.
 *
 * <p>IMEXT URLs (when {@code security.imext.enabled=true}):
 * <ul>
 *   <li>{@code GET /api/auth/imext/start} — start B2C login</li>
 *   <li>{@code /oauth2/authorization/iamext} — Spring OAuth2 redirect to B2C</li>
 *   <li>{@code /login/oauth2/code/iamext} — Azure redirect (Spring exchanges code)</li>
 *   <li>{@code GET /api/auth/imext/response} — app handles success/error, then MainPage</li>
 *   <li>{@code POST /api/auth/bootstrap-by-enl-id} — optional/manual bootstrap API</li>
 * </ul>
 */
package com.mmm.authentication;
