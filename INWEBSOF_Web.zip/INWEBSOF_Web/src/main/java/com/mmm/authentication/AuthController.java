package com.mmm.authentication;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.PortalProperties;
import com.mmm.portal_common.WelcomeAck;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Thin auth API. Core logic lives in {@link AuthService}.
 * Paths unchanged: {@code /api/auth/*}.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final PortalProperties portalProperties;
    private final WelcomeAck welcomeAck;
    private final Gson gson = new Gson();

    /** Optional local password gate; blank = any password if user exists (dev). */
    @Value("${insba.local-auth.password:}")
    private String localPassword;

    public AuthController(AuthService authService, PortalProperties portalProperties, WelcomeAck welcomeAck) {
        this.authService = authService;
        this.portalProperties = portalProperties;
        this.welcomeAck = welcomeAck;
    }

    /**
     * Local/dev login: validate ENL_ID (+ optional password), establish session via common bootstrap.
     * Response stays lean (success/fail + redirect) — user details come from /menus or /me.
     */
    @PostMapping("/login")
    public String login(HttpServletRequest request,
                        @RequestParam("loginId") String loginId,
                        @RequestParam(value = "password", required = false, defaultValue = "") String password) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        if (loginId == null || loginId.isBlank()) {
            result.SetError(-1, "failure", "Login id is required");
            return gson.toJson(result);
        }

        if (localPassword != null && !localPassword.isBlank() && !localPassword.equals(password)) {
            result.SetError(-1, "failure", "Invalid password");
            return gson.toJson(result);
        }

        Map<String, Object> user;
        try {
            user = authService.bootstrapSessionByEnlId(request, loginId);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "User lookup failed: " + ex.getMessage());
            return gson.toJson(result);
        }

        if (user == null) {
            result.SetError(-1, "failure", "User not found or inactive");
            return gson.toJson(result);
        }

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("loginId", user.get("loginId"));
        data.put("redirect", "MainPage.html");
        // Theme still optional here so login.html / theme-db can warm sessionStorage without blocking
        data.put("theme_json", user.get("theme_json") == null ? "" : String.valueOf(user.get("theme_json")));
        result.SetSuccess("success", data);
        return gson.toJson(result);
    }

    /**
     * IMEXT extension point: after Microsoft IMEXT/B2C succeeds and ENL_ID is known,
     * call this (or {@link AuthService#bootstrapSessionByEnlId}) to establish the same session as local login.
     */
    @PostMapping("/bootstrap-by-enl-id")
    public String bootstrapByEnlId(HttpServletRequest request,
                                   @RequestParam("enlId") String enlId) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        if (enlId == null || enlId.isBlank()) {
            result.SetError(-1, "failure", "enlId is required");
            return gson.toJson(result);
        }
        Map<String, Object> user;
        try {
            user = authService.bootstrapSessionByEnlId(request, enlId);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Bootstrap failed: " + ex.getMessage());
            return gson.toJson(result);
        }
        if (user == null) {
            result.SetError(-1, "failure", "User not found or inactive");
            return gson.toJson(result);
        }
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("loginId", user.get("loginId"));
        data.put("redirect", "MainPage.html");
        result.SetSuccess("success", data);
        return gson.toJson(result);
    }

    @PostMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        ResponseDataGeneric result = new ResponseDataGeneric();
        result.SetSuccess("success", "logged out");
        return gson.toJson(result);
    }

    @GetMapping("/me")
    public String me(HttpServletRequest request) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession session = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(session)) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }
        Map<String, Object> data = UserSessionSupport.toClientUserMap(session);
        putWelcomeMessage(data, session);
        try {
            data.put("theme_json", authService.getThemeJson(String.valueOf(session.getAttribute(UserSessionSupport.LOGIN_ID))));
        } catch (Exception ignore) {
            data.put("theme_json", "");
        }
        result.SetSuccess("success", data);
        return gson.toJson(result);
    }

    /**
     * Load menus for the logged-in user and return user details (incl. cust_name / cust_code)
     * so the client can store them in cookies.
     */
    @GetMapping("/menus")
    public String menus(HttpServletRequest request,
                        @RequestParam(value = "app_type", required = false) String appType) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession session = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(session)) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }
        String loginId = UserSessionSupport.requireLoginId(session);
        try {
            List<Map<String, Object>> menus = authService.loadMenus(loginId, appType);
            Map<String, Object> data = UserSessionSupport.toClientUserMap(session);
            data.put("appType", appType == null || appType.isBlank() ? authService.getDefaultAppType() : appType);
            data.put("customerName", portalProperties.getCustomerName());
            data.put("portal", portalProperties.toClientMap());
            data.put("menus", menus);
            putWelcomeMessage(data, session);
            try {
                data.put("theme_json", authService.getThemeJson(loginId));
            } catch (Exception ignore) {
                data.put("theme_json", "");
            }
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Menu load failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    /** welcome_msg is the modal HTML. An acknowledged message is omitted unless the module shows it again. */
    private void putWelcomeMessage(Map<String, Object> data, HttpSession session) {
        Map<String, String> welcome = welcomeAck.welcomeFor(session);
        String html = welcome.getOrDefault("welcome_msg", "");
        data.put("welcome_title", welcome.getOrDefault("welcome_title", ""));
        data.put("welcome_msg", html);
        data.put("welcome_internal_code", welcome.getOrDefault("welcome_internal_code", ""));
        data.put("ack_required", welcome.getOrDefault("ack_required", "No"));
        data.put("ack_message", welcome.getOrDefault("ack_message", ""));
        data.put("show_ack_prompt_even_acknowledged",
                welcome.getOrDefault("show_ack_prompt_even_acknowledged", "No"));
        data.put("already_acknowledged", welcome.getOrDefault("already_acknowledged", "No"));
        data.put("acknowledged_on", welcome.getOrDefault("acknowledged_on", ""));
        data.put("show_welcome", html.isBlank() ? "No" : "Yes");
    }

    /**
     * Change Customer Code autocomplete — client sends only {@code value} (typed term).
     */
    @GetMapping("/customers/autocomplete")
    public String customersAutocomplete(HttpServletRequest request,
                                        @RequestParam("value") String value) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession session = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(session)) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }
        try {
            List<Map<String, Object>> rows = authService.searchCustomersByTerm(value);
            result.SetSuccess("success", rows);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Customer search failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }
}