package com.mmm.authentication;

import java.io.IOException;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.google.gson.Gson;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Global session gate for {@code /api/**} when {@code security.session-check.enabled=true}.
 * Unauthenticated calls get ResponseDataGeneric JSON (HTTP 200) and never reach the controller.
 * Public auth entry points and smoke/info paths are excluded in {@link com.mmm.config.WebMvcConfig}.
 */
@Component
public class SessionLoginInterceptor implements HandlerInterceptor {

    private final Gson gson = new Gson();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        HttpSession session = request.getSession(false);
        if (UserSessionSupport.isLoggedIn(session)) {
            return true;
        }
        writeLoginRequired(response);
        return false;
    }

    private void writeLoginRequired(HttpServletResponse response) throws IOException {
        ResponseDataGeneric result = new ResponseDataGeneric();
        result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                UserSessionSupport.SESSION_EXPIRED_MESSAGE);
        response.setStatus(HttpServletResponse.SC_OK);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(gson.toJson(result));
    }
}