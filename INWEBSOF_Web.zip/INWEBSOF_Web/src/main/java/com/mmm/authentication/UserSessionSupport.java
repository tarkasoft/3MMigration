package com.mmm.authentication;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpSession;

/**
 * HTTP session keys and helpers for authenticated user context.
 * Login and IMEXT both store the same attributes after ENL_ID is known.
 */
public final class UserSessionSupport {

    public static final String LOGIN_ID = "loginId";
    public static final String USER_ID = "userId";
    public static final String LOGIN_USER_NAME = "loginUserName";
    public static final String LOGIN_USER_TYPE = "loginUserType";
    public static final String LOGIN_USER_INT_CODE = "login_user_int_code";
    public static final String SUPERVISOR = "supervisor";
    public static final String REPORTING_HEAD_INT_CODE = "reporting_head_int_code";
    public static final String LOGIN_USER_EMAIL = "loginUserEmail";
    public static final String LOGIN_USER_ROLES = "login_user_roles";
    public static final String CUST_NAME = "cust_name";
    public static final String CUST_CODE = "cust_code";
    public static final String SEE_OTHER_CUST_DATA = "see_other_cust_data";
    public static final String INPC_HH = "inpc_hh";
    public static final String INPC_MM = "inpc_mm";

    /** Session expired / not logged in — client MainPage handles this as redirect or IMEXT reload. */
    public static final int SESSION_EXPIRED_ERROR_CODE = -9;
    public static final String SESSION_EXPIRED_MESSAGE = "Please login once again";

    private UserSessionSupport() {}

    /**
     * Store identity + roles + customer fields needed by the rest of the app.
     *
     * @param userProfile map from {@link AuthService#loadUserByEnlId(String)} (must include roles)
     */
    public static void store(HttpSession session, Map<String, Object> userProfile) {
        if (session == null || userProfile == null) {
            return;
        }
        String enlId = str(userProfile.get("loginId"));
        session.setAttribute(LOGIN_ID, enlId);
        session.setAttribute(USER_ID, enlId);
        session.setAttribute(LOGIN_USER_NAME, userProfile.get("name"));
        session.setAttribute(LOGIN_USER_TYPE, userProfile.getOrDefault("loginUserType", "Customer"));
        session.setAttribute(LOGIN_USER_INT_CODE, userProfile.get("internal_code"));
        session.setAttribute(SUPERVISOR, userProfile.get("supervisor"));
        session.setAttribute(REPORTING_HEAD_INT_CODE, userProfile.get("reporting_head_int_code"));
        session.setAttribute(LOGIN_USER_EMAIL, userProfile.get("email"));
        session.setAttribute(LOGIN_USER_ROLES, userProfile.getOrDefault("roles", ""));
        session.setAttribute(CUST_NAME, nullToEmpty(userProfile.get("cust_name")));
        session.setAttribute(CUST_CODE, nullToEmpty(userProfile.get("cust_code")));
        session.setAttribute(SEE_OTHER_CUST_DATA, nullToEmpty(userProfile.get("see_other_cust_data")));
    }

    public static boolean isLoggedIn(HttpSession session) {
        return session != null && session.getAttribute(LOGIN_ID) != null;
    }

    /** Hours from the login session. Blank or missing is 0. */
    public static int inpcHours(HttpSession session) {
        return number(session == null ? null : session.getAttribute(INPC_HH));
    }

    /** Minutes from the login session. Blank or missing is 0. */
    public static int inpcMinutes(HttpSession session) {
        return number(session == null ? null : session.getAttribute(INPC_MM));
    }

    /**
     * {@code dateadd(MINUTE, inpc_mm, dateadd(HOUR, inpc_hh, getdate()))}
     * using the hours and minutes stored on the login session.
     */
    public static String sessionDate(HttpSession session) {
        return "dateadd(MINUTE, " + inpcMinutes(session)
                + ", dateadd(HOUR, " + inpcHours(session) + ", getdate()))";
    }

    /** Same expression from the current request's session. No request means 0 and 0. */
    public static String sessionDate() {
        return sessionDate(currentSession());
    }

    public static HttpSession currentSession() {
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        if (!(attributes instanceof ServletRequestAttributes servlet)) {
            return null;
        }
        return servlet.getRequest().getSession(false);
    }

    public static int number(Object value) {
        if (value == null) {
            return 0;
        }
        String text = String.valueOf(value).trim();
        if (text.isEmpty() || "null".equalsIgnoreCase(text)) {
            return 0;
        }
        try {
            return Integer.parseInt(text.split("\\.")[0]);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    public static String requireLoginId(HttpSession session) {
        if (!isLoggedIn(session)) {
            return null;
        }
        return String.valueOf(session.getAttribute(LOGIN_ID));
    }

    public static boolean canChangeCustomer(HttpSession session) {
        if (!isLoggedIn(session)) {
            return false;
        }
        return "yes".equalsIgnoreCase(str(session.getAttribute(SEE_OTHER_CUST_DATA)).trim());
    }

    /**
     * Procedure context is overridden only when the authenticated session has
     * permission and the client supplies both selected-customer values.
     * Otherwise both values come from the authenticated session.
     */
    public static ProcedureCustomerContext resolveProcedureCustomerContext(
            HttpSession session, String requestedCustCode, String requestedLoginId) {
        String sessionCustCode = str(session == null ? null : session.getAttribute(CUST_CODE)).trim();
        String sessionLoginId = str(session == null ? null : session.getAttribute(LOGIN_ID)).trim();
        String overrideCustCode = str(requestedCustCode).trim();
        String overrideLoginId = str(requestedLoginId).trim();
        if (canChangeCustomer(session)
                && !overrideCustCode.isEmpty()
                && !overrideLoginId.isEmpty()) {
            return new ProcedureCustomerContext(overrideCustCode, overrideLoginId, true);
        }
        return new ProcedureCustomerContext(sessionCustCode, sessionLoginId, false);
    }

    public record ProcedureCustomerContext(String custCode, String loginId, boolean overridden) {}

    /** User fields for menus / me JSON (client may cookie cust_*). */
    public static Map<String, Object> toClientUserMap(HttpSession session) {
        Map<String, Object> data = new LinkedHashMap<>();
        if (session == null) {
            return data;
        }
        data.put("loginId", session.getAttribute(LOGIN_ID));
        data.put("loginUserName", session.getAttribute(LOGIN_USER_NAME));
        data.put("loginUserType", session.getAttribute(LOGIN_USER_TYPE));
        data.put("login_user_int_code", session.getAttribute(LOGIN_USER_INT_CODE));
        data.put("roles", session.getAttribute(LOGIN_USER_ROLES));
        data.put("cust_name", nullToEmpty(session.getAttribute(CUST_NAME)));
        data.put("cust_code", nullToEmpty(session.getAttribute(CUST_CODE)));
        data.put("see_other_cust_data", nullToEmpty(session.getAttribute(SEE_OTHER_CUST_DATA)));
        return data;
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static String nullToEmpty(Object o) {
        if (o == null) {
            return "";
        }
        String s = String.valueOf(o);
        return "null".equalsIgnoreCase(s) ? "" : s;
    }
}
