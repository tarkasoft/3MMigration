package com.mmm.web;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Replaces the Whitelabel error page. Browsers get a short HTML card.
 * Clients that ask for JSON still get a small JSON body.
 */
@Controller
public class HtmlErrorController implements ErrorController {

	@RequestMapping(value = "${server.error.path:/error}", produces = MediaType.TEXT_HTML_VALUE)
	@ResponseBody
	public String html(HttpServletRequest request) {
		int status = status(request);
		String detail = detail(request);
		String title = title(status);
		String home = request.getContextPath() + "/MainPage.html";
		return """
				<!DOCTYPE html>
				<html lang="en">
				<head>
				<meta charset="utf-8"/>
				<meta name="viewport" content="width=device-width, initial-scale=1"/>
				<title>%d · %s</title>
				<style>
				  body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center;
				    background:#f8fafc; color:#0f172a; font-family:Inter, system-ui, Segoe UI, sans-serif; }
				  .card { width:min(32rem, calc(100%% - 2rem)); background:#fff; border:1px solid #e2e8f0;
				    border-radius:0.75rem; box-shadow:0 10px 30px rgba(15,23,42,.06); padding:1.75rem 1.5rem; }
				  .code { display:inline-block; font-size:.75rem; font-weight:650; letter-spacing:.04em;
				    color:#1d4ed8; background:#dbeafe; border-radius:999px; padding:.2rem .55rem; }
				  h1 { margin:.75rem 0 .4rem; font-size:1.25rem; }
				  p { margin:0; color:#475569; line-height:1.5; }
				  a { display:inline-block; margin-top:1.25rem; background:#2563eb; color:#fff; text-decoration:none;
				    border-radius:.5rem; padding:.45rem .9rem; font-size:.9rem; }
				</style>
				</head>
				<body>
				  <div class="card">
				    <span class="code">%d</span>
				    <h1>%s</h1>
				    <p>%s</p>
				    <a href="%s">Back to home</a>
				  </div>
				</body>
				</html>
				""".formatted(status, esc(title), status, esc(title), esc(detail), esc(home));
	}

	@RequestMapping(value = "${server.error.path:/error}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Map<String, Object> json(HttpServletRequest request) {
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("status", status(request));
		body.put("message", detail(request));
		return body;
	}

	private static int status(HttpServletRequest request) {
		Object raw = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
		if (raw instanceof Integer n) {
			return n;
		}
		try {
			return raw == null ? 500 : Integer.parseInt(String.valueOf(raw));
		} catch (NumberFormatException ex) {
			return 500;
		}
	}

	private static String title(int status) {
		if (status == 400) {
			return "This request could not be completed";
		}
		if (status == 401 || status == 403) {
			return "You do not have access to this page";
		}
		if (status == 404) {
			return "This page was not found";
		}
		return "Something went wrong";
	}

	private static String detail(HttpServletRequest request) {
		String message = text(request.getAttribute(RequestDispatcher.ERROR_MESSAGE));
		if (message.isEmpty()) {
			Object ex = request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
			if (ex instanceof Throwable t && t.getMessage() != null) {
				message = t.getMessage();
			}
		}
		int nl = message.indexOf('\n');
		if (nl >= 0) {
			message = message.substring(0, nl).trim();
		}
		if (message.length() > 280) {
			message = message.substring(0, 280).trim();
		}
		if (message.isEmpty()) {
			return "Please go back and try again.";
		}
		return message;
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static String esc(String value) {
		if (value == null) {
			return "";
		}
		return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
	}
}
