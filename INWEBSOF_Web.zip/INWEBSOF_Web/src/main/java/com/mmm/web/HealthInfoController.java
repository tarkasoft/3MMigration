package com.mmm.web;

import java.util.LinkedHashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.config.security.ImextSecurityProvision;
import com.mmm.titpl.ResponseDataGeneric;

@RestController
@RequestMapping("/api")
public class HealthInfoController {

    private final SessionFactory systemSessionFactory;
    private final HibernateFactoryRegistry registry;
    private final ImextSecurityProvision imext;
    private final Gson gson = new Gson();

    public HealthInfoController(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory systemSessionFactory,
                                HibernateFactoryRegistry registry,
                                ImextSecurityProvision imext) {
        this.systemSessionFactory = systemSessionFactory;
        this.registry = registry;
        this.imext = imext;
    }

    @GetMapping("/info")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String info() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("app", "INWEBSOF_Web");
        data.put("imextEnabled", imext.isEnabled());
        data.put("imextPolicy", imext.getPolicy());
        data.put("menuDatasources", registry.menuDatasourceMap());

        boolean systemOk = false;
        String systemError = null;
        try {
            Session session = systemSessionFactory.getCurrentSession();
            Number one = session.createNativeQuery("SELECT 1", Integer.class).uniqueResult();
            systemOk = one != null && one.intValue() == 1;
        } catch (Exception ex) {
            systemError = ex.getMessage();
        }
        data.put("systemDbOk", systemOk);
        if (systemError != null) {
            data.put("systemDbError", systemError);
        }

        ResponseDataGeneric result = new ResponseDataGeneric();
        result.SetSuccess(systemOk ? "success" : "degraded", data);
        return gson.toJson(result);
    }
}