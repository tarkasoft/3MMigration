package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.AreaBreakType;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.VerticalAlignment;

/**
 * PPF warranty certificate (legacy {@code DownloadEWPDF_PPF}).
 * Assets: {@code classpath:ewarranty/images/}.
 */
final class EwWarrantyPdfPpf {
	private static final Logger logger = LoggerFactory.getLogger(EwWarrantyPdfPpf.class);
	private static final String IMG = "ewarranty/images/";
	private static final DeviceRgb TH = new DeviceRgb(151, 156, 152);
	private static final float NOTE_SIZE = 7f;

	record PdfResult(byte[] bytes, String fileName) {
	}

	PdfResult build(Map<String, Object> header, List<Map<String, Object>> vinyl,
			List<byte[]> photos, Map<String, Object> signatory, byte[] signBytes,
			String approvedDate) throws Exception {
		if (vinyl == null || vinyl.isEmpty()) {
			throw new IllegalArgumentException("PPF product lines were not found for this request.");
		}
		String product = text(vinyl.get(0).get("vinyl"));
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = new PdfWriter(out);
		PdfDocument pdf = new PdfDocument(writer);
		pdf.setDefaultPageSize(PageSize.A4);
		Document doc = new Document(pdf, PageSize.A4);
		doc.setMargins(48, 28, 28, 28);
		PdfFont regular = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);
		PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
		doc.setFont(regular);

		addBleed(doc, pdf, coverImage(product));
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		drawContentHeader(pdf, pdf.getLastPage());
		addDetailsPage(doc, header, product, vinyl, photos, signatory, signBytes, approvedDate, bold, regular);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		addBleed(doc, pdf, termsImage(product, true));
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		addBleed(doc, pdf, termsImage(product, false));

		doc.close();
		String reqId = text(header.get("req_id")).replaceAll("[^A-Za-z0-9_-]", "_");
		String name = "PPF_warranty_certificate"
				+ (reqId.isEmpty() ? "" : "_" + reqId) + ".pdf";
		logger.info("EW PPF PDF built {} ({} bytes) signatory={} approved={}",
				name, out.size(), text(signatory == null ? "" : signatory.get("name")), approvedDate);
		return new PdfResult(out.toByteArray(), name);
	}

	private void addDetailsPage(Document doc, Map<String, Object> h, String product,
			List<Map<String, Object>> vinyl, List<byte[]> photos, Map<String, Object> signatory,
			byte[] signBytes, String approvedDate, PdfFont bold, PdfFont regular) {
		doc.add(new Paragraph("Type of Warranty").setFont(bold).setFontSize(16)
				.setFontColor(ColorConstants.WHITE).setMarginBottom(8));
		Table meta = new Table(UnitValue.createPercentArray(new float[] { 16, 18, 16, 16, 18, 16 }))
				.setWidth(UnitValue.createPercentValue(100));
		meta.addCell(plain("Serial No.:", regular, 8));
		meta.addCell(underlined(text(h.get("req_id")), regular));
		meta.addCell(plain("Date Of Issue:", regular, 8));
		meta.addCell(underlined(text(h.get("req_date")), regular));
		meta.addCell(plain("Date Of Installation:", regular, 8));
		meta.addCell(underlined(text(h.get("date_of_inst")), regular));
		doc.add(meta.setMarginBottom(10));

		Table parties = new Table(UnitValue.createPercentArray(new float[] { 50, 50 }))
				.setWidth(UnitValue.createPercentValue(100));
		parties.addCell(partyBox("Issued to", new String[][] {
				{ "Customer Name :", text(h.get("customer")) },
				{ "Customer Address1 :", text(h.get("ppf_cust_address_1")) },
				{ "Customer Address2 :", text(h.get("ppf_cust_address_2")) },
				{ "Customer City:", text(h.get("ppf_cust_city")) },
				{ "Customer Postal:", text(h.get("ppf_cust_pin")) },
				{ "Customer State :", text(h.get("ppf_cust_state")) }
		}, bold, regular));
		parties.addCell(partyBox("Store Details", new String[][] {
				{ "Customer :", text(h.get("applicator")) },
				{ "Contact Name:", text(h.get("app_contact_name")) },
				{ "Address1 :", text(h.get("app_address1")) },
				{ "Address2:", text(h.get("app_address2")) },
				{ "City:", text(h.get("app_city")) },
				{ "State :", text(h.get("app_state")) }
		}, bold, regular));
		doc.add(parties.setMarginBottom(12));
		doc.add(note(regular));

		boolean vehicle = "Vehicle".equalsIgnoreCase(text(h.get("inst_type")));
		doc.add(new Paragraph(vehicle ? "Vehicle Information" : "Installation Information")
				.setFont(bold).setFontSize(13).setTextAlignment(TextAlignment.CENTER)
				.setMarginTop(8).setMarginBottom(6));
		doc.add(infoTable(h, vehicle, bold, regular));

		doc.add(new Paragraph("Product Information")
				.setFont(bold).setFontSize(13).setTextAlignment(TextAlignment.CENTER)
				.setMarginTop(12).setMarginBottom(6));
		doc.add(productTable(vinyl, bold, regular));
		doc.add(note(regular).setMarginTop(10));
		addPhotosPage(doc, photos, signatory == null ? Map.of() : signatory, signBytes,
				approvedDate, bold, regular);
	}

	private void addPhotosPage(Document doc, List<byte[]> photos, Map<String, Object> signatory,
			byte[] signBytes, String approvedDate, PdfFont bold, PdfFont regular) {
		doc.add(new Paragraph("Application Photographs").setFont(bold).setFontSize(14)
				.setFontColor(ColorConstants.BLACK)
				.setTextAlignment(TextAlignment.CENTER)
				.setMarginTop(14).setMarginBottom(8));
		int shown = 0;
		if (photos != null) {
			for (byte[] bytes : photos) {
				if (bytes == null || bytes.length == 0) {
					continue;
				}
				try {
					Image img = new Image(ImageDataFactory.create(bytes));
					img.scaleToFit(480, 320);
					img.setMarginBottom(8);
					doc.add(img);
					shown++;
				} catch (Exception ex) {
					logger.warn("EW PPF photo skipped: {}", ex.getMessage());
				}
			}
		}
		if (shown == 0) {
			doc.add(new Paragraph("No application photographs were found for this request.")
					.setFont(regular).setFontSize(9).setMarginBottom(8));
		}
		doc.add(new Paragraph(" ").setMarginTop(16));
		Table sign = new Table(UnitValue.createPercentArray(
				new float[] { 22, 4, 22, 4, 22, 4, 22 }))
				.setWidth(UnitValue.createPercentValue(100));
		sign.setBorder(com.itextpdf.layout.borders.Border.NO_BORDER);
		if (signBytes != null && signBytes.length > 0) {
			try {
				Image sig = new Image(ImageDataFactory.create(signBytes));
				sig.scaleToFit(80, 28);
				sign.addCell(signCell().add(sig)
						.setBorderBottom(new SolidBorder(ColorConstants.BLACK, 0.5f)));
			} catch (Exception ex) {
				logger.warn("EW PPF signatory image skipped: {}", ex.getMessage());
				sign.addCell(underlined("", regular));
			}
		} else {
			sign.addCell(underlined("", regular));
		}
		sign.addCell(plain("", regular, 8));
		sign.addCell(underlined(text(signatory.get("name")), bold));
		sign.addCell(plain("", regular, 8));
		sign.addCell(underlined(text(signatory.get("designation")), bold));
		sign.addCell(plain("", regular, 8));
		sign.addCell(underlined(approvedDate, bold));
		sign.addCell(plain("Electronic Signature", bold, 8));
		sign.addCell(plain("", regular, 8));
		sign.addCell(plain("Name", bold, 8));
		sign.addCell(plain("", regular, 8));
		sign.addCell(plain("Designation", bold, 8));
		sign.addCell(plain("", regular, 8));
		sign.addCell(plain("Approved Date", bold, 8));
		doc.add(sign);
		doc.add(note(regular).setMarginTop(12));
	}

	private Cell signCell() {
		return new Cell().setBorder(com.itextpdf.layout.borders.Border.NO_BORDER).setPadding(2);
	}

	private Table infoTable(Map<String, Object> h, boolean vehicle, PdfFont bold, PdfFont regular) {
		Table t = new Table(UnitValue.createPercentArray(new float[] { 22, 28, 22, 28 }))
				.setWidth(UnitValue.createPercentValue(100));
		if (vehicle) {
			pair(t, "Registration No", h.get("reg_no"), bold, regular);
			pair(t, "End Customer Name", h.get("v_end_cust_name"), bold, regular);
			pair(t, "Address Line 1", h.get("v_address_1"), bold, regular);
			pair(t, "Address Line 2", h.get("v_address_2"), bold, regular);
			pair(t, "City", h.get("v_city"), bold, regular);
			pair(t, "State", h.get("v_state"), bold, regular);
			pair(t, "Postal Code", h.get("v_postal_code"), bold, regular);
			pair(t, "Customer Mobile No", h.get("v_cust_mob_no"), bold, regular);
			pair(t, "Email ID", h.get("v_email_id"), bold, regular);
			pair(t, "Fax Number", h.get("v_fax_no"), bold, regular);
			pair(t, "Car Model", h.get("v_car_model"), bold, regular);
			pair(t, "Odometer Reading", h.get("v_odometer_rd"), bold, regular);
			pair(t, "VIN/Chassis Number", h.get("v_vin_no"), bold, regular);
			pair(t, "Installation Place", h.get("v_inst_place"), bold, regular);
			pair(t, "Applicator Name", h.get("v_applicator_name"), bold, regular);
			pair(t, "Applicator Certificate Number", h.get("v_appl_cert_no"), bold, regular);
			pair(t, "Type of Application", h.get("v_to_app"), bold, regular);
			pair(t, "Date of Installation", h.get("date_of_inst"), bold, regular);
		} else {
			pair(t, "Company Name", h.get("end_cust_name"), bold, regular);
			pair(t, "Address1", h.get("address_1"), bold, regular);
			pair(t, "Address2", h.get("address_2"), bold, regular);
			pair(t, "City", h.get("city"), bold, regular);
			pair(t, "Postal Code", h.get("postal_code"), bold, regular);
			pair(t, "State", h.get("state"), bold, regular);
			pair(t, "Date of Installation", h.get("date_of_inst"), bold, regular);
			pair(t, " ", " ", bold, regular);
		}
		return t;
	}

	private Table productTable(List<Map<String, Object>> vinyl, PdfFont bold, PdfFont regular) {
		Table t = new Table(UnitValue.createPercentArray(new float[] { 50, 25, 25 }))
				.setWidth(UnitValue.createPercentValue(100));
		t.addCell(th("3M Product Code", bold));
		t.addCell(th("Lot Number", bold));
		t.addCell(th("Qty (in Sqft)", bold));
		String life = "";
		for (Map<String, Object> row : vinyl) {
			t.addCell(td(text(row.get("vinyl")), regular, TextAlignment.LEFT));
			t.addCell(td(text(row.get("lot_no")), regular, TextAlignment.LEFT));
			t.addCell(td(text(row.get("quantity")), regular, TextAlignment.RIGHT));
			life = text(row.get("warranty_life"));
		}
		t.addCell(th("Warranty Life", bold));
		t.addCell(new Cell(1, 2).add(new Paragraph(life + " Years").setFont(regular).setFontSize(8))
				.setPadding(4).setTextAlignment(TextAlignment.CENTER));
		return t;
	}

	private void pair(Table t, String label, Object value, PdfFont bold, PdfFont regular) {
		t.addCell(th(label, bold).setTextAlignment(TextAlignment.LEFT));
		t.addCell(td(text(value), regular, TextAlignment.LEFT));
	}

	private Cell partyBox(String title, String[][] rows, PdfFont bold, PdfFont regular) {
		Table inner = new Table(UnitValue.createPercentArray(new float[] { 38, 62 }))
				.setWidth(UnitValue.createPercentValue(100));
		inner.addCell(new Cell(1, 2).add(new Paragraph(title).setFont(bold).setFontSize(10))
				.setBorder(null).setPaddingBottom(4));
		for (String[] row : rows) {
			inner.addCell(plain(row[0], regular, 8).setBorder(null).setPadding(2));
			inner.addCell(plain(row[1], regular, 8).setBorder(null).setPadding(2));
		}
		return new Cell().add(inner).setPadding(6).setBorder(new SolidBorder(ColorConstants.BLACK, 0.6f));
	}

	private Cell th(String text, PdfFont bold) {
		return new Cell().add(new Paragraph(text).setFont(bold).setFontSize(8))
				.setBackgroundColor(TH).setPadding(4).setVerticalAlignment(VerticalAlignment.MIDDLE)
				.setTextAlignment(TextAlignment.CENTER);
	}

	private Cell td(String text, PdfFont font, TextAlignment align) {
		return new Cell().add(new Paragraph(text == null ? "" : text).setFont(font).setFontSize(8))
				.setPadding(4).setTextAlignment(align);
	}

	private Cell plain(String text, PdfFont font, float size) {
		return new Cell().add(new Paragraph(text == null ? "" : text).setFont(font).setFontSize(size))
				.setBorder(null).setPadding(1);
	}

	private Cell underlined(String text, PdfFont font) {
		return new Cell().add(new Paragraph(text == null ? "" : text).setFont(font).setFontSize(8))
				.setBorder(com.itextpdf.layout.borders.Border.NO_BORDER)
				.setBorderBottom(new SolidBorder(ColorConstants.BLACK, 0.5f)).setPadding(1);
	}

	private Paragraph note(PdfFont font) {
		return new Paragraph("NOTE: This Warranty period starts from the date of installation.")
				.setFont(font).setFontSize(NOTE_SIZE);
	}

	private void addBleed(Document doc, PdfDocument pdf, String resource) throws Exception {
		byte[] bytes = read(resource);
		if (bytes.length == 0) {
			doc.add(new Paragraph(" "));
			return;
		}
		Image img = new Image(ImageDataFactory.create(bytes));
		img.setFixedPosition(0, 0);
		img.scaleAbsolute(PageSize.A4.getWidth(), PageSize.A4.getHeight());
		doc.add(img);
	}

	private void drawContentHeader(PdfDocument pdf, PdfPage page) {
		try {
			byte[] header = read(IMG + "Common/header.png");
			byte[] logo = read(IMG + "Common/3m_logo.png");
			PdfCanvas canvas = new PdfCanvas(page);
			if (header.length > 0) {
				com.itextpdf.layout.element.Image hi =
						new Image(ImageDataFactory.create(header));
				hi.scaleAbsolute(PageSize.A4.getWidth(), 40);
				hi.setFixedPosition(0, PageSize.A4.getHeight() - 40);
				new com.itextpdf.layout.Canvas(canvas, page.getPageSize()).add(hi);
			}
			if (logo.length > 0) {
				Image li = new Image(ImageDataFactory.create(logo));
				li.scaleToFit(100, 40);
				li.setFixedPosition(PageSize.A4.getWidth() - 120, PageSize.A4.getHeight() - 48);
				new com.itextpdf.layout.Canvas(canvas, page.getPageSize()).add(li);
			}
		} catch (Exception ex) {
			logger.warn("EW PPF PDF header overlay skipped: {}", ex.getMessage());
		}
	}

	private String coverImage(String product) {
		if (eq(product, "3M Paint Protection Film Series 100 Gloss")) {
			return IMG + "PPF/ppf_car1.jpg";
		}
		if (eq(product, "Scotchgard Paint Protection Film Pro Series 200 Gloss")) {
			return IMG + "PPF/ppf_car2.jpg";
		}
		if (eq(product, "Scotchgard Paint Protection Film Pro Series 200 Matte")) {
			return IMG + "PPF/ppf_car3.jpg";
		}
		if (eq(product, "3M Paint Protection Film Series 50 Gloss")) {
			return IMG + "PPF/prod_5_first_page.jpg";
		}
		return IMG + "PPF/prod_4_first_page.jpg";
	}

	private String termsImage(String product, boolean first) {
		if (eq(product, "3M Paint Protection Film Series 100 Gloss")) {
			return first ? IMG + "PPF/prod_1_last_page_first.jpg" : IMG + "PPF/prod_1_last_page_sec.jpg";
		}
		if (eq(product, "Scotchgard Paint Protection Film Pro Series 200 Gloss")) {
			return first ? IMG + "PPF/prod_2_last_page_first.jpg" : IMG + "PPF/prod_2_last_page_sec.jpg";
		}
		if (eq(product, "Scotchgard Paint Protection Film Pro Series 200 Matte")) {
			return first ? IMG + "PPF/prod_3_last_page_first.jpg" : IMG + "PPF/prod_3_last_page_sec.jpg";
		}
		if (eq(product, "3M Paint Protection Film Series 50 Gloss")) {
			return first ? IMG + "PPF/prod_5_sec_page.jpg" : IMG + "PPF/prod_5_third_page.jpg";
		}
		return first ? IMG + "PPF/prod_4_sec_page.jpg" : IMG + "PPF/prod_4_third_page.jpg";
	}

	private boolean eq(String a, String b) {
		return a != null && a.equalsIgnoreCase(b);
	}

	private byte[] read(String classpath) {
		try (InputStream in = new ClassPathResource(classpath).getInputStream()) {
			return in.readAllBytes();
		} catch (Exception ex) {
			logger.warn("EW PPF image missing {}: {}", classpath, ex.getMessage());
			return new byte[0];
		}
	}
}
