package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Legacy {@code GetImgFilesFromServer}: {@code mount-root + /EWARANTY/ + picture_path}
 * via {@code FileInputStream}. Mount comes from YAML {@code inpc.ewarranty.mount-root}
 * (same value as legacy {@code mmm.app.mount}). No SMB.
 */
@Component
public class EwFileStore {
	private static final Logger logger = LoggerFactory.getLogger(EwFileStore.class);

	private final String mountRoot;

	public EwFileStore(@Value("${inpc.ewarranty.mount-root:}") String mountRoot) {
		this.mountRoot = mountRoot == null ? "" : mountRoot.trim();
	}

	public byte[] readQuietly(String storedPath, String fileName) {
		String uploadedFileName = text(storedPath);
		if (uploadedFileName.isEmpty()) {
			uploadedFileName = text(fileName);
		}
		if (uploadedFileName.isEmpty()) {
			logger.warn("EW file path empty storedPath={} fileName={}", storedPath, fileName);
			return new byte[0];
		}
		if (mountRoot.isBlank()) {
			logger.warn("inpc.ewarranty.mount-root is not set in application.yml");
			System.out.println("inpc.ewarranty.mount-root is not set");
			return new byte[0];
		}
		String path = mountRoot + "/EWARANTY";
		String new_path = path + "/" + uploadedFileName;
		System.out.println("new_path...." + new_path);
		logger.info("new_path....{}", new_path);
		try (FileInputStream input = new FileInputStream(new File(new_path));
				ByteArrayOutputStream output = new ByteArrayOutputStream()) {
			input.transferTo(output);
			byte[] bytes = output.toByteArray();
			logger.info("EW photograph read ok path={} bytes={}", new_path, bytes.length);
			return bytes;
		} catch (Exception e) {
			e.printStackTrace();
			logger.warn("EW photograph read failed path={}: {}", new_path, e.getMessage());
			return new byte[0];
		}
	}
}
