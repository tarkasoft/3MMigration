package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.AreaBreakType;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.VerticalAlignment;

/**
 * Graphics-family warranty certificates (BWF / DI-NOC / MCS / Special).
 * Assets: {@code classpath:ewarranty/images/}. Legacy: DownloadEWPDF_PG / MCS / BWF / DiNOC.
 */
final class EwWarrantyPdfGraphics {
	private static final Logger logger = LoggerFactory.getLogger(EwWarrantyPdfGraphics.class);
	private static final String IMG = "ewarranty/images/";
	private static final DeviceRgb TH = new DeviceRgb(151, 156, 152);
	private static final DeviceRgb TH_PURPLE = new DeviceRgb(115, 55, 140);
	private static final DeviceRgb TH_LABEL = new DeviceRgb(178, 183, 171);
	private static final DeviceRgb TH_VALUE = new DeviceRgb(200, 212, 203);
	private static final DeviceRgb TH_GRAY = new DeviceRgb(141, 136, 141);
	private static final float NOTE_SIZE = 7f;

	enum Family {
		SPECIAL(
				"Special Warranty - Graphics",
				"Special_Warranty_Graphics",
				"Customer Details",
				IMG + "SpecialWarranty/sp_first_page.jpg",
				new String[] { IMG + "SpecialWarranty/sp_last_page.jpg" },
				null),
		MCS_PRINTED(
				"MCS Warranty-Printed",
				"MCS_Printed_warranty",
				"Customer Details",
				IMG + "MCS/mcs_first_page_printed.jpg",
				new String[] { IMG + "MCS/mcs_printed_last_page.jpg" },
				IMG + "MCS/mcs_logo.png"),
		MCS_COLORED(
				"MCS Warranty-Colored & Signage",
				"MCS_Non_Printed_warranty",
				"Customer Details",
				IMG + "MCS/mcs_car.jpg",
				new String[] { IMG + "MCS/mcs_last_page.jpg" },
				IMG + "MCS/mcs_logo.png"),
		BWF(
				"Building Window Film Warranty",
				"BuildingWindowFilmWarranty",
				"Customer Details",
				IMG + "BWF/bwf_page1.jpg",
				new String[] { IMG + "BWF/bwf_page_last.jpg" },
				null),
		DINOC(
				"DI-NOC Warranty",
				"Di_NOC_warranty",
				"Customer Details",
				IMG + "DiNOC/di_noc_first_page.png",
				new String[] { IMG + "DiNOC/di_noc_last_page.png" },
				null);

		final String template;
		final String filePrefix;
		final String titleText;
		final String coverImage;
		final String[] lastPages;
		final String logoOverlay;

		Family(String template, String filePrefix, String titleText, String coverImage,
				String[] lastPages, String logoOverlay) {
			this.template = template;
			this.filePrefix = filePrefix;
			this.titleText = titleText;
			this.coverImage = coverImage;
			this.lastPages = lastPages;
			this.logoOverlay = logoOverlay;
		}

		static Family of(String wrtyTemplate) {
			String t = text(wrtyTemplate);
			for (Family f : values()) {
				if (f.template.equals(t)) {
					return f;
				}
			}
			throw new IllegalArgumentException("Warranty PDF for this template is not available: " + t);
		}
	}

	record PdfResult(byte[] bytes, String fileName) {
	}

	PdfResult build(Family family, Map<String, Object> header, String prodRef,
			List<Map<String, Object>> vinylGfx, List<Map<String, Object>> vinylColors,
			List<Map<String, Object>> secVinylColors, List<Map<String, Object>> substrate,
			List<Map<String, Object>> overlaminate, List<Map<String, Object>> proof,
			List<byte[]> photos, Map<String, Object> signatory, byte[] signBytes,
			String approvedDate) throws Exception {
		if (vinylGfx == null || vinylGfx.isEmpty()) {
			throw new IllegalArgumentException("Product lines were not found for this request.");
		}
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = new PdfWriter(out);
		PdfDocument pdf = new PdfDocument(writer);
		pdf.setDefaultPageSize(PageSize.A4);
		Document doc = new Document(pdf, PageSize.A4);
		doc.setMargins(48, 28, 28, 28);
		PdfFont regular = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);
		PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
		doc.setFont(regular);

		addBleed(doc, family.coverImage);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		drawContentHeader(pdf, pdf.getLastPage(), family);
		addPartiesPage(doc, header, family, bold, regular);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		drawContentHeader(pdf, pdf.getLastPage(), family);
		addSpecsPage(doc, header, prodRef, vinylGfx, vinylColors, secVinylColors,
				substrate, overlaminate, proof, photos, signatory, signBytes, approvedDate,
				bold, regular);

		for (String last : family.lastPages) {
			doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
			addBleed(doc, last);
		}

		doc.close();
		String reqId = text(header.get("req_id")).replaceAll("[^A-Za-z0-9_-]", "_");
		String name = family.filePrefix + (reqId.isEmpty() ? "" : "_" + reqId) + ".pdf";
		logger.info("EW Graphics PDF built family={} {} ({} bytes)",
				family.name(), name, out.size());
		return new PdfResult(out.toByteArray(), name);
	}

	private void addPartiesPage(Document doc, Map<String, Object> h, Family family,
			PdfFont bold, PdfFont regular) {
		doc.add(new Paragraph(family.titleText).setFont(bold).setFontSize(16)
				.setFontColor(ColorConstants.WHITE).setMarginBottom(8));
		Table meta = new Table(UnitValue.createPercentArray(new float[] { 16, 18, 16, 16, 18, 16 }))
				.setWidth(UnitValue.createPercentValue(100));
		meta.addCell(plain("Serial No.:", regular, 8));
		meta.addCell(underlined(text(h.get("req_id")), regular));
		meta.addCell(plain("Date Of Issue:", regular, 8));
		meta.addCell(underlined(text(h.get("req_date")), regular));
		meta.addCell(plain("Date Of Installation:", regular, 8));
		meta.addCell(underlined(text(h.get("date_of_inst")), regular));
		doc.add(meta.setMarginBottom(10));

		Table parties = new Table(UnitValue.createPercentArray(new float[] { 50, 50 }))
				.setWidth(UnitValue.createPercentValue(100));
		parties.addCell(partyBox("Issued To", new String[][] {
				{ "Customer Details", text(h.get("customer")) },
				{ "Organization Name", text(h.get("customer")) },
				{ "Address1", text(h.get("ppf_cust_address_1")) },
				{ "Address2", text(h.get("ppf_cust_address_2")) },
				{ "City", text(h.get("ppf_cust_city")) },
				{ "Postal Code", text(h.get("ppf_cust_pin")) },
				{ "State", text(h.get("ppf_cust_state")) }
		}, bold, regular));
		parties.addCell(partyBox("Distributor Details", new String[][] {
				{ "Distributor Details", text(h.get("distributor")) },
				{ "Organization Name", text(h.get("distributor")) },
				{ "Address1", text(h.get("dist_address1")) },
				{ "Address2", text(h.get("dist_address2")) },
				{ "City", text(h.get("dist_city")) },
				{ "Postal Code", text(h.get("dist_pin")) },
				{ "State", text(h.get("dist_state")) }
		}, bold, regular));
		doc.add(parties.setMarginBottom(10));

		doc.add(sectionTitle("Installation Address", bold));
		doc.add(kvTable(new String[][] {
				{ "Customer Details", text(h.get("end_cust_name")) },
				{ "Organization Name", text(h.get("end_cust_name")) },
				{ "Address1", text(h.get("address_1")) },
				{ "Address2", text(h.get("address_2")) },
				{ "City", text(h.get("city")) },
				{ "Postal Code", text(h.get("postal_code")) },
				{ "State", text(h.get("state")) },
				{ "Branch ID", text(h.get("branch_id")) },
				{ "Branch/Site Name", text(h.get("branch_site_name")) },
				{ "Date Of Installation", text(h.get("date_of_inst")) },
				{ "Vehicle Make", text(h.get("v_car_model")) },
				{ "Vehicle Registration Number", text(h.get("reg_no")) }
		}, bold, regular).setMarginBottom(10));

		doc.add(sectionTitle("Converter Details", bold));
		doc.add(kvTable(new String[][] {
				{ "Customer Details", text(h.get("conv_name")) },
				{ "Company Name", text(h.get("conv_name")) },
				{ "Address1", text(h.get("conv_address1")) },
				{ "Address2", text(h.get("conv_address2")) },
				{ "City", text(h.get("conv_city")) },
				{ "Postal Code", text(h.get("conv_pin")) },
				{ "State", text(h.get("conv_state")) }
		}, bold, regular));
		doc.add(note(regular).setMarginTop(10));
	}

	private void addSpecsPage(Document doc, Map<String, Object> h, String prodRef,
			List<Map<String, Object>> vinylGfx, List<Map<String, Object>> vinylColors,
			List<Map<String, Object>> secVinylColors, List<Map<String, Object>> substrate,
			List<Map<String, Object>> overlaminate, List<Map<String, Object>> proof,
			List<byte[]> photos, Map<String, Object> signatory, byte[] signBytes,
			String approvedDate, PdfFont bold, PdfFont regular) {
		Map<String, Object> vinyl = vinylGfx.get(0);
		String slotLabel = text(prodRef).isEmpty() ? "1" : text(prodRef);
		doc.add(new Paragraph("Specification Details – Graphic Element " + slotLabel)
				.setFont(bold).setFontSize(14).setFontColor(ColorConstants.WHITE)
				.setMarginBottom(8));

		Table specs = new Table(UnitValue.createPercentArray(new float[] { 50, 50 }))
				.setWidth(UnitValue.createPercentValue(100));
		specRow(specs, "Application Type", text(vinyl.get("application")), bold, regular, true);
		specRow(specs, "Graphic Conversion Method", text(vinyl.get("graphic_conv_method")),
				bold, regular, false);
		specRow(specs, "Application Substrate", text(vinyl.get("substrate")), bold, regular, true);
		specRow(specs, "Type of Exposure", text(vinyl.get("type_of_exposure")), bold, regular, false);
		specRow(specs, "Print Platform", text(vinyl.get("printing_hardware")), bold, regular, true);
		specRow(specs, "Printer Model", text(vinyl.get("printer_format")), bold, regular, false);
		specRow(specs, "INK", text(vinyl.get("ink")), bold, regular, true);
		specRow(specs, "Edge Sealer", text(vinyl.get("edge_sealer")), bold, regular, false);
		doc.add(specs.setMarginBottom(10));

		String printSp = text(h.get("print_service_provider"));
		if (!printSp.isEmpty()) {
			Table psp = new Table(UnitValue.createPercentArray(new float[] { 40, 60 }))
					.setWidth(UnitValue.createPercentValue(100));
			psp.addCell(th("Print Service Provider", bold));
			psp.addCell(td(printSp, regular, TextAlignment.LEFT));
			doc.add(psp.setMarginBottom(10));
		}

		doc.add(materialsTable(vinyl, vinylColors, secVinylColors, substrate, overlaminate,
				bold, regular).setMarginBottom(8));

		Table life = new Table(UnitValue.createPercentArray(new float[] { 40, 60 }))
				.setWidth(UnitValue.createPercentValue(100));
		life.addCell(th("Warranty Life", bold));
		life.addCell(td(text(vinyl.get("warranty_life")) + " Years", regular, TextAlignment.CENTER));
		doc.add(life.setMarginBottom(10));
		doc.add(note(regular));

		doc.add(new Paragraph("Proof of Installation")
				.setFont(bold).setFontSize(13).setTextAlignment(TextAlignment.CENTER)
				.setMarginTop(10).setMarginBottom(6));
		doc.add(poiTable(proof, bold, regular).setMarginBottom(10));

		doc.add(new Paragraph("Application Photograph").setFont(bold).setFontSize(14)
				.setTextAlignment(TextAlignment.CENTER).setMarginTop(8).setMarginBottom(8));
		int shown = 0;
		if (photos != null) {
			for (byte[] bytes : photos) {
				if (bytes == null || bytes.length == 0) {
					continue;
				}
				try {
					Image img = new Image(ImageDataFactory.create(bytes));
					img.scaleToFit(480, 280);
					img.setMarginBottom(8);
					doc.add(img);
					shown++;
				} catch (Exception ex) {
					logger.warn("EW Graphics photo skipped: {}", ex.getMessage());
				}
			}
		}
		if (shown == 0) {
			doc.add(new Paragraph("No application photographs were found for this request.")
					.setFont(regular).setFontSize(9).setMarginBottom(8));
		}

		doc.add(new Paragraph(" ").setMarginTop(12));
		Table sign = new Table(UnitValue.createPercentArray(
				new float[] { 22, 4, 22, 4, 22, 4, 22 }))
				.setWidth(UnitValue.createPercentValue(100));
		sign.setBorder(com.itextpdf.layout.borders.Border.NO_BORDER);
		if (signBytes != null && signBytes.length > 0) {
			try {
				Image sig = new Image(ImageDataFactory.create(signBytes));
				sig.scaleToFit(80, 28);
				sign.addCell(signCell().add(sig)
						.setBorderBottom(new SolidBorder(ColorConstants.BLACK, 0.5f)));
			} catch (Exception ex) {
				logger.warn("EW Graphics signatory image skipped: {}", ex.getMessage());
				sign.addCell(underlined("", regular));
			}
		} else {
			sign.addCell(underlined("", regular));
		}
		sign.addCell(plain("", regular, 8));
		sign.addCell(underlined(text(signatory == null ? "" : signatory.get("name")), bold));
		sign.addCell(plain("", regular, 8));
		sign.addCell(underlined(text(signatory == null ? "" : signatory.get("designation")), bold));
		sign.addCell(plain("", regular, 8));
		sign.addCell(underlined(approvedDate, bold));
		sign.addCell(plain("Electronic Signature", bold, 8));
		sign.addCell(plain("", regular, 8));
		sign.addCell(plain("Name", bold, 8));
		sign.addCell(plain("", regular, 8));
		sign.addCell(plain("Designation", bold, 8));
		sign.addCell(plain("", regular, 8));
		sign.addCell(plain("Approved Date", bold, 8));
		doc.add(sign);
		doc.add(note(regular).setMarginTop(12));
	}

	private Table materialsTable(Map<String, Object> vinyl, List<Map<String, Object>> colors,
			List<Map<String, Object>> secColors, List<Map<String, Object>> substrate,
			List<Map<String, Object>> overlaminate, PdfFont bold, PdfFont regular) {
		Table t = new Table(UnitValue.createPercentArray(new float[] { 22, 26, 18, 17, 17 }))
				.setWidth(UnitValue.createPercentValue(100));
		t.addCell(new Cell(1, 5).add(new Paragraph("Graphic Material Details")
				.setFont(bold).setFontSize(9).setFontColor(ColorConstants.WHITE))
				.setBackgroundColor(TH_PURPLE).setPadding(4)
				.setTextAlignment(TextAlignment.CENTER));
		t.addCell(thGray("", bold));
		t.addCell(new Cell(1, 2).add(new Paragraph("3M Product Code").setFont(bold).setFontSize(8))
				.setBackgroundColor(TH_GRAY).setPadding(3).setTextAlignment(TextAlignment.CENTER));
		t.addCell(thGray("Lot Number", bold));
		t.addCell(thGray("Qty (in Sqft)", bold));

		Map<String, Object> sub = first(substrate);
		t.addCell(tdLabel("Flexible Substrate", regular));
		t.addCell(new Cell(1, 2).add(new Paragraph(text(sub.get("m_flexible_substrate")))
				.setFont(regular).setFontSize(8)).setBackgroundColor(TH_VALUE).setPadding(3));
		t.addCell(tdValue(text(sub.get("substrate_lot_no")), regular, TextAlignment.LEFT));
		t.addCell(tdValue(text(sub.get("quantity")), regular, TextAlignment.RIGHT));

		String product = text(vinyl.get("vinyl"));
		List<Map<String, Object>> colorRows = colors == null || colors.isEmpty()
				? List.of(Map.of("color", "", "lot_no", "", "quantity", ""))
				: colors;
		boolean hasColor = !text(colorRows.get(0).get("color")).isEmpty();
		int rowspan = Math.max(1, colorRows.size());
		t.addCell(new Cell(rowspan, 1).add(new Paragraph("3M Primary Film").setFont(regular).setFontSize(8))
				.setBackgroundColor(TH_LABEL).setPadding(3).setVerticalAlignment(VerticalAlignment.MIDDLE));
		if (hasColor) {
			t.addCell(new Cell(rowspan, 1).add(new Paragraph(product).setFont(regular).setFontSize(8))
					.setBackgroundColor(TH_VALUE).setPadding(3).setVerticalAlignment(VerticalAlignment.MIDDLE));
			for (int i = 0; i < colorRows.size(); i++) {
				Map<String, Object> row = colorRows.get(i);
				t.addCell(tdValue(text(row.get("color")), regular, TextAlignment.LEFT));
				t.addCell(tdValue(text(row.get("lot_no")), regular, TextAlignment.LEFT));
				t.addCell(tdValue(text(row.get("quantity")), regular, TextAlignment.RIGHT));
			}
		} else {
			t.addCell(new Cell(rowspan, 2).add(new Paragraph(product).setFont(regular).setFontSize(8))
					.setBackgroundColor(TH_VALUE).setPadding(3).setVerticalAlignment(VerticalAlignment.MIDDLE));
			for (Map<String, Object> row : colorRows) {
				t.addCell(tdValue(text(row.get("lot_no")), regular, TextAlignment.LEFT));
				t.addCell(tdValue(text(row.get("quantity")), regular, TextAlignment.RIGHT));
			}
		}

		List<Map<String, Object>> secRows = secColors == null || secColors.isEmpty()
				? List.of(Map.of("sec_vinyl", "NA", "color", "NA", "lot_no", "NA", "quantity", "0"))
				: secColors;
		String secVinyl = text(secRows.get(0).get("sec_vinyl"));
		String secColor0 = text(secRows.get(0).get("color"));
		boolean secHasColor = !secColor0.isEmpty() || "NA".equalsIgnoreCase(secColor0);
		int secSpan = Math.max(1, secRows.size());
		t.addCell(new Cell(secSpan, 1).add(new Paragraph("3M Secondary Film").setFont(regular).setFontSize(8))
				.setBackgroundColor(TH_LABEL).setPadding(3).setVerticalAlignment(VerticalAlignment.MIDDLE));
		if (secHasColor) {
			t.addCell(new Cell(secSpan, 1).add(new Paragraph(secVinyl).setFont(regular).setFontSize(8))
					.setBackgroundColor(TH_VALUE).setPadding(3).setVerticalAlignment(VerticalAlignment.MIDDLE));
			for (Map<String, Object> row : secRows) {
				t.addCell(tdValue(text(row.get("color")), regular, TextAlignment.LEFT));
				t.addCell(tdValue(text(row.get("lot_no")), regular, TextAlignment.LEFT));
				t.addCell(tdValue(text(row.get("quantity")), regular, TextAlignment.RIGHT));
			}
		} else {
			t.addCell(new Cell(secSpan, 2).add(new Paragraph(secVinyl).setFont(regular).setFontSize(8))
					.setBackgroundColor(TH_VALUE).setPadding(3).setVerticalAlignment(VerticalAlignment.MIDDLE));
			for (Map<String, Object> row : secRows) {
				t.addCell(tdValue(text(row.get("lot_no")), regular, TextAlignment.LEFT));
				t.addCell(tdValue(text(row.get("quantity")), regular, TextAlignment.RIGHT));
			}
		}

		Map<String, Object> ol = first(overlaminate);
		t.addCell(tdLabel("Over Laminate", regular));
		t.addCell(new Cell(1, 2).add(new Paragraph(text(ol.get("overlaminate")))
				.setFont(regular).setFontSize(8)).setBackgroundColor(TH_VALUE).setPadding(3));
		t.addCell(tdValue(text(ol.get("overlaminate_lot_no")), regular, TextAlignment.LEFT));
		t.addCell(tdValue(text(ol.get("quantity")), regular, TextAlignment.RIGHT));
		return t;
	}

	private Table poiTable(List<Map<String, Object>> proof, PdfFont bold, PdfFont regular) {
		Table t = new Table(UnitValue.createPercentArray(new float[] { 12, 12, 10, 14, 12, 40 }))
				.setWidth(UnitValue.createPercentValue(100));
		t.addCell(th("Width", bold));
		t.addCell(th("Height", bold));
		t.addCell(th("Unit", bold));
		t.addCell(th("Area", bold));
		t.addCell(th("Qty", bold));
		t.addCell(th("Remarks", bold));
		if (proof == null || proof.isEmpty()) {
			t.addCell(td("", regular, TextAlignment.CENTER));
			t.addCell(td("", regular, TextAlignment.CENTER));
			t.addCell(td("", regular, TextAlignment.CENTER));
			t.addCell(td("", regular, TextAlignment.CENTER));
			t.addCell(td("", regular, TextAlignment.CENTER));
			t.addCell(td("", regular, TextAlignment.LEFT));
			return t;
		}
		for (Map<String, Object> row : proof) {
			t.addCell(td(text(row.get("width")), regular, TextAlignment.CENTER));
			t.addCell(td(text(row.get("height")), regular, TextAlignment.CENTER));
			t.addCell(td(text(row.get("unit")), regular, TextAlignment.CENTER));
			t.addCell(td(text(row.get("dimension")), regular, TextAlignment.CENTER));
			t.addCell(td(text(row.get("quantity")), regular, TextAlignment.CENTER));
			t.addCell(td(text(row.get("description")), regular, TextAlignment.LEFT));
		}
		return t;
	}

	private void specRow(Table t, String label, String value, PdfFont bold, PdfFont regular,
			boolean alt) {
		DeviceRgb bg = alt ? TH_LABEL : TH_VALUE;
		t.addCell(new Cell().add(new Paragraph(label).setFont(bold).setFontSize(8))
				.setBackgroundColor(bg).setPadding(3).setTextAlignment(TextAlignment.CENTER));
		t.addCell(new Cell().add(new Paragraph(value).setFont(regular).setFontSize(8))
				.setBackgroundColor(bg).setPadding(3).setTextAlignment(TextAlignment.CENTER));
	}

	private Paragraph sectionTitle(String text, PdfFont bold) {
		return new Paragraph(text).setFont(bold).setFontSize(11)
				.setFontColor(ColorConstants.WHITE)
				.setBackgroundColor(TH_PURPLE)
				.setTextAlignment(TextAlignment.CENTER)
				.setPadding(4).setMarginBottom(4).setMarginTop(6);
	}

	private Table kvTable(String[][] rows, PdfFont bold, PdfFont regular) {
		Table t = new Table(UnitValue.createPercentArray(new float[] { 22, 28, 22, 28 }))
				.setWidth(UnitValue.createPercentValue(100));
		for (int i = 0; i < rows.length; i += 2) {
			String[] a = rows[i];
			t.addCell(th(a[0], bold).setTextAlignment(TextAlignment.LEFT));
			t.addCell(td(a[1], regular, TextAlignment.LEFT).setBackgroundColor(TH_VALUE));
			if (i + 1 < rows.length) {
				String[] b = rows[i + 1];
				t.addCell(th(b[0], bold).setTextAlignment(TextAlignment.LEFT));
				t.addCell(td(b[1], regular, TextAlignment.LEFT).setBackgroundColor(TH_VALUE));
			} else {
				t.addCell(th(" ", bold));
				t.addCell(td(" ", regular, TextAlignment.LEFT));
			}
		}
		return t;
	}

	private Cell partyBox(String title, String[][] rows, PdfFont bold, PdfFont regular) {
		Table inner = new Table(UnitValue.createPercentArray(new float[] { 40, 60 }))
				.setWidth(UnitValue.createPercentValue(100));
		inner.addCell(new Cell(1, 2).add(new Paragraph(title).setFont(bold).setFontSize(9)
				.setFontColor(ColorConstants.WHITE))
				.setBackgroundColor(TH_PURPLE).setPadding(4)
				.setTextAlignment(TextAlignment.CENTER));
		for (String[] row : rows) {
			inner.addCell(new Cell().add(new Paragraph(row[0]).setFont(bold).setFontSize(8))
					.setBackgroundColor(TH_LABEL).setPadding(3)
					.setTextAlignment(TextAlignment.CENTER));
			inner.addCell(new Cell().add(new Paragraph(row[1]).setFont(regular).setFontSize(8))
					.setBackgroundColor(TH_VALUE).setPadding(3)
					.setTextAlignment(TextAlignment.CENTER));
		}
		return new Cell().add(inner).setPadding(4)
				.setBorder(new SolidBorder(ColorConstants.BLACK, 0.4f));
	}

	private Cell th(String text, PdfFont bold) {
		return new Cell().add(new Paragraph(text).setFont(bold).setFontSize(8))
				.setBackgroundColor(TH).setPadding(4).setVerticalAlignment(VerticalAlignment.MIDDLE)
				.setTextAlignment(TextAlignment.CENTER);
	}

	private Cell thGray(String text, PdfFont bold) {
		return new Cell().add(new Paragraph(text).setFont(bold).setFontSize(8))
				.setBackgroundColor(TH_GRAY).setPadding(3).setTextAlignment(TextAlignment.CENTER);
	}

	private Cell td(String text, PdfFont font, TextAlignment align) {
		return new Cell().add(new Paragraph(text == null ? "" : text).setFont(font).setFontSize(8))
				.setPadding(4).setTextAlignment(align);
	}

	private Cell tdLabel(String text, PdfFont font) {
		return new Cell().add(new Paragraph(text).setFont(font).setFontSize(8))
				.setBackgroundColor(TH_LABEL).setPadding(3);
	}

	private Cell tdValue(String text, PdfFont font, TextAlignment align) {
		return new Cell().add(new Paragraph(text == null ? "" : text).setFont(font).setFontSize(8))
				.setBackgroundColor(TH_VALUE).setPadding(3).setTextAlignment(align);
	}

	private Cell plain(String text, PdfFont font, float size) {
		return new Cell().add(new Paragraph(text == null ? "" : text).setFont(font).setFontSize(size))
				.setBorder(null).setPadding(1);
	}

	private Cell underlined(String text, PdfFont font) {
		return new Cell().add(new Paragraph(text == null ? "" : text).setFont(font).setFontSize(8))
				.setBorder(com.itextpdf.layout.borders.Border.NO_BORDER)
				.setBorderBottom(new SolidBorder(ColorConstants.BLACK, 0.5f)).setPadding(1);
	}

	private Cell signCell() {
		return new Cell().setBorder(com.itextpdf.layout.borders.Border.NO_BORDER).setPadding(2);
	}

	private Paragraph note(PdfFont font) {
		return new Paragraph("NOTE: This Warranty period starts from the date of installation.")
				.setFont(font).setFontSize(NOTE_SIZE);
	}

	private Map<String, Object> first(List<Map<String, Object>> rows) {
		if (rows == null || rows.isEmpty()) {
			return Map.of();
		}
		return rows.get(0);
	}

	private void addBleed(Document doc, String resource) throws Exception {
		byte[] bytes = read(resource);
		if (bytes.length == 0) {
			doc.add(new Paragraph(" "));
			return;
		}
		Image img = new Image(ImageDataFactory.create(bytes));
		img.setFixedPosition(0, 0);
		img.scaleAbsolute(PageSize.A4.getWidth(), PageSize.A4.getHeight());
		doc.add(img);
	}

	private void drawContentHeader(PdfDocument pdf, PdfPage page, Family family) {
		try {
			byte[] header = read(IMG + "Common/header.png");
			byte[] logo = read(IMG + "Common/3m_logo.png");
			PdfCanvas canvas = new PdfCanvas(page);
			if (header.length > 0) {
				Image hi = new Image(ImageDataFactory.create(header));
				hi.scaleAbsolute(PageSize.A4.getWidth(), 40);
				hi.setFixedPosition(0, PageSize.A4.getHeight() - 40);
				new com.itextpdf.layout.Canvas(canvas, page.getPageSize()).add(hi);
			}
			if (logo.length > 0) {
				Image li = new Image(ImageDataFactory.create(logo));
				li.scaleToFit(100, 40);
				li.setFixedPosition(PageSize.A4.getWidth() - 120, PageSize.A4.getHeight() - 48);
				new com.itextpdf.layout.Canvas(canvas, page.getPageSize()).add(li);
			}
			if (family.logoOverlay != null) {
				byte[] mcs = read(family.logoOverlay);
				if (mcs.length > 0) {
					Image mi = new Image(ImageDataFactory.create(mcs));
					mi.scaleToFit(60, 28);
					mi.setFixedPosition(20, PageSize.A4.getHeight() - 48);
					new com.itextpdf.layout.Canvas(canvas, page.getPageSize()).add(mi);
				}
			}
		} catch (Exception ex) {
			logger.warn("EW Graphics PDF header overlay skipped: {}", ex.getMessage());
		}
	}

	private byte[] read(String classpath) {
		try (InputStream in = new ClassPathResource(classpath).getInputStream()) {
			return in.readAllBytes();
		} catch (Exception ex) {
			logger.warn("EW Graphics image missing {}: {}", classpath, ex.getMessage());
			return new byte[0];
		}
	}
}
