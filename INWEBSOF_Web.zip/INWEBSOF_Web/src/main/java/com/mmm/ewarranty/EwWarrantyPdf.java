package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Warranty certificate download (legacy {@code DownloadEWPDFAdmin/DownloadEWarrantyPDF}).
 * Dispatches by exact {@code wrty_template}.
 */
@RestController
@RequestMapping("/api/customer/ewarranty")
public class EwWarrantyPdf {
	private static final Logger logger = LoggerFactory.getLogger(EwWarrantyPdf.class);

	private final EwContext context;
	private final EwWarrantyPdfSql pdfSql;
	private final EwWarrantyPdfPpf ppf;
	private final EwWarrantyPdfGraphics graphics;
	private final EwFileStore files;

	public EwWarrantyPdf(HibernateFactoryRegistry registry, EwFileStore files) {
		this.context = new EwContext(new EwRequestsSql(registry));
		this.pdfSql = new EwWarrantyPdfSql(registry);
		this.ppf = new EwWarrantyPdfPpf();
		this.graphics = new EwWarrantyPdfGraphics();
		this.files = files;
	}

	@GetMapping("/converter/requests/{id}/products/{prodRefCode}/warranty-pdf")
	public ResponseEntity<byte[]> converterPdf(HttpServletRequest request,
			@PathVariable("id") long id,
			@PathVariable("prodRefCode") String prodRefCode,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			return pdf(id, prodRefCode, "en.converter", working.internalCode());
		} catch (Exception ex) {
			return fail(id, prodRefCode, ex);
		}
	}

	@GetMapping("/distributor/requests/{id}/products/{prodRefCode}/warranty-pdf")
	public ResponseEntity<byte[]> distributorPdf(HttpServletRequest request,
			@PathVariable("id") long id,
			@PathVariable("prodRefCode") String prodRefCode,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			EwContext.WorkingDistributor working =
					context.resolveDistributor(request.getSession(false), custCode, loginId);
			return pdf(id, prodRefCode, "en.distributor", working.internalCode());
		} catch (Exception ex) {
			return fail(id, prodRefCode, ex);
		}
	}

	private ResponseEntity<byte[]> pdf(long id, String prodRefCode, String ownerColumn, long ownerId)
			throws Exception {
		Map<String, Object> header = pdfSql.header(id, ownerColumn, ownerId);
		if (header == null) {
			throw new IllegalArgumentException("Request not found for this customer.");
		}
		if (!"Closed".equalsIgnoreCase(text(header.get("status")))) {
			throw new IllegalArgumentException("Warranty certificate is available after the request is Closed.");
		}
		String template = text(header.get("wrty_template"));
		String slot = text(prodRefCode);
		if (slot.isEmpty()) {
			slot = "1";
		}
		Map<String, Object> signatory = pdfSql.signatory();
		byte[] signBytes = files.readQuietly(
				cell(signatory, "file_path"), cell(signatory, "file_path"));
		String approved = pdfSql.lastApprovedDate(id);

		if ("Paint Protection Film".equals(template)
				|| template.toLowerCase().indexOf("paint protection") >= 0) {
			return ppfPdf(id, slot, header, signatory, signBytes, approved);
		}

		EwWarrantyPdfGraphics.Family family = EwWarrantyPdfGraphics.Family.of(template);
		return graphicsPdf(id, slot, header, family, signatory, signBytes, approved);
	}

	private ResponseEntity<byte[]> ppfPdf(long id, String slot, Map<String, Object> header,
			Map<String, Object> signatory, byte[] signBytes, String approved) throws Exception {
		List<Map<String, Object>> vinyl = pdfSql.vinyl(id, slot);
		List<Map<String, Object>> proof = pdfSql.proof(id, slot);
		List<byte[]> photos = loadPhotos(proof);
		logger.info("EW PPF PDF photos={} signatoryBytes={}", photos.size(), signBytes.length);
		EwWarrantyPdfPpf.PdfResult result = ppf.build(
				header, vinyl, photos, signatory, signBytes, approved);
		return pdfResponse(result.bytes(), result.fileName());
	}

	private ResponseEntity<byte[]> graphicsPdf(long id, String slot, Map<String, Object> header,
			EwWarrantyPdfGraphics.Family family, Map<String, Object> signatory,
			byte[] signBytes, String approved) throws Exception {
		List<Map<String, Object>> vinylGfx = pdfSql.vinylGfx(id, slot);
		List<Map<String, Object>> colors = pdfSql.vinylColors(id, slot);
		List<Map<String, Object>> secColors = pdfSql.secVinylColors(id, slot);
		List<Map<String, Object>> substrate = pdfSql.substrate(id, slot);
		List<Map<String, Object>> overlaminate = pdfSql.overlaminate(id, slot);
		List<Map<String, Object>> proof = pdfSql.proofGfx(id, slot);
		List<byte[]> photos = loadPhotos(proof);
		logger.info("EW Graphics PDF family={} slot={} photos={} vinyl={}",
				family.name(), slot, photos.size(), vinylGfx.size());
		EwWarrantyPdfGraphics.PdfResult result = graphics.build(
				family, header, slot, vinylGfx, colors, secColors, substrate, overlaminate,
				proof, photos, signatory, signBytes, approved);
		return pdfResponse(result.bytes(), result.fileName());
	}

	private List<byte[]> loadPhotos(List<Map<String, Object>> proof) {
		List<byte[]> photos = new ArrayList<>();
		logger.info("EW PDF proof rows={}", proof == null ? 0 : proof.size());
		if (proof == null) {
			return photos;
		}
		for (Map<String, Object> row : proof) {
			String path = cell(row, "picture_path");
			String name = cell(row, "picture_name");
			byte[] img = files.readQuietly(path, name);
			logger.info("EW PDF photo picture_path={} picture_name={} bytes={}", path, name, img.length);
			if (img.length > 0) {
				photos.add(img);
			}
		}
		return photos;
	}

	private ResponseEntity<byte[]> pdfResponse(byte[] bytes, String fileName) {
		return ResponseEntity.ok()
				.contentType(MediaType.APPLICATION_PDF)
				.header(HttpHeaders.CONTENT_DISPOSITION,
						ContentDisposition.attachment().filename(fileName).build().toString())
				.header("X-Content-Type-Options", "nosniff")
				.body(bytes);
	}

	private ResponseEntity<byte[]> fail(long id, String prodRef, Exception ex) {
		HttpStatus status = HttpStatus.BAD_REQUEST;
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			status = HttpStatus.UNAUTHORIZED;
		} else if (!(ex instanceof IllegalArgumentException)) {
			status = HttpStatus.BAD_GATEWAY;
			logger.error("EW warranty PDF failed requestId={} prod={}", id, prodRef, ex);
		} else {
			logger.warn("EW warranty PDF rejected: {}", ex.getMessage());
		}
		return ResponseEntity.status(status).build();
	}

	private static String cell(Map<String, Object> row, String key) {
		if (row == null || key == null) {
			return "";
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(key)) {
				return text(entry.getValue());
			}
		}
		return "";
	}
}
