package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/**
 * New Request lookups, cascade, and autocomplete against {@code dINTWSYS}.
 */
final class EwReqWarrantySql {
	private static final Logger logger = LoggerFactory.getLogger(EwReqWarrantySql.class);

	private static final Set<String> LIFE_COLUMNS = Set.of(
			"fin_prod_info_app",
			"graphic_conv_method",
			"type_of_exposure",
			"substrate",
			"m_flexible_substrate",
			"vinyl",
			"sec_vinyl",
			"overlaminate",
			"printer_format",
			"printing_hardware",
			"ink",
			"warranty_type");

	private static final String LOOKUPS_SQL = """
			select
				isnull(lookup_key, '') as lookupKey,
				isnull(lookup_value, '') as lookupValue,
				isnull(remarks, '') as lookupRemarks,
				isnull(warranty_template, '') as warranty_template
			from ew_lookup_master with (nolock)
			where active = 'Yes'
			order by lookup_key, sequence
			""";

	private static final String PROD_MASTER_SQL = """
			select
				isnull(category, '') as lookupKey,
				isnull(name, '') as lookupValue,
				isnull(color, '') as prodColor,
				isnull(warranty_type, '') as warranty_template
			from ew_product_master with (nolock)
			where active = 'Yes' and category != 'Vinyl'
			order by category, sequence
			""";

	private static final String TEMPLATES_SQL = """
			select
				isnull(special_warranty_graphics, 0) as special_warranty_graphics,
				isnull(mcs_warranty_printed, 0) as mcs_warranty_printed,
				isnull(mcs_warranty_colored_signage, 0) as mcs_warranty_colored_signage,
				isnull(building_window_film_warranty, 0) as building_window_film_warranty,
				isnull(paint_protection_film, 0) as paint_protection_film,
				isnull(di_noc_warranty, 0) as di_noc_warranty,
				isnull(auto_closed, '') as auto_closed,
				isnull(company_name, '') as company_name
			from ew_convertor with (nolock)
			where cast(internal_code as varchar(20)) = ?
			""";

	private static final String APPROVERS_SQL = """
			select
				isnull(asm_kam_enl, '') as asm_kam_enl,
				isnull(asm_kam_name, '') as asm_kam_name,
				isnull(segment_leader_enl, '') as segment_leader_enl,
				isnull(segment_leader_name, '') as segment_leader_name
			from ew_converter_approver_mapping with (nolock)
			where cast(converter as varchar(20)) = ?
			""";

	private static final String STATES_SQL = """
			select
				isnull(code, '') as code,
				isnull(name, '') as name,
				cast(internal_code as varchar(20)) as internal_code
			from tk_state with (nolock)
			order by name
			""";

	private static final String DIST_AC_SQL = """
			select distinct top 10
				d.code + ' - ' + d.name as value,
				cast(d.internal_code as varchar(20)) as internal_code,
				isnull(d.address1, '') + isnull(d.address2, '') as address,
				isnull(d.city, '') as city,
				isnull(d.state, '') as state,
				isnull(d.phone_no, '') as phone_no,
				isnull(d.email, '') as email
			from ew_converter_distributor_mapping mp with (nolock)
			inner join ew_distributor d with (nolock) on d.internal_code = mp.distributor
			where cast(mp.converter as varchar(20)) = ?
				and (d.code like ? or d.name like ?)
			""";

	private static final String CUST_AC_SQL = """
			select top 10
				code + ' - ' + company_name as value,
				cast(internal_code as varchar(20)) as internal_code,
				isnull(address1, '') as address1,
				isnull(address2, '') as address,
				isnull(city, '') as city,
				isnull(state, '') as state,
				isnull(phone_no, '') as phone_no,
				isnull(email, '') as email,
				isnull(pin, '') as pin,
				isnull(company_name, '') as customer_name
			from ew_conv_customer with (nolock)
			where (company_name like ? or code like ?)
				and ui_status = 'Approved'
			""";

	private static final String APPL_AC_SQL = """
			select top 10
				code + ' - ' + company_name as value,
				cast(internal_code as varchar(20)) as internal_code,
				isnull(address1, '') + isnull(address2, '') as address,
				isnull(city, '') as city,
				isnull(state, '') as state,
				isnull(phone_no, '') as phone_no,
				isnull(email, '') as email
			from ew_applicator with (nolock)
			where company_name like ? or code like ?
			""";

	private static final String SEGMENT_LEADER_LOOKUP_SQL = """
			select isnull(segment_leader, '') as segment_leader
			from ew_lookup_master with (nolock)
			where lookup_key = 'Warranty Template'
				and lookup_value = ?
			""";

	private final HibernateFactoryRegistry registry;

	EwReqWarrantySql(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	Map<String, Object> onload(long convertorInternalCode) {
		Map<String, Object> data = new LinkedHashMap<>();
		data.put("lookupData", NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, LOOKUPS_SQL));
		data.put("prodMasterDataSet", NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, PROD_MASTER_SQL));
		data.put("stateDataSet", NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, STATES_SQL));
		String convKey = String.valueOf(convertorInternalCode);
		List<Map<String, Object>> templates = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, TEMPLATES_SQL, convKey);
		data.put("warranty_templates", templates);
		data.put("converter_approver_object", NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, APPROVERS_SQL, convKey));
		data.put("auto_closed", templates.isEmpty() ? "" : text(templates.get(0).get("auto_closed")));
		data.put("converter_name", templates.isEmpty() ? "" : text(templates.get(0).get("company_name")));
		return data;
	}

	List<Map<String, Object>> cascadeValues(Map<String, Object> filters) {
		String outRaw = text(filters.get("out_param"));
		if ("application".equalsIgnoreCase(outRaw)) {
			outRaw = "fin_prod_info_app";
		}
		String outParam = lifeColumn(outRaw);
		StringBuilder sql = new StringBuilder(
				"select distinct isnull(cast(" + outParam + " as varchar(200)), '') as value "
						+ "from ew_warranty_life with (nolock) where 1=1 ");
		List<Object> params = new ArrayList<>();
		appendLifeFilters(sql, params, filters, outParam);
		sql.append(" order by value");
		logger.info("EW cascade: {}", SqlDebugFormatter.render(sql.toString(), params.toArray()));
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql.toString(), params.toArray());
	}

	List<Map<String, Object>> warrantyLife(Map<String, Object> filters) {
		StringBuilder sql = new StringBuilder(
				"select warranty_life from ew_warranty_life with (nolock) where 1=1 ");
		List<Object> params = new ArrayList<>();
		appendLifeFilters(sql, params, filters, "");
		logger.info("EW warranty life: {}", SqlDebugFormatter.render(sql.toString(), params.toArray()));
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql.toString(), params.toArray());
	}

	List<Map<String, Object>> distributorAutocomplete(long convertorInternalCode, String phrase,
			String warrantyType) {
		/* ew_converter_distributor_mapping has no warranty_type column (legacy SQL is stale). */
		String like = like(phrase);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, DIST_AC_SQL,
				String.valueOf(convertorInternalCode), like, like);
	}

	List<Map<String, Object>> customerAutocomplete(String phrase) {
		String like = like(phrase);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, CUST_AC_SQL, like, like);
	}

	List<Map<String, Object>> applicatorAutocomplete(String phrase) {
		String like = like(phrase);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, APPL_AC_SQL, like, like);
	}

	/**
	 * Legacy {@code GetSegmentLeaderAutoComplete}: users listed in
	 * {@code ew_lookup_master.segment_leader} for the warranty template.
	 */
	List<Map<String, Object>> segmentLeaderAutocomplete(String warrantyType, String phrase) {
		String warrTemp = text(warrantyType);
		if (warrTemp.isEmpty()) {
			return List.of();
		}
		List<Map<String, Object>> lookup = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, SEGMENT_LEADER_LOOKUP_SQL, warrTemp);
		if (lookup == null || lookup.isEmpty()) {
			return List.of();
		}
		List<String> enlIds = parseEnlList(text(lookup.get(0).get("segment_leader")));
		if (enlIds.isEmpty()) {
			return List.of();
		}
		StringBuilder sql = new StringBuilder("""
				select
					ia.enl_id + '-' + ia.name as value,
					cast(ia.internal_code as varchar(20)) as internal_code,
					isnull(ia.enl_id, '') as enl_id,
					isnull(ia.name, '') as name
				from ia_user_master ia with (nolock)
				where ia.enl_id in (
				""");
		List<Object> params = new ArrayList<>();
		for (int i = 0; i < enlIds.size(); i++) {
			if (i > 0) {
				sql.append(", ");
			}
			sql.append("?");
			params.add(enlIds.get(i));
		}
		sql.append(") ");
		String term = text(phrase).trim();
		if (!term.isEmpty()) {
			sql.append(" and (ia.enl_id like ? or ia.name like ?) ");
			String like = like(term);
			params.add(like);
			params.add(like);
		}
		sql.append(" order by ia.name");
		logger.info("EW segment leader AC: {}", SqlDebugFormatter.render(sql.toString(), params.toArray()));
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql.toString(), params.toArray());
	}

	private static List<String> parseEnlList(String raw) {
		List<String> out = new ArrayList<>();
		if (raw == null || raw.isBlank()) {
			return out;
		}
		for (String part : raw.split(",")) {
			String id = part.trim().replace("'", "").replace("\"", "");
			if (!id.isEmpty()) {
				out.add(id);
			}
		}
		return out;
	}

	List<Map<String, Object>> vinylAutocomplete(String phrase, String warrantyType, String systemName,
			Map<String, Object> filters) {
		boolean secondary = text(systemName).toLowerCase(Locale.ROOT).contains("sec_vinyl");
		boolean ppf = "Paint Protection Film".equalsIgnoreCase(text(warrantyType));
		StringBuilder sql = new StringBuilder("""
				select distinct
					p.name as value,
					cast(p.internal_code as varchar(20)) as internal_code,
					isnull(p.color, '') as color
				from ew_product_master p with (nolock)
				""");
		if (secondary) {
			sql.append(" inner join ew_warranty_life el with (nolock) on rtrim(ltrim(el.sec_vinyl)) = rtrim(ltrim(p.name)) ");
		} else {
			sql.append(" inner join ew_warranty_life el with (nolock) on rtrim(ltrim(el.vinyl)) = rtrim(ltrim(p.name)) ");
		}
		sql.append(" where p.active = 'Yes' and p.name like ? ");
		List<Object> params = new ArrayList<>();
		params.add(like(phrase));
		if (ppf) {
			sql.append(" and p.warranty_type = ? ");
			params.add(text(warrantyType));
		} else {
			sql.append(" and p.warranty_type in (?, 'All') ");
			params.add(text(warrantyType));
		}
		if (secondary) {
			sql.append(" and p.category = '3M Secondary Film (Vinyl)' ");
		} else {
			sql.append(" and p.category = '3M Primary Film (Vinyl)' ");
		}
		if (filters != null) {
			for (Map.Entry<String, Object> entry : filters.entrySet()) {
				String col = text(entry.getKey());
				if ("warr_temp".equals(col)) {
					col = "warranty_type";
				}
				if ("vinyl".equals(col) || "out_param".equals(col) || "application".equals(col)) {
					/* application / Type of Application is header v_to_app — not a life column. */
					continue;
				}
				if (!LIFE_COLUMNS.contains(col)) {
					continue;
				}
				String val = text(entry.getValue());
				if (val.isEmpty()) {
					continue;
				}
				sql.append(" and el.").append(col).append(" like ? ");
				params.add(val + "%");
			}
		}
		logger.info("EW vinyl AC: {}", SqlDebugFormatter.render(sql.toString(), params.toArray()));
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql.toString(), params.toArray());
	}

	private static void appendLifeFilters(StringBuilder sql, List<Object> params,
			Map<String, Object> filters, String skipColumn) {
		if (filters == null) {
			return;
		}
		for (Map.Entry<String, Object> entry : filters.entrySet()) {
			String key = text(entry.getKey());
			if ("out_param".equals(key)) {
				continue;
			}
			/* Frontend sends `application`; life table column is fin_prod_info_app. */
			String col = "warr_temp".equals(key) ? "warranty_type"
					: ("application".equals(key) ? "fin_prod_info_app" : key);
			if (!LIFE_COLUMNS.contains(col) || col.equals(skipColumn)) {
				continue;
			}
			String val = text(entry.getValue());
			if (val.isEmpty() || "NA".equalsIgnoreCase(val) || "None".equalsIgnoreCase(val)) {
				continue;
			}
			if ("vinyl".equals(col) || "sec_vinyl".equals(col)) {
				sql.append(" and ").append(col).append(" like ? ");
				params.add(val + "%");
			} else {
				sql.append(" and ").append(col).append(" = ? ");
				params.add(val);
			}
		}
	}

	private static String lifeColumn(String name) {
		if (!LIFE_COLUMNS.contains(name)) {
			throw new IllegalArgumentException("Invalid cascade field.");
		}
		return name;
	}

	private static String like(String phrase) {
		return "%" + text(phrase) + "%";
	}
}
