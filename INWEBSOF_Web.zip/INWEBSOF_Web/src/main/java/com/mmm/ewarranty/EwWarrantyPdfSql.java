package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/** SQL for CSD graphic E-Warranty PDF (legacy DownloadEWPDFCommon). */
final class EwWarrantyPdfSql {
	private static final Logger logger = LoggerFactory.getLogger(EwWarrantyPdfSql.class);

	private static final String HEADER_SQL = """
			select
				isnull(en.req_id, '') as req_id,
				isnull(convert(varchar(10), en.req_date, 103), '') as req_date,
				isnull(en.status, '') as status,
				isnull(en.wrty_template, '') as wrty_template,
				isnull(en.inst_type, 'Non Vehicle') as inst_type,
				isnull(convert(varchar(10), en.date_of_inst, 103), '') as date_of_inst,
				isnull(en.print_service_provider, '') as print_service_provider,
				isnull(en.branch_site_name, '') as branch_site_name,
				isnull(en.branch_id, '') as branch_id,
				isnull(en.proj_type, '') as proj_type,
				isnull(en.no_of_products, '0') as no_of_products,
				case
					when isnull(en.ppf_cust_company_name, '') != ''
						then isnull(en.ppf_cust_company_name, '')
					else isnull(c.code + ' - ' + c.company_name, '')
				end as customer,
				isnull(en.ppf_cust_address_1, '') as ppf_cust_address_1,
				isnull(en.ppf_cust_address_2, '') as ppf_cust_address_2,
				isnull(en.ppf_cust_city, '') as ppf_cust_city,
				isnull(s5.name, '') as ppf_cust_state,
				isnull(en.ppf_cust_pin, '') as ppf_cust_pin,
				isnull(en.end_cust_name, '') as end_cust_name,
				isnull(en.address_1, '') as address_1,
				isnull(en.address_2, '') as address_2,
				isnull(en.city, '') as city,
				isnull(s.name, '') as state,
				isnull(en.postal_code, '') as postal_code,
				isnull(en.reg_no, '') as reg_no,
				isnull(en.v_end_cust_name, '') as v_end_cust_name,
				isnull(en.v_address_1, '') as v_address_1,
				isnull(en.v_address_2, '') as v_address_2,
				isnull(en.v_city, '') as v_city,
				isnull(en.v_state, '') as v_state,
				isnull(en.v_postal_code, '') as v_postal_code,
				isnull(en.v_email_id, '') as v_email_id,
				isnull(en.v_cust_mob_no, '') as v_cust_mob_no,
				isnull(en.v_fax_no, '') as v_fax_no,
				isnull(en.v_car_model, '') as v_car_model,
				isnull(en.v_odometer_rd, '') as v_odometer_rd,
				isnull(en.v_vin_no, '') as v_vin_no,
				isnull(en.v_inst_place, '') as v_inst_place,
				isnull(en.v_applicator_name, '') as v_applicator_name,
				isnull(en.v_appl_cert_no, '') as v_appl_cert_no,
				isnull(en.v_to_app, '') as v_to_app,
				isnull(en.partial_application_remarks, '') as partial_application_remarks,
				isnull(ap.code + ' - ' + ap.company_name, '') as applicator,
				isnull(ap.contact_name, '') as app_contact_name,
				isnull(ap.address1, '') as app_address1,
				isnull(ap.address2, '') as app_address2,
				isnull(ap.city, '') as app_city,
				isnull(ap.pin, '') as app_pin,
				isnull(s3.name, '') as app_state,
				isnull(ap.phone_no, '') as app_phone_no,
				isnull(ap.email, '') as app_email,
				isnull(d.code + ' - ' + d.name, '') as distributor,
				isnull(d.address1, '') as dist_address1,
				isnull(d.address2, '') as dist_address2,
				isnull(d.city, '') as dist_city,
				isnull(d.pin, '') as dist_pin,
				isnull(s1.name, '') as dist_state,
				isnull(d.phone_no, '') as dist_phone_no,
				isnull(d.email, '') as dist_email,
				isnull(con.company_name, '') as conv_name,
				isnull(con.contact_name, '') as conv_contact_name,
				isnull(con.address1, '') as conv_address1,
				isnull(con.address2, '') as conv_address2,
				isnull(con.city, '') as conv_city,
				isnull(con.pin, '') as conv_pin,
				isnull(s2.name, '') as conv_state,
				isnull(c.address1, '') as cust_address1,
				isnull(c.address2, '') as cust_address2,
				isnull(c.city, '') as cust_city,
				isnull(s4.name, '') as cust_state,
				isnull(c.pin, '') as cust_pin,
				isnull(c.phone_no, '') as cust_phone_no,
				isnull(c.email, '') as cust_email
			from ew_new_request_header en with (nolock)
			left join ew_conv_customer c with (nolock) on c.internal_code = en.customer
			left join ew_distributor d with (nolock) on d.internal_code = en.distributor
			left join ew_applicator ap with (nolock) on ap.internal_code = en.applicator
			left join ew_convertor con with (nolock) on con.internal_code = en.converter
			left join tk_state s with (nolock) on s.internal_code = en.state
			left join tk_state s1 with (nolock) on s1.internal_code = d.state
			left join tk_state s2 with (nolock) on s2.internal_code = con.state
			left join tk_state s3 with (nolock) on s3.internal_code = ap.state
			left join tk_state s4 with (nolock) on s4.internal_code = c.state
			left join tk_state s5 with (nolock) on s5.internal_code = en.ppf_cust_state
			where cast(en.internal_code as varchar(20)) = ?
				and cast(%s as varchar(20)) = ?
			""";

	private static final String VINYL_SQL = """
			select
				isnull(vinyl, '') as vinyl,
				isnull(lot_no, '') as lot_no,
				isnull(cast(quantity as varchar(50)), '') as quantity,
				isnull(warranty_life, '0') as warranty_life
			from ew_new_request_vinyl with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			""";

	private static final String VINYL_GFX_SQL = """
			select
				isnull(vinyl, '') as vinyl,
				isnull(cast(prod_ref_code as varchar(20)), '0') as prod_ref_code,
				isnull(ink, '0') as ink,
				isnull(printer_format, '0') as printer_format,
				isnull(printing_hardware, '0') as printing_hardware,
				isnull(edge_sealer, '0') as edge_sealer,
				isnull(type_of_exposure, '0') as type_of_exposure,
				isnull(graphic_conv_method, '0') as graphic_conv_method,
				isnull(application, '0') as application,
				isnull(substrate, '') as substrate,
				isnull(warranty_life, '0') as warranty_life
			from ew_new_request_vinyl with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			""";

	private static final String VINYL_COLOR_SQL = """
			select
				isnull(color, '') as color,
				isnull(lot_no, '') as lot_no,
				isnull(cast(quantity as varchar(50)), '') as quantity
			from ew_new_request_vinyl with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			""";

	private static final String SEC_VINYL_COLOR_SQL = """
			select
				isnull(vinyl, 'NA') as sec_vinyl,
				isnull(color, 'NA') as color,
				isnull(lot_no, 'NA') as lot_no,
				isnull(cast(quantity as varchar(50)), '0') as quantity
			from ew_new_request_sec_vinyl with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			union all
			select 'NA', 'NA', 'NA', '0'
			where not exists (
				select 1
				from ew_new_request_sec_vinyl with (nolock)
				where cast(ref_s_ref_data_code as varchar(20)) = ?
					and cast(prod_ref_code as varchar(20)) = ?
			)
			""";

	private static final String SUBSTRATE_SQL = """
			select
				isnull(cast(prod_ref_code as varchar(20)), '0') as prod_ref_code,
				isnull(m_flexible_substrate, '') as m_flexible_substrate,
				isnull(substrate_lot_no, '') as substrate_lot_no,
				isnull(cast(quantity as varchar(50)), '0') as quantity
			from ew_new_request_subs_lot_no with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			""";

	private static final String OVERLAMINATE_SQL = """
			select
				isnull(overlaminate, '') as overlaminate,
				isnull(overlaminate_lot_no, '') as overlaminate_lot_no,
				isnull(cast(prod_ref_code as varchar(20)), '0') as prod_ref_code,
				isnull(cast(quantity as varchar(50)), '0') as quantity
			from ew_new_request_overlam_lot_no with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			""";

	private static final String POI_SQL = """
			select
				isnull(picture_name, '') as picture_name,
				isnull(picture_path, '') as picture_path,
				isnull(description, '') as description
			from ew_new_request_proof_inst with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			""";

	private static final String POI_ALL_SQL = """
			select
				isnull(picture_name, '') as picture_name,
				isnull(picture_path, '') as picture_path,
				isnull(description, '') as description
			from ew_new_request_proof_inst with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String POI_GFX_SQL = """
			select
				isnull(cast(width as varchar(50)), '') as width,
				isnull(cast(height as varchar(50)), '') as height,
				isnull(unit, '') as unit,
				isnull(cast(width * height * quantity as varchar(50)), '') as dimension,
				isnull(cast(quantity as varchar(50)), '') as quantity,
				isnull(description, '') as description,
				isnull(picture_path, '') as picture_path,
				isnull(picture_name, '') as picture_name,
				isnull(cast(prod_ref_code as varchar(20)), '') as prod_ref_code
			from ew_new_request_proof_inst with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and cast(prod_ref_code as varchar(20)) = ?
			""";

	private static final String POI_GFX_ALL_SQL = """
			select
				isnull(cast(width as varchar(50)), '') as width,
				isnull(cast(height as varchar(50)), '') as height,
				isnull(unit, '') as unit,
				isnull(cast(width * height * quantity as varchar(50)), '') as dimension,
				isnull(cast(quantity as varchar(50)), '') as quantity,
				isnull(description, '') as description,
				isnull(picture_path, '') as picture_path,
				isnull(picture_name, '') as picture_name,
				isnull(cast(prod_ref_code as varchar(20)), '') as prod_ref_code
			from ew_new_request_proof_inst with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String SIGNATORY_SQL = """
			select top 1
				isnull(designation, '') as designation,
				isnull(name, '') as name,
				isnull(file_path, '') as file_path
			from ew_signatory_details with (nolock)
			""";

	private static final String APPROVED_DATE_SQL = """
			select isnull(convert(varchar(10), modified_date, 103), '') as approved_date
			from ew_new_request_approval_matrix with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and internal_code in (
					select max(internal_code)
					from ew_new_request_approval_matrix with (nolock)
					where cast(ref_s_ref_data_code as varchar(20)) = ?
						and isnull(ui_status, '') != 'Closed'
				)
			""";

	private final HibernateFactoryRegistry registry;

	EwWarrantyPdfSql(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	Map<String, Object> header(long requestId, String ownerColumn, long ownerId) {
		String owner = "en.converter".equals(ownerColumn) ? "en.converter" : "en.distributor";
		String sql = String.format(HEADER_SQL, owner);
		String req = String.valueOf(requestId);
		String own = String.valueOf(ownerId);
		logger.info("EW PDF header: {}", SqlDebugFormatter.render(sql, req, own));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql, req, own);
		return rows == null || rows.isEmpty() ? null : rows.get(0);
	}

	List<Map<String, Object>> vinyl(long requestId, String prodRef) {
		return query(VINYL_SQL, String.valueOf(requestId), text(prodRef));
	}

	List<Map<String, Object>> vinylGfx(long requestId, String prodRef) {
		return query(VINYL_GFX_SQL, String.valueOf(requestId), text(prodRef));
	}

	List<Map<String, Object>> vinylColors(long requestId, String prodRef) {
		return query(VINYL_COLOR_SQL, String.valueOf(requestId), text(prodRef));
	}

	List<Map<String, Object>> secVinylColors(long requestId, String prodRef) {
		String req = String.valueOf(requestId);
		String slot = text(prodRef);
		return query(SEC_VINYL_COLOR_SQL, req, slot, req, slot);
	}

	List<Map<String, Object>> substrate(long requestId, String prodRef) {
		return query(SUBSTRATE_SQL, String.valueOf(requestId), text(prodRef));
	}

	List<Map<String, Object>> overlaminate(long requestId, String prodRef) {
		return query(OVERLAMINATE_SQL, String.valueOf(requestId), text(prodRef));
	}

	List<Map<String, Object>> proof(long requestId, String prodRef) {
		try {
			List<Map<String, Object>> rows = query(POI_SQL, String.valueOf(requestId), text(prodRef));
			if (rows.isEmpty() && !"1".equals(text(prodRef))) {
				rows = query(POI_SQL, String.valueOf(requestId), "1");
			}
			if (rows.isEmpty()) {
				rows = query(POI_ALL_SQL, String.valueOf(requestId));
			}
			return rows;
		} catch (RuntimeException ex) {
			logger.warn("EW PDF proof skipped: {}", ex.getMessage());
			return List.of();
		}
	}

	List<Map<String, Object>> proofGfx(long requestId, String prodRef) {
		try {
			List<Map<String, Object>> rows = query(POI_GFX_SQL, String.valueOf(requestId), text(prodRef));
			if (rows.isEmpty() && !"1".equals(text(prodRef))) {
				rows = query(POI_GFX_SQL, String.valueOf(requestId), "1");
			}
			if (rows.isEmpty()) {
				rows = query(POI_GFX_ALL_SQL, String.valueOf(requestId));
			}
			return rows;
		} catch (RuntimeException ex) {
			logger.warn("EW PDF proofGfx skipped: {}", ex.getMessage());
			return List.of();
		}
	}

	Map<String, Object> signatory() {
		try {
			List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
					registry, HibernateFactoryRegistry.CSD, SIGNATORY_SQL);
			return rows == null || rows.isEmpty() ? Map.of() : rows.get(0);
		} catch (RuntimeException ex) {
			logger.warn("EW PDF signatory skipped: {}", ex.getMessage());
			return Map.of();
		}
	}

	String lastApprovedDate(long requestId) {
		String key = String.valueOf(requestId);
		try {
			List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
					registry, HibernateFactoryRegistry.CSD, APPROVED_DATE_SQL, key, key);
			if (rows == null || rows.isEmpty()) {
				return "";
			}
			return text(rows.get(0).get("approved_date"));
		} catch (RuntimeException ex) {
			logger.warn("EW PDF approved date skipped: {}", ex.getMessage());
			return "";
		}
	}

	private List<Map<String, Object>> query(String sql, Object... params) {
		logger.info("EW PDF query: {}", SqlDebugFormatter.render(sql, params));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql, params);
		return rows == null ? new ArrayList<>() : rows;
	}
}
