package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Converter New Request APIs: onload, cascade, autocompletes, save.
 */
@RestController
@RequestMapping("/api/customer/ewarranty/new-request")
public class EwReqWarranty {
	private static final Logger logger = LoggerFactory.getLogger(EwReqWarranty.class);
	private static final Gson GSON = new Gson();

	private final EwRequestsSql requestsSql;
	private final EwReqWarrantySql sql;
	private final EwContext context;
	private final SaveEwRequest save;

	public EwReqWarranty(HibernateFactoryRegistry registry) {
		this.requestsSql = new EwRequestsSql(registry);
		this.sql = new EwReqWarrantySql(registry);
		this.context = new EwContext(requestsSql);
		this.save = new SaveEwRequest(registry);
	}

	@GetMapping("/onload")
	public String onload(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			Map<String, Object> data = sql.onload(working.internalCode());
			data.putAll(working.toMap());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping("/cascade")
	public String cascade(HttpServletRequest request,
			@RequestBody(required = false) Map<String, Object> body,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			context.resolveConvertor(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", sql.cascadeValues(lifeFilters(body)));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping("/warranty-life")
	public String warrantyLife(HttpServletRequest request,
			@RequestBody(required = false) Map<String, Object> body,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			context.resolveConvertor(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", sql.warrantyLife(lifeFilters(body)));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/distributors")
	public String distributors(HttpServletRequest request,
			@RequestParam(value = "phrase", required = false) String phrase,
			@RequestParam(value = "warrantyType", required = false) String warrantyType,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", sql.distributorAutocomplete(
					working.internalCode(), phrase, warrantyType));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/customers")
	public String customers(HttpServletRequest request,
			@RequestParam(value = "phrase", required = false) String phrase,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			context.resolveConvertor(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", sql.customerAutocomplete(phrase));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/applicators")
	public String applicators(HttpServletRequest request,
			@RequestParam(value = "phrase", required = false) String phrase,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			context.resolveConvertor(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", sql.applicatorAutocomplete(phrase));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** Legacy {@code EWCommon/GetSegmentLeaderAutoComplete}. */
	@GetMapping("/segment-leaders")
	public String segmentLeaders(HttpServletRequest request,
			@RequestParam(value = "phrase", required = false) String phrase,
			@RequestParam(value = "warrantyType", required = false) String warrantyType,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			context.resolveConvertor(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", sql.segmentLeaderAutocomplete(warrantyType, phrase));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping("/vinyl")
	public String vinyl(HttpServletRequest request,
			@RequestBody(required = false) Map<String, Object> body,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			context.resolveConvertor(request.getSession(false), custCode, loginId);
			Map<String, Object> payload = body == null ? Map.of() : body;
			Map<String, Object> filters = lifeFilters(asMap(payload.get("filters")));
			result.SetSuccess("success", sql.vinylAutocomplete(
					text(payload.get("phrase")),
					text(payload.get("warrantyType")),
					text(payload.get("systemName")),
					filters));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping
	public String save(HttpServletRequest request,
			@RequestBody(required = false) Map<String, Object> body,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			Map<String, Object> payload = body == null ? Map.of() : body;
			Map<String, Object> header = asMap(payload.get("header"));
			if (header.isEmpty() && payload.containsKey("wrty_template")) {
				header = payload;
			}
			result.SetSuccess("success", save.save(
					working,
					working.loginId(),
					header,
					asList(payload.get("products")),
					asList(payload.get("secVinyl")),
					asList(payload.get("addnlInvoices"))));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	private static Map<String, Object> lifeFilters(Map<String, Object> raw) {
		Map<String, Object> out = new LinkedHashMap<>();
		if (raw == null) {
			return out;
		}
		for (Map.Entry<String, Object> entry : raw.entrySet()) {
			String key = normalizeLifeKey(text(entry.getKey()));
			if (key.isEmpty()) {
				continue;
			}
			out.put(key, entry.getValue());
		}
		return out;
	}

	private static String normalizeLifeKey(String key) {
		if (key.isEmpty()) {
			return key;
		}
		String lower = key.toLowerCase(Locale.ROOT);
		/* Legacy cascade column on ew_warranty_life is fin_prod_info_app (not application). */
		if ("fin_prod_info_app".equals(lower) || "application".equals(lower)) {
			return "fin_prod_info_app";
		}
		if ("warr_temp".equals(lower) || "wrty_template".equals(lower) || "warrantytype".equals(lower)) {
			return "warr_temp";
		}
		if ("outparam".equals(lower) || "out_param".equals(lower)) {
			return "out_param";
		}
		if (lower.matches(".*_\\d+$")) {
			lower = lower.replaceFirst("_\\d+$", "");
		}
		if (lower.startsWith("ew_p")) {
			int us = lower.indexOf('_', 4);
			if (us > 0) {
				lower = lower.substring(us + 1);
			}
		}
		return lower;
	}

	private static Map<String, Object> asMap(Object value) {
		if (value instanceof Map<?, ?> map) {
			Map<String, Object> copy = new LinkedHashMap<>();
			map.forEach((k, v) -> copy.put(String.valueOf(k), v));
			return copy;
		}
		return new LinkedHashMap<>();
	}

	private static List<Map<String, Object>> asList(Object value) {
		List<Map<String, Object>> list = new ArrayList<>();
		if (value instanceof List<?> source) {
			for (Object item : source) {
				if (item instanceof Map<?, ?>) {
					list.add(asMap(item));
				}
			}
		}
		return list;
	}

	private String error(ResponseDataGeneric result, Exception ex) {
		String message = sqlMessage(ex);
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "error", message);
		} else if (ex instanceof IllegalArgumentException) {
			result.SetError(1, "error", message);
		} else {
			logger.error("E-Warranty new request API failed", ex);
			result.SetError(1, "error", message);
		}
		return GSON.toJson(result);
	}

	/** Prefer JDBC / SQL Server message so the UI can show the real cause. */
	private static String sqlMessage(Exception ex) {
		Throwable cur = ex;
		SQLException sql = null;
		while (cur != null) {
			if (cur instanceof SQLException s) {
				sql = s;
			}
			cur = cur.getCause();
		}
		if (sql != null) {
			String detail = text(sql.getMessage());
			if (!detail.isEmpty()) {
				return "Database error: " + detail;
			}
		}
		String message = ex.getMessage();
		return message == null || message.isBlank() ? "Unexpected error." : message;
	}
}
