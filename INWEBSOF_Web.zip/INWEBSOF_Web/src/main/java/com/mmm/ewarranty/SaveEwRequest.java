package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.sqlDate;
import static com.mmm.titpl.CommonFunctions.text;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/**
 * Insert a graphic E-Warranty request (header + product vinyl rows + approval
 * matrix) in one transaction.
 */
final class SaveEwRequest {
	private static final Logger logger = LoggerFactory.getLogger(SaveEwRequest.class);
	private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE;

	private final HibernateFactoryRegistry registry;

	SaveEwRequest(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	Map<String, Object> save(
			EwContext.WorkingConvertor working,
			String loginId,
			Map<String, Object> header,
			List<Map<String, Object>> products,
			List<Map<String, Object>> secVinyl,
			List<Map<String, Object>> addnlInvoices) {
		if (header == null) {
			throw new IllegalArgumentException("Request details are required.");
		}
		String saveTypeRaw = text(header.get("save_type"));
		if (!"Draft".equalsIgnoreCase(saveTypeRaw) && !"Submit".equalsIgnoreCase(saveTypeRaw)) {
			throw new IllegalArgumentException("save_type must be Draft or Submit.");
		}
		String saveType = "Submit".equalsIgnoreCase(saveTypeRaw) ? "Submit" : "Draft";
		String wrtyTemplate = text(header.get("wrty_template"));
		require(wrtyTemplate, "Select a warranty template.");
		boolean ppf = "Paint Protection Film".equalsIgnoreCase(wrtyTemplate);
		String distInt = text(header.get("dist_int_code"));
		if (!ppf) {
			require(distInt, "Distributor cannot be empty.");
			if ("0".equals(distInt)) {
				throw new IllegalArgumentException("Distributor cannot be empty.");
			}
		}
		String dateOfInst = sqlDate(header.get("date_of_inst"), "Installation date");
		require(dateOfInst, "Enter installation date.");
		LocalDate install = LocalDate.parse(dateOfInst, ISO);
		long days = ChronoUnit.DAYS.between(install, LocalDate.now());
		if (ppf && days > 7) {
			throw new IllegalArgumentException(
					"Installation date and warranty creation date should not exceed 7 days.");
		}
		if (!ppf && days > 60) {
			throw new IllegalArgumentException(
					"Installation date and warranty creation date should not exceed 60 days.");
		}
		int productCount = products == null ? 0 : products.size();
		final int expected = intVal(header.get("no_of_products"), ppf ? 1 : productCount);
		/*
		 * Header no_of_products = product tabs (PPF always 1). Vinyl list may have
		 * multiple rows per tab (legacy GetVinylGroupObj / AddVinylGroupRow).
		 */
		final int headerProducts = ppf ? 1 : expected;
		if (ppf) {
			if (productCount < 1 || productCount > 5) {
				throw new IllegalArgumentException("Enter at least one PPF line.");
			}
		} else if (expected < 1 || expected > 5) {
			throw new IllegalArgumentException("No. of products must be between 1 and 5.");
		} else if (products == null || products.isEmpty()) {
			throw new IllegalArgumentException("Enter product details for each product tab.");
		} else {
			boolean[] seen = new boolean[expected + 1];
			for (Map<String, Object> product : products) {
				int slot = intVal(product.get("prod_sl_no"), 0);
				if (slot >= 1 && slot <= expected) {
					seen[slot] = true;
				}
			}
			for (int i = 1; i <= expected; i++) {
				if (!seen[i]) {
					throw new IllegalArgumentException("Enter product details for each product tab.");
				}
			}
		}
		for (Map<String, Object> product : products) {
			String life = text(product.get("warranty_life"));
			if (life.isEmpty() || "0".equals(life)) {
				throw new IllegalArgumentException(
						"Warranty life is required for product " + text(product.get("prod_sl_no")) + ".");
			}
			require(text(product.get("vinyl")),
					"Enter vinyl / film for product " + text(product.get("prod_sl_no")) + ".");
		}

		final String status = "Submit".equals(saveType)
				? (ppf ? "Pending With KAM/ASM" : "Pending With Distributor")
				: "Draft";
		final String nowSql = UserSessionSupport.sessionDate();
		final String createdBy = text(loginId);
		final String converter = String.valueOf(working.internalCode());
		String roleRaw = text(header.get("g_ew_user_type"));
		final String createdRole = roleRaw.isEmpty() ? "Converter" : roleRaw;
		final List<Map<String, Object>> secRows = secVinyl == null ? List.of() : secVinyl;
		final List<Map<String, Object>> addnlRows = addnlInvoices == null ? List.of() : addnlInvoices;

		Map<String, Object> data = registry.withSession(HibernateFactoryRegistry.CSD, session -> {
			Transaction transaction = session.beginTransaction();
			try {
				String reqId = nextReqId(session, nowSql);
				insertHeader(session, nowSql, header, reqId, status, saveType, dateOfInst,
						converter, createdBy, createdRole, headerProducts);
				long headerId = headerIdForReqId(session, reqId);
				insertVinyl(session, nowSql, headerId, products);
				if (!ppf) {
					insertGraphicsChildren(session, nowSql, headerId, products, secRows, addnlRows);
				}
				insertApprovalMatrix(session, nowSql, headerId, wrtyTemplate,
						text(header.get("auto_closed")), createdBy);
				updateApproverEnl(session, headerId);
				transaction.commit();
				Map<String, Object> saved = new LinkedHashMap<>();
				saved.put("reqId", reqId);
				saved.put("internalCode", headerId);
				saved.put("saveType", saveType);
				saved.put("status", status);
				saved.put("message", "Submit".equals(saveType)
						? ("Warranty created successfully. Request No: " + reqId)
						: ("Warranty saved as Draft. Request No: " + reqId));
				return saved;
			} catch (RuntimeException ex) {
				logger.error("EW save failed (rolled back): {}", ex.getMessage(), ex);
				rollback(transaction);
				throw ex;
			} catch (Exception ex) {
				logger.error("EW save failed (rolled back): {}", ex.getMessage(), ex);
				rollback(transaction);
				throw new RuntimeException(ex.getMessage(), ex);
			}
		});
		logger.info("EW request saved {} as {} by {}", data.get("reqId"), saveType, createdBy);
		return data;
	}

	private void insertHeader(Session session, String nowSql, Map<String, Object> header,
			String reqId, String status, String saveType, String dateOfInst,
			String converter, String createdBy, String createdRole, int noOfProducts) {
		String sql = """
				insert into ew_new_request_header (
					asm_kam_approver, remarks, print_service_provider, branch_site_name, branch_id,
					ppf_cust_email, ppf_cust_phone, ppf_cust_company_name, ppf_cust_address_1,
					ppf_cust_address_2, ppf_cust_city, ppf_cust_state, ppf_cust_pin,
					segment_leader, proj_info_market_catg_others_remrks, partial_application_remarks,
					end_cust_int_code, status, distributor, customer, req_id, wrty_type, wrty_template,
					date_of_inst, end_cust_name, address_1, address_2, city, state, postal_code,
					vehicle, reg_no, v_end_cust_name, v_address_1, v_address_2,
					v_city, v_state, v_postal_code, v_email_id,
					v_cust_mob_no, v_fax_no, v_car_model, v_odometer_rd, v_vin_no,
					v_inst_place, v_applicator_name, v_appl_cert_no, v_to_app, market_cat,
					save_type, req_date, created_date, converter, applicator, inst_type,
					req_created_role, req_created_by, no_of_products, project_name
				) values (
					?, ?, ?, ?, ?,
					?, ?, ?, ?,
					?, ?, ?, ?,
					?, ?, ?,
					?, ?, ?, ?, ?, ?, ?,
					?, ?, ?, ?, ?, ?, ?,
					?, ?, ?, ?, ?,
					?, ?, ?, ?,
					?, ?, ?, ?, ?,
					?, ?, ?, ?, ?,
					?,
				"""
				+ nowSql + ", " + nowSql
				+ """
					, ?, ?, ?,
					?, ?, ?, ?
				)
				""";
		update(session, "EW header insert", sql,
				text(header.get("asm_kam_approver")),
				text(header.get("ew_remarks")),
				text(header.get("print_service_provider")),
				text(header.get("branch_site_name")),
				text(header.get("branch_id")),
				text(header.get("ppf_cust_email")),
				text(header.get("ppf_cust_phone")),
				text(header.get("ppf_cust_company_name")),
				text(header.get("ppf_cust_address_1")),
				text(header.get("ppf_cust_address_2")),
				text(header.get("ppf_cust_city")),
				text(header.get("ppf_cust_state")),
				text(header.get("ppf_cust_pin")),
				text(header.get("segment_leader")),
				text(header.get("proj_info_market_catg_others_remrks")),
				text(header.get("partial_application_remarks")),
				nz(header.get("end_cust_int_code")),
				status,
				text(header.get("dist_int_code")),
				nz(header.get("cust_int_code")),
				reqId,
				text(header.get("wrty_type")),
				text(header.get("wrty_template")),
				dateOfInst,
				text(header.get("end_cust_name")),
				text(header.get("address_1")),
				text(header.get("address_2")),
				text(header.get("city")),
				text(header.get("state")),
				text(header.get("postal_code")),
				text(header.get("vehicle")),
				text(header.get("reg_no")),
				text(header.get("v_end_cust_name")),
				text(header.get("v_address_1")),
				text(header.get("v_address_2")),
				text(header.get("v_city")),
				text(header.get("v_state")),
				text(header.get("v_postal_code")),
				text(header.get("v_email_id")),
				text(header.get("v_cust_mob_no")),
				text(header.get("v_fax_no")),
				text(header.get("v_car_model")),
				text(header.get("v_odometer_rd")),
				text(header.get("v_vin_no")),
				text(header.get("v_inst_place")),
				text(header.get("v_applicator_name")),
				text(header.get("v_appl_cert_no")),
				text(header.get("v_to_app")),
				text(header.get("market_cat")),
				saveType,
				converter,
				nz(header.get("applicator_int_code")),
				text(header.get("inst_type")),
				createdRole,
				createdBy,
				String.valueOf(noOfProducts),
				text(header.get("project_name")));
	}

	private void insertVinyl(Session session, String nowSql, long headerId,
			List<Map<String, Object>> products) {
		String sql = """
				insert into ew_new_request_vinyl (
					vinyl_unique_lot_no, sequence, warranty_life, substrate, prod_ref_code,
					ink, printer_format, printing_hardware, edge_sealer, type_of_exposure,
					graphic_conv_method, application, ref_s_ref_data_code, vinyl, lot_no,
					quantity, created_date, color
				) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
				"""
				+ nowSql + ", ?)";
		int seq = 1;
		for (Map<String, Object> product : products) {
			String slot = text(product.get("prod_sl_no"));
			if (slot.isEmpty()) {
				slot = String.valueOf(seq);
			}
			update(session, "EW vinyl insert #" + slot, sql,
					text(product.get("vinyl_unique_lot_no")),
					String.valueOf(seq),
					text(product.get("warranty_life")),
					text(product.get("substrate")),
					slot,
					text(product.get("ink")),
					text(product.get("printer_format")),
					text(product.get("printing_hardware")),
					text(product.get("edge_sealer")),
					text(product.get("type_of_exposure")),
					text(product.get("graphic_conv_method")),
					text(product.get("application")),
					headerId,
					text(product.get("vinyl")),
					text(product.get("vinyl_lot_no")),
					nzQty(product.get("vinyl_qty")),
					text(product.get("vinyl_color")));
			seq++;
		}
	}

	/**
	 * Legacy child tables for non-PPF: substrate / overlam / POI once per product tab,
	 * secondary vinyl rows, Dist→Converter invoice lines (file bytes uploaded separately).
	 */
	private void insertGraphicsChildren(Session session, String nowSql, long headerId,
			List<Map<String, Object>> products,
			List<Map<String, Object>> secVinyl,
			List<Map<String, Object>> addnlInvoices) {
		Map<String, Map<String, Object>> bySlot = new LinkedHashMap<>();
		for (Map<String, Object> product : products) {
			String slot = text(product.get("prod_sl_no"));
			if (slot.isEmpty()) {
				continue;
			}
			bySlot.putIfAbsent(slot, product);
		}
		String subSql = """
				insert into ew_new_request_subs_lot_no (
					quantity, prod_ref_code, m_flexible_substrate, ref_s_ref_data_code,
					substrate_lot_no, created_date
				) values (?, ?, ?, ?, ?,
				"""
				+ nowSql + ")";
		String overSql = """
				insert into ew_new_request_overlam_lot_no (
					quantity, prod_ref_code, ref_s_ref_data_code, overlaminate,
					overlaminate_lot_no, created_date
				) values (?, ?, ?, ?, ?,
				"""
				+ nowSql + ")";
		String poiSql = """
				insert into ew_new_request_proof_inst (
					prod_ref_code, ref_s_ref_data_code, width, height, unit, dimension,
					quantity, description, created_date, sequence, picture_path, picture_name
				) values (?, ?, ?, ?, ?, ?, ?, ?,
				"""
				+ nowSql + ", ?, ?, ?)";
		for (Map.Entry<String, Map<String, Object>> entry : bySlot.entrySet()) {
			String slot = entry.getKey();
			Map<String, Object> p = entry.getValue();
			String flex = text(p.get("m_flexible_substrate"));
			String subLot = text(p.get("substrate_lot_no"));
			String subQty = text(p.get("substrate_qty"));
			if (!flex.isEmpty() || !subLot.isEmpty() || !subQty.isEmpty()) {
				update(session, "EW substrate #" + slot, subSql,
						nzQty(subQty), slot, flex, headerId, subLot);
			}
			String over = text(p.get("overlaminate"));
			String overLot = text(p.get("overlaminate_lot_no"));
			String overQty = text(p.get("overlaminate_qty"));
			if (!over.isEmpty() || !overLot.isEmpty() || !overQty.isEmpty()) {
				update(session, "EW overlam #" + slot, overSql,
						nzQty(overQty), slot, headerId, over, overLot);
			}
			String w = text(p.get("poi_width"));
			String h = text(p.get("poi_height"));
			String unit = text(p.get("poi_unit"));
			String area = text(p.get("poi_area"));
			String poiQty = text(p.get("poi_qty"));
			String remarks = text(p.get("poi_remarks"));
			if (!w.isEmpty() || !h.isEmpty() || !unit.isEmpty() || !area.isEmpty()
					|| !poiQty.isEmpty() || !remarks.isEmpty()) {
				String dimension = area;
				if (dimension.isEmpty() && !w.isEmpty() && !h.isEmpty()) {
					try {
						dimension = String.valueOf(
								Double.parseDouble(w.replace(",", ""))
										* Double.parseDouble(h.replace(",", "")));
					} catch (NumberFormatException ignore) {
						dimension = "";
					}
					if (!dimension.isEmpty() && !unit.isEmpty()) {
						dimension = dimension + " (sq." + unit + ")";
					}
				}
				update(session, "EW POI #" + slot, poiSql,
						slot, headerId, w, h, unit, dimension, nzQty(poiQty), remarks,
						"1", text(p.get("poi_picture_path")), text(p.get("poi_picture_name")));
			}
		}
		String secSql = """
				insert into ew_new_request_sec_vinyl (
					prod_ref_code, ref_s_ref_data_code, sequence, vinyl, lot_no,
					quantity, color, created_date
				) values (?, ?, ?, ?, ?, ?, ?,
				"""
				+ nowSql + ")";
		int secSeq = 1;
		for (Map<String, Object> row : secVinyl) {
			String vinyl = text(row.get("vinyl"));
			if (vinyl.isEmpty()) {
				continue;
			}
			String slot = text(row.get("prod_sl_no"));
			if (slot.isEmpty()) {
				slot = "1";
			}
			update(session, "EW sec vinyl #" + slot, secSql,
					slot, headerId, String.valueOf(secSeq), vinyl,
					text(row.get("lot_no")), nzQty(row.get("quantity")), text(row.get("color")));
			secSeq++;
		}
		String addnlSql = """
				insert into ew_new_request_addnl_inv_details (
					ref_doc_code, prod_ref_code, ref_s_ref_data_code,
					ctc_invoice_no, ctc_invoice_date, created_date
				) values (?, ?, ?, ?, ?,
				"""
				+ nowSql + ")";
		int docSeq = 1;
		for (Map<String, Object> row : addnlInvoices) {
			String invNo = text(row.get("invoice_no"));
			String invDateRaw = text(row.get("invoice_date"));
			if (invNo.isEmpty() && invDateRaw.isEmpty()) {
				continue;
			}
			String invDate = "1990-01-01";
			if (!invDateRaw.isEmpty()) {
				try {
					invDate = sqlDate(invDateRaw, "Distributor invoice date");
				} catch (RuntimeException ex) {
					invDate = "1990-01-01";
				}
			}
			if (invDate == null || invDate.isBlank() || "0000-00-00".equals(invDate)) {
				invDate = "1990-01-01";
			}
			update(session, "EW addnl invoice #" + docSeq, addnlSql,
					String.valueOf(docSeq), "0", headerId, invNo, invDate);
			docSeq++;
		}
	}

	private void insertApprovalMatrix(Session session, String nowSql, long headerId,
			String wrtyTemplate, String autoClosed, String createdBy) {
		String cond;
		if ("Paint Protection Film".equalsIgnoreCase(wrtyTemplate)) {
			cond = " and matrix_for = 'PPF' and sequence <> '1' ";
		} else if ("Yes".equalsIgnoreCase(text(autoClosed))) {
			cond = " and matrix_for = 'Graphics' and sequence in ('1','5') ";
		} else {
			cond = " and matrix_for = 'Graphics' ";
		}
		String sql = "insert into ew_new_request_approval_matrix ("
				+ "pending_with_enl_id, ref_s_ref_data_code, ui_status, sequence, approval_src, "
				+ "approval_role, created_enl_id, created_date) "
				+ "select '', ?, ui_status, sequence, approval_type, approval_role, ?, " + nowSql + " "
				+ "from ew_approval_matrix with (nolock) where 1=1 " + cond + " order by sequence";
		update(session, "EW approval matrix", sql, headerId, createdBy);
	}

	private void updateApproverEnl(Session session, long headerId) {
		update(session, "EW KAM/ASM matrix", """
				update ew_new_request_approval_matrix
				set pending_with_enl_id = (
					select ia.enl_id
					from ew_new_request_header en with (nolock)
					inner join ia_user_master ia with (nolock) on ia.enl_id = en.asm_kam_approver
					where en.internal_code = ?
				)
				where ref_s_ref_data_code = ? and approval_role = 'KAM/ASM'
				""", headerId, headerId);
		update(session, "EW Segment Leader matrix", """
				update ew_new_request_approval_matrix
				set pending_with_enl_id = (
					select ia.enl_id
					from ew_new_request_header en with (nolock)
					inner join ia_user_master ia with (nolock) on ia.enl_id = en.segment_leader
					where en.internal_code = ?
				)
				where ref_s_ref_data_code = ? and approval_role = 'Segment Leader'
				""", headerId, headerId);
	}

	private String nextReqId(Session session, String nowSql) {
		int updated = update(session, "EW ticket number",
				"update ew_code_generator set last_no = last_no + 1 "
						+ "where year_code = year(" + nowSql + ") and type = ?",
				"Warranty Request");
		if (updated != 1) {
			throw new IllegalStateException(
					"E-Warranty request numbering is not configured for this year.");
		}
		String sql = "select cast(last_no as varchar(20)) as last_no, "
				+ "right(left(convert(varchar, " + nowSql + ", 112), 6), 4) as month_year "
				+ "from ew_code_generator with (nolock) "
				+ "where year_code = year(" + nowSql + ") and type = ?";
		List<Map<String, Object>> rows = NativeQuerySupport.executeQueryInSession(
				session, sql, "Warranty Request");
		if (rows.isEmpty()) {
			throw new IllegalStateException(
					"E-Warranty request numbering is not configured for this year.");
		}
		String number = text(rows.get(0).get("last_no")).split("\\.")[0];
		String monthYear = text(rows.get(0).get("month_year"));
		return monthYear + "0".repeat(Math.max(0, 5 - number.length())) + number;
	}

	private long headerIdForReqId(Session session, String reqId) {
		List<Map<String, Object>> rows = NativeQuerySupport.executeQueryInSession(session, """
				select cast(internal_code as varchar(20)) as internal_code
				from ew_new_request_header with (nolock)
				where req_id = ?
				""", reqId);
		if (rows.isEmpty()) {
			throw new IllegalStateException("The warranty request was not saved (no id for " + reqId + ").");
		}
		return Long.parseLong(text(rows.get(0).get("internal_code")));
	}

	private static int update(Session session, String label, String sql, Object... parameters) {
		logger.info("{}: {}", label, SqlDebugFormatter.render(sql, parameters));
		return NativeQuerySupport.executeUpdateInSession(session, sql, parameters);
	}

	private static void rollback(Transaction transaction) {
		if (transaction != null && transaction.isActive()) {
			transaction.rollback();
		}
	}

	private static void require(String value, String message) {
		if (value == null || value.isBlank()) {
			throw new IllegalArgumentException(message);
		}
	}

	private static String nz(Object value) {
		String v = text(value);
		return v.isEmpty() ? "0" : v;
	}

	private static String nzQty(Object value) {
		String v = text(value);
		return v.isEmpty() ? "0" : v;
	}

	private static int intVal(Object value, int fallback) {
		String v = text(value);
		if (v.isEmpty()) {
			return fallback;
		}
		try {
			return Integer.parseInt(v.split("\\.")[0]);
		} catch (NumberFormatException ex) {
			return fallback;
		}
	}
}
