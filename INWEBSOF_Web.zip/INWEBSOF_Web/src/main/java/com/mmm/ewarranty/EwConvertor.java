package com.mmm.ewarranty;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Converter persona APIs for CSD graphic E-Warranty.
 * Datasource: {@link HibernateFactoryRegistry#CSD} ({@code dINTWSYS}).
 */
@RestController
@RequestMapping("/api/customer/ewarranty/converter")
public class EwConvertor {
	private static final Logger logger = LoggerFactory.getLogger(EwConvertor.class);
	private static final Gson GSON = new Gson();

	private final EwRequestsSql sql;
	private final EwContext context;

	public EwConvertor(HibernateFactoryRegistry registry) {
		this.sql = new EwRequestsSql(registry);
		this.context = new EwContext(sql);
	}

	@GetMapping("/context")
	public String context(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			result.SetSuccess("success", working.toMap());
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/requests")
	public String requests(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("requests", sql.requestsByConvertor(working.internalCode()));
			data.putAll(working.toMap());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/** Legacy EWReqPopup.GetApprovalDetailsForPopup (converter-owned). */
	@GetMapping("/requests/{id}")
	public String requestPopup(HttpServletRequest request,
			@PathVariable("id") long id,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			Map<String, Object> data = sql.popupForConvertor(id, working.internalCode());
			if (data == null) {
				throw new IllegalArgumentException("Request not found for this converter.");
			}
			data.putAll(working.toMap());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	private String error(ResponseDataGeneric result, Exception ex) {
		String message = ex.getMessage() == null ? "Unexpected error." : ex.getMessage();
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(message)) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "error", message);
		} else if (ex instanceof IllegalArgumentException) {
			result.SetError(1, "error", message);
		} else {
			logger.error("E-Warranty converter API failed", ex);
			result.SetError(1, "error", message);
		}
		return GSON.toJson(result);
	}
}
