package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;
import com.mmm.titpl.SqlDebugFormatter;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Search-criteria autocompletes for CSD graphic E-Warranty.
 * Suggestions match code or name; callers send only {@code code} when filtering.
 */
@RestController
@RequestMapping("/api/customer/ewarranty/autocomplete")
public class CsdAutocomplete {
	private static final Logger logger = LoggerFactory.getLogger(CsdAutocomplete.class);
	private static final Gson GSON = new Gson();

	private static final String REQ_ID_SQL = """
			select distinct top 30
				isnull(en.req_id, '') as code,
				'' as name,
				isnull(en.req_id, '') as value
			from ew_new_request_header en with (nolock)
			where isnull(en.req_id, '') != ''
				and en.req_id like ?
				and cast(%s as varchar(20)) = ?
			order by value
			""";

	private static final String DIST_SQL = """
			select top 30
				isnull(code, '') as code,
				isnull(name, '') as name,
				isnull(code, '') + '-' + isnull(name, '') as value
			from ew_distributor with (nolock)
			where isnull(code, '') like ? or isnull(name, '') like ?
			order by code
			""";

	private static final String CONV_SQL = """
			select top 30
				isnull(code, '') as code,
				isnull(company_name, '') as name,
				isnull(code, '') + '-' + isnull(company_name, '') as value
			from ew_convertor with (nolock)
			where isnull(code, '') like ? or isnull(company_name, '') like ?
			order by code
			""";

	private static final String CUST_SQL = """
			select distinct top 30 code, name, value from (
				select
					isnull(ecc.code, '') as code,
					isnull(ecc.company_name, '') as name,
					isnull(ecc.code, '') + ' - ' + isnull(ecc.company_name, '') as value
				from ew_conv_customer ecc with (nolock)
				where isnull(ecc.code, '') like ? or isnull(ecc.company_name, '') like ?
				union
				select
					isnull(en.ppf_cust_company_name, '') as code,
					isnull(en.ppf_cust_company_name, '') as name,
					isnull(en.ppf_cust_company_name, '') as value
				from ew_new_request_header en with (nolock)
				where isnull(en.ppf_cust_company_name, '') != ''
					and en.ppf_cust_company_name like ?
					and cast(%s as varchar(20)) = ?
			) x
			order by value
			""";

	private final HibernateFactoryRegistry registry;
	private final EwContext context;

	public CsdAutocomplete(HibernateFactoryRegistry registry) {
		this.registry = registry;
		this.context = new EwContext(new EwRequestsSql(registry));
	}

	@GetMapping
	public String search(HttpServletRequest request,
			@RequestParam("type") String type,
			@RequestParam(value = "phrase", required = false) String phrase,
			@RequestParam(value = "persona", required = false) String persona,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Owner owner = resolveOwner(request, persona, custCode, loginId);
			String kind = text(type).toLowerCase(Locale.ROOT);
			String like = "%" + text(phrase) + "%";
			List<Map<String, Object>> rows = switch (kind) {
				case "requestid", "req_id", "request_id" -> queryReqId(like, owner);
				case "distributor" -> query(DIST_SQL, like, like);
				case "converter" -> query(CONV_SQL, like, like);
				case "customer" -> queryCustomer(like, owner);
				default -> throw new IllegalArgumentException("Unknown autocomplete type.");
			};
			result.SetSuccess("success", rows);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	private Owner resolveOwner(HttpServletRequest request, String persona, String custCode,
			String loginId) {
		String p = text(persona).toLowerCase(Locale.ROOT);
		if (p.startsWith("dist")) {
			EwContext.WorkingDistributor dist =
					context.resolveDistributor(request.getSession(false), custCode, loginId);
			return new Owner("en.distributor", dist.internalCode());
		}
		EwContext.WorkingConvertor conv =
				context.resolveConvertor(request.getSession(false), custCode, loginId);
		return new Owner("en.converter", conv.internalCode());
	}

	private List<Map<String, Object>> queryReqId(String like, Owner owner) {
		String sql = String.format(REQ_ID_SQL, owner.ownerColumn());
		return query(sql, like, String.valueOf(owner.id()));
	}

	private List<Map<String, Object>> queryCustomer(String like, Owner owner) {
		String sql = String.format(CUST_SQL, owner.ownerColumn());
		return query(sql, like, like, like, String.valueOf(owner.id()));
	}

	private List<Map<String, Object>> query(String sql, Object... params) {
		logger.info("CSD autocomplete: {}", SqlDebugFormatter.render(sql, params));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql, params);
		return rows == null ? new ArrayList<>() : rows;
	}

	private String error(ResponseDataGeneric result, Exception ex) {
		String message = ex.getMessage() == null ? "Unexpected error." : ex.getMessage();
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(message)) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "error", message);
		} else if (ex instanceof IllegalArgumentException) {
			result.SetError(1, "error", message);
		} else {
			logger.error("CSD autocomplete failed", ex);
			result.SetError(1, "error", message);
		}
		return GSON.toJson(result);
	}

	private record Owner(String column, long id) {
		String ownerColumn() {
			return "en.distributor".equals(column) ? "en.distributor" : "en.converter";
		}
	}
}
