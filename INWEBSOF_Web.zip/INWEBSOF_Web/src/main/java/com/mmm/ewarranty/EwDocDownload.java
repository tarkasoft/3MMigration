package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Stored EW document download (legacy {@code DownlodEWFilesFromServer}).
 * Invoice / proof / agreement files from mount ({@code inpc.ewarranty.mount-root}/EWARANTY/…).
 */
@RestController
@RequestMapping("/api/customer/ewarranty")
public class EwDocDownload {
	private static final Logger logger = LoggerFactory.getLogger(EwDocDownload.class);

	private final EwContext context;
	private final EwRequestsSql sql;
	private final EwFileStore files;

	public EwDocDownload(HibernateFactoryRegistry registry, EwFileStore files) {
		this.sql = new EwRequestsSql(registry);
		this.context = new EwContext(sql);
		this.files = files;
	}

	@GetMapping("/converter/requests/{id}/files/download")
	public ResponseEntity<byte[]> converterFile(HttpServletRequest request,
			@PathVariable("id") long id,
			@RequestParam(value = "fileName", required = false) String fileName,
			@RequestParam(value = "filePath", required = false) String filePath,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			EwContext.WorkingConvertor working =
					context.resolveConvertor(request.getSession(false), custCode, loginId);
			return download(id, "en.converter", working.internalCode(), fileName, filePath);
		} catch (Exception ex) {
			return fail(id, ex);
		}
	}

	@GetMapping("/distributor/requests/{id}/files/download")
	public ResponseEntity<byte[]> distributorFile(HttpServletRequest request,
			@PathVariable("id") long id,
			@RequestParam(value = "fileName", required = false) String fileName,
			@RequestParam(value = "filePath", required = false) String filePath,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			EwContext.WorkingDistributor working =
					context.resolveDistributor(request.getSession(false), custCode, loginId);
			return download(id, "en.distributor", working.internalCode(), fileName, filePath);
		} catch (Exception ex) {
			return fail(id, ex);
		}
	}

	private ResponseEntity<byte[]> download(long id, String ownerColumn, long ownerId,
			String fileName, String filePath) {
		String path = text(filePath);
		String name = text(fileName);
		if (path.isBlank() && name.isBlank()) {
			throw new IllegalArgumentException("Document path is missing.");
		}
		if (!sql.storedFileOnOwnedRequest(id, ownerColumn, ownerId, path, name)) {
			throw new IllegalArgumentException("Document was not found for this request.");
		}
		byte[] bytes = files.readQuietly(path, name);
		if (bytes.length == 0 && !path.isBlank()) {
			bytes = files.readQuietly(path, "");
		}
		if (bytes.length == 0 && !name.isBlank()) {
			bytes = files.readQuietly(name, name);
		}
		if (bytes.length == 0) {
			throw new IllegalArgumentException("Document was not found on the file share.");
		}
		String display = name.isBlank() ? path : name;
		int slash = display.replace('\\', '/').lastIndexOf('/');
		if (slash >= 0) {
			display = display.substring(slash + 1);
		}
		if (display.isBlank()) {
			display = "document";
		}
		String lower = display.toLowerCase(Locale.ROOT);
		MediaType type = lower.endsWith(".pdf") ? MediaType.APPLICATION_PDF
				: (lower.endsWith(".png") ? MediaType.IMAGE_PNG
				: (lower.endsWith(".jpg") || lower.endsWith(".jpeg") ? MediaType.IMAGE_JPEG
				: MediaType.APPLICATION_OCTET_STREAM));
		logger.info("EW file download requestId={} name={} bytes={}", id, display, bytes.length);
		return ResponseEntity.ok()
				.contentType(type)
				.header(HttpHeaders.CONTENT_DISPOSITION,
						ContentDisposition.attachment().filename(display).build().toString())
				.header("X-Content-Type-Options", "nosniff")
				.body(bytes);
	}

	private ResponseEntity<byte[]> fail(long id, Exception ex) {
		HttpStatus status = HttpStatus.BAD_REQUEST;
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			status = HttpStatus.UNAUTHORIZED;
		} else if (!(ex instanceof IllegalArgumentException)) {
			status = HttpStatus.BAD_GATEWAY;
			logger.error("EW file download failed requestId={}", id, ex);
		} else {
			logger.warn("EW file download rejected: {}", ex.getMessage());
		}
		return ResponseEntity.status(status).build();
	}
}
