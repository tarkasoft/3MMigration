package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

/**
 * CSD graphic E-Warranty SQL against {@code dINTWSYS}
 * ({@link HibernateFactoryRegistry#CSD}).
 */
final class EwRequestsSql {
	private static final Logger logger = LoggerFactory.getLogger(EwRequestsSql.class);

	private static final String CONVERTOR_BY_CODE_SQL = """
			select
				cast(internal_code as varchar(20)) as internal_code,
				isnull(code, '') as code,
				isnull(company_name, '') as company_name,
				isnull(code, '') + '-' + isnull(company_name, '') as display
			from ew_convertor with (nolock)
			where cast(code as varchar(50)) = ?
			""";

	private static final String CONVERTOR_COUNT_SQL = """
			select count(*) as cnt
			from ew_convertor with (nolock)
			where cast(code as varchar(50)) = ?
			""";

	private static final String DISTRIBUTOR_BY_CODE_SQL = """
			select
				cast(internal_code as varchar(20)) as internal_code,
				isnull(code, '') as code,
				isnull(name, '') as name,
				isnull(code, '') + '-' + isnull(name, '') as display
			from ew_distributor with (nolock)
			where cast(code as varchar(50)) = ?
			""";

	private static final String REQUESTS_BY_CONVERTOR_SQL = """
			select
				cast(en.internal_code as varchar(20)) as req_int_code,
				isnull(en.req_id, '') as req_id,
				isnull(convert(varchar(10), en.req_date, 103), '') as request_date,
				isnull(en.wrty_type, '') as wrty_type,
				isnull(ec.code + '-' + ec.name, '') as distributor,
				isnull(ec.code, '') as dist_code,
				case
					when isnull(en.ppf_cust_company_name, '') != ''
						then isnull(en.ppf_cust_company_name, '')
					else isnull(ecc.code + ' - ' + ecc.company_name, '')
				end as customer,
				isnull(ecc.code, '') as cust_code,
				isnull(en.status, '') as status,
				isnull(con.code + '-' + con.company_name, '') as converter,
				isnull(con.code, '') as conv_code,
				isnull(en.wrty_template, '') as wrty_template
			from ew_new_request_header en with (nolock)
			left join ew_distributor ec with (nolock) on ec.internal_code = en.distributor
			left join ew_conv_customer ecc with (nolock) on ecc.internal_code = en.customer
			left join ew_convertor con with (nolock) on con.internal_code = en.converter
			where cast(en.converter as varchar(20)) = ?
			order by en.internal_code desc
			""";

	private static final String REQUESTS_BY_DISTRIBUTOR_SQL = """
			select
				cast(en.internal_code as varchar(20)) as req_int_code,
				isnull(en.req_id, '') as req_id,
				isnull(convert(varchar(10), en.req_date, 103), '') as request_date,
				isnull(en.wrty_type, '') as wrty_type,
				isnull(ec.code + '-' + ec.name, '') as distributor,
				isnull(ec.code, '') as dist_code,
				case
					when isnull(en.ppf_cust_company_name, '') != ''
						then isnull(en.ppf_cust_company_name, '')
					else isnull(ecc.code + ' - ' + ecc.company_name, '')
				end as customer,
				isnull(ecc.code, '') as cust_code,
				isnull(en.status, '') as status,
				isnull(con.code + '-' + con.company_name, '') as converter,
				isnull(con.code, '') as conv_code,
				isnull(en.wrty_template, '') as wrty_template
			from ew_new_request_header en with (nolock)
			left join ew_distributor ec with (nolock) on ec.internal_code = en.distributor
			left join ew_conv_customer ecc with (nolock) on ecc.internal_code = en.customer
			left join ew_convertor con with (nolock) on con.internal_code = en.converter
			where cast(en.distributor as varchar(20)) = ?
			order by en.internal_code desc
			""";

	/** Legacy EWReqWarranty.GetEditModeHeaderDetail. */
	private static final String REQUEST_DETAIL_SQL = """
			select
				isnull(en.project_name, '') as project_name,
				isnull(en.remarks, '') as remarks,
				isnull(en.ppf_cust_phone, '') as ppf_cust_phone,
				isnull(en.ppf_cust_email, '') as ppf_cust_email,
				isnull(en.ppf_cust_address_1, '') as ppf_cust_address_1,
				isnull(en.ppf_cust_address_2, '') as ppf_cust_address_2,
				isnull(en.ppf_cust_city, '') as ppf_cust_city,
				isnull(en.ppf_cust_state, '') as ppf_cust_state,
				isnull(en.ppf_cust_pin, '') as ppf_cust_pin,
				isnull(en.ppf_cust_company_name, '') as ppf_cust_company_name,
				cast(en.internal_code as varchar(20)) as req_int_code,
				isnull(cast(en.sequence as varchar(20)), '0') as sequence,
				isnull(en.pending_with_role, '') as pending_with_role,
				isnull(en.pending_with_src, '') as pending_with_type,
				isnull(en.status, 'New') as status,
				isnull(d.code + ' - ' + d.name, '') as distributor,
				case
					when isnull(en.ppf_cust_company_name, '') != ''
						then isnull(en.ppf_cust_company_name, '')
					else isnull(c.code + ' - ' + c.company_name, '')
				end as customer,
				isnull(c.code + ' - ' + c.company_name, '') as other_company_customer,
				isnull(en.req_id, '') as req_id,
				isnull(en.wrty_type, '') as wrty_type,
				isnull(en.wrty_template, '') as wrty_template,
				isnull(en.ctc_inv_no, '') as ctc_inv_no,
				isnull(convert(varchar(10), en.ctc_inv_date, 103), '') as ctc_inv_date,
				isnull(en.addnl_inv_no, '') as addnl_inv_no,
				isnull(convert(varchar(10), en.addnl_inv_date, 103), '') as addnl_inv_date,
				isnull(convert(varchar(10), en.date_of_inst, 103), '') as date_of_inst,
				isnull(en.end_cust_name, '') as end_cust_name,
				isnull(en.address_1, '') as address_1,
				isnull(en.address_2, '') as address_2,
				isnull(en.city, '') as city,
				isnull(en.state, '') as state,
				isnull(en.postal_code, '') as postal_code,
				isnull(en.vehicle, '') as vehicle,
				isnull(en.reg_no, '') as reg_no,
				isnull(en.v_end_cust_name, '') as v_end_cust_name,
				isnull(en.v_address_1, '') as v_address_1,
				isnull(en.v_address_2, '') as v_address_2,
				isnull(en.v_city, '') as v_city,
				isnull(en.v_state, '') as v_state,
				isnull(en.v_postal_code, '') as v_postal_code,
				isnull(en.v_email_id, '') as v_email_id,
				isnull(en.v_cust_mob_no, '') as v_cust_mob_no,
				isnull(en.v_fax_no, '') as v_fax_no,
				isnull(en.v_car_model, '') as v_car_model,
				isnull(en.v_odometer_rd, '') as v_odometer_rd,
				isnull(en.v_vin_no, '') as v_vin_no,
				isnull(en.v_inst_place, '') as v_inst_place,
				isnull(en.v_applicator_name, '') as v_applicator_name,
				isnull(en.v_appl_cert_no, '') as v_appl_cert_no,
				isnull(en.v_to_app, '') as v_to_app,
				isnull(en.application, '') as application,
				isnull(en.proj_no, '') as proj_no,
				isnull(en.market_cat, '') as market_cat,
				isnull(en.print_hw, '') as print_hw,
				isnull(convert(varchar(10), en.req_date, 103), '') as req_date,
				isnull(convert(varchar(10), en.req_date, 103), '') as request_date,
				isnull(cast(c.internal_code as varchar(20)), '') as cust_int_code,
				isnull(cast(d.internal_code as varchar(20)), '') as dist_int_code,
				isnull(ap.code + ' - ' + ap.company_name, '') as applicator,
				isnull(cast(en.applicator as varchar(20)), '0') as applicator_int_code,
				isnull(en.inst_type, 'Non Vehicle') as inst_type,
				isnull(c.address1, '') + isnull(c.address2, '') as cust_address,
				isnull(c.city, '') as cust_city,
				isnull(s4.name, '') as cust_state,
				isnull(c.phone_no, '') as cust_phone_no,
				isnull(c.email, '') as cust_email,
				isnull(d.address1, '') + isnull(d.address2, '') as dist_address,
				isnull(d.city, '') as dist_city,
				isnull(s1.name, '') as dist_state,
				isnull(d.phone_no, '') as dist_phone_no,
				isnull(d.email, '') as dist_email,
				isnull(ap.address1, '') + isnull(ap.address2, '') as app_address,
				isnull(ap.city, '') as app_city,
				isnull(s3.name, '') as app_state,
				isnull(ap.phone_no, '') as app_phone_no,
				isnull(ap.email, '') as app_email,
				isnull(con.code + '-' + con.company_name, '') as converter,
				isnull(con.code, '') as conv_code,
				isnull(con.company_name, '') as conv_name,
				isnull(con.address1, '') + isnull(con.address2, '') as conv_address,
				isnull(con.city, '') as conv_city,
				isnull(s2.name, '') as conv_state,
				isnull(con.phone_no, '') as conv_phone_no,
				isnull(con.email, '') as conv_email,
				isnull(ec.code + '-' + ec.name, '') as end_customer,
				isnull(cast(en.end_cust_int_code as varchar(20)), '0') as end_cust_int_code,
				isnull(en.partial_application_remarks, '') as partial_application_remarks,
				isnull(en.proj_type, '') as proj_type,
				isnull(ia.enl_id + '-' + ia.name, '') as segment_leader,
				isnull(ka.enl_id, '') as asm_kam_approver,
				isnull(en.segment_leader, '') as segment_leader_int_code,
				isnull(en.print_service_provider, '') as print_service_provider,
				isnull(en.branch_site_name, '') as branch_site_name,
				isnull(en.branch_id, '') as branch_id,
				isnull(en.no_of_products, '0') as no_of_products
			from ew_new_request_header en with (nolock)
			left join ew_conv_customer c with (nolock) on c.internal_code = en.customer
			left join ew_distributor d with (nolock) on d.internal_code = en.distributor
			left join ew_applicator ap with (nolock) on ap.internal_code = en.applicator
			left join ew_convertor con with (nolock) on con.internal_code = en.converter
			left join ew_end_customer ec with (nolock) on ec.internal_code = en.end_cust_int_code
			left join ia_user_master ia with (nolock) on ia.enl_id = en.segment_leader
			left join ia_user_master ka with (nolock) on ka.enl_id = en.asm_kam_approver
			left join tk_state s1 with (nolock) on s1.internal_code = d.state
			left join tk_state s2 with (nolock) on s2.internal_code = con.state
			left join tk_state s3 with (nolock) on s3.internal_code = ap.state
			left join tk_state s4 with (nolock) on s4.internal_code = c.state
			where cast(en.internal_code as varchar(20)) = ?
				and cast(%s as varchar(20)) = ?
			""";

	private static final String VINYL_SQL = """
			select
				isnull(vinyl, '') as vinyl,
				isnull(lot_no, '') as lot_no,
				isnull(cast(quantity as varchar(50)), '') as quantity,
				isnull(color, '') as color,
				isnull(prod_ref_code, '0') as prod_ref_code,
				isnull(ink, '') as ink,
				isnull(printer_format, '') as printer_format,
				isnull(printing_hardware, '') as printing_hardware,
				isnull(edge_sealer, '') as edge_sealer,
				isnull(type_of_exposure, '') as type_of_exposure,
				isnull(graphic_conv_method, '') as graphic_conv_method,
				isnull(application, '') as application,
				isnull(substrate, '') as substrate,
				isnull(vinyl_unique_lot_no, '') as vinyl_unique_lot_no,
				isnull(warranty_life, '0') as warranty_life
			from ew_new_request_vinyl with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			order by prod_ref_code, sequence
			""";

	private static final String SEC_VINYL_SQL = """
			select
				isnull(prod_ref_code, '') as prod_ref_code,
				isnull(vinyl, '') as vinyl,
				isnull(lot_no, '') as lot_no,
				isnull(color, '') as color,
				isnull(cast(quantity as varchar(50)), '') as quantity,
				isnull(cast(sequence as varchar(10)), '') as sequence
			from ew_new_request_sec_vinyl with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String SUBSTRATE_SQL = """
			select
				isnull(substrate_lot_no, '') as substrate_lot_no,
				isnull(prod_ref_code, '0') as prod_ref_code,
				isnull(m_flexible_substrate, '') as m_flexible_substrate,
				isnull(cast(quantity as varchar(50)), '0') as quantity
			from ew_new_request_subs_lot_no with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String OVERLAM_SQL = """
			select
				isnull(cast(quantity as varchar(50)), '0') as quantity,
				isnull(overlaminate, '') as overlaminate,
				isnull(overlaminate_lot_no, '') as overlaminate_lot_no,
				isnull(prod_ref_code, '0') as prod_ref_code
			from ew_new_request_overlam_lot_no with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String POI_SQL = """
			select
				isnull(prod_ref_code, '0') as prod_ref_code,
				isnull(cast(width as varchar(50)), '') as width,
				isnull(cast(height as varchar(50)), '') as height,
				isnull(unit, '') as unit,
				isnull(dimension, '') as dimension,
				isnull(cast(quantity as varchar(50)), '') as quantity,
				isnull(description, '') as description,
				isnull(picture_path, '') as picture_path,
				isnull(picture_name, '') as picture_name,
				isnull(cast(sequence as varchar(10)), '0') as sequence
			from ew_new_request_proof_inst with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String DOC_SQL = """
			select
				isnull(file_name, '') as ftp_file_name,
				isnull(file_path, '') as ftp_file_path,
				isnull(ctc_invoice_no, '') as ctc_invoice_no,
				isnull(convert(varchar(10), ctc_invoice_date, 103), '') as ctc_invoice_date,
				isnull(cast(ref_doc_code as varchar(20)), '0') as row_sequence,
				isnull(prod_ref_code, '') as prod_ref_code
			from %s with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			""";

	private static final String REQUEST_OWNED_SQL = """
			select top 1 1 as ok
			from ew_new_request_header en with (nolock)
			where cast(en.internal_code as varchar(20)) = ?
				and cast(%s as varchar(20)) = ?
			""";

	private static final String FILE_ON_INV_SQL = """
			select top 1 1 as ok
			from %s with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and (
					replace(lower(isnull(file_path, '')), '\\', '/') = ?
					or replace(lower(isnull(file_name, '')), '\\', '/') = ?
					or replace(lower(isnull(file_path, '')), '\\', '/')
						+ '/' + replace(lower(isnull(file_name, '')), '\\', '/') = ?
				)
			""";

	private static final String FILE_ON_POI_SQL = """
			select top 1 1 as ok
			from ew_new_request_proof_inst with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
				and (
					replace(lower(isnull(picture_path, '')), '\\', '/') = ?
					or replace(lower(isnull(picture_name, '')), '\\', '/') = ?
					or replace(lower(isnull(picture_path, '')), '\\', '/')
						+ '/' + replace(lower(isnull(picture_name, '')), '\\', '/') = ?
				)
			""";

	private static final String APPROVAL_SQL = """
			select
				isnull(cast(arh.internal_code as varchar(20)), '') as internal_code,
				isnull(arh.ui_status, '') as approver_role,
				case
					when arh.approval_src = 'Distributor' then 'Distributor'
					else isnull(iaa.name, '')
				end as approver,
				isnull(arh.approval_status, '') as approval_status,
				isnull(arh.approval_remarks, '') as approval_remarks,
				case
					when arh.modified_date is null or year(arh.modified_date) <= 1900
						then ''
					else convert(varchar(10), arh.modified_date, 103)
				end as modified_date
			from ew_new_request_approval_matrix arh with (nolock)
			left join ia_user_master ia with (nolock) on ia.enl_id = arh.updated_by
			left join ia_user_master iaa with (nolock) on iaa.enl_id = arh.pending_with_enl_id
			where cast(arh.ref_s_ref_data_code as varchar(20)) = ?
			order by arh.sequence
			""";

	private static final String HISTORY_SQL = """
			select
				isnull(approver_src, '') as approver_src,
				isnull(approver_role, '') as approver_role,
				isnull(updated_by_name, '') as updated_by_name,
				isnull(convert(varchar(20), created_date, 120), '') as created_date,
				isnull(approver_status, '') as approver_status,
				isnull(approver_remarks, '') as approver_remarks
			from ew_new_request_history with (nolock)
			where cast(ref_s_ref_data_code as varchar(20)) = ?
			order by created_date desc
			""";

	private final HibernateFactoryRegistry registry;

	EwRequestsSql(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	/** Legacy: prefer cust code on ew_convertor; else loginId as code. */
	Map<String, Object> convertorForLogin(String custCode, String loginId) {
		String cust = text(custCode);
		String login = text(loginId);
		if (!cust.isEmpty() && convertorCount(cust) > 0) {
			return convertorByCode(cust);
		}
		if (!login.isEmpty()) {
			return convertorByCode(login);
		}
		if (!cust.isEmpty()) {
			return convertorByCode(cust);
		}
		return null;
	}

	Map<String, Object> convertorByCode(String code) {
		String key = text(code);
		if (key.isEmpty()) {
			return null;
		}
		logger.info("EW convertor lookup: {}", SqlDebugFormatter.render(CONVERTOR_BY_CODE_SQL, key));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, CONVERTOR_BY_CODE_SQL, key);
		return rows.isEmpty() ? null : rows.get(0);
	}

	private int convertorCount(String code) {
		String key = text(code);
		if (key.isEmpty()) {
			return 0;
		}
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, CONVERTOR_COUNT_SQL, key);
		if (rows.isEmpty()) {
			return 0;
		}
		Object cnt = rows.get(0).get("cnt");
		if (cnt instanceof Number n) {
			return n.intValue();
		}
		try {
			return Integer.parseInt(text(cnt));
		} catch (NumberFormatException ex) {
			return 0;
		}
	}

	Map<String, Object> distributorByCode(String code) {
		String key = text(code);
		if (key.isEmpty()) {
			return null;
		}
		logger.info("EW distributor lookup: {}", SqlDebugFormatter.render(DISTRIBUTOR_BY_CODE_SQL, key));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, DISTRIBUTOR_BY_CODE_SQL, key);
		return rows.isEmpty() ? null : rows.get(0);
	}

	List<Map<String, Object>> requestsByConvertor(long convertorInternalCode) {
		if (convertorInternalCode <= 0) {
			return List.of();
		}
		String key = String.valueOf(convertorInternalCode);
		logger.info("EW convertor requests: {}", SqlDebugFormatter.render(REQUESTS_BY_CONVERTOR_SQL, key));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, REQUESTS_BY_CONVERTOR_SQL, key);
		return rows == null ? new ArrayList<>() : rows;
	}

	List<Map<String, Object>> requestsByDistributor(long distributorInternalCode) {
		if (distributorInternalCode <= 0) {
			return List.of();
		}
		String key = String.valueOf(distributorInternalCode);
		logger.info("EW distributor requests: {}", SqlDebugFormatter.render(REQUESTS_BY_DISTRIBUTOR_SQL, key));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, REQUESTS_BY_DISTRIBUTOR_SQL, key);
		return rows == null ? new ArrayList<>() : rows;
	}

	Map<String, Object> popupForConvertor(long requestId, long convertorInternalCode) {
		return popup(requestId, "en.converter", convertorInternalCode);
	}

	Map<String, Object> popupForDistributor(long requestId, long distributorInternalCode) {
		return popup(requestId, "en.distributor", distributorInternalCode);
	}

	boolean storedFileOnOwnedRequest(long requestId, String ownerColumn, long ownerId,
			String filePath, String fileName) {
		if (requestId <= 0 || ownerId <= 0) {
			return false;
		}
		String owner = "en.converter".equals(ownerColumn) ? "en.converter" : "en.distributor";
		String reqKey = String.valueOf(requestId);
		String ownKey = String.valueOf(ownerId);
		String ownedSql = String.format(REQUEST_OWNED_SQL, owner);
		if (!hasRow(ownedSql, reqKey, ownKey)) {
			return false;
		}
		String path = normalizeStored(filePath);
		String name = lastSegment(fileName);
		if (name.isEmpty()) {
			name = lastSegment(path);
		}
		String joined = path;
		if (!name.isEmpty() && !path.toLowerCase().endsWith("/" + name.toLowerCase())
				&& !path.equalsIgnoreCase(name)) {
			joined = path.isEmpty() ? name : path + "/" + name;
		}
		if (path.isEmpty() && name.isEmpty()) {
			return false;
		}
		String p = path.toLowerCase();
		String n = name.toLowerCase();
		String j = joined.toLowerCase();
		return hasFileOnInv("ew_new_request_conv_cust_inv_details", reqKey, p, n, j)
				|| hasFileOnInv("ew_new_request_addnl_inv_details", reqKey, p, n, j)
				|| hasFileOnInv("ew_new_request_dist_agree_doc", reqKey, p, n, j)
				|| hasRow(FILE_ON_POI_SQL, reqKey, p, n, j);
	}

	private boolean hasFileOnInv(String table, String reqKey, String path, String name, String joined) {
		if (!"ew_new_request_conv_cust_inv_details".equals(table)
				&& !"ew_new_request_addnl_inv_details".equals(table)
				&& !"ew_new_request_dist_agree_doc".equals(table)) {
			return false;
		}
		return hasRow(String.format(FILE_ON_INV_SQL, table), reqKey, path, name, joined);
	}

	private boolean hasRow(String sql, Object... params) {
		try {
			List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
					registry, HibernateFactoryRegistry.CSD, sql, params);
			return rows != null && !rows.isEmpty();
		} catch (RuntimeException ex) {
			logger.warn("EW file ownership query skipped: {}", ex.getMessage());
			return false;
		}
	}

	private static String normalizeStored(String raw) {
		String value = text(raw).replace('\\', '/').trim();
		if (value.regionMatches(true, 0, "smb:", 0, 4)) {
			value = value.substring(4);
		}
		while (value.startsWith("/")) {
			value = value.substring(1);
		}
		if (value.regionMatches(true, 0, "EWARANTY/", 0, 9)) {
			value = value.substring(9);
		}
		return value;
	}

	private static String lastSegment(String raw) {
		String value = normalizeStored(raw);
		int slash = value.lastIndexOf('/');
		return slash >= 0 ? value.substring(slash + 1) : value;
	}

	/** Same payload as legacy EWReqPopup.GetApprovalDetailsForPopup. */
	private Map<String, Object> popup(long requestId, String ownerColumn, long ownerId) {
		if (requestId <= 0 || ownerId <= 0) {
			return null;
		}
		String owner = "en.converter".equals(ownerColumn) ? "en.converter" : "en.distributor";
		String sql = String.format(REQUEST_DETAIL_SQL, owner);
		String reqKey = String.valueOf(requestId);
		String ownKey = String.valueOf(ownerId);
		logger.info("EW popup header: {}", SqlDebugFormatter.render(sql, reqKey, ownKey));
		List<Map<String, Object>> rows;
		try {
			rows = NativeQuerySupport.executeQuery(
					registry, HibernateFactoryRegistry.CSD, sql, reqKey, ownKey);
		} catch (RuntimeException ex) {
			logger.warn("EW popup header full SQL failed, retry without optional joins: {}",
					ex.getMessage());
			String fallback = sql
					.replace("left join ia_user_master ia with (nolock) on ia.enl_id = en.segment_leader", "")
					.replace("left join ia_user_master ka with (nolock) on ka.enl_id = en.asm_kam_approver", "")
					.replace("isnull(ia.enl_id + '-' + ia.name, '') as segment_leader", "'' as segment_leader")
					.replace("isnull(ka.enl_id, '') as asm_kam_approver", "'' as asm_kam_approver");
			rows = NativeQuerySupport.executeQuery(
					registry, HibernateFactoryRegistry.CSD, fallback, reqKey, ownKey);
		}
		if (rows == null || rows.isEmpty()) {
			return null;
		}
		Map<String, Object> header = rows.get(0);
		Map<String, Object> data = new LinkedHashMap<>();
		data.put("header_details", rows);
		data.put("header", header);
		data.put("poi_details", queryOptional(POI_SQL, reqKey));
		List<Map<String, Object>> vinyl = queryList(VINYL_SQL, reqKey);
		data.put("vinyl_edit_obj", vinyl);
		data.put("products", vinyl);
		data.put("sec_vinyl_edit_obj", queryOptional(SEC_VINYL_SQL, reqKey));
		data.put("substrate_edit_obj", queryOptional(SUBSTRATE_SQL, reqKey));
		data.put("overlaminate_edit_obj", queryOptional(OVERLAM_SQL, reqKey));
		data.put("ctc_doc_obj", queryDoc("ew_new_request_conv_cust_inv_details", reqKey));
		data.put("addnl_doc_obj", queryDoc("ew_new_request_addnl_inv_details", reqKey));
		data.put("approval_details", queryOptional(APPROVAL_SQL, reqKey));
		data.put("history_details", queryOptional(HISTORY_SQL, reqKey));
		data.put("dist_agree_doc_obj", queryDoc("ew_new_request_dist_agree_doc", reqKey));
		return data;
	}

	private List<Map<String, Object>> queryDoc(String table, String key) {
		if (!"ew_new_request_conv_cust_inv_details".equals(table)
				&& !"ew_new_request_addnl_inv_details".equals(table)
				&& !"ew_new_request_dist_agree_doc".equals(table)) {
			return List.of();
		}
		return queryOptional(String.format(DOC_SQL, table), key);
	}

	private List<Map<String, Object>> queryList(String sql, String key) {
		logger.info("EW popup query: {}", SqlDebugFormatter.render(sql, key));
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.CSD, sql, key);
		return rows == null ? new ArrayList<>() : rows;
	}

	private List<Map<String, Object>> queryOptional(String sql, String key) {
		if (key == null || key.isBlank()) {
			return List.of();
		}
		try {
			return queryList(sql, key);
		} catch (RuntimeException ex) {
			logger.warn("EW popup optional query skipped: {}", ex.getMessage());
			return List.of();
		}
	}
}
