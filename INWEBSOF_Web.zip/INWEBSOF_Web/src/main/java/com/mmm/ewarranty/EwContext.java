package com.mmm.ewarranty;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import com.mmm.authentication.UserSessionSupport;

import jakarta.servlet.http.HttpSession;

/**
 * Working converter or distributor for CSD graphic E-Warranty.
 *
 * Resolve order (portal Change Customer — same as CIR/Rebate/TSD):
 * <ol>
 *   <li>{@link UserSessionSupport#resolveProcedureCustomerContext}</li>
 *   <li>Map customer code onto {@code ew_convertor} or {@code ew_distributor}</li>
 * </ol>
 * Does not use TSD session keys.
 */
final class EwContext {

	private final EwRequestsSql sql;

	EwContext(EwRequestsSql sql) {
		this.sql = sql;
	}

	WorkingConvertor resolveConvertor(HttpSession session, String requestedCustCode, String requestedLoginId) {
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		UserSessionSupport.ProcedureCustomerContext portal =
				UserSessionSupport.resolveProcedureCustomerContext(
						session, requestedCustCode, requestedLoginId);
		String loginId = text(portal.loginId());
		String custCode = text(portal.custCode());
		if (custCode.isEmpty() && loginId.isEmpty()) {
			throw new IllegalArgumentException("No customer is selected for E-Warranty Converter.");
		}
		Map<String, Object> conv = sql.convertorForLogin(custCode, loginId);
		if (conv == null) {
			throw new IllegalArgumentException(
					"Customer is not mapped as a Converter in E-Warranty (ew_convertor).");
		}
		return WorkingConvertor.from(conv, loginId, portal.overridden());
	}

	WorkingDistributor resolveDistributor(HttpSession session, String requestedCustCode,
			String requestedLoginId) {
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		UserSessionSupport.ProcedureCustomerContext portal =
				UserSessionSupport.resolveProcedureCustomerContext(
						session, requestedCustCode, requestedLoginId);
		String loginId = text(portal.loginId());
		String custCode = text(portal.custCode());
		if (custCode.isEmpty()) {
			throw new IllegalArgumentException("No customer is selected for E-Warranty Distributor.");
		}
		Map<String, Object> dist = sql.distributorByCode(custCode);
		if (dist == null) {
			throw new IllegalArgumentException(
					"Customer is not mapped as a Distributor in E-Warranty (ew_distributor).");
		}
		return WorkingDistributor.from(dist, loginId, portal.overridden());
	}

	record WorkingConvertor(
			long internalCode,
			String code,
			String companyName,
			String display,
			String loginId,
			boolean overridden) {

		static WorkingConvertor from(Map<String, Object> row, String loginId, boolean overridden) {
			return new WorkingConvertor(
					parseLong(row.get("internal_code")),
					text(row.get("code")),
					text(row.get("company_name")),
					text(row.get("display")),
					text(loginId),
					overridden);
		}

		Map<String, Object> toMap() {
			Map<String, Object> map = new LinkedHashMap<>();
			map.put("persona", "converter");
			map.put("convIntCode", internalCode);
			map.put("convCode", code);
			map.put("convName", companyName);
			map.put("convDisplay", display);
			map.put("custCode", code);
			map.put("loginId", loginId);
			map.put("overridden", overridden);
			map.put("source", overridden ? "change_customer" : "login");
			return map;
		}
	}

	record WorkingDistributor(
			long internalCode,
			String code,
			String name,
			String display,
			String loginId,
			boolean overridden) {

		static WorkingDistributor from(Map<String, Object> row, String loginId, boolean overridden) {
			return new WorkingDistributor(
					parseLong(row.get("internal_code")),
					text(row.get("code")),
					text(row.get("name")),
					text(row.get("display")),
					text(loginId),
					overridden);
		}

		Map<String, Object> toMap() {
			Map<String, Object> map = new LinkedHashMap<>();
			map.put("persona", "distributor");
			map.put("distIntCode", internalCode);
			map.put("distCode", code);
			map.put("distName", name);
			map.put("distDisplay", display);
			map.put("custCode", code);
			map.put("loginId", loginId);
			map.put("overridden", overridden);
			map.put("source", overridden ? "change_customer" : "login");
			return map;
		}
	}

	private static long parseLong(Object value) {
		String s = text(value);
		if (s.isEmpty()) {
			return 0L;
		}
		try {
			return Long.parseLong(s.trim());
		} catch (NumberFormatException ex) {
			return 0L;
		}
	}

	@SuppressWarnings("unused")
	private static boolean isCustomer(String userType) {
		String t = text(userType).toLowerCase(Locale.ROOT);
		return t.contains("customer") || t.contains("distributor") || t.contains("converter");
	}
}
