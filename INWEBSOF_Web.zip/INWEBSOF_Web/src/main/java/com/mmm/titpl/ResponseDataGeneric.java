package com.mmm.titpl;

/**
 * Compatibility wrapper matching legacy ResponseDataGeneric JSON shape.
 */
public class ResponseDataGeneric {

    private int errorCode;
    private String status;
    private String message;
    private Object data;

    public void SetSuccess(String status, Object data) {
        this.errorCode = 0;
        this.status = status;
        this.message = status;
        this.data = data;
    }

    public void SetError(int errorCode, String status, String message) {
        this.errorCode = errorCode;
        this.status = status;
        this.message = message;
        this.data = null;
    }

    public int getErrorCode() { return errorCode; }
    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public Object getData() { return data; }
}