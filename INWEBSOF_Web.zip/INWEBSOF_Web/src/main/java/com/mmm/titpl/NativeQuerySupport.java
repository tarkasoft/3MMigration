package com.mmm.titpl;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.query.NativeQuery;
import org.hibernate.type.BasicTypeReference;
import org.hibernate.type.StandardBasicTypes;

import com.mmm.config.HibernateFactoryRegistry;

/**
 * Shared native-SQL helpers (RoleRights-style Map results).
 */
public final class NativeQuerySupport {

    private NativeQuerySupport() {}

    /**
     * Run a full native SELECT (no bind parameters).
     * Opens a session on {@code datasourceName}, executes SQL, closes session.
     * On any failure throws {@link RuntimeException} (cause preserved).
     *
     * @return list of row maps (column label -> value); empty list if no rows
     */
    public static List<Map<String, Object>> executeQuery(HibernateFactoryRegistry registry,
                                                         String datasourceName,
                                                         String sql) {
        if (registry == null) {
            throw new IllegalArgumentException("registry is required");
        }
        if (datasourceName == null || datasourceName.isBlank()) {
            throw new IllegalArgumentException("datasourceName is required");
        }
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("sql is required");
        }
        try {
            return registry.withSession(datasourceName, session -> executeQuery(session, sql));
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException("Native query failed on datasource '" + datasourceName + "': " + ex.getMessage(), ex);
        }
    }

    /**
     * Run a parameterized native SELECT and map each result row by column label.
     * Values are bound through JDBC; they must not be concatenated into SQL.
     */
    public static List<Map<String, Object>> executeQuery(
            HibernateFactoryRegistry registry,
            String datasourceName,
            String sql,
            Object... parameters) {
        if (registry == null) {
            throw new IllegalArgumentException("registry is required");
        }
        if (datasourceName == null || datasourceName.isBlank()) {
            throw new IllegalArgumentException("datasourceName is required");
        }
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("sql is required");
        }
        try {
            return registry.withSession(datasourceName, session -> executeQueryInSession(session, sql, parameters));
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(
                    "Native query failed on datasource '" + datasourceName + "': " + ex.getMessage(), ex);
        }
    }

    /**
     * Execute a parameterized native INSERT, UPDATE, or DELETE in a transaction.
     * The session is opened and closed by the registry.
     *
     * @return the number of affected rows
     */
    public static int executeUpdate(
            HibernateFactoryRegistry registry,
            String datasourceName,
            String sql,
            Object... parameters) {
        if (registry == null) {
            throw new IllegalArgumentException("registry is required");
        }
        if (datasourceName == null || datasourceName.isBlank()) {
            throw new IllegalArgumentException("datasourceName is required");
        }
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("sql is required");
        }
        return registry.withSession(datasourceName, session -> {
            org.hibernate.Transaction transaction = session.beginTransaction();
            try {
                int affected = executeUpdateInSession(session, sql, parameters);
                transaction.commit();
                return affected;
            } catch (RuntimeException ex) {
                if (transaction.isActive()) {
                    transaction.rollback();
                }
                throw ex;
            }
        });
    }

    /**
     * Run a full native SELECT on an already-open Session (no bind parameters).
     * Does not close the session. Throws {@link RuntimeException} on SQL errors.
     */
    public static List<Map<String, Object>> executeQuery(Session session, String sql) {
        if (session == null) {
            throw new IllegalArgumentException("session is required");
        }
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("sql is required");
        }
        try {
            return session.doReturningWork(connection -> {
                try (Statement st = connection.createStatement();
                     ResultSet rs = st.executeQuery(sql)) {
                    return resultSetToMaps(rs);
                }
            });
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException("Native query failed: " + ex.getMessage(), ex);
        }
    }

    /**
     * Run a parameterized native SELECT on an already-open Session.
     * The caller remains responsible for the session lifecycle.
     */
    public static List<Map<String, Object>> executeQueryInSession(
            Session session,
            String sql,
            Object... parameters) {
        if (session == null) {
            throw new IllegalArgumentException("session is required");
        }
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("sql is required");
        }
        try {
            return session.doReturningWork(connection -> {
                if (connection == null) {
                    throw new IllegalStateException("No database connection is available.");
                }
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    bind(statement, parameters);
                    try (ResultSet resultSet = statement.executeQuery()) {
                        return resultSetToMaps(resultSet);
                    }
                }
            });
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException("Native query failed: " + ex.getMessage(), ex);
        }
    }

    /**
     * Execute a parameterized native INSERT, UPDATE, or DELETE on an open
     * Session. The caller owns the session and transaction lifecycle.
     *
     * @return the number of affected rows
     */
    public static int executeUpdateInSession(Session session, String sql, Object... parameters) {
        if (session == null) {
            throw new IllegalArgumentException("session is required");
        }
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("sql is required");
        }
        try {
            return session.doReturningWork(connection -> {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    bind(statement, parameters);
                    return statement.executeUpdate();
                }
            });
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException("Native update failed: " + ex.getMessage(), ex);
        }
    }

    /**
     * Execute a stored procedure with input parameters and return its first
     * result set using the same column-label Map format as {@link #executeQuery}.
     */
    public static List<Map<String, Object>> executeProcedure(
            HibernateFactoryRegistry registry,
            String datasourceName,
            String callSql,
            Object... inputParameters) {
        if (registry == null) {
            throw new IllegalArgumentException("registry is required");
        }
        if (datasourceName == null || datasourceName.isBlank()) {
            throw new IllegalArgumentException("datasourceName is required");
        }
        return registry.withSession(
                datasourceName,
                session -> executeProcedure(session, callSql, inputParameters));
    }

    /**
     * Execute a stored procedure on an existing session. The session lifecycle
     * remains the caller's responsibility.
     */
    public static List<Map<String, Object>> executeProcedure(
            Session session,
            String callSql,
            Object... inputParameters) {
        if (session == null) {
            throw new IllegalArgumentException("session is required");
        }
        if (callSql == null || callSql.isBlank()) {
            throw new IllegalArgumentException("callSql is required");
        }
        try {
            return session.doReturningWork(connection -> {
                try (CallableStatement call = connection.prepareCall(callSql)) {
                    if (inputParameters != null) {
                        for (int i = 0; i < inputParameters.length; i++) {
                            try {
                                call.setObject(i + 1, inputParameters[i]);
                            } catch (SQLException ex) {
                                throw new SQLException("Failed to bind stored procedure parameter #" + (i + 1),
                                        ex.getSQLState(), ex.getErrorCode(), ex);
                            }
                        }
                    }
                    boolean hasResult = call.execute();
                    while (!hasResult && call.getUpdateCount() != -1) {
                        hasResult = call.getMoreResults();
                    }
                    if (!hasResult) {
                        return new ArrayList<>();
                    }
                    try (ResultSet rs = call.getResultSet()) {
                        return resultSetToMaps(rs);
                    }
                }
            });
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException("Stored procedure failed: " + ex.getMessage(), ex);
        }
    }

    /**
     * Execute a stored procedure with sequential input parameters followed by
     * registered output parameters. Output values are keyed by JDBC position.
     */
    public static Map<Integer, Object> executeProcedureWithOutputs(
            HibernateFactoryRegistry registry,
            String datasourceName,
            String callSql,
            Map<Integer, Integer> outputTypes,
            Object... inputParameters) {
        if (registry == null) {
            throw new IllegalArgumentException("registry is required");
        }
        if (datasourceName == null || datasourceName.isBlank()) {
            throw new IllegalArgumentException("datasourceName is required");
        }
        return registry.withSession(
                datasourceName,
                session -> executeProcedureWithOutputs(
                        session, callSql, outputTypes, inputParameters));
    }

    /**
     * Existing-session variant of {@link #executeProcedureWithOutputs(
     * HibernateFactoryRegistry, String, String, Map, Object...)}.
     */
    public static Map<Integer, Object> executeProcedureWithOutputs(
            Session session,
            String callSql,
            Map<Integer, Integer> outputTypes,
            Object... inputParameters) {
        if (session == null) {
            throw new IllegalArgumentException("session is required");
        }
        if (callSql == null || callSql.isBlank()) {
            throw new IllegalArgumentException("callSql is required");
        }
        if (outputTypes == null || outputTypes.isEmpty()) {
            throw new IllegalArgumentException("outputTypes are required");
        }
        try {
            return session.doReturningWork(connection -> {
                try (CallableStatement call = connection.prepareCall(callSql)) {
                    if (inputParameters != null) {
                        for (int i = 0; i < inputParameters.length; i++) {
                            call.setObject(i + 1, inputParameters[i]);
                        }
                    }
                    for (Map.Entry<Integer, Integer> output : outputTypes.entrySet()) {
                        call.registerOutParameter(output.getKey(), output.getValue());
                    }
                    boolean result = call.execute();
                    int guard = 0;
                    while (guard++ < 20) {
                        if (result) {
                            java.sql.ResultSet rs = call.getResultSet();
                            if (rs != null) {
                                rs.close();
                            }
                        } else if (call.getUpdateCount() == -1) {
                            break;
                        }
                        result = call.getMoreResults();
                    }
                    Map<Integer, Object> values = new LinkedHashMap<>();
                    for (Map.Entry<Integer, Integer> output : outputTypes.entrySet()) {
                        Object value = call.getObject(output.getKey());
                        if (value == null && (output.getValue() == Types.VARCHAR || output.getValue() == Types.CHAR)) {
                            value = call.getString(output.getKey());
                        }
                        values.put(output.getKey(), value);
                    }
                    return values;
                }
            });
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException("Stored procedure failed: " + ex.getMessage(), ex);
        }
    }

    private static List<Map<String, Object>> resultSetToMaps(ResultSet rs) throws SQLException {
        if (rs == null) {
            return new ArrayList<>();
        }
        ResultSetMetaData meta = rs.getMetaData();
        if (meta == null) {
            return new ArrayList<>();
        }
        int colCount = meta.getColumnCount();
        List<Map<String, Object>> rows = new ArrayList<>();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<>(Math.max(colCount, 1));
            for (int i = 1; i <= colCount; i++) {
                String label = meta.getColumnLabel(i);
                if (label == null || label.isBlank()) {
                    label = meta.getColumnName(i);
                }
                if (label == null || label.isBlank()) {
                    label = "col" + i;
                }
                row.put(label, rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

    private static void bind(PreparedStatement statement, Object[] parameters) throws SQLException {
        if (parameters == null) {
            return;
        }
        for (int i = 0; i < parameters.length; i++) {
            Object value = parameters[i];
            if (value == null) {
                statement.setNull(i + 1, Types.VARCHAR);
            } else {
                statement.setObject(i + 1, value);
            }
        }
    }

    public static List<Map<String, Object>> listAsMaps(Session session, String sql,
                                                       Map<String, Object> params,
                                                       Map<String, BasicTypeReference<?>> scalars) {
        @SuppressWarnings("rawtypes")
        NativeQuery query = session.createNativeQuery(sql);
        if (scalars != null) {
            scalars.forEach(query::addScalar);
        }
        if (params != null) {
            params.forEach(query::setParameter);
        }
        @SuppressWarnings("unchecked")
        List<Object[]> rows = query.list();
        if (rows == null || rows.isEmpty()) {
            return new ArrayList<>();
        }

        List<String> keys = scalars != null ? new ArrayList<>(scalars.keySet()) : List.of();
        List<Map<String, Object>> out = new ArrayList<>(rows.size());
        for (Object row : rows) {
            Map<String, Object> map = new LinkedHashMap<>();
            if (row instanceof Object[] arr) {
                for (int i = 0; i < keys.size() && i < arr.length; i++) {
                    map.put(keys.get(i), arr[i]);
                }
            } else if (keys.size() == 1) {
                map.put(keys.get(0), row);
            } else {
                map.put("value", row);
            }
            out.add(map);
        }
        return out;
    }


    /**
     * Run a native SELECT with scalar aliases and no bind parameters (SQL already complete).
     * Same row-map shape as {@link #listAsMaps}.
     */
    public static List<Map<String, Object>> listAsMapsDirectQuery(Session session, String sql,
                                                                  Map<String, BasicTypeReference<?>> scalars) {
        return listAsMaps(session, sql, null, scalars);
    }

    /**
     * Native SELECT with no bind parameters and zero scalar registration (no addScalar, no scalars map).
     * Rows are read from JDBC ResultSet metadata (column label -> value) via {@link #executeQuery(Session, String)}.
     * Prefer this when testing/autocomplete without Hibernate scalar aliases.
     */
    public static List<Map<String, Object>> listAsMapsDirectQueryNoScalars(Session session, String sql) {
        return executeQuery(session, sql);
    }
    public static Map<String, BasicTypeReference<?>> stringScalars(String... names) {
        Map<String, BasicTypeReference<?>> m = new LinkedHashMap<>();
        for (String n : names) {
            m.put(n, StandardBasicTypes.STRING);
        }
        return m;
    }
}