package com.mmm.titpl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 * Formats a parameterized SQL statement for diagnostics only.
 */
public final class SqlDebugFormatter {
	private SqlDebugFormatter() {
	}

	public static String render(String sql, Object... parameters) {
		StringBuilder rendered = new StringBuilder(sql.length() + 32);
		int parameterIndex = 0;
		char quote = 0;
		boolean bracketedIdentifier = false;
		boolean lineComment = false;
		boolean blockComment = false;
		int placeholderCount = 0;

		for (int i = 0; i < sql.length(); i++) {
			char current = sql.charAt(i);
			char next = i + 1 < sql.length() ? sql.charAt(i + 1) : 0;

			if (lineComment) {
				rendered.append(current);
				if (current == '\n' || current == '\r') {
					lineComment = false;
				}
				continue;
			}
			if (blockComment) {
				rendered.append(current);
				if (current == '*' && next == '/') {
					rendered.append(next);
					i++;
					blockComment = false;
				}
				continue;
			}
			if (quote != 0) {
				rendered.append(current);
				if (current == quote) {
					if (next == quote) {
						rendered.append(next);
						i++;
					} else {
						quote = 0;
					}
				}
				continue;
			}
			if (bracketedIdentifier) {
				rendered.append(current);
				if (current == ']') {
					if (next == ']') {
						rendered.append(next);
						i++;
					} else {
						bracketedIdentifier = false;
					}
				}
				continue;
			}
			if (current == '-' && next == '-') {
				rendered.append(current).append(next);
				i++;
				lineComment = true;
			} else if (current == '/' && next == '*') {
				rendered.append(current).append(next);
				i++;
				blockComment = true;
			} else if (current == '\'' || current == '"') {
				rendered.append(current);
				quote = current;
			} else if (current == '[') {
				rendered.append(current);
				bracketedIdentifier = true;
			} else if (current == '?') {
				placeholderCount++;
				if (parameterIndex < parameters.length) {
					rendered.append(sqlLiteral(parameters[parameterIndex++]));
				} else {
					rendered.append(current);
				}
			} else {
				rendered.append(current);
			}
		}

		if (placeholderCount != parameters.length) {
			rendered.append(" /* SQL bind count mismatch: ")
					.append(placeholderCount).append(" placeholders, ")
					.append(parameters.length).append(" values */");
		}
		return rendered.toString();
	}

	private static String sqlLiteral(Object value) {
		if (value == null) {
			return "NULL";
		}
		if (value instanceof Boolean bool) {
			return bool ? "1" : "0";
		}
		if (value instanceof Number || value instanceof BigDecimal || value instanceof BigInteger) {
			return value.toString();
		}
		if (value instanceof byte[] bytes) {
			StringBuilder hex = new StringBuilder("0x");
			for (byte item : bytes) {
				hex.append(String.format("%02X", item & 0xff));
			}
			return hex.toString();
		}
		if (value instanceof Date date) {
			return quote(date.toString());
		}
		return quote(value.toString());
	}

	private static String quote(String value) {
		return "N'" + value.replace("'", "''") + "'";
	}
}
