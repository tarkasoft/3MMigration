package com.mmm.titpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import org.hibernate.Session;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Reusable, parameterized MSSQL server-side paging for Common.DataTable.
 *
 * <p>The browser sends only page/filter/sort values. SQL and the mapping from
 * browser field names to result-column aliases are defined by trusted Java
 * code. This prevents clients from submitting SQL or arbitrary ORDER BY
 * expressions.</p>
 */
public final class CommonDataTable {

    private static final int DEFAULT_PAGE_SIZE = 10;
    private static final int MAX_PAGE_SIZE = 200;
    private static final int MAX_FILTER_LENGTH = 500;
    private static final Pattern SAFE_ALIAS = Pattern.compile("[A-Za-z_][A-Za-z0-9_]*");

    private CommonDataTable() {
    }

    public record Request(
            int page,
            int pageSize,
            String sortField,
            String sortDirection,
            String globalFilter,
            Map<String, String> columnFilters) {

        public Request {
            page = Math.max(1, page);
            pageSize = pageSize <= 0 ? DEFAULT_PAGE_SIZE : Math.min(pageSize, MAX_PAGE_SIZE);
            sortField = clean(sortField, 100);
            sortDirection = "desc".equalsIgnoreCase(sortDirection) ? "desc" : "asc";
            globalFilter = clean(globalFilter, MAX_FILTER_LENGTH);
            columnFilters = sanitizeFilters(columnFilters);
        }

        private static Map<String, String> sanitizeFilters(Map<String, String> source) {
            if (source == null || source.isEmpty()) {
                return Collections.emptyMap();
            }
            Map<String, String> cleaned = new LinkedHashMap<>();
            source.forEach((key, value) -> {
                String safeKey = clean(key, 100);
                String safeValue = clean(value, MAX_FILTER_LENGTH);
                if (!safeKey.isEmpty() && !safeValue.isEmpty()) {
                    cleaned.put(safeKey, safeValue);
                }
            });
            return Collections.unmodifiableMap(cleaned);
        }
    }

    public record Page(
            List<Map<String, Object>> rows,
            long totalRecords,
            int totalPages,
            int page,
            int pageSize) {

        public Map<String, Object> toMap() {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("rows", rows);
            data.put("totalRecords", totalRecords);
            data.put("totalPages", totalPages);
            data.put("page", page);
            data.put("pageSize", pageSize);
            return data;
        }
    }

    public record Column(String resultAlias, boolean searchable, boolean sortable) {
        public Column {
            resultAlias = requireAlias(resultAlias);
        }
    }

    public static final class QuerySpec {
        private final String baseSql;
        private final List<Object> baseParameters;
        private final Map<String, Column> columns;
        private final String defaultSortField;

        private QuerySpec(Builder builder) {
            this.baseSql = normalizeBaseSql(builder.baseSql);
            this.baseParameters = List.copyOf(builder.baseParameters);
            this.columns = Collections.unmodifiableMap(new LinkedHashMap<>(builder.columns));
            this.defaultSortField = builder.defaultSortField;
        }

        public static Builder builder(String baseSql) {
            return new Builder(baseSql);
        }

        public static final class Builder {
            private final String baseSql;
            private final List<Object> baseParameters = new ArrayList<>();
            private final Map<String, Column> columns = new LinkedHashMap<>();
            private String defaultSortField;

            private Builder(String baseSql) {
                this.baseSql = baseSql;
            }

            public Builder parameter(Object value) {
                baseParameters.add(value);
                return this;
            }

            public Builder parameters(List<?> values) {
                if (values != null) {
                    baseParameters.addAll(values);
                }
                return this;
            }

            public Builder column(String requestField, String resultAlias) {
                return column(requestField, resultAlias, true, true);
            }

            public Builder column(
                    String requestField,
                    String resultAlias,
                    boolean searchable,
                    boolean sortable) {
                String field = requireField(requestField);
                columns.put(field, new Column(resultAlias, searchable, sortable));
                return this;
            }

            public Builder defaultSort(String requestField) {
                this.defaultSortField = requireField(requestField);
                return this;
            }

            public QuerySpec build() {
                if (columns.isEmpty()) {
                    throw new IllegalArgumentException("At least one DataTable column is required");
                }
                if (defaultSortField == null || !columns.containsKey(defaultSortField)) {
                    throw new IllegalArgumentException("defaultSort must reference a registered column");
                }
                if (!columns.get(defaultSortField).sortable()) {
                    throw new IllegalArgumentException("defaultSort column must be sortable");
                }
                return new QuerySpec(this);
            }
        }

        @Override
        public String toString() {
            StringBuilder text = new StringBuilder();
            text.append("baseSql:\n").append(baseSql).append('\n');
            text.append("defaultSort: ").append(defaultSortField).append('\n');
            text.append("baseParameters: ").append(baseParameters.size()).append('\n');
            text.append("columns:");
            columns.forEach((field, column) -> text
                    .append("\n  ")
                    .append(field)
                    .append(" -> ")
                    .append(column.resultAlias())
                    .append(" searchable=")
                    .append(column.searchable())
                    .append(" sortable=")
                    .append(column.sortable()));
            return text.toString();
        }
    }

    /**
     * Executes a COUNT query and one MSSQL OFFSET/FETCH page on the caller's
     * current Hibernate session/transaction.
     */
    public static Page query(Session session, QuerySpec spec, Request request) {
        if (session == null) {
            throw new IllegalArgumentException("session is required");
        }
        if (spec == null) {
            throw new IllegalArgumentException("querySpec is required");
        }
        if (request == null) {
            throw new IllegalArgumentException("request is required");
        }

        QueryParts filters = buildFilters(spec, request);
        SortChoice sort = resolveSort(spec, request);
        String countSql =
                "select count_big(1) as total_records from (" + spec.baseSql + ") grid_data"
                        + filters.whereSql();

        return session.doReturningWork(connection -> {
            long totalRecords = executeCount(
                    connection,
                    countSql,
                    combine(spec.baseParameters, filters.parameters()));
            int totalPages = totalRecords == 0
                    ? 0
                    : (int) Math.ceil((double) totalRecords / request.pageSize());
            int resolvedPage = totalPages == 0 ? 1 : Math.min(request.page(), totalPages);
            long offset = (long) (resolvedPage - 1) * request.pageSize();

            String pageSql =
                    "select grid_data.* from (" + spec.baseSql + ") grid_data"
                            + filters.whereSql()
                            + " order by grid_data." + quoteAlias(sort.resultAlias())
                            + " " + sort.direction()
                            + " offset ? rows fetch next ? rows only";
            List<Object> pageParameters = combine(spec.baseParameters, filters.parameters());
            pageParameters.add(offset);
            pageParameters.add(request.pageSize());
            System.out.println("pageSql:\n" + sqlWithValues(pageSql, pageParameters));
            List<Map<String, Object>> rows = executeRows(connection, pageSql, pageParameters);

            return new Page(rows, totalRecords, totalPages, resolvedPage, request.pageSize());
        });
    }

    /**
     * Converts the browser's JSON columnFilters object into a Java map.
     * Request construction applies the shared key/value length validation.
     */
    public static Map<String, String> parseColumnFilters(String json) {
        Map<String, String> filters = new LinkedHashMap<>();
        if (json == null || json.isBlank()) {
            return filters;
        }
        JsonElement parsed = JsonParser.parseString(json);
        if (!parsed.isJsonObject()) {
            return filters;
        }
        JsonObject object = parsed.getAsJsonObject();
        object.entrySet().forEach(entry -> {
            JsonElement value = entry.getValue();
            if (value != null && value.isJsonPrimitive()) {
                filters.put(entry.getKey(), value.getAsString());
            }
        });
        return filters;
    }

    private static QueryParts buildFilters(QuerySpec spec, Request request) {
        List<String> conditions = new ArrayList<>();
        List<Object> parameters = new ArrayList<>();

        if (!request.globalFilter().isEmpty()) {
            List<String> globalConditions = new ArrayList<>();
            String pattern = containsPattern(request.globalFilter());
            spec.columns.values().forEach(column -> {
                if (column.searchable()) {
                    globalConditions.add(textExpression(column.resultAlias()) + " like ? escape '\\'");
                    parameters.add(pattern);
                }
            });
            if (!globalConditions.isEmpty()) {
                conditions.add("(" + String.join(" or ", globalConditions) + ")");
            }
        }

        request.columnFilters().forEach((requestField, value) -> {
            Column column = spec.columns.get(requestField);
            if (column != null && column.searchable() && !value.isEmpty()) {
                conditions.add(textExpression(column.resultAlias()) + " like ? escape '\\'");
                parameters.add(containsPattern(value));
            }
        });

        String whereSql = conditions.isEmpty() ? "" : " where " + String.join(" and ", conditions);
        return new QueryParts(whereSql, parameters);
    }

    private static SortChoice resolveSort(QuerySpec spec, Request request) {
        String requestField = request.sortField();
        Column selected = spec.columns.get(requestField);
        if (selected == null || !selected.sortable()) {
            selected = spec.columns.get(spec.defaultSortField);
        }
        String direction = "desc".equals(request.sortDirection()) ? "desc" : "asc";
        return new SortChoice(selected.resultAlias(), direction);
    }

    private static long executeCount(Connection connection, String sql, List<Object> parameters)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, parameters);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getLong(1) : 0L;
            }
        }
    }

    private static List<Map<String, Object>> executeRows(
            Connection connection,
            String sql,
            List<Object> parameters) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, parameters);
            try (ResultSet resultSet = statement.executeQuery()) {
                ResultSetMetaData metadata = resultSet.getMetaData();
                int columnCount = metadata.getColumnCount();
                List<Map<String, Object>> rows = new ArrayList<>();
                while (resultSet.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 1; i <= columnCount; i++) {
                        row.put(metadata.getColumnLabel(i), resultSet.getObject(i));
                    }
                    rows.add(row);
                }
                return rows;
            }
        }
    }

    /** Debug display only. The executed statement still uses bound parameters. */
    private static String sqlWithValues(String sql, List<Object> parameters) {
        StringBuilder rendered = new StringBuilder();
        int parameterIndex = 0;
        for (int i = 0; i < sql.length(); i++) {
            char ch = sql.charAt(i);
            if (ch == '?' && parameterIndex < parameters.size()) {
                rendered.append(sqlLiteral(parameters.get(parameterIndex++)));
            } else {
                rendered.append(ch);
            }
        }
        return rendered.toString();
    }

    private static String sqlLiteral(Object value) {
        if (value == null) {
            return "null";
        }
        if (value instanceof Number) {
            return value.toString();
        }
        return "N'" + String.valueOf(value).replace("'", "''") + "'";
    }

    private static void bind(PreparedStatement statement, List<Object> parameters) throws SQLException {
        for (int i = 0; i < parameters.size(); i++) {
            statement.setObject(i + 1, parameters.get(i));
        }
    }

    private static List<Object> combine(List<Object> first, List<Object> second) {
        List<Object> combined = new ArrayList<>(first.size() + second.size() + 2);
        combined.addAll(first);
        combined.addAll(second);
        return combined;
    }

    private static String textExpression(String alias) {
        return "lower(convert(nvarchar(max), grid_data." + quoteAlias(alias) + "))";
    }

    private static String containsPattern(String value) {
        String escaped = value
                .toLowerCase(Locale.ROOT)
                .replace("\\", "\\\\")
                .replace("[", "\\[")
                .replace("%", "\\%")
                .replace("_", "\\_");
        return "%" + escaped + "%";
    }

    private static String quoteAlias(String alias) {
        return "[" + requireAlias(alias) + "]";
    }

    private static String normalizeBaseSql(String sql) {
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("baseSql is required");
        }
        String normalized = sql.trim();
        while (normalized.endsWith(";")) {
            normalized = normalized.substring(0, normalized.length() - 1).trim();
        }
        return normalized;
    }

    private static String requireAlias(String value) {
        String alias = clean(value, 100);
        if (!SAFE_ALIAS.matcher(alias).matches()) {
            throw new IllegalArgumentException("Unsafe SQL result alias: " + value);
        }
        return alias;
    }

    private static String requireField(String value) {
        String field = clean(value, 100);
        if (!SAFE_ALIAS.matcher(field).matches()) {
            throw new IllegalArgumentException("Invalid DataTable field: " + value);
        }
        return field;
    }

    private static String clean(String value, int maxLength) {
        String cleaned = value == null ? "" : value.trim();
        return cleaned.length() <= maxLength ? cleaned : cleaned.substring(0, maxLength);
    }

    private record QueryParts(String whereSql, List<Object> parameters) {
    }

    private record SortChoice(String resultAlias, String direction) {
    }
}
