package com.mmm.titpl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.query.NativeQuery;
import org.hibernate.type.BasicTypeReference;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

/**
 * Developer browser endpoints: withSession + Map mapping on system and cir.
 *
 *   GET /INPCV2/api/test/
 *   GET /INPCV2/api/test/system?limit=5
 *   GET /INPCV2/api/test/cir?limit=5
 *   GET /INPCV2/api/test/both
 *   GET /INPCV2/api/test/traditional?limit=5
 *   GET /INPCV2/api/test/mapping?limit=5
 */
@RestController
@RequestMapping("/api/test")
public class NativeQueryMappingTest {

    private static final String BASE_USER_SQL_TEMPLATE = """
            select top %d u.enl_id as enlId,
                   u.name as name,
                   isnull(u.active, '') as active,
                   isnull(u.email, '') as email
            from ia_user_master u
            order by u.enl_id
            """;

    private static final String BASE_COUNT_SQL =
            "select count(*) as cnt from ia_user_master";

    private static final String BASE_USER_BY_ID_SQL = """
            select u.enl_id as enlId, u.name as name
            from ia_user_master u
            where u.enl_id = :enlId
            """;

	    private final HibernateFactoryRegistry registry;
	    private final Gson gson = new Gson();
	
	    public NativeQueryMappingTest(HibernateFactoryRegistry registry) {
	        this.registry = registry;
	    }

    @GetMapping({"", "/"})
    public String index() {
        ResponseDataGeneric result = new ResponseDataGeneric();
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("endpoints", List.of(
                "GET /api/test/system?limit=5",
                "GET /api/test/cir?limit=5",
                "GET /api/test/both",
                "GET /api/test/traditional?limit=5",
                "GET /api/test/mapping?limit=5"));
        data.put("pattern", "withSession + traditional open/close Session");
        data.put("datasources", List.of(
                HibernateFactoryRegistry.SYSTEM,
                HibernateFactoryRegistry.CIR));
        result.SetSuccess("success", data);
        return gson.toJson(result);
    }

    @GetMapping("/system")
    public String system(@RequestParam(value = "limit", defaultValue = "5") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            int n = Math.max(1, Math.min(limit, 50));
            String sql = BASE_USER_SQL_TEMPLATE.formatted(n);

            List<Map<String, Object>> rows = registry.withSession(
                    HibernateFactoryRegistry.SYSTEM,
                    session -> NativeQuerySupport.executeQuery(session, sql));

            Number count = registry.withSession(HibernateFactoryRegistry.SYSTEM, session -> {
                List<Map<String, Object>> c =
                        NativeQuerySupport.executeQuery(session, BASE_COUNT_SQL);
                return (Number) c.get(0).get("cnt");
            });

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("datasource", HibernateFactoryRegistry.SYSTEM);
            data.put("pattern", "withSession + executeQuery");
            data.put("totalUsers", count);
            data.put("rows", rows);
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "system query failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    @GetMapping("/cir")
    public String cir(@RequestParam(value = "limit", defaultValue = "5") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            int n = Math.max(1, Math.min(limit, 50));
            String sql = BASE_USER_SQL_TEMPLATE.formatted(n);

            List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
                    registry, HibernateFactoryRegistry.CIR, sql);

            Number count = registry.withSession(HibernateFactoryRegistry.CIR, session -> {
                List<Map<String, Object>> c =
                        NativeQuerySupport.executeQuery(session, BASE_COUNT_SQL);
                return (Number) c.get(0).get("cnt");
            });

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("datasource", HibernateFactoryRegistry.CIR);
            data.put("pattern", "executeQuery(registry, cir, sql) via withSession");
            data.put("totalUsers", count);
            data.put("rows", rows);
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "cir query failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    @GetMapping("/both")
    public String both() {
        ResponseDataGeneric result = new ResponseDataGeneric();
        try {
            Map<String, BasicTypeReference<?>> scalars = new LinkedHashMap<>();
            scalars.put("enlId", StandardBasicTypes.LONG);
            scalars.put("name", StandardBasicTypes.STRING);

            List<Map<String, Object>> seed = registry.withSession(
                    HibernateFactoryRegistry.SYSTEM,
                    session -> NativeQuerySupport.executeQuery(
                            session, BASE_USER_SQL_TEMPLATE.formatted(1)));

            if (seed.isEmpty()) {
                result.SetError(-1, "failure", "no seed row on system ia_user_master");
                return gson.toJson(result);
            }

            Object enlId = seed.get(0).containsKey("enlId")
                    ? seed.get(0).get("enlId")
                    : seed.get(0).get("enl_id");

            Map<String, Object> params = new LinkedHashMap<>();
            params.put("enlId", enlId);

            List<Map<String, Object>> systemRows = registry.withSession(
                    HibernateFactoryRegistry.SYSTEM,
                    session -> NativeQuerySupport.listAsMaps(
                            session, BASE_USER_BY_ID_SQL, params, scalars));

            List<Map<String, Object>> cirRows = registry.withSession(
                    HibernateFactoryRegistry.CIR,
                    session -> NativeQuerySupport.listAsMaps(
                            session, BASE_USER_BY_ID_SQL, params, scalars));

            Number systemCnt = registry.withSession(HibernateFactoryRegistry.SYSTEM, session -> {
                List<Map<String, Object>> c =
                        NativeQuerySupport.executeQuery(session, BASE_COUNT_SQL);
                return (Number) c.get(0).get("cnt");
            });
            Number cirCnt = registry.withSession(HibernateFactoryRegistry.CIR, session -> {
                List<Map<String, Object>> c =
                        NativeQuerySupport.executeQuery(session, BASE_COUNT_SQL);
                return (Number) c.get(0).get("cnt");
            });

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("pattern", "withSession + listAsMaps on system and cir");
            data.put("enlId", enlId);
            data.put("systemUserCount", systemCnt);
            data.put("cirUserCount", cirCnt);
            data.put("systemRows", systemRows);
            data.put("cirRows", cirRows);
            data.put("systemSfHash",
                    System.identityHashCode(registry.getSystemSessionFactory()));
            data.put("cirSfHash",
                    System.identityHashCode(registry.getCirSessionFactory()));
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "both query failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }


    /**
     * Traditional approach: open Session, run query, always close in finally.
     * Same result shape as /system, but without withSession helper.
     */
    @GetMapping("/traditional")
    public String traditional(@RequestParam(value = "limit", defaultValue = "5") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        Session session = null;
        try {
            int n = Math.max(1, Math.min(limit, 50));
            String sql = BASE_USER_SQL_TEMPLATE.formatted(n);

            session = registry.getSessionFactory(HibernateFactoryRegistry.SYSTEM).openSession();
            List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session, sql);
            List<Map<String, Object>> countRows =
                    NativeQuerySupport.executeQuery(session, BASE_COUNT_SQL);
            Number count = countRows.isEmpty() || countRows.get(0).get("cnt") == null
                    ? 0L
                    : (Number) countRows.get(0).get("cnt");

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("datasource", HibernateFactoryRegistry.SYSTEM);
            data.put("pattern", "traditional openSession + try/finally close");
            data.put("totalUsers", count);
            data.put("rows", rows);
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "traditional query failed: " + ex.getMessage());
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
        return gson.toJson(result);
    }


    /**
     * Map mapping without NativeQuerySupport.executeQuery.
     * Traditional open/close + createNativeQuery + addScalar + manual List of Map.
     */
    @GetMapping("/mapping")
    public String mapping(@RequestParam(value = "limit", defaultValue = "5") int limit) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        Session session = null;
        try {
            int n = Math.max(1, Math.min(limit, 50));
            String sql = """
                    select top %d u.enl_id as enlId,
                           u.name as name,
                           isnull(u.active, '') as active,
                           isnull(u.email, '') as email
                    from ia_user_master u
                    order by u.enl_id
                    """.formatted(n);

            session = registry.getSessionFactory(HibernateFactoryRegistry.SYSTEM).openSession();

            @SuppressWarnings("rawtypes")
            NativeQuery query = session.createNativeQuery(sql);
            query.addScalar("enlId", StandardBasicTypes.LONG);
            query.addScalar("name", StandardBasicTypes.STRING);
            query.addScalar("active", StandardBasicTypes.STRING);
            query.addScalar("email", StandardBasicTypes.STRING);

            @SuppressWarnings("unchecked")
            List<Object[]> rawRows = query.list();

            List<Map<String, Object>> rows = new java.util.ArrayList<>(rawRows.size());
            for (Object[] arr : rawRows) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("enlId", arr[0]);
                row.put("name", arr[1]);
                row.put("active", arr[2]);
                row.put("email", arr[3]);
                rows.add(row);
            }

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("datasource", HibernateFactoryRegistry.SYSTEM);
            data.put("pattern", "createNativeQuery + addScalar + manual Map (no executeQuery)");
            data.put("rows", rows);
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "mapping query failed: " + ex.getMessage());
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
        return gson.toJson(result);
    }
}