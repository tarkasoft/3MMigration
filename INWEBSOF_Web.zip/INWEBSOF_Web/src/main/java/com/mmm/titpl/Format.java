package com.mmm.titpl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jakarta.persistence.PersistenceException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.hibernate.Session;

import com.mmm.titpl.NativeQuerySupport;

/**
 * Minimal Format helpers needed by DynamicModuleDetails / SystemSetup / DisplayGrid.
 */
public class Format {

	public static String GetSessonUserId(HttpServletRequest request)
	{
		HttpSession session = request.getSession(true);
		String userId="";
		if(null != session && session.getAttribute("loginId")!=null)
		{
			userId=session.getAttribute("loginId").toString();
		}
		else if(null != session && session.getAttribute("userId")!=null)
		{
			userId=session.getAttribute("userId").toString();
		}
		return userId;
	}

	public static String GetSessonUserIntCode(HttpServletRequest request)
	{
		HttpSession session = (HttpSession) request.getSession(true);
		String login_user_int_code="0";
		if(null != session && session.getAttribute("login_user_int_code")!=null) 
		{
			login_user_int_code=session.getAttribute("login_user_int_code").toString();
		}
		return login_user_int_code;

	}

	public static String GetUserIntForEnlId(Session session, String fw_user_code) 
	{
		String internal_code="";
		try
			{
					String Sql = " 	 select internal_code as internal_code   from ia_user_master where enl_id = '"+fw_user_code+"' ";
					System.out.println("  GetUserIntForEnlId ="+Sql);
					List<Map<String,Object>> query_data_obj=NativeQuerySupport.executeQuery(session, Sql);
					if(query_data_obj!=null && query_data_obj.size()>0)
					{
						for(Map<String,Object> map2:query_data_obj)
						{
							Object v = map2.get("internal_code");
							if(v!=null) internal_code=v.toString();
						}
						
					}
					
			}
			catch (PersistenceException ex) {
				Throwable cause = ex.getCause();
				if (cause instanceof SQLException) { }
			
			}
			catch (RuntimeException ex) {
				System.out.println("GetUserIntForEnlId error: "+ex.getMessage());
			}
		
		return internal_code;
	}

	public static String GetObjectValueFromMap(Object value) {
		return value == null ? "" : String.valueOf(value);
	}

	public static String getCurrentTimeStamp() {
		return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new java.util.Date());
	}
}