package com.mmm.titpl;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.AuthService;
import com.mmm.authentication.UserSessionSupport;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Persists Switcher theme JSON on ia_user_master.theme_json.
 * Matches custom-switcher.min.js: POST $host_url + "updateThemejson"
 */
@RestController
@RequestMapping("titpl")
public class ThemeController {

    private final AuthService authService;
    private final Gson gson = new Gson();

    public ThemeController(AuthService authService) {
        this.authService = authService;
    }

    private String requireLoginId(HttpServletRequest request, ResponseDataGeneric result) {
        HttpSession session = request.getSession(false);
        String loginId = UserSessionSupport.requireLoginId(session);
        if (loginId == null) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return null;
        }
        return loginId;
    }

    @PostMapping(value = "updateThemejson",
            consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE, MediaType.ALL_VALUE })
    public String updateThemejson(HttpServletRequest request, @RequestBody(required = false) String body) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        String loginId = requireLoginId(request, result);
        if (loginId == null) {
            return gson.toJson(result);
        }
        try {
            String json = body == null ? "" : body.trim();
            if (json.isEmpty()) {
                result.SetError(-1, "failure", "Empty theme JSON");
                return gson.toJson(result);
            }
            if (!json.startsWith("{")) {
                result.SetError(-1, "failure", "theme payload must be a JSON object");
                return gson.toJson(result);
            }
            int n = authService.saveThemeJson(loginId, json);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("updated", n);
            data.put("loginId", loginId);
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Save theme failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    @GetMapping("getThemejson")
    public String getThemejson(HttpServletRequest request) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        String loginId = requireLoginId(request, result);
        if (loginId == null) {
            return gson.toJson(result);
        }
        try {
            String theme = authService.getThemeJson(loginId);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("theme_json", theme == null ? "" : theme);
            data.put("loginId", loginId);
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Load theme failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }
}