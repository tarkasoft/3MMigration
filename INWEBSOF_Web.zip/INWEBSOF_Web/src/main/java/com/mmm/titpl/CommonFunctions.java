package com.mmm.titpl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/**
 * Shared value helpers for module Java (trim/text, numbers, portal dates).
 * Prefer this over copying private {@code text}/{@code sqlDate} into each class.
 *
 * <pre>
 * import static com.mmm.titpl.CommonFunctions.*;
 * // or: import static com.mmm.titpl.CommonFunctions.text;
 * </pre>
 */
public final class CommonFunctions {
	private static final DateTimeFormatter SQL_YMD = DateTimeFormatter.ISO_LOCAL_DATE;
	private static final DateTimeFormatter[] PARSE_PATTERNS = {
			DateTimeFormatter.ofPattern("dd/MM/uuuu"),
			DateTimeFormatter.ofPattern("d/M/uuuu"),
			DateTimeFormatter.ofPattern("dd-MM-uuuu"),
			DateTimeFormatter.ofPattern("d-M-uuuu"),
			DateTimeFormatter.ofPattern("uuuu-MM-dd"),
			DateTimeFormatter.ofPattern("uuuu/MM/dd"),
			DateTimeFormatter.ofPattern("uuuuMMdd")
	};

	private CommonFunctions() {
	}

	/** Null-safe trim; never returns null. */
	public static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	/** First letter upper, rest lower (Locale.ROOT). Blank unchanged. */
	public static String capitalize(String value) {
		String v = text(value);
		if (v.isEmpty()) {
			return v;
		}
		return v.substring(0, 1).toUpperCase(Locale.ROOT) + v.substring(1).toLowerCase(Locale.ROOT);
	}

	/**
	 * Normalize any common date input to standard SQL {@code yyyy-MM-dd}, or
	 * {@code null} for blank / empty / SQL Server 1900 sentinels.
	 * <p>
	 * Accepts: {@code ""}, {@code null}, {@code dd/mm/yyyy}, {@code d/m/yyyy},
	 * {@code dd-mm-yyyy}, {@code yyyy-mm-dd}, {@code yyyy/mm/dd},
	 * {@code yyyy-mm-dd HH:mm:ss[.S]}, {@code 1900-01-01}, {@code 1900-00-00},
	 * {@code 01/01/1900}, etc.
	 *
	 * @param fieldLabel used in {@link IllegalArgumentException} message
	 */
	public static String sqlDate(Object value, String fieldLabel) {
		String raw = text(value);
		if (raw.isEmpty() || "null".equalsIgnoreCase(raw) || "undefined".equalsIgnoreCase(raw)) {
			return null;
		}
		/* Drop time / ISO T suffix: "2026-10-27 00:00:00.0", "2026-10-27T00:00:00". */
		String datePart = raw;
		int tIdx = indexOfTimeSeparator(raw);
		if (tIdx > 0) {
			datePart = raw.substring(0, tIdx).trim();
		}
		if (datePart.isEmpty() || isSqlEmptyDate(datePart)) {
			return null;
		}
		String label = text(fieldLabel).isEmpty() ? "date" : text(fieldLabel);
		LocalDate parsed = tryParseDate(datePart);
		if (parsed == null) {
			throw new IllegalArgumentException("Invalid " + label + ": " + raw);
		}
		if (parsed.getYear() == 1900) {
			return null;
		}
		return parsed.format(SQL_YMD);
	}

	/** True for blank SQL dates: 1900-01-01, 1900-00-00, 00/00/0000, 01/01/1900, …. */
	private static boolean isSqlEmptyDate(String datePart) {
		String s = datePart.trim();
		if (s.isEmpty()) {
			return true;
		}
		/* Normalize separators for sentinel checks. */
		String norm = s.replace('/', '-').replace('.', '-');
		if ("1900-00-00".equals(norm) || "0000-00-00".equals(norm)
				|| "00-00-0000".equals(norm) || "00-00-1900".equals(norm)) {
			return true;
		}
		if (norm.startsWith("1900-") || norm.endsWith("-1900") || norm.endsWith("-0000")) {
			return true;
		}
		return false;
	}

	private static int indexOfTimeSeparator(String raw) {
		int space = raw.indexOf(' ');
		int tee = raw.indexOf('T');
		if (space < 0) {
			return tee;
		}
		if (tee < 0) {
			return space;
		}
		return Math.min(space, tee);
	}

	private static LocalDate tryParseDate(String datePart) {
		for (DateTimeFormatter formatter : PARSE_PATTERNS) {
			try {
				return LocalDate.parse(datePart, formatter);
			} catch (DateTimeParseException ignored) {
				/* try next pattern */
			}
		}
		return null;
	}

	/** Parse long; blank / {@code 0} / bad → {@code 0}. Strips decimal suffix. */
	public static long longVal(Object value) {
		String t = text(value);
		if (t.isEmpty() || "0".equals(t)) {
			return 0L;
		}
		try {
			return Long.parseLong(t.split("\\.")[0]);
		} catch (NumberFormatException ex) {
			return 0L;
		}
	}

	/** Parse int; blank / bad → {@code fallback}. Strips decimal suffix. */
	public static int intVal(Object value, int fallback) {
		String t = text(value);
		if (t.isEmpty()) {
			return fallback;
		}
		try {
			return Integer.parseInt(t.split("\\.")[0]);
		} catch (NumberFormatException ex) {
			return fallback;
		}
	}
}
