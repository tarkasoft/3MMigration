package com.mmm.rebate;

import java.util.Date;
import java.util.Properties;

import jakarta.mail.Message;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

final class RebateMail {
	private static final String SMTP_HOST = "mailserv.mmm.com";
	private static final String MAIL_FROM = "3msupport.in@mmm.com";

	private RebateMail() {}

	static void send(String to, String cc, String subject, String body) {
		if (to == null || to.isBlank()) {
			throw new IllegalStateException("Notification email address is not configured.");
		}
		try {
			Properties properties = new Properties();
			properties.put("mail.smtp.host", SMTP_HOST);
			jakarta.mail.Session session = jakarta.mail.Session.getInstance(properties);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(MAIL_FROM));
			addRecipients(message, Message.RecipientType.TO, to);
			addRecipients(message, Message.RecipientType.CC, cc);
			message.setSentDate(new Date());
			message.setSubject(subject, "UTF-8");
			message.setContent(body, "text/html; charset=UTF-8");
			Transport.send(message);
		} catch (Exception ex) {
			throw new IllegalStateException("The Rebate update was saved, but its notification email could not be sent.", ex);
		}
	}

	private static void addRecipients(MimeMessage message, Message.RecipientType type, String addresses)
			throws Exception {
		if (addresses == null || addresses.isBlank()) {
			return;
		}
		for (String address : addresses.split(",")) {
			if (!address.isBlank()) {
				message.addRecipient(type, new InternetAddress(address.trim()));
			}
		}
	}
}
