package com.mmm.rebate;

import static com.mmm.titpl.CommonFunctions.sqlDate;
import static com.mmm.titpl.CommonFunctions.text;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.SqlDebugFormatter;

final class RebateProgramSql {
	private static final Logger logger = LoggerFactory.getLogger(RebateProgramSql.class);
	private final HibernateFactoryRegistry registry;

	RebateProgramSql(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	List<Map<String, Object>> customer(String custCode) {
		return query("select top 1 internal_code,cust_code,cust_name,email "
				+ "from reb_customer_master where cust_code=? and isnull(status,'')<>'Deleted'", custCode);
	}

	List<Map<String, Object>> programDetails(int customer, int program) {
		return query("select top 1 pm.program_no,pm.program_name,"
				+ "isnull(pm.program_desc,'') as program_desc,isnull(pm.program_type,'') as program_type,"
				+ "isnull(pm.bso_remarks,'') as bso_remarks,pm.target_type,pm.email_cc,"
				+ "isnull(inv_user.email_id,'') as inv_approver_email,rd.div_name,pcm.target,"
				+ "isnull((select top 1 doc_name from reb_program_udoc_group "
				+ "where ref_s_ref_data_code=pm.internal_code),'') as program_doc_name,"
				+ "isnull(convert(varchar,pm.start_date,6),'') as start_date,"
				+ "isnull(convert(varchar,pm.end_date,6),'') as end_date,"
				+ "isnull(convert(varchar,pm.cut_off_date,6),'') as cut_off_date "
				+ "from reb_prg_cust_mapping pcm inner join reb_program pm on pm.internal_code=pcm.ref_prg_code "
				+ "left join reb_division rd on rd.internal_code=pm.division "
				+ "left join reb_user_master inv_user on inv_user.internal_code=pm.invoice_approver "
				+ "where pcm.ref_cust_code=? and pcm.ref_prg_code=? and pcm.approval_status='Approved'",
				customer, program);
	}

	List<Map<String, Object>> programFile(int customer, int program) {
		return query("select top 1 doc_path,doc_name from reb_program_udoc_group "
				+ "where ref_s_ref_data_code=? and exists (select 1 from reb_prg_cust_mapping pcm "
				+ "where pcm.ref_prg_code=? and pcm.ref_cust_code=? and pcm.approval_status='Approved')",
				program, program, customer);
	}

	List<Map<String, Object>> enrollment(int customer) {
		return query("select pm.internal_code as program_int_code,cm.cust_code,pm.program_no,pm.program_name,"
				+ "isnull(rd.div_name,'') as division,isnull(pcm.target,0) as target,"
				+ "isnull(program_doc.doc_name,'') as program_doc_name,"
				+ "isnull(pm.target_type,'') as target_type,isnull(pcm.prg_accepted_type,'') as prg_accepted_type,"
				+ "case when convert(varchar," + UserSessionSupport.sessionDate() + ",112)>convert(varchar,pm.cut_off_date,112) then 1 else 0 end as cut_off_date_over,"
				+ "isnull(convert(varchar(10),pm.cut_off_date,23),'') as cut_off_date,"
				+ "isnull(convert(varchar,pm.start_date,6)+' - '+convert(varchar,pm.end_date,6),'') as pgm_period "
				+ "from reb_prg_cust_mapping pcm inner join reb_customer_master cm on cm.internal_code=pcm.ref_cust_code "
				+ "inner join reb_program pm on pm.internal_code=pcm.ref_prg_code "
				+ "left join reb_division rd on rd.internal_code=pm.division "
				+ "outer apply (select top 1 doc_name from reb_program_udoc_group "
				+ "where ref_s_ref_data_code=pm.internal_code) program_doc "
				+ "where cm.internal_code=? and pcm.approval_status='Approved' "
				+ "order by pm.created_date desc,pcm.prg_accepted_type", customer);
	}

	List<Map<String, Object>> ytd(int customer) {
		return query("select rp.internal_code as program_int_code,rp.program_no,rp.program_name,"
				+ "isnull(convert(varchar,rp.start_date,6)+' - '+convert(varchar,rp.end_date,6),'') as pgm_period,"
				+ "isnull(tgt.target,0) as target,isnull(rp.target_type,'') as target_type,"
				+ "isnull(datediff(day,tgt.approved_date," + UserSessionSupport.sessionDate() + "),0) as diff_days,"
				+ "sum(isnull(rc.ytd_achievement,0)) as ytd_achievement,"
				+ "sum(isnull(rc.p_incentive_amt,0)) as p_incentive_amt,"
				+ "isnull(err.error_status,'') as error_reported,isnull(err.internal_code,0) as error_int_code "
				+ "from reb_cust_ytd_interim rc inner join reb_program rp on rp.internal_code=rc.ref_prg_code "
				+ "inner join reb_prg_cust_mapping tgt on tgt.ref_prg_code=rp.internal_code "
				+ "and tgt.ref_cust_code=rc.ref_cust_code and tgt.approval_status='Approved' "
				+ "and isnull(tgt.prg_accepted_type,'')<>'' "
				+ "left join reb_report_err_history err on err.prg_int_code=rp.internal_code "
				+ "and err.cust_int_code=rc.ref_cust_code and err.error_type='YTD' "
				+ "where rc.ref_cust_code=? group by rp.internal_code,rp.program_no,rp.program_name,"
				+ "rp.start_date,rp.end_date,tgt.target,rp.target_type,tgt.approved_date,err.error_status,err.internal_code "
				+ "order by max(rp.created_date) desc", customer);
	}

	List<Map<String, Object>> claims(int customer) {
		return claims(customer, "", "");
	}

	List<Map<String, Object>> claims(int customer, String fromDate, String toDate) {
		// Align grid fields with legacy GetClaimDetails:
		// Claim No, Program No, Program Name, Division, Program Period,
		// Program Target, Final Achievement, Final Payout, Claim Status, Credit Note No.
		String sql = "select convert(varchar(30),rc.claim_bso_case_no) as claim_bso_case_no,"
				+ "rc.inv_approval_remarks,rp.internal_code as prg_int_code,"
				+ "isnull(datediff(day,rc.d_approved_date," + UserSessionSupport.sessionDate() + "),0) as submitted_diff_days,"
				+ "rp.program_no,rp.program_name,isnull(rd.div_name,'') as division,"
				+ "isnull(convert(varchar,rp.start_date,6)+' - '+convert(varchar,rp.end_date,6),'') as pgm_period,"
				+ "isnull(map.target,0) as target,isnull(rp.target_type,'') as target_type,"
				+ "isnull(ytd.acheived,0) as acheived,rc.incentive_amt,isnull(rc.claim_no,'') as claim_no,"
				+ "convert(varchar(10),rc.d_approved_date,23) as approved_date,"
				+ "case when isnull(rp.program_type,'')<>'Rebate' and (isnull(rc.claim_status,'')='Credit Note Processing' "
				+ "or isnull(rc.claim_status,'')='Submitted for Credit Note process') "
				+ "then 'GSTR-2A Confirmation Awaited' else isnull(rc.claim_status,'') end as claim_status,"
				+ "isnull(rc.credit_note_no,'') as credit_note_no,"
				+ "isnull(err.error_status,'') as error_reported,isnull(err.internal_code,0) as error_int_code "
				+ "from reb_cust_incentive rc inner join reb_prg_cust_mapping map "
				+ "on map.ref_cust_code=rc.ref_cust_code and map.ref_prg_code=rc.ref_prg_code "
				+ "and isnull(map.prg_accepted_type,'')<>'' "
				+ "inner join reb_program rp on rp.internal_code=rc.ref_prg_code "
				+ "left join reb_division rd on rd.internal_code=rp.division "
				+ "left join (select ref_cust_code,ref_prg_code,sum(ytd_achievement) as acheived "
				+ "from reb_cust_ytd_interim where ref_cust_code=? group by ref_cust_code,ref_prg_code) ytd "
				+ "on ytd.ref_cust_code=rc.ref_cust_code and ytd.ref_prg_code=rc.ref_prg_code "
				+ "left join reb_report_err_history err on err.prg_int_code=rc.ref_prg_code "
				+ "and err.cust_int_code=rc.ref_cust_code and err.error_type='Invoice' "
				+ "where rc.d_approval_status='Approved' and rc.ref_cust_code=?";
		List<Object> parameters = new ArrayList<>(List.of(customer, customer));
		if (fromDate != null && !fromDate.isBlank()) {
			sql += " and rc.d_approved_date>=?";
			parameters.add(fromDate);
		}
		if (toDate != null && !toDate.isBlank()) {
			sql += " and rc.d_approved_date<dateadd(day,1,?)";
			parameters.add(toDate);
		}
		sql += " order by rp.created_date desc";
		return query(sql, parameters.toArray());
	}

	List<Map<String, Object>> claimsExport(int customer, String fromDate, String toDate) {
		String sql = "select isnull(rci.claim_no,'') as claim_no,isnull(rb.program_no,'') as program_no,"
				+ "isnull(rb.program_name,'') as program_name,isnull(rd.div_name,'') as div_name,"
				+ "isnull(convert(varchar,rb.start_date,6)+' - '+convert(varchar,rb.end_date,6),'') as period,"
				+ "isnull(rcm.target,0) as target,isnull(ytd_new.ytd_acheived,0) as ytd_acheived,"
				+ "isnull(ytd.incentive_amt,0) as final_payout,"
				+ "case when isnull(rb.program_type,'')<>'Rebate' and (isnull(rci.claim_status,'')='Credit Note Processing' "
				+ "or isnull(rci.claim_status,'')='Submitted for Credit Note process') "
				+ "then 'GSTR-2A Confirmation Awaited' else isnull(rci.claim_status,'') end as claim_status,"
				+ "isnull(rci.credit_note_no,'') as credit_note_no,isnull(ytd.state_code,'') as state_code,"
				+ "isnull(ytd.gst_no,'') as mmm_gst_no,isnull(rcv.cust_inv_no,'') as cust_inv_no,"
				+ "isnull(convert(varchar(10),rcv.cust_inv_date,23),'') as cust_inv_date,"
				+ "isnull(rcv.inv_value,0) as inv_value "
				+ "from reb_cust_incentive rci "
				+ "inner join (select ref_prg_code,ref_cust_code,rcy.state_code,sum(incentive_amt) as incentive_amt,"
				+ "gsc.gst_no from reb_cust_ytd rcy left join gst_state_codes gsc on rcy.state_code=gsc.state_code "
				+ "group by ref_prg_code,ref_cust_code,rcy.state_code,gsc.gst_no) ytd "
				+ "on ytd.ref_cust_code=rci.ref_cust_code and ytd.ref_prg_code=rci.ref_prg_code "
				+ "inner join reb_program rb on rb.internal_code=rci.ref_prg_code "
				+ "inner join reb_division rd on rd.internal_code=rb.division "
				+ "inner join reb_prg_cust_mapping rcm on rcm.ref_cust_code=rci.ref_cust_code "
				+ "and rcm.ref_prg_code=rci.ref_prg_code "
				+ "left join (select ref_cust_code,ref_prg_code,sum(ytd_achievement) as ytd_acheived "
				+ "from reb_cust_ytd_interim where ref_cust_code=? group by ref_cust_code,ref_prg_code) ytd_new "
				+ "on ytd_new.ref_cust_code=rci.ref_cust_code and ytd_new.ref_prg_code=rci.ref_prg_code "
				+ "left join reb_cust_invoice rcv on rcv.ref_cust_code=rci.ref_cust_code "
				+ "and rcv.ref_prg_code=rci.ref_prg_code and rcv.state_code=ytd.state_code "
				+ "where rci.d_approval_status='Approved' and rci.ref_cust_code=?";
		List<Object> parameters = new ArrayList<>(List.of(customer, customer));
		if (fromDate != null && !fromDate.isBlank()) {
			sql += " and rci.d_approved_date>=?";
			parameters.add(fromDate);
		}
		if (toDate != null && !toDate.isBlank()) {
			sql += " and rci.d_approved_date<dateadd(day,1,?)";
			parameters.add(toDate);
		}
		sql += " order by isnull(rci.claim_no,''),ytd.state_code";
		return query(sql, parameters.toArray());
	}

	List<Map<String, Object>> claim(int customer, int program, long claimCase) {
		return query("select top 1 rc.claim_bso_case_no,isnull(rc.claim_no,'') as claim_no,"
				+ "isnull(rc.claim_status,'') as claim_status,isnull(rc.inv_approval_remarks,'') as inv_approval_remarks,"
				+ "isnull((select top 1 isnull(y.payout_bso_remarks,'') from reb_cust_ytd y "
				+ "where y.ref_prg_code=rc.ref_prg_code and y.ref_cust_code=rc.ref_cust_code "
				+ "and y.payout_bso_case_no=rc.claim_bso_case_no),'') as payout_bso_remarks,"
				+ "isnull(rc.incentive_amt,0) as incentive_amt,"
				/* Legacy CallTarkaDatePickerNew from-date: DATEADD(DAY,-30,d_approved_date) as dd/mm/yyyy */
				+ "isnull(convert(varchar(10),dateadd(day,-30,rc.d_approved_date),103),'') as inv_date_from,"
				+ "isnull(convert(varchar(10),rc.d_approved_date,103),'') as inv_approved_date,"
				+ "isnull(rp.program_name,'') as program_name,isnull(rp.program_no,'') as program_no,"
				+ "isnull(rd.div_name,'') as division,"
				+ "isnull(convert(varchar,rp.start_date,6)+' - '+convert(varchar,rp.end_date,6),'') as pgm_period,"
				+ "isnull(cm.pan_no,'') as cust_pan_no,isnull(cm.gst_no,'') as cust_gst_no "
				+ "from reb_cust_incentive rc "
				+ "inner join reb_program rp on rp.internal_code=rc.ref_prg_code "
				+ "inner join reb_prg_cust_mapping pcm on pcm.ref_cust_code=rc.ref_cust_code "
				+ "and pcm.ref_prg_code=rc.ref_prg_code and isnull(pcm.prg_accepted_type,'')<>'' "
				+ "left join reb_division rd on rd.internal_code=rp.division "
				+ "left join reb_customer_master cm on cm.internal_code=rc.ref_cust_code "
				+ "where rc.ref_cust_code=? and rc.ref_prg_code=? and rc.claim_bso_case_no=? "
				+ "and rc.d_approval_status='Approved'", customer, program, claimCase);
	}

	List<Map<String, Object>> invoices(int customer, int program, long claimCase) {
		return query("select y.state_code,sum(y.incentive_amt) as incentive_amt,isnull(g.gst_no,'') as mmm_gst_no,"
				+ "isnull(i.cust_tax_type,'') as cust_tax_type,isnull(i.cust_inv_no,'') as cust_inv_no,"
				+ "isnull(convert(varchar(10),i.cust_inv_date,23),'') as cust_inv_date,"
				+ "isnull(i.inv_value,0) as inv_value,isnull(i.u_invoice_doc_name,'') as u_invoice_doc_name,"
				+ "isnull(i.u_invoice_doc_path,'') as u_invoice_doc_path,"
				+ "isnull(i.u_invoice_gst_doc_name,'') as u_invoice_gst_doc_name,"
				+ "isnull(i.u_invoice_gst_doc_path,'') as u_invoice_gst_doc_path "
				+ "from reb_cust_ytd y left join gst_state_codes g on g.state_code=y.state_code "
				+ "left join reb_cust_invoice i on i.ref_cust_code=y.ref_cust_code and i.ref_prg_code=y.ref_prg_code "
				+ "and i.state_code=y.state_code and i.inv_bso_case_no=y.payout_bso_case_no "
				+ "where y.ref_cust_code=? and y.ref_prg_code=? and y.payout_bso_case_no=? "
				+ "group by y.state_code,g.gst_no,i.cust_tax_type,i.cust_inv_no,i.cust_inv_date,i.inv_value,"
				+ "i.u_invoice_doc_name,i.u_invoice_doc_path,i.u_invoice_gst_doc_name,i.u_invoice_gst_doc_path "
				+ "order by y.state_code", customer, program, claimCase);
	}

	/** Legacy GetSKUDescription — best-effort HSN/SAC + description by state. */
	List<Map<String, Object>> skuHints(int customer, int program, long claimCase) {
		try {
			return query("select y.state_code,max(isnull(it.IDESC,'')) as item_desc,"
					+ "max(isnull(it.imhrmn,'')) as hsn_code "
					+ "from reb_cust_ytd y left join SO_ItemMaster it on it.IPROD=y.sku_code "
					+ "where y.ref_cust_code=? and y.ref_prg_code=? and y.payout_bso_case_no=? "
					+ "group by y.state_code", customer, program, claimCase);
		} catch (Exception ex) {
			logger.warn("Rebate SKU/HSN lookup skipped: {}", ex.getMessage());
			return List.of();
		}
	}

	List<Map<String, Object>> programDocuments(int customer, int program, long claimCase) {
		return query("select a.doc_int_code as doc_code,isnull(a.document_name,'') as document_name,"
				+ "isnull(a.is_mandatory,'No') as is_mandatory,"
				+ "isnull(md.doc_name,'') as doc_name,isnull(md.doc_path,'') as doc_path "
				+ "from (select dt.internal_code as doc_int_code,isnull(dt.document_name,'') as document_name,"
				+ "pdg.ref_s_ref_data_code as prg_int_code,"
				+ "isnull(pdg.is_mandatory,'No') as is_mandatory from reb_program rp "
				+ "inner join reb_program_document_group pdg on pdg.ref_s_ref_data_code=rp.internal_code "
				+ "inner join reb_document_type dt on dt.internal_code=pdg.document where rp.internal_code=?) a "
				+ "left join reb_prg_cust_mapping_docs md on a.prg_int_code=md.ref_prg_code "
				+ "and md.ref_cust_code=? and md.ref_doc_code=a.doc_int_code and md.bso_case_no=? "
				+ "order by a.doc_int_code", program, customer, claimCase);
	}

	List<Map<String, Object>> invoiceEvidence(int customer, int program, String state, long claimCase) {
		return query("select top 1 internal_code,claim_no,incentive_amt from reb_cust_invoice "
				+ "where ref_cust_code=? and ref_prg_code=? and state_code=? and inv_bso_case_no=?",
				customer, program, state, claimCase);
	}

	/** Update invoice line fields only (files already on the claim). */
	void updateInvoiceDetails(int customer, int program, long claimCase, String state,
			String claimNo, String taxType, String invoiceNo, String invoiceDate, BigDecimal amount) {
		String invDate = sqlDate(invoiceDate, "Invoice date");
		registry.withSession(HibernateFactoryRegistry.INFOAPPS, session -> {
			Transaction tx = session.beginTransaction();
			try {
				upsertInvoiceDetails(session, customer, program, claimCase, state, claimNo,
						taxType, invoiceNo, invDate, amount);
				tx.commit();
				return null;
			} catch (RuntimeException ex) {
				if (tx.isActive()) {
					tx.rollback();
				}
				throw ex;
			}
		});
	}

	void saveInvoiceEvidence(int customer, int program, long claimCase, String state,
			String claimNo, String taxType, String invoiceNo, String invoiceDate, BigDecimal amount,
			String kind, String displayName, String remoteName) {
		String invDate = sqlDate(invoiceDate, "Invoice date");
		registry.withSession(HibernateFactoryRegistry.INFOAPPS, session -> {
			Transaction tx = session.beginTransaction();
			try {
				upsertInvoiceDetails(session, customer, program, claimCase, state, claimNo,
						taxType, invoiceNo, invDate, amount);
				String update = "INVOICE".equals(kind)
						? "update reb_cust_invoice set invoice_uploaded_date=" + UserSessionSupport.sessionDate() + ",u_invoice_doc_name=?,u_invoice_doc_path=?,approved_status='' where ref_cust_code=? and ref_prg_code=? and state_code=? and inv_bso_case_no=?"
						: "update reb_cust_invoice set u_invoice_gst_doc_name=?,u_invoice_gst_doc_path=?,approved_status='' where ref_cust_code=? and ref_prg_code=? and state_code=? and inv_bso_case_no=?";
				updateInSession(session, update, displayName, remoteName,
						customer, program, state, claimCase);
				tx.commit();
				return null;
			} catch (RuntimeException ex) {
				if (tx.isActive()) {
					tx.rollback();
				}
				throw ex;
			}
		});
	}

	/** uploaded_by / created_by / modified_by are int (customer internal_code), not login id. */
	private void upsertInvoiceDetails(org.hibernate.Session session, int customer, int program,
			long claimCase, String state, String claimNo, String taxType, String invoiceNo,
			String invDate, BigDecimal amount) {
		List<Map<String, Object>> rows = queryInSession(session,
				"select top 1 internal_code from reb_cust_invoice where ref_cust_code=? "
						+ "and ref_prg_code=? and state_code=? and inv_bso_case_no=?",
				customer, program, state, claimCase);
		if (rows.isEmpty()) {
			updateInSession(session,
					"insert into reb_cust_invoice(claim_no,cust_tax_type,inv_bso_case_no,uploaded_by,"
							+ "ref_cust_code,ref_prg_code,state_code,incentive_amt,cust_inv_no,cust_inv_date,"
							+ "cust_inv_amt,inv_value,created_date,created_by,modified_date,modified_by) "
							+ "select ?,?,?,?, ?,?,?,sum(y.incentive_amt),?,?,sum(y.incentive_amt),?,"
							+ "" + UserSessionSupport.sessionDate() + ",?," + UserSessionSupport.sessionDate() + ",? "
							+ "from reb_cust_ytd y where y.ref_cust_code=? and y.ref_prg_code=? "
							+ "and y.state_code=? and y.payout_bso_case_no=?",
					claimNo, taxType, claimCase, customer, customer, program, state,
					invoiceNo, invDate, amount, customer, customer,
					customer, program, state, claimCase);
		} else {
			updateInSession(session,
					"update reb_cust_invoice set cust_tax_type=?,cust_inv_no=?,cust_inv_date=?,"
							+ "cust_inv_amt=(select sum(y.incentive_amt) from reb_cust_ytd y where "
							+ "y.ref_cust_code=? and y.ref_prg_code=? and y.state_code=? and y.payout_bso_case_no=?),"
							+ "incentive_amt=(select sum(y.incentive_amt) from reb_cust_ytd y where "
							+ "y.ref_cust_code=? and y.ref_prg_code=? and y.state_code=? and y.payout_bso_case_no=?),"
							+ "inv_value=?,modified_date=" + UserSessionSupport.sessionDate() + ",modified_by=? where internal_code=?",
					taxType, invoiceNo, invDate,
					customer, program, state, claimCase, customer, program, state, claimCase,
					amount, customer, rows.get(0).get("internal_code"));
		}
	}

	void saveProgramDocument(int customer, int program, long claimCase, int documentCode,
			String displayName, String remoteName) {
		registry.withSession(HibernateFactoryRegistry.INFOAPPS, session -> {
			Transaction tx = session.beginTransaction();
			try {
				updateInSession(session,
						"delete from reb_prg_cust_mapping_docs where ref_prg_code=? and ref_cust_code=? "
								+ "and ref_doc_code=? and bso_case_no=?",
						program, customer, documentCode, claimCase);
				updateInSession(session,
						"insert into reb_prg_cust_mapping_docs(ref_prg_code,ref_cust_code,ref_doc_code,doc_path,doc_name,bso_case_no) "
								+ "values (?,?,?,?,?,?)",
						program, customer, documentCode, remoteName, displayName, claimCase);
				tx.commit();
				return null;
			} catch (RuntimeException ex) {
				if (tx.isActive()) {
					tx.rollback();
				}
				throw ex;
			}
		});
	}

	int deleteProgramDocument(int customer, int program, long claimCase, int documentCode) {
		return update(
				"delete from reb_prg_cust_mapping_docs where ref_prg_code=? and ref_cust_code=? "
						+ "and ref_doc_code=? and bso_case_no=?",
				program, customer, documentCode, claimCase);
	}

	int deleteInvoiceEvidence(int customer, int program, long claimCase, String state, String kind) {
		String update = "INVOICE".equals(kind)
				? "update reb_cust_invoice set u_invoice_doc_name='',u_invoice_doc_path='',approved_status='' "
						+ "where ref_cust_code=? and ref_prg_code=? and state_code=? and inv_bso_case_no=?"
				: "update reb_cust_invoice set u_invoice_gst_doc_name='',u_invoice_gst_doc_path='',approved_status='' "
						+ "where ref_cust_code=? and ref_prg_code=? and state_code=? and inv_bso_case_no=?";
		return update(update, customer, program, state, claimCase);
	}

	List<Map<String, Object>> programDocument(int customer, int program, long claimCase, int documentCode) {
		return query("select top 1 doc_name,doc_path from reb_prg_cust_mapping_docs "
				+ "where ref_prg_code=? and ref_cust_code=? and ref_doc_code=? and bso_case_no=?",
				program, customer, documentCode, claimCase);
	}

	void enroll(int customer, int program, String acceptedBy) {
		int changed = update(
				"update reb_prg_cust_mapping set prg_accepted_type='Customer',prg_accepted_by=?,"
						+ "prg_accepted_date=" + UserSessionSupport.sessionDate() + " where ref_prg_code=? and ref_cust_code=? "
						+ "and approval_status='Approved' and isnull(prg_accepted_type,'')=''"
						+ " and convert(varchar," + UserSessionSupport.sessionDate() + ",112)<=convert(varchar,"
						+ "(select cut_off_date from reb_program where internal_code=?),112)",
				acceptedBy, program, customer, program);
		if (changed != 1) {
			throw new IllegalStateException("The program is no longer available for enrollment.");
		}
	}

	void discrepancy(int customer, int program, String type, String remarks) {
		String eligibleSql = "YTD".equals(type)
				? "select top 1 tgt.internal_code from reb_cust_ytd_interim y "
						+ "inner join reb_prg_cust_mapping tgt on tgt.ref_cust_code=y.ref_cust_code "
						+ "and tgt.ref_prg_code=y.ref_prg_code where y.ref_cust_code=? and y.ref_prg_code=? "
						+ "and tgt.approval_status='Approved' and isnull(tgt.prg_accepted_type,'')<>'' "
						+ "and isnull(datediff(day,tgt.approved_date," + UserSessionSupport.sessionDate() + "),0)<=7"
				: "select top 1 internal_code from reb_cust_incentive where ref_cust_code=? and ref_prg_code=? "
						+ "and d_approval_status='Approved' and isnull(datediff(day,d_approved_date," + UserSessionSupport.sessionDate() + "),0)<=7";
		if (query(eligibleSql, customer, program).isEmpty()) {
			throw new IllegalArgumentException("The seven-day discrepancy reporting window has closed.");
		}
		if (!"YTD".equals(type) && enrollmentOwnership(customer, program).isEmpty()) {
			throw new IllegalArgumentException("The program is not available to this customer.");
		}
		if (!query("select top 1 internal_code from reb_report_err_history where prg_int_code=? "
				+ "and cust_int_code=? and error_type=? and error_status='Pending'",
				program, customer, type).isEmpty()) {
			throw new IllegalArgumentException("A discrepancy for this item is already under review.");
		}
		update(
				"insert into reb_report_err_history(prg_int_code,cust_int_code,error_type,remarks,created_date,error_status) "
						+ "values (?,?,?,?," + UserSessionSupport.sessionDate() + ",'Pending')",
				program, customer, type, remarks);
	}

	void submitClaim(int customer, int program, long claimCase, String type, String remarks,
			boolean panVerified, boolean updateRequested, List<Map<String, Object>> invoices) {
		registry.withSession(HibernateFactoryRegistry.INFOAPPS, session -> {
			Transaction tx = session.beginTransaction();
			try {
				List<Map<String, Object>> owned = queryInSession(session,
						"select top 1 claim_no,claim_status from reb_cust_incentive where ref_cust_code=? "
								+ "and ref_prg_code=? and claim_bso_case_no=? and d_approval_status='Approved'",
						customer, program, claimCase);
				if (owned.isEmpty()) {
					throw new IllegalArgumentException("Claim not found for this customer.");
				}
				String previousStatus = text(owned.get(0).get("claim_status"));
				if (!previousStatus.isEmpty() && !"Draft".equalsIgnoreCase(previousStatus)
						&& !"Save".equalsIgnoreCase(previousStatus)
						&& !"Sent for Rework".equalsIgnoreCase(previousStatus)) {
					throw new IllegalArgumentException("This claim is not open for customer updates.");
				}
				if (invoices.isEmpty()) {
					throw new IllegalArgumentException("This claim has no invoice payout lines.");
				}
				for (Map<String, Object> invoice : invoices) {
					String state = text(invoice.get("stateCode"));
					String taxType = text(invoice.get("taxType"));
					if (state.isEmpty() || !("IGST".equals(taxType) || "CGSTSGST".equals(taxType))) {
						throw new IllegalArgumentException("Each invoice must have a state and GST type.");
					}
					String invoiceNo = text(invoice.get("invoiceNo"));
					String date = sqlDate(invoice.get("invoiceDate"), "Invoice date");
					BigDecimal amount = decimal(invoice.get("invoiceValue"));
					List<Map<String, Object>> existing = queryInSession(session,
							"select internal_code from reb_cust_invoice where ref_cust_code=? and ref_prg_code=? "
									+ "and state_code=? and inv_bso_case_no=?",
							customer, program, state, claimCase);
					if (existing.isEmpty()) {
						updateInSession(session,
								"insert into reb_cust_invoice(claim_no,cust_tax_type,inv_bso_case_no,uploaded_by,"
										+ "ref_cust_code,ref_prg_code,state_code,incentive_amt,cust_inv_no,cust_inv_date,"
										+ "cust_inv_amt,inv_value,"
										+ "created_date,created_by,modified_date,modified_by) "
										+ "select ?,?,?,?, ?,?,?,sum(y.incentive_amt),?,?,sum(y.incentive_amt),?,"
										+ "" + UserSessionSupport.sessionDate() + ",?," + UserSessionSupport.sessionDate() + ",? from reb_cust_ytd y where y.ref_cust_code=? "
										+ "and y.ref_prg_code=? and y.state_code=? and y.payout_bso_case_no=?",
								text(owned.get(0).get("claim_no")), taxType, claimCase, customer, customer, program, state,
										invoiceNo, date, amount, customer, customer,
										customer, program, state, claimCase);
					} else {
						updateInSession(session,
								"update reb_cust_invoice set cust_tax_type=?,cust_inv_no=?,cust_inv_date=?,"
										+ "cust_inv_amt=(select sum(y.incentive_amt) from reb_cust_ytd y where "
										+ "y.ref_cust_code=? and y.ref_prg_code=? and y.state_code=? and y.payout_bso_case_no=?),"
										+ "incentive_amt=(select sum(y.incentive_amt) from reb_cust_ytd y where "
										+ "y.ref_cust_code=? and y.ref_prg_code=? and y.state_code=? and y.payout_bso_case_no=?),"
										+ "inv_value=?,modified_date=" + UserSessionSupport.sessionDate() + ",modified_by=? where ref_cust_code=? and ref_prg_code=? "
										+ "and state_code=? and inv_bso_case_no=?",
								taxType, invoiceNo, date,
								customer, program, state, claimCase, customer, program, state, claimCase,
								amount, customer, customer, program, state, claimCase);
					}
				}
				updateInSession(session,
						"update reb_cust_incentive set claim_submitted_date=" + UserSessionSupport.sessionDate() + ",invoice_uploaded_by='Customer',"
								+ "customer_remarks=?,claim_status=?,verified_pan_gst=?,new_pan_gst=? "
								+ "where ref_prg_code=? and ref_cust_code=? and claim_bso_case_no=?",
						remarks, "Submit".equalsIgnoreCase(type)
								? ("Sent for Rework".equalsIgnoreCase(previousStatus)
										? "Resubmitted for verification" : "Submit")
								: "Draft",
						panVerified ? 1 : 0, updateRequested ? 1 : 0, program, customer, claimCase);
				if ("Submit".equalsIgnoreCase(type) && "Sent for Rework".equalsIgnoreCase(previousStatus)) {
					updateInSession(session,
							"update reb_cust_invoice set approved_status='Resubmitted for verification' "
									+ "where ref_cust_code=? and ref_prg_code=? and inv_bso_case_no=? "
									+ "and isnull(approved_status,'')<>'Approved'",
							customer, program, claimCase);
				}
				tx.commit();
				return null;
			} catch (RuntimeException ex) {
				if (tx.isActive()) {
					tx.rollback();
				}
				throw ex;
			}
		});
	}

	private List<Map<String, Object>> enrollmentOwnership(int customer, int program) {
		return query("select top 1 internal_code from reb_prg_cust_mapping "
				+ "where ref_cust_code=? and ref_prg_code=? and approval_status='Approved'",
				customer, program);
	}

	private List<Map<String, Object>> query(String sql, Object... args) {
		logSql(sql, args);
		return NativeQuerySupport.executeQuery(registry, HibernateFactoryRegistry.INFOAPPS, sql, args);
	}

	private int update(String sql, Object... args) {
		logSql(sql, args);
		return NativeQuerySupport.executeUpdate(registry, HibernateFactoryRegistry.INFOAPPS, sql, args);
	}

	private List<Map<String, Object>> queryInSession(org.hibernate.Session session, String sql, Object... args) {
		logSql(sql, args);
		return NativeQuerySupport.executeQueryInSession(session, sql, args);
	}

	private int updateInSession(org.hibernate.Session session, String sql, Object... args) {
		logSql(sql, args);
		return NativeQuerySupport.executeUpdateInSession(session, sql, args);
	}

	private static void logSql(String sql, Object... args) {
		logger.info("Rebate INFOAPPS SQL: {}", SqlDebugFormatter.render(sql, args));
	}

	private static BigDecimal decimal(Object value) {
		String text = text(value);
		if (text.isEmpty()) {
			return BigDecimal.ZERO;
		}
		try {
			BigDecimal amount = new BigDecimal(text);
			if (amount.signum() < 0 || amount.precision() > 16) {
				throw new IllegalArgumentException("Invoice value is outside the accepted range.");
			}
			return amount;
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException("Invoice value must be numeric.");
		}
	}

}
