package com.mmm.rebate;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.share.DiskShare;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;

final class RebateDocUpload {
	private static final Logger logger = LoggerFactory.getLogger(RebateDocUpload.class);
	private static final SMB2Dialect SMB3_DIALECT = SMB2Dialect.SMB_3_1_1;
	private static final String SHARE_PROCEDURE = "{call BPCSLCLIN.CMW010S(?,?,?)}";
	private static final String SHARE_CODE = "REBATE";
	private static final String SHARE_LOGIN = "";
	private static final String SHARE_SEARCH = "ATTACHMENT";
	private static final String SMB_DOMAIN = "MMM";
	private final HibernateFactoryRegistry registry;

	RebateDocUpload(HibernateFactoryRegistry registry) {
		this.registry = registry;
	}

	void put(String remoteName, MultipartFile upload) throws Exception {
		Share share = share();
		SMBClient client = new SMBClient(config());
		try (Connection connection = client.connect(share.host())) {
			var session = connection.authenticate(new AuthenticationContext(
					share.username(), share.password().toCharArray(), SMB_DOMAIN));
			try (DiskShare disk = (DiskShare) session.connectShare(share.name());
					com.hierynomus.smbj.share.File target = disk.openFile(
							remotePath(share, remoteName),
							EnumSet.of(AccessMask.GENERIC_WRITE),
							null,
							SMB2ShareAccess.ALL,
							SMB2CreateDisposition.FILE_OVERWRITE_IF,
							null);
					InputStream input = upload.getInputStream();
					java.io.OutputStream output = target.getOutputStream()) {
				input.transferTo(output);
			} finally {
				session.close();
			}
		} finally {
			client.close();
		}
	}

	byte[] get(String remoteName) throws Exception {
		Share share = share();
		SMBClient client = new SMBClient(config());
		try (Connection connection = client.connect(share.host())) {
			var session = connection.authenticate(new AuthenticationContext(
					share.username(), share.password().toCharArray(), SMB_DOMAIN));
			try (DiskShare disk = (DiskShare) session.connectShare(share.name());
					com.hierynomus.smbj.share.File source = disk.openFile(
							remotePath(share, remoteName),
							EnumSet.of(AccessMask.GENERIC_READ),
							null,
							SMB2ShareAccess.ALL,
							SMB2CreateDisposition.FILE_OPEN,
							null);
					InputStream input = source.getInputStream();
					ByteArrayOutputStream output = new ByteArrayOutputStream()) {
				input.transferTo(output);
				return output.toByteArray();
			} finally {
				session.close();
			}
		} finally {
			client.close();
		}
	}

	private Share share() {
		List<Map<String, Object>> rows = NativeQuerySupport.executeProcedure(
				registry,
				HibernateFactoryRegistry.AS400,
				SHARE_PROCEDURE,
				SHARE_CODE, SHARE_LOGIN, SHARE_SEARCH);
		for (Map<String, Object> row : rows) {
			String rawPath = text(value(row, "NWPATH")).replace('\\', '/');
			rawPath = rawPath.replaceFirst("(?i)^smb:", "").replaceFirst("^/+", "");
			while (rawPath.endsWith("/")) {
				rawPath = rawPath.substring(0, rawPath.length() - 1);
			}
			String[] parts = rawPath.split("/", 3);
			String username = text(value(row, "NWLID"));
			String password = text(value(row, "NWPWD"));
			if (parts.length < 2 || parts[0].isBlank() || parts[1].isBlank()
					|| username.isBlank() || password.isBlank()) {
				continue;
			}
			String host = parts[0];
			int port = host.indexOf(':');
			if (port > 0) {
				host = host.substring(0, port);
			}
			String folder = parts.length > 2 ? safeFolder(parts[2]) : "";
			logger.info("Rebate share host={} share={} folder={}", host, parts[1], folder);
			return new Share(host, parts[1], folder, username, password);
		}
		throw new IllegalStateException("Rebate attachment share settings were not returned by CMW010S.");
	}

	private static String remotePath(Share share, String remoteName) {
		String folder = share.folder().isEmpty() ? "REBATE" : share.folder();
		return folder + "/" + safeName(remoteName);
	}

	private static SmbConfig config() {
		return SmbConfig.builder().withDialects(SMB3_DIALECT).withEncryptData(true).build();
	}

	static String safeName(String value) {
		String name = value == null ? "" : value.trim();
		if (name.isEmpty() || name.length() > 180 || name.contains("..")
				|| name.indexOf('/') >= 0 || name.indexOf('\\') >= 0
				|| !name.matches("[A-Za-z0-9._-]+")) {
			throw new IllegalArgumentException("Invalid Rebate document name.");
		}
		return name;
	}

	private static String safeFolder(String value) {
		String folder = value == null ? "" : value.trim().replace('\\', '/');
		while (folder.startsWith("/")) {
			folder = folder.substring(1);
		}
		if (folder.isEmpty()) {
			return "";
		}
		for (String part : folder.split("/")) {
			if (part.isBlank() || ".".equals(part) || "..".equals(part)
					|| part.matches(".*[<>:\"|?*\\p{Cntrl}].*")) {
				throw new IllegalStateException("Rebate attachment share path is invalid.");
			}
		}
		return folder;
	}

	private static Object value(Map<String, Object> row, String name) {
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
				return entry.getValue();
			}
		}
		return null;
	}

	private record Share(String host, String name, String folder, String username, String password) {}
}
