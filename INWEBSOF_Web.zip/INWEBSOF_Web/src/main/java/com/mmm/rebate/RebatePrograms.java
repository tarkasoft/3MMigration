package com.mmm.rebate;

import static com.mmm.titpl.CommonFunctions.text;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Customer-facing Rebate Programs API backed by the INFOAPPS database.
 */
@RestController
@RequestMapping("/api/customer/rebate")
public class RebatePrograms {
	private static final Logger logger = LoggerFactory.getLogger(RebatePrograms.class);
	private static final Gson GSON = new Gson();
	private final RebateProgramSql sql;
	private final RebateDocUpload files;

	public RebatePrograms(HibernateFactoryRegistry registry) {
		this.sql = new RebateProgramSql(registry);
		this.files = new RebateDocUpload(registry);
	}

	@GetMapping("/context")
	public String context(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", customer.custCode());
			data.put("loginId", customer.loginId());
			data.put("customerName", customer.name());
			data.put("email", customer.email());
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/enrollment")
	public String enrollment(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			result.SetSuccess("success", sql.enrollment(customer.internalCode()));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/ytd")
	public String ytd(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			result.SetSuccess("success", sql.ytd(customer.internalCode()));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/claims")
	public String claims(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			result.SetSuccess("success", sql.claims(customer.internalCode()));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/claims/{program}/{claimCase}")
	public String claim(HttpServletRequest request, @PathVariable int program, @PathVariable long claimCase,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			List<Map<String, Object>> claims = sql.claim(customer.internalCode(), program, claimCase);
			if (claims == null || claims.isEmpty() || claims.get(0) == null) {
				throw new IllegalArgumentException("Claim not found for this customer.");
			}
			Map<String, Object> claimRow = jsonSafeRow(claims.get(0));
			List<Map<String, Object>> invoices;
			List<Map<String, Object>> documents;
			try {
				invoices = jsonSafeRows(sql.invoices(customer.internalCode(), program, claimCase));
				Map<String, Map<String, Object>> skuByState = new LinkedHashMap<>();
				for (Map<String, Object> sku : sql.skuHints(customer.internalCode(), program, claimCase)) {
					String state = text(cell(sku, "state_code"));
					if (!state.isEmpty()) {
						skuByState.put(state, sku);
					}
				}
				for (Map<String, Object> invoice : invoices) {
					Map<String, Object> sku = skuByState.get(text(cell(invoice, "state_code")));
					invoice.put("hsn_code", sku == null ? "" : text(cell(sku, "hsn_code")));
					invoice.put("item_desc", sku == null ? "" : text(cell(sku, "item_desc")));
				}
			} catch (Exception ex) {
				throw new IllegalStateException("Unable to load claim invoices. " + rootDetail(ex), ex);
			}
			try {
				documents = jsonSafeRows(sql.programDocuments(customer.internalCode(), program, claimCase));
			} catch (Exception ex) {
				throw new IllegalStateException("Unable to load claim documents. " + rootDetail(ex), ex);
			}
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("claim", claimRow);
			data.put("invoices", invoices);
			data.put("documents", documents);
			data.put("editable", editableStatus(text(cell(claimRow, "claim_status"))));
			result.SetSuccess("success", data);
			return GSON.toJson(result);
		} catch (Exception ex) {
			return error(result, ex);
		}
	}

	@PostMapping("/enroll")
	public String enroll(HttpServletRequest request, @RequestBody Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, value(body, "custCode"), value(body, "loginId"));
			int program = positiveInt(body.get("program"), "Program");
			sql.enroll(customer.internalCode(), program, customer.loginId());
			Map<String, Object> details = first(sql.programDetails(customer.internalCode(), program));
			String programName = text(cell(details, "program_name"));
			RebateMail.send(customer.email(), text(cell(details, "email_cc")),
					"Successfully enrolled in Rebate program " + text(cell(details, "program_no")),
					"Dear Customer,<br><br>You have enrolled in <b>" + escape(programName)
							+ "</b>. The program period is " + escape(text(cell(details, "start_date")))
							+ " to " + escape(text(cell(details, "end_date")))
							+ ".<br><br>3M India Rebates Management Team");
			Map<String, Object> data = Map.of("message", "Enrollment completed and confirmation email sent.");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping("/discrepancy")
	public String discrepancy(HttpServletRequest request, @RequestBody Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, value(body, "custCode"), value(body, "loginId"));
			int program = positiveInt(body.get("program"), "Program");
			String type = value(body, "type");
			String remarks = value(body, "remarks").trim();
			if (!("YTD".equals(type) || "Invoice".equals(type)) || remarks.isEmpty() || remarks.length() > 2000) {
				throw new IllegalArgumentException("Choose a valid discrepancy type and enter a description.");
			}
			sql.discrepancy(customer.internalCode(), program, type, remarks);
			Map<String, Object> details = first(sql.programDetails(customer.internalCode(), program));
			String subject = type + " discrepancy for program "
					+ text(cell(details, "program_no"));
			RebateMail.send(customer.email(), text(cell(details, "email_cc")),
					subject, "Your discrepancy has been received.<br><br>3M India Rebates Management Team");
			RebateMail.send("3mrebatesmanagement.in@mmm.com",
					text(cell(details, "email_cc")), subject,
					"Please review the following customer discrepancy:<br><br>" + escape(remarks)
							+ "<br><br>3M India Rebates Management Team");
			result.SetSuccess("success", Map.of("message", "Your request has been submitted."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping("/claim/submit")
	public String submitClaim(HttpServletRequest request, @RequestBody Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, value(body, "custCode"), value(body, "loginId"));
			int program = positiveInt(body.get("program"), "Program");
			long claimCase = positiveLong(body.get("claimCase"), "Claim");
			String type = value(body, "type");
			/* Legacy SubmitFinalData('Draft'|'Submit'); accept Save as Draft alias. */
			if ("Save".equalsIgnoreCase(type)) {
				type = "Draft";
			}
			if (!("Submit".equals(type) || "Draft".equals(type))) {
				throw new IllegalArgumentException("Invalid claim action.");
			}
			if ("Submit".equals(type)) {
				if (!Boolean.TRUE.equals(body.get("termsAccepted"))) {
					throw new IllegalArgumentException("Accept the claim terms and conditions before submitting.");
				}
				if (!Boolean.TRUE.equals(body.get("panVerified")) && !Boolean.TRUE.equals(body.get("updateRequested"))) {
					throw new IllegalArgumentException("Select a PAN/GST declaration before submitting.");
				}
				List<Map<String, Object>> requiredDocuments =
						sql.programDocuments(customer.internalCode(), program, claimCase);
				for (Map<String, Object> document : requiredDocuments) {
					if ("Yes".equalsIgnoreCase(text(cell(document, "is_mandatory")))
							&& text(cell(document, "doc_name")).isEmpty()) {
						throw new IllegalArgumentException("Upload all mandatory claim documents before submitting.");
					}
				}
			}
			Object rawInvoices = body.get("invoices");
			if (!(rawInvoices instanceof List<?> rows)) {
				throw new IllegalArgumentException("Invoice details are required.");
			}
			List<Map<String, Object>> invoices = rows.stream()
					.filter(Map.class::isInstance)
					.map(row -> (Map<String, Object>) row)
					.toList();
			if ("Submit".equals(type)) {
				for (Map<String, Object> invoice : sql.invoices(customer.internalCode(), program, claimCase)) {
					if (text(cell(invoice, "u_invoice_doc_path")).isEmpty()
							|| text(cell(invoice, "u_invoice_gst_doc_path")).isEmpty()) {
						throw new IllegalArgumentException("Upload all invoice and GST evidence before submitting.");
					}
				}
			}
			sql.submitClaim(customer.internalCode(), program, claimCase, type,
					value(body, "panRemarks"), Boolean.TRUE.equals(body.get("panVerified")),
					Boolean.TRUE.equals(body.get("updateRequested")), invoices);
			if ("Submit".equals(type)) {
				Map<String, Object> details = first(sql.programDetails(customer.internalCode(), program));
				String claimNo = text(cell(sql.claim(customer.internalCode(), program, claimCase).get(0), "claim_no"));
				String subject = "Claim submitted: " + claimNo;
				String bodyText = "Your claim " + escape(claimNo) + " has been submitted for "
						+ escape(text(cell(details, "program_name")))
						+ ".<br><br>3M India Rebates Management Team";
				RebateMail.send(customer.email(), text(cell(details, "email_cc")), subject, bodyText);
				RebateMail.send(text(cell(details, "inv_approver_email")),
						text(cell(details, "email_cc")), subject,
						"A Rebate claim has been submitted by customer " + escape(customer.custCode())
								+ ". Claim: " + escape(claimNo) + ".<br><br>" + escape(value(body, "panRemarks")));
			}
			result.SetSuccess("success", Map.of("message",
					"Submit".equals(type) ? "Claim submitted and notification email sent."
							: "Claim saved for later (Draft)."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	/**
	 * Save invoice line fields when evidence files are already uploaded (no new file required).
	 * POST /api/customer/rebate/claim/invoice-details
	 */
	@PostMapping("/claim/invoice-details")
	public String updateInvoiceDetails(HttpServletRequest request, @RequestBody Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, value(body, "custCode"), value(body, "loginId"));
			int program = positiveInt(body.get("program"), "Program");
			long claimCase = positiveLong(body.get("claimCase"), "Claim");
			String stateCode = value(body, "stateCode");
			if (stateCode.isEmpty()) {
				throw new IllegalArgumentException("State is required.");
			}
			List<Map<String, Object>> claims = sql.claim(customer.internalCode(), program, claimCase);
			if (claims.isEmpty()) {
				throw new IllegalArgumentException("Claim not found for this customer.");
			}
			if (!editableStatus(text(cell(claims.get(0), "claim_status")))) {
				throw new IllegalArgumentException("This claim is not open for customer updates.");
			}
			Map<String, Object> line = sql.invoices(customer.internalCode(), program, claimCase).stream()
					.filter(row -> stateCode.equals(String.valueOf(cell(row, "state_code"))))
					.findFirst()
					.orElseThrow(() -> new IllegalArgumentException("State is not part of this claim."));
			if (text(cell(line, "u_invoice_doc_path")).isEmpty()
					&& text(cell(line, "u_invoice_doc_name")).isEmpty()) {
				throw new IllegalArgumentException("Upload the invoice copy before saving details only.");
			}
			String taxType = value(body, "taxType");
			if (!("IGST".equals(taxType) || "CGSTSGST".equals(taxType))) {
				throw new IllegalArgumentException("Select a valid GST type.");
			}
			String invoiceNo = value(body, "invoiceNo");
			if (invoiceNo.isEmpty()) {
				throw new IllegalArgumentException("Invoice number is required.");
			}
			String claimNo = text(cell(claims.get(0), "claim_no"));
			sql.updateInvoiceDetails(customer.internalCode(), program, claimCase, stateCode, claimNo,
					taxType, invoiceNo, value(body, "invoiceDate"), amount(value(body, "invoiceValue")));
			result.SetSuccess("success", Map.of("message", "Invoice details saved."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@PostMapping("/claim/upload")
	public String uploadInvoiceEvidence(HttpServletRequest request, @RequestParam("file") MultipartFile file,
			@RequestParam String custCode, @RequestParam String loginId, @RequestParam int program,
			@RequestParam long claimCase, @RequestParam String stateCode, @RequestParam String kind) {
		return upload(request, file, custCode, loginId, program, claimCase, stateCode, kind, 0);
	}

	@PostMapping("/claim/program-document")
	public String uploadProgramDocument(HttpServletRequest request, @RequestParam("file") MultipartFile file,
			@RequestParam String custCode, @RequestParam String loginId, @RequestParam int program,
			@RequestParam long claimCase, @RequestParam int documentCode) {
		return upload(request, file, custCode, loginId, program, claimCase, "", "PROGRAM", documentCode);
	}

	private String upload(HttpServletRequest request, MultipartFile file, String custCode, String loginId,
			int program, long claimCase, String stateCode, String kind, int documentCode) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			if (file == null || file.isEmpty() || file.getSize() > 20L * 1024 * 1024) {
				throw new IllegalArgumentException("Select a file smaller than 20 MB.");
			}
			List<Map<String, Object>> claims = sql.claim(customer.internalCode(), program, claimCase);
			if (claims.isEmpty()) {
				throw new IllegalArgumentException("Claim not found for this customer.");
			}
			if (!editableStatus(text(cell(claims.get(0), "claim_status")))) {
				throw new IllegalArgumentException("This claim is not open for customer updates.");
			}
			String extension = extension(file.getOriginalFilename());
			String safeDisplayName = displayName(file.getOriginalFilename());
			String remoteName = "reb_" + customer.internalCode() + "_" + program + "_" + claimCase + "_"
					+ kind.toLowerCase(java.util.Locale.ROOT) + "_" + UUID.randomUUID().toString().replace("-", "") + extension;
			String type = kind.toUpperCase(java.util.Locale.ROOT);
			if ("PROGRAM".equals(type)) {
				if (sql.programDocuments(customer.internalCode(), program, claimCase).stream()
						.noneMatch(row -> String.valueOf(cell(row, "doc_code")).equals(String.valueOf(documentCode)))) {
					throw new IllegalArgumentException("Document is not assigned to this program.");
				}
				files.put(remoteName, file);
				sql.saveProgramDocument(customer.internalCode(), program, claimCase, documentCode, safeDisplayName, remoteName);
			} else {
				if (!("INVOICE".equals(type) || "GST".equals(type))) {
					throw new IllegalArgumentException("Invalid evidence type.");
				}
				List<Map<String, Object>> payoutLines = sql.invoices(customer.internalCode(), program, claimCase);
				payoutLines.stream()
						.filter(row -> stateCode.equals(String.valueOf(cell(row, "state_code"))))
						.findFirst().orElseThrow(() -> new IllegalArgumentException("State is not part of this claim."));
				String taxType = request.getParameter("taxType");
				String invoiceNo = request.getParameter("invoiceNo");
				String invoiceDate = request.getParameter("invoiceDate");
				String invoiceValue = request.getParameter("invoiceValue");
				String claimNo = text(cell(claims.get(0), "claim_no"));
				files.put(remoteName, file);
				sql.saveInvoiceEvidence(customer.internalCode(), program, claimCase,
						stateCode, claimNo, taxType, invoiceNo == null ? "" : invoiceNo,
						invoiceDate == null ? "" : invoiceDate, amount(invoiceValue),
						type, safeDisplayName, remoteName);
			}
			result.SetSuccess("success", Map.of("message", "File uploaded."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@DeleteMapping("/claim/program-document/{documentCode}")
	public String deleteProgramDocument(HttpServletRequest request, @PathVariable int documentCode,
			@RequestParam String custCode, @RequestParam String loginId,
			@RequestParam int program, @RequestParam long claimCase) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			List<Map<String, Object>> claims = sql.claim(customer.internalCode(), program, claimCase);
			if (claims.isEmpty()) {
				throw new IllegalArgumentException("Claim not found for this customer.");
			}
			if (!editableStatus(text(cell(claims.get(0), "claim_status")))) {
				throw new IllegalArgumentException("This claim is not open for customer updates.");
			}
			if (sql.deleteProgramDocument(customer.internalCode(), program, claimCase, documentCode) == 0) {
				throw new IllegalArgumentException("Document was already removed or does not belong to this claim.");
			}
			result.SetSuccess("success", Map.of("message", "Document deleted."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/claim/program-document/{documentCode}/download")
	public ResponseEntity<byte[]> downloadProgramDocument(HttpServletRequest request,
			@PathVariable int documentCode, @RequestParam int program, @RequestParam long claimCase,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			Customer customer = customer(request, custCode, loginId);
			if (sql.claim(customer.internalCode(), program, claimCase).isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			List<Map<String, Object>> rows = sql.programDocument(
					customer.internalCode(), program, claimCase, documentCode);
			if (rows.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			String name = RebateDocUpload.safeName(text(cell(rows.get(0), "doc_path")));
			return download(name, text(cell(rows.get(0), "doc_name")), files.get(name));
		} catch (Exception ex) {
			logger.error("Unable to download Rebate program document", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	@DeleteMapping("/claim/evidence/{program}/{claimCase}/{stateCode}/{kind}")
	public String deleteEvidence(HttpServletRequest request, @PathVariable int program,
			@PathVariable long claimCase, @PathVariable String stateCode, @PathVariable String kind,
			@RequestParam String custCode, @RequestParam String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			List<Map<String, Object>> claims = sql.claim(customer.internalCode(), program, claimCase);
			if (claims.isEmpty()) {
				throw new IllegalArgumentException("Claim not found for this customer.");
			}
			if (!editableStatus(text(cell(claims.get(0), "claim_status")))) {
				throw new IllegalArgumentException("This claim is not open for customer updates.");
			}
			String normalizedKind = kind == null ? "" : kind.toUpperCase(java.util.Locale.ROOT);
			if (!("INVOICE".equals(normalizedKind) || "GST".equals(normalizedKind))) {
				throw new IllegalArgumentException("Invalid evidence type.");
			}
			if (sql.deleteInvoiceEvidence(customer.internalCode(), program, claimCase, stateCode, normalizedKind) == 0) {
				throw new IllegalArgumentException("Evidence was already removed or does not belong to this claim.");
			}
			result.SetSuccess("success", Map.of("message", "File deleted."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/claim/evidence/{program}/{claimCase}/{stateCode}/{kind}")
	public ResponseEntity<byte[]> downloadEvidence(HttpServletRequest request,
			@PathVariable int program, @PathVariable long claimCase, @PathVariable String stateCode,
			@PathVariable String kind,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			Customer customer = customer(request, custCode, loginId);
			if (sql.claim(customer.internalCode(), program, claimCase).isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			List<Map<String, Object>> invoices = sql.invoices(customer.internalCode(), program, claimCase);
			Map<String, Object> invoice = invoices.stream()
					.filter(row -> stateCode.equals(String.valueOf(cell(row, "state_code"))))
					.findFirst().orElse(null);
			String normalizedKind = kind.toUpperCase(java.util.Locale.ROOT);
			String pathColumn = "INVOICE".equals(normalizedKind) ? "u_invoice_doc_path"
					: "GST".equals(normalizedKind) ? "u_invoice_gst_doc_path" : "";
			String nameColumn = "INVOICE".equals(normalizedKind) ? "u_invoice_doc_name"
					: "GST".equals(normalizedKind) ? "u_invoice_gst_doc_name" : "";
			if (invoice == null || pathColumn.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			String remote = RebateDocUpload.safeName(text(cell(invoice, pathColumn)));
			if (remote.isBlank()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			return download(remote, text(cell(invoice, nameColumn)), files.get(remote));
		} catch (Exception ex) {
			logger.error("Unable to download Rebate claim evidence", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	@GetMapping("/programs/{program}/document")
	public ResponseEntity<byte[]> downloadProgramFile(HttpServletRequest request, @PathVariable int program,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		try {
			Customer customer = customer(request, custCode, loginId);
			List<Map<String, Object>> rows = sql.programFile(customer.internalCode(), program);
			if (rows.isEmpty() || text(cell(rows.get(0), "doc_path")).isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			String remote = RebateDocUpload.safeName(text(cell(rows.get(0), "doc_path")));
			return download(remote, text(cell(rows.get(0), "doc_name")), files.get(remote));
		} catch (Exception ex) {
			logger.error("Unable to download Rebate program document", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	@GetMapping("/programs/{program}/details")
	public String programDetails(HttpServletRequest request, @PathVariable int program,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Customer customer = customer(request, custCode, loginId);
			result.SetSuccess("success", Map.of("program",
					first(sql.programDetails(customer.internalCode(), program))));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	private Customer customer(HttpServletRequest request, String custCode, String loginId) {
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(session, custCode, loginId);
		String userType = String.valueOf(session.getAttribute(UserSessionSupport.LOGIN_USER_TYPE));
		if (!isCustomer(userType) && !context.overridden()) {
			throw new IllegalArgumentException("Rebate Programs is available to customer accounts only.");
		}
		List<Map<String, Object>> rows = sql.customer(context.custCode());
		if (rows.isEmpty()) {
			throw new IllegalArgumentException("No Rebate customer record exists for the selected customer.");
		}
		Map<String, Object> row = rows.get(0);
		int internalCode = positiveInt(cell(row, "internal_code"), "Customer");
		return new Customer(internalCode, context.custCode(), context.loginId(),
				text(cell(row, "cust_name")), text(cell(row, "email")));
	}

	private static String error(ResponseDataGeneric result, Exception ex) {
		if (ex instanceof IllegalStateException && UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure", ex.getMessage());
		} else {
			boolean expected = (ex instanceof IllegalArgumentException)
					|| (ex instanceof IllegalStateException && ex.getCause() == null);
			if (!expected) {
				logger.error("Rebate request failed", ex);
			}
			result.SetError(-1, "failure", userFacingMessage(ex));
		}
		return GSON.toJson(result);
	}

	private static String userFacingMessage(Exception ex) {
		if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
			String message = ex.getMessage();
			return message == null || message.isBlank() ? "The request could not be completed." : message;
		}
		return "Unable to complete the Rebate request: " + rootDetail(ex);
	}

	private static String rootDetail(Throwable ex) {
		Throwable root = ex;
		while (root.getCause() != null && root.getCause() != root) {
			root = root.getCause();
		}
		String detail = root.getMessage();
		if (detail != null && !detail.isBlank()) {
			return detail;
		}
		StackTraceElement[] stack = root.getStackTrace();
		if (stack != null && stack.length > 0) {
			return root.getClass().getSimpleName() + " at " + stack[0];
		}
		return root.getClass().getSimpleName();
	}

	private static List<Map<String, Object>> jsonSafeRows(List<Map<String, Object>> rows) {
		if (rows == null || rows.isEmpty()) {
			return List.of();
		}
		List<Map<String, Object>> out = new java.util.ArrayList<>(rows.size());
		for (Map<String, Object> row : rows) {
			if (row != null) {
				out.add(jsonSafeRow(row));
			}
		}
		return out;
	}

	private static Map<String, Object> jsonSafeRow(Map<String, Object> row) {
		Map<String, Object> copy = new LinkedHashMap<>();
		if (row == null) {
			return copy;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (entry.getKey() == null) {
				continue;
			}
			Object value = entry.getValue();
			if (value == null || value instanceof String || value instanceof Number || value instanceof Boolean) {
				copy.put(entry.getKey(), value);
			} else {
				copy.put(entry.getKey(), String.valueOf(value));
			}
		}
		return copy;
	}

	private static int positiveInt(Object value, String label) {
		long parsed = positiveLong(value, label);
		if (parsed > Integer.MAX_VALUE) {
			throw new IllegalArgumentException(label + " is invalid.");
		}
		return (int) parsed;
	}

	private static long positiveLong(Object value, String label) {
		try {
			long parsed = Long.parseLong(String.valueOf(value));
			if (parsed <= 0) {
				throw new NumberFormatException();
			}
			return parsed;
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException(label + " is invalid.");
		}
	}

	private static String value(Map<String, Object> body, String key) {
		Object result = body.get(key);
		return result == null ? "" : String.valueOf(result);
	}

	private static BigDecimal amount(String value) {
		try {
			BigDecimal amount = new BigDecimal(value == null || value.isBlank() ? "0" : value);
			if (amount.signum() < 0 || amount.precision() > 16) {
				throw new NumberFormatException();
			}
			return amount;
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException("Invoice value must be a valid non-negative amount.");
		}
	}

	private static String extension(String originalName) {
		String name = originalName == null ? "" : originalName;
		int dot = name.lastIndexOf('.');
		if (dot < 0) {
			throw new IllegalArgumentException("Files must have a supported extension.");
		}
		String extension = name.substring(dot).toLowerCase(java.util.Locale.ROOT);
		if (!List.of(".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png").contains(extension)) {
			throw new IllegalArgumentException("Supported files are PDF, Office documents, JPG, and PNG.");
		}
		return extension;
	}

	private static String displayName(String originalName) {
		String value = originalName == null ? "document" : originalName.trim();
		value = value.replaceAll("[^A-Za-z0-9._-]", "_");
		return value.length() > 120 ? value.substring(value.length() - 120) : value;
	}

	private ResponseEntity<byte[]> download(String remoteName, String displayName, byte[] content) {
		String safeDisplay = displayName == null || displayName.isBlank() ? remoteName : displayName;
		MediaType type = remoteName.toLowerCase(java.util.Locale.ROOT).endsWith(".pdf")
				? MediaType.APPLICATION_PDF : MediaType.APPLICATION_OCTET_STREAM;
		return ResponseEntity.ok().contentType(type)
				.header(HttpHeaders.CONTENT_DISPOSITION,
						ContentDisposition.attachment().filename(safeDisplay).build().toString())
				.body(content);
	}

	private static Object cell(Map<String, Object> row, String key) {
		if (row == null || key == null) {
			return null;
		}
		return row.entrySet().stream()
				.filter(entry -> entry.getKey() != null && entry.getKey().equalsIgnoreCase(key))
				.map(Map.Entry::getValue).findFirst().orElse(null);
	}

	private static Map<String, Object> first(List<Map<String, Object>> rows) {
		if (rows == null || rows.isEmpty()) {
			throw new IllegalArgumentException("The selected Rebate program was not found.");
		}
		return rows.get(0);
	}

	private static String escape(String value) {
		return value == null ? "" : value.replace("&", "&amp;").replace("<", "&lt;")
				.replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;");
	}

	private static boolean isCustomer(String value) {
		return "CUST".equalsIgnoreCase(value) || "Customer".equalsIgnoreCase(value)
				|| "Vendor".equalsIgnoreCase(value) || "VEND".equalsIgnoreCase(value);
	}

	private static boolean editableStatus(String status) {
		return status == null || status.isBlank() || "Draft".equalsIgnoreCase(status)
				|| "Save".equalsIgnoreCase(status) || "Sent for Rework".equalsIgnoreCase(status);
	}

	private record Customer(int internalCode, String custCode, String loginId, String name, String email) {}
}
