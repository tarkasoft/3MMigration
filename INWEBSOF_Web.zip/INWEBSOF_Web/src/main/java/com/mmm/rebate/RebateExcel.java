package com.mmm.rebate;

import static com.mmm.titpl.CommonFunctions.sqlDate;
import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/customer/rebate")
public class RebateExcel {
	private static final Logger logger = LoggerFactory.getLogger(RebateExcel.class);
	private final RebateProgramSql sql;

	public RebateExcel(HibernateFactoryRegistry registry) {
		this.sql = new RebateProgramSql(registry);
	}

	@GetMapping("/claims/export")
	public ResponseEntity<byte[]> exportClaims(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "from", required = false) String fromDate,
			@RequestParam(value = "to", required = false) String toDate) {
		try {
			int customerCode = customer(request, custCode, loginId);
			String from = sqlDate(fromDate, "Approval from date");
			String to = sqlDate(toDate, "Approval to date");
			validateDateRange(from, to);
			List<Map<String, Object>> claims = sql.claimsExport(customerCode, from, to);
			try (XSSFWorkbook workbook = new XSSFWorkbook();
					ByteArrayOutputStream output = new ByteArrayOutputStream()) {
				var sheet = workbook.createSheet("Rebate Claims");
				String[] columns = {"Claim No", "Program No", "Program Name", "Division", "Program Period",
						"Program Target", "Final Achievement", "Final Payout", "Claim Status", "Credit Note No",
						"State Code", "3M GST No", "Claim Value", "Invoice No", "Invoice Date", "Invoice Value"};
				String[] keys = {"claim_no", "program_no", "program_name", "div_name", "period",
						"target", "ytd_acheived", "final_payout", "claim_status", "credit_note_no",
						"state_code", "mmm_gst_no", "final_payout", "cust_inv_no", "cust_inv_date", "inv_value"};
				boolean[] numeric = {false, false, false, false, false, true, true, true, false, false,
						false, false, true, false, false, true};

				CellStyle headerStyle = workbook.createCellStyle();
				Font headerFont = workbook.createFont();
				headerFont.setFontName("Arial");
				headerFont.setFontHeightInPoints((short) 10);
				headerFont.setBold(true);
				headerStyle.setFont(headerFont);
				headerStyle.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
				headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				headerStyle.setAlignment(HorizontalAlignment.CENTER);
				headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
				headerStyle.setBorderTop(BorderStyle.THIN);
				headerStyle.setBorderBottom(BorderStyle.THIN);
				headerStyle.setBorderLeft(BorderStyle.THIN);
				headerStyle.setBorderRight(BorderStyle.THIN);

				Row header = sheet.createRow(0);
				for (int i = 0; i < columns.length; i++) {
					Cell cell = header.createCell(i);
					cell.setCellValue(columns[i]);
					cell.setCellStyle(headerStyle);
				}

				for (int r = 0; r < claims.size(); r++) {
					Map<String, Object> claim = claims.get(r);
					Row row = sheet.createRow(r + 1);
					for (int c = 0; c < keys.length; c++) {
						String value = text(cell(claim, keys[c]));
						if (numeric[c]) {
							row.createCell(c).setCellValue(number(value));
						} else {
							row.createCell(c).setCellValue(value);
						}
					}
				}
				for (int i = 0; i < columns.length; i++) {
					sheet.autoSizeColumn(i);
				}
				workbook.write(output);
				return ResponseEntity.ok()
						.contentType(MediaType.parseMediaType(
								"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
						.header(HttpHeaders.CONTENT_DISPOSITION,
								ContentDisposition.attachment().filename("rebate_claims.xlsx").build().toString())
						.body(output.toByteArray());
			}
		} catch (IllegalArgumentException | IllegalStateException ex) {
			logger.warn("Rebate Excel request rejected: {}", ex.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		} catch (Exception ex) {
			logger.error("Unable to export Rebate claims", ex);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	private int customer(HttpServletRequest request, String custCode, String loginId) {
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(session, custCode, loginId);
		String userType = String.valueOf(session.getAttribute(UserSessionSupport.LOGIN_USER_TYPE));
		if (!isCustomer(userType) && !context.overridden()) {
			throw new IllegalArgumentException("Rebate Programs is available to customer accounts only.");
		}
		List<Map<String, Object>> rows = sql.customer(context.custCode());
		if (rows.isEmpty()) {
			throw new IllegalArgumentException("No Rebate customer record exists for the selected customer.");
		}
		Object code = cell(rows.get(0), "internal_code");
		try {
			int parsed = Integer.parseInt(String.valueOf(code));
			if (parsed <= 0) {
				throw new NumberFormatException();
			}
			return parsed;
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException("Customer is invalid.");
		}
	}

	private static void validateDateRange(String fromDate, String toDate) {
		boolean hasFrom = fromDate != null;
		boolean hasTo = toDate != null;
		if (hasFrom != hasTo) {
			throw new IllegalArgumentException("Select both approval-date limits or leave both blank.");
		}
		if (hasFrom && LocalDate.parse(fromDate).isAfter(LocalDate.parse(toDate))) {
			throw new IllegalArgumentException("The approval-date range is invalid.");
		}
	}

	private static Object cell(Map<String, Object> row, String key) {
		return row.entrySet().stream()
				.filter(entry -> entry.getKey() != null && entry.getKey().equalsIgnoreCase(key))
				.map(Map.Entry::getValue).findFirst().orElse(null);
	}

	private static double number(String value) {
		if (value == null || value.isBlank()) {
			return 0d;
		}
		try {
			return Double.parseDouble(value.trim());
		} catch (NumberFormatException ex) {
			return 0d;
		}
	}

	private static boolean isCustomer(String value) {
		return "CUST".equalsIgnoreCase(value) || "Customer".equalsIgnoreCase(value)
				|| "Vendor".equalsIgnoreCase(value) || "VEND".equalsIgnoreCase(value);
	}
}
