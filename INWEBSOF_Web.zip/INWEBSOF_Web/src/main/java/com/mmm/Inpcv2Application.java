package com.mmm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * INPCV2 Spring Boot WAR entry (EAP 8 Undertow / OpenShift / Eclipse Tomcat 10.1).
 * Parent: Spring Boot 3.5.16 (Java 21). Boot 4.x needs Tomcat 11 — see doc/DEPENDENCY_VAPT.md.
 *
 * Uses excludeName (strings) so Eclipse never emits an "Unresolved compilation problems"
 * stub when the Maven classpath briefly lags a parent bump.
 */
@SpringBootApplication(excludeName = {
        "org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration",
        "org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration",
        "org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration"
})
public class Inpcv2Application extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(Inpcv2Application.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(Inpcv2Application.class, args);
    }
}