package com.mmm.customer.account_status;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Types;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Statement of Accounts — single-file API.
 * COS011S does not return a ledger. It returns one output, SOAFILENAME.
 * The PDF sits on FTP under /temp/CUSSOA, the same folder credit-release uses.
 *
 * GET /api/customer/account-status/statement?custCode=&loginId=&fromDate=&toDate=&dummy=
 * GET /api/customer/account-status/statement/file?...  streams that PDF.
 *
 * The tab has no date picker, so a blank range is first day of last month
 * through today. The procedure wants yyyyMM, not a full day.
 */
@RestController
@RequestMapping("/api/customer/account-status/statement")
public class StatementOfAccounts {

	private static final Logger logger = LoggerFactory.getLogger(StatementOfAccounts.class);
	private static final DateTimeFormatter YMD = DateTimeFormatter.BASIC_ISO_DATE;
	private static final DateTimeFormatter YM = DateTimeFormatter.ofPattern("yyyyMM");
	private static final DateTimeFormatter PERIOD = DateTimeFormatter.ofPattern("MMM yyyy");
	private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd/MM/uuuu");
	private static final DateTimeFormatter DMY_DASH = DateTimeFormatter.ofPattern("dd-MM-uuuu");

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	@Value("${inpc.account-status.app-code:INPC}")
	private String appCode;

	/** Same FTP settings as invoice/credit PDF download. Base path default is /temp/CUSSOA. */
	@Value("${inpc.credit-release.ftp-host:US400IN}")
	private String ftpHost;

	@Value("${inpc.credit-release.ftp-port:21}")
	private int ftpPort;

	@Value("${inpc.credit-release.ftp-username:}")
	private String ftpUsername;

	@Value("${inpc.credit-release.ftp-password:}")
	private String ftpPassword;

	@Value("${inpc.credit-release.ftp-base-path:/temp/CUSSOA}")
	private String ftpBasePath;

	public StatementOfAccounts(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Statement request: custCode={}, loginId={}, fromDate={}, toDate={}, dummy={}",
				custCode, loginId, fromDate, toDate, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			DateRange range = resolveRange(fromDate, toDate);
			if (range.error != null) {
				result.SetError(-1, "failure", range.error);
				return gson.toJson(result);
			}

			List<Map<String, Object>> rows = dummy
					? dummyRows(code)
					: loadAs400Rows(login, code, range);

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("fromMonth", range.from.format(YM));
			data.put("toMonth", range.to.format(YM));
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load statement of accounts", ex);
			result.SetError(-1, "failure", "Unable to load statement of accounts");
		}
		return gson.toJson(result);
	}

	@GetMapping("/file")
	public ResponseEntity<byte[]> file(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		if (dummy) {
			return ResponseEntity.badRequest().build();
		}
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			if (context.custCode().isEmpty()) {
				return ResponseEntity.badRequest().build();
			}
			DateRange range = resolveRange(fromDate, toDate);
			if (range.error != null) {
				return ResponseEntity.badRequest().build();
			}
			String fileName = soaFileName(context.loginId(), range);
			if (fileName.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			byte[] pdf = fetchPdf(fileName);
			return pdfResponse(fileName, pdf);
		} catch (Exception ex) {
			logger.error("Unable to download statement PDF", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	private List<Map<String, Object>> loadAs400Rows(String loginId, String custCode, DateRange range) {
		String fileName = soaFileName(loginId, range);
		if (fileName.isEmpty()) {
			return new ArrayList<>();
		}
		Map<String, Object> row = new LinkedHashMap<>();
		row.put("period", range.from.format(PERIOD) + " to " + range.to.format(PERIOD));
		row.put("opening", "");
		row.put("charges", "");
		row.put("payments", "");
		row.put("closing", "");
		row.put("action", fileName);
		row.put("fileName", fileName);
		row.put("custCode", custCode);
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row);
		return rows;
	}

	private String soaFileName(String loginId, DateRange range) {
		String code = appCode == null ? "" : appCode.trim();
		String fromYm = range.from.format(YM);
		String toYm = range.to.format(YM);
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS011S("
				+ sqlLiteral(code) + ","
				+ sqlLiteral(loginId) + ","
				+ sqlLiteral(fromYm) + ","
				+ sqlLiteral(toYm) + ",? /* OUT SOAFILENAME */)");
		Map<Integer, Object> outputs = NativeQuerySupport.executeProcedureWithOutputs(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS011S(?,?,?,?,?)}",
				Map.of(5, Types.VARCHAR),
				code, loginId, fromYm, toYm);
		String fileName = text(outputs.get(5)).toUpperCase();
		if (fileName.isEmpty()) {
			logger.info("COS011S returned a blank SOAFILENAME.");
			return "";
		}
		if (fileName.indexOf('/') >= 0 || fileName.indexOf('\\') >= 0 || fileName.contains("..")) {
			throw new IllegalStateException("AS400 returned an invalid statement filename");
		}
		logger.info("COS011S SOAFILENAME={}", fileName);
		return fileName;
	}

	private byte[] fetchPdf(String fileName) {
		if (ftpUsername == null || ftpUsername.isBlank() || ftpPassword == null || ftpPassword.isBlank()) {
			throw new IllegalStateException("Statement FTP credentials are not configured");
		}
		FTPClient ftp = new FTPClient();
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			ftp.setConnectTimeout(30_000);
			ftp.setDefaultTimeout(30_000);
			ftp.connect(ftpHost, ftpPort);
			ftp.setSoTimeout(60_000);
			if (!ftp.login(ftpUsername, ftpPassword)) {
				throw new IllegalStateException("FTP login failed");
			}
			ftp.enterLocalPassiveMode();
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
			String base = ftpBasePath == null ? "" : ftpBasePath.trim().replaceAll("/+$", "");
			String remotePath = base + "/" + fileName;
			System.out.println("Statement FTP get: " + remotePath);
			if (!ftp.retrieveFile(remotePath, out)) {
				throw new IllegalStateException("Statement PDF was not found on FTP");
			}
			return out.toByteArray();
		} catch (IOException ex) {
			throw new IllegalStateException("FTP read failed", ex);
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.logout();
				} catch (IOException ignored) {
					// Disconnect below.
				}
				try {
					ftp.disconnect();
				} catch (IOException ignored) {
					// Nothing else to release.
				}
			}
		}
	}

	private static ResponseEntity<byte[]> pdfResponse(String fileName, byte[] pdf) {
		String safeName = fileName.replaceAll("[^A-Za-z0-9._-]", "_");
		if (!safeName.toLowerCase().endsWith(".pdf")) {
			safeName = safeName + ".pdf";
		}
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + safeName + "\"")
				.contentType(MediaType.APPLICATION_PDF)
				.body(pdf);
	}

	private static DateRange resolveRange(String fromDate, String toDate) {
		LocalDate today = LocalDate.now();
		LocalDate from = parseDate(fromDate);
		LocalDate to = parseDate(toDate);
		if (from == null && to == null) {
			from = today.minusMonths(1).withDayOfMonth(1);
			to = today;
		}
		if (from == null || to == null) {
			return DateRange.error("Valid From Date and To Date are required");
		}
		if (from.isAfter(to)) {
			return DateRange.error("From Date cannot be after To Date");
		}
		if (to.isAfter(today)) {
			return DateRange.error("To Date cannot be in the future");
		}
		if (from.plusMonths(6).isBefore(to)) {
			return DateRange.error("Date range cannot exceed 6 months");
		}
		return new DateRange(YearMonth.from(from), YearMonth.from(to), null);
	}

	private static LocalDate parseDate(String raw) {
		String value = raw == null ? "" : raw.trim();
		if (value.isEmpty() || "0".equals(value) || "000000".equals(value) || "00000000".equals(value)) {
			return null;
		}
		try {
			if (value.length() == 6 && value.chars().allMatch(Character::isDigit)) {
				return YearMonth.parse(value, YM).atDay(1);
			}
			if (value.length() == 8 && value.chars().allMatch(Character::isDigit)) {
				return LocalDate.parse(value, YMD);
			}
			if (value.contains("/")) {
				return LocalDate.parse(value, DMY);
			}
			if (value.contains("-") && value.length() >= 10 && Character.isDigit(value.charAt(0))) {
				return LocalDate.parse(value.substring(0, 10), DMY_DASH);
			}
			return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
		} catch (DateTimeParseException ex) {
			return null;
		}
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static List<Map<String, Object>> dummyRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row("Sep 2026", 11666024, 485620, 703520, 11448124, "View PDF"));
		rows.add(row("Aug 2026", 12410500, 685240, 1429716, 11666024, "View PDF"));
		rows.add(row("Jul 2026", 11980100, 812400, 382000, 12410500, "View PDF"));
		rows.add(row("Jun 2026", 10550000, 540100, 410000, 11980100, "View PDF"));
		rows.add(row("May 2026", 9875250, 425750, 351000, 10550000, "View PDF"));
		rows.add(row("Apr 2026", 9200000, 390250, 2715000, 9875250, "View PDF"));
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static Map<String, Object> row(
			String period, double opening, double charges, double payments, double closing, String action) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("period", period);
		m.put("opening", opening);
		m.put("charges", charges);
		m.put("payments", payments);
		m.put("closing", closing);
		m.put("action", action);
		return m;
	}

	private static final class DateRange {
		private final YearMonth from;
		private final YearMonth to;
		private final String error;

		private DateRange(YearMonth from, YearMonth to, String error) {
			this.from = from;
			this.to = to;
			this.error = error;
		}

		private static DateRange error(String message) {
			return new DateRange(null, null, message);
		}
	}
}
