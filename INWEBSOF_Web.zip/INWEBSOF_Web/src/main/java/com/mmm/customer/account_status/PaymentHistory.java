package com.mmm.customer.account_status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Payment History tab — single-file API (MyOrders / PaidInvoices style).
 * Real data comes from the legacy AS400 procedure BPCSLCLIN.COS010S.
 * Set dummy=true to use local sample rows when AS400 is unavailable.
 *
 * GET /api/customer/account-status/payment-history
 *       ?custCode=&loginId=&fromDate=&toDate=&dummy=
 *
 * fromDate / toDate accept yyyymmdd, dd/MM/yyyy, dd-MM-yyyy or yyyy-MM-dd.
 * When both are blank the range defaults to first day of last month -> today.
 */
@RestController
@RequestMapping("/api/customer/account-status/payment-history")
public class PaymentHistory {

	private static final Logger logger = LoggerFactory.getLogger(PaymentHistory.class);
	private static final DateTimeFormatter YMD = DateTimeFormatter.BASIC_ISO_DATE;
	private static final DateTimeFormatter DMY_SLASH = DateTimeFormatter.ofPattern("dd/MM/uuuu");
	private static final DateTimeFormatter DMY_DASH = DateTimeFormatter.ofPattern("dd-MM-uuuu");
	private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu");

	/**
	 * COS010S result set, in order (myaccsts.js:775-785):
	 * 1 PHCKNO, 2 PHDESC, 3 RECVDT, 4 RECVAMT, 5 APPLAMT,
	 * 6 UNAPPLAMT, 7 CLSDDT, 8 OBLIGATEID, 9 OBLIGATEDT.
	 */
	private static final int LEGACY_COLUMN_COUNT = 9;

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	/** Legacy account-status application code. Override if AS400 expects another value. */
	@Value("${inpc.account-status.app-code:INPC}")
	private String appCode;

	public PaymentHistory(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Payment history request: custCode={}, loginId={}, fromDate={}, toDate={}, dummy={}",
				custCode, loginId, fromDate, toDate, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			LocalDate today = LocalDate.now();
			LocalDate from = parseDate(fromDate);
			LocalDate to = parseDate(toDate);
			if (from == null && to == null) {
				from = today.minusMonths(1).withDayOfMonth(1);
				to = today;
			}
			if (from == null || to == null) {
				result.SetError(-1, "failure", "Valid From Date and To Date are required");
				return gson.toJson(result);
			}
			if (from.isAfter(to)) {
				result.SetError(-1, "failure", "From Date cannot be after To Date");
				return gson.toJson(result);
			}
			if (to.isAfter(today)) {
				result.SetError(-1, "failure", "To Date cannot be in the future");
				return gson.toJson(result);
			}
			if (from.plusMonths(6).isBefore(to)) {
				result.SetError(-1, "failure", "Date range cannot exceed 6 months");
				return gson.toJson(result);
			}

			List<Map<String, Object>> rows = dummy
					? buildDummyRows(code)
					: loadAs400Rows(login, from, to);

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("fromDate", from.format(YMD));
			data.put("toDate", to.format(YMD));
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load payment history", ex);
			result.SetError(-1, "failure", "Unable to load payment history");
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadAs400Rows(String loginId, LocalDate from, LocalDate to) {
		// COS010S declares the two dates as decimal yyyyMMdd, not character.
		BigDecimal fromNumeric = new BigDecimal(from.format(YMD));
		BigDecimal toNumeric = new BigDecimal(to.format(YMD));
		String code = appCode == null ? "" : appCode.trim();

		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS010S("
				+ sqlLiteral(code) + ","
				+ sqlLiteral(loginId) + ","
				+ fromNumeric.toPlainString() + ","
				+ toNumeric.toPlainString() + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS010S(?,?,?,?)}",
				code, loginId, fromNumeric, toNumeric);

		logRawColumns(rawRows);

		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			Map<String, Object> row = new LinkedHashMap<>();
			// PHCKNO is the cheque / instrument number, shown as Payment Reference.
			row.put("paymentRef", text(valueAt(source, 1, "PHCKNO", "CKNO")));
			row.put("receivedDate", displayDate(valueAt(source, 3, "RECVDT", "PHPAYE")));
			row.put("receivedAmount", zeroIfBlank(valueAt(source, 4, "RECVAMT", "PHPAYA")));
			row.put("appliedAmount", zeroIfBlank(valueAt(source, 5, "APPLAMT", "PHCAAP")));
			// OBLIGATEID / OBLIGATEDT are the obligation (invoice) number and date.
			row.put("invoiceNo", text(valueAt(source, 8, "OBLIGATEID", "OHOBNO")));
			row.put("invoiceDate", displayDate(valueAt(source, 9, "OBLIGATEDT", "OHOBD8")));
			row.put("unappliedAmount", zeroIfBlank(valueAt(source, 6, "UNAPPLAMT", "PHUNAA")));
			rows.add(row);
		}
		return rows;
	}

	/**
	 * Logs the raw AS400 column names and first-row values. COS010S names only some
	 * of its columns, so this is the quickest way to confirm the positional contract
	 * still holds if the procedure is ever changed.
	 */
	private static void logRawColumns(List<Map<String, Object>> rawRows) {
		if (rawRows == null || rawRows.isEmpty()) {
			logger.info("COS010S returned 0 rows.");
			return;
		}
		Map<String, Object> first = rawRows.get(0);
		logger.info("COS010S returned {} row(s). {} raw column(s): {}",
				rawRows.size(), first.size(), first.keySet());
		logger.info("COS010S first row values: {}", first.values());
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	/**
	 * Resolves a column by name, falling back to a fixed 1-based ordinal.
	 *
	 * Unlike COS009S, this procedure builds several columns from expressions —
	 * REPLACE(PHPAYE,'/','-'), IFNULL(OHOBNO,' ') and the SUBSTR(DIGITS(OHOBD8))
	 * date — and DB2 returns those **unnamed**. The legacy UI worked around it by
	 * renaming every column positionally (see keyChange + the statickeys array at
	 * myaccsts.js:874-884), so position is the authoritative contract here, not name.
	 *
	 * The ordinal is only used when the row has the full nine columns the legacy
	 * result set is documented to have, so a changed procedure shape degrades to a
	 * blank cell rather than a plausible-looking wrong value.
	 */
	private static Object valueAt(Map<String, Object> row, int ordinal, String... names) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			for (String name : names) {
				if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
					if (!isBlank(entry.getValue())) {
						return entry.getValue();
					}
				}
			}
		}
		if (ordinal >= 1 && row.size() == LEGACY_COLUMN_COUNT) {
			return new ArrayList<>(row.values()).get(ordinal - 1);
		}
		return null;
	}

	private static String text(Object value) {
		if (value == null) {
			return "";
		}
		if (value instanceof BigDecimal decimal) {
			return decimal.stripTrailingZeros().toPlainString();
		}
		return String.valueOf(value).trim();
	}

	private static boolean isBlank(Object value) {
		return value == null || text(value).isEmpty();
	}

	private static Object zeroIfBlank(Object value) {
		return isBlank(value) ? "0" : value;
	}

	private static LocalDate parseDate(String raw) {
		String value = raw == null ? "" : raw.trim();
		if (value.isEmpty() || "0".equals(value)) {
			return null;
		}
		try {
			if (value.length() == 8 && value.chars().allMatch(Character::isDigit)) {
				return LocalDate.parse(value, YMD);
			}
			if (value.contains("/")) {
				return LocalDate.parse(value, DMY_SLASH);
			}
			// COS010S edits its dates to dd-MM-yyyy; the UI may still send yyyy-MM-dd.
			if (value.length() == 10 && value.charAt(4) == '-') {
				return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
			}
			return LocalDate.parse(value, DMY_DASH);
		} catch (DateTimeParseException ex) {
			return null;
		}
	}

	private static String displayDate(Object raw) {
		String value = text(raw);
		if (value.isEmpty()) {
			return "";
		}
		if ("0".equals(value)) {
			return "NA";
		}
		LocalDate date = parseDate(value);
		return date == null ? value : date.format(DISPLAY_DATE);
	}

	private static List<Map<String, Object>> buildDummyRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row("034946", "11-09-2026", 11431678, 11431678, "4N26012889", "22-07-2026", 0));
		rows.add(row("047843", "17-08-2026", 54634.94, 54634.94, "4N26007646", "11-06-2026", 0));
		rows.add(row("048102", "28-08-2026", 128450, 125950, "4N26008102", "22-06-2026", 2500));
		rows.add(row("048891", "02-09-2026", 89210.50, 89210.50, "4N26008891", "05-07-2026", 0));
		rows.add(row("049551", "10-09-2026", 36780, 35580, "4N26009551", "01-08-2026", 1200));
		rows.add(row("ACH-SEP-4412", "15-09-2026", 175430.50, 175430.50, "4N26009910", "12-08-2026", 0));
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static Map<String, Object> row(
			String paymentRef, String receivedDate, double receivedAmount, double appliedAmount,
			String invoiceNo, String invoiceDate, double unappliedAmount) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("paymentRef", paymentRef);
		m.put("receivedDate", receivedDate);
		m.put("receivedAmount", receivedAmount);
		m.put("appliedAmount", appliedAmount);
		m.put("invoiceNo", invoiceNo);
		m.put("invoiceDate", invoiceDate);
		m.put("unappliedAmount", unappliedAmount);
		return m;
	}
}
