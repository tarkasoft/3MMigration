package com.mmm.customer;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileAttributes;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.protocol.commons.EnumWithValue;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Policies &amp; Guidelines (legacy Policy/Agreements).
 * CMW010S returns the COMAGM share. Files are listed and read with SMBJ
 * over SMB 3.1.1 only. The browser receives file names, never the share
 * path or password.
 *
 * GET /api/customer/policies/list?custCode=&loginId=&dummy=
 * GET /api/customer/policies/file?name=&custCode=&loginId=&dummy=
 */
@RestController
@RequestMapping("/api/customer/policies")
public class PoliciesGuidelines {

	private static final Logger logger = LoggerFactory.getLogger(PoliciesGuidelines.class);
	private static final String COMAGM = "COMAGM";

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	/** Legacy APPCODEAGM. */
	@Value("${inpc.policies.app-code:CUSAGM}")
	private String appCode;

	/** Legacy NtlmPasswordAuthentication domain. */
	@Value("${inpc.policies.smb-domain:MMM}")
	private String smbDomain;

	public PoliciesGuidelines(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping("/list")
	public String list(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Policies list request: loginId={}, dummy={}", loginId, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}
		try {
			String login = resolveLogin(httpSession, custCode, loginId);
			List<Map<String, Object>> rows = dummy ? dummyRows() : listShare(login);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("loginId", login);
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "smb");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to list policies", ex);
			result.SetError(-1, "failure", "Unable to load policies and guidelines");
		}
		return gson.toJson(result);
	}

	@GetMapping("/file")
	public ResponseEntity<byte[]> file(
			HttpServletRequest request,
			@RequestParam("name") String name,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		String safeName = safeFileName(name);
		if (safeName.isEmpty()) {
			return ResponseEntity.badRequest().build();
		}
		try {
			byte[] body;
			MediaType type;
			if (dummy) {
				body = ("Sample policy document: " + safeName).getBytes(java.nio.charset.StandardCharsets.UTF_8);
				type = MediaType.TEXT_PLAIN;
			} else {
				String login = resolveLogin(httpSession, custCode, loginId);
				body = readShareFile(login, safeName);
				type = safeName.toLowerCase(Locale.ROOT).endsWith(".pdf")
						? MediaType.APPLICATION_PDF
						: MediaType.APPLICATION_OCTET_STREAM;
			}
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
							.filename(safeName)
							.build()
							.toString())
					.contentType(type)
					.body(body);
		} catch (Exception ex) {
			logger.error("Unable to download policy file {}", safeName, ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	private List<Map<String, Object>> listShare(String loginId) throws Exception {
		ShareLocation location = locateShare(loginId);
		List<Map<String, Object>> rows = new ArrayList<>();
		withShare(location, share -> {
			String folder = location.folder();
			for (FileIdBothDirectoryInformation info : share.list(folder)) {
				String fileName = info.getFileName();
				if (fileName == null || fileName.equals(".") || fileName.equals("..")) {
					continue;
				}
				if (EnumWithValue.EnumUtils.isSet(info.getFileAttributes(), FileAttributes.FILE_ATTRIBUTE_DIRECTORY)) {
					continue;
				}
				if ("thumbs.db".equalsIgnoreCase(fileName)) {
					continue;
				}
				if (safeFileName(fileName).isEmpty()) {
					continue;
				}
				Map<String, Object> row = new LinkedHashMap<>();
				row.put("name", fileName);
				rows.add(row);
			}
		});
		rows.sort((a, b) -> String.valueOf(a.get("name")).compareToIgnoreCase(String.valueOf(b.get("name"))));
		return rows;
	}

	private byte[] readShareFile(String loginId, String fileName) throws Exception {
		ShareLocation location = locateShare(loginId);
		byte[][] holder = new byte[1][];
		withShare(location, share -> {
			String remote = location.folder().isEmpty() ? fileName : location.folder() + "/" + fileName;
			try (com.hierynomus.smbj.share.File remoteFile = share.openFile(
					remote,
					EnumSet.of(AccessMask.GENERIC_READ),
					null,
					SMB2ShareAccess.ALL,
					SMB2CreateDisposition.FILE_OPEN,
					null);
					InputStream in = remoteFile.getInputStream();
					ByteArrayOutputStream out = new ByteArrayOutputStream()) {
				in.transferTo(out);
				holder[0] = out.toByteArray();
			}
		});
		if (holder[0] == null) {
			throw new IllegalStateException("Policy file was not read");
		}
		return holder[0];
	}

	private ShareLocation locateShare(String loginId) {
		String code = appCode == null ? "" : appCode.trim();
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.CMW010S("
				+ sqlLiteral(code) + ","
				+ sqlLiteral(loginId) + ",'')");
		List<Map<String, Object>> rows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.CMW010S(?,?,?)}",
				code, loginId, "");
		for (Map<String, Object> row : rows) {
			if (!COMAGM.equalsIgnoreCase(text(value(row, "NWCODE")))) {
				continue;
			}
			ShareLocation location = parseShare(text(value(row, "NWPATH")));
			location.username = text(value(row, "NWLID"));
			location.password = text(value(row, "NWPWD"));
			if (location.username.isEmpty() || location.password.isEmpty()) {
				throw new IllegalStateException("COMAGM share credentials are blank");
			}
			logger.info("COMAGM share host={} share={} folder={}", location.host, location.share, location.folder);
			return location;
		}
		throw new IllegalStateException("COMAGM share was not returned by CMW010S");
	}

	private void withShare(ShareLocation location, ShareWork work) throws Exception {
		SmbConfig config = SmbConfig.builder()
				.withDialects(SMB2Dialect.SMB_3_1_1)
				.withEncryptData(true)
				.build();
		SMBClient client = new SMBClient(config);
		try (Connection connection = client.connect(location.host)) {
			AuthenticationContext auth = new AuthenticationContext(
					location.username,
					location.password.toCharArray(),
					smbDomain == null ? "MMM" : smbDomain.trim());
			Session session = connection.authenticate(auth);
			try (DiskShare share = (DiskShare) session.connectShare(location.share)) {
				work.run(share);
			} finally {
				session.close();
			}
		} finally {
			client.close();
		}
	}

	private static ShareLocation parseShare(String rawPath) {
		String raw = rawPath == null ? "" : rawPath.trim();
		if (raw.toLowerCase(Locale.ROOT).startsWith("smb:")) {
			raw = raw.substring(4);
		}
		raw = raw.replace('\\', '/');
		while (raw.startsWith("/")) {
			raw = raw.substring(1);
		}
		while (raw.endsWith("/")) {
			raw = raw.substring(0, raw.length() - 1);
		}
		String[] parts = raw.split("/", 3);
		if (parts.length < 2 || parts[0].isBlank() || parts[1].isBlank()) {
			throw new IllegalStateException("COMAGM path is not a host/share path");
		}
		String host = parts[0];
		int colon = host.indexOf(':');
		if (colon > 0) {
			host = host.substring(0, colon);
		}
		ShareLocation location = new ShareLocation();
		location.host = host;
		location.share = parts[1];
		location.folder = parts.length > 2 ? parts[2] : "";
		return location;
	}

	private static String resolveLogin(HttpSession httpSession, String requestedCustCode, String requestedLoginId) {
		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(httpSession, requestedCustCode, requestedLoginId);
		return context.loginId() == null ? "" : context.loginId();
	}

	private static String safeFileName(String name) {
		String value = name == null ? "" : name.trim();
		if (value.isEmpty() || value.length() > 255) {
			return "";
		}
		if (value.indexOf('/') >= 0 || value.indexOf('\\') >= 0 || value.contains("..")) {
			return "";
		}
		if (value.indexOf(':') >= 0 || value.indexOf('*') >= 0 || value.indexOf('?') >= 0
				|| value.indexOf('"') >= 0 || value.indexOf('<') >= 0 || value.indexOf('>') >= 0
				|| value.indexOf('|') >= 0) {
			return "";
		}
		return value;
	}

	private static Object value(Map<String, Object> row, String name) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
				return entry.getValue();
			}
		}
		return null;
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	private static List<Map<String, Object>> dummyRows() {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(named("Commercial_Agreement.pdf"));
		rows.add(named("Credit_Policy.pdf"));
		rows.add(named("GST_Guidelines.pdf"));
		rows.add(named("Dealer_Terms.pdf"));
		rows.add(named("Return_Policy.pdf"));
		return rows;
	}

	private static Map<String, Object> named(String name) {
		Map<String, Object> row = new LinkedHashMap<>();
		row.put("name", name);
		return row;
	}

	private interface ShareWork {
		void run(DiskShare share) throws Exception;
	}

	private static final class ShareLocation {
		private String host;
		private String share;
		private String folder;
		private String username;
		private String password;

		private String folder() {
			return folder == null ? "" : folder;
		}
	}
}
