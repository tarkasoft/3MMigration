package com.mmm.customer;

import java.util.LinkedHashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.CommonDataTable;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Contact Us MSSQL list with shared server-side filtering, sorting and paging.
 * Reads {@code contact_us_data} through {@link CommonDataTable}.
 * Client: {@code GET /api/portal/contact-us/list}
 */
@RestController
@RequestMapping("/api/portal/contact-us")
public class ContactUs {

    private static final CommonDataTable.QuerySpec CONTACT_TABLE =
            CommonDataTable.QuerySpec.builder("""
                    select
                           isnull(c.div_no,'') as div_no,
                           isnull(c.division,'') as division,
                           isnull(c.div_short_name,'') as div_short_name,
                           isnull(c.customer_service_contact,'') as customer_service_contact,
                           isnull(c.email,'') as email,
                           isnull(c.mobile,'') as mobile,
                           isnull(c.credit_services_contact,'') as credit_services_contact,
                           isnull(c.email1,'') as email1
                    from contact_us_data c
                    """)
                    .column("div_no", "div_no")
                    .column("division", "division")
                    .column("div_short_name", "div_short_name")
                    .column("customer_service_contact", "customer_service_contact")
                    .column("email", "email")
                    .column("mobile", "mobile")
                    .column("credit_services_contact", "credit_services_contact")
                    .column("email1", "email1")
                    .defaultSort("div_no")
                    .build();

    private final SessionFactory systemSessionFactory;
    private final Gson gson = new Gson();

    public ContactUs(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory systemSessionFactory) {
        this.systemSessionFactory = systemSessionFactory;
        System.out.println("CONTACT_TABLE initialized:\n" + CONTACT_TABLE);
    }

    private Session systemSession() {
        return systemSessionFactory.getCurrentSession();
    }

    @GetMapping("/list")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String list(
            HttpServletRequest request,
            @RequestParam(value = "custCode", required = false) String custCode,
            @RequestParam(value = "loginId", required = false) String loginId,
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
            @RequestParam(value = "sortField", defaultValue = "div_no") String sortField,
            @RequestParam(value = "sortDir", defaultValue = "asc") String sortDir,
            @RequestParam(value = "globalFilter", defaultValue = "") String globalFilter,
            @RequestParam(value = "columnFilters", defaultValue = "{}") String columnFiltersJson) {
    	System.out.println("CONTACT_TABLE initialized:\n" + CONTACT_TABLE);
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession httpSession = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(httpSession)) {
            result.SetError(
                    UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
                    "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }

        try {
            CommonDataTable.Request tableRequest = new CommonDataTable.Request(
                    page,
                    pageSize,
                    sortField,
                    sortDir,
                    globalFilter,
                    CommonDataTable.parseColumnFilters(columnFiltersJson));
          	System.out.println("tableRequestd:\n" + tableRequest);
            CommonDataTable.Page tablePage =  CommonDataTable.query(systemSession(), CONTACT_TABLE, tableRequest);
            
            Map<String, Object> data = new LinkedHashMap<>(tablePage.toMap());
            data.put("count", tablePage.totalRecords());
            String sessionLogin = UserSessionSupport.requireLoginId(httpSession);
            data.put("loginId", (loginId == null || loginId.isBlank()) ? sessionLogin : loginId.trim());
            if (custCode != null && !custCode.isBlank()) {
                data.put("custCode", custCode.trim());
            }
            result.SetSuccess("success", data);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Unable to load contact list: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

}
