package com.mmm.customer;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * My Orders — single-file API (CustomerPayment / ContactUs style).
 * Real data comes from the legacy AS400 procedures. Set dummy=true to use
 * local sample rows when AS400 is unavailable.
 *
 * GET /api/customer/my-orders/open?custCode=&loginId=&dummy=
 * GET /api/customer/my-orders/invoiced?custCode=&loginId=&fromDate=&toDate=&stock=&dummy=
 */
@RestController
@RequestMapping("/api/customer/my-orders")
public class MyOrders {

	private static final Logger logger = LoggerFactory.getLogger(MyOrders.class);
	private static final String APP_CODE = "MYORD";
	private static final DateTimeFormatter YMD = DateTimeFormatter.BASIC_ISO_DATE;
	private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd/MM/uuuu");
	private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu");

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	public MyOrders(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping("/open")
	public String open(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			List<Map<String, Object>> rows = dummy
					? buildDummyOpenRows(code)
					: loadAs400OpenRows(code, login);
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load open orders", ex);
			result.SetError(-1, "failure", "Unable to load open orders");
		}
		return gson.toJson(result);
	}

	@GetMapping("/invoiced")
	public String invoiced(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "stock", required = false) String stock,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Invoiced orders request: custCode={}, loginId={}, fromDate={}, toDate={}, stock={}, dummy={}",
				custCode, loginId, fromDate, toDate, stock, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			LocalDate from = parseDate(fromDate);
			LocalDate to = parseDate(toDate);
			if (from == null || to == null) {
				result.SetError(-1, "failure", "Valid fromDate and toDate are required");
				return gson.toJson(result);
			}
			if (from.isAfter(to)) {
				result.SetError(-1, "failure", "From Date cannot be after To Date");
				return gson.toJson(result);
			}
			if (from.plusMonths(6).isBefore(to)) {
				result.SetError(-1, "failure", "Date range cannot exceed 6 months");
				return gson.toJson(result);
			}

			String stockValue = stock == null ? "" : stock.trim();
			List<Map<String, Object>> rows;
			if (dummy) {
				String stockQ = stockValue.toLowerCase(Locale.ROOT);
				rows = new ArrayList<>();
				for (Map<String, Object> r : buildDummyInvoicedRows(code)) {
					if (!stockQ.isEmpty()) {
						String sn = String.valueOf(r.getOrDefault("stockNo", "")).toLowerCase(Locale.ROOT);
						if (!sn.contains(stockQ)) {
							continue;
						}
					}
					rows.add(r);
				}
			} else {
				rows = loadAs400InvoicedRows(code, login, from, to, stockValue);
			}

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("fromDate", from.format(YMD));
			data.put("toDate", to.format(YMD));
			data.put("stock", stockValue);
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load invoice orders", ex);
			result.SetError(-1, "failure", "Unable to load invoice orders");
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadAs400OpenRows(String custCode, String loginId) {
		BigDecimal customerNumber;
		try {
			customerNumber = new BigDecimal(custCode.trim());
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException("Customer code must be numeric", ex);
		}

		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS004S("
				+ sqlLiteral(APP_CODE) + ","
				+ sqlLiteral(loginId) + ","
				+ sqlLiteral("") + ","
				+ customerNumber.toPlainString() + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS004S(?,?,?,?)}",
				APP_CODE, loginId, "", customerNumber);
		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			Object orderQty = value(source, 6, "ORDQ", "CSOQTY");
			Object shippedQty = value(source, 7, "SQTY", "CSSQTY");
			Object openQty = value(source, 0, "OPENQTY", "OPNQTY", "BALQTY");
			if (openQty == null) {
				openQty = subtract(orderQty, shippedQty);
			}
			Map<String, Object> row = new LinkedHashMap<>();
			row.put("poNo", text(value(source, 2, "CPO", "CUCUSPO", "CSCUSPO")));
			row.put("poDate", displayDate(value(source, 1, "ORDDT", "CSORDT")));
			row.put("stockNo", text(value(source, 3, "SKU", "CSPROD")));
			row.put("description", text(value(source, 4, "DESC", "CSDESC")));
			row.put("status", text(value(source, 5, "STS", "CSSTS")));
			row.put("orderQty", zeroIfBlank(orderQty));
			row.put("allocatedQty", zeroIfBlank(value(source, 0, "ALCQTY", "ALLOCQTY")));
			row.put("shippedQty", zeroIfBlank(shippedQty));
			row.put("openQty", zeroIfBlank(openQty));
			row.put("unitPrice", zeroIfBlank(value(source, 8, "PRIC", "CSPRCE")));
			row.put("amount", zeroIfBlank(value(source, 9, "LAMT", "CSLTOT")));
			row.put("orderNo3m", text(value(source, 10, "ORDN", "CSORD")));
			row.put("expectedShipDate", displayDate(value(source, 12, "EDDT", "CSEXDT")));
			rows.add(row);
		}
		return rows;
	}

	private List<Map<String, Object>> loadAs400InvoicedRows(
			String custCode, String loginId, LocalDate from, LocalDate to, String stock) {
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS006S("
				+ sqlLiteral(APP_CODE) + ","
				+ sqlLiteral(loginId) + ","
				+ sqlLiteral("") + ","
				+ sqlLiteral(custCode) + ","
				+ sqlLiteral(from.format(YMD)) + ","
				+ sqlLiteral(to.format(YMD)) + ","
				+ sqlLiteral(stock) + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS006S(?,?,?,?,?,?,?)}",
				APP_CODE, loginId, "", custCode, from.format(YMD), to.format(YMD), stock);
		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			Map<String, Object> row = new LinkedHashMap<>();
			row.put("poNo", text(value(source, 2, "CUCUSPO", "CSCUSPO", "CPO")));
			row.put("poDate", displayDate(value(source, 1, "CSORDT", "ORDDT")));
			row.put("stockNo", text(value(source, 3, "CSPROD", "SKU")));
			row.put("description", text(value(source, 4, "CSDESC", "DESC")));
			row.put("orderQty", value(source, 19, "CSOQTY", "ORDQ"));
			row.put("shippedQty", value(source, 6, "CSSQTY", "SQTY"));
			row.put("unitPrice", value(source, 7, "CSPRCE", "PRIC"));
			row.put("amount", value(source, 8, "CSLTOT", "LAMT"));
			row.put("orderNo3m", text(value(source, 9, "CSORD", "ORDN")));
			row.put("invoiceNo", text(value(source, 10, "CSINVN", "INVN")));
			row.put("invoiceDate", displayDate(value(source, 11, "CSINVDT", "INVD")));
			row.put("carrier", text(value(source, 17, "CSTRNM", "TRANSPORTER")));
			row.put("lrNo", text(value(source, 12, "CSLRN", "LRN")));
			row.put("lrDate", displayDate(value(source, 15, "CSLRDT", "LRDT")));
			row.put("expectedDeliveryDate", displayDate(value(source, 13, "CSEXDT", "EDDT")));
			row.put("actualDeliveryDate", displayDate(value(source, 16, "CSACDT", "ACDT")));
			rows.add(row);
		}
		return rows;
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	private static Object value(
			Map<String, Object> row, int fallbackIndex, String... names) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			for (String name : names) {
				if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
					return entry.getValue();
				}
			}
		}
		if (fallbackIndex > 0 && fallbackIndex <= row.size()) {
			return new ArrayList<>(row.values()).get(fallbackIndex - 1);
		}
		return null;
	}

	private static String text(Object value) {
		if (value == null) {
			return "";
		}
		if (value instanceof BigDecimal decimal) {
			return decimal.stripTrailingZeros().toPlainString();
		}
		return String.valueOf(value).trim();
	}

	private static Object zeroIfBlank(Object value) {
		if (value == null || text(value).isEmpty()) {
			return "0";
		}
		return value;
	}

	private static Object subtract(Object first, Object second) {
		try {
			BigDecimal left = new BigDecimal(text(first));
			BigDecimal right = new BigDecimal(text(second));
			return left.subtract(right);
		} catch (RuntimeException ex) {
			return "";
		}
	}

	private static LocalDate parseDate(String raw) {
		String value = raw == null ? "" : raw.trim();
		if (value.isEmpty()) {
			return null;
		}
		try {
			if (value.length() == 8 && value.chars().allMatch(Character::isDigit)) {
				return LocalDate.parse(value, YMD);
			}
			if (value.contains("/")) {
				return LocalDate.parse(value, DMY);
			}
			return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
		} catch (DateTimeParseException ex) {
			return null;
		}
	}

	private static String displayDate(Object raw) {
		String value = text(raw);
		if (value.isEmpty() || "0".equals(value)) {
			return value.isEmpty() ? "" : "NA";
		}
		LocalDate date = parseDate(value);
		return date == null ? value : date.format(DISPLAY_DATE);
	}

	private static List<Map<String, Object>> buildDummyOpenRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(openRow("ProcareDB190926", "19-09-2026", "IS260046823", "AS Cloth Pack of 3 (16X16)", "In Progress",
				720, 0, 0, 720, 274.81, 197863.2, "268681", "28-09-2026"));
		rows.add(openRow("ProCare DB13626", "13-06-2026", "IS260045858", "Ceramic Warranty Card - Grey", "In Progress",
				210, 50, 0, 160, 22.62, 4750.2, "155525", "30-09-2026"));
		rows.add(openRow("CCGF_Q69_3187", "17-08-2026", "60455101794", "BODY SCHUTZ GUN", "In Progress",
				2, 0, 0, 2, 11599.05, 23198.1, "195883", "25-09-2026"));
		rows.add(openRow("RK-PO-9021", "01-09-2026", "70001234567", "3M Intense Cleaner 5L", "Allocated",
				48, 48, 12, 36, 420.04, 20161.92, "233393", "22-09-2026"));
		rows.add(openRow("RK-PO-9105", "05-09-2026", "IS260047101", "Masking Tape 24mm x 50m", "In Progress",
				500, 100, 0, 400, 45.5, 22750.0, "240112", "27-09-2026"));
		rows.add(openRow("ProcareDB191001", "10-09-2026", "IS260048220", "Safety Goggles Clear", "In Progress",
				120, 0, 0, 120, 189.0, 22680.0, "241890", "29-09-2026"));
		rows.add(openRow("CCGF_Q70_1102", "12-09-2026", "60455101901", "Adhesive Primer 1L", "Open",
				36, 0, 0, 36, 890.25, 32049.0, "242301", "01-10-2026"));
		rows.add(openRow("RK-PO-9188", "15-09-2026", "IS260049333", "Dust Cloth Blue Pack 50", "In Progress",
				80, 20, 0, 60, 312.4, 24992.0, "243055", "02-10-2026"));
		rows.add(openRow("ProcareDB191120", "18-09-2026", "70009876543", "Floor Pad 17 inch Red", "In Progress",
				24, 0, 0, 24, 675.0, 16200.0, "244410", "03-10-2026"));
		rows.add(openRow("RK-PO-9202", "20-09-2026", "IS260050010", "Hand Sanitizer Gel 500ml", "Allocated",
				200, 200, 40, 160, 95.75, 19150.0, "245001", "04-10-2026"));
		// stamp cust for traceability in dummy set
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static List<Map<String, Object>> buildDummyInvoicedRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(invRow("ProCare DB13626", "13-06-2026", "IS260045858", "Ceramic Warranty Card - Grey",
				210, 210, 22.62, 4750.2, "155525", "4N26017959", "02-09-2026", "RTS LOGISTICS", "103130", "02-09-2026"));
		rows.add(invRow("CCGF_Q69_3187", "17-08-2026", "60455101794", "BODY SCHUTZ GUN",
				2, 2, 11599.05, 23198.1, "195883", "MO26030690", "18-08-2026", "ALLCARGO LOGISTICS LTD", "349746476", "18-08-2026"));
		rows.add(invRow("RK-PO-8801", "01-08-2026", "70001234567", "3M Intense Cleaner 5L",
				40, 40, 420.04, 16801.6, "233393", "4N26018110", "05-08-2026", "VRL Logistics", "VRL-88921", "05-08-2026"));
		rows.add(invRow("ProcareDB180512", "12-05-2026", "IS260041200", "Scuff Pad Fine Grade",
				100, 100, 18.5, 1850.0, "148221", "MO26029001", "20-05-2026", "NO PHYSICAL MOVEMENT", "I TYPE", "20-05-2026"));
		rows.add(invRow("RK-PO-8955", "22-08-2026", "IS260047101", "Masking Tape 24mm x 50m",
				300, 300, 45.5, 13650.0, "239900", "4N26018888", "28-08-2026", "RTS LOGISTICS", "103988", "28-08-2026"));
		rows.add(invRow("CCGF_Q68_2201", "03-07-2026", "60455101850", "Spray Gun Nozzle Kit",
				5, 5, 2450.0, 12250.0, "201445", "MO26030112", "10-07-2026", "VRL Logistics", "VRL-77102", "10-07-2026"));
		rows.add(invRow("ProcareDB190201", "02-09-2026", "IS260048220", "Safety Goggles Clear",
				60, 60, 189.0, 11340.0, "241200", "4N26019201", "08-09-2026", "ALLCARGO LOGISTICS LTD", "350001122", "08-09-2026"));
		rows.add(invRow("RK-PO-9010", "08-09-2026", "IS260049333", "Dust Cloth Blue Pack 50",
				40, 40, 312.4, 12496.0, "242880", "MO26031055", "12-09-2026", "RTS LOGISTICS", "104201", "12-09-2026"));
		rows.add(invRow("ProcareDB191015", "15-09-2026", "70009876543", "Floor Pad 17 inch Red",
				12, 12, 675.0, 8100.0, "243900", "4N26019550", "18-09-2026", "VRL Logistics", "VRL-90210", "18-09-2026"));
		rows.add(invRow("RK-PO-9055", "16-09-2026", "IS260050010", "Hand Sanitizer Gel 500ml",
				100, 100, 95.75, 9575.0, "244555", "MO26031200", "19-09-2026", "NO PHYSICAL MOVEMENT", "I TYPE", "19-09-2026"));
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static Map<String, Object> openRow(
			String poNo, String poDate, String stockNo, String description, String status,
			int orderQty, int allocatedQty, int shippedQty, int openQty,
			double unitPrice, double amount, String orderNo3m, String expectedShipDate) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("poNo", poNo);
		m.put("poDate", poDate);
		m.put("stockNo", stockNo);
		m.put("description", description);
		m.put("status", status);
		m.put("orderQty", orderQty);
		m.put("allocatedQty", allocatedQty);
		m.put("shippedQty", shippedQty);
		m.put("openQty", openQty);
		m.put("unitPrice", unitPrice);
		m.put("amount", amount);
		m.put("orderNo3m", orderNo3m);
		m.put("expectedShipDate", expectedShipDate);
		return m;
	}

	private static Map<String, Object> invRow(
			String poNo, String poDate, String stockNo, String description,
			int orderQty, int shippedQty, double unitPrice, double amount, String orderNo3m,
			String invoiceNo, String invoiceDate, String carrier, String lrNo, String lrDate) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("poNo", poNo);
		m.put("poDate", poDate);
		m.put("stockNo", stockNo);
		m.put("description", description);
		m.put("orderQty", orderQty);
		m.put("shippedQty", shippedQty);
		m.put("unitPrice", unitPrice);
		m.put("amount", amount);
		m.put("orderNo3m", orderNo3m);
		m.put("invoiceNo", invoiceNo);
		m.put("invoiceDate", invoiceDate);
		m.put("carrier", carrier);
		m.put("lrNo", lrNo);
		m.put("lrDate", lrDate);
		m.put("expectedDeliveryDate", "");
		m.put("actualDeliveryDate", "");
		return m;
	}
}