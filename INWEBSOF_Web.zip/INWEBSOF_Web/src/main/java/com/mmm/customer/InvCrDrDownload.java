package com.mmm.customer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Types;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Invoice / Credit Note / Debit Note download.
 * One class for the list and the PDF link.
 *
 * GET /api/customer/inv-cr-dr/list?custCode=&loginId=&docType=&fromDate=&toDate=&dummy=
 * GET /api/customer/inv-cr-dr/download?custCode=&loginId=&docNo=&docType=&invoiceDate=&dummy=
 *
 * docType: SI Sales Invoice, CN Credit Note, DN Debit Note.
 * Dates accept yyyymmdd, yyyy-MM-dd, or dd/MM/yyyy.
 * Real data uses BPCSLCLIN.COS064S and BPCSLCLIN.INVRPTR2S.
 * Pass dummy=true to retain the sample-data path for local testing.
 */
@RestController
@RequestMapping("/api/customer/inv-cr-dr")
public class InvCrDrDownload {

	private static final Logger log = LoggerFactory.getLogger(InvCrDrDownload.class);
	private static final DateTimeFormatter YMD = DateTimeFormatter.BASIC_ISO_DATE;
	private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private static final DateTimeFormatter DMY_COMPACT = DateTimeFormatter.ofPattern("ddMMyyyy");

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	@Value("${inpc.credit-release.app-code:CRSAPP}")
	private String appCode;

	@Value("${inpc.credit-release.ftp-host:US400IN}")
	private String ftpHost;

	@Value("${inpc.credit-release.ftp-port:21}")
	private int ftpPort;

	@Value("${inpc.credit-release.ftp-username:}")
	private String ftpUsername;

	@Value("${inpc.credit-release.ftp-password:}")
	private String ftpPassword;

	@Value("${inpc.credit-release.ftp-base-path:/temp/CUSSOA}")
	private String ftpBasePath;

	public InvCrDrDownload(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping("/list")
	public String list(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "docType", required = false) String docType,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		log.info("Incoming invoice/credit/debit list params: custCode={}, loginId={}, docType={}, fromDate={}, toDate={}, dummy={}",
				custCode, loginId, docType, fromDate, toDate, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}
		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
		String code = context.custCode();
		if (code.isEmpty()) {
			result.SetError(-1, "failure", "custCode is required");
			return gson.toJson(result);
		}
		String type = docType == null ? "" : docType.trim().toUpperCase(Locale.ROOT);
		if (!List.of("SI", "CN", "DN").contains(type)) {
			result.SetError(-1, "failure", "Choose Sales Invoice, Credit Note, or Debit Note.");
			return gson.toJson(result);
		}
		LocalDate from = parseDate(fromDate);
		LocalDate to = parseDate(toDate);
		if (from == null || to == null) {
			result.SetError(-1, "failure", "From Date and To Date are required.");
			return gson.toJson(result);
		}
		long days = ChronoUnit.DAYS.between(from, to);
		if (days < 0) {
			result.SetError(-1, "failure", "From Date must be on or before To Date.");
			return gson.toJson(result);
		}
		if (days >= 60) {
			result.SetError(-1, "failure", "Date difference must be less than 60 days.");
			return gson.toJson(result);
		}
		String effectiveLoginId = context.loginId();

		List<Map<String, Object>> rows;
		try {
			rows = dummy
					? dummyRowsForRange(code, type, from, to)
					: loadAs400Rows(code, effectiveLoginId, type, from, to);
		} catch (RuntimeException ex) {
			log.error("Invoice/credit/debit list failed for customer {}: {}", code, ex.getMessage(), ex);
			result.SetError(-1, "failure", "Unable to load documents from AS400.");
			return gson.toJson(result);
		}

		Map<String, Object> data = new LinkedHashMap<>();
		data.put("custCode", code);
		data.put("loginId", effectiveLoginId);
		data.put("docType", type);
		data.put("fromDate", from.format(DMY));
		data.put("toDate", to.format(DMY));
		data.put("rows", rows);
		data.put("count", rows.size());
		data.put("source", dummy ? "dummy" : "as400");
		result.SetSuccess("success", data);
		return gson.toJson(result);
	}

	@GetMapping("/download")
	public ResponseEntity<byte[]> download(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "docNo", required = false) String docNo,
			@RequestParam(value = "docType", required = false) String docType,
			@RequestParam(value = "invoiceDate", required = false) String invoiceDate,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		log.info("Incoming invoice/credit/debit download params: custCode={}, loginId={}, docNo={}, docType={}, invoiceDate={}, dummy={}",
				custCode, loginId, docNo, docType, invoiceDate, dummy);
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			return ResponseEntity.status(401).build();
		}
		String no = docNo == null ? "" : docNo.trim();
		if (no.length() < 3 || !no.matches("[A-Za-z0-9_-]+")) {
			return ResponseEntity.badRequest().build();
		}
		String type = docType == null ? "" : docType.trim().toUpperCase(Locale.ROOT);
		if (!List.of("SI", "CN", "DN").contains(type)) {
			return ResponseEntity.badRequest().build();
		}
		String label = switch (type) {
			case "CN" -> "Credit Note";
			case "DN" -> "Debit Note";
			default -> "Sales Invoice";
		};
		if (dummy) {
			byte[] pdf = samplePdf(label + " " + no);
			return pdfResponse(no + ".pdf", pdf);
		}

		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
		String code = context.custCode();
		LocalDate date = parseDate(invoiceDate);
		if (code.isEmpty() || date == null) {
			return ResponseEntity.badRequest().build();
		}
		try {
			String fileName = resolveAs400PdfName(no, date, code);
			byte[] pdf = fetchPdf(fileName);
			return pdfResponse(fileName, pdf);
		} catch (IllegalArgumentException ex) {
			log.warn("Invoice PDF request rejected for {}: {}", no, ex.getMessage());
			return ResponseEntity.badRequest().build();
		} catch (RuntimeException ex) {
			log.error("s Invoice PDF download failed for customer {}, document {}: {}",
					code, no, ex.getMessage(), ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	private static LocalDate parseDate(String raw) {
		if (raw == null || raw.isBlank()) {
			return null;
		}
		String s = raw.trim();
		try {
			if (s.length() == 8 && s.chars().allMatch(Character::isDigit)) {
				return LocalDate.parse(s, YMD);
			}
			if (s.indexOf('/') >= 0) {
				return LocalDate.parse(s, DMY);
			}
			return LocalDate.parse(s, DateTimeFormatter.ISO_LOCAL_DATE);
		} catch (DateTimeParseException ex) {
			return null;
		}
	}

	private List<Map<String, Object>> loadAs400Rows(
			String custCode, String loginId, String docType, LocalDate from, LocalDate to) {
		String legacyType = legacyOrderType(docType);
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS064S("
				+ sqlLiteral(appCode.trim()) + ","
				+ sqlLiteral(loginId) + ","
				+ sqlLiteral(legacyType) + ","
				+ sqlLiteral(from.format(YMD)) + ","
				+ sqlLiteral(to.format(YMD)) + ","
				+ sqlLiteral(custCode) + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS064S(?,?,?,?,?,?)}",
				appCode.trim(), loginId, legacyType, from.format(YMD), to.format(YMD), custCode);
		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			String rawDate = text(firstValue(source, "INVD"));
			LocalDate invoiceDate = parseDate(rawDate);
			Map<String, Object> row = new LinkedHashMap<>();
			row.put("docNo", text(firstValue(source, "INVN")));
			row.put("docType", docType);
			row.put("invoiceDateRaw", rawDate);
			row.put("invoiceDate", invoiceDate == null ? rawDate : invoiceDate.format(DMY));
			row.put("orderNo", text(firstValue(source, "ORDN")));
			row.put("orgInvoice", text(firstValue(source, "OINVN")));
			row.put("amount", zeroIfBlank(firstValue(source, "AMT")));
			rows.add(row);
		}
		return rows;
	}

	private String resolveAs400PdfName(String invoiceNo, LocalDate invoiceDate, String custCode) {
		String prefix = invoiceNo.substring(0, 2);
		String number = invoiceNo.substring(2).trim();
		if (number.isEmpty()) {
			throw new IllegalArgumentException("Invalid invoice number");
		}
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.INVRPTR2S("
				+ sqlLiteral(prefix) + ","
				+ sqlLiteral(number) + ","
				+ sqlLiteral(invoiceDate.format(DMY_COMPACT)) + ","
				+ sqlLiteral(custCode) + ",? /* OUT VARCHAR */)");
		Map<Integer, Object> outputs = NativeQuerySupport.executeProcedureWithOutputs(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.INVRPTR2S(?,?,?,?,?)}",
				Map.of(5, Types.VARCHAR),
				prefix, number, invoiceDate.format(DMY_COMPACT), custCode);
		String fileName = text(outputs.get(5));
		if (fileName.isEmpty() || !fileName.matches("[A-Za-z0-9._-]+")) {
			throw new IllegalStateException("AS400 returned an invalid PDF filename");
		}
		return fileName;
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	private byte[] fetchPdf(String fileName) {
		if (ftpUsername == null || ftpUsername.isBlank() || ftpPassword == null || ftpPassword.isBlank()) {
			throw new IllegalStateException("Credit-release FTP credentials are not configured");
		}
		FTPClient ftp = new FTPClient();
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			ftp.setConnectTimeout(30_000);
			ftp.setDefaultTimeout(30_000);
			ftp.connect(ftpHost, ftpPort);
			ftp.setSoTimeout(60_000);
			if (!ftp.login(ftpUsername, ftpPassword)) {
				throw new IllegalStateException("FTP login failed");
			}
			ftp.enterLocalPassiveMode();
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
			String base = ftpBasePath == null ? "" : ftpBasePath.trim().replaceAll("/+$", "");
			String remotePath = base + "/" + fileName;
			if (!ftp.retrieveFile(remotePath, out)) {
				throw new IllegalStateException("PDF was not found on FTP");
			}
			return out.toByteArray();
		} catch (IOException ex) {
			throw new IllegalStateException("FTP read failed", ex);
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.logout();
				} catch (IOException ignored) {
					// Disconnect below.
				}
				try {
					ftp.disconnect();
				} catch (IOException ignored) {
					// Nothing else to release.
				}
			}
		}
	}

	private static ResponseEntity<byte[]> pdfResponse(String fileName, byte[] pdf) {
		String safeName = fileName == null ? "invoice.pdf" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + safeName + "\"")
				.contentType(MediaType.APPLICATION_PDF)
				.body(pdf);
	}

	private static String legacyOrderType(String docType) {
		return switch (docType) {
			case "SI" -> "O";
			case "CN" -> "C";
			case "DN" -> "D";
			default -> throw new IllegalArgumentException("Unsupported document type");
		};
	}

	private static List<Map<String, Object>> dummyRowsForRange(
			String custCode, String docType, LocalDate from, LocalDate to) {
		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> row : dummyRows(custCode)) {
			if (!docType.equals(String.valueOf(row.get("docType")))) {
				continue;
			}
			LocalDate date = (LocalDate) row.get("_date");
			if (date.isBefore(from) || date.isAfter(to)) {
				continue;
			}
			Map<String, Object> out = new LinkedHashMap<>(row);
			out.remove("_date");
			out.put("invoiceDateRaw", date.format(YMD));
			out.put("invoiceDate", date.format(DMY));
			rows.add(out);
		}
		return rows;
	}

	private static Object firstValue(Map<String, Object> row, String... names) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			for (String name : names) {
				if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
					return entry.getValue();
				}
			}
		}
		return null;
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static Object zeroIfBlank(Object value) {
		if (value == null || text(value).isEmpty()) {
			return "0";
		}
		return value;
	}

	private static List<Map<String, Object>> dummyRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row(custCode, "SI", "MO26066269", LocalDate.of(2026, 3, 14), "13276", "MO26066269", 30379.96));
		rows.add(row(custCode, "SI", "MO26066288", LocalDate.of(2026, 3, 14), "96011", "MO26066289", 30379.96));
		rows.add(row(custCode, "SI", "4N26037533", LocalDate.of(2026, 3, 16), "44913", "4N26037633", 417383.48));
		rows.add(row(custCode, "SI", "4N26037664", LocalDate.of(2026, 3, 17), "44913", "4N26037664", 15735.43));
		rows.add(row(custCode, "SI", "MO26066770", LocalDate.of(2026, 3, 17), "44925", "MO26066770", 162995.62));
		rows.add(row(custCode, "SI", "4N26038149", LocalDate.of(2026, 3, 21), "51890", "4N26038349", 250073.87));
		rows.add(row(custCode, "SI", "MO26068220", LocalDate.of(2026, 3, 23), "44925", "MO26068220", 11986.27));
		rows.add(row(custCode, "SI", "4N26091001", LocalDate.of(2026, 9, 5), "57020", "4N26091018", 11950.16));
		rows.add(row(custCode, "SI", "MO26091055", LocalDate.of(2026, 9, 12), "44925", "MO26091055", 3296138.85));
		rows.add(row(custCode, "SI", "4N26091880", LocalDate.of(2026, 9, 18), "56190", "4N26091880", 7544.03));
		rows.add(row(custCode, "CN", "CN26044220", LocalDate.of(2026, 3, 16), "44926", "CN26044220", 446271.12));
		rows.add(row(custCode, "CN", "CN26042521", LocalDate.of(2026, 3, 17), "47738", "CN26042521", 256982.54));
		rows.add(row(custCode, "CN", "CN26091002", LocalDate.of(2026, 9, 8), "44926", "CN26091002", 25114.41));
		rows.add(row(custCode, "DN", "DN26037533", LocalDate.of(2026, 3, 18), "44913", "DN26037533", 18715.00));
		rows.add(row(custCode, "DN", "DN26091077", LocalDate.of(2026, 9, 15), "13272", "DN26091077", 9800.50));
		return rows;
	}

	private static Map<String, Object> row(
			String custCode, String docType, String docNo, LocalDate date,
			String orderNo, String orgInvoice, double amount) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("custCode", custCode);
		m.put("docType", docType);
		m.put("docNo", docNo);
		m.put("orderNo", orderNo);
		m.put("orgInvoice", orgInvoice);
		m.put("amount", amount);
		m.put("_date", date);
		return m;
	}

	/** One-page sample PDF. The real file will come from AS400. */
	private static byte[] samplePdf(String line) {
		String escaped = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
		String stream = "BT /F1 14 Tf 72 740 Td (" + escaped + ") Tj ET\n";
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			List<Integer> offsets = new ArrayList<>();
			write(out, "%PDF-1.4\n");
			offsets.add(out.size());
			write(out, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
			offsets.add(out.size());
			write(out, "2 0 obj\n<< /Type /Pages /Count 1 /Kids [3 0 R] >>\nendobj\n");
			offsets.add(out.size());
			write(out, "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R "
					+ "/Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n");
			offsets.add(out.size());
			write(out, "4 0 obj\n<< /Length " + stream.length() + " >>\nstream\n" + stream + "endstream\nendobj\n");
			offsets.add(out.size());
			write(out, "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n");
			int xref = out.size();
			write(out, "xref\n0 6\n");
			write(out, "0000000000 65535 f \n");
			for (int off : offsets) {
				write(out, String.format(Locale.ROOT, "%010d 00000 n \n", off));
			}
			write(out, "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF");
			return out.toByteArray();
		} catch (Exception ex) {
			return ("%PDF-1.4\n" + line).getBytes(StandardCharsets.US_ASCII);
		}
	}

	private static void write(ByteArrayOutputStream out, String text) {
		out.writeBytes(text.getBytes(StandardCharsets.US_ASCII));
	}
}
