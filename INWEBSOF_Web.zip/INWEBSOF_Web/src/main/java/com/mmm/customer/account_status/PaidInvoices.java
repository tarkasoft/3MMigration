package com.mmm.customer.account_status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Paid Invoices tab — single-file API (MyOrders style).
 * Real data comes from the legacy AS400 procedure BPCSLCLIN.COS009S.
 * Set dummy=true to use local sample rows when AS400 is unavailable.
 *
 * GET /api/customer/account-status/paid-invoices
 *       ?custCode=&loginId=&fromDate=&toDate=&dummy=
 *
 * fromDate / toDate accept yyyymmdd, dd/MM/yyyy or yyyy-MM-dd.
 * When both are blank the range defaults to first day of last month -> today.
 */
@RestController
@RequestMapping("/api/customer/account-status/paid-invoices")
public class PaidInvoices {

	private static final Logger logger = LoggerFactory.getLogger(PaidInvoices.class);
	private static final DateTimeFormatter YMD = DateTimeFormatter.BASIC_ISO_DATE;
	private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd/MM/uuuu");
	private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu");

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	/** Legacy account-status application code. Override if AS400 expects another value. */
	@Value("${inpc.account-status.app-code:INPC}")
	private String appCode;

	public PaidInvoices(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Paid invoices request: custCode={}, loginId={}, fromDate={}, toDate={}, dummy={}",
				custCode, loginId, fromDate, toDate, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			LocalDate today = LocalDate.now();
			LocalDate from = parseDate(fromDate);
			LocalDate to = parseDate(toDate);
			if (from == null && to == null) {
				from = today.minusMonths(1).withDayOfMonth(1);
				to = today;
			}
			if (from == null || to == null) {
				result.SetError(-1, "failure", "Valid From Date and To Date are required");
				return gson.toJson(result);
			}
			if (from.isAfter(to)) {
				result.SetError(-1, "failure", "From Date cannot be after To Date");
				return gson.toJson(result);
			}
			if (to.isAfter(today)) {
				result.SetError(-1, "failure", "To Date cannot be in the future");
				return gson.toJson(result);
			}
			if (from.plusMonths(6).isBefore(to)) {
				result.SetError(-1, "failure", "Date range cannot exceed 6 months");
				return gson.toJson(result);
			}

			List<Map<String, Object>> rows = dummy
					? buildDummyRows(code)
					: loadAs400Rows(login, from, to);

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("fromDate", from.format(YMD));
			data.put("toDate", to.format(YMD));
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load paid invoices", ex);
			result.SetError(-1, "failure", "Unable to load paid invoices");
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadAs400Rows(String loginId, LocalDate from, LocalDate to) {
		// COS009S declares the two dates as decimal yyyyMMdd, not character.
		BigDecimal fromNumeric = new BigDecimal(from.format(YMD));
		BigDecimal toNumeric = new BigDecimal(to.format(YMD));
		String code = appCode == null ? "" : appCode.trim();

		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS009S("
				+ sqlLiteral(code) + ","
				+ sqlLiteral(loginId) + ","
				+ fromNumeric.toPlainString() + ","
				+ toNumeric.toPlainString() + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS009S(?,?,?,?)}",
				code, loginId, fromNumeric, toNumeric);

		logRawColumns(rawRows);

		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			Object invoiceDate = value(source, "CSINVDT", "INVDT");
			Object closedDate = value(source, "CSCLODT", "CLODT");
			// COS009S appends a summary row flagged by CSTERM = 'Total'. The legacy grid
			// keeps the row but blanks its identity/date cells, so the amounts read as totals.
			boolean totalRow = "Total".equalsIgnoreCase(text(value(source, "CSTERM", "TERM")));

			Map<String, Object> row = new LinkedHashMap<>();
			row.put("invoiceNo", totalRow ? "" : text(value(source, "CSINVN", "INVN")));
			row.put("invoiceDate", totalRow ? "" : displayDate(invoiceDate));
			row.put("poNo", totalRow ? "" : text(value(source, "CSCUSPO", "CUSPO")));
			row.put("invoiceAmount", zeroIfBlank(value(source, "CSTOT", "TOT")));
			// CSCKNO / CSCKA are the cheque (payment) reference and its amount.
			row.put("paymentRef", text(value(source, "CSCKNO", "CKNO")));
			row.put("amount", zeroIfBlank(value(source, "CSCKA", "CKA")));
			// CSCRNO is a credit-note reference, not a number: keep it blank when absent.
			row.put("creditNoteAdj", text(value(source, "CSCRNO", "CRNO")));
			row.put("creditNoteAmount", zeroIfBlank(value(source, "CSCRA", "CRA")));
			row.put("closedDate", totalRow ? "" : displayDate(closedDate));
			row.put("daysToPay", totalRow ? "" : daysToPay(invoiceDate, closedDate));
			row.put("totalRow", totalRow);
			rows.add(row);
		}
		return rows;
	}

	/**
	 * The COS009S column names are only partly confirmed. Logging the raw names of
	 * the first row lets the aliases above be corrected after one live run.
	 */
	private static void logRawColumns(List<Map<String, Object>> rawRows) {
		if (rawRows == null || rawRows.isEmpty()) {
			logger.info("COS009S returned 0 rows.");
			return;
		}
		logger.info("COS009S returned {} row(s). Raw columns of first row: {}",
				rawRows.size(), rawRows.get(0).keySet());
	}

	/** Legacy calculatedaystopay(): closed date minus invoice date. */
	private static Object daysToPay(Object invoiceDate, Object closedDate) {
		LocalDate invoice = parseDate(text(invoiceDate));
		LocalDate closed = parseDate(text(closedDate));
		if (invoice == null || closed == null) {
			return "0";
		}
		return ChronoUnit.DAYS.between(invoice, closed);
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	/**
	 * Resolves a column by name only. Positional fallback is deliberately not used:
	 * COS009S returns more columns than the grid shows, so guessing by position
	 * silently pulls the wrong figure into a cell.
	 */
	private static Object value(Map<String, Object> row, String... names) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			for (String name : names) {
				if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
					return entry.getValue();
				}
			}
		}
		return null;
	}

	private static String text(Object value) {
		if (value == null) {
			return "";
		}
		if (value instanceof BigDecimal decimal) {
			return decimal.stripTrailingZeros().toPlainString();
		}
		return String.valueOf(value).trim();
	}

	private static boolean isBlank(Object value) {
		return value == null || text(value).isEmpty();
	}

	private static Object zeroIfBlank(Object value) {
		return isBlank(value) ? "0" : value;
	}

	private static LocalDate parseDate(String raw) {
		String value = raw == null ? "" : raw.trim();
		if (value.isEmpty() || "0".equals(value)) {
			return null;
		}
		try {
			if (value.length() == 8 && value.chars().allMatch(Character::isDigit)) {
				return LocalDate.parse(value, YMD);
			}
			if (value.contains("/")) {
				return LocalDate.parse(value, DMY);
			}
			return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
		} catch (DateTimeParseException ex) {
			return null;
		}
	}

	private static String displayDate(Object raw) {
		String value = text(raw);
		if (value.isEmpty()) {
			return "";
		}
		if ("0".equals(value)) {
			return "NA";
		}
		LocalDate date = parseDate(value);
		return date == null ? value : date.format(DISPLAY_DATE);
	}

	private static List<Map<String, Object>> buildDummyRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row("4N26007646", "11-06-2026", "ProCare DB21526", 54634.94, "047843", 54634.94, "", 0, "17-08-2026", 67));
		rows.add(row("4N26008102", "22-06-2026", "PO-DB-4412", 128450, "048102", 125950, "CN-4412", 2500, "28-08-2026", 67));
		rows.add(row("4N26008891", "05-07-2026", "ProCare DB21610", 89210.50, "048891", 89210.50, "", 0, "02-09-2026", 59));
		rows.add(row("4N26009220", "18-07-2026", "PO-DB-4488", 245000, "UTR-HDFC92837461", 245000, "", 0, "02-09-2026", 46));
		rows.add(row("4N26009551", "01-08-2026", "PO-DB-4501", 36780, "049551", 35580, "CN-4501", 1200, "10-09-2026", 40));
		rows.add(row("4N26009910", "12-08-2026", "ProCare DB21702", 175430.50, "ACH-SEP-4412", 175430.50, "", 0, "15-09-2026", 34));
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static Map<String, Object> row(
			String invoiceNo, String invoiceDate, String poNo, double invoiceAmount, String paymentRef,
			double amount, String creditNoteAdj, double creditNoteAmount, String closedDate, int daysToPay) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("invoiceNo", invoiceNo);
		m.put("invoiceDate", invoiceDate);
		m.put("poNo", poNo);
		m.put("invoiceAmount", invoiceAmount);
		m.put("paymentRef", paymentRef);
		m.put("amount", amount);
		m.put("creditNoteAdj", creditNoteAdj);
		m.put("creditNoteAmount", creditNoteAmount);
		m.put("closedDate", closedDate);
		m.put("daysToPay", daysToPay);
		m.put("totalRow", false);
		return m;
	}
}
