package com.mmm.customer.account_status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Unapplied Amount tab — single-file API (MyOrders / PaidInvoices style).
 * Real data comes from the legacy AS400 procedure BPCSLCLIN.COS024S.
 * Set dummy=true to use local sample rows when AS400 is unavailable.
 *
 * GET /api/customer/account-status/unapplied?custCode=&loginId=&dummy=
 *
 * COS024S returns three columns. The legacy screen renames them by position
 * (UnappliedAmtCtrl.js keyChangeAll: pref, applamt, unapplamt), so ordinal
 * is the contract when a row has exactly those three columns.
 */
@RestController
@RequestMapping("/api/customer/account-status/unapplied")
public class UnappliedAmount {

	private static final Logger logger = LoggerFactory.getLogger(UnappliedAmount.class);

	/** Legacy result order: 1 payment reference, 2 applied amount, 3 unapplied amount. */
	private static final int LEGACY_COLUMN_COUNT = 3;

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	/** Legacy account-status application code (APPCODEMYPAY = INPC). */
	@Value("${inpc.account-status.app-code:INPC}")
	private String appCode;

	public UnappliedAmount(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Unapplied amount request: custCode={}, loginId={}, dummy={}", custCode, loginId, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			List<Map<String, Object>> rows = dummy
					? dummyRows(code)
					: loadAs400Rows(login, code);

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load unapplied amount", ex);
			result.SetError(-1, "failure", "Unable to load unapplied amount");
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadAs400Rows(String loginId, String custCode) {
		String code = appCode == null ? "" : appCode.trim();
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS024S("
				+ sqlLiteral(code) + ","
				+ sqlLiteral(loginId) + ","
				+ sqlLiteral(custCode) + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS024S(?,?,?)}",
				code, loginId, custCode);

		logRawColumns(rawRows);

		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			Map<String, Object> row = new LinkedHashMap<>();
			row.put("paymentRef", text(valueAt(source, 1, "PREF", "PHCKNO", "CKNO")));
			row.put("appliedAmount", zeroIfBlank(valueAt(source, 2, "APPLAMT", "PHCAAP")));
			row.put("unappliedAmount", zeroIfBlank(valueAt(source, 3, "UNAPPLAMT", "PHUNAA")));
			row.put("custCode", custCode);
			rows.add(row);
		}
		return rows;
	}

	private static void logRawColumns(List<Map<String, Object>> rawRows) {
		if (rawRows == null || rawRows.isEmpty()) {
			logger.info("COS024S returned 0 rows.");
			return;
		}
		Map<String, Object> first = rawRows.get(0);
		logger.info("COS024S returned {} row(s). {} raw column(s): {}",
				rawRows.size(), first.size(), first.keySet());
		logger.info("COS024S first row values: {}", first.values());
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	/**
	 * Name lookup first, then the fixed 1-based ordinal, and only when the row
	 * has the three columns the legacy screen assigned.
	 */
	private static Object valueAt(Map<String, Object> row, int ordinal, String... names) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			for (String name : names) {
				if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
					if (!isBlank(entry.getValue())) {
						return entry.getValue();
					}
				}
			}
		}
		if (ordinal >= 1 && row.size() == LEGACY_COLUMN_COUNT) {
			return new ArrayList<>(row.values()).get(ordinal - 1);
		}
		return null;
	}

	private static String text(Object value) {
		if (value == null) {
			return "";
		}
		if (value instanceof BigDecimal decimal) {
			return decimal.stripTrailingZeros().toPlainString();
		}
		return String.valueOf(value).trim();
	}

	private static boolean isBlank(Object value) {
		return value == null || text(value).isEmpty();
	}

	private static Object zeroIfBlank(Object value) {
		return isBlank(value) ? "0" : value;
	}

	private static List<Map<String, Object>> dummyRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row("034946", 1020000, 125450));
		rows.add(row("035102", 250000, 48750));
		rows.add(row("035288", 75000, 75000));
		rows.add(row("035401", 110500, 22500));
		rows.add(row("035612", 40000, 18900));
		rows.add(row("035790", 325000, 9850));
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static Map<String, Object> row(String paymentRef, double appliedAmount, double unappliedAmount) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("paymentRef", paymentRef);
		m.put("appliedAmount", appliedAmount);
		m.put("unappliedAmount", unappliedAmount);
		return m;
	}
}
