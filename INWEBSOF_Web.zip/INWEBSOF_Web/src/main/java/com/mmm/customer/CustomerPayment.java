package com.mmm.customer;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.BasicTypeReference;
import org.hibernate.type.StandardBasicTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Customer Payment Summary — single-file controller (ChangeCustomer style).
 * System Hibernate: {@link #systemSession()} ({@code @Transactional} + getCurrentSession).
 * AS400 data comes from {@code BPCSLCLIN.COS015S} through {@link NativeQuerySupport}.
 *
 * Client: {@code GET /api/customer/customer-payment/summary?custCode=...&loginId=...&dummy=...}
 */
@RestController
@RequestMapping("/api/customer/customer-payment")
public class CustomerPayment {

    private static final Logger logger = LoggerFactory.getLogger(CustomerPayment.class);
    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu");
    private static final String PAYMENT_SUMMARY_CUSTOMER_CODE = "0";

    private final SessionFactory systemSessionFactory;
    private final HibernateFactoryRegistry hibernateRegistry;
    private final Gson gson = new Gson();

    /** Legacy payment application code (APPCODEMYPAY = INPC). */
    @Value("${inpc.account-status.app-code:INPC}")
    private String appCode;

    public CustomerPayment(
            @Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory systemSessionFactory,
            HibernateFactoryRegistry hibernateRegistry) {
        this.systemSessionFactory = systemSessionFactory;
        this.hibernateRegistry = hibernateRegistry;
        // Do NOT call getAs400SessionFactory() here — AS400 is lazy; building it in the
        // constructor breaks Spring bean creation when AS400 DS is down/misconfigured.
    }

    /** System Hibernate — Spring TX / getCurrentSession (ChangeCustomer style). */
    private Session systemSession() {
        return systemSessionFactory.getCurrentSession();
    }

    @GetMapping("/summary")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String summary(
            HttpServletRequest request,
            @RequestParam(value = "custCode", required = false) String custCode,
            @RequestParam(value = "loginId", required = false) String loginId,
            @RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession httpSession = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(httpSession)) {
            result.SetError(
                    UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
                    "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }

        try {
            UserSessionSupport.ProcedureCustomerContext context =
                    UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
            String code = context.custCode();
            String login = context.loginId();
            if (code.isEmpty()) {
                result.SetError(-1, "failure", "Customer code is required.");
                return gson.toJson(result);
            }

            Map<String, Object> company = loadCompanyFromSystem(code);
            Map<String, Object> cycles = dummy
                    ? buildDummyPaymentCycles(LocalDate.now())
                    : loadPaymentCyclesFromAs400(login);

            Map<String, Object> data = new LinkedHashMap<>();
            Object companyLevel = firstNonBlank(
                    cycles.get("companyLevel"),
                    company.get("companyLevel"),
                    company.get("cust_name"),
                    code);
            data.put("companyLevel", companyLevel == null ? "" : String.valueOf(companyLevel));
            data.put("asOf", firstNonBlank(cycles.get("asOf"), formatAsOf(LocalDate.now())));
            data.put("currency", firstNonBlank(cycles.get("currency"), "INR"));
            data.put("custCode", code);
            data.put("loginId", login);
            data.put("source", dummy ? "dummy" : "as400");

            @SuppressWarnings("unchecked")
            Map<String, Object> currentMonth = cycles.get("currentMonth") instanceof Map
                    ? (Map<String, Object>) cycles.get("currentMonth")
                    : emptyMonth(LocalDate.now());
            @SuppressWarnings("unchecked")
            Map<String, Object> nextMonth = cycles.get("nextMonth") instanceof Map
                    ? (Map<String, Object>) cycles.get("nextMonth")
                    : emptyMonth(LocalDate.now().plusMonths(1));
            data.put("currentMonth", currentMonth);
            data.put("nextMonth", nextMonth);

            if (cycles.get("rawRows") != null) {
                data.put("rawRows", cycles.get("rawRows"));
            }
            if (!company.isEmpty()) {
                data.put("customer", company);
            }

            result.SetSuccess("success", data);
        } catch (Exception ex) {
            logger.error("Unable to load customer payment summary", ex);
            result.SetError(-1, "failure", "Unable to load payment summary.");
        }
        return gson.toJson(result);
    }

    /** System DB — customer master for company / customer label. */
    private Map<String, Object> loadCompanyFromSystem(String custCode) {
        String sql = """
                select top 1
                       isnull(u.cust_code,'') as cust_code,
                       isnull(u.cust_name,'') as cust_name,
                       isnull(u.cust_name,'') as companyLevel
                from ia_user_master u
                where isnull(u.cust_code,'') = :custCode
                """;
        Map<String, Object> params = Map.of("custCode", custCode);
        Map<String, BasicTypeReference<?>> scalars = new LinkedHashMap<>();
        scalars.put("cust_code", StandardBasicTypes.STRING);
        scalars.put("cust_name", StandardBasicTypes.STRING);
        scalars.put("companyLevel", StandardBasicTypes.STRING);
        List<Map<String, Object>> rows =
                NativeQuerySupport.listAsMaps(systemSession(), sql, params, scalars);
        if (rows == null || rows.isEmpty()) {
            Map<String, Object> empty = new LinkedHashMap<>();
            empty.put("cust_code", custCode);
            empty.put("cust_name", "");
            empty.put("companyLevel", custCode);
            return empty;
        }
        return rows.get(0);
    }

    /** Legacy CPAR payment summary uses CUSTCOD=0 for company-level cycles. */
    private Map<String, Object> loadPaymentCyclesFromAs400(String loginId) {
        String configuredAppCode = appCode == null ? "" : appCode.trim();
        System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS015S("
                + sqlLiteral(configuredAppCode) + ","
                + sqlLiteral(loginId) + ","
                + sqlLiteral(PAYMENT_SUMMARY_CUSTOMER_CODE) + ")");
        List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
                hibernateRegistry,
                HibernateFactoryRegistry.AS400,
                "{call BPCSLCLIN.COS015S(?,?,?)}",
                configuredAppCode, loginId, PAYMENT_SUMMARY_CUSTOMER_CODE);
        if (rawRows != null && !rawRows.isEmpty()) {
            logger.info("COS015S returned {} row(s); columns: {}", rawRows.size(), rawRows.get(0).keySet());
        } else {
            logger.info("COS015S returned 0 rows.");
        }
        Map<String, Object> cycles = mapPaymentCycles(rawRows, LocalDate.now());
        cycles.put("rawRows", rawRows);
        return cycles;
    }

    private static String sqlLiteral(Object value) {
        String text = value == null ? "" : String.valueOf(value);
        text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
        return "'" + text.replace("'", "''") + "'";
    }

    private static Map<String, Object> mapPaymentCycles(List<Map<String, Object>> rows, LocalDate today) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("asOf", formatAsOf(today));
        out.put("currency", "INR");
        Map<String, Object> current = emptyMonth(today);
        Map<String, Object> next = emptyMonth(today.plusMonths(1));
        List<Map<String, Object>> currentPayments = new ArrayList<>();
        List<Map<String, Object>> nextPayments = new ArrayList<>();
        BigDecimal currentTotal = BigDecimal.ZERO;
        BigDecimal nextTotal = BigDecimal.ZERO;
        int holdCount = 0;

        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object rawDate = firstPresent(row, "ECCDDT", "ECCDT", "eccddt", "eccdt", "ecsDate", "ECSDATE");
                Object rawAmount = firstPresent(row, "AMT", "amt", "00007");
                if (rawAmount == null && row != null && row.size() > 1) {
                    rawAmount = new ArrayList<>(row.values()).get(1);
                }
                BigDecimal amount = toAmount(rawAmount);
                String dateText = dateValue(rawDate);
                boolean holdRow = isZeroDate(dateText)
                        || "-".equals(dateValue(firstPresent(row, "ecsDate", "ECSDATE")));
                if (holdRow) {
                    if (holdCount++ == 0) {
                        current.put("holdAmount", amount);
                    } else if (holdCount == 2) {
                        next.put("holdAmount", amount);
                    }
                    continue;
                }

                LocalDate paymentDate = parsePaymentDate(rawDate);
                if (paymentDate == null) {
                    logger.warn("Skipping COS015S row with an invalid payment date: {}", rawDate);
                    continue;
                }

                Map<String, Object> payment = new LinkedHashMap<>();
                payment.put("date", paymentDate.format(DISPLAY_DATE));
                payment.put("amount", amount);
                if (paymentDate.getYear() == today.getYear()
                        && paymentDate.getMonthValue() == today.getMonthValue()) {
                    currentPayments.add(payment);
                    currentTotal = currentTotal.add(amount);
                } else if (paymentDate.getYear() == today.plusMonths(1).getYear()
                        && paymentDate.getMonthValue() == today.plusMonths(1).getMonthValue()) {
                    nextPayments.add(payment);
                    nextTotal = nextTotal.add(amount);
                } else {
                    logger.warn("Skipping COS015S payment outside current/next month: {}", rawDate);
                }
            }
        }

        currentPayments.sort((left, right) -> String.valueOf(left.get("date"))
                .compareTo(String.valueOf(right.get("date"))));
        nextPayments.sort((left, right) -> String.valueOf(left.get("date"))
                .compareTo(String.valueOf(right.get("date"))));
        current.put("payments", currentPayments);
        current.put("total", currentTotal);
        next.put("payments", nextPayments);
        next.put("total", nextTotal);
        out.put("currentMonth", current);
        out.put("nextMonth", next);
        return out;
    }

    private static Map<String, Object> buildDummyPaymentCycles(LocalDate today) {
        int[] days = {5, 10, 15, 20, 25, 30};
        String[] currentAmounts = {
                "3131243.41", "11249545.80", "25636770.86",
                "15030044.73", "31308341.91", "32819996.15"
        };
        String[] nextAmounts = {
                "18935631.37", "23393094.28", "77547322.94",
                "20459356.85", "16843006.61", "38853118.25"
        };
        List<Map<String, Object>> rows = new ArrayList<>();
        LocalDate nextMonth = today.plusMonths(1);
        for (int i = 0; i < days.length; i++) {
            LocalDate currentDate = today.withDayOfMonth(Math.min(days[i], today.lengthOfMonth()));
            LocalDate nextDate = nextMonth.withDayOfMonth(Math.min(days[i], nextMonth.lengthOfMonth()));
            rows.add(paymentCycleRow(currentDate, currentAmounts[i]));
            rows.add(paymentCycleRow(nextDate, nextAmounts[i]));
        }
        Map<String, Object> cycles = mapPaymentCycles(rows, today);
        cycles.put("source", "dummy");
        return cycles;
    }

    private static Map<String, Object> paymentCycleRow(LocalDate date, String amount) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("ECCDT", date.format(DateTimeFormatter.BASIC_ISO_DATE));
        row.put("AMT", new BigDecimal(amount));
        return row;
    }

    private static LocalDate parsePaymentDate(Object value) {
        if (value instanceof Date date) {
            return date.toLocalDate();
        }
        if (value instanceof Timestamp timestamp) {
            return timestamp.toLocalDateTime().toLocalDate();
        }
        String raw = dateValue(value);
        if (raw.length() == 8 && raw.chars().allMatch(Character::isDigit)) {
            try {
                return LocalDate.parse(raw, DateTimeFormatter.BASIC_ISO_DATE);
            } catch (DateTimeParseException ex) {
                return null;
            }
        }
        try {
            return LocalDate.parse(raw, DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (DateTimeParseException ex) {
            return null;
        }
    }

    private static BigDecimal toAmount(Object value) {
        if (value == null) {
            return BigDecimal.ZERO;
        }
        if (value instanceof BigDecimal decimal) {
            return decimal;
        }
        if (value instanceof Number number) {
            return new BigDecimal(number.toString());
        }
        String raw = String.valueOf(value).replace(",", "").trim();
        if (raw.isEmpty()) {
            return BigDecimal.ZERO;
        }
        try {
            return new BigDecimal(raw);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid payment amount returned by COS015S.", ex);
        }
    }

    private static String dateValue(Object value) {
        if (value instanceof Number number) {
            try {
                return new BigDecimal(number.toString()).stripTrailingZeros().toPlainString();
            } catch (NumberFormatException ex) {
                return number.toString();
            }
        }
        return stringVal(value);
    }

    private static boolean isZeroDate(String value) {
        if (value == null || value.isBlank()) {
            return false;
        }
        try {
            return new BigDecimal(value).compareTo(BigDecimal.ZERO) == 0;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private static Map<String, Object> emptyMonth(LocalDate month) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("label", month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)));
        m.put("payments", List.of());
        m.put("total", 0);
        return m;
    }

    private static String formatAsOf(LocalDate d) {
        return d.format(DateTimeFormatter.ofPattern("dd MMMM, yyyy", Locale.ENGLISH));
    }

    private static Object firstNonBlank(Object... vals) {
        if (vals == null) {
            return null;
        }
        for (Object v : vals) {
            if (v == null) {
                continue;
            }
            String s = String.valueOf(v).trim();
            if (!s.isEmpty() && !"null".equalsIgnoreCase(s)) {
                return s;
            }
        }
        return null;
    }

    private static Object firstPresent(Map<String, Object> row, String... keys) {
        if (row == null || keys == null) {
            return null;
        }
        for (String k : keys) {
            if (row.containsKey(k) && row.get(k) != null) {
                return row.get(k);
            }
            for (Map.Entry<String, Object> e : row.entrySet()) {
                if (e.getKey() != null && e.getKey().equalsIgnoreCase(k) && e.getValue() != null) {
                    return e.getValue();
                }
            }
        }
        return null;
    }

    private static String stringVal(Object o) {
        return o == null ? "" : String.valueOf(o).trim();
    }

}
