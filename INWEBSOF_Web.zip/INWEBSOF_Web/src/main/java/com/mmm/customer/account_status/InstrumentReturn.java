package com.mmm.customer.account_status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Instrument Return tab — single-file API (MyOrders / PaidInvoices style).
 * Real data comes from the legacy AS400 procedure BPCSLCLIN.COS016S.
 * Set dummy=true to use local sample rows when AS400 is unavailable.
 *
 * GET /api/customer/account-status/instrument-return?custCode=&loginId=&dummy=
 *
 * PaymentRefCtrl.js renames the result by position:
 * CRCHQN, CRCHDT, CRAMT, CRSTS, CRRFRT.
 * CRSTS is R = Resolved, P = Partially Resolved, anything else Unresolved.
 */
@RestController
@RequestMapping("/api/customer/account-status/instrument-return")
public class InstrumentReturn {

	private static final Logger logger = LoggerFactory.getLogger(InstrumentReturn.class);
	private static final DateTimeFormatter YMD = DateTimeFormatter.BASIC_ISO_DATE;
	private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd/MM/uuuu");
	private static final DateTimeFormatter DMY_DASH = DateTimeFormatter.ofPattern("dd-MM-uuuu");
	private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu");

	/** Legacy keyChangeAll length in PaymentRefCtrl.js. */
	private static final int LEGACY_COLUMN_COUNT = 5;

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	/** Legacy payments application code (APPCODEMYPAY = INPC). */
	@Value("${inpc.account-status.app-code:INPC}")
	private String appCode;

	public InstrumentReturn(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Instrument return request: custCode={}, loginId={}, dummy={}", custCode, loginId, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			List<Map<String, Object>> rows = dummy
					? dummyRows(code)
					: loadAs400Rows(login, code);

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load instrument return", ex);
			result.SetError(-1, "failure", "Unable to load instrument return");
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadAs400Rows(String loginId, String custCode) {
		String code = appCode == null ? "" : appCode.trim();
		String customer = custCode == null ? "" : custCode.trim();
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS016S("
				+ sqlLiteral(code) + ","
				+ sqlLiteral(loginId) + ","
				+ sqlLiteral(customer) + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS016S(?,?,?)}",
				code, loginId, customer);

		logRawColumns(rawRows);

		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			Map<String, Object> row = new LinkedHashMap<>();
			row.put("paymentRef", text(valueAt(source, 1, "CRCHQN")));
			row.put("txnDate", displayDate(valueAt(source, 2, "CRCHDT")));
			row.put("amount", zeroIfBlank(valueAt(source, 3, "CRAMT")));
			row.put("status", statusLabel(text(valueAt(source, 4, "CRSTS"))));
			row.put("reason", text(valueAt(source, 5, "CRRFRT")));
			row.put("custCode", customer);
			rows.add(row);
		}
		return rows;
	}

	/** Legacy changests(): R Resolved, P Partially Resolved, otherwise Unresolved. */
	private static String statusLabel(String code) {
		String value = code == null ? "" : code.trim().toUpperCase();
		if (value.startsWith("R")) {
			return "Resolved";
		}
		if (value.startsWith("P")) {
			return "Partially Resolved";
		}
		if (value.isEmpty()) {
			return "";
		}
		return "Unresolved";
	}

	private static void logRawColumns(List<Map<String, Object>> rawRows) {
		if (rawRows == null || rawRows.isEmpty()) {
			logger.info("COS016S returned 0 rows.");
			return;
		}
		Map<String, Object> first = rawRows.get(0);
		logger.info("COS016S returned {} row(s). {} raw column(s): {}",
				rawRows.size(), first.size(), first.keySet());
		logger.info("COS016S first row values: {}", first.values());
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	private static Object valueAt(Map<String, Object> row, int ordinal, String... names) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			for (String name : names) {
				if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
					if (!isBlank(entry.getValue())) {
						return entry.getValue();
					}
				}
			}
		}
		if (ordinal >= 1 && row.size() == LEGACY_COLUMN_COUNT) {
			return new ArrayList<>(row.values()).get(ordinal - 1);
		}
		return null;
	}

	private static String text(Object value) {
		if (value == null) {
			return "";
		}
		if (value instanceof BigDecimal decimal) {
			return decimal.stripTrailingZeros().toPlainString();
		}
		return String.valueOf(value).trim();
	}

	private static boolean isBlank(Object value) {
		return value == null || text(value).isEmpty();
	}

	private static Object zeroIfBlank(Object value) {
		return isBlank(value) ? "0" : value;
	}

	private static LocalDate parseDate(String raw) {
		String value = raw == null ? "" : raw.trim();
		if (value.isEmpty() || "0".equals(value) || "NA".equalsIgnoreCase(value)) {
			return null;
		}
		try {
			if (value.length() == 8 && value.chars().allMatch(Character::isDigit)) {
				return LocalDate.parse(value, YMD);
			}
			if (value.contains("/")) {
				return LocalDate.parse(value, DMY);
			}
			if (value.contains("-") && value.length() >= 10 && Character.isDigit(value.charAt(0))) {
				return LocalDate.parse(value.substring(0, 10), DMY_DASH);
			}
			return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
		} catch (DateTimeParseException ex) {
			return null;
		}
	}

	private static String displayDate(Object raw) {
		String value = text(raw);
		if (value.isEmpty() || "0".equals(value)) {
			return "NA";
		}
		if ("NA".equalsIgnoreCase(value)) {
			return "NA";
		}
		LocalDate date = parseDate(value);
		return date == null ? value : date.format(DISPLAY_DATE);
	}

	private static List<Map<String, Object>> dummyRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row("CHQ-992184", "14/08/2026", 75000, "Returned", "Insufficient funds"));
		rows.add(row("CHQ-990811", "29/07/2026", 120000, "Returned", "Signature mismatch"));
		rows.add(row("CHQ-988402", "11/07/2026", 45500, "Returned", "Account closed"));
		rows.add(row("CHQ-987155", "02/07/2026", 200000, "Returned", "Stop payment"));
		rows.add(row("CHQ-985900", "18/06/2026", 60250, "Returned", "Drawer signature differs"));
		rows.add(row("CHQ-984210", "05/06/2026", 33800, "Returned", "Post-dated cheque presented early"));
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static Map<String, Object> row(String paymentRef, String txnDate, double amount, String status, String reason) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("paymentRef", paymentRef);
		m.put("txnDate", txnDate);
		m.put("amount", amount);
		m.put("status", status);
		m.put("reason", reason);
		return m;
	}
}
