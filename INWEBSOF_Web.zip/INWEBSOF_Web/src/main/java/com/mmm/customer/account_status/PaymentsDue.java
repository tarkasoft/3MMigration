package com.mmm.customer.account_status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Payments Due tab — single-file API (MyOrders / PaidInvoices style).
 * Real data comes from the legacy AS400 procedure BPCSLCLIN.COS014S.
 * Set dummy=true to use local sample rows when AS400 is unavailable.
 *
 * GET /api/customer/account-status/payments-due?custCode=&loginId=&dummy=
 *
 * Legacy MyPayments/getPayment always passes debit date 99999999 (all dates).
 * The result is renamed by position in PaymentsCtrl.js keyChangeAll. This grid
 * keeps the eleven columns the new screen already shows. Remarks stay read-only
 * and are not returned.
 */
@RestController
@RequestMapping("/api/customer/account-status/payments-due")
public class PaymentsDue {

	private static final Logger logger = LoggerFactory.getLogger(PaymentsDue.class);
	private static final DateTimeFormatter YMD = DateTimeFormatter.BASIC_ISO_DATE;
	private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd/MM/uuuu");
	private static final DateTimeFormatter DMY_DASH = DateTimeFormatter.ofPattern("dd-MM-uuuu");
	private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu");

	/** Legacy getPayment debit-date sentinel: every debit date. */
	private static final String ALL_DEBIT_DATES = "99999999";

	/**
	 * COS014S result order from PaymentsCtrl.js keyChangeAll, before the later
	 * empty slots in that array: 21 named columns.
	 */
	private static final int LEGACY_COLUMN_COUNT = 21;

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	/** Legacy payments application code (APPCODEMYPAY = INPC). */
	@Value("${inpc.account-status.app-code:INPC}")
	private String appCode;

	public PaymentsDue(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Payments due request: custCode={}, loginId={}, dummy={}", custCode, loginId, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}

			List<Map<String, Object>> rows = dummy
					? dummyRows(code)
					: loadAs400Rows(login, code);

			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", code);
			data.put("loginId", login);
			data.put("debitDate", ALL_DEBIT_DATES);
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load payments due", ex);
			result.SetError(-1, "failure", "Unable to load payments due");
		}
		return gson.toJson(result);
	}

	private List<Map<String, Object>> loadAs400Rows(String loginId, String custCode) {
		String code = appCode == null ? "" : appCode.trim();
		String customer = custCode == null ? "" : custCode.trim();
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS014S("
				+ sqlLiteral(code) + ","
				+ sqlLiteral(loginId) + ","
				+ sqlLiteral(customer) + ","
				+ sqlLiteral(ALL_DEBIT_DATES) + ")");
		List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS014S(?,?,?,?)}",
				code, loginId, customer, ALL_DEBIT_DATES);

		logRawColumns(rawRows);

		List<Map<String, Object>> rows = new ArrayList<>();
		for (Map<String, Object> source : rawRows) {
			Map<String, Object> row = new LinkedHashMap<>();
			row.put("division", text(valueAt(source, 1, "ESDIV")));
			row.put("type", text(valueAt(source, 3, "ESTYPE")));
			row.put("invNo", text(valueAt(source, 4, "ESINVN")));
			row.put("poNo", text(valueAt(source, 6, "ESCUSPO")));
			row.put("paymentTerm", text(valueAt(source, 7, "ESTERM")));
			row.put("invDate", displayDate(valueAt(source, 5, "ESINVDT")));
			row.put("dueDate", displayDate(valueAt(source, 12, "ESDUDT")));
			row.put("invAmount", zeroIfBlank(valueAt(source, 8, "ESIAMT")));
			row.put("balanceAmt", zeroIfBlank(valueAt(source, 9, "ESBAMT")));
			row.put("amountToDebit", zeroIfBlank(valueAt(source, 10, "ESDAMT")));
			row.put("balanceAfterDebit", zeroIfBlank(valueAt(source, 11, "ESBADA")));
			row.put("custCode", customer);
			rows.add(row);
		}
		return rows;
	}

	private static void logRawColumns(List<Map<String, Object>> rawRows) {
		if (rawRows == null || rawRows.isEmpty()) {
			logger.info("COS014S returned 0 rows.");
			return;
		}
		Map<String, Object> first = rawRows.get(0);
		logger.info("COS014S returned {} row(s). {} raw column(s): {}",
				rawRows.size(), first.size(), first.keySet());
		logger.info("COS014S first row values: {}", first.values());
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	/**
	 * Name lookup first, then the fixed 1-based ordinal, and only when the row
	 * has the 21 columns the legacy screen assigned.
	 */
	private static Object valueAt(Map<String, Object> row, int ordinal, String... names) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			for (String name : names) {
				if (entry.getKey() != null && entry.getKey().trim().equalsIgnoreCase(name)) {
					if (!isBlank(entry.getValue())) {
						return entry.getValue();
					}
				}
			}
		}
		if (ordinal >= 1 && row.size() == LEGACY_COLUMN_COUNT) {
			return new ArrayList<>(row.values()).get(ordinal - 1);
		}
		return null;
	}

	private static String text(Object value) {
		if (value == null) {
			return "";
		}
		if (value instanceof BigDecimal decimal) {
			return decimal.stripTrailingZeros().toPlainString();
		}
		return String.valueOf(value).trim();
	}

	private static boolean isBlank(Object value) {
		return value == null || text(value).isEmpty();
	}

	private static Object zeroIfBlank(Object value) {
		return isBlank(value) ? "0" : value;
	}

	private static LocalDate parseDate(String raw) {
		String value = raw == null ? "" : raw.trim();
		if (value.isEmpty() || "0".equals(value) || "NA".equalsIgnoreCase(value)) {
			return null;
		}
		try {
			if (value.length() == 8 && value.chars().allMatch(Character::isDigit)) {
				return LocalDate.parse(value, YMD);
			}
			if (value.contains("/")) {
				return LocalDate.parse(value, DMY);
			}
			if (value.contains("-") && value.length() >= 10 && Character.isDigit(value.charAt(0))) {
				return LocalDate.parse(value.substring(0, 10), DMY_DASH);
			}
			return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
		} catch (DateTimeParseException ex) {
			return null;
		}
	}

	/** Legacy formatDate2: yyyyMMdd becomes dd-MM-yyyy. Blank or 0 becomes NA. */
	private static String displayDate(Object raw) {
		String value = text(raw);
		if (value.isEmpty() || "0".equals(value)) {
			return "NA";
		}
		if ("NA".equalsIgnoreCase(value)) {
			return "NA";
		}
		LocalDate date = parseDate(value);
		return date == null ? value : date.format(DISPLAY_DATE);
	}

	private static List<Map<String, Object>> dummyRows(String custCode) {
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(row("Industrial", "Invoice", "INV-2026-08421", "PO-DB-4412", "EOM ACH 45", "12/08/2026", "26/09/2026", 512450, 485620, 485620, 0));
		rows.add(row("Automotive", "Invoice", "INV-2026-08510", "PO-DB-4488", "EOM ACH 45", "20/08/2026", "04/10/2026", 276800, 276800, 150000, 126800));
		rows.add(row("Healthcare", "Debit Note", "DN-2026-0192", "PO-DB-4501", "Net 30", "01/09/2026", "01/10/2026", 48750, 48750, 48750, 0));
		rows.add(row("Industrial", "Invoice", "INV-2026-08602", "PO-DB-4520", "EOM ACH 45", "05/09/2026", "20/10/2026", 915320, 915320, 0, 915320));
		rows.add(row("Electronics", "Invoice", "INV-2026-08644", "PO-DB-4533", "Net 15", "08/09/2026", "23/09/2026", 162110.50, 112110.50, 112110.50, 0));
		rows.add(row("Automotive", "Invoice", "INV-2026-08701", "PO-DB-4550", "EOM ACH 45", "10/09/2026", "25/10/2026", 340000, 340000, 340000, 0));
		for (Map<String, Object> r : rows) {
			r.put("custCode", custCode);
		}
		return rows;
	}

	private static Map<String, Object> row(
			String division, String type, String invNo, String poNo, String paymentTerm,
			String invDate, String dueDate, double invAmount, double balanceAmt,
			double amountToDebit, double balanceAfterDebit) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("division", division);
		m.put("type", type);
		m.put("invNo", invNo);
		m.put("poNo", poNo);
		m.put("paymentTerm", paymentTerm);
		m.put("invDate", invDate);
		m.put("dueDate", dueDate);
		m.put("invAmount", invAmount);
		m.put("balanceAmt", balanceAmt);
		m.put("amountToDebit", amountToDebit);
		m.put("balanceAfterDebit", balanceAfterDebit);
		return m;
	}
}
