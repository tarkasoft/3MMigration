package com.mmm.customer.account_status;

import java.sql.Types;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Account Summary tab.
 * Live figures come from BPCSLCLIN.COS001S and BPCSLCLIN.COS002S.
 * Both procedures take APPCODE and LOGINID only; the customer is the login
 * on AS400. dummy=true keeps the local sample (window.as400_dummy_data_required).
 *
 * GET /api/customer/account-status/summary?custCode=&loginId=&dummy=
 */
@RestController
@RequestMapping("/api/customer/account-status/summary")
public class AccountSummary {

	private static final Logger logger = LoggerFactory.getLogger(AccountSummary.class);
	private static final DateTimeFormatter AS_ON = DateTimeFormatter.ofPattern("dd MMMM, yyyy", Locale.ENGLISH);

	private static final String COLOR_30 = "#0b5fff";
	private static final String COLOR_60 = "#f59e0b";
	private static final String COLOR_90 = "#f97316";
	private static final String COLOR_GT90 = "#ef4444";

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();

	@Value("${inpc.account-status.app-code:INPC}")
	private String appCode;

	public AccountSummary(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {

		logger.info("Account summary request: custCode={}, loginId={}, dummy={}", custCode, loginId, dummy);
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(
					UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
					"failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}

		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			String login = context.loginId();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}
			if (!dummy && login.isEmpty()) {
				result.SetError(-1, "failure", "loginId is required");
				return gson.toJson(result);
			}

			Map<String, Object> data = dummy
					? dummySummary(code)
					: loadAs400Summary(login, code);
			data.put("loginId", login);
			data.put("source", dummy ? "dummy" : "as400");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load account summary", ex);
			result.SetError(-1, "failure", "Unable to load account summary");
		}
		return gson.toJson(result);
	}

	private Map<String, Object> loadAs400Summary(String loginId, String custCode) {
		String code = appCode == null ? "" : appCode.trim();
		Map<Integer, Object> summary = callCos001(code, loginId);
		Map<Integer, Object> ageing = callCos002(code, loginId);

		double outstandingTotal = money(summary.get(8));
		double outstandingCurrent = money(ageing.get(3));
		double unappliedCash = money(summary.get(7));
		double unappliedCreditNotes = money(summary.get(12));
		double overdueTotal = money(summary.get(11));
		double due30 = money(ageing.get(4));
		double due60 = money(ageing.get(5));
		double due90 = money(ageing.get(6));
		double dueGt90 = money(ageing.get(7));
		String terms = text(summary.get(10));

		Map<String, Object> data = new LinkedHashMap<>();
		data.put("custCode", custCode);
		data.put("custName", text(summary.get(3)));
		data.put("asOn", LocalDate.now().format(AS_ON));
		data.put("paymentTerms", terms);
		data.put("termsShort", terms);
		data.put("status", text(summary.get(4)));
		data.put("creditLimit", money(summary.get(5)));
		data.put("amountOverCreditLimit", money(summary.get(6)));
		data.put("openOrders", money(summary.get(9)));
		data.put("outstandingTotal", outstandingTotal);
		data.put("outstandingCurrent", outstandingCurrent);
		data.put("unappliedCash", unappliedCash);
		data.put("unappliedCreditNotes", unappliedCreditNotes);
		data.put("overdueTotal", overdueTotal);
		data.put("openBalanceLabel", compactInr(outstandingTotal));
		data.put("overdueLabel", compactInr(overdueTotal));
		data.put("unappliedLabel", compactInr(unappliedCash + unappliedCreditNotes));

		double ageingBase = due30 + due60 + due90 + dueGt90;
		List<Map<String, Object>> aging = new ArrayList<>();
		aging.add(age("1-30 Days", due30, percent(due30, ageingBase), COLOR_30));
		aging.add(age("31-60 Days", due60, percent(due60, ageingBase), COLOR_60));
		aging.add(age("61-90 Days", due90, percent(due90, ageingBase), COLOR_90));
		aging.add(age(">90 Days", dueGt90, percent(dueGt90, ageingBase), COLOR_GT90));
		data.put("aging", aging);
		return data;
	}

	/**
	 * COS001S outputs, JDBC positions:
	 * 3 CUSTNAME, 4 ACCTSTATUS, 5 CRDTLIMIT, 6 AMTOVRCRDTLMT, 7 UNAPPLIEDCASH,
	 * 8 TOTDUE, 9 OPENORDERS, 10 PAYMENTTERMS, 11 TOTOVRDUE, 12 UNAPPLIEDCREDITNOTE.
	 */
	private Map<Integer, Object> callCos001(String appCode, String loginId) {
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS001S("
				+ sqlLiteral(appCode) + ","
				+ sqlLiteral(loginId)
				+ ",? /* CUSTNAME */,? /* ACCTSTATUS */,? /* CRDTLIMIT */,? /* AMTOVRCRDTLMT */"
				+ ",? /* UNAPPLIEDCASH */,? /* TOTDUE */,? /* OPENORDERS */,? /* PAYMENTTERMS */"
				+ ",? /* TOTOVRDUE */,? /* UNAPPLIEDCREDITNOTE */)");
		Map<Integer, Integer> outputs = new LinkedHashMap<>();
		for (int position = 3; position <= 12; position++) {
			outputs.put(position, Types.VARCHAR);
		}
		Map<Integer, Object> values = NativeQuerySupport.executeProcedureWithOutputs(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS001S(?,?,?,?,?,?,?,?,?,?,?,?)}",
				outputs,
				appCode, loginId);
		logger.info("COS001S outputs: {}", values);
		return values;
	}

	/**
	 * COS002S outputs, JDBC positions:
	 * 3 CURDUE, 4 DUE30DAYS, 5 DUE60DAYS, 6 DUE90DAYS, 7 DUEGT90DAYS, 8 DUETOT.
	 */
	private Map<Integer, Object> callCos002(String appCode, String loginId) {
		System.out.println("AS400 procedure call: CALL BPCSLCLIN.COS002S("
				+ sqlLiteral(appCode) + ","
				+ sqlLiteral(loginId)
				+ ",? /* CURDUE */,? /* DUE30DAYS */,? /* DUE60DAYS */,? /* DUE90DAYS */"
				+ ",? /* DUEGT90DAYS */,? /* DUETOT */)");
		Map<Integer, Integer> outputs = new LinkedHashMap<>();
		for (int position = 3; position <= 8; position++) {
			outputs.put(position, Types.VARCHAR);
		}
		Map<Integer, Object> values = NativeQuerySupport.executeProcedureWithOutputs(
				hibernateRegistry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.COS002S(?,?,?,?,?,?,?,?)}",
				outputs,
				appCode, loginId);
		logger.info("COS002S outputs: {}", values);
		return values;
	}

	private static double money(Object raw) {
		String value = text(raw).replace(",", "").replace("₹", "").trim();
		if (value.isEmpty() || "NA".equalsIgnoreCase(value)) {
			return 0d;
		}
		try {
			return Double.parseDouble(value);
		} catch (NumberFormatException ex) {
			return 0d;
		}
	}

	private static int percent(double part, double whole) {
		if (whole <= 0d) {
			return 0;
		}
		return (int) Math.round(part * 100d / whole);
	}

	/** Snapshot shorthand used by the cards: 1.14 Cr, 32.3 L. */
	private static String compactInr(double amount) {
		double abs = Math.abs(amount);
		String sign = amount < 0d ? "-" : "";
		if (abs >= 10_000_000d) {
			return sign + trimDecimals(abs / 10_000_000d) + " Cr";
		}
		if (abs >= 100_000d) {
			return sign + trimDecimals(abs / 100_000d) + " L";
		}
		return sign + trimDecimals(abs);
	}

	private static String trimDecimals(double value) {
		String text = String.format(Locale.ENGLISH, "%.2f", value);
		if (text.endsWith("0")) {
			text = text.substring(0, text.length() - 1);
		}
		if (text.endsWith("0")) {
			text = text.substring(0, text.length() - 1);
		}
		if (text.endsWith(".")) {
			text = text.substring(0, text.length() - 1);
		}
		return text;
	}

	private static String sqlLiteral(Object value) {
		String text = value == null ? "" : String.valueOf(value);
		text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return "'" + text.replace("'", "''") + "'";
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static Map<String, Object> dummySummary(String custCode) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("custCode", custCode);
		m.put("asOn", LocalDate.now().format(AS_ON));
		m.put("paymentTerms", "EOM ACH 45 days");
		m.put("termsShort", "Net 45 ACH");
		m.put("status", "Active");
		m.put("outstandingTotal", 11448124.00);
		m.put("outstandingCurrent", 8215680.50);
		m.put("unappliedCash", 125450.00);
		m.put("unappliedCreditNotes", 48750.00);
		m.put("overdueTotal", 3232443.50);
		m.put("openBalanceLabel", "1.14 Cr");
		m.put("overdueLabel", "32.3 L");
		m.put("unappliedLabel", "1.74 L");
		List<Map<String, Object>> aging = new ArrayList<>();
		aging.add(age("1-30 Days", 178420.00, 55, COLOR_30));
		aging.add(age("31-60 Days", 965110.25, 35, COLOR_60));
		aging.add(age("61-90 Days", 742890.00, 28, COLOR_90));
		aging.add(age(">90 Days", 1346023.25, 42, COLOR_GT90));
		m.put("aging", aging);
		return m;
	}

	private static Map<String, Object> age(String label, double amount, int pct, String color) {
		Map<String, Object> row = new LinkedHashMap<>();
		row.put("label", label);
		row.put("amount", amount);
		row.put("pct", pct);
		row.put("color", color);
		return row;
	}
}
