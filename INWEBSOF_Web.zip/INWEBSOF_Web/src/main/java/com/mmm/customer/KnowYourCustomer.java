package com.mmm.customer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Know Your Customer. One class for the header, the ship-to rows, and the update.
 *
 * GET  /api/customer/know-your-customer?custCode=&loginId=
 * POST /api/customer/know-your-customer
 *
 * Live KYC records use the INFOAPPS datasource. Pass dummy=true to preserve
 * the local sample-data path without writing to the database.
 */
@RestController
@RequestMapping("/api/customer/know-your-customer")
public class KnowYourCustomer {

	private static final Logger logger = LoggerFactory.getLogger(KnowYourCustomer.class);
	private static final String HEADER_SQL = "select top 1 "
			+ "isnull(cast(kh.cust_code as varchar(30)), cast(soc.CCUST as varchar(30))) as custCode, "
			+ "isnull(kh.name_of_proprietor, soc.CNME) as proprietorName, "
			+ "isnull(kh.business_address, concat(soc.CAD1, soc.CAD2, soc.CAD3, soc.CZIP)) as businessAddress, "
			+ "isnull(kh.billing_address, concat(soc.CAD1, soc.CAD2, soc.CAD3, soc.CZIP)) as billingAddress, "
			+ "isnull(kh.gst_no, '') as gstNo, isnull(kh.pan_no, '') as panNo, "
			+ "isnull(kh.primary_contact_no, '') as primaryContact, "
			+ "isnull(kh.alternate_contact_no, '') as alternateContact, "
			+ "isnull(kh.email_id_accounting, '') as emailAccounting, "
			+ "isnull(kh.email_id_transaction, '') as emailTransaction, "
			+ "isnull(kh.remarks, '') as remarks, isnull(kh.drug_license_no, '') as drugLicenseNo, "
			+ "isnull(kh.ui_status, 'New') as status, isnull(kh.approved_remarks, '') as approvalRemarks "
			+ "from SO_CustomerMaster soc left join Kyc_header kh "
			+ "on rtrim(cast(kh.cust_code as varchar(30))) = rtrim(cast(soc.CCUST as varchar(30))) "
			+ "where rtrim(cast(soc.CCUST as varchar(30))) = ?";
	private static final String KYC_ROWS_SQL = "select shipto_code as shipToCode, "
			+ "shipto_address as shipToAddress, isnull(gst_no, '') as gstNo, "
			+ "isnull(phone_no, '') as phoneNo, isnull(email_id, '') as emailId, "
			+ "isnull(pan_no, '') as panNo, isnull(contact_person, '') as contactPerson, "
			+ "isnull(shipto_remarks, '') as remarks from Kyc_group "
			+ "where rtrim(cast(cust_code as varchar(30))) = ? order by shipto_code";
	private static final String MASTER_ROWS_SQL = "select TSHIP as shipToCode, "
			+ "concat(TATN, TADR1, TADR2, TADR3, TPOST) as shipToAddress, "
			+ "'' as gstNo, isnull(TPhone, '') as phoneNo, isnull(STDATN, '') as emailId, "
			+ "'' as panNo, isnull(TCONT, '') as contactPerson, '' as remarks "
			+ "from ShipTo_Master where rtrim(cast(TCUST as varchar(30))) = ? order by TSHIP";
	private static String updateHeaderSql() {
		return "update Kyc_header set "
			+ "name_of_proprietor = ?, business_address = ?, billing_address = ?, gst_no = ?, "
			+ "drug_license_no = ?, pan_no = ?, primary_contact_no = ?, alternate_contact_no = ?, "
			+ "email_id_accounting = ?, email_id_transaction = ?, ui_status = 'New', remarks = ?, "
			+ "updated_date = " + com.mmm.authentication.UserSessionSupport.sessionDate() + " "
			+ "where rtrim(cast(cust_code as varchar(30))) = ?";
	}
	private static String insertHeaderSql() {
		return "insert into Kyc_header "
			+ "(created_date, cust_code, name_of_proprietor, business_address, billing_address, "
			+ "gst_no, drug_license_no, pan_no, primary_contact_no, alternate_contact_no, "
			+ "email_id_accounting, email_id_transaction, ui_status, remarks) "
			+ "values (" + com.mmm.authentication.UserSessionSupport.sessionDate() + ", ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'New', ?)";
	}
	private static final String UPDATE_ROW_SQL = "update Kyc_group set shipto_address = ?, gst_no = ?, "
			+ "phone_no = ?, email_id = ?, pan_no = ?, contact_person = ?, shipto_remarks = ? "
			+ "where rtrim(cast(cust_code as varchar(30))) = ? "
			+ "and rtrim(cast(shipto_code as varchar(30))) = ?";
	private static final String INSERT_ROW_SQL = "insert into Kyc_group "
			+ "(cust_code, shipto_code, shipto_address, gst_no, phone_no, email_id, pan_no, contact_person, shipto_remarks) "
			+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String[] HEADER_FIELDS = {
			"proprietorName", "businessAddress", "billingAddress", "gstNo", "panNo",
			"primaryContact", "alternateContact", "emailAccounting", "emailTransaction",
			"remarks", "drugLicenseNo"
	};
	private static final String[] ROW_FIELDS = {
			"shipToCode", "shipToAddress", "gstNo", "phoneNo", "emailId", "panNo", "contactPerson", "remarks"
	};
	private static final Pattern GST = Pattern.compile("^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$");
	private static final Pattern PAN = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
	private static final Pattern PHONE = Pattern.compile("^[6-9][0-9]{9}$");

	private final HibernateFactoryRegistry hibernateRegistry;
	private final Gson gson = new Gson();
	private final Map<String, Map<String, Object>> dummySaved = new ConcurrentHashMap<>();

	public KnowYourCustomer(HibernateFactoryRegistry hibernateRegistry) {
		this.hibernateRegistry = hibernateRegistry;
	}

	@GetMapping
	public String get(
			HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam(value = "dummy", defaultValue = "false") boolean dummy) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}
		try {
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(httpSession, custCode, loginId);
			String code = context.custCode();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}
			Map<String, Object> data = dummy
					? copyOf(dummySaved.getOrDefault(code, dummy(code)))
					: loadInfoapps(code);
			data.put("custCode", code);
			data.put("loginId", context.loginId());
			data.put("source", dummy ? "dummy" : "infoapps");
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to load KYC for customer", ex);
			result.SetError(-1, "failure", "Unable to load customer KYC details");
		}
		return gson.toJson(result);
	}

	@PostMapping(consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE, MediaType.ALL_VALUE })
	public String save(HttpServletRequest request, @RequestBody(required = false) String body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession httpSession = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(httpSession)) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
					UserSessionSupport.SESSION_EXPIRED_MESSAGE);
			return gson.toJson(result);
		}
		String json = body == null ? "" : body.trim();
		if (!json.startsWith("{")) {
			result.SetError(-1, "failure", "Update payload must be a JSON object");
			return gson.toJson(result);
		}
		try {
			Map<String, Object> posted = gson.fromJson(json, new TypeToken<Map<String, Object>>() { }.getType());
			if (posted == null) {
				result.SetError(-1, "failure", "Update payload must be a JSON object");
				return gson.toJson(result);
			}
			UserSessionSupport.ProcedureCustomerContext context =
					UserSessionSupport.resolveProcedureCustomerContext(
							httpSession, text(posted.get("custCode")), text(posted.get("loginId")));
			String code = context.custCode();
			if (code.isEmpty()) {
				result.SetError(-1, "failure", "custCode is required");
				return gson.toJson(result);
			}
			boolean dummy = Boolean.parseBoolean(text(posted.get("dummy")));
			Map<String, Object> record = new LinkedHashMap<>();
			record.put("custCode", code);
			for (String field : HEADER_FIELDS) {
				record.put(field, text(posted.get(field)));
			}
			record.put("gstNo", upper(text(record.get("gstNo"))));
			record.put("panNo", upper(text(record.get("panNo"))));
			List<Map<String, Object>> shipRows = rows(posted.get("rows"));
			String invalid = invalidTaxOrPhone(record, shipRows);
			if (!invalid.isEmpty()) {
				result.SetError(-1, "failure", invalid);
				return gson.toJson(result);
			}
			record.put("rows", shipRows);
			record.put("status", "New");
			record.put("approvalRemarks", "");
			record.put("source", dummy ? "dummy" : "infoapps");
			if (dummy) {
				dummySaved.put(code, record);
			} else {
				saveInfoapps(record);
			}
			result.SetSuccess("success", copyOf(record));
		} catch (IllegalArgumentException ex) {
			result.SetError(-1, "failure", ex.getMessage());
		} catch (Exception ex) {
			logger.error("Unable to save KYC details", ex);
			result.SetError(-1, "failure", "Unable to update customer KYC details");
		}
		return gson.toJson(result);
	}

	private Map<String, Object> loadInfoapps(String custCode) {
		List<Map<String, Object>> headerRows = queryInfoapps("KYC header/customer query", HEADER_SQL, custCode);
		if (headerRows.isEmpty()) {
			throw new IllegalArgumentException("Customer was not found in SO_CustomerMaster");
		}
		Map<String, Object> data = new LinkedHashMap<>();
		Map<String, Object> header = headerRows.get(0);
		for (String field : HEADER_FIELDS) {
			data.put(field, text(cell(header, field)));
		}
		data.put("custCode", custCode);
		data.put("status", defaultText(cell(header, "status"), "New"));
		data.put("approvalRemarks", text(cell(header, "approvalRemarks")));
		List<Map<String, Object>> shipRows = queryInfoapps("KYC saved ship-to query", KYC_ROWS_SQL, custCode);
		if (shipRows.isEmpty()) {
			shipRows = queryInfoapps("KYC master ship-to fallback query", MASTER_ROWS_SQL, custCode);
		}
		data.put("rows", mapRows(shipRows));
		data.put("source", "infoapps");
		return data;
	}

	private List<Map<String, Object>> queryInfoapps(String label, String sql, Object... parameters) {
		logSql(label, sql, parameters);
		return NativeQuerySupport.executeQuery(
				hibernateRegistry, HibernateFactoryRegistry.INFOAPPS, sql, parameters);
	}

	private void saveInfoapps(Map<String, Object> record) {
		String custCode = text(record.get("custCode"));
		List<Map<String, Object>> shipRows = rows(record.get("rows"));
		Set<String> shipCodes = new HashSet<>();
		for (Map<String, Object> row : shipRows) {
			String shipCode = text(row.get("shipToCode"));
			if (shipCode.isEmpty()) {
				throw new IllegalArgumentException("Ship-to code is required for each populated ship-to row.");
			}
			if (!shipCodes.add(shipCode)) {
				throw new IllegalArgumentException("Duplicate ship-to code: " + shipCode);
			}
		}

		hibernateRegistry.withSession(HibernateFactoryRegistry.INFOAPPS, session -> {
			Transaction transaction = session.beginTransaction();
			try {
				int updated = executeUpdateInSession(session, "KYC header update", updateHeaderSql(),
						text(record.get("proprietorName")),
						text(record.get("businessAddress")),
						text(record.get("billingAddress")),
						text(record.get("gstNo")),
						text(record.get("drugLicenseNo")),
						text(record.get("panNo")),
						text(record.get("primaryContact")),
						text(record.get("alternateContact")),
						text(record.get("emailAccounting")),
						text(record.get("emailTransaction")),
						text(record.get("remarks")),
						custCode);
				if (updated == 0) {
					executeUpdateInSession(session, "KYC header insert", insertHeaderSql(),
							custCode,
							text(record.get("proprietorName")),
							text(record.get("businessAddress")),
							text(record.get("billingAddress")),
							text(record.get("gstNo")),
							text(record.get("drugLicenseNo")),
							text(record.get("panNo")),
							text(record.get("primaryContact")),
							text(record.get("alternateContact")),
							text(record.get("emailAccounting")),
							text(record.get("emailTransaction")),
							text(record.get("remarks")));
				}
				for (Map<String, Object> row : shipRows) {
					int rowUpdated = executeUpdateInSession(session, "KYC ship-to update", UPDATE_ROW_SQL,
							text(row.get("shipToAddress")),
							text(row.get("gstNo")),
							text(row.get("phoneNo")),
							text(row.get("emailId")),
							text(row.get("panNo")),
							text(row.get("contactPerson")),
							text(row.get("remarks")),
							custCode,
							text(row.get("shipToCode")));
					if (rowUpdated == 0) {
						executeUpdateInSession(session, "KYC ship-to insert", INSERT_ROW_SQL,
								custCode,
								text(row.get("shipToCode")),
								text(row.get("shipToAddress")),
								text(row.get("gstNo")),
								text(row.get("phoneNo")),
								text(row.get("emailId")),
								text(row.get("panNo")),
								text(row.get("contactPerson")),
								text(row.get("remarks")));
					}
				}
				transaction.commit();
				return null;
			} catch (RuntimeException ex) {
				if (transaction.isActive()) {
					transaction.rollback();
				}
				throw ex;
			}
		});
	}

	private static int executeUpdateInSession(Session session, String label, String sql, Object... parameters) {
		logSql(label, sql, parameters);
		return NativeQuerySupport.executeUpdateInSession(session, sql, parameters);
	}

	private static void logSql(String label, String sql, Object... parameters) {
		logger.info("{}:\n{}", label, sqlWithValues(label, sql, parameters));
	}

	private static String sqlWithValues(String label, String sql, Object[] parameters) {
		StringBuilder rendered = new StringBuilder();
		int parameterIndex = 0;
		boolean inString = false;
		for (int i = 0; i < sql.length(); i++) {
			char ch = sql.charAt(i);
			if (ch == '\'' && inString && i + 1 < sql.length() && sql.charAt(i + 1) == '\'') {
				rendered.append("''");
				i++;
			} else if (ch == '\'') {
				inString = !inString;
				rendered.append(ch);
			} else if (ch == '?' && !inString && parameterIndex < parameters.length) {
				Object value = parameters[parameterIndex++];
				if (value == null) {
					rendered.append("null");
				} else if (value instanceof Number) {
					rendered.append(value);
				} else {
					rendered.append("N'")
							.append(String.valueOf(value).replace("\r", " ").replace("\n", " ").replace("'", "''"))
							.append("'");
				}
			} else {
				rendered.append(ch);
			}
		}
		if (parameterIndex != parameters.length) {
			logger.warn("{} SQL has {} unrendered bound parameter(s)", label, parameters.length - parameterIndex);
		}
		return rendered.toString();
	}

	private static List<Map<String, Object>> mapRows(List<Map<String, Object>> sourceRows) {
		List<Map<String, Object>> mapped = new ArrayList<>();
		for (Map<String, Object> source : sourceRows) {
			Map<String, Object> row = new LinkedHashMap<>();
			for (String field : ROW_FIELDS) {
				row.put(field, text(cell(source, field)));
			}
			mapped.add(row);
		}
		return mapped;
	}

	private static Object cell(Map<String, Object> row, String name) {
		if (row.containsKey(name)) {
			return row.get(name);
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(name)) {
				return entry.getValue();
			}
		}
		return null;
	}

	private static String text(Object value) {
		return value == null ? "" : String.valueOf(value).trim();
	}

	private static String defaultText(Object value, String fallback) {
		String result = text(value);
		return result.isEmpty() ? fallback : result;
	}

	private static String upper(String value) {
		return value.toUpperCase(Locale.ROOT);
	}

	private static String phoneDigits(String raw) {
		String digits = raw.replaceAll("[\\s\\-()]", "");
		if (digits.startsWith("+91")) {
			digits = digits.substring(3);
		} else if (digits.startsWith("91") && digits.length() == 12) {
			digits = digits.substring(2);
		} else if (digits.startsWith("0") && digits.length() == 11) {
			digits = digits.substring(1);
		}
		return digits;
	}

	private static String invalidTaxOrPhone(Map<String, Object> record, List<Map<String, Object>> shipRows) {
		String gst = text(record.get("gstNo"));
		String pan = text(record.get("panNo"));
		String primary = text(record.get("primaryContact"));
		String alternate = text(record.get("alternateContact"));
		if (gst.isEmpty()) {
			return "GST No is required.";
		}
		if (!GST.matcher(gst).matches()) {
			return "Enter a 15-character GST number.";
		}
		if (pan.isEmpty()) {
			return "PAN No is required.";
		}
		if (!PAN.matcher(pan).matches()) {
			return "Enter a 10-character PAN.";
		}
		if (!gst.substring(2, 12).equals(pan)) {
			return "GST number does not match the PAN.";
		}
		if (primary.isEmpty() || !PHONE.matcher(phoneDigits(primary)).matches()) {
			return "Enter a 10-digit primary mobile number.";
		}
		if (!alternate.isEmpty() && !PHONE.matcher(phoneDigits(alternate)).matches()) {
			return "Enter a 10-digit alternate mobile number, or leave it blank.";
		}
		record.put("primaryContact", phoneDigits(primary));
		if (!alternate.isEmpty()) {
			record.put("alternateContact", phoneDigits(alternate));
		}
		Set<String> shipCodes = new HashSet<>();
		for (int i = 0; i < shipRows.size(); i++) {
			Map<String, Object> row = shipRows.get(i);
			String shipCode = text(row.get("shipToCode"));
			String rowGst = upper(text(row.get("gstNo")));
			String rowPan = upper(text(row.get("panNo")));
			String rowPhone = text(row.get("phoneNo"));
			row.put("gstNo", rowGst);
			row.put("panNo", rowPan);
			int rowNo = i + 1;
			if (shipCode.isEmpty()) {
				return "Ship-to row " + rowNo + ": ship-to code is required.";
			}
			if (!shipCodes.add(shipCode)) {
				return "Ship-to row " + rowNo + ": duplicate ship-to code.";
			}
			if (!rowGst.isEmpty() && !GST.matcher(rowGst).matches()) {
				return "Ship-to row " + rowNo + ": enter a 15-character GST number.";
			}
			if (!rowPan.isEmpty() && !PAN.matcher(rowPan).matches()) {
				return "Ship-to row " + rowNo + ": enter a 10-character PAN.";
			}
			if (!rowGst.isEmpty() && !rowPan.isEmpty() && !rowGst.substring(2, 12).equals(rowPan)) {
				return "Ship-to row " + rowNo + ": GST number does not match the PAN.";
			}
			if (!rowPhone.isEmpty() && !PHONE.matcher(phoneDigits(rowPhone)).matches()) {
				return "Ship-to row " + rowNo + ": enter a 10-digit mobile number.";
			}
			if (!rowPhone.isEmpty()) {
				row.put("phoneNo", phoneDigits(rowPhone));
			}
		}
		return "";
	}

	private static List<Map<String, Object>> rows(Object raw) {
		List<Map<String, Object>> out = new ArrayList<>();
		if (!(raw instanceof List<?> list)) {
			return out;
		}
		for (Object item : list) {
			if (!(item instanceof Map<?, ?> map)) {
				continue;
			}
			Map<String, Object> row = new LinkedHashMap<>();
			boolean any = false;
			for (String field : ROW_FIELDS) {
				String value = text(map.get(field));
				row.put(field, value);
				if (!value.isEmpty()) {
					any = true;
				}
			}
			if (any) {
				out.add(row);
			}
		}
		return out;
	}

	private static Map<String, Object> dummy(String custCode) {
		Map<String, Object> data = new LinkedHashMap<>();
		data.put("custCode", custCode);
		data.put("proprietorName", "DIRT BLASTERS");
		data.put("businessAddress", "#37, JAGANATH ARCADE, GROUND AND 1ST FLOOR, SBM COLONY, 50 FEET ROAD, ANAND NAGAR, 560024");
		data.put("billingAddress", "#37, JAGANATH ARCADE, GROUND AND 1ST FLOOR, SBM COLONY, 50 FEET ROAD, ANAND NAGAR, 560024");
		data.put("gstNo", "");
		data.put("panNo", "");
		data.put("primaryContact", "");
		data.put("alternateContact", "");
		data.put("emailAccounting", "");
		data.put("emailTransaction", "");
		data.put("remarks", "");
		data.put("drugLicenseNo", "");
		data.put("status", "New");
		data.put("source", "dummy");
		List<Map<String, Object>> rows = new ArrayList<>();
		rows.add(ship("6", "#37, JAGANATH ARCADE", "", "", "", "", "DIRT BLASTERS", ""));
		rows.add(ship("5", "B-105, GAGAN DARS", "", "", "", "", "DIRT BLASTERS", ""));
		rows.add(ship("2", "3M CAR CARE #5 80F", "", "", "", "", "DIRT BLASTERS", ""));
		rows.add(ship("1", "Ground Floor, Narayan", "", "9886590541", "", "", "", ""));
		rows.add(ship("3", "#5, 80 FT ROAD NEAR", "", "", "", "", "Amit Shah", ""));
		data.put("rows", rows);
		return data;
	}

	private static Map<String, Object> ship(
			String code, String address, String gst, String phone, String email, String pan, String person, String remarks) {
		Map<String, Object> row = new LinkedHashMap<>();
		row.put("shipToCode", code);
		row.put("shipToAddress", address);
		row.put("gstNo", gst);
		row.put("phoneNo", phone);
		row.put("emailId", email);
		row.put("panNo", pan);
		row.put("contactPerson", person);
		row.put("remarks", remarks);
		return row;
	}

	private static Map<String, Object> copyOf(Map<String, Object> source) {
		Map<String, Object> copy = new LinkedHashMap<>();
		for (String field : HEADER_FIELDS) {
			copy.put(field, text(source.get(field)));
		}
		copy.put("custCode", text(source.get("custCode")));
		copy.put("status", text(source.get("status")));
		copy.put("approvalRemarks", text(source.get("approvalRemarks")));
		copy.put("source", text(source.get("source")));
		copy.put("rows", rows(source.get("rows")));
		return copy;
	}
}
