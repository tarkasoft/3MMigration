package com.mmm.shipanddebit;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.share.DiskShare;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Supporting documents are uploaded after the claim has been saved.
 * The folder comes from the CLAIMDOC row of CMW010S. The browser never sees the share.
 */
@RestController
@RequestMapping("/api/customer/ship-and-debit/documents")
public class ShipAndDebitDocUpload {

	private static final Logger logger = LoggerFactory.getLogger(ShipAndDebitDocUpload.class);
	private static final long MAX_TOTAL_BYTES = (long) (4.5 * 1024 * 1024);
	private static final long MAX_FILE_BYTES = MAX_TOTAL_BYTES;
	private static final String CLAIMDOC = "CLAIMDOC";
	private static final SMB2Dialect SMB3 = SMB2Dialect.SMB_3_1_1;
	private static final int SMB_WRITE_BUFFER_BYTES = 1024 * 1024;
	private static final Set<String> ALLOWED_EXTENSIONS = Set.of(
			"zip", "7z", "jpeg", "jpg", "png", "gif", "pdf", "tiff", "tif",
			"bmp", "bpg", "fax", "img");

	private final ShipAndDebitSql sql;
	private final Gson gson = new Gson();

	public ShipAndDebitDocUpload(HibernateFactoryRegistry registry,
			@Value("${inpc.ship-and-debit.as400:as400ind}") String as400,
			@Value("${inpc.ship-and-debit.app-code:CCM}") String appCode,
			@Value("${inpc.ship-and-debit.claim-list-app-code:INPC}") String claimListAppCode) {
		this.sql = new ShipAndDebitSql(registry, as400, appCode, claimListAppCode);
	}

	@GetMapping("/list")
	public String list(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("claimNumber") String claimNumber) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			requireAccepted(request, context.loginId());
			String claim = safeClaim(claimNumber);
			requireClaim(context.loginId(), claim);
			result.SetSuccess("success", listFiles(context.loginId(), claim));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	@PostMapping
	public String upload(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("claimNumber") String claimNumber,
			@RequestParam(value = "files", required = false) List<MultipartFile> files,
			@RequestParam(value = "file", required = false) MultipartFile singleFile) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		logger.info("Claim document request received: contentLength={} bytes",
				request.getContentLengthLong());
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			requireAccepted(request, context.loginId());
			String claim = safeClaim(claimNumber);
			requireClaim(context.loginId(), claim);
			List<MultipartFile> uploads = uploads(files, singleFile);
			if (uploads.isEmpty()) {
				throw new IllegalArgumentException("Choose a file.");
			}
			long batchBytes = uploads.stream().mapToLong(MultipartFile::getSize).sum();
			logger.info("Claim document upload batch received: claim={} files={} payloadBytes={}",
					claim, uploads.size(), batchBytes);
			List<String> storedNames = storeDocuments(context.loginId(), claim, uploads);
			result.SetSuccess("success", Map.of("files", storedNames, "message", "Documents stored."));
		} catch (Exception ex) {
			if (ex instanceof IllegalArgumentException || ex instanceof IllegalStateException) {
				logger.warn("Claim document request rejected: contentLength={} bytes reason={}",
						request.getContentLengthLong(), ex.getMessage());
			}
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	@PostMapping("/delete")
	public String delete(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("claimNumber") String claimNumber,
			@RequestParam("name") String name) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			requireAccepted(request, context.loginId());
			String claim = safeClaim(claimNumber);
			requireClaim(context.loginId(), claim);
			String storedName = safeFileName(name);
			deleteDocument(context.loginId(), claim, storedName);
			result.SetSuccess("success", Map.of("name", storedName, "message", "Document deleted."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	List<String> storeDocuments(String loginId, String claimNumber, List<MultipartFile> files) throws Exception {
		if (files == null || files.isEmpty()) {
			return List.of();
		}
		long uploadStarted = System.nanoTime();
		String claim = safeClaim(claimNumber);
		validateUploads(files);
		List<String> storedNames = new ArrayList<>();
		long shareLookupStarted = System.nanoTime();
		Share share = share(loginId);
		logger.info("Claim document upload share lookup completed in {} ms",
				elapsedMillis(shareLookupStarted));
		SMBClient client = new SMBClient(smbConfig());
		try {
			long connectStarted = System.nanoTime();
			Connection connection = client.connect(share.host());
			logger.info("Claim document upload SMB connect completed in {} ms", elapsedMillis(connectStarted));
			try (connection) {
				long authenticateStarted = System.nanoTime();
				var session = connection.authenticate(new AuthenticationContext(
						share.username(), share.password().toCharArray(), "MMM"));
				logger.info("Claim document upload SMB authentication completed in {} ms",
						elapsedMillis(authenticateStarted));
				try {
					long connectShareStarted = System.nanoTime();
					DiskShare disk = (DiskShare) session.connectShare(share.share());
					logger.info("Claim document upload share connection completed in {} ms",
							elapsedMillis(connectShareStarted));
					try (disk) {
						long folderStarted = System.nanoTime();
						String claimFolder = remote(share, claim);
						if (!disk.folderExists(claimFolder)) {
							disk.mkdir(claimFolder);
						}
						logger.info("Claim document upload folder check completed in {} ms",
								elapsedMillis(folderStarted));
						int documentNumber = 0;
						for (MultipartFile file : files) {
							int currentDocument = ++documentNumber;
							String originalName = safeFileName(file.getOriginalFilename());
							Instant fileStartedAt = Instant.now();
							long fileStarted = System.nanoTime();
							logger.info("Claim document upload started: claim={} file={}/{} name={} sizeBytes={} startedAt={}",
									claim, currentDocument, files.size(), originalName, file.getSize(), fileStartedAt);
							try {
								String storedName = putWithUniqueName(disk, claimFolder, file);
								storedNames.add(storedName);
								logger.info("Claim document upload completed: claim={} file={}/{} name={} storedName={} sizeBytes={} startedAt={} finishedAt={} elapsedMs={}",
										claim, currentDocument, files.size(), originalName, storedName, file.getSize(),
										fileStartedAt, Instant.now(), elapsedMillis(fileStarted));
							} catch (Exception ex) {
								logger.error("Claim document upload failed: claim={} file={}/{} name={} sizeBytes={} startedAt={} elapsedMs={}",
										claim, currentDocument, files.size(), originalName, file.getSize(),
										fileStartedAt, elapsedMillis(fileStarted), ex);
								throw ex;
							}
						}
						logger.info("Claim document upload batch ({} files) completed in {} ms",
								files.size(), elapsedMillis(uploadStarted));
					}
				} finally {
					session.close();
				}
			}
		} finally {
			client.close();
		}
		return storedNames;
	}

	@GetMapping
	public ResponseEntity<byte[]> download(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("claimNumber") String claimNumber,
			@RequestParam("name") String name) {
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			requireAccepted(request, context.loginId());
			String claim = safeClaim(claimNumber);
			requireClaim(context.loginId(), claim);
			String storedName = safeFileName(name);
			byte[] body = get(context.loginId(), claim, storedName);
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(storedName).build().toString())
					.contentType(MediaType.APPLICATION_OCTET_STREAM)
					.body(body);
		} catch (Exception ex) {
			logger.warn("Claim document download failed: {}", ex.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	private java.util.List<String> listFiles(String loginId, String claimNumber) throws Exception {
		long listStarted = System.nanoTime();
		logger.info("Claim document listing started for claim {}", claimNumber);
		long shareLookupStarted = System.nanoTime();
		Share share = share(loginId);
		logger.info("Claim document listing share lookup completed in {} ms", elapsedMillis(shareLookupStarted));
		java.util.List<String> names = new java.util.ArrayList<>();
		SMBClient client = new SMBClient(smbConfig());
		long connectStarted = System.nanoTime();
		try (Connection connection = client.connect(share.host())) {
			logger.info("Claim document listing SMB connect completed in {} ms", elapsedMillis(connectStarted));
			long authenticateStarted = System.nanoTime();
			var session = connection.authenticate(new AuthenticationContext(
					share.username(), share.password().toCharArray(), "MMM"));
			logger.info("Claim document listing SMB authentication completed in {} ms",
					elapsedMillis(authenticateStarted));
			long shareConnectStarted = System.nanoTime();
			logger.info("Claim document listing connecting to share {}", share.share());
			try (DiskShare disk = (DiskShare) session.connectShare(share.share())) {
				logger.info("Claim document listing share connection completed in {} ms",
						elapsedMillis(shareConnectStarted));
				String folder = share.folder();
				long rootListStarted = System.nanoTime();
				logger.info("Claim document listing root files matching claim {}_", claimNumber);
				addNames(disk, folder, claimNumber + "_", names);
				logger.info("Claim document root listing completed in {} ms; {} matching document(s)",
						elapsedMillis(rootListStarted), names.size());
				String claimFolder = folder.isEmpty() ? claimNumber : folder + "/" + claimNumber;
				long claimFolderCheckStarted = System.nanoTime();
				boolean claimFolderExists = disk.folderExists(claimFolder);
				logger.info("Claim document folder check completed in {} ms; exists={}",
						elapsedMillis(claimFolderCheckStarted), claimFolderExists);
				if (claimFolderExists) {
					int beforeClaimFolder = names.size();
					long claimFolderListStarted = System.nanoTime();
					logger.info("Claim document listing files in claim folder {}", claimNumber);
					addNames(disk, claimFolder, "", names);
					logger.info("Claim document folder listing completed in {} ms; {} document(s)",
							elapsedMillis(claimFolderListStarted), names.size() - beforeClaimFolder);
				}
			} finally {
				session.close();
			}
		} finally {
			client.close();
		}
		logger.info("Claim document listing for claim {} returned {} document(s) in {} ms",
				claimNumber, names.size(), elapsedMillis(listStarted));
		return names;
	}

	private static void addNames(DiskShare disk, String folder, String prefix, java.util.List<String> names) {
		String path = folder == null || folder.isEmpty() ? "" : folder;
		String searchPattern = prefix.isEmpty() ? "*" : prefix + "*";
		for (var info : disk.list(path, searchPattern)) {
			String name = info.getFileName();
			if (".".equals(name) || "..".equals(name)) {
				continue;
			}
			if (!prefix.isEmpty() && !name.startsWith(prefix)) {
				continue;
			}
			names.add(name);
			logger.info("Claim document listing found document {}", names.size());
		}
	}

	private static void put(DiskShare disk, String claimFolder, String storedName, MultipartFile file) throws Exception {
		try (
			com.hierynomus.smbj.share.File target = disk.openFile(
					claimFolder + "/" + storedName,
					EnumSet.of(AccessMask.GENERIC_WRITE), null, SMB2ShareAccess.ALL,
					SMB2CreateDisposition.FILE_CREATE, null);
			InputStream input = file.getInputStream();
			OutputStream output = new BufferedOutputStream(
					target.getOutputStream(), SMB_WRITE_BUFFER_BYTES)) {
			input.transferTo(output);
		}
	}

	private static String putWithUniqueName(DiskShare disk, String claimFolder, MultipartFile file) throws Exception {
		for (int attempt = 0; attempt < 900; attempt++) {
			String storedName = withRandomSuffix(file.getOriginalFilename());
			if (disk.fileExists(claimFolder + "/" + storedName)) {
				continue;
			}
			put(disk, claimFolder, storedName, file);
			return storedName;
		}
		throw new IllegalStateException("Unable to generate a unique name for the uploaded document.");
	}

	private static String withRandomSuffix(String originalName) {
		String safeName = safeFileName(originalName);
		int extensionStart = safeName.lastIndexOf('.');
		String extension = extensionStart > 0 ? safeName.substring(extensionStart) : "";
		String baseName = extensionStart > 0 ? safeName.substring(0, extensionStart) : safeName;
		String suffix = "_" + ThreadLocalRandom.current().nextInt(100, 1000);
		int maxBaseLength = 120 - suffix.length() - extension.length();
		if (baseName.length() > maxBaseLength) {
			baseName = baseName.substring(0, maxBaseLength);
		}
		return baseName + suffix + extension;
	}

	private void deleteDocument(String loginId, String claimNumber, String storedName) throws Exception {
		Share share = share(loginId);
		SMBClient client = new SMBClient(smbConfig());
		try (Connection connection = client.connect(share.host())) {
			var session = connection.authenticate(new AuthenticationContext(
					share.username(), share.password().toCharArray(), "MMM"));
			try (DiskShare disk = (DiskShare) session.connectShare(share.share())) {
				String claimFolder = remote(share, claimNumber);
				String filePath = claimFolder + "/" + storedName;
				if (!disk.fileExists(filePath)) {
					if (!storedName.startsWith(claimNumber + "_")
							|| !disk.fileExists(remote(share, storedName))) {
						throw new IllegalArgumentException("Document was not found for this claim.");
					}
					filePath = remote(share, storedName);
				}
				disk.rm(filePath);
				logger.info("Deleted claim document claim={} name={}", claimNumber, storedName);
			} finally {
				session.close();
			}
		} finally {
			client.close();
		}
	}

	private static long elapsedMillis(long startedNanos) {
		return java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedNanos);
	}

	private byte[] get(String loginId, String claimNumber, String storedName) throws Exception {
		long downloadStarted = System.nanoTime();
		logger.info("Claim document download started for claim {}", claimNumber);
		long shareLookupStarted = System.nanoTime();
		Share share = share(loginId);
		logger.info("Claim document download share lookup completed in {} ms", elapsedMillis(shareLookupStarted));
		SMBClient client = new SMBClient(smbConfig());
		long connectStarted = System.nanoTime();
		try (Connection connection = client.connect(share.host())) {
			logger.info("Claim document download SMB connect completed in {} ms", elapsedMillis(connectStarted));
			long authenticateStarted = System.nanoTime();
			var session = connection.authenticate(new AuthenticationContext(
					share.username(), share.password().toCharArray(), "MMM"));
			logger.info("Claim document download SMB authentication completed in {} ms",
					elapsedMillis(authenticateStarted));
			long shareConnectStarted = System.nanoTime();
			try (DiskShare disk = (DiskShare) session.connectShare(share.share())) {
				logger.info("Claim document download share connection completed in {} ms",
						elapsedMillis(shareConnectStarted));
				String claimFolder = remote(share, claimNumber);
				String filePath = claimFolder + "/" + storedName;
				long fileCheckStarted = System.nanoTime();
				if (!disk.fileExists(filePath)) {
					if (!storedName.startsWith(claimNumber + "_") || !disk.fileExists(remote(share, storedName))) {
						throw new IllegalArgumentException("Document was not found for this claim.");
					}
					filePath = remote(share, storedName);
				}
				logger.info("Claim document download file lookup completed in {} ms",
						elapsedMillis(fileCheckStarted));
				long readStarted = System.nanoTime();
				try (
					com.hierynomus.smbj.share.File source = disk.openFile(
							filePath,
							EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL,
							SMB2CreateDisposition.FILE_OPEN, null);
					InputStream input = source.getInputStream();
					java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream()) {
					input.transferTo(output);
					logger.info("Claim document download read {} bytes in {} ms; total {} ms",
							output.size(), elapsedMillis(readStarted), elapsedMillis(downloadStarted));
					return output.toByteArray();
				}
			} finally {
				session.close();
			}
		} finally {
			client.close();
		}
	}

	private static SmbConfig smbConfig() {
		return SmbConfig.builder()
				.withDialects(SMB3)
				.withEncryptData(true)
				.withNegotiatedBufferSize()
				.build();
	}

	private Share share(String loginId) {
		for (Map<String, Object> row : sql.shareRows(loginId)) {
			if (!CLAIMDOC.equalsIgnoreCase(text(cell(row, "NWCODE")))) {
				continue;
			}
			String raw = text(cell(row, "NWPATH")).replace('\\', '/');
			raw = raw.replaceFirst("(?i)^smb:", "").replaceFirst("^/+", "");
			while (raw.endsWith("/")) {
				raw = raw.substring(0, raw.length() - 1);
			}
			String[] parts = raw.split("/", 3);
			String username = text(cell(row, "NWLID"));
			String password = text(cell(row, "NWPWD"));
			if (parts.length < 2 || username.isEmpty() || password.isEmpty()) {
				continue;
			}
			String host = parts[0];
			int port = host.indexOf(':');
			if (port > 0) {
				host = host.substring(0, port);
			}
			String folder = parts.length > 2 ? parts[2] : "";
			logger.info("CLAIMDOC share host={} share={}", host, parts[1]);
			return new Share(host, parts[1], folder, username, password);
		}
		throw new IllegalStateException("CLAIMDOC share was not returned by CMW010S.");
	}

	private void requireAccepted(HttpServletRequest request, String loginId) {
		ShipAndDebitTerms.requireAccepted(request.getSession(false), loginId);
	}

	private void requireClaim(String loginId, String claimNumber) {
		if (sql.claim(loginId, claimNumber).isEmpty()) {
			throw new IllegalArgumentException("Claim was not found for the current user.");
		}
	}

	private static String remote(Share share, String name) {
		return share.folder().isEmpty() ? name : share.folder() + "/" + name;
	}

	private static String safeClaim(String value) {
		String claim = text(value);
		if (!claim.matches("[A-Za-z0-9._-]{1,40}")) {
			throw new IllegalArgumentException("Claim number is invalid.");
		}
		return claim;
	}

	private static String safeFileName(String value) {
		String name = text(value);
		int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
		if (slash >= 0) {
			name = name.substring(slash + 1);
		}
		name = name.replaceAll("[^A-Za-z0-9._-]", "_");
		if (name.isEmpty() || name.length() > 120 || name.contains("..")) {
			throw new IllegalArgumentException("File name is invalid.");
		}
		return name;
	}

	private static List<MultipartFile> uploads(List<MultipartFile> files, MultipartFile singleFile) {
		List<MultipartFile> uploads = new ArrayList<>();
		if (files != null) {
			uploads.addAll(files);
		}
		if (singleFile != null && !singleFile.isEmpty()) {
			uploads.add(singleFile);
		}
		return uploads;
	}

	static void validateUploads(List<MultipartFile> files) {
		long totalBytes = 0;
		for (MultipartFile file : files) {
			if (file.isEmpty()) {
				throw new IllegalArgumentException("A selected document is empty.");
			}
			String name = safeFileName(file.getOriginalFilename());
			int dot = name.lastIndexOf('.');
			String extension = dot < 0 ? "" : name.substring(dot + 1).toLowerCase(java.util.Locale.ROOT);
			if (!ALLOWED_EXTENSIONS.contains(extension)) {
				throw new IllegalArgumentException("Only image, PDF, ZIP, or 7Z documents are allowed.");
			}
			if (file.getSize() > MAX_FILE_BYTES) {
				throw new IllegalArgumentException(
						"Each document must be 4.5 MB or smaller to fit within the 5 MB request limit.");
			}
			totalBytes += file.getSize();
			if (totalBytes > MAX_TOTAL_BYTES) {
				throw new IllegalArgumentException(
						"Each upload batch must not exceed 4.5 MB to fit within the 5 MB request limit.");
			}
		}
	}

	private static Object cell(Map<String, Object> row, String name) {
		if (row.containsKey(name)) {
			return row.get(name);
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (name.equalsIgnoreCase(entry.getKey())) {
				return entry.getValue();
			}
		}
		return null;
	}

	private UserSessionSupport.ProcedureCustomerContext customer(
			HttpServletRequest request, String custCode, String loginId) {
		var session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		return UserSessionSupport.resolveProcedureCustomerContext(session, firstParam(custCode), firstParam(loginId));
	}

	private static String firstParam(String value) {
		if (value == null) {
			return null;
		}
		int comma = value.indexOf(',');
		return (comma < 0 ? value : value.substring(0, comma)).trim();
	}

	private String error(ResponseDataGeneric result, Exception ex) {
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure", ex.getMessage());
		} else {
			if (!(ex instanceof IllegalArgumentException || ex instanceof IllegalStateException)) {
				logger.error("Claim document failed", ex);
			}
			result.SetError(-1, "failure",
					ex instanceof IllegalArgumentException || ex instanceof IllegalStateException
							? ex.getMessage() : "Unable to store the claim document.");
		}
		return gson.toJson(result);
	}

	private record Share(String host, String share, String folder, String username, String password) {}
}
