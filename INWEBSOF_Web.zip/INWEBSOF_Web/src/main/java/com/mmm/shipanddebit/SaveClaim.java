package com.mmm.shipanddebit;

import static com.mmm.titpl.CommonFunctions.text;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.sql.SQLException;
import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mmm.titpl.NativeQuerySupport;

/**
 * One transaction: allocate the claim number, then insert each line.
 * The AS/400 procedure writes the claim tables. Java does not split header and detail.
 */
final class SaveClaim {

	private static final String NUMBER_CALL = "{call SFLASH.PMS328S(?,?,?,?)}";
	private static final String INSERT_CALL = "{call SFLASH.PMS334S(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final String UPDATE_CALL = "{call SFLASH.PMS360S(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final List<String> INSERT_PARAMETERS = List.of("appCode", "loginId", "claimNumber", "endCustomer",
			"division", "sku", "description", "invoiceNumber", "invoiceDate", "uom", "availQty", "salesPerson",
			"rcPrice", "distInvoiceNumber", "distInvoiceDate", "distBillQty", "distBillPrice", "claimValue",
			"claimMonth", "comments", "lineComments", "lateRemarks");

	private final ShipAndDebitSql sql;

	SaveClaim(ShipAndDebitSql sql) {
		this.sql = sql;
	}

	Map<String, Object> create(String loginId, String endCustomer, String division, String claimMonth,
			String comments, String lateRemarks, List<Map<String, Object>> lines) {
		if (lines == null || lines.isEmpty()) {
			throw new IllegalArgumentException("Add at least one claim line.");
		}
		if (endCustomer.isBlank() || division.isBlank() || claimMonth.isBlank()) {
			throw new IllegalArgumentException("Division, end customer, and claim month are required.");
		}
		if (comments == null || comments.isBlank()) {
			throw new IllegalArgumentException("Claim comments are required.");
		}
		for (Map<String, Object> line : lines) {
			validateClaimPeriodDates(claimMonth, text(line.get("invoiceDate")), text(line.get("distInvoiceDate")));
		}
		String login = loginId.trim().toUpperCase();
		return sql.registry().withSession(sql.as400(), session -> {
			Transaction transaction = session.beginTransaction();
			try {
				String claimNumber = claimNumber(session, login);
				for (Map<String, Object> line : lines) {
					insertLine(session, login, claimNumber, endCustomer, division, claimMonth, comments, lateRemarks, line);
				}
				transaction.commit();
				Map<String, Object> saved = new LinkedHashMap<>();
				saved.put("claimNumber", claimNumber);
				saved.put("message", "Claim " + claimNumber + " was submitted.");
				return saved;
			} catch (RuntimeException ex) {
				if (transaction.isActive()) {
					transaction.rollback();
				}
				throw ex;
			}
		});
	}

	Map<String, Object> update(String loginId, String claimNumber, String comments, String lateRemarks,
			List<Map<String, Object>> lines) {
		if (claimNumber == null || claimNumber.isBlank()) {
			throw new IllegalArgumentException("Claim number is required.");
		}
		if (lines == null || lines.isEmpty()) {
			throw new IllegalArgumentException("Select at least one line to update or delete.");
		}
		if (comments == null || comments.isBlank()) {
			throw new IllegalArgumentException("Claim comments are required.");
		}
		String login = loginId.trim().toUpperCase();
		String claim = claimNumber.trim();
		String endCustomer = "";
		String division = "";
		String claimMonth = "";
		int insertCount = 0;
		int deleteCount = 0;
		int updateCount = 0;
		for (Map<String, Object> line : lines) {
			String action = text(line.get("action"));
			if ("I".equalsIgnoreCase(action)) {
				insertCount++;
			} else if ("D".equalsIgnoreCase(action)) {
				deleteCount++;
			} else if ("U".equalsIgnoreCase(action)) {
				updateCount++;
			}
		}
		if (insertCount > 0 || updateCount > 0) {
			List<Map<String, Object>> claimRows = sql.claim(login, claim);
			if (claimRows.isEmpty()) {
				throw new IllegalArgumentException("The claim could not be verified for updating lines.");
			}
			if (insertCount > 0 && claimRows.size() - deleteCount + insertCount > 35) {
				throw new IllegalArgumentException("Maximum 35 lines can be added per claim.");
			}
			Map<String, Object> header = claimRows.get(0);
			String returnedClaim = field(header, "CLNO#", 0);
			if (!returnedClaim.isEmpty() && !claim.equals(returnedClaim)) {
				throw new IllegalArgumentException("The claim could not be verified for updating lines.");
			}
			endCustomer = field(header, "ECUST", 4);
			division = field(header, "DIVCOD", 1);
			claimMonth = field(header, "CLMOT", 6);
			if (claimMonth.isEmpty() || (insertCount > 0 && (endCustomer.isEmpty() || division.isEmpty()))) {
				throw new IllegalStateException("The existing claim header is incomplete; the new line was not added.");
			}
		}
		final String claimEndCustomer = endCustomer;
		final String claimDivision = division;
		final String claimMonthValue = claimMonth;
		return sql.registry().withSession(sql.as400(), session -> {
			Transaction transaction = session.beginTransaction();
			try {
				int changed = 0;
				for (Map<String, Object> line : lines) {
					String action = text(line.get("action")).toUpperCase();
					if ("I".equals(action)) {
						validateNewLine(line, claimMonthValue);
						insertLine(session, login, claim, claimEndCustomer, claimDivision, claimMonthValue,
								comments, lateRemarks, line);
						changed++;
						continue;
					}
					if (!"U".equals(action) && !"D".equals(action)) {
						continue;
					}
					if ("U".equals(action)) {
						validateClaimPeriodDates(claimMonthValue,
								text(line.get("invoiceDate")), text(line.get("newDistDate")));
					}
					updateLine(session, login, claim, comments, lateRemarks, action, line);
					changed++;
				}
				if (changed == 0) {
					throw new IllegalArgumentException("Select Update or Delete on a line.");
				}
				transaction.commit();
				Map<String, Object> saved = new LinkedHashMap<>();
				saved.put("claimNumber", claim);
				saved.put("message", "Claim " + claim + " was saved.");
				return saved;
			} catch (RuntimeException ex) {
				if (transaction.isActive()) {
					transaction.rollback();
				}
				throw ex;
			}
		});
	}

	private static String field(Map<String, Object> row, String name, int position) {
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(name)) {
				return text(entry.getValue());
			}
		}
		int index = 0;
		for (Object value : row.values()) {
			if (index++ == position) {
				return text(value);
			}
		}
		return "";
	}

	private static void validateNewLine(Map<String, Object> line, String claimMonth) {
		String[] required = { "sku", "description", "invoiceNumber", "invoiceDate", "uom", "availQty",
			"rcPrice", "distInvoiceNumber", "distInvoiceDate", "distBillQty",
			"distBillPrice", "claimValue" };
		for (String name : required) {
			if (text(line.get(name)).isEmpty()) {
				throw new IllegalArgumentException("Each new claim line needs " + name + ".");
			}
		}
		if (!text(line.get("invoiceDate")).matches("\\d{8}")
				|| !text(line.get("distInvoiceDate")).matches("\\d{8}")) {
			throw new IllegalArgumentException("New claim line invoice dates must use YYYYMMDD.");
		}
		validateClaimPeriodDates(claimMonth, text(line.get("invoiceDate")), text(line.get("distInvoiceDate")));
	}

	static void validateClaimPeriodDates(String claimMonth, String invoiceDate, String distInvoiceDate) {
		if (claimMonth == null || !claimMonth.matches("\\d{6}")) {
			throw new IllegalArgumentException("Claim month must use YYYYMM.");
		}
		try {
			YearMonth selectedMonth = YearMonth.of(
					Integer.parseInt(claimMonth.substring(0, 4)),
					Integer.parseInt(claimMonth.substring(4, 6)));
			LocalDate invoice = LocalDate.parse(invoiceDate, DateTimeFormatter.BASIC_ISO_DATE);
			LocalDate distributorInvoice = LocalDate.parse(distInvoiceDate, DateTimeFormatter.BASIC_ISO_DATE);
			if (YearMonth.from(invoice).isAfter(selectedMonth)) {
				throw new IllegalArgumentException("3M invoice date cannot be after the claim month.");
			}
			if (!YearMonth.from(distributorInvoice).equals(selectedMonth)) {
				throw new IllegalArgumentException("Distributor invoice date must be within the selected claim month.");
			}
			if (distributorInvoice.isBefore(invoice)) {
				throw new IllegalArgumentException("Distributor invoice date must be on or after the 3M invoice date.");
			}
			if (distributorInvoice.isAfter(LocalDate.now())) {
				throw new IllegalArgumentException("Distributor invoice date cannot be later than today.");
			}
		} catch (DateTimeException | NumberFormatException ex) {
			throw new IllegalArgumentException("Claim and invoice dates must be valid YYYYMM / YYYYMMDD dates.", ex);
		}
	}

	private void updateLine(Session session, String login, String claimNumber, String comments, String lateRemarks,
			String action, Map<String, Object> line) {
		String sku = text(line.get("sku"));
		String invoiceNumber = text(line.get("invoiceNumber"));
		String invoiceDate = text(line.get("invoiceDate"));
		String oldDistInvoice = text(line.get("oldDistInvoice"));
		String oldDistDate = text(line.get("oldDistDate"));
		String qty = text(line.get("qty"));
		String claimValue = text(line.get("claimValue"));
		String newDistInvoice = text(line.get("newDistInvoice"));
		String newDistDate = text(line.get("newDistDate"));
		String lineComments = text(line.get("lineComments"));
		String rcPrice = text(line.get("rcPrice"));
		if (sku.isEmpty() || invoiceNumber.isEmpty()) {
			throw new IllegalArgumentException("Each changed line needs a SKU and a 3M invoice number.");
		}
		System.out.println(sql.as400ProcedureLogPrefix() + "CALL SFLASH.PMS360S("
				+ String.join(", ", List.of(
						"/* 1 appCode */ " + ShipAndDebitSql.sqlLiteral(sql.appCode()),
						"/* 2 loginId */ " + ShipAndDebitSql.sqlLiteral(login),
						"/* 3 action */ " + ShipAndDebitSql.sqlLiteral(action),
						"/* 4 claimNumber */ " + ShipAndDebitSql.sqlLiteral(claimNumber),
						"/* 5 sku */ " + ShipAndDebitSql.sqlLiteral(sku),
						"/* 6 invoiceNumber */ " + ShipAndDebitSql.sqlLiteral(invoiceNumber),
						"/* 7 invoiceDate */ " + ShipAndDebitSql.sqlLiteral(invoiceDate),
						"/* 8 oldDistInvoice */ " + ShipAndDebitSql.sqlLiteral(oldDistInvoice),
						"/* 9 oldDistDate */ " + ShipAndDebitSql.sqlLiteral(oldDistDate),
						"/* 10 qty */ " + ShipAndDebitSql.sqlLiteral(qty),
						"/* 11 claimValue */ " + ShipAndDebitSql.sqlLiteral(claimValue),
						"/* 12 comments */ " + ShipAndDebitSql.sqlLiteral(comments),
						"/* 13 newDistInvoice */ " + ShipAndDebitSql.sqlLiteral(newDistInvoice),
						"/* 14 newDistDate */ " + ShipAndDebitSql.sqlLiteral(newDistDate),
						"/* 15 lineComments */ " + ShipAndDebitSql.sqlLiteral(lineComments),
						"/* 16 rcPrice */ " + ShipAndDebitSql.sqlLiteral(rcPrice),
						"/* 17 lateRemarks */ " + ShipAndDebitSql.sqlLiteral(lateRemarks))) + ");");
		NativeQuerySupport.executeProcedure(session, UPDATE_CALL,
				sql.appCode(), login, action, claimNumber, sku, invoiceNumber, invoiceDate,
				oldDistInvoice, oldDistDate, qty, claimValue, comments,
				newDistInvoice, newDistDate, lineComments, rcPrice, lateRemarks);
	}

	private String claimNumber(Session session, String login) {
		System.out.println(sql.as400ProcedureLogPrefix() + "CALL SFLASH.PMS328S("
				+ ShipAndDebitSql.sqlLiteral(sql.appCode()) + ","
				+ ShipAndDebitSql.sqlLiteral(login) + ",'C',? /* 4 OUT RNUM */);");
		Map<Integer, Integer> outputs = new LinkedHashMap<>();
		outputs.put(4, Types.VARCHAR);
		Map<Integer, Object> values = NativeQuerySupport.executeProcedureWithOutputs(
				session, NUMBER_CALL, outputs, sql.appCode(), login, "C");
		String claimNumber = text(values.get(4));
		if (claimNumber.isEmpty()) {
			throw new IllegalStateException("AS/400 did not return a claim number.");
		}
		System.out.println(sql.as400ProcedureLogPrefix() + "PMS328S OUT RNUM="
				+ ShipAndDebitSql.sqlLiteral(claimNumber)
				+ " (use this returned value as PMS334S parameter #3).");
		return claimNumber;
	}

	private void insertLine(Session session, String login, String claimNumber, String endCustomer, String division,
			String claimMonth, String comments, String lateRemarks, Map<String, Object> line) {
		String sku = text(line.get("sku"));
		String description = text(line.get("description"));
		String descriptionPrefix = sku + " - ";
		if (description.startsWith(descriptionPrefix)) {
			description = description.substring(descriptionPrefix.length());
		}
		String invoiceNumber = text(line.get("invoiceNumber"));
		String invoiceDate = text(line.get("invoiceDate"));
		String uom = text(line.get("uom"));
		String availQty = text(line.get("availQty"));
		String salesPerson = text(line.get("salesPerson"));
		String rcPrice = text(line.get("rcPrice"));
		String distInvoiceNumber = text(line.get("distInvoiceNumber"));
		String distInvoiceDate = text(line.get("distInvoiceDate"));
		String distBillQty = text(line.get("distBillQty"));
		String distBillPrice = text(line.get("distBillPrice"));
		String claimValue = text(line.get("claimValue"));
		String lineComments = text(line.get("lineComments"));
		if (sku.isEmpty() || invoiceNumber.isEmpty()) {
			throw new IllegalArgumentException("Each line needs a SKU and a 3M invoice number.");
		}
		if (description.length() > 30) {
			throw new IllegalArgumentException("Product description must not exceed 30 characters for PMS334S.");
		}
		System.out.println(sql.as400ProcedureLogPrefix() + "CALL SFLASH.PMS334S("
				+ String.join(", ", List.of(
						"/* 1 appCode */ " + ShipAndDebitSql.sqlLiteral(sql.appCode()),
						"/* 2 loginId */ " + ShipAndDebitSql.sqlLiteral(login),
						"/* 3 claimNumber */ " + ShipAndDebitSql.sqlLiteral(claimNumber),
						"/* 4 endCustomer */ " + ShipAndDebitSql.sqlLiteral(endCustomer),
						"/* 5 division */ " + ShipAndDebitSql.sqlLiteral(division),
						"/* 6 sku */ " + ShipAndDebitSql.sqlLiteral(sku),
						"/* 7 description */ " + ShipAndDebitSql.sqlLiteral(description),
						"/* 8 invoiceNumber */ " + ShipAndDebitSql.sqlLiteral(invoiceNumber),
						"/* 9 invoiceDate */ " + ShipAndDebitSql.sqlLiteral(invoiceDate),
						"/* 10 uom */ " + ShipAndDebitSql.sqlLiteral(uom),
						"/* 11 availQty */ " + ShipAndDebitSql.sqlLiteral(availQty),
						"/* 12 salesPerson */ " + ShipAndDebitSql.sqlLiteral(salesPerson),
						"/* 13 rcPrice */ " + ShipAndDebitSql.sqlLiteral(rcPrice),
						"/* 14 distInvoiceNumber */ " + ShipAndDebitSql.sqlLiteral(distInvoiceNumber),
						"/* 15 distInvoiceDate */ " + ShipAndDebitSql.sqlLiteral(distInvoiceDate),
						"/* 16 distBillQty */ " + ShipAndDebitSql.sqlLiteral(distBillQty),
						"/* 17 distBillPrice */ " + ShipAndDebitSql.sqlLiteral(distBillPrice),
						"/* 18 claimValue */ " + ShipAndDebitSql.sqlLiteral(claimValue),
						"/* 19 claimMonth */ " + ShipAndDebitSql.sqlLiteral(claimMonth),
						"/* 20 comments */ " + ShipAndDebitSql.sqlLiteral(comments),
						"/* 21 lineComments */ " + ShipAndDebitSql.sqlLiteral(lineComments),
						"/* 22 lateRemarks */ " + ShipAndDebitSql.sqlLiteral(lateRemarks))) + ");");
		try {
			NativeQuerySupport.executeProcedure(session, INSERT_CALL,
					sql.appCode(), login, claimNumber, endCustomer, division,
					sku, description, invoiceNumber, invoiceDate, uom, availQty, salesPerson, rcPrice,
					distInvoiceNumber, distInvoiceDate, distBillQty, distBillPrice, claimValue,
					claimMonth, comments, lineComments, lateRemarks);
		} catch (RuntimeException ex) {
			String detail = insertBindingFailure(ex);
			if (detail != null) {
				throw new ProcedureBindingFailure(detail, ex);
			}
			throw ex;
		}
	}

	private static String insertBindingFailure(Throwable failure) {
		for (Throwable cause = failure; cause != null; cause = cause.getCause()) {
			if (!(cause instanceof SQLException sqlException)) {
				continue;
			}
			String message = sqlException.getMessage();
			String prefix = "Failed to bind stored procedure parameter #";
			if (message == null || !message.startsWith(prefix)) {
				continue;
			}
			try {
				int position = Integer.parseInt(message.substring(prefix.length()));
				if (position < 1 || position > INSERT_PARAMETERS.size()) {
					return null;
				}
				String state = sqlException.getSQLState();
				String diagnostic = state == null || state.isBlank() ? "" : " (SQLSTATE " + state + ")";
				return "AS/400 rejected claim field '" + INSERT_PARAMETERS.get(position - 1)
						+ "' while binding PMS334S parameter #" + position + diagnostic
						+ ". Check the value length and format.";
			} catch (NumberFormatException ignored) {
				return null;
			}
		}
		return null;
	}

	static final class ProcedureBindingFailure extends RuntimeException {
		ProcedureBindingFailure(String message, Throwable cause) {
			super(message, cause);
		}
	}
}
