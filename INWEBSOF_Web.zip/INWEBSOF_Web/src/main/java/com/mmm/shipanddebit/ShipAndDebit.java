package com.mmm.shipanddebit;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Contract Claim Management. Customer code and login follow
 * {@code doc/getCustomer.md}.
 */
@RestController
@RequestMapping("/api/customer/ship-and-debit")
public class ShipAndDebit {

	private static final Logger logger = LoggerFactory.getLogger(ShipAndDebit.class);
	private final ShipAndDebitSql sql;
	private final SaveClaim saveClaim;
	private final ShipAndDebitDocUpload documents;
	private final Gson gson = new Gson();

	public ShipAndDebit(HibernateFactoryRegistry registry,
			ShipAndDebitDocUpload documents,
			@Value("${inpc.ship-and-debit.as400:as400ind}") String as400,
			@Value("${inpc.ship-and-debit.app-code:CCM}") String appCode,
			@Value("${inpc.ship-and-debit.claim-list-app-code:INPC}") String claimListAppCode) {
		this.sql = new ShipAndDebitSql(registry, as400, appCode, claimListAppCode);
		this.saveClaim = new SaveClaim(sql);
		this.documents = documents;
	}

	@GetMapping("/open")
	public String open(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			Map<String, Object> terms = sql.terms(context.loginId());
			ShipAndDebitTerms.store(request.getSession(false), context.loginId(),
					Boolean.TRUE.equals(terms.get("accepted")), text(terms.get("role")));
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("custCode", context.custCode());
			data.put("loginId", context.loginId());
			data.put("accepted", terms.get("accepted"));
			data.put("role", terms.get("role"));
			data.put("name", terms.get("name"));
			data.put("email", terms.get("email"));
			data.put("posDealerExists", sql.dealerExists(context.custCode()));
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	@PostMapping("/terms")
	public String acceptTerms(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			boolean accepted = sql.acceptTerms(context.loginId());
			if (!accepted) {
				throw new IllegalStateException("The terms were not accepted.");
			}
			ShipAndDebitTerms.markAccepted(request.getSession(false), context.loginId());
			result.SetSuccess("success", Map.of("accepted", true));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	@GetMapping("/claims")
	public String claims(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("status") String status) {
		return rows(request, custCode, loginId, context -> {
			String role = ShipAndDebitTerms.role(request.getSession(false), context.loginId());
			if (status.indexOf(',') >= 0) {
				return sql.claimsByStatus(context.loginId(), role, status);
			}
			return sql.claims(context.loginId(), role, status);
		});
	}

	@GetMapping("/claims/{claimNumber}")
	public String claim(HttpServletRequest request, @PathVariable String claimNumber,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		return rows(request, custCode, loginId, context -> sql.claim(context.loginId(), claimNumber));
	}

	@PostMapping("/claims/{claimNumber}")
	public String update(HttpServletRequest request, @PathVariable String claimNumber,
			@RequestBody Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request,
					text(body.get("custCode")), text(body.get("loginId")));
			requireAccepted(request, context.loginId());
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> lines = (List<Map<String, Object>>) body.get("lines");
			result.SetSuccess("success", saveClaim.update(
					context.loginId(), claimNumber,
					text(body.get("comments")),
					text(body.get("lateRemarks")),
					lines));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}
	@PostMapping(value = "/claims", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String create(HttpServletRequest request, @RequestBody Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			result.SetSuccess("success", createClaim(request, body, List.of()));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	@PostMapping(value = "/claims", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String createWithDocuments(HttpServletRequest request,
			@RequestParam("claim") String claimJson,
			@RequestParam(value = "files", required = false) List<MultipartFile> files) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			Map<String, Object> body = gson.fromJson(claimJson, Map.class);
			if (body == null) {
				throw new IllegalArgumentException("Claim details are required.");
			}
			result.SetSuccess("success", createClaim(request, body, files == null ? List.of() : files));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	private Map<String, Object> createClaim(HttpServletRequest request, Map<String, Object> body,
			List<MultipartFile> files) throws Exception {
		String passedCust = text(body.get("custCode"));
		String passedLogin = text(body.get("loginId"));
		UserSessionSupport.ProcedureCustomerContext context = customer(request, passedCust, passedLogin);
		requireAccepted(request, context.loginId());
		if (!files.isEmpty()) {
			ShipAndDebitDocUpload.validateUploads(files);
		}
		String posDealerExists = sql.dealerExists(context.custCode());
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lines = (List<Map<String, Object>>) body.get("lines");
		Map<String, Object> saved = saveClaim.create(
				context.loginId(),
				text(body.get("endCustomer")),
				text(body.get("division")),
				text(body.get("claimMonth")),
				text(body.get("comments")),
				text(body.get("lateRemarks")),
				lines);
		saved.put("posDealerExists", posDealerExists);
		if (!files.isEmpty()) {
			String claimNumber = text(saved.get("claimNumber"));
			try {
				List<String> storedFiles = documents.storeDocuments(context.loginId(), claimNumber, files);
				saved.put("documentsStored", true);
				saved.put("documentFiles", storedFiles);
			} catch (Exception ex) {
				logger.error("Claim {} was saved but supporting document upload failed", claimNumber, ex);
				saved.put("documentsStored", false);
				saved.put("documentMessage",
						"Claim was saved, but supporting documents could not all be stored. Retry the document upload.");
			}
		}
		return saved;
	}

	@GetMapping("/divisions")
	public String divisions(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		return rows(request, custCode, loginId, context -> sql.divisions(context.loginId(), context.custCode()));
	}

	@GetMapping("/skus")
	public String skus(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("endCustomer") String endCustomer,
			@RequestParam("division") String division) {
		return rows(request, custCode, loginId,
				context -> sql.skus(context.loginId(), context.custCode(), endCustomer, division));
	}

	@GetMapping("/invoices")
	public String invoices(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("sku") String sku,
			@RequestParam("claimMonth") String claimMonth) {
		return rows(request, custCode, loginId,
				context -> sql.invoices(context.loginId(), context.custCode(), sku, claimMonth));
	}

	@GetMapping("/late-flag")
	public String lateFlag(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("division") String division,
			@RequestParam("claimMonth") String claimMonth) {
		return rows(request, custCode, loginId, context -> sql.lateFlag(division, claimMonth));
	}

	@GetMapping("/claim-check")
	public String claimCheck(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("sku") String sku,
			@RequestParam("invoiceNumber") String invoiceNumber,
			@RequestParam("invoiceDate") String invoiceDate,
			@RequestParam("distInvoiceNumber") String distInvoiceNumber,
			@RequestParam("distInvoiceDate") String distInvoiceDate) {
		return rows(request, custCode, loginId, context -> sql.claimCheck(
				context.loginId(), sku, invoiceNumber, invoiceDate, distInvoiceNumber, distInvoiceDate,
				context.custCode()));
	}

	@GetMapping("/invoice-details")
	public String invoiceDetails(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("endCustomer") String endCustomer,
			@RequestParam("sku") String sku,
			@RequestParam("invoiceNumber") String invoiceNumber,
			@RequestParam("invoiceDate") String invoiceDate,
			@RequestParam("distInvoiceDate") String distInvoiceDate) {
		return rows(request, custCode, loginId, context -> sql.invoiceDetails(
				context.loginId(), endCustomer, sku, invoiceNumber, invoiceDate, distInvoiceDate));
	}

	@GetMapping("/end-customers")
	public String endCustomers(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("division") String division) {
		return rows(request, custCode, loginId,
				context -> sql.endCustomers(context.loginId(), division, context.custCode()));
	}

	@GetMapping("/rate-contracts/file")
	public ResponseEntity<byte[]> rateContractFile(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("number") String number) {
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			requireAccepted(request, context.loginId());
			String contractNumber = text(number);
			if (contractNumber.isEmpty()) {
				throw new IllegalArgumentException("Contract number is required.");
			}
			List<Map<String, Object>> rows = sql.rateContract(contractNumber);
			byte[] file = rateWorkbook(contractNumber, rows);
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
							.filename("ApprovedRC" + contractNumber + ".xlsx").build().toString())
					.contentType(MediaType.parseMediaType(
							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
					.body(file);
		} catch (Exception ex) {
			logger.error("Rate contract download failed", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	@GetMapping("/rate-contracts/detail")
	public String rateContract(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("number") String number) {
		return rows(request, custCode, loginId, context -> sql.rateContract(number));
	}

	@GetMapping("/rate-contracts")
	public String rateContracts(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("flag") String flag) {
		return rows(request, custCode, loginId,
				context -> sql.rateContracts(context.loginId(), flag, context.custCode()));
	}

	@PostMapping("/rate-contracts/accept")
	public String acceptRate(HttpServletRequest request, @RequestBody Map<String, Object> body) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request,
					text(body.get("custCode")), text(body.get("loginId")));
			requireAccepted(request, context.loginId());
			String contractNumber = text(body.get("contractNumber"));
			String endCustomer = text(body.get("endCustomer"));
			if (contractNumber.isEmpty() || endCustomer.isEmpty()) {
				throw new IllegalArgumentException("Contract number and end customer are required.");
			}
			String statusFlag = text(body.get("statusFlag"));
			if (statusFlag.isEmpty()) {
				statusFlag = "A";
			}
			sql.acceptRateContract(context.loginId(), endCustomer, contractNumber, statusFlag);
			result.SetSuccess("success", Map.of("message", "Rate contract accepted."));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	@GetMapping("/report/file")
	public ResponseEntity<byte[]> reportFile(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate) {
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			requireAccepted(request, context.loginId());
			HttpSession session = request.getSession(false);
			String internalCode = session == null ? "" : text(
					session.getAttribute(UserSessionSupport.LOGIN_USER_INT_CODE));
			List<Map<String, Object>> rows = sql.report(fromDate, toDate, internalCode, context.custCode());
			byte[] file = workbook(rows);
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
							.filename("claim-report.xlsx").build().toString())
					.contentType(MediaType.parseMediaType(
							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
					.body(file);
		} catch (Exception ex) {
			logger.error("Claim report download failed", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	private static byte[] rateWorkbook(String contractNumber, List<Map<String, Object>> rows) throws Exception {
		try (XSSFWorkbook book = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			String sheetName = "ApprovedRC" + contractNumber;
			if (sheetName.length() > 31) {
				sheetName = sheetName.substring(0, 31);
			}
			Sheet sheet = book.createSheet(sheetName);
			Map<String, Object> first = rows == null || rows.isEmpty() ? Map.of() : rows.get(0);
			Font bold = book.createFont();
			bold.setBold(true);
			bold.setFontName("Calibri");
			bold.setFontHeightInPoints((short) 11);
			CellStyle label = bordered(book, bold, IndexedColors.GREY_25_PERCENT, HorizontalAlignment.LEFT);
			CellStyle value = bordered(book, null, null, HorizontalAlignment.LEFT);
			CellStyle section = bordered(book, bold, IndexedColors.PALE_BLUE, HorizontalAlignment.LEFT);
			CellStyle header = bordered(book, bold, IndexedColors.LEMON_CHIFFON, HorizontalAlignment.CENTER);
			CellStyle text = bordered(book, null, null, HorizontalAlignment.LEFT);
			CellStyle center = bordered(book, null, null, HorizontalAlignment.CENTER);
			CellStyle money = bordered(book, null, null, HorizontalAlignment.RIGHT);
			DataFormat format = book.createDataFormat();
			money.setDataFormat(format.getFormat("#,##0.00"));

			put(sheet.createRow(0), 0, "Division", label);
			put(sheet.getRow(0), 1, pick(first, "RCDIVC") + " - " + pick(first, "RCDIVD"), value);
			put(sheet.getRow(0), 2, "End Customer Code/Description", label);
			put(sheet.getRow(0), 3, pick(first, "RCCUST", "DRECUS") + " - "
					+ pick(first, "RCCNME", "DRECNM"), value);
			put(sheet.createRow(1), 0, "Rate Contract Start Date", label);
			put(sheet.getRow(1), 1, displayDate(pick(first, "RCSDAT")), value);
			put(sheet.getRow(1), 2, "Rate Contract End Date", label);
			put(sheet.getRow(1), 3, displayDate(pick(first, "RCEDAT")), value);
			Row title = sheet.createRow(3);
			put(title, 0, "Stock Code Details", section);
			sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, 4));
			for (int i = 1; i <= 4; i++) {
				title.createCell(i).setCellStyle(section);
			}
			Row heads = sheet.createRow(4);
			String[] names = { "Sl No", "Product code / Description", "UOM", "Book Price", "Rate Contract Price" };
			for (int i = 0; i < names.length; i++) {
				put(heads, i, names[i], header);
			}
			int line = 5;
			int serial = 1;
			if (rows != null) {
				for (Map<String, Object> row : rows) {
					Row excel = sheet.createRow(line++);
					put(excel, 0, String.valueOf(serial++), center);
					put(excel, 1, pick(row, "RCPROD") + " - " + pick(row, "RCDESC"), text);
					put(excel, 2, pick(row, "RCSUOM"), center);
					putNumber(excel, 3, pick(row, "RCACTP"), money);
					putNumber(excel, 4, pick(row, "RCECPR"), money);
				}
			}
			sheet.setColumnWidth(0, 10 * 256);
			sheet.setColumnWidth(1, 42 * 256);
			sheet.setColumnWidth(2, 12 * 256);
			sheet.setColumnWidth(3, 16 * 256);
			sheet.setColumnWidth(4, 22 * 256);
			book.write(out);
			return out.toByteArray();
		}
	}

	private static CellStyle bordered(XSSFWorkbook book, Font font, IndexedColors fill, HorizontalAlignment align) {
		CellStyle style = book.createCellStyle();
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		style.setVerticalAlignment(VerticalAlignment.CENTER);
		style.setAlignment(align);
		style.setWrapText(true);
		if (font != null) {
			style.setFont(font);
		}
		if (fill != null) {
			style.setFillForegroundColor(fill.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}
		return style;
	}

	private static void put(Row row, int column, String text, CellStyle style) {
		Cell cell = row.createCell(column);
		cell.setCellValue(text == null ? "" : text);
		cell.setCellStyle(style);
	}

	private static void putNumber(Row row, int column, String text, CellStyle style) {
		Cell cell = row.createCell(column);
		cell.setCellStyle(style);
		String raw = text == null ? "" : text.replace(",", "").trim();
		if (raw.isEmpty()) {
			cell.setBlank();
			return;
		}
		try {
			cell.setCellValue(Double.parseDouble(raw));
		} catch (NumberFormatException ex) {
			cell.setCellValue(text);
		}
	}

	private static String pick(Map<String, Object> row, String... keys) {
		if (row == null) {
			return "";
		}
		for (String key : keys) {
			for (Map.Entry<String, Object> entry : row.entrySet()) {
				if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(key)) {
					String value = text(entry.getValue());
					if (!value.isEmpty()) {
						return value;
					}
				}
			}
		}
		return "";
	}

	private static String displayDate(String value) {
		if (value != null && value.matches("\\d{8}")) {
			return value.substring(6, 8) + "-" + value.substring(4, 6) + "-" + value.substring(0, 4);
		}
		return value == null ? "" : value;
	}

	private static byte[] workbook(List<Map<String, Object>> rows) throws Exception {
		try (XSSFWorkbook book = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			var sheet = book.createSheet("Claims");
			if (rows != null && !rows.isEmpty()) {
				List<String> keys = new java.util.ArrayList<>(rows.get(0).keySet());
				Row header = sheet.createRow(0);
				for (int i = 0; i < keys.size(); i++) {
					header.createCell(i).setCellValue(keys.get(i));
				}
				for (int r = 0; r < rows.size(); r++) {
					Row line = sheet.createRow(r + 1);
					for (int c = 0; c < keys.size(); c++) {
						line.createCell(c).setCellValue(text(rows.get(r).get(keys.get(c))));
					}
				}
			}
			book.write(out);
			return out.toByteArray();
		}
	}

	@GetMapping("/report")
	public String report(HttpServletRequest request,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId,
			@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate) {
		return rows(request, custCode, loginId, context -> {
			HttpSession session = request.getSession(false);
			String internalCode = session == null ? "" : text(
					session.getAttribute(UserSessionSupport.LOGIN_USER_INT_CODE));
			return sql.report(fromDate, toDate, internalCode, context.custCode());
		});
	}

	private String rows(HttpServletRequest request, String custCode, String loginId, Rows work) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			UserSessionSupport.ProcedureCustomerContext context = customer(request, custCode, loginId);
			requireAccepted(request, context.loginId());
			result.SetSuccess("success", work.load(context));
		} catch (Exception ex) {
			return error(result, ex);
		}
		return gson.toJson(result);
	}

	private void requireAccepted(HttpServletRequest request, String loginId) {
		ShipAndDebitTerms.requireAccepted(request.getSession(false), loginId);
	}

	private UserSessionSupport.ProcedureCustomerContext customer(
			HttpServletRequest request, String custCode, String loginId) {
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(session, firstParam(custCode), firstParam(loginId));
		if (context.custCode().isBlank() || context.loginId().isBlank()) {
			throw new IllegalArgumentException("No customer is selected for Ship and Debit.");
		}
		return context;
	}

	/** Spring joins a repeated query parameter with a comma. Keep the first value. */
	private static String firstParam(String value) {
		if (value == null) {
			return null;
		}
		int comma = value.indexOf(',');
		return (comma < 0 ? value : value.substring(0, comma)).trim();
	}

	private String error(ResponseDataGeneric result, Exception ex) {
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure", ex.getMessage());
		} else {
			if (!(ex instanceof IllegalArgumentException || ex instanceof IllegalStateException)) {
				logger.error("Ship and Debit request failed", ex);
			}
			String message = ex instanceof SaveClaim.ProcedureBindingFailure
					? ex.getMessage()
					: sqlDiagnostic(ex);
			result.SetError(-1, "failure",
					ex instanceof IllegalArgumentException || ex instanceof IllegalStateException
							? ex.getMessage()
							: message != null ? message : "Unable to complete the Ship and Debit request.");
		}
		return gson.toJson(result);
	}

	private static String sqlDiagnostic(Throwable failure) {
		for (Throwable cause = failure; cause != null; cause = cause.getCause()) {
			if (cause instanceof SQLException sqlException && sqlException.getSQLState() != null
					&& !sqlException.getSQLState().isBlank()) {
				String state = sqlException.getSQLState();
				if ("22001".equals(state)) {
					return "AS/400 reported data truncation (SQLSTATE 22001). A value exceeds a database field's allowed length.";
				}
				return "The AS/400 database rejected the request (SQLSTATE " + state + ").";
			}
		}
		return null;
	}

	@FunctionalInterface
	private interface Rows {
		Object load(UserSessionSupport.ProcedureCustomerContext context);
	}
}
