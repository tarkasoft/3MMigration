package com.mmm.shipanddebit;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.util.ContentCachingRequestWrapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class ShipAndDebitApiAuditInterceptor implements HandlerInterceptor {

	private static final Logger logger = LoggerFactory.getLogger(ShipAndDebitApiAuditInterceptor.class);
	private static final String START_ATTRIBUTE = ShipAndDebitApiAuditInterceptor.class.getName() + ".started";
	private static final String PARAMS_ATTRIBUTE = ShipAndDebitApiAuditInterceptor.class.getName() + ".params";
	private static final String HANDLER_ATTRIBUTE = ShipAndDebitApiAuditInterceptor.class.getName() + ".handler";

	private final ObjectMapper objectMapper;

	public ShipAndDebitApiAuditInterceptor(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		request.setAttribute(START_ATTRIBUTE, System.nanoTime());
		request.setAttribute(PARAMS_ATTRIBUTE, parameters(request));
		request.setAttribute(HANDLER_ATTRIBUTE, handlerName(handler));
		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
			Object handler, Exception exception) {
		Object started = request.getAttribute(START_ATTRIBUTE);
		long durationMs = started instanceof Long
				? (System.nanoTime() - (Long) started) / 1_000_000
				: -1;
		logger.info("Ship and Debit API method={} path={} handler={} params={} bodyFields={} contentType={} contentLength={} "
						+ "status={} durationMs={} error={}",
				request.getMethod(),
				request.getRequestURI(),
				request.getAttribute(HANDLER_ATTRIBUTE),
				request.getAttribute(PARAMS_ATTRIBUTE),
				bodyFields(request),
				request.getContentType(),
				request.getContentLengthLong(),
				response.getStatus(),
				durationMs,
				exception == null ? "-" : exception.getClass().getSimpleName());
	}

	private List<String> bodyFields(HttpServletRequest request) {
		if (!(request instanceof ContentCachingRequestWrapper cached)
				|| request.getContentType() == null
				|| !request.getContentType().toLowerCase(java.util.Locale.ROOT).contains("application/json")) {
			return List.of();
		}
		byte[] body = cached.getContentAsByteArray();
		if (body.length == 0) {
			return List.of();
		}
		try {
			JsonNode json = objectMapper.readTree(body);
			List<String> names = new ArrayList<>();
			if (json != null && json.isObject()) {
				json.fieldNames().forEachRemaining(names::add);
			}
			return names;
		} catch (IOException ex) {
			return List.of("[invalid-json]");
		}
	}

	private static Map<String, List<String>> parameters(HttpServletRequest request) {
		Map<String, List<String>> safe = new LinkedHashMap<>();
		for (Map.Entry<String, String[]> entry : new TreeMap<>(request.getParameterMap()).entrySet()) {
			String name = entry.getKey();
			String key = name.toLowerCase(java.util.Locale.ROOT);
			if (key.contains("password") || key.equals("pwd") || key.contains("token")
					|| key.contains("secret") || key.contains("email") || key.contains("loginid")
					|| key.contains("comment") || key.contains("remark") || key.equals("claim")
					|| key.equals("file") || key.equals("files")) {
				safe.put(name, List.of("[REDACTED]"));
			} else {
				List<String> values = new ArrayList<>();
				Arrays.stream(entry.getValue()).map(ShipAndDebitApiAuditInterceptor::safeValue)
						.forEach(values::add);
				safe.put(name, values);
			}
		}
		return safe;
	}

	private static String safeValue(String value) {
		if (value == null) {
			return "";
		}
		String safe = value.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
		return safe.length() > 160 ? safe.substring(0, 160) + "..." : safe;
	}

	private static String handlerName(Object handler) {
		if (handler instanceof HandlerMethod method) {
			return method.getBeanType().getSimpleName() + "#" + method.getMethod().getName();
		}
		return handler.getClass().getSimpleName();
	}
}
