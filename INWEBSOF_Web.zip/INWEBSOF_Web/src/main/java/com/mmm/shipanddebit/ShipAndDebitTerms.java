package com.mmm.shipanddebit;

import jakarta.servlet.http.HttpSession;

final class ShipAndDebitTerms {

	private static final String LOGIN_ATTRIBUTE = ShipAndDebitTerms.class.getName() + ".login";
	private static final String ACCEPTED_ATTRIBUTE = ShipAndDebitTerms.class.getName() + ".accepted";
	private static final String ROLE_ATTRIBUTE = ShipAndDebitTerms.class.getName() + ".role";

	private ShipAndDebitTerms() {
	}

	static void store(HttpSession session, String loginId, boolean accepted, String role) {
		if (session == null) {
			throw new IllegalStateException("The session expired. Please sign in again.");
		}
		session.setAttribute(LOGIN_ATTRIBUTE, loginId);
		session.setAttribute(ACCEPTED_ATTRIBUTE, accepted);
		session.setAttribute(ROLE_ATTRIBUTE, role);
	}

	static void markAccepted(HttpSession session, String loginId) {
		if (session == null) {
			throw new IllegalStateException("The session expired. Please sign in again.");
		}
		if (!loginId.equals(session.getAttribute(LOGIN_ATTRIBUTE))) {
			session.setAttribute(LOGIN_ATTRIBUTE, loginId);
			session.removeAttribute(ROLE_ATTRIBUTE);
		}
		session.setAttribute(ACCEPTED_ATTRIBUTE, true);
	}

	static void requireAccepted(HttpSession session, String loginId) {
		if (session == null || !loginId.equals(session.getAttribute(LOGIN_ATTRIBUTE))
				|| !Boolean.TRUE.equals(session.getAttribute(ACCEPTED_ATTRIBUTE))) {
			throw new IllegalStateException("Accept the terms before using Ship and Debit.");
		}
	}

	static String role(HttpSession session, String loginId) {
		requireAccepted(session, loginId);
		Object role = session.getAttribute(ROLE_ATTRIBUTE);
		if (!(role instanceof String)) {
			throw new IllegalStateException("Ship and Debit session data is missing. Reopen the menu.");
		}
		return (String) role;
	}
}
