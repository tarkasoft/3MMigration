package com.mmm.shipanddebit;

import static com.mmm.titpl.CommonFunctions.text;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;

/**
 * AS/400 calls follow Account Status: print the procedure, then
 * {@link NativeQuerySupport} with local variables in {@code ?} order.
 * The pool name comes from {@code inpc.ship-and-debit.as400}.
 */
final class ShipAndDebitSql {

	private static final String POS = HibernateFactoryRegistry.POS;

	private final HibernateFactoryRegistry registry;
	private final String as400;
	private final String appCode;
	private final String claimListAppCode;

	ShipAndDebitSql(HibernateFactoryRegistry registry, String as400, String appCode, String claimListAppCode) {
		this.registry = registry;
		this.as400 = as400 == null || as400.isBlank() ? "as400ind" : as400.trim();
		this.appCode = appCode == null || appCode.isBlank() ? "CCM" : appCode.trim();
		this.claimListAppCode = claimListAppCode == null || claimListAppCode.isBlank()
				? "INPC" : claimListAppCode.trim();
	}

	String appCode() {
		return appCode;
	}

	String as400ProcedureLogPrefix() {
		return "AS400 procedure call [datasource=" + as400 + "]: ";
	}

	static String sqlLiteral(Object value) {
		return quote(value);
	}

	Map<String, Object> terms(String loginId) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS330S("
				+ quote(appCode) + "," + quote(login)
				+ ",? /* ROLE */,? /* EMAIL */,? /* NAME */,? /* DISTRTERMS */)");
		Map<Integer, Integer> outputs = new LinkedHashMap<>();
		outputs.put(3, Types.VARCHAR);
		outputs.put(4, Types.VARCHAR);
		outputs.put(5, Types.VARCHAR);
		outputs.put(6, Types.VARCHAR);
		Map<Integer, Object> values = NativeQuerySupport.executeProcedureWithOutputs(
				registry, as400, "{call SFLASH.PMS330S(?,?,?,?,?,?)}", outputs, appCode, login);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS330S("
				+ quote(appCode) + "," + quote(login) + ","
				+ quote(values.get(3)) + "," + quote(values.get(4)) + ","
				+ quote(values.get(5)) + "," + quote(values.get(6)) + ")");
		System.out.flush();
		Map<String, Object> terms = new LinkedHashMap<>();
		terms.put("role", text(values.get(3)));
		terms.put("email", text(values.get(4)));
		terms.put("name", text(values.get(5)));
		terms.put("accepted", "Y".equalsIgnoreCase(text(values.get(6))));
		terms.put("distrTerms", text(values.get(6)));
		return terms;
	}

	boolean acceptTerms(String loginId) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS351S("
				+ quote(appCode) + "," + quote(login) + ",? /* STATUS */)");
		Map<Integer, Integer> outputs = new LinkedHashMap<>();
		outputs.put(3, Types.VARCHAR);
		Map<Integer, Object> values = NativeQuerySupport.executeProcedureWithOutputs(
				registry, as400, "{call SFLASH.PMS351S(?,?,?)}", outputs, appCode, login);
		String status = text(values.get(3));
		System.out.println("PMS351S STATUS=" + status);
		System.out.flush();
		if ("Y".equalsIgnoreCase(status)) {
			return true;
		}
		Map<String, Object> after = terms(loginId);
		System.out.println("PMS330S DISTRTERMS=" + after.get("distrTerms"));
		System.out.flush();
		if (!Boolean.TRUE.equals(after.get("accepted"))) {
			throw new IllegalStateException("The terms were not accepted. STATUS=" + status + ".");
		}
		return true;
	}

	String dealerExists(String customerCode) {
		String sql = "select count(1) as cnt from dbo.Dealer where DistributorID = ?";
		System.out.println("POS query: " + sql + " [" + customerCode + "]");
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(registry, POS, sql, customerCode);
		String count = rows.isEmpty() ? "0" : text(rows.get(0).get("cnt"));
		return "0".equals(count) || count.isEmpty() ? "No" : "Yes";
	}

	List<Map<String, Object>> claims(String loginId, String role, String statusList) {
		String login = upper(loginId);
		List<Map<String, Object>> rows = new ArrayList<>();
		for (String status : statusList.split(",")) {
			String one = status.trim().toUpperCase(Locale.ROOT);
			if (one.isEmpty()) {
				continue;
			}
			System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS324S("
					+ quote(claimListAppCode) + "," + quote(login) + "," + quote(role) + "," + quote(one) + ")");
			rows.addAll(labelClaims(NativeQuerySupport.executeProcedure(
					registry, as400, "{call SFLASH.PMS324S(?,?,?,?)}",
					claimListAppCode, login, role, one)));
		}
		return rows;
	}

	Map<String, List<Map<String, Object>>> claimsByStatus(String loginId, String role, String statusList) {
		String login = upper(loginId);
		Map<String, List<Map<String, Object>>> buckets = new LinkedHashMap<>();
		for (String status : statusList.split(",")) {
			String one = status.trim().toUpperCase(Locale.ROOT);
			if (one.isEmpty()) {
				continue;
			}
			System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS324S("
					+ quote(claimListAppCode) + "," + quote(login) + "," + quote(role) + "," + quote(one) + ")");
			buckets.put(one, labelClaims(NativeQuerySupport.executeProcedure(
					registry, as400, "{call SFLASH.PMS324S(?,?,?,?)}",
					claimListAppCode, login, role, one)));
		}
		return buckets;
	}

	/** Legacy keyChangeAll names the first nine PMS324S columns by position. STATUSLVL keeps its own name. */
	private List<Map<String, Object>> labelClaims(List<Map<String, Object>> rows) {
		String[] labels = { "DCCLNO", "DCNAME", "DCECNM", "DCRQNM", "DCRQDT", "DCBSGS", "DCDVMS", "DCCLVL", "DCCORD" };
		List<Map<String, Object>> labeled = new ArrayList<>();
		boolean printed = false;
		for (Map<String, Object> row : rows) {
			if (!printed) {
				System.out.println("PMS324S columns: " + row.keySet());
				printed = true;
			}
			List<String> keys = new ArrayList<>(row.keySet());
			Map<String, Object> named = new LinkedHashMap<>();
			Object pendingWith = null;
			for (int i = 0; i < keys.size(); i++) {
				String key = keys.get(i);
				if (key != null && key.equalsIgnoreCase("STATUSLVL")) {
					pendingWith = row.get(key);
				}
				if (i < labels.length) {
					named.put(labels[i], row.get(key));
				} else {
					named.put(key, row.get(key));
				}
			}
			if (pendingWith != null) {
				named.put("STATUSLVL", pendingWith);
			}
			labeled.add(named);
		}
		return labeled;
	}

	List<Map<String, Object>> claim(String loginId, String claimNumber) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS325S("
				+ quote(appCode) + "," + quote(claimNumber) + "," + quote(login) + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS325S(?,?,?)}", appCode, claimNumber, login);
	}

	List<Map<String, Object>> divisions(String loginId, String customerCode) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS362S("
				+ quote(appCode) + "," + quote(login) + "," + quote(customerCode) + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS362S(?,?,?)}", appCode, login, customerCode);
	}

	List<Map<String, Object>> endCustomers(String loginId, String division, String customerCode) {
		String customer = customerCode == null ? "" : customerCode.trim();
		String divisionCode = division == null ? "" : division.trim();
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS349S('ESOF','',"
				+ quote(customer) + "," + quote(divisionCode) + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS349S(?,?,?,?)}",
				"ESOF", "", customer, divisionCode);
	}

	List<Map<String, Object>> skus(String loginId, String distributor, String endCustomer, String division) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS350S("
				+ quote(appCode) + "," + quote(login) + "," + quote(distributor) + ","
				+ quote(endCustomer) + "," + quote(division) + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS350S(?,?,?,?,?)}",
				appCode, login, text(distributor), text(endCustomer), text(division));
	}

	List<Map<String, Object>> invoices(String loginId, String distributor, String sku, String claimMonth) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS333S("
				+ quote(appCode) + "," + quote(login) + "," + quote(distributor) + ","
				+ quote(sku) + "," + quote(claimMonth) + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS333S(?,?,?,?,?)}",
				appCode, login, text(distributor), text(sku), text(claimMonth));
	}

	List<Map<String, Object>> lateFlag(String division, String claimMonth) {
		BigDecimal month = new BigDecimal(text(claimMonth));
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS387S("
				+ quote(division) + "," + month.toPlainString() + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS387S(?,?)}", text(division), month);
	}

	Map<String, Object> claimCheck(String loginId, String sku, String invoiceNumber, String invoiceDate,
			String distInvoiceNumber, String distInvoiceDate, String distributor) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS355S("
				+ quote(appCode) + "," + quote(login) + "," + quote(sku) + "," + quote(invoiceNumber) + ","
				+ quote(invoiceDate) + "," + quote(distInvoiceNumber) + "," + quote(distInvoiceDate)
				+ ",? /* CLAIMStatus */,? /* CLAIMNUMBER */)");
		Map<Integer, Integer> outputs = new LinkedHashMap<>();
		outputs.put(8, Types.VARCHAR);
		outputs.put(9, Types.VARCHAR);
		Map<Integer, Object> values = NativeQuerySupport.executeProcedureWithOutputs(
				registry, as400, "{call SFLASH.PMS355S(?,?,?,?,?,?,?,?,?)}", outputs,
				appCode, login, text(sku), text(invoiceNumber), text(invoiceDate),
				text(distInvoiceNumber), text(distInvoiceDate));
		Map<String, Object> checked = new LinkedHashMap<>();
		checked.put("claimStatus", text(values.get(8)));
		checked.put("claimNumber", text(values.get(9)));
		checked.put("posInvDate", maxDistributorInvoiceDate(distributor));
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS355S("
				+ quote(appCode) + "," + quote(login) + "," + quote(sku) + "," + quote(invoiceNumber) + ","
				+ quote(invoiceDate) + "," + quote(distInvoiceNumber) + "," + quote(distInvoiceDate) + ","
				+ quote(checked.get("claimStatus")) + "," + quote(checked.get("claimNumber")) + ")");
		System.out.flush();
		return checked;
	}

	Map<String, Object> invoiceDetails(String loginId, String endCustomer, String sku, String invoiceNumber,
			String invoiceDate, String distInvoiceDate) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS337S("
				+ quote(appCode) + "," + quote(login) + "," + quote(endCustomer) + "," + quote(sku) + ","
				+ quote(invoiceNumber) + "," + quote(invoiceDate) + "," + quote(distInvoiceDate) + ",'0')");
		Map<Integer, Integer> outputs = new LinkedHashMap<>();
		for (int position = 9; position <= 21; position++) {
			outputs.put(position, Types.VARCHAR);
		}
		Map<Integer, Object> values = NativeQuerySupport.executeProcedureWithOutputs(
				registry, as400, "{call SFLASH.PMS337S(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}", outputs,
				appCode, login, text(endCustomer), text(sku), text(invoiceNumber), text(invoiceDate),
				text(distInvoiceDate), "0");
		String[] names = { "UMO", "AQTY", "SPERSON", "RCPRICE", "DISTPPRICE", "TAX", "FRIEGHT", "DISCOUNT",
				"VATCST", "TAXFLAG", "IGST", "CGST", "extTaxPc" };
		Map<String, Object> detail = new LinkedHashMap<>();
		for (int i = 0; i < names.length; i++) {
			detail.put(names[i], text(values.get(9 + i)));
		}
		return detail;
	}

	String maxDistributorInvoiceDate(String distributor) {
		String sql = "select isnull(max_date,'00000000') as max_date from dis_max_inv_date where DistributorID = ?";
		System.out.println("POS query: " + sql + " [" + distributor + "]");
		List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(registry, POS, sql, text(distributor));
		String date = "";
		if (!rows.isEmpty()) {
			for (Map.Entry<String, Object> entry : rows.get(0).entrySet()) {
				if (entry.getKey() != null && entry.getKey().equalsIgnoreCase("max_date")) {
					date = text(entry.getValue()).replace("-", "");
				}
			}
		}
		return date.isEmpty() ? "20300101" : date;
	}

	List<Map<String, Object>> rateContracts(String loginId, String flag, String customerCode) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS261S("
				+ quote(appCode) + "," + quote(login) + "," + quote(flag) + "," + quote(customerCode) + ",'')");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS261S(?,?,?,?,?)}",
				appCode, login, flag, customerCode, "");
	}

	List<Map<String, Object>> rateContract(String contractNumber) {
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS332S("
				+ quote(appCode) + "," + quote(contractNumber) + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS332S(?,?)}", appCode, contractNumber);
	}

	void acceptRateContract(String loginId, String endCustomer, String contractNumber, String statusFlag) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS262S("
				+ quote(appCode) + "," + quote(login) + "," + quote(endCustomer) + ","
				+ quote(contractNumber) + "," + quote(statusFlag) + ")");
		NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS262S(?,?,?,?,?)}",
				appCode, login, endCustomer, contractNumber, statusFlag);
	}

	List<Map<String, Object>> report(String fromDate, String toDate, String userInternalCode, String customerCode) {
		System.out.println(as400ProcedureLogPrefix() + "CALL SFLASH.PMS396S("
				+ quote(fromDate) + "," + quote(toDate) + ","
				+ quote(userInternalCode) + "," + quote(customerCode) + ")");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call SFLASH.PMS396S(?,?,?,?)}",
				fromDate, toDate, userInternalCode, customerCode);
	}

	List<Map<String, Object>> shareRows(String loginId) {
		String login = upper(loginId);
		System.out.println(as400ProcedureLogPrefix() + "CALL BPCSLCLIN.CMW010S("
				+ quote(appCode) + "," + quote(login) + ",'')");
		return NativeQuerySupport.executeProcedure(
				registry, as400, "{call BPCSLCLIN.CMW010S(?,?,?)}", appCode, login, "");
	}

	String as400() {
		return as400;
	}

	HibernateFactoryRegistry registry() {
		return registry;
	}

	private static String upper(String value) {
		return text(value).toUpperCase(Locale.ROOT);
	}

	private static String quote(Object value) {
		String text = text(value).replace("'", "''");
		return "'" + text + "'";
	}
}
