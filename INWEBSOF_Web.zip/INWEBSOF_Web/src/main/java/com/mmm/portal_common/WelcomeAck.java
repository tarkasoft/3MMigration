package com.mmm.portal_common;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.AuthService;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Welcome popup acknowledgement. The message still comes from {@code welcome_msg_module}.
 * When {@code ack_required} is Yes, the popup stays until this insert succeeds.
 * It stays hidden after that unless {@code show_ack_prompt_even_acknowledged} is Yes.
 */
@RestController
@RequestMapping("/api/portal/welcome-ack")
public class WelcomeAck {

    private final SessionFactory sessionFactory;
    private final Gson gson = new Gson();

    public WelcomeAck(@Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session session() {
        return sessionFactory.getCurrentSession();
    }

    @PostMapping
    @Transactional(transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String acknowledge(HttpServletRequest request,
            @RequestParam("welcomeInternalCode") String welcomeInternalCode) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession httpSession = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(httpSession)) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }
        try {
            String loginId = UserSessionSupport.requireLoginId(httpSession);
            String custCode = text(httpSession.getAttribute(UserSessionSupport.CUST_CODE));
            String userType = text(httpSession.getAttribute(UserSessionSupport.LOGIN_USER_TYPE));
            save(userType, loginId, custCode, welcomeInternalCode);
            result.SetSuccess("success", Map.of("message", "Acknowledged."));
        } catch (IllegalArgumentException ex) {
            result.SetError(-1, "failure", ex.getMessage());
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Unable to save the acknowledgement.");
        }
        return gson.toJson(result);
    }

    /** Menus and /me. Hides an acknowledged message unless the module asks to show it again. */
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public Map<String, String> welcomeFor(HttpSession httpSession) {
        Map<String, String> out = empty();
        if (!UserSessionSupport.isLoggedIn(httpSession)) {
            return out;
        }
        try {
            String userType = text(httpSession.getAttribute(UserSessionSupport.LOGIN_USER_TYPE));
            String loginId = UserSessionSupport.requireLoginId(httpSession);
            String custCode = text(httpSession.getAttribute(UserSessionSupport.CUST_CODE));
            Map<String, String> current = currentMessage(userType);
            if (current.get("welcome_msg").isBlank()) {
                return out;
            }
            String acknowledgedOn = acknowledgedOn(current.get("welcome_internal_code"), loginId, custCode);
            boolean acknowledged = !acknowledgedOn.isEmpty();
            boolean showAgain = isYes(current.get("show_ack_prompt_even_acknowledged"));
            if (acknowledged && isYes(current.get("ack_required")) && !showAgain) {
                return out;
            }
            current.put("already_acknowledged", acknowledged && showAgain ? "Yes" : "No");
            current.put("acknowledged_on", acknowledged && showAgain ? acknowledgedOn : "");
            return current;
        } catch (Exception ex) {
            return out;
        }
    }

    private void save(String userType, String loginId, String custCode, String welcomeInternalCode) {
        int requestedId = parseId(welcomeInternalCode);
        if (requestedId <= 0) {
            throw new IllegalArgumentException("Welcome message is invalid.");
        }
        Map<String, String> current = currentMessage(userType);
        if (!String.valueOf(requestedId).equals(current.get("welcome_internal_code"))) {
            throw new IllegalArgumentException("This welcome message is not active.");
        }
        if (!isYes(current.get("ack_required"))) {
            throw new IllegalArgumentException("This welcome message does not require acknowledgement.");
        }
        if (!acknowledgedOn(current.get("welcome_internal_code"), loginId, custCode).isEmpty()) {
            return;
        }
        String sql = """
                insert into dbo.welcome_msg_ack
                    (ref_welcome_int_code, title, user_id, cust_code, acknowledged_on)
                values (:id, :title, :userId, :custCode, getdate())
                """.replace("getdate()", UserSessionSupport.sessionDate());
        session().createNativeQuery(sql)
                .setParameter("id", requestedId)
                .setParameter("title", current.get("welcome_title"))
                .setParameter("userId", loginId)
                .setParameter("custCode", custCode == null ? "" : custCode)
                .executeUpdate();
    }

    private Map<String, String> currentMessage(String loginUserType) {
        Map<String, String> out = empty();
        String userType = AuthService.normalizeLoginUserType(loginUserType);
        String sql = """
                select top 1
                       cast(w.internal_code as varchar(20)) as welcome_internal_code,
                       isnull(w.title,'') as welcome_title,
                       isnull(w.html_body,'') as welcome_msg,
                       isnull(w.ack_required,'No') as ack_required,
                       isnull(w.ack_message,'') as ack_message,
                       isnull(w.show_ack_prompt_even_acknowledged,'No') as show_ack_prompt_even_acknowledged
                from dbo.welcome_msg_module w
                left join dbo.ia_user_type t on t.internal_code = try_cast(w.w_user_type as int)
                where (
                      lower(ltrim(rtrim(isnull(t.user_type_name,'')))) = lower(:userType)
                   or lower(ltrim(rtrim(isnull(w.w_user_type,'')))) = lower(:userType)
                )
                  and w.from_date is not null
                  and w.to_date is not null
                  and isnull(w.active,'Yes') = 'Yes'
                  and convert(date, w.from_date) <= convert(date, getdate())
                  and convert(date, w.to_date) >= convert(date, getdate())
                  and ltrim(rtrim(isnull(w.html_body,''))) <> ''
                order by w.internal_code desc
                """.replace("getdate()", UserSessionSupport.sessionDate());
        List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(
                session(), sql, Map.of("userType", userType),
                stringScalars("welcome_internal_code", "welcome_title", "welcome_msg", "ack_required",
                        "ack_message", "show_ack_prompt_even_acknowledged"));
        if (rows.isEmpty()) {
            return out;
        }
        Map<String, Object> row = rows.get(0);
        out.put("welcome_internal_code", text(row.get("welcome_internal_code")).split("\\.")[0]);
        out.put("welcome_title", text(row.get("welcome_title")));
        out.put("welcome_msg", text(row.get("welcome_msg")));
        out.put("ack_required", isYes(text(row.get("ack_required"))) ? "Yes" : "No");
        out.put("ack_message", text(row.get("ack_message")));
        out.put("show_ack_prompt_even_acknowledged",
                isYes(text(row.get("show_ack_prompt_even_acknowledged"))) ? "Yes" : "No");
        out.put("already_acknowledged", "No");
        out.put("acknowledged_on", "");
        return out;
    }

    /** Last acknowledgement timestamp for this message, login, and customer. Empty when none. */
    private String acknowledgedOn(String welcomeInternalCode, String loginId, String custCode) {
        int id = parseId(welcomeInternalCode);
        if (id <= 0 || loginId == null || loginId.isBlank()) {
            return "";
        }
        String sql = """
                select top 1
                       convert(varchar(10), acknowledged_on, 103) + ' '
                       + convert(varchar(5), acknowledged_on, 108) as acknowledged_on
                from dbo.welcome_msg_ack
                where ref_welcome_int_code = :id
                  and user_id = :userId
                  and cust_code = :custCode
                order by acknowledged_on desc
                """;
        List<Map<String, Object>> rows = NativeQuerySupport.listAsMaps(
                session(), sql,
                Map.of("id", id, "userId", loginId, "custCode", custCode == null ? "" : custCode),
                stringScalars("acknowledged_on"));
        return rows.isEmpty() ? "" : text(rows.get(0).get("acknowledged_on"));
    }

    private static Map<String, org.hibernate.type.BasicTypeReference<?>> stringScalars(String... names) {
        Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
        for (String name : names) {
            scalars.put(name, StandardBasicTypes.STRING);
        }
        return scalars;
    }

    private static Map<String, String> empty() {
        Map<String, String> out = new LinkedHashMap<>();
        out.put("welcome_internal_code", "");
        out.put("welcome_title", "");
        out.put("welcome_msg", "");
        out.put("ack_required", "No");
        out.put("ack_message", "");
        out.put("show_ack_prompt_even_acknowledged", "No");
        out.put("already_acknowledged", "No");
        out.put("acknowledged_on", "");
        return out;
    }

    private static boolean isYes(String value) {
        return "yes".equalsIgnoreCase(value == null ? "" : value.trim());
    }

    private static int parseId(String value) {
        String digits = value == null ? "" : value.trim().split("\\.")[0];
        if (digits.isEmpty()) {
            return 0;
        }
        try {
            return Integer.parseInt(digits);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private static String text(Object value) {
        if (value == null) {
            return "";
        }
        String s = String.valueOf(value).trim();
        return "null".equalsIgnoreCase(s) ? "" : s;
    }
}
