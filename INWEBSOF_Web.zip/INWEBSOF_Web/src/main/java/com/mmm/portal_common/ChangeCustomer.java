package com.mmm.portal_common;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.titpl.NativeQuerySupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.config.SystemHibernateConfig;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Change Customer Code autocomplete — single-file controller.
 * Queries {@code ia_user_master.cust_code / cust_name} via system Hibernate session.
 * Client: {@code GET /api/portal/change-customer/autocomplete?value=...}
 */
@RestController
@RequestMapping("/api/portal/change-customer")
public class ChangeCustomer {

    private final SessionFactory sessionFactory;
    private final HibernateFactoryRegistry hibernateRegistry;
    private final Gson gson = new Gson();

    public ChangeCustomer(
            @Qualifier(SystemHibernateConfig.SYSTEM_SF) SessionFactory sessionFactory,
            HibernateFactoryRegistry hibernateRegistry) {
        this.sessionFactory = sessionFactory;
        this.hibernateRegistry = hibernateRegistry;
    }

    private Session session() {
        return sessionFactory.getCurrentSession();
    }

    /**
     * RECORD / SAMPLE ONLY — registry-style query (same pattern as CustomerPayment AS400).
     * Opens session for the named datasource, runs SQL, closes session inside executeQuery.
     * Not used by autocomplete endpoints; kept so the pattern is visible next to session()+listAsMaps.
     *
     * <pre>
     * List&lt;Map&lt;String, Object&gt;&gt; rows = NativeQuerySupport.executeQuery(
     *         hibernateRegistry, HibernateFactoryRegistry.AS400, sql);
     * </pre>
     */
    @SuppressWarnings("unused")
    private List<Map<String, Object>> sampleAs400ExecuteQuery(String custCode) {
        String safe = custCode == null ? "" : custCode.replace("'", "''");
        // Stub SQL (no rows). Replace with real AS400 SQL when needed.
        String sql =
                "SELECT "
                + "  CAST('" + safe + "' AS VARCHAR(20)) AS CUST_CODE, "
                + "  CAST('' AS VARCHAR(100)) AS CUST_NAME "
                + "FROM SYSIBM.SYSDUMMY1 "
                + "WHERE 1 = 0";
        List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
                hibernateRegistry, HibernateFactoryRegistry.AS400, sql);
        return rows;
    }

    /**
     * jQuery UI autocomplete source. Request param {@code value} = typed term only.
     * Response {@code data} is a list of maps: code, name, loginId,
     * value ("code - name").
     */
    @GetMapping("/autocomplete")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String autocomplete(HttpServletRequest request, @RequestParam("value") String value) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession httpSession = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(httpSession)) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }
        if (!UserSessionSupport.canChangeCustomer(httpSession)) {
            result.SetError(-1, "failure", "Change Customer is not permitted");
            return gson.toJson(result);
        }
        try {
            String q = value == null ? "" : value.trim();
            String like = q.isEmpty() ? "%" : "%" + q + "%";
            String sql = """
                    select top 50
                           isnull(u.cust_code,'') as code,
                           isnull(u.cust_name,'') as name,
                           min(isnull(u.enl_id,'')) as loginId,
                           (isnull(u.cust_code,'') + ' - ' + isnull(u.cust_name,'')) as value
                    from ia_user_master u
                    inner join dbo.ia_user_type ut
                            on ut.internal_code = try_cast(u.u_user_type as int)
                    where isnull(u.active,'Yes') = 'Yes'
                      and isnull(u.cust_code,'') <> ''
                      and lower(ltrim(rtrim(isnull(ut.user_type_name,'')))) = 'customer'
                      and (isnull(u.cust_code,'') like :like
                           or isnull(u.cust_name,'') like :like)
                    group by isnull(u.cust_code,''), isnull(u.cust_name,'')
                    order by code
                    """;
            System.out.println("Change Customer autocomplete SQL:\n" + sql.replace(":like", sqlLiteral(like)));
            Map<String, Object> params = Map.of("like", like);
            Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
            scalars.put("code", StandardBasicTypes.STRING);
            scalars.put("name", StandardBasicTypes.STRING);
            scalars.put("loginId", StandardBasicTypes.STRING);
            scalars.put("value", StandardBasicTypes.STRING);
            List<Map<String, Object>> rows =
                    NativeQuerySupport.listAsMaps(session(), sql, params, scalars);
            result.SetSuccess("success", rows);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Customer search failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    /**
     * Test/check-only variant of autocomplete: same ia_user_master search and response shape
     * (code, name, value only), but LIKE is embedded in SQL (no Hibernate bind parameters).
     * Client: {@code GET /api/portal/change-customer/autocomplete-without-map?value=...}
     */
    @GetMapping("/autocomplete-without-map")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String autocompleteWithoutMap(HttpServletRequest request, @RequestParam("value") String value) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession httpSession = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(httpSession)) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }
        if (!UserSessionSupport.canChangeCustomer(httpSession)) {
            result.SetError(-1, "failure", "Change Customer is not permitted");
            return gson.toJson(result);
        }
        try {
            String q = value == null ? "" : value.trim();
            // Test-only: embed LIKE literal (escape single quotes for T-SQL). Prefer /autocomplete in production.
            String likeLiteral = q.isEmpty()
                    ? "'%'"
                    : "'%" + q.replace("'", "''") + "%'";
            String sql =
                    "select top 50 "
                    + "isnull(u.cust_code,'') as code, "
                    + "isnull(u.cust_name,'') as name, "
                    + "min(isnull(u.enl_id,'')) as loginId, "
                    + "(isnull(u.cust_code,'') + ' - ' + isnull(u.cust_name,'')) as value "
                    + "from ia_user_master u "
                    + "inner join dbo.ia_user_type ut "
                    + "on ut.internal_code = try_cast(u.u_user_type as int) "
                    + "where isnull(u.active,'Yes') = 'Yes' "
                    + "and isnull(u.cust_code,'') <> '' "
                    + "and lower(ltrim(rtrim(isnull(ut.user_type_name,'')))) = 'customer' "
                    + "and (isnull(u.cust_code,'') like " + likeLiteral + " "
                    + "or isnull(u.cust_name,'') like " + likeLiteral + ") "
                    + "group by isnull(u.cust_code,''), isnull(u.cust_name,'') "
                    + "order by code";
            System.out.println("Change Customer autocomplete-without-map SQL:\n" + sql);
            Map<String, org.hibernate.type.BasicTypeReference<?>> scalars = new LinkedHashMap<>();
            scalars.put("code", StandardBasicTypes.STRING);
            scalars.put("name", StandardBasicTypes.STRING);
            scalars.put("loginId", StandardBasicTypes.STRING);
            scalars.put("value", StandardBasicTypes.STRING);
            List<Map<String, Object>> rows =
                    NativeQuerySupport.listAsMapsDirectQuery(session(), sql, scalars);
            result.SetSuccess("success", rows);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Customer search failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    /**
     * TEST-ONLY: autocomplete without Map bind params AND without any scalar registration.
     * Embeds LIKE literal in SQL; rows via NativeQuerySupport.listAsMapsDirectQueryNoScalars
     * (JDBC ResultSet column labels - no addScalar / no scalars map).
     * Client: {@code GET /api/portal/change-customer/autocomplete-without-map-no-scalars?value=...}
     * Prefer {@code /autocomplete} in production. Existing {@code /autocomplete-without-map} unchanged.
     */
    @GetMapping("/autocomplete-without-map-no-scalars")
    @Transactional(readOnly = true, transactionManager = SystemHibernateConfig.SYSTEM_TX)
    public String autocompleteWithoutMapNoScalars(HttpServletRequest request, @RequestParam("value") String value) {
        ResponseDataGeneric result = new ResponseDataGeneric();
        HttpSession httpSession = request.getSession(false);
        if (!UserSessionSupport.isLoggedIn(httpSession)) {
            result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure",
                    UserSessionSupport.SESSION_EXPIRED_MESSAGE);
            return gson.toJson(result);
        }
        if (!UserSessionSupport.canChangeCustomer(httpSession)) {
            result.SetError(-1, "failure", "Change Customer is not permitted");
            return gson.toJson(result);
        }
        try {
            String q = value == null ? "" : value.trim();
            // Test-only: embed LIKE literal (escape single quotes for T-SQL). No bind map, no scalars.
            String likeLiteral = q.isEmpty()
                    ? "'%'"
                    : "'%" + q.replace("'", "''") + "%'";
            String sql =
                    "select top 50 "
                    + "isnull(u.cust_code,'') as code, "
                    + "isnull(u.cust_name,'') as name, "
                    + "min(isnull(u.enl_id,'')) as loginId, "
                    + "(isnull(u.cust_code,'') + ' - ' + isnull(u.cust_name,'')) as value "
                    + "from ia_user_master u "
                    + "inner join dbo.ia_user_type ut "
                    + "on ut.internal_code = try_cast(u.u_user_type as int) "
                    + "where isnull(u.active,'Yes') = 'Yes' "
                    + "and isnull(u.cust_code,'') <> '' "
                    + "and lower(ltrim(rtrim(isnull(ut.user_type_name,'')))) = 'customer' "
                    + "and (isnull(u.cust_code,'') like " + likeLiteral + " "
                    + "or isnull(u.cust_name,'') like " + likeLiteral + ") "
                    + "group by isnull(u.cust_code,''), isnull(u.cust_name,'') "
                    + "order by code";
            System.out.println("Change Customer autocomplete-without-map-no-scalars SQL:\n" + sql);
            List<Map<String, Object>> rows =
                    NativeQuerySupport.listAsMapsDirectQueryNoScalars(session(), sql);
            result.SetSuccess("success", rows);
        } catch (Exception ex) {
            result.SetError(-1, "failure", "Customer search failed: " + ex.getMessage());
        }
        return gson.toJson(result);
    }

    private static String sqlLiteral(String value) {
        return "'" + (value == null ? "" : value.replace("'", "''")) + "'";
    }
}