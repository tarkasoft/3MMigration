package com.mmm.shoporder;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/customer/shop-order")
public class ShopOrder {

	private static final Logger logger = LoggerFactory.getLogger(ShopOrder.class);
	private static final Gson GSON = new Gson();
	private static final List<Map<String, Object>> MOCK_SHOP_ORDERS = List.of(
			shopOrder("123456", "WH-CHARAN-01", "IA2100000000", 100, List.of(
					item("IA2100000001", 50, 100, 50, "JW100000", "01/01/2026", "N"),
					item("IA2100000002", 40, 40, 40, "JW100001", "02/07/2026", "Y"),
					item("IA2100000003", 10, 11, 11, "JW100001", "02/07/2026", "Y"))),
			shopOrder("123457", "WH-METRO-02", "IA2100000200", 80, List.of(
					item("IA2100000201", 30, 35, 30, "JW200010", "15/08/2026", "N"),
					item("IA2100000202", 25, 25, 25, "JW200011", "16/08/2026", "Y"))),
			shopOrder("123458", "WH-CHARAN-01", "IA2100000030", 120, List.of(
					item("IA2100000031", 60, 60, 55, "JW300020", "21/09/2026", "N"),
					item("IA2100000032", 45, 45, 45, "JW300021", "22/09/2026", "Y"),
					item("IA2100000033", 15, 15, 15, "JW300022", "22/09/2026", "Y"))));

	private final String as400;

	public ShopOrder(@Value("${inpc.shop-order.as400:as400ind}") String as400) {
		this.as400 = as400 == null || as400.isBlank() ? "as400ind" : as400.trim();
	}

	@GetMapping("/autocomplete")
	public String autocomplete(HttpServletRequest request,
			@RequestParam(value = "term", defaultValue = "") String term,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			requireLogin(request, custCode, loginId);
			String search = term == null ? "" : term.trim().toLowerCase(Locale.ROOT);
			List<Map<String, Object>> matches = new ArrayList<>();
			if (!search.isEmpty()) {
				for (Map<String, Object> row : MOCK_SHOP_ORDERS) {
					if (String.valueOf(row.get("shopOrder")).toLowerCase(Locale.ROOT).contains(search)) {
						Map<String, Object> suggestion = new LinkedHashMap<>();
						suggestion.put("shopOrder", row.get("shopOrder"));
						suggestion.put("jwWarehouseCode", row.get("jwWarehouseCode"));
						suggestion.put("finishedGood", row.get("finishedGood"));
						suggestion.put("requestedQuantity", row.get("requestedQuantity"));
						matches.add(suggestion);
					}
				}
			}
			logger.debug("Serving mock Shop Order autocomplete; configured AS/400 pool is {}", as400);
			result.SetSuccess("success", matches);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	@GetMapping("/details/{shopOrder}")
	public String details(HttpServletRequest request, @PathVariable String shopOrder,
			@RequestParam(value = "custCode", required = false) String custCode,
			@RequestParam(value = "loginId", required = false) String loginId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		try {
			requireLogin(request, custCode, loginId);
			Map<String, Object> match = MOCK_SHOP_ORDERS.stream()
					.filter(row -> shopOrder.equals(String.valueOf(row.get("shopOrder"))))
					.findFirst()
					.orElseThrow(() -> new IllegalArgumentException("Shop order was not found."));
			Map<String, Object> details = new LinkedHashMap<>();
			details.put("shopOrder", match.get("shopOrder"));
			details.put("jwWarehouseCode", match.get("jwWarehouseCode"));
			details.put("finishedGood", match.get("finishedGood"));
			details.put("requestedQuantity", match.get("requestedQuantity"));
			details.put("items", match.get("items"));
			logger.debug("Serving mock Shop Order details; configured AS/400 pool is {}", as400);
			result.SetSuccess("success", details);
		} catch (Exception ex) {
			return error(result, ex);
		}
		return GSON.toJson(result);
	}

	private static Map<String, Object> shopOrder(String shopOrder, String warehouse, String finishedGood,
			int requestedQuantity, List<Map<String, Object>> items) {
		Map<String, Object> row = new LinkedHashMap<>();
		row.put("shopOrder", shopOrder);
		row.put("jwWarehouseCode", warehouse);
		row.put("finishedGood", finishedGood);
		row.put("requestedQuantity", requestedQuantity);
		row.put("items", items);
		return Map.copyOf(row);
	}

	private static Map<String, Object> item(String childSku, int requiredQuantity, int issueQuantity,
			int consumedQuantity, String dcNumber, String dcDate, String indicator) {
		return Map.of(
				"childSku", childSku,
				"requiredQuantity", requiredQuantity,
				"issueQuantity", issueQuantity,
				"consumedQuantity", consumedQuantity,
				"dcNumber", dcNumber,
				"dcDate", dcDate,
				"indicator", indicator);
	}

	private static void requireLogin(HttpServletRequest request, String custCode, String loginId) {
		if (!UserSessionSupport.isLoggedIn(request.getSession(false))) {
			throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		}
		UserSessionSupport.resolveProcedureCustomerContext(request.getSession(false), custCode, loginId);
	}

	private static String error(ResponseDataGeneric result, Exception ex) {
		if (ex instanceof IllegalStateException
				&& UserSessionSupport.SESSION_EXPIRED_MESSAGE.equals(ex.getMessage())) {
			result.SetError(UserSessionSupport.SESSION_EXPIRED_ERROR_CODE, "failure", ex.getMessage());
		} else {
			if (!(ex instanceof IllegalArgumentException)) {
				logger.error("Unable to load Shop Order mock data", ex);
			}
			result.SetError(-1, "failure", ex instanceof IllegalArgumentException
					? ex.getMessage() : "Unable to process Shop Order lookup.");
		}
		return GSON.toJson(result);
	}
}
