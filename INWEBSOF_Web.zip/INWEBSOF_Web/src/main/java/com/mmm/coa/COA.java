package com.mmm.coa;

import static com.mmm.titpl.CommonFunctions.text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.ResponseDataGeneric;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Certificate of Analysis. Stock code and batch look up one file on the
 * COMAGM-style COA share. A miss opens the request form.
 *
 * GET  /api/customer/coa/context
 * GET  /api/customer/coa/sku?phrase=
 * GET  /api/customer/coa/batch?phrase=&stockCode=
 * GET  /api/customer/coa/invoice?phrase=&stockCode=
 * GET  /api/customer/coa/list?stockCode=&batchId=
 * GET  /api/customer/coa/file?name=
 * POST /api/customer/coa/request
 */
@RestController
@RequestMapping("/api/customer/coa")
public class COA {

	private static final Logger logger = LoggerFactory.getLogger(COA.class);
	private final CoaSql sql;
	private final Gson gson = new Gson();

	public COA(
			HibernateFactoryRegistry registry,
			@Value("${inpc.coa.app-code:COAINPC}") String appCode,
			@Value("${inpc.coa.share-login:COA}") String shareLogin,
			@Value("${inpc.coa.share-search:COAINATTH}") String shareSearch,
			@Value("${inpc.coa.smb-domain:MMM}") String smbDomain) {
		this.sql = new CoaSql(registry, appCode, shareLogin, shareSearch, smbDomain);
	}

	@GetMapping("/context")
	public String context(HttpServletRequest request) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			return expired(result);
		}
		Map<String, Object> data = new LinkedHashMap<>();
		data.put("custCode", text(session.getAttribute(UserSessionSupport.CUST_CODE)));
		data.put("loginId", text(session.getAttribute(UserSessionSupport.LOGIN_ID)));
		data.put("email", text(session.getAttribute(UserSessionSupport.LOGIN_USER_EMAIL)));
		data.put("userType", text(session.getAttribute(UserSessionSupport.LOGIN_USER_TYPE)));
		data.put("reportTab", CoaSql.canDownloadReports(session));
		result.SetSuccess("success", data);
		return gson.toJson(result);
	}

	@GetMapping("/sku")
	public String sku(HttpServletRequest request, @RequestParam("phrase") String phrase) {
		return suggestions(request, phrase, (session, login) -> sql.skuSuggestions(phrase, login.custCode(), login.customer()));
	}

	@GetMapping("/batch")
	public String batch(
			HttpServletRequest request,
			@RequestParam("phrase") String phrase,
			@RequestParam(value = "stockCode", required = false) String stockCode) {
		return suggestions(request, phrase, (session, login) -> sql.batchSuggestions(phrase, stockCode));
	}

	@GetMapping("/invoice")
	public String invoice(
			HttpServletRequest request,
			@RequestParam("phrase") String phrase,
			@RequestParam(value = "stockCode", required = false) String stockCode) {
		return suggestions(request, phrase, (session, login) -> sql.invoiceSuggestions(phrase, stockCode, login.custCode(), login.customer()));
	}

	@GetMapping("/list")
	public String list(
			HttpServletRequest request,
			@RequestParam("stockCode") String stockCode,
			@RequestParam("batchId") String batchId) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			return expired(result);
		}
		String sku = stockCode == null ? "" : stockCode.trim();
		String batch = batchId == null ? "" : batchId.trim();
		if (sku.isEmpty() || batch.isEmpty()) {
			result.SetError(-1, "failure", "Stock code and batch id are required");
			return gson.toJson(result);
		}
		try {
			LoginView login = login(session);
			List<Map<String, Object>> found = sql.documents(sku, batch);
			List<Map<String, Object>> rows = new ArrayList<>();
			for (Map<String, Object> item : found) {
				Map<String, Object> row = new LinkedHashMap<>();
				row.put("fileName", text(CoaSql.cell(item, "file_name")));
				row.put("skuCode", text(CoaSql.cell(item, "sku_code")));
				row.put("batchCode", text(CoaSql.cell(item, "batch_code")));
				if (!text(row.get("fileName")).isEmpty()) {
					rows.add(row);
				}
			}
			if (!rows.isEmpty()) {
				sql.insertCustomerLog(login.custCode(), "", sku, batch, "Valid Case", "File Found", login.loginId());
			}
			Map<String, Object> data = new LinkedHashMap<>();
			data.put("rows", rows);
			data.put("count", rows.size());
			data.put("mandatory", CoaSql.mandatorySku(sku));
			result.SetSuccess("success", data);
		} catch (Exception ex) {
			logger.error("Unable to look up COA", ex);
			result.SetError(-1, "failure", "Unable to look up the certificate");
		}
		return gson.toJson(result);
	}

	@GetMapping("/file")
	public ResponseEntity<byte[]> file(HttpServletRequest request, @RequestParam("name") String name) {
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		String safeName = safeFileName(name);
		if (safeName.isEmpty()) {
			return ResponseEntity.badRequest().build();
		}
		try {
			byte[] body = sql.readShareFile(safeName);
			MediaType type = safeName.toLowerCase(Locale.ROOT).endsWith(".pdf")
					? MediaType.APPLICATION_PDF
					: MediaType.APPLICATION_OCTET_STREAM;
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(safeName).build().toString())
					.contentType(type)
					.body(body);
		} catch (Exception ex) {
			logger.error("Unable to download COA {}", safeName, ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	@PostMapping("/request")
	public String request(
			HttpServletRequest request,
			@RequestParam("stockCode") String stockCode,
			@RequestParam("batchId") String batchId,
			@RequestParam("invoiceNo") String invoiceNo,
			@RequestParam("invoiceDate") String invoiceDate,
			@RequestParam("message") String message,
			@RequestParam(value = "file", required = false) MultipartFile file) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			return expired(result);
		}
		LoginView login = login(session);
		String email = text(session.getAttribute(UserSessionSupport.LOGIN_USER_EMAIL));
		String sku = stockCode == null ? "" : stockCode.trim();
		String batch = batchId == null ? "" : batchId.trim();
		String invoice = invoiceNo == null ? "" : invoiceNo.trim();
		String date = invoiceDate == null ? "" : invoiceDate.trim();
		String remarks = message == null ? "" : message.trim();
		if (email.isEmpty()) {
			result.SetError(-1, "failure", "Email id not found. Please contact Sales Rep.");
			return gson.toJson(result);
		}
		if (sku.isEmpty() || batch.isEmpty() || invoice.isEmpty() || date.isEmpty() || remarks.isEmpty()) {
			result.SetError(-1, "failure", "Invoice, date, stock code, batch, and message are required");
			return gson.toJson(result);
		}
		boolean uploaded = file != null && !file.isEmpty();
		if (CoaSql.mandatorySku(sku) && !uploaded) {
			result.SetError(-1, "failure", "Please upload the photocopy of the carton box label");
			return gson.toJson(result);
		}
		try {
			String customerName = sql.customerName(login.custCode());
			String internal = sql.internalMail();
			String subject = "COA Request for SKU " + sku + " and Batch# " + batch + ". ";
			String body = mailBody(login.custCode(), customerName, email, invoice, date, sku, batch, remarks);
			byte[] attachment = uploaded ? file.getBytes() : null;
			String fileName = uploaded ? file.getOriginalFilename() : "";
			String mailResult = sql.sendMail(email, internal, subject, body, fileName, attachment);
			sql.insertCustomerLog(login.custCode(), invoice, sku, batch, "InValid Case", remarks, login.loginId());
			if ("Mail Sent Successfully".equals(mailResult)) {
				result.SetSuccess("success", "Your Request is submitted successfully.");
			} else {
				result.SetError(-1, "failure", mailResult);
			}
		} catch (Exception ex) {
			logger.error("Unable to submit COA request", ex);
			result.SetError(-1, "failure", "Unable to submit the request");
		}
		return gson.toJson(result);
	}

	private String suggestions(HttpServletRequest request, String phrase, SuggestionQuery query) {
		ResponseDataGeneric result = new ResponseDataGeneric();
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			return expired(result);
		}
		if (phrase == null || phrase.trim().isEmpty()) {
			result.SetSuccess("success", List.of());
			return gson.toJson(result);
		}
		try {
			LoginView login = login(
					session,
					request.getParameter("custCode"),
					request.getParameter("loginId"));
			result.SetSuccess("success", query.run(session, login));
		} catch (Exception ex) {
			logger.error("COA suggestion failed", ex);
			result.SetError(-1, "failure", "Unable to search");
		}
		return gson.toJson(result);
	}

	private String expired(ResponseDataGeneric result) {
		result.SetError(
				UserSessionSupport.SESSION_EXPIRED_ERROR_CODE,
				"failure",
				UserSessionSupport.SESSION_EXPIRED_MESSAGE);
		return gson.toJson(result);
	}

	private static LoginView login(HttpSession session) {
		return login(session, "", "");
	}

	private static LoginView login(HttpSession session, String custCode, String loginId) {
		UserSessionSupport.ProcedureCustomerContext context =
				UserSessionSupport.resolveProcedureCustomerContext(session, custCode, loginId);
		String userType = text(session.getAttribute(UserSessionSupport.LOGIN_USER_TYPE));
		return new LoginView(
				context.custCode(),
				context.loginId(),
				CoaSql.isCustomer(userType) || context.overridden());
	}

	private static String mailBody(String custCode, String custName, String email, String invoice, String date,
			String sku, String batch, String remarks) {
		String cell = "border:1px solid black;text-align:left;padding:10px;";
		String label = cell + "background-color:#F0F7ED;";
		return "Dear Customer,<br/><br/>Thanks for reaching out to us. We have received your request for COA for the below SKU and Batch number. "
				+ "Our Customer Service team will revert to you.<br/><br/><table style='border-collapse:collapse;width:50%'>"
				+ row("Customer Code", custCode + "-" + custName, label, cell)
				+ row("Customer Email", email, label, cell)
				+ row("Invoice No", invoice, label, cell)
				+ row("Invoice Date", date, label, cell)
				+ row("SKU Code", sku, label, cell)
				+ row("Batch ID", batch, label, cell)
				+ row("Customer Remarks", remarks, label, cell)
				+ "</table><br/><br/>Thanks &amp; Regards,<br/>3M India";
	}

	private static String row(String name, String value, String label, String cell) {
		return "<tr><td style='" + label + "'>" + escape(name) + "</td><td style='" + cell + "'>" + escape(value) + "</td></tr>";
	}

	private static String escape(String value) {
		return value == null ? "" : value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
	}

	private static String safeFileName(String name) {
		String value = name == null ? "" : name.trim();
		if (value.isEmpty() || value.length() > 255 || value.contains("..") || value.indexOf('/') >= 0 || value.indexOf('\\') >= 0) {
			return "";
		}
		return value;
	}

	private record LoginView(String custCode, String loginId, boolean customer) {}

	@FunctionalInterface
	private interface SuggestionQuery {
		List<Map<String, Object>> run(HttpSession session, LoginView login);
	}
}
