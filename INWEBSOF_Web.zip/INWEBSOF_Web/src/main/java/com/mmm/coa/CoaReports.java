package com.mmm.coa;

import static com.mmm.titpl.CommonFunctions.sqlDate;
import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * COA Reports. Available only when the session roles include
 * INPC_COA_REPORT_DOWNLOAD.
 *
 * GET /api/customer/coa/report/log?from=&to=&type=Success|Error
 * GET /api/customer/coa/report/errors?from=&to=
 */
@RestController
@RequestMapping("/api/customer/coa/report")
public class CoaReports {

	private static final Logger logger = LoggerFactory.getLogger(CoaReports.class);
	private static final MediaType XLSX = MediaType.parseMediaType(
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	private final CoaSql sql;

	public CoaReports(
			HibernateFactoryRegistry registry,
			@Value("${inpc.coa.app-code:COAINPC}") String appCode,
			@Value("${inpc.coa.share-login:COA}") String shareLogin,
			@Value("${inpc.coa.share-search:COAINATTH}") String shareSearch,
			@Value("${inpc.coa.smb-domain:MMM}") String smbDomain) {
		this.sql = new CoaSql(registry, appCode, shareLogin, shareSearch, smbDomain);
	}

	@GetMapping("/log")
	public ResponseEntity<byte[]> log(
			HttpServletRequest request,
			@RequestParam(value = "from", required = false) String from,
			@RequestParam(value = "to", required = false) String to,
			@RequestParam("type") String type) {
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		if (!CoaSql.canDownloadReports(session)) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
		}
		if (!"Success".equalsIgnoreCase(type) && !"Error".equalsIgnoreCase(type)) {
			return ResponseEntity.badRequest().build();
		}
		try {
			List<Map<String, Object>> rows = sql.logReport(
					sqlDate(from, "From date"), sqlDate(to, "To date"), type);
			boolean error = "Error".equalsIgnoreCase(type);
			String[] headers = error
					? new String[] { "Customer Code", "Customer Name", "Invoice No", "SKU#", "Batch ID", "Remarks", "Login ID", "DateTime" }
					: new String[] { "Customer Code", "Customer Name", "SKU#", "Batch ID", "Remarks", "Login ID", "DateTime" };
			String[] fields = error
					? new String[] { "cust_code", "customer_name", "invoice_number", "item_code", "batch_id", "remarks", "login_id", "datetime" }
					: new String[] { "cust_code", "customer_name", "item_code", "batch_id", "remarks", "login_id", "datetime" };
			String fileName = error ? "COA_Error_Report.xlsx" : "COA_Success_Report.xlsx";
			return workbook(fileName, error ? "COA_Error_Report" : "COA_Success_Report", headers, fields, rows);
		} catch (IllegalArgumentException ex) {
			return ResponseEntity.badRequest().build();
		} catch (Exception ex) {
			logger.error("Unable to build COA report", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	@GetMapping("/errors")
	public ResponseEntity<byte[]> errors(
			HttpServletRequest request,
			@RequestParam(value = "from", required = false) String from,
			@RequestParam(value = "to", required = false) String to) {
		HttpSession session = request.getSession(false);
		if (!UserSessionSupport.isLoggedIn(session)) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		if (!CoaSql.canDownloadReports(session)) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
		}
		try {
			List<Map<String, Object>> rows = sql.errorFileReport(
					sqlDate(from, "From date"), sqlDate(to, "To date"));
			return workbook(
					"coa_error_data.xlsx",
					"coa_error_data",
					new String[] { "File Name", "Reason", "File Created Date" },
					new String[] { "file_name", "reason", "datetime" },
					rows);
		} catch (IllegalArgumentException ex) {
			return ResponseEntity.badRequest().build();
		} catch (Exception ex) {
			logger.error("Unable to build COA error-file report", ex);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
		}
	}

	private static ResponseEntity<byte[]> workbook(String fileName, String sheetName, String[] headers, String[] fields,
			List<Map<String, Object>> rows) throws Exception {
		try (XSSFWorkbook book = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			Sheet sheet = book.createSheet(sheetName);
			Row head = sheet.createRow(0);
			for (int i = 0; i < headers.length; i++) {
				head.createCell(i).setCellValue(headers[i]);
			}
			int line = 1;
			for (Map<String, Object> row : rows) {
				Row excel = sheet.createRow(line++);
				for (int i = 0; i < fields.length; i++) {
					excel.createCell(i).setCellValue(text(CoaSql.cell(row, fields[i])));
				}
			}
			for (int i = 0; i < headers.length; i++) {
				sheet.autoSizeColumn(i);
			}
			book.write(out);
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(fileName).build().toString())
					.contentType(XLSX)
					.body(out.toByteArray());
		}
	}

}
