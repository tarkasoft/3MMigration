package com.mmm.coa;

import static com.mmm.titpl.CommonFunctions.text;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mmm.authentication.UserSessionSupport;
import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.share.DiskShare;
import com.mmm.authentication.UserSessionSupport;
import com.mmm.config.HibernateFactoryRegistry;
import com.mmm.titpl.NativeQuerySupport;

import jakarta.mail.Message;
import jakarta.mail.Multipart;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import jakarta.servlet.http.HttpSession;

/**
 * dINPC access for Certificate of Analysis. Sales and COA tables use the
 * existing infoapps pool. The share row comes from AS400 CMW010S.
 */
final class CoaSql {

	static final String REPORT_ROLE = "INPC_COA_REPORT_DOWNLOAD";
	private static final Logger logger = LoggerFactory.getLogger(CoaSql.class);
	private static final String SMTP_HOST = "mailserv.mmm.com";
	private static final String MAIL_FROM = "3msupport.in@mmm.com";

	private final HibernateFactoryRegistry registry;
	private final String appCode;
	private final String shareLogin;
	private final String shareSearch;
	private final String smbDomain;

	CoaSql(HibernateFactoryRegistry registry, String appCode, String shareLogin, String shareSearch, String smbDomain) {
		this.registry = registry;
		this.appCode = appCode == null ? "COAINPC" : appCode.trim();
		this.shareLogin = shareLogin == null ? "COA" : shareLogin.trim();
		this.shareSearch = shareSearch == null ? "COAINATTH" : shareSearch.trim();
		this.smbDomain = smbDomain == null ? "MMM" : smbDomain.trim();
	}

	static boolean canDownloadReports(HttpSession session) {
		if (session == null) {
			return false;
		}
		Object raw = session.getAttribute(UserSessionSupport.LOGIN_USER_ROLES);
		if (raw == null) {
			return false;
		}
		for (String role : String.valueOf(raw).split(",")) {
			if (REPORT_ROLE.equalsIgnoreCase(role.trim())) {
				return true;
			}
		}
		return false;
	}

	static boolean isCustomer(String userType) {
		String value = userType == null ? "" : userType.trim();
		return "CUST".equalsIgnoreCase(value) || "Customer".equalsIgnoreCase(value);
	}

	List<Map<String, Object>> skuSuggestions(String phrase, String custCode, boolean customer) {
		String sql = "select distinct top 10 IPROD as value, '0' as cc_desc, "
				+ "case when left(IPROD,2) in ('Im','Ie','Is','IA') then 1 else 0 end as is_mandatory "
				+ "from SO_ItemMaster i inner join SO_Sales s on s.OBPROD = i.IPROD "
				+ "where IPROD like ?";
		List<Object> args = new ArrayList<>();
		args.add(like(phrase));
		if (customer) {
			sql += " and cast(OBMCUS as varchar) = ?";
			args.add(custCode);
		}
		return query(sql, args.toArray());
	}

	List<Map<String, Object>> batchSuggestions(String phrase, String stockCode) {
		String sql = "select distinct top 10 ILOT as value, ILDATE as name from EIL where ILOT like ?";
		List<Object> args = new ArrayList<>();
		args.add(like(phrase));
		if (stockCode != null && !stockCode.isBlank()) {
			sql += " and IPROD = ?";
			args.add(stockCode.trim());
		}
		return query(sql, args.toArray());
	}

	List<Map<String, Object>> invoiceSuggestions(String phrase, String stockCode, String custCode, boolean customer) {
		String sql = "select distinct top 10 OBINV# as value, OBINVD as name from SO_Sales "
				+ "where OBINV# like ? and OBOTYP not in ('1','C','D','9')";
		List<Object> args = new ArrayList<>();
		args.add(like(phrase));
		if (stockCode != null && !stockCode.isBlank()) {
			sql += " and OBPROD = ?";
			args.add(stockCode.trim());
		}
		if (customer) {
			sql += " and cast(OBMCUS as varchar) = ?";
			args.add(custCode);
		}
		return query(sql, args.toArray());
	}

	List<Map<String, Object>> documents(String stockCode, String batchId) {
		String sql = "select top 1 file_name, sku_code, batch_code from coa_file_data "
				+ "where sku_code = ? and batch_code = ?";
		return query(sql, stockCode, batchId);
	}

	List<Map<String, Object>> logReport(String fromDate, String toDate, String type) {
		StringBuilder sql = new StringBuilder(
				"select customer as cust_code, sc.CNME as customer_name, invoice_number, item_code, batch_id, remarks, login_id, "
						+ "convert(varchar, created_date, 126) as datetime "
						+ "from coa_customer_log cl "
						+ "left join SO_CustomerMaster sc on cast(sc.CCUST as varchar) = customer where 1 = 1");
		List<Object> args = new ArrayList<>();
		appendDate(sql, args, "created_date", fromDate, toDate);
		if ("Success".equalsIgnoreCase(type)) {
			sql.append(" and type = 'Valid Case'");
		} else if ("Error".equalsIgnoreCase(type)) {
			sql.append(" and type = 'InValid Case'");
		}
		return query(sql.toString(), args.toArray());
	}

	List<Map<String, Object>> errorFileReport(String fromDate, String toDate) {
		StringBuilder sql = new StringBuilder(
				"select file_name, reason, convert(varchar, file_created_date, 20) as datetime "
						+ "from coa_error_data where 1 = 1");
		List<Object> args = new ArrayList<>();
		appendDate(sql, args, "file_created_date", fromDate, toDate);
		sql.append(" order by file_created_date desc");
		return query(sql.toString(), args.toArray());
	}

	void insertCustomerLog(String customer, String invoiceNumber, String itemCode, String batchCode,
			String type, String remarks, String loginId) {
		String sql = "insert into coa_customer_log(customer, invoice_number, item_code, batch_id, type, remarks, created_date, login_id) "
				+ "values (?,?,?,?,?,?," + UserSessionSupport.sessionDate() + ",?)";
		update(sql, customer, invoiceNumber, itemCode, batchCode, type, remarks, loginId);
	}

	String customerName(String custCode) {
		List<Map<String, Object>> rows = query(
				"select CNME as cust_name from SO_CustomerMaster where rtrim(ccust) = ?",
				custCode);
		return rows.isEmpty() ? "" : text(rows.get(0).get("cust_name"));
	}

	String internalMail() {
		List<Map<String, Object>> rows = query("select to_email from coa_mail_setup where 1 = 1");
		return rows.isEmpty() ? "" : text(rows.get(0).get("to_email"));
	}

	String sendMail(String customerEmail, String internalCc, String subject, String htmlBody,
			String fileName, byte[] attachment) {
		String result = "Mail Sent Successfully";
		try {
			Properties props = new Properties();
			props.put("mail.smtp.host", SMTP_HOST);
			jakarta.mail.Session mailSession = jakarta.mail.Session.getInstance(props);
			MimeMessage message = new MimeMessage(mailSession);
			message.setFrom(new InternetAddress(MAIL_FROM));
			addRecipients(message, Message.RecipientType.TO, customerEmail);
			addRecipients(message, Message.RecipientType.CC, internalCc);
			message.setSentDate(new Date());
			message.setSubject(subject);
			if (attachment != null && attachment.length > 0 && fileName != null && !fileName.isBlank()) {
				MimeBodyPart text = new MimeBodyPart();
				text.setContent(htmlBody, "text/html; charset=UTF-8");
				MimeBodyPart file = new MimeBodyPart();
				file.setFileName(fileName);
				file.setContent(attachment, "application/octet-stream");
				Multipart multipart = new MimeMultipart();
				multipart.addBodyPart(text);
				multipart.addBodyPart(file);
				message.setContent(multipart);
			} else {
				message.setContent(htmlBody, "text/html; charset=UTF-8");
			}
			Transport.send(message);
		} catch (Exception ex) {
			result = ex.getMessage() == null ? "Mail failed" : ex.getMessage();
			logger.error("COA mail failed", ex);
		}
		insertMailHistory("COA File Not Found", customerEmail, internalCc, subject, result);
		return result;
	}

	byte[] readShareFile(String fileName) throws Exception {
		ShareLocation location = locateShare();
		byte[][] holder = new byte[1][];
		SmbConfig config = SmbConfig.builder()
				.withDialects(SMB2Dialect.SMB_3_1_1)
				.withEncryptData(true)
				.build();
		SMBClient client = new SMBClient(config);
		try (Connection connection = client.connect(location.host)) {
			AuthenticationContext auth = new AuthenticationContext(
					location.username, location.password.toCharArray(), smbDomain);
			com.hierynomus.smbj.session.Session smbSession = connection.authenticate(auth);
			try (DiskShare share = (DiskShare) smbSession.connectShare(location.share)) {
				String remote = location.folder.isEmpty() ? fileName : location.folder + "/" + fileName;
				try (com.hierynomus.smbj.share.File remoteFile = share.openFile(
						remote,
						EnumSet.of(AccessMask.GENERIC_READ),
						null,
						SMB2ShareAccess.ALL,
						SMB2CreateDisposition.FILE_OPEN,
						null);
						InputStream in = remoteFile.getInputStream();
						ByteArrayOutputStream out = new ByteArrayOutputStream()) {
					in.transferTo(out);
					holder[0] = out.toByteArray();
				}
			} finally {
				smbSession.close();
			}
		} finally {
			client.close();
		}
		if (holder[0] == null) {
			throw new IllegalStateException("COA file was not read");
		}
		return holder[0];
	}

	static boolean mandatorySku(String stockCode) {
		String value = stockCode == null ? "" : stockCode.trim();
		if (value.length() < 2) {
			return false;
		}
		String prefix = value.substring(0, 2);
		return "Im".equalsIgnoreCase(prefix) || "Ie".equalsIgnoreCase(prefix)
				|| "Is".equalsIgnoreCase(prefix) || "IA".equalsIgnoreCase(prefix);
	}

	private ShareLocation locateShare() {
		logSql("AS400 procedure call", "{call BPCSLCLIN.CMW010S(?,?,?)}",
				new Object[] { appCode, shareLogin, shareSearch });
		List<Map<String, Object>> rows = NativeQuerySupport.executeProcedure(
				registry,
				HibernateFactoryRegistry.AS400,
				"{call BPCSLCLIN.CMW010S(?,?,?)}",
				appCode, shareLogin, shareSearch);
		ShareLocation location = null;
		for (Map<String, Object> row : rows) {
			ShareLocation next = parseShare(text(cell(row, "NWPATH")));
			next.username = text(cell(row, "NWLID"));
			next.password = text(cell(row, "NWPWD"));
			if (!next.username.isEmpty() && !next.password.isEmpty()) {
				location = next;
			}
		}
		if (location == null) {
			throw new IllegalStateException("COA share was not returned by CMW010S");
		}
		logger.info("COA share host={} share={} folder={}", location.host, location.share, location.folder);
		return location;
	}

	private List<Map<String, Object>> query(String sql, Object... args) {
		logSql("COA SQL query", sql, args);
		return NativeQuerySupport.executeQuery(
				registry, HibernateFactoryRegistry.INFOAPPS, sql, args);
	}

	private void update(String sql, Object... args) {
		logSql("COA SQL update", sql, args);
		NativeQuerySupport.executeUpdate(
				registry, HibernateFactoryRegistry.INFOAPPS, sql, args);
	}

	private void insertMailHistory(String mailType, String to, String cc, String subject, String response) {
		update("insert into coa_mail_history(mail_type, mail_to, mail_cc, mail_bcc, created_date, mail_response, mail_subject) "
				+ "values (?,?,?,''," + UserSessionSupport.sessionDate() + ",?,?)",
				mailType, to, cc, trim(response, 500), trim(subject, 250));
	}

	private static void appendDate(StringBuilder sql, List<Object> args, String column, String fromDate, String toDate) {
		if (fromDate == null || toDate == null || fromDate.isBlank() || toDate.isBlank()) {
			return;
		}
		sql.append(" and convert(varchar(10), ").append(column).append(", 126) between ? and ?");
		args.add(fromDate);
		args.add(toDate);
	}

	private static String sqlWithValues(String sql, Object[] args) {
		StringBuilder rendered = new StringBuilder();
		int parameterIndex = 0;
		boolean inString = false;
		for (int i = 0; i < sql.length(); i++) {
			char ch = sql.charAt(i);
			if (ch == '\'' && inString && i + 1 < sql.length() && sql.charAt(i + 1) == '\'') {
				rendered.append("''");
				i++;
			} else if (ch == '\'') {
				inString = !inString;
				rendered.append(ch);
			} else if (ch == '?' && !inString && parameterIndex < args.length) {
				Object value = args[parameterIndex++];
				if (value == null) {
					rendered.append("null");
				} else if (value instanceof Number) {
					rendered.append(value);
				} else {
					rendered.append("N'")
							.append(String.valueOf(value).replace("\r", " ").replace("\n", " ").replace("'", "''"))
							.append("'");
				}
			} else {
				rendered.append(ch);
			}
		}
		return rendered.toString();
	}

	private static void logSql(String label, String sql, Object... args) {
		System.out.println(label + ":\n" + sqlWithValues(sql, args));
	}

	private static void addRecipients(MimeMessage message, Message.RecipientType type, String csv) throws Exception {
		if (csv == null || csv.isBlank()) {
			return;
		}
		for (String part : csv.split(",")) {
			if (!part.isBlank()) {
				message.addRecipient(type, new InternetAddress(part.trim()));
			}
		}
	}

	private static String like(String phrase) {
		String value = phrase == null ? "" : phrase.trim().replace("%", "").replace("_", "");
		if (value.length() > 40) {
			value = value.substring(0, 40);
		}
		return "%" + value + "%";
	}

	static Object cell(Map<String, Object> row, String name) {
		if (row == null) {
			return null;
		}
		for (Map.Entry<String, Object> entry : row.entrySet()) {
			if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(name)) {
				return entry.getValue();
			}
		}
		return row.get(name);
	}

	private static ShareLocation parseShare(String rawPath) {
		String raw = rawPath == null ? "" : rawPath.trim();
		if (raw.toLowerCase(Locale.ROOT).startsWith("smb:")) {
			raw = raw.substring(4);
		}
		raw = raw.replace('\\', '/');
		while (raw.startsWith("/")) {
			raw = raw.substring(1);
		}
		while (raw.endsWith("/")) {
			raw = raw.substring(0, raw.length() - 1);
		}
		String[] parts = raw.split("/", 3);
		if (parts.length < 2 || parts[0].isBlank() || parts[1].isBlank()) {
			throw new IllegalStateException("COA path is not a host/share path");
		}
		String host = parts[0];
		int colon = host.indexOf(':');
		if (colon > 0) {
			host = host.substring(0, colon);
		}
		ShareLocation location = new ShareLocation();
		location.host = host;
		location.share = parts[1];
		location.folder = parts.length > 2 ? parts[2] : "";
		return location;
	}

	private static String trim(String value, int max) {
		String text = value == null ? "" : value;
		return text.length() <= max ? text : text.substring(0, max);
	}

	private static final class ShareLocation {
		private String host;
		private String share;
		private String folder;
		private String username;
		private String password;
	}
}
