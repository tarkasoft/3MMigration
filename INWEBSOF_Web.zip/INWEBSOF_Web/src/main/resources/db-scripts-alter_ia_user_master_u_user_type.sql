-- Add u_user_type to ia_user_master (Admin / Customer / Distributor / Customer Service).
-- Run once on system DB (dINSBA / ia_user_master).
IF COL_LENGTH('dbo.ia_user_master', 'u_user_type') IS NULL
BEGIN
    ALTER TABLE dbo.ia_user_master ADD u_user_type nvarchar(50) NULL;
    PRINT 'Added ia_user_master.u_user_type';
END
ELSE
    PRINT 'ia_user_master.u_user_type already exists';
