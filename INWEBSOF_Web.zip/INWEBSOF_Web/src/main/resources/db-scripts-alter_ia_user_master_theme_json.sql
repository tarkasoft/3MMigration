-- INPCV2: persist Switcher theme per user (SQL Server)
-- Run once on system DB (dINSBA / ia_user_master).

IF COL_LENGTH('dbo.ia_user_master', 'theme_json') IS NULL
BEGIN
    ALTER TABLE dbo.ia_user_master ADD theme_json nvarchar(max) NULL;
    PRINT 'Added ia_user_master.theme_json';
END
ELSE
    PRINT 'ia_user_master.theme_json already exists';