-- Add show_welcome to ia_user_master (Yes = show welcome popup every login).
-- Run once on system DB.
IF COL_LENGTH('dbo.ia_user_master', 'show_welcome') IS NULL
BEGIN
    ALTER TABLE dbo.ia_user_master ADD show_welcome nvarchar(10) NULL;
    PRINT 'Added ia_user_master.show_welcome';
END
ELSE
    PRINT 'ia_user_master.show_welcome already exists';