/**
 * Contact Us module.
 * Depends (MainPage script order): js/inpc_loader.js, custom_js/common.js (Common.GetCustCode / Common.GetLoginId / Common.DataTable),
 * then this file via menu js_path before contact_us.html calls LoadContactUs().
 * Uses global $app_url from fw-globals.js — never redefine host here.
 */
ContactUs =
{
	LOADER_TARGET: "m_contact_us",
	API_LIST: "api/portal/contact-us/list",
	_inited: false,

	/**
	 * Page entry: called once HTML is in #home_dashboard.
	 * MainPage loads this file via JS Path before HTML.
	 */
	LoadContactUs: function () {
		ContactUs._ensureTable();
		Common.DataTable.reload("m_contact_us", true);
	},

	_loadPage: function (request) {
		var custCode = String(Common.GetCustCode() || "").trim();
		var loginId = String(Common.GetLoginId() || "").trim();
		var base = $app_url ? String($app_url) : "";
		showLoader("Loading contact list…", ContactUs.LOADER_TARGET);
		var xhr = $.ajax({
			url: base + ContactUs.API_LIST,
			method: "GET",
			dataType: "json",
			data: {
				custCode: custCode,
				loginId: loginId,
				page: request.page,
				pageSize: request.pageSize,
				sortField: request.sortField,
				sortDir: request.sortDir,
				globalFilter: request.globalFilter,
				columnFilters: JSON.stringify(request.columnFilters || {})
			},
			xhrFields: { withCredentials: true }
		});

		xhr.fail(function (failedXhr, status) {
			if (status === "abort") return;
			var httpMsg = "Network error loading contact list";
			if (failedXhr && failedXhr.status) httpMsg += " (HTTP " + failedXhr.status + ")";
			Common.showPageMsg(ContactUs.LOADER_TARGET, httpMsg + ".", "danger");
		});

		var promise = xhr.then(function (json) {
			if (window.inpcIsSessionExpiredPayload(json)) {
				window.inpcHandleSessionExpired(json && (json.message || json.data));
				return $.Deferred().reject(json, "session").promise();
			}
			var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
			if (code === -9 || code === "-9") {
				window.inpcHandleSessionExpired(json && (json.message || json.data));
				return $.Deferred().reject(json, "session").promise();
			}
			if (!json || (code != null && Number(code) !== 0)) {
				var bizMsg = (json && (json.message || json.status)) || "Unable to load contact list.";
				Common.showPageMsg(ContactUs.LOADER_TARGET, bizMsg, "danger");
				return $.Deferred().reject(json, "business").promise();
			}
			Common.clearPageMsg(ContactUs.LOADER_TARGET);
			var payload = json.data != null ? json.data : json;
			var list = Array.isArray(payload) ? payload : ContactUs._pick(payload, ["rows", "items", "contacts", "list"]);
			list = Array.isArray(list) ? list : [];
			var rows = [];
			for (var i = 0; i < list.length; i++) rows.push(ContactUs._normalizeRow(list[i]));
			return {
				rows: rows,
				totalRecords: Number(payload.totalRecords != null ? payload.totalRecords : payload.count) || 0,
				page: Number(payload.page) || request.page,
				pageSize: Number(payload.pageSize) || request.pageSize
			};
		});
		promise.always(function () {
			hideLoader(ContactUs.LOADER_TARGET);
		});
		promise.abort = function () {
			xhr.abort();
		};
		return promise;
	},

	_ensureTable: function () {
		// Always init against current HTML (menu swaps the fragment each visit)
		ContactUs._inited = true;
		Common.DataTable.init({
			rootId: "m_contact_us",
			tableId: "cu_table",
			tbodyId: "cu_tbody",
			infoId: "cu_info",
			pagerId: "cu_pager",
			searchId: "cu_search",
			pageSizeId: "cu_page_size",
			pageSizes: [10, 25, 50, 100],
			pageSize: 10,
			filter_type: "full",
			searchPlaceholder: "Division / contact / email",
			stickyHeader: true,
			fillWidth: true,
			serverSide: true,
			sortField: "div_no",
			sortDir: "asc",
			searchDelay: 300,
			loadData: ContactUs._loadPage,
			cellBorder: "row",
			maxHeight: "420px",
			emptyMessage: "No contacts found",
			columns: [
				{ title: "Div#", field: "div_no", sortable: true, width: 60 },
				{ title: "Division", field: "division", sortable: true, width: 190 },
				{ title: "DivShortName", field: "div_short_name", width: 110 },
				{ title: "Customer Service Contact", field: "customer_service_contact", width: 180 },
				{ title: "Email", field: "email", type: "email", width: 190 },
				{ title: "Mobile", field: "mobile", width: 115 },
				{ title: "Credit Services Contact", field: "credit_services_contact", width: 180 },
				{ title: "Email", field: "email1", type: "email", width: 190 }
			],
			rows: []
		});
	},

	_pick: function (obj, keys) {
		if (!obj || typeof obj !== "object") {
			return undefined;
		}
		for (var i = 0; i < keys.length; i++) {
			if (obj[keys[i]] != null && obj[keys[i]] !== "") {
				return obj[keys[i]];
			}
		}
		return undefined;
	},

	_normalizeRow: function (r) {
		r = r || {};
		return {
			div_no: ContactUs._pick(r, ["div_no", "div", "divNo"]) || "",
			division: ContactUs._pick(r, ["division", "div_name"]) || "",
			div_short_name: ContactUs._pick(r, ["div_short_name", "short", "divShortName"]) || "",
			customer_service_contact: ContactUs._pick(r, ["customer_service_contact", "cs", "csContact"]) || "",
			email: ContactUs._pick(r, ["email", "csEmail"]) || "",
			mobile: ContactUs._pick(r, ["mobile"]) || "",
			credit_services_contact: ContactUs._pick(r, ["credit_services_contact", "credit", "crContact"]) || "",
			email1: ContactUs._pick(r, ["email1", "crEmail"]) || ""
		};
	}
};
