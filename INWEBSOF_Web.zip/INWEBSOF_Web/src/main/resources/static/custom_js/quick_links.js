﻿/**
 * Header menu search (from sunstar_dev quick_links.js).
 * Icon top-right expands a search slide; results open the clicked menu via its onclick.
 */
(function () {
  function ready(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  ready(function () {
    var searchContainer = document.getElementById("searchContainer");
    var searchBtn = document.getElementById("searchBtn");
    var searchInput = document.getElementById("header-search1");
    var resultsEl = document.getElementById("autoComplete_list_1");

    if (!searchContainer || !searchBtn || !searchInput || !resultsEl) {
      return;
    }

    function clearResults() {
      resultsEl.innerHTML = "";
      resultsEl.setAttribute("hidden", "true");
    }

    function closeSearch(clearInput) {
      searchContainer.classList.remove("active");
      clearResults();
      if (clearInput) {
        searchInput.value = "";
      }
      searchInput.blur();
    }

    var mobileSearchBtn = document.getElementById("mobileSearchBtn");
    if (mobileSearchBtn) {
      mobileSearchBtn.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        searchContainer.classList.add("active");
        setTimeout(function () { searchInput.focus(); }, 100);
      });
    }

    searchBtn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var isActive = searchContainer.classList.contains("active");
      if (!isActive) {
        searchContainer.classList.add("active");
        setTimeout(function () {
          searchInput.focus();
        }, 100);
      } else if (String(searchInput.value || "").trim() === "") {
        closeSearch(true);
      } else {
        searchInput.focus();
      }
    });

    document.addEventListener("click", function (e) {
      if (!searchContainer.contains(e.target)) {
        closeSearch(false);
      }
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && searchContainer.classList.contains("active")) {
        closeSearch(true);
      }
    });

    initModuleSearch();
  });

  function initModuleSearch() {
    bindSearch("#header-search1", "#autoComplete_list_1");
  }

  function bindSearch(inputId, resultId) {
    var $searchInput = $(inputId);
    var $searchResults = $(resultId);
    var selectedIndex = -1;
    var searchContainer = document.getElementById("searchContainer");

    function resetSearch(clearInput) {
      $searchResults.empty().attr("hidden", true);
      selectedIndex = -1;
      if (clearInput) {
        $searchInput.val("");
      }
    }

    function highlightText(text, searchTerm) {
      if (!searchTerm) return text;
      var regex = new RegExp("(" + escapeRegExp(searchTerm) + ")", "gi");
      return text.replace(regex, '<strong class="cus-highlight">$1</strong>');
    }

    function escapeRegExp(string) {
      return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }

    function updateSelection() {
      var $items = $searchResults.find(".cus-search-result-item");
      $items.removeClass("selected");
      if (selectedIndex >= 0 && $items.length) {
        $items.eq(selectedIndex).addClass("selected")[0].scrollIntoView({ block: "nearest" });
      }
    }

    function getParentText($item) {
      var parentTexts = [];
      var $current = $item.closest("ul");
      while ($current.length && $current.closest("#side-menu").length) {
        var $parentMenu = $current.prev("a");
        if ($parentMenu.length && $parentMenu.text().trim()) {
          parentTexts.unshift($parentMenu.text().trim());
        }
        $current = $current.parent().closest("ul");
      }
      return parentTexts.length > 0 ? parentTexts.join(" > ") : "";
    }

    function openMenuFromOnclick(onclick) {
      if (!onclick) return;
      try {
        // Menu builders store LoadHtmlFiles(...) / getModulesDetailsNew(...) on onclick.
        // eslint-disable-next-line no-eval
        eval(onclick);
      } catch (err) {
        console.warn("Menu search open failed:", err);
      }
    }

    $searchInput.on("keyup", function (e) {
      if (e.key === "ArrowUp" || e.key === "ArrowDown" || e.key === "Enter") return;

      var searchTerm = $(this).val().toLowerCase().trim();
      resetSearch();
      if (!searchTerm) return;

      $("#side-menu li a.side-menu__item, #side-menu li a").each(function () {
        var $item = $(this);
        var $parentLi = $item.closest("li");
        var text = $item.clone().children().remove().end().text().trim();
        if (!text) {
          text = $item.text().trim();
        }
        var onclick = $item.attr("onclick") || "";

        if (!text) return;

        var isModule =
          !$parentLi.hasClass("has-sub") &&
          ($parentLi.hasClass("slide") || $parentLi.closest("ul.slide-menu").length > 0) &&
          onclick.trim().length > 0;

        if (!isModule) return;

        if (text.toLowerCase().indexOf(searchTerm) === -1) return;

        var icon = $item.find("i").first().attr("class") || "ri-arrow-right-s-line";
        var parentText = getParentText($item);

        var $li = $(
          '<li class="cus-search-result-item">' +
            '<div class="result-content">' +
            '<i class="' +
            icon +
            '"></i>' +
            "<span>" +
            highlightText(text, searchTerm) +
            "</span>" +
            "</div>" +
            (parentText ? '<div class="parent-text">' + parentText + "</div>" : "") +
            "</li>"
        );

        $li.data("onclick", onclick).on("click", function () {
          openMenuFromOnclick($(this).data("onclick"));
          resetSearch(true);
          if (searchContainer) {
            searchContainer.classList.remove("active");
          }
        });

        $searchResults.append($li);
      });

      if ($searchResults.children().length === 0) {
        $searchResults.html('<li class="cus-no-results">No menus found</li>');
      }
      $searchResults.removeAttr("hidden");
    });

    $searchInput.on("keydown", function (e) {
      var $items = $searchResults.find(".cus-search-result-item");
      if (!$items.length) return;

      if (e.key === "ArrowDown") {
        e.preventDefault();
        selectedIndex = selectedIndex < $items.length - 1 ? selectedIndex + 1 : 0;
        updateSelection();
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        selectedIndex = selectedIndex > 0 ? selectedIndex - 1 : $items.length - 1;
        updateSelection();
      }
      if (e.key === "Enter") {
        e.preventDefault();
        if (selectedIndex >= 0) {
          $items.eq(selectedIndex).trigger("click");
        }
      }
      if (e.key === "Escape") {
        resetSearch(true);
        if (searchContainer) {
          searchContainer.classList.remove("active");
        }
      }
    });
  }
})();
