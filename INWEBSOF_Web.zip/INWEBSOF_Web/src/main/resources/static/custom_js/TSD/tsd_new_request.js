/**
 * TSD New Request form — plain jQuery.
 * Load → lookups → warranty type → approver/docs → Draft/Submit (multipart + SMB).
 */
TsdNewRequest = {
	API: "api/customer/tsd",
	HOME: "m_tsd_home",
	custCode: "",
	loginId: "",
	distributor: null,
	states: [],
	productCategories: [],
	prevProductCount: 1,
	editIntCode: 0,
	/** Existing Attachment Details from GET /requests/{id} (edit merge). */
	editDocuments: [],
	saving: false,
	rsmNsmObj: [],
	divisionObj: [],
	_acAjax: {},
	_docsAjax: null,
	_docDownloadAbort: null,
	/** Doc int codes whose previously saved file was cleared in this session (edit). */
	_docRemoved: {},
	_docPreviewUrls: {},

	/**
	 * Active TSD shell (multi-tab safe). Prefer InpcTabs active pane, else visible home.
	 */
	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + TsdNewRequest.HOME) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		if (window.Tsd && typeof Tsd._$home === "function") {
			var $viaTsd = Tsd._$home();
			if ($viaTsd && $viaTsd.length) {
				return $viaTsd;
			}
		}
		var $visible = $("#" + TsdNewRequest.HOME).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $("#" + TsdNewRequest.HOME).first();
	},

	/** Find within #m_tsd_home so duplicate ids in other portal tabs are ignored. */
	_$: function (selector) {
		var $home = TsdNewRequest._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	Load: function () {
		TsdNewRequest.custCode = (window.Tsd && Tsd.custCode) || "";
		TsdNewRequest.loginId = (window.Tsd && Tsd.loginId) || "";
		TsdNewRequest.distributor = null;
		TsdNewRequest.states = [];
		TsdNewRequest.productCategories = [];
		TsdNewRequest.prevProductCount = 1;
		var pendingEdit = Number((window.Tsd && Tsd.pendingEditIntCode) || 0) || 0;
		if (window.Tsd) {
			Tsd.pendingEditIntCode = 0;
		}
		TsdNewRequest.editIntCode = pendingEdit > 0 ? pendingEdit : 0;
		if (!(pendingEdit > 0)) {
			TsdNewRequest.editDocuments = [];
			TsdNewRequest.clearEditBanner();
		}
		TsdNewRequest._docRemoved = {};
		TsdNewRequest.clearDocPreviews();
		TsdNewRequest.saving = false;
		TsdNewRequest.rsmNsmObj = [];
		TsdNewRequest.divisionObj = [];
		TsdNewRequest.bindEvents();

		if ((window.Tsd && Tsd.needsConverter) || !TsdNewRequest.custCode) {
			TsdNewRequest.showMsg("Select a converter (Change Converter) before creating a request.", true);
			TsdNewRequest.hideFormBody(true);
			if (window.Tsd && Tsd.canChangeConverter && typeof Tsd.openConverterModal === "function") {
				Tsd.openConverterModal();
			}
			return;
		}
		TsdNewRequest.hideFormBody(false);
		TsdNewRequest.loadLookups(function () {
			if (pendingEdit > 0) {
				TsdNewRequest.loadEditRequest(pendingEdit);
			}
		});
	},

	hideFormBody: function (hide) {
		TsdNewRequest._$("#tsd_nr_warranty_section, #tsd_nr_customer_details, #tsd_nr_ppc_details, #tsd_nr_buyer_details, #tsd_nr_product_section, #tsd_nr_approver_docs, .tsd-nr-actions")
			.toggleClass("tsd-nr-hidden", !!hide);
	},

	bindEvents: function () {
		/* HTML/legacy parity:
		 * - warranty type radios: onclick → OnWarrTypeChange (built in formWarrantyTypes)
		 * - warranty_exists / conv_rel / acc_overdue: HTML onclick
		 * - cust_state: HTML onchange → GetDocumentList
		 * - no_of_products: HTML onfocus/onchange → captureNoOfProducts / assignProductTabs
		 * - prod_type_N: HTML onchange → ClearProductDetails
		 * Cancel / Draft / Submit: jQuery (avoids double-bind with HTML onclick)
		 */
		TsdNewRequest._$("#tsd_nr_cancel").off("click.tsdnr").on("click.tsdnr", function () {
			TsdNewRequest.ClearTSDNewRequest();
		});
		TsdNewRequest._$("#tsd_nr_draft").off("click.tsdnr").on("click.tsdnr", function () {
			TsdNewRequest.save("Draft");
		});
		TsdNewRequest._$("#tsd_nr_submit").off("click.tsdnr").on("click.tsdnr", function () {
			TsdNewRequest.save("Submit");
		});
		/* Clear field highlight + banner when user edits the invalid control. */
		TsdNewRequest._$("#m_tsd_new_request").off("change.tsdErr input.tsdErr click.tsdErr")
			.on("change.tsdErr input.tsdErr", "input, select, textarea", function () {
				TsdNewRequest.clearFieldError($(this));
			})
			.on("click.tsdErr", ".tsd-nr-type-card, .tsd-nr-radios label", function () {
				TsdNewRequest.clearFieldError($(this));
			});
	},

	/** Validation helper: message + focus selector (id / name / wrap). */
	fail: function (msg, focus) {
		return { msg: msg, focus: focus || "" };
	},

	clearFieldErrors: function () {
		TsdNewRequest._$("#m_tsd_new_request .tsd-nr-err").removeClass("tsd-nr-err");
	},

	clearFieldError: function ($from) {
		if (!$from || !$from.length) {
			return;
		}
		$from.removeClass("tsd-nr-err");
		$from.closest(".tsd-nr-err").removeClass("tsd-nr-err");
		TsdNewRequest.showMsg("", false);
	},

	highlightField: function (focus) {
		TsdNewRequest.clearFieldErrors();
		if (!focus) {
			return;
		}
		var $el = TsdNewRequest._$(focus).first();
		if (!$el.length) {
			return;
		}
		var $panel = $el.closest(".tsd-nr-prod-panel");
		if ($panel.length) {
			var prod = Number($panel.attr("data-prod")) || 0;
			if (prod && typeof TsdNewRequest.showProductTab === "function") {
				TsdNewRequest.showProductTab(prod);
			}
		}
		var $mark;
		if ($el.is("input[type='radio'], input[type='checkbox']")) {
			$mark = $el.closest(".tsd-nr-q, .tsd-nr-type-row, .tsd-nr-field");
		} else if ($el.is(".tsd-nr-q, .tsd-nr-type-row, .tsd-nr-field, tr")) {
			$mark = $el;
		} else if ($el.is("input, select, textarea")) {
			$mark = $el;
		} else {
			$mark = $el.closest(".tsd-nr-q, .tsd-nr-field, .tsd-nr-type-row");
			if (!$mark.length) {
				$mark = $el;
			}
		}
		$mark.addClass("tsd-nr-err");
		var node = $mark[0];
		window.setTimeout(function () {
			try {
				node.scrollIntoView({ behavior: "smooth", block: "center" });
			} catch (e) {
				try {
					node.scrollIntoView(true);
				} catch (e2) { /* ignore */ }
			}
		}, 50);
	},

	/** Legacy: captureNoOfProducts (onfocus). */
	captureNoOfProducts: function () {
		TsdNewRequest.prevProductCount = Number(TsdNewRequest._$("#tsd_nr_no_of_products").val()) || 1;
	},

	/** Legacy: OnWarrTypeChange. */
	OnWarrTypeChange: function () {
		TsdNewRequest.onWarrantyTypeChange();
	},

	/** Legacy: OnWarrTypeExistChange — show/hide Warranty No + AC. */
	OnWarrTypeExistChange: function () {
		var yes = TsdNewRequest._$("input[name='tsd_nr_warranty_exists']:checked").val() === "Yes";
		TsdNewRequest._$("#tsd_nr_warranty_no_wrap").toggleClass("tsd-nr-hidden", !yes);
		if (!yes) {
			TsdNewRequest._$("#tsd_nr_warranty_no").val("");
			TsdNewRequest.warrAcError("");
			TsdNewRequest.destroyWarrantyAutocomplete();
		} else {
			TsdNewRequest.wireWarrantyAutocomplete();
		}
	},

	/** Legacy: HandleRelationshipWithConv — Sister Concern not allowed. */
	HandleRelationshipWithConv: function () {
		var rel = TsdNewRequest.radio("tsd_nr_conv_rel");
		if (rel === "Sister Concern") {
			TsdNewRequest.showMsg("You cannot raise the request for Sister Concern.", true);
			TsdNewRequest._$("input[name='tsd_nr_conv_rel'][value='No Relationship']").prop("checked", true);
			return false;
		}
		TsdNewRequest.showMsg("", false);
		return true;
	},

	/** Legacy: HandleAccountOverDueStatus — Overdue not allowed. */
	HandleAccountOverDueStatus: function () {
		var status = TsdNewRequest.radio("tsd_nr_acc_overdue");
		if (status === "Overdue") {
			/*
			 * Defer: same click also runs clearFieldError on .tsd-nr-radios label
			 * and would wipe the banner if shown synchronously.
			 */
			window.setTimeout(function () {
				TsdNewRequest.showMsg(
					"You cannot raise this request as you selected account as overdue.",
					true);
			}, 0);
			return false;
		}
		/* Not Overdue (unclick Overdue) → clear banner. */
		TsdNewRequest.showMsg("", false);
		return true;
	},

	/** Legacy: ClearTSDNewRequest — Cancel back to My Requests. */
	ClearTSDNewRequest: function () {
		TsdNewRequest.editIntCode = 0;
		TsdNewRequest.editDocuments = [];
		TsdNewRequest._docRemoved = {};
		TsdNewRequest.clearDocPreviews();
		TsdNewRequest.clearEditBanner();
		if (window.Tsd && typeof Tsd.showTab === "function") {
			Tsd.showTab("requests");
		}
	},

	clearEditBanner: function () {
		TsdNewRequest._$("#tsd_nr_edit_banner").removeClass("is-on");
		TsdNewRequest._$("#tsd_nr_edit_req_no").text("");
		TsdNewRequest._$("#tsd_nr_edit_meta").text("");
		TsdNewRequest.setWarrantyTypeLocked(false);
	},

	showEditBanner: function (reqNo, status) {
		var no = String(reqNo == null ? "" : reqNo).trim();
		var st = String(status == null ? "" : status).trim();
		TsdNewRequest._$("#tsd_nr_edit_req_no").text(no || String(TsdNewRequest.editIntCode || ""));
		TsdNewRequest._$("#tsd_nr_edit_meta").text(st
			? ("Status : " + st + " — update details and save Draft or Submit. Warranty type cannot be changed.")
			: "Update details and save Draft or Submit. Warranty type cannot be changed.");
		TsdNewRequest._$("#tsd_nr_edit_banner").addClass("is-on");
	},

	/** Edit mode: warranty type is fixed; other fields remain editable. */
	setWarrantyTypeLocked: function (locked) {
		var $radios = TsdNewRequest._$("input[name='tsd_nr_warr_type']");
		$radios.prop("disabled", !!locked);
		TsdNewRequest._$("#tsd_nr_warranty_types").toggleClass("tsd-nr-warr-locked", !!locked);
		if (locked) {
			$radios.removeAttr("onclick");
		} else {
			$radios.attr("onclick", "TsdNewRequest.OnWarrTypeChange()");
		}
	},

	/** Legacy: ClearProductDetails(id) — name/WO/project/years/remarks + INPCV2 hidden product keys. */
	ClearProductDetails: function (id) {
		TsdNewRequest._$("#tsd_nr_prod_name_" + id).val("");
		TsdNewRequest._$("#tsd_nr_prod_code_" + id).val("");
		TsdNewRequest._$("#tsd_nr_prod_sb_cols_" + id).val("");
		TsdNewRequest._$("#tsd_nr_prod_tbl_name_" + id).val("");
		TsdNewRequest._$("#tsd_nr_prod_tbl_cols_" + id).val("");
		TsdNewRequest._$("#tsd_nr_work_order_" + id).val("");
		TsdNewRequest._$("#tsd_nr_project_" + id).val("");
		TsdNewRequest._$("#tsd_nr_warr_years_" + id).val("");
		TsdNewRequest._$("#tsd_nr_prod_remarks_" + id).val("");
		TsdNewRequest._$("#tsd_nr_install_date_" + id).val("");
		TsdNewRequest._$("#tsd_nr_ppc_qty_" + id).val("");
		TsdNewRequest._$("#tsd_nr_ppc_uom_" + id).val("");
		TsdNewRequest.prodAcError(id, "");
		TsdNewRequest._$("#tsd_nr_prod_tables_" + id).addClass("tsd-nr-hidden").empty();
		if (window.Common && Common.HideAcSpinner) {
			Common.HideAcSpinner("#m_tsd_new_request", "tsd_nr_prod_ac_spinner_" + id);
		}
	},

	loadLookups: function (done) {
		var editing = Number(TsdNewRequest.editIntCode) > 0;
		showLoader(editing ? "Loading draft for edit..." : "Loading New Request...",
			"tsd_new_request_panel");
		$.ajax({
			url: (window.$app_url || "") + TsdNewRequest.API + "/new-request/lookups",
			method: "GET",
			data: { custCode: TsdNewRequest.custCode, loginId: TsdNewRequest.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (TsdNewRequest.isSessionGone(json)) {
				return;
			}
			if (!TsdNewRequest.ok(json)) {
				TsdNewRequest.showMsg((json && json.message) || "Unable to load New Request lookups.", true);
				TsdNewRequest.hideFormBody(true);
				if (editing) {
					hideLoader("tsd_new_request_panel");
					hideLoader("m_tsd_home");
				}
				return;
			}
			var data = json.data || {};
			TsdNewRequest.distributor = data.distributor || {};
			TsdNewRequest.states = data.states || [];
			TsdNewRequest.productCategories = data.productCategories || [];
			TsdNewRequest.applyDistributor();
			TsdNewRequest.fillStates();
			TsdNewRequest.formWarrantyTypes();
			TsdNewRequest.assignProductTabs(false);
			/* Edit: skip empty type UI — applyEditRequest fills then calls onWarrantyTypeChange. */
			if (!editing) {
				TsdNewRequest.onWarrantyTypeChange();
				TsdNewRequest.ensureDatePickers();
				TsdNewRequest.showMsg("", false);
			}
			if (typeof done === "function") {
				done();
			}
		}).fail(function () {
			TsdNewRequest.showMsg("Unable to load New Request lookups.", true);
			TsdNewRequest.hideFormBody(true);
			if (editing) {
				hideLoader("tsd_new_request_panel");
				hideLoader("m_tsd_home");
			}
		}).always(function () {
			/*
			 * Edit continues with GET /requests/{id}; do not hide here or the
			 * spinner drops while that call is still in flight (blank screen).
			 */
			if (!editing) {
				hideLoader("tsd_new_request_panel");
			}
		});
	},

	warrAcError: function (message) {
		var $err = TsdNewRequest._$("#tsd_nr_warr_ac_error");
		if (!$err.length) {
			return;
		}
		var msg = String(message || "").trim();
		if (!msg) {
			$err.removeClass("on").text("");
			return;
		}
		$err.addClass("on").text(msg);
	},

	destroyWarrantyAutocomplete: function () {
		var $txt = TsdNewRequest._$("#tsd_nr_warranty_no");
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		try {
			if ($txt.data("ui-autocomplete")) {
				$txt.autocomplete("destroy");
			}
		} catch (e) { /* ignore */ }
		if (window.Common && Common.HideAcSpinner) {
			Common.HideAcSpinner("#m_tsd_new_request", "tsd_nr_warr_ac_spinner");
		}
	},

	/**
	 * Legacy {@code TSDCommon.GetWarrantyAutoComplete} on #warranty_no.
	 * Select → load Approved PQ into Actual form (new request, not edit).
	 */
	wireWarrantyAutocomplete: function () {
		var $txt = TsdNewRequest._$("#tsd_nr_warranty_no");
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		TsdNewRequest.destroyWarrantyAutocomplete();
		$txt.off("input.tsdWarrAc").on("input.tsdWarrAc", function () {
			TsdNewRequest.warrAcError("");
		});
		$txt.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: "#m_tsd_new_request",
			position: { my: "left top", at: "left bottom", collision: "flip" },
			open: function () {
				$(this).autocomplete("widget").css({ zIndex: 1090, position: "absolute" });
			},
			source: function (request, response) {
				var term = String(request.term || "").trim();
				TsdNewRequest.warrAcError("");
				if (TsdNewRequest._acAjax.warr && TsdNewRequest._acAjax.warr.abort) {
					TsdNewRequest._acAjax.warr.abort();
				}
				if (window.Common && Common.ShowAcSpinner) {
					Common.ShowAcSpinner("#m_tsd_new_request", "tsd_nr_warr_ac_spinner");
				}
				TsdNewRequest._acAjax.warr = $.ajax({
					url: (window.$app_url || "") + TsdNewRequest.API + "/warranties/autocomplete",
					method: "GET",
					data: {
						phrase: request.term,
						custCode: TsdNewRequest.custCode,
						loginId: TsdNewRequest.loginId
					},
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (TsdNewRequest.isSessionGone(json)) {
						response([]);
						return;
					}
					if (!TsdNewRequest.ok(json)) {
						TsdNewRequest.warrAcError((json && json.message) || "Unable to search warranty numbers.");
						response([]);
						return;
					}
					var rows = json.data || [];
					if (!rows.length) {
						TsdNewRequest.warrAcError("No approved PQ Warranty found for \"" + term + "\".");
						response([]);
						return;
					}
					TsdNewRequest.warrAcError("");
					response($.map(rows, function (row) {
						return {
							label: row.value || "",
							value: row.value || "",
							internal_code: row.internal_code
						};
					}));
				}).fail(function (_xhr, status) {
					if (status !== "abort") {
						TsdNewRequest.warrAcError("Unable to search warranty numbers.");
						response([]);
					}
				}).always(function () {
					if (window.Common && Common.HideAcSpinner) {
						Common.HideAcSpinner("#m_tsd_new_request", "tsd_nr_warr_ac_spinner");
					}
					$txt.removeClass("ui-autocomplete-loading");
				});
			},
			select: function (_event, ui) {
				var item = ui.item || {};
				$txt.val(item.value || "");
				TsdNewRequest.warrAcError("");
				TsdNewRequest.loadPqReference(item.internal_code, item.value || "");
				return false;
			}
		});
	},

	/**
	 * Legacy select → {@code getOnloadData} + {@code ReAssignWarrantyData} with
	 * {@code $g_pq_auto_complete=Yes}. Prefills Actual form; keeps new-request save
	 * ({@code editIntCode} stays 0).
	 */
	loadPqReference: function (internalCode, warrantyNo) {
		var id = Number(internalCode) || 0;
		if (!id) {
			return;
		}
		showLoader("Loading PQ Warranty details...", "tsd_new_request_panel");
		$.ajax({
			url: (window.$app_url || "") + TsdNewRequest.API + "/requests/" + encodeURIComponent(id),
			method: "GET",
			data: { custCode: TsdNewRequest.custCode, loginId: TsdNewRequest.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (TsdNewRequest.isSessionGone(json)) {
				return;
			}
			if (!TsdNewRequest.ok(json)) {
				TsdNewRequest.showMsg((json && json.message) || "Unable to load PQ Warranty.", true);
				return;
			}
			TsdNewRequest.applyPqReference(json.data || {}, warrantyNo);
		}).fail(function () {
			TsdNewRequest.showMsg("Unable to load PQ Warranty.", true);
		}).always(function () {
			hideLoader("tsd_new_request_panel");
		});
	},

	/** Prefill from Approved PQ into Current Actual Warranty (new request). */
	applyPqReference: function (data, warrantyNo) {
		var h = data.header || {};
		var status = String(h.wrr_status || "").trim();
		if (!/^Approved$/i.test(status)) {
			TsdNewRequest.showMsg("Selected warranty is not Approved.", true);
			return;
		}
		/* Stay on Actual Warranty — do not switch type to PQ or enter edit mode. */
		TsdNewRequest.editIntCode = 0;
		TsdNewRequest.editDocuments = [];
		TsdNewRequest._docRemoved = {};
		TsdNewRequest.clearDocPreviews();
		TsdNewRequest.clearEditBanner();
		TsdNewRequest.setWarrantyTypeLocked(false);
		TsdNewRequest._$("input[name='tsd_nr_warr_type']").filter(function () {
			return String(this.value || "") === "Actual Warranty";
		}).prop("checked", true);

		var nProd = Number(h.no_of_products) || (data.products || []).length || 1;
		if (nProd < 1) {
			nProd = 1;
		}
		if (nProd > 10) {
			nProd = 10;
		}
		TsdNewRequest._$("#tsd_nr_no_of_products").val(String(nProd));
		TsdNewRequest.prevProductCount = nProd;

		TsdNewRequest.setRadio("tsd_nr_cust_type", h.is_conv_appl);
		TsdNewRequest.setRadio("tsd_nr_first_pq", h.is_first_pq_war);
		TsdNewRequest.setRadio("tsd_nr_conv_rel", h.rel_with_exist_cust);
		TsdNewRequest.setRadio("tsd_nr_pq_cert", h.pq_cert_issued);
		TsdNewRequest.setRadio("tsd_nr_agreement", h.agreement_signed);
		TsdNewRequest.setRadio("tsd_nr_sister_cert", h.signed_current);
		TsdNewRequest.setRadio("tsd_nr_sop_mcs", h.certified_by_us);
		TsdNewRequest.setRadio("tsd_nr_warranty_exists", "Yes");
		TsdNewRequest.setRadio("tsd_nr_acc_overdue", h.acc_overdue_status);

		TsdNewRequest._$("#tsd_nr_warranty_no").val(warrantyNo || h.req_id || h.warranty_no || "");
		TsdNewRequest._$("#tsd_nr_remarks").val(h.cust_remarks || "");
		TsdNewRequest._$("#tsd_nr_cust_name").val(h.customer_name || "");
		TsdNewRequest._$("#tsd_nr_cust_addr1").val(h.cust_addr1 || "");
		TsdNewRequest._$("#tsd_nr_cust_addr2").val(h.cust_addr2 || "");
		TsdNewRequest._$("#tsd_nr_contractor_name").val(h.contract_name || "");
		TsdNewRequest._$("#tsd_nr_contractor_addr1").val(h.contractor_address1 || "");
		TsdNewRequest._$("#tsd_nr_contractor_addr2").val(h.contractor_address2 || "");
		TsdNewRequest._$("#tsd_nr_tender_no").val(h.p_tender_no || "");
		TsdNewRequest.setSelectByValueOrText("#tsd_nr_cust_state",
			h.cust_state_code, h.cust_state);
		TsdNewRequest.setSelectByValueOrText("#tsd_nr_contractor_state",
			h.contract_state_code, h.contract_state);

		TsdNewRequest.onWarrantyTypeChange();
		TsdNewRequest.setRadio("tsd_nr_warranty_exists", "Yes");
		TsdNewRequest._$("#tsd_nr_warranty_no_wrap").removeClass("tsd-nr-hidden");
		TsdNewRequest._$("#tsd_nr_warranty_no").val(warrantyNo || h.req_id || "");
		TsdNewRequest.wireWarrantyAutocomplete();
		TsdNewRequest.populateEditProducts(data.products || []);
		TsdNewRequest.ensureDatePickers();
		if (typeof TsdNewRequest.GetDocumentList === "function") {
			TsdNewRequest.GetDocumentList();
		}
		TsdNewRequest.showMsg("PQ Warranty details loaded. Complete Actual fields and save as a new request.", false);
	},

	/**
	 * Legacy {@code getOnloadData} / {@code ReAssignWarrantyData} for Draft|Rework edit.
	 */
	loadEditRequest: function (internalCode) {
		var id = Number(internalCode) || 0;
		if (!id) {
			hideLoader("tsd_new_request_panel");
			hideLoader("m_tsd_home");
			return;
		}
		TsdNewRequest.editIntCode = id;
		showLoader("Loading draft for edit...", "tsd_new_request_panel");
		showLoader("Loading draft for edit...", "m_tsd_home");
		var editLoaded = false;
		$.ajax({
			url: (window.$app_url || "") + TsdNewRequest.API + "/requests/" + encodeURIComponent(id),
			method: "GET",
			data: { custCode: TsdNewRequest.custCode, loginId: TsdNewRequest.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (TsdNewRequest.isSessionGone(json)) {
				return;
			}
			if (!TsdNewRequest.ok(json)) {
				TsdNewRequest.showMsg((json && json.message) || "Unable to load request for edit.", true);
				return;
			}
			/* Close edit spinner before populate (GetDocumentList opens its own). */
			hideLoader("tsd_new_request_panel");
			hideLoader("m_tsd_home");
			editLoaded = true;
			TsdNewRequest.applyEditRequest(json.data || {});
		}).fail(function () {
			TsdNewRequest.showMsg("Unable to load request for edit.", true);
		}).always(function () {
			if (!editLoaded) {
				hideLoader("tsd_new_request_panel");
				hideLoader("m_tsd_home");
			}
		});
	},

	applyEditRequest: function (data) {
		var h = data.header || {};
		var status = String(h.wrr_status || "").trim();
		if (!/^(Draft|Rework)$/i.test(status)) {
			TsdNewRequest.clearEditBanner();
			TsdNewRequest.showMsg("Only Draft or Rework requests can be edited.", true);
			TsdNewRequest.editIntCode = 0;
			TsdNewRequest.editDocuments = [];
			TsdNewRequest._docRemoved = {};
			TsdNewRequest.clearDocPreviews();
			return;
		}
		TsdNewRequest.editIntCode = Number(h.internal_code || TsdNewRequest.editIntCode) || 0;
		TsdNewRequest.editDocuments = Array.isArray(data.documents) ? data.documents : [];
		TsdNewRequest._docRemoved = {};
		TsdNewRequest.clearDocPreviews();
		var type = String(h.wrty_type || "").trim();
		if (type) {
			TsdNewRequest._$("input[name='tsd_nr_warr_type']").filter(function () {
				return String(this.value || "") === type;
			}).prop("checked", true);
		}
		TsdNewRequest.setWarrantyTypeLocked(true);
		var nProd = Number(h.no_of_products) || (data.products || []).length || 1;
		if (nProd < 1) {
			nProd = 1;
		}
		if (nProd > 10) {
			nProd = 10;
		}
		TsdNewRequest._$("#tsd_nr_no_of_products").val(String(nProd));
		TsdNewRequest.prevProductCount = nProd;

		TsdNewRequest.setRadio("tsd_nr_cust_type", h.is_conv_appl);
		TsdNewRequest.setRadio("tsd_nr_first_pq", h.is_first_pq_war);
		TsdNewRequest.setRadio("tsd_nr_conv_rel", h.rel_with_exist_cust);
		TsdNewRequest.setRadio("tsd_nr_pq_cert", h.pq_cert_issued);
		TsdNewRequest.setRadio("tsd_nr_agreement", h.agreement_signed);
		TsdNewRequest.setRadio("tsd_nr_sister_cert", h.signed_current);
		TsdNewRequest.setRadio("tsd_nr_sop_mcs", h.certified_by_us);
		TsdNewRequest.setRadio("tsd_nr_warranty_exists", h.pq_warranty_exists);
		TsdNewRequest.setRadio("tsd_nr_acc_overdue", h.acc_overdue_status);
		TsdNewRequest.setRadio("tsd_nr_first_ppc", h.is_first_time_ppc);
		TsdNewRequest.setRadio("tsd_nr_ppc_agreement", h.is_dist_signed_curr);

		TsdNewRequest._$("#tsd_nr_warranty_no").val(h.warranty_no || "");
		TsdNewRequest._$("#tsd_nr_remarks").val(h.cust_remarks || "");
		TsdNewRequest._$("#tsd_nr_cust_name").val(h.customer_name || "");
		TsdNewRequest._$("#tsd_nr_cust_addr1").val(h.cust_addr1 || "");
		TsdNewRequest._$("#tsd_nr_cust_addr2").val(h.cust_addr2 || "");
		TsdNewRequest._$("#tsd_nr_contractor_name").val(h.contract_name || "");
		TsdNewRequest._$("#tsd_nr_contractor_addr1").val(h.contractor_address1 || "");
		TsdNewRequest._$("#tsd_nr_contractor_addr2").val(h.contractor_address2 || "");
		TsdNewRequest._$("#tsd_nr_tender_no").val(h.p_tender_no || "");
		TsdNewRequest._$("#tsd_nr_buyer_name").val(h.buyer_name || "");
		TsdNewRequest._$("#tsd_nr_date_of_sale").val(TsdNewRequest.toUiDate(h.date_of_sale));
		if (h.dist_int_code) {
			TsdNewRequest._$("#tsd_nr_dist_int_code").val(h.dist_int_code);
		}
		TsdNewRequest.setSelectByValueOrText("#tsd_nr_cust_state",
			h.cust_state_code, h.cust_state);
		TsdNewRequest.setSelectByValueOrText("#tsd_nr_contractor_state",
			h.contract_state_code, h.contract_state);

		TsdNewRequest.onWarrantyTypeChange();
		TsdNewRequest.populateEditProducts(data.products || []);
		TsdNewRequest.showEditBanner(h.req_id || TsdNewRequest.editIntCode, status);
		TsdNewRequest.showMsg("", false);
		TsdNewRequest.ensureDatePickers();
	},

	setRadio: function (name, value) {
		var v = String(value == null ? "" : value).trim();
		if (!v) {
			return;
		}
		TsdNewRequest._$("input[name='" + name + "']").filter(function () {
			return String(this.value || "") === v;
		}).prop("checked", true);
	},

	setSelectByValueOrText: function (sel, value, text) {
		var $s = TsdNewRequest._$(sel);
		if (!$s.length) {
			return;
		}
		var code = String(value == null ? "" : value).trim();
		if (code) {
			var matched = false;
			$s.find("option").each(function () {
				if (String(this.value || "") === code) {
					$s.val(code);
					matched = true;
					return false;
				}
			});
			if (matched) {
				return;
			}
		}
		var label = String(text == null ? "" : text).trim().toLowerCase();
		if (!label) {
			return;
		}
		$s.find("option").each(function () {
			if (String($(this).text() || "").trim().toLowerCase() === label) {
				$s.val(String($(this).val() || ""));
				return false;
			}
		});
	},

	/**
	 * Normalize any API/DB date to portal picker format {@code dd/mm/yyyy}.
	 * Blank / SQL 1900 sentinel → empty (do not show in date picker).
	 */
	toUiDate: function (raw) {
		var s = String(raw == null ? "" : raw).trim();
		if (!s) {
			return "";
		}
		if (/^\d{2}\/\d{2}\/\d{4}/.test(s)) {
			s = s.substring(0, 10);
			if (/\/1900$/.test(s)) {
				return "";
			}
			return s;
		}
		var iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
		if (iso) {
			if (iso[1] === "1900") {
				return "";
			}
			return iso[3] + "/" + iso[2] + "/" + iso[1];
		}
		var dash = s.match(/^(\d{2})-(\d{2})-(\d{4})/);
		if (dash) {
			if (dash[3] === "1900") {
				return "";
			}
			return dash[1] + "/" + dash[2] + "/" + dash[3];
		}
		/* Avoid JS Date parsing of dd/mm (ambiguous); only try clear ISO-like strings. */
		return "";
	},

	populateEditProducts: function (products) {
		if (!products || !products.length) {
			return;
		}
		for (var i = 0; i < products.length; i++) {
			var p = products[i] || {};
			var n = Number(p.prod_sl_no) || (i + 1);
			var cat = String(p.product_type_code || "").trim();
			if (cat) {
				TsdNewRequest._$("#tsd_nr_prod_type_" + n).val(cat);
			}
			TsdNewRequest._$("#tsd_nr_prod_name_" + n).val(p.product_name || "");
			TsdNewRequest._$("#tsd_nr_prod_code_" + n).val(p.prod_int_code || p.product_code || "");
			TsdNewRequest._$("#tsd_nr_prod_sb_cols_" + n).val(p.prod_sign_board_table_columns || "");
			TsdNewRequest._$("#tsd_nr_prod_tbl_name_" + n).val(p.prod_table_name || "");
			TsdNewRequest._$("#tsd_nr_prod_tbl_cols_" + n).val(p.prod_table_columns || "");
			TsdNewRequest._$("#tsd_nr_work_order_" + n).val(p.work_order_details || "");
			TsdNewRequest._$("#tsd_nr_project_" + n).val(p.project_name || "");
			TsdNewRequest._$("#tsd_nr_warr_years_" + n).val(p.no_of_warrnty_years || "");
			TsdNewRequest._$("#tsd_nr_prod_remarks_" + n).val(p.comments || "");
			TsdNewRequest._$("#tsd_nr_install_date_" + n).val(TsdNewRequest.toUiDate(p.actual_date_of_instl));
			TsdNewRequest._$("#tsd_nr_ppc_qty_" + n).val(p.ppc_qty || "");
			TsdNewRequest._$("#tsd_nr_ppc_uom_" + n).val(p.ppc_uom || "");
			var prodId = String(p.prod_int_code || p.product_code || "").trim();
			var rows = Array.isArray(p.signboard_rows) ? p.signboard_rows : [];
			if (prodId) {
				TsdNewRequest.loadProductDynTables(n, prodId,
					p.sign_board_table_label || "Product Details",
					p.sign_board_table_remarks || "",
					rows);
			}
		}
	},

	applyDistributor: function () {
		var d = TsdNewRequest.distributor || {};
		var display = d.conv_display || ((d.conv_code || "") + (d.conv_name ? ("-" + d.conv_name) : ""));
		TsdNewRequest._$("#tsd_nr_conv_name").val(display);
		TsdNewRequest._$("#tsd_nr_conv_addr1").val(d.address1 || "");
		TsdNewRequest._$("#tsd_nr_conv_addr2").val(d.address2 || "");
		TsdNewRequest._$("#tsd_nr_conv_state").val(d.state_name || "");
		TsdNewRequest._$("#tsd_nr_dist_int_code").val(d.dist_int_code || "");
		TsdNewRequest._$("#tsd_nr_ppc_dist_name").val(display);
		if (window.Tsd) {
			Tsd.custCode = String(d.conv_code || Tsd.custCode || "").trim();
			TsdNewRequest.custCode = Tsd.custCode;
		}
	},

	fillStates: function () {
		var opts = '<option value="">SELECT STATE</option>';
		var list = TsdNewRequest.states || [];
		for (var i = 0; i < list.length; i++) {
			var s = list[i] || {};
			var code = String(s.internal_code == null ? "" : s.internal_code);
			var name = String(s.name == null ? s.code || "" : s.name);
			opts += '<option value="' + TsdNewRequest.escAttr(code) + '">'
				+ TsdNewRequest.esc(name) + "</option>";
		}
		TsdNewRequest._$("#tsd_nr_cust_state, #tsd_nr_contractor_state").html(opts);
	},

	flagOn: function (value) {
		var v = String(value == null ? "" : value).trim().toLowerCase();
		return v === "1" || v === "yes" || v === "y" || v === "true";
	},

	formWarrantyTypes: function () {
		var d = TsdNewRequest.distributor || {};
		var html = "";
		function typeCard(value, title, hint) {
			return '<label class="tsd-nr-type-card">'
				+ '<input type="radio" name="tsd_nr_warr_type" value="' + value + '"'
				+ ' onclick="TsdNewRequest.OnWarrTypeChange()">'
				+ '<span class="tsd-nr-type-card-ui" aria-hidden="true">'
				+ '<span class="tsd-nr-type-dot"></span>'
				+ '<span class="tsd-nr-type-text">'
				+ '<span class="tsd-nr-type-title">' + title + '</span>'
				+ (hint ? '<span class="tsd-nr-type-hint">' + hint + '</span>' : '')
				+ '</span></span></label>';
		}
		if (TsdNewRequest.flagOn(d.is_pq_warranty)) {
			html += typeCard("PQ Warranty", "PQ Warranty", "Pre-qualification");
		}
		if (TsdNewRequest.flagOn(d.is_actual_warranty)) {
			html += typeCard("Actual Warranty", "Actual Warranty", "Post installation");
		}
		if (TsdNewRequest.flagOn(d.is_ppc_for_retail_sale)) {
			html += typeCard("PPC for Retail Sale", "PPC for Retail Sale", "Retail certificate");
		}
		if (!html) {
			html = '<span class="tsd-nr-placeholder">Converter is not set up for any warranty type. Contact administrator.</span>';
			TsdNewRequest.hideFormBody(true);
			TsdNewRequest._$("#tsd_nr_warranty_section").removeClass("tsd-nr-hidden");
		}
		TsdNewRequest._$("#tsd_nr_warranty_types").html(html);
	},

	selectedWarrantyType: function () {
		return String(TsdNewRequest._$("input[name='tsd_nr_warr_type']:checked").val() || "");
	},

	onWarrantyTypeChange: function () {
		var type = TsdNewRequest.selectedWarrantyType();
		var isPq = type === "PQ Warranty";
		var isActual = type === "Actual Warranty";
		var isPpc = type === "PPC for Retail Sale";
		var isPqFamily = isPq || isActual;

		TsdNewRequest._$("#tsd_nr_customer_details").toggleClass("tsd-nr-hidden", !isPqFamily);
		TsdNewRequest._$("#tsd_nr_ppc_details").toggleClass("tsd-nr-hidden", !isPpc);
		TsdNewRequest._$("#tsd_nr_buyer_details").toggleClass("tsd-nr-hidden", !isPpc);
		TsdNewRequest._$("#tsd_nr_warranty_exists").toggleClass("tsd-nr-hidden", !isActual);
		TsdNewRequest._$("#tsd_nr_account_overdue").toggleClass("tsd-nr-hidden", !(isActual || isPpc));
		TsdNewRequest._$("#tsd_nr_tender_wrap").toggleClass("tsd-nr-hidden", isPpc);
		TsdNewRequest._$("#tsd_nr_product_section").toggleClass("tsd-nr-hidden", !type);
		TsdNewRequest._$("#tsd_nr_approver_docs, .tsd-nr-actions").toggleClass("tsd-nr-hidden", !type);

		if (!isActual) {
			TsdNewRequest._$("input[name='tsd_nr_warranty_exists']").prop("checked", false);
			TsdNewRequest._$("#tsd_nr_warranty_no_wrap").addClass("tsd-nr-hidden");
			TsdNewRequest._$("#tsd_nr_warranty_no").val("");
			TsdNewRequest.warrAcError("");
			TsdNewRequest.destroyWarrantyAutocomplete();
		} else {
			var yes = TsdNewRequest._$("input[name='tsd_nr_warranty_exists']:checked").val() === "Yes";
			TsdNewRequest._$("#tsd_nr_warranty_no_wrap").toggleClass("tsd-nr-hidden", !yes);
			if (yes) {
				TsdNewRequest.wireWarrantyAutocomplete();
			} else {
				TsdNewRequest.destroyWarrantyAutocomplete();
			}
		}

		TsdNewRequest.assignProductTabs(false);
		/* Legacy: warranty type / PPC onload also calls GetDocumentList */
		TsdNewRequest.GetDocumentList();
	},

	assignProductTabs: function (confirmReduce) {
		var $sel = TsdNewRequest._$("#tsd_nr_no_of_products");
		if (!$sel.length) {
			return;
		}
		var n = Number($sel.val()) || 1;
		if (n < 1) {
			n = 1;
		}
		if (n > 10) {
			n = 10;
		}
		if (confirmReduce && TsdNewRequest.prevProductCount > 0 && n < TsdNewRequest.prevProductCount) {
			var previous = TsdNewRequest.prevProductCount;
			var applyChange = function () {
				TsdNewRequest._renderProductTabs(n);
			};
			var cancelChange = function () {
				$sel.val(String(previous));
			};
			if (window.Swal && typeof Swal.fire === "function") {
				Swal.fire({
					title: "Change No. of Products?",
					text: "All entered Product Details will be deleted. Do you want to change?",
					icon: "warning",
					showCancelButton: true,
					confirmButtonText: "Yes, change",
					cancelButtonText: "Cancel",
					confirmButtonColor: "#d33",
					cancelButtonColor: "#94a3b8",
					reverseButtons: true,
					focusCancel: true
				}).then(function (result) {
					if (result && result.isConfirmed) {
						applyChange();
					} else {
						cancelChange();
					}
				});
				if (window.jQuery) {
					$(".swal2-container").css("z-index", "22222229999");
				}
				return;
			}
			if (!window.confirm("All entered Product Details will be deleted. Do you want to change?")) {
				cancelChange();
				return;
			}
		}
		TsdNewRequest._renderProductTabs(n);
	},

	/** Legacy / detail-popup product band colors — one tint per Product tab. */
	productColors: [
		"#e3fdcd", "#dcfccc", "#ecfdcd", "#ecfdb1", "#e4f3b1",
		"#fcfccc", "#f2fcb8", "#ddfdcd", "#ecfdcd", "#fcfccc"
	],

	productColor: function (index) {
		var colors = TsdNewRequest.productColors;
		var i = Math.max(0, (Number(index) || 1) - 1);
		return colors[i % colors.length];
	},

	_renderProductTabs: function (n) {
		TsdNewRequest.prevProductCount = n;
		var type = TsdNewRequest.selectedWarrantyType();
		var isActual = type === "Actual Warranty";
		var isPpc = type === "PPC for Retail Sale";
		var catOpts = TsdNewRequest.categoryOptionsHtml();

		var tabs = "";
		var panels = "";
		for (var i = 1; i <= n; i++) {
			var bg = TsdNewRequest.productColor(i);
			tabs += '<li class="nav-item" role="presentation">'
				+ '<button type="button" class="nav-link tsd-nr-prod-tab' + (i === 1 ? " active" : "")
				+ '" data-prod="' + i + '" data-prod-bg="' + TsdNewRequest.escAttr(bg) + '"'
				+ ' style="--tsd-prod-bg:' + TsdNewRequest.escAttr(bg) + '"'
				+ ' role="tab" aria-selected="' + (i === 1 ? "true" : "false")
				+ '">Product ' + i + "</button></li>";
			panels += TsdNewRequest.productPanelHtml(i, catOpts, isActual, isPpc, i === 1, bg);
		}
		TsdNewRequest._$("#tsd_nr_products_ul").html(tabs);
		TsdNewRequest._$("#tsd_nr_tab_content_product").html(panels);

		TsdNewRequest._$("#tsd_nr_products_ul").off("click.tsdnr", ".tsd-nr-prod-tab")
			.on("click.tsdnr", ".tsd-nr-prod-tab", function () {
				TsdNewRequest.showProductTab(Number($(this).attr("data-prod")) || 1);
				return false;
			});

		for (var p = 1; p <= n; p++) {
			TsdNewRequest.wireProductAutocomplete(p);
		}
		TsdNewRequest.ensureDatePickers();
	},

	/**
	 * Framework date picker (same as CIR / Rebate / COA): dd/mm/yyyy + calendar icon.
	 * Never use &lt;input type="date"&gt;.
	 */
	ensureDatePickers: function () {
		var $root = TsdNewRequest._$("#m_tsd_new_request");
		if (!$root.length) {
			return;
		}
		if (typeof window.initDatePickers === "function") {
			window.initDatePickers($root);
			return;
		}
		if (!window.jQuery || !$.fn.datepicker) {
			return;
		}
		$root.find(".date-picker, .date").each(function () {
			var $el = $(this);
			$el.attr("data-date-format", "dd/mm/yyyy");
			$el.attr("placeholder", "dd/mm/yyyy");
			try {
				if ($el.data("datepicker")) {
					$el.datepicker("destroy");
				}
			} catch (eD) { /* ignore */ }
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				format: "dd/mm/yyyy",
				orientation: "bottom auto",
				defaultViewDate: new Date()
			});
		});
	},

	categoryOptionsHtml: function () {
		var html = '<option value="">SELECT TYPE</option>';
		var list = TsdNewRequest.productCategories || [];
		for (var i = 0; i < list.length; i++) {
			var c = list[i] || {};
			if (String(c.active || "").toLowerCase() === "no") {
				continue;
			}
			var code = String(c.internal_code == null ? "" : c.internal_code);
			var name = String(c.category == null ? "" : c.category);
			html += '<option value="' + TsdNewRequest.escAttr(code) + '">'
				+ TsdNewRequest.esc(name) + "</option>";
		}
		return html;
	},

	productPanelHtml: function (i, catOpts, isActual, isPpc, active, bg) {
		var panelBg = bg || TsdNewRequest.productColor(i);
		var html = '<div class="tsd-nr-prod-panel' + (active ? " active" : "")
			+ '" id="tsd_nr_tab_product_' + i + '" data-prod="' + i + '"'
			+ ' style="--tsd-prod-bg:' + TsdNewRequest.escAttr(panelBg) + '"'
			+ ' role="tabpanel">';
		html += '<div class="tsd-nr-grid">';
		html += '<div class="tsd-nr-field"><label>Product Type <span class="tsd-nr-req">*</span></label>'
			+ '<select class="form-select form-select-sm tsd-nr-prod-type" id="tsd_nr_prod_type_' + i + '"'
			+ ' onchange="TsdNewRequest.ClearProductDetails(' + i + ')">'
			+ catOpts + "</select></div>";
		html += '<div class="tsd-nr-field"><label>Product Name <span class="tsd-nr-req">*</span></label>'
			+ '<div class="position-relative tsd-nr-ac-wrap">'
			+ '<input type="text" class="form-control form-control-sm pe-4 ac_loader" id="tsd_nr_prod_name_' + i
			+ '" autocomplete="off" placeholder="Type product name / code">'
			+ '<span id="tsd_nr_prod_ac_spinner_' + i + '" class="inpc-ac-spinner ac_loader" role="status"'
			+ ' aria-label="Searching products" aria-hidden="true" hidden>'
			+ '<span class="spinner-border spinner-border-sm text-primary" aria-hidden="true"></span></span>'
			+ '</div>'
			+ '<div id="tsd_nr_prod_ac_error_' + i + '" class="tsd-nr-ac-error" role="status"></div>'
			+ '<input type="hidden" id="tsd_nr_prod_code_' + i + '" value="">'
			+ '<input type="hidden" id="tsd_nr_prod_sb_cols_' + i + '" value="">'
			+ '<input type="hidden" id="tsd_nr_prod_tbl_name_' + i + '" value="">'
			+ '<input type="hidden" id="tsd_nr_prod_tbl_cols_' + i + '" value=""></div>';
		html += '<div class="tsd-nr-field tsd-nr-field-wide"><label>WorkOrder/PO Details <span class="tsd-nr-req">*</span></label>'
			+ '<textarea class="form-control form-control-sm" id="tsd_nr_work_order_' + i
			+ '" rows="2" maxlength="200"></textarea></div>';
		html += '<div class="tsd-nr-field tsd-nr-field-wide"><label>Project Name <span class="tsd-nr-req">*</span></label>'
			+ '<textarea class="form-control form-control-sm" id="tsd_nr_project_' + i
			+ '" rows="2" maxlength="200"></textarea></div>';
		html += '<div class="tsd-nr-field"><label>No of warranty years <span class="tsd-nr-req">*</span></label>'
			+ '<input type="text" class="form-control form-control-sm" id="tsd_nr_warr_years_' + i
			+ '" maxlength="10" disabled readonly title="Filled from product master"></div>';
		html += '<div class="tsd-nr-field tsd-nr-field-wide"><label>Remarks</label>'
			+ '<textarea class="form-control form-control-sm" id="tsd_nr_prod_remarks_' + i
			+ '" rows="2" maxlength="500"></textarea></div>';
		if (isActual) {
			html += '<div class="tsd-nr-field"><label>Actual Installation Date</label>'
				+ '<div class="input-group input-group-sm">'
				+ '<input type="text" class="form-control form-control-sm date date-picker"'
				+ ' id="tsd_nr_install_date_' + i + '"'
				+ ' placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" autocomplete="off">'
				+ '<span class="input-group-text">'
				+ '<i class="ri-calendar-2-line text-primary fs-15" role="button"'
				+ ' aria-label="Choose installation date" style="cursor:pointer;"'
				+ ' onclick="all_obj.CallTarkaDatePickerNew(\'tsd_new_request\',\'tsd_nr_install_date_'
				+ i + '\')"></i></span></div></div>';
		}
		if (isPpc) {
			html += '<div class="tsd-nr-field"><label>PPC Qty</label>'
				+ '<input type="text" class="form-control form-control-sm" id="tsd_nr_ppc_qty_' + i
				+ '" maxlength="20"></div>';
			html += '<div class="tsd-nr-field"><label>PPC UOM <span class="tsd-nr-req">*</span></label>'
				+ '<input type="text" class="form-control form-control-sm" id="tsd_nr_ppc_uom_' + i
				+ '" maxlength="40"></div>';
		}
		html += "</div>";
		html += '<div id="tsd_nr_prod_tables_' + i + '" class="tsd-nr-prod-tables tsd-nr-hidden"></div>';
		html += "</div>";
		return html;
	},

	showProductTab: function (id) {
		TsdNewRequest._$("#tsd_nr_products_ul .tsd-nr-prod-tab").removeClass("active").attr("aria-selected", "false");
		TsdNewRequest._$("#tsd_nr_products_ul .tsd-nr-prod-tab[data-prod='" + id + "']")
			.addClass("active").attr("aria-selected", "true");
		TsdNewRequest._$("#tsd_nr_tab_content_product .tsd-nr-prod-panel").removeClass("active");
		TsdNewRequest._$("#tsd_nr_tab_product_" + id).addClass("active");
	},

	prodAcError: function (i, message) {
		var $err = TsdNewRequest._$("#tsd_nr_prod_ac_error_" + i);
		if (!$err.length) {
			return;
		}
		var msg = String(message || "").trim();
		if (!msg) {
			$err.removeClass("on").text("");
			return;
		}
		$err.addClass("on").text(msg);
	},

	wireProductAutocomplete: function (i) {
		var $txt = TsdNewRequest._$("#tsd_nr_prod_name_" + i);
		var spinnerId = "tsd_nr_prod_ac_spinner_" + i;
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		try {
			if ($txt.data("ui-autocomplete")) {
				$txt.autocomplete("destroy");
			}
		} catch (e) { /* ignore */ }

		$txt.off("input.tsdnrAc").on("input.tsdnrAc", function () {
			TsdNewRequest.prodAcError(i, "");
			TsdNewRequest._$("#tsd_nr_prod_code_" + i).val("");
		});

		$txt.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: "#m_tsd_new_request",
			position: { my: "left top", at: "left bottom", collision: "flip" },
			open: function () {
				$(this).autocomplete("widget").css({ zIndex: 1090, position: "absolute" });
			},
			source: function (request, response) {
				var cat = String(TsdNewRequest._$("#tsd_nr_prod_type_" + i).val() || "").trim();
				var term = String(request.term || "").trim();
				TsdNewRequest.prodAcError(i, "");
				if (!cat) {
					TsdNewRequest.prodAcError(i, "Select Product Type before searching product name.");
					response([]);
					return;
				}
				var key = "p" + i;
				if (TsdNewRequest._acAjax[key] && TsdNewRequest._acAjax[key].abort) {
					TsdNewRequest._acAjax[key].abort();
				}
				if (window.Common && Common.ShowAcSpinner) {
					Common.ShowAcSpinner("#m_tsd_new_request", spinnerId);
				}
				TsdNewRequest._acAjax[key] = $.ajax({
					url: (window.$app_url || "") + TsdNewRequest.API + "/products/autocomplete",
					method: "GET",
					data: { phrase: request.term, categoryId: cat },
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (TsdNewRequest.isSessionGone(json)) {
						response([]);
						return;
					}
					if (!TsdNewRequest.ok(json)) {
						TsdNewRequest.prodAcError(i,
							(json && json.message) || "Unable to search products.");
						response([]);
						return;
					}
					var rows = json.data || [];
					if (!rows.length) {
						TsdNewRequest.prodAcError(i,
							"No product found for \"" + term + "\". Try another name or code.");
						response([]);
						return;
					}
					TsdNewRequest.prodAcError(i, "");
					response($.map(rows, function (row) {
						return {
							label: row.value || row.product_name || "",
							value: row.value || row.product_name || "",
							internal_code: row.internal_code,
							warranty_years: row.warranty_years,
							sign_board_table_columns: row.sign_board_table_columns || "",
							table_name: row.table_name || "",
							table_columns: row.table_columns || "",
							sign_board_table_label: row.sign_board_table_label || "",
							sign_board_table_remarks: row.sign_board_table_remarks || ""
						};
					}));
				}).fail(function (_xhr, status) {
					if (status !== "abort") {
						TsdNewRequest.prodAcError(i, "Unable to search products.");
						response([]);
					}
				}).always(function () {
					if (window.Common && Common.HideAcSpinner) {
						Common.HideAcSpinner("#m_tsd_new_request", spinnerId);
					}
					$txt.removeClass("ui-autocomplete-loading");
				});
			},
			select: function (_event, ui) {
				var item = ui.item || {};
				TsdNewRequest._$("#tsd_nr_prod_code_" + i).val(item.internal_code || "");
				TsdNewRequest._$("#tsd_nr_prod_sb_cols_" + i).val(item.sign_board_table_columns || "");
				TsdNewRequest._$("#tsd_nr_prod_tbl_name_" + i).val(item.table_name || "");
				TsdNewRequest._$("#tsd_nr_prod_tbl_cols_" + i).val(item.table_columns || "");
				if (item.warranty_years != null && item.warranty_years !== "") {
					TsdNewRequest._$("#tsd_nr_warr_years_" + i).val(item.warranty_years);
				}
				$txt.val(item.value || "");
				TsdNewRequest.prodAcError(i, "");
				TsdNewRequest.loadProductDynTables(i, item.internal_code,
					item.sign_board_table_label || "Product Details",
					item.sign_board_table_remarks || "");
				return false;
			}
		});
	},

	/**
	 * Legacy {@code TSDPM.GetSavedProductMasterDynTableDetails} — Product Details grid
	 * with Document upload + add/delete rows (max 10 on New Request).
	 */
	loadProductDynTables: function (prodIndex, productId, label, remarks, existingRows) {
		var $box = TsdNewRequest._$("#tsd_nr_prod_tables_" + prodIndex);
		if (!$box.length || !productId) {
			return;
		}
		$box.removeClass("tsd-nr-hidden").html(
			'<div class="tsd-nr-placeholder">Loading Product Details…</div>');
		$.ajax({
			url: (window.$app_url || "") + TsdNewRequest.API + "/products/"
				+ encodeURIComponent(productId) + "/dyn-table",
			method: "GET",
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (TsdNewRequest.isSessionGone(json)) {
				return;
			}
			if (!TsdNewRequest.ok(json)) {
				$box.html('<div class="tsd-nr-ac-error on">'
					+ TsdNewRequest.esc((json && json.message) || "Unable to load Product Details.")
					+ "</div>");
				return;
			}
			var data = json.data || {};
			var staticRows = data.query_data_obj || [];
			var sbMeta = data.retro_query_data_obj || [];
			var title = "";
			if (staticRows.length) {
				title = String(staticRows[0].table_name || "").trim();
				TsdNewRequest._$("#tsd_nr_prod_tbl_name_" + prodIndex).val(title);
				TsdNewRequest._$("#tsd_nr_prod_tbl_cols_" + prodIndex).val(staticRows[0].table_columns || "");
			}
			var columns = String(TsdNewRequest._$("#tsd_nr_prod_sb_cols_" + prodIndex).val() || "").trim();
			var sbLabel = label || "Product Details";
			var sbNote = remarks || "";
			if (sbMeta.length) {
				columns = String(sbMeta[0].table_columns || columns || "").trim();
				if (sbMeta[0].sign_board_table_label) {
					sbLabel = String(sbMeta[0].sign_board_table_label);
				}
				if (sbMeta[0].sign_board_table_remarks) {
					sbNote = String(sbMeta[0].sign_board_table_remarks);
				}
				TsdNewRequest._$("#tsd_nr_prod_sb_cols_" + prodIndex).val(columns);
			}
			if (!columns && existingRows && existingRows.length
					&& existingRows[0].table_columns) {
				columns = String(existingRows[0].table_columns || "").trim();
				TsdNewRequest._$("#tsd_nr_prod_sb_cols_" + prodIndex).val(columns);
			}
			if (!columns) {
				$box.addClass("tsd-nr-hidden").empty();
				return;
			}
			var html = '<div class="tsd-nr-sb-label">' + TsdNewRequest.esc(sbLabel) + "</div>";
			html += TsdNewRequest.signboardTableHtml(prodIndex, title || sbLabel, columns, productId);
			if (sbNote) {
				html += '<div class="tsd-nr-sb-note">Note:- ' + TsdNewRequest.esc(sbNote) + "</div>";
			}
			$box.html(html);
			if (existingRows && existingRows.length) {
				TsdNewRequest.fillSignboardRows(prodIndex, existingRows);
			}
		}).fail(function () {
			$box.html('<div class="tsd-nr-ac-error on">Unable to load Product Details.</div>');
		});
	},

	fillSignboardRows: function (prodIndex, rows) {
		var $table = TsdNewRequest._$("#tsd_nr_sb_table_" + prodIndex);
		if (!$table.length || !rows || !rows.length) {
			return;
		}
		var cols = [];
		$table.find("thead tr.tsd-nr-sb-cols th").each(function (idx, th) {
			if (idx < $table.find("thead tr.tsd-nr-sb-cols th").length - 1) {
				cols.push($(th).text());
			}
		});
		var productId = String($table.attr("data-product-id") || "");
		var body = "";
		for (var i = 0; i < rows.length; i++) {
			body += TsdNewRequest.signboardRowHtml(prodIndex, i + 1, cols, productId,
				i === rows.length - 1);
		}
		$table.find("tbody").html(body);
		for (var r = 0; r < rows.length; r++) {
			var row = rows[r] || {};
			var cells = String(row.tr_data || "").split("~");
			var $tr = $table.find("tbody tr").eq(r);
			var textIdx = 0;
			$tr.find("td").not(".tsd-nr-sb-act").each(function (cIdx) {
				var colName = String(cols[cIdx] || "").trim();
				if (/^document$/i.test(colName)) {
					var fileName = String(row.signboard_filename || "").trim();
					var filePath = String(row.signboard_filepath || "").trim();
					var $doc = $(this);
					$doc.attr("data-filename", fileName).attr("data-filepath", filePath);
					if (fileName || filePath) {
						var sbHref = TsdNewRequest.existingDocDownloadUrl(
							TsdNewRequest.editIntCode, 0, fileName, filePath);
						var sbLabel = fileName || "Uploaded file";
						var sbHtml = '<div class="tsd-nr-sb-existing small mb-1">';
						if (sbHref) {
							sbHtml += '<a class="tsd-nr-doc-link" href="'
								+ TsdNewRequest.escAttr(sbHref)
								+ '" title="View / download">'
								+ TsdNewRequest.esc(sbLabel)
								+ ' <i class="ri-eye-line" aria-hidden="true"></i></a>';
						} else {
							sbHtml += '<span class="text-muted">'
								+ TsdNewRequest.esc(sbLabel) + "</span>";
						}
						sbHtml += "</div>";
						$doc.prepend(sbHtml);
					}
				} else {
					var val = cells[cIdx] != null ? cells[cIdx]
						: (cells[textIdx] != null ? cells[textIdx] : "");
					$(this).find("input.tsd-nr-sb-cell").val(val);
					textIdx++;
				}
			});
		}
		TsdNewRequest.refreshSignboardActions(prodIndex);
		TsdNewRequest._$("#tsd_nr_sb_table_" + prodIndex).off("click.tsdnrSbDoc", "a.tsd-nr-doc-link")
			.on("click.tsdnrSbDoc", "a.tsd-nr-doc-link", function (event) {
				event.preventDefault();
				TsdNewRequest.downloadExistingDocument(this);
			});
	},

	signboardTableHtml: function (prodIndex, title, columnsCsv, productId) {
		var cols = String(columnsCsv || "").split(",");
		var colCount = cols.length;
		var html = '<div class="tsd-nr-sb-wrap"><table class="tsd-nr-sb" id="tsd_nr_sb_table_'
			+ prodIndex + '" data-prod="' + prodIndex + '" data-product-id="'
			+ TsdNewRequest.escAttr(productId || "") + '" tot_col_cnt="' + colCount + '">';
		html += "<thead>";
		if (title) {
			html += '<tr><th class="tsd-nr-sb-title" colspan="' + (colCount + 1) + '">'
				+ TsdNewRequest.esc(title) + "</th></tr>";
		}
		html += '<tr class="tsd-nr-sb-cols">';
		for (var c = 0; c < cols.length; c++) {
			html += "<th>" + TsdNewRequest.esc(String(cols[c] || "").trim()) + "</th>";
		}
		html += "<th>Actions</th></tr></thead><tbody>";
		html += TsdNewRequest.signboardRowHtml(prodIndex, 1, cols, productId, true);
		html += "</tbody></table></div>";
		return html;
	},

	signboardRowHtml: function (prodIndex, rowId, cols, productId, isLast) {
		var html = '<tr id="tsd_nr_sb_row_' + prodIndex + '_' + rowId + '" data-row="' + rowId + '">';
		for (var i = 0; i < cols.length; i++) {
			var colName = String(cols[i] || "").trim();
			if (colName.toLowerCase() === "document") {
				html += '<td class="tsd-nr-sb-doc" id="tsd_nr_sb_doc_' + prodIndex + '_' + rowId
					+ '" data-product-id="' + TsdNewRequest.escAttr(productId || "") + '">'
					+ '<input type="file" class="form-control form-control-sm tsd-nr-sb-file"'
					+ ' id="tsd_nr_sb_file_' + prodIndex + '_' + rowId + '"></td>';
			} else {
				html += '<td><input type="text" class="form-control form-control-sm tsd-nr-sb-cell"'
					+ ' maxlength="75" autocomplete="off"></td>';
			}
		}
		html += '<td class="tsd-nr-sb-act">';
		if (isLast) {
			html += '<button type="button" class="btn btn-sm btn-sb-add" title="Add row"'
				+ ' onclick="return TsdNewRequest.AddSignboardRow(' + prodIndex + ');">'
				+ '<i class="ri-add-line" aria-hidden="true"></i></button>';
		} else {
			html += '<button type="button" class="btn btn-sm btn-sb-del" title="Delete row"'
				+ ' onclick="return TsdNewRequest.DeleteSignboardRow(this);">'
				+ '<i class="ri-delete-bin-line" aria-hidden="true"></i></button>';
		}
		html += "</td></tr>";
		return html;
	},

	/** True if the row has any text cell, new file, or saved document path. */
	signboardRowHasValue: function ($tr) {
		if (!$tr || !$tr.length) {
			return false;
		}
		var hasText = false;
		$tr.find("input.tsd-nr-sb-cell").each(function () {
			if ($.trim($(this).val() || "") !== "") {
				hasText = true;
				return false;
			}
		});
		if (hasText) {
			return true;
		}
		var $file = $tr.find("input.tsd-nr-sb-file");
		if ($file.length && $file[0].files && $file[0].files.length) {
			return true;
		}
		var $doc = $tr.find("td.tsd-nr-sb-doc");
		if ($doc.length && (String($doc.attr("data-filename") || "").trim()
				|| String($doc.attr("data-filepath") || "").trim())) {
			return true;
		}
		return false;
	},

	AddSignboardRow: function (prodIndex) {
		var $table = TsdNewRequest._$("#tsd_nr_sb_table_" + prodIndex);
		if (!$table.length) {
			return false;
		}
		var $last = $table.find("tbody tr").last();
		if ($last.length && !TsdNewRequest.signboardRowHasValue($last)) {
			var msg = "Fill at least one value in the current Product Details row before adding another.";
			if (window.Swal && Swal.fire) {
				Swal.fire({
					title: "Row incomplete",
					text: msg,
					icon: "warning",
					confirmButtonColor: "#DD6B55"
				});
				$(".swal2-container").css("z-index", "22222229999");
			} else {
				window.alert(msg);
			}
			return false;
		}
		var count = $table.find("tbody tr").length;
		if (count >= 10 && !(TsdNewRequest.editIntCode > 0)) {
			TsdNewRequest.showSignboardLimitNote();
			return false;
		}
		var cols = [];
		$table.find("thead tr.tsd-nr-sb-cols th").each(function (idx, th) {
			if (idx < $table.find("thead tr.tsd-nr-sb-cols th").length - 1) {
				cols.push($(th).text());
			}
		});
		var productId = String($table.attr("data-product-id") || "");
		var nextId = 1;
		$table.find("tbody tr").each(function () {
			var n = Number($(this).attr("data-row")) || 0;
			if (n >= nextId) {
				nextId = n + 1;
			}
		});
		$table.find("tbody").append(
			TsdNewRequest.signboardRowHtml(prodIndex, nextId, cols, productId, true));
		TsdNewRequest.refreshSignboardActions(prodIndex);
		return false;
	},

	/** Show Note to Requester when user tries to add more than 10 Product Details rows. */
	showSignboardLimitNote: function () {
		var $note = TsdNewRequest._$("#tsd_nr_signboard_note");
		if (!$note.length) {
			return;
		}
		$note.removeClass("tsd-nr-hidden");
		$note.removeClass("is-flash");
		/* reflow so flash animation can replay */
		void $note[0].offsetWidth;
		$note.addClass("is-flash");
		var el = $note[0];
		try {
			el.scrollIntoView({ behavior: "smooth", block: "center" });
		} catch (e) {
			el.scrollIntoView(true);
		}
		window.setTimeout(function () {
			$note.removeClass("is-flash");
		}, 1600);
	},

	DeleteSignboardRow: function (btn) {
		var $tr = $(btn).closest("tr");
		var prodIndex = Number($tr.closest("table").attr("data-prod")) || 0;
		$tr.remove();
		if (prodIndex) {
			TsdNewRequest.refreshSignboardActions(prodIndex);
		}
		return false;
	},

	refreshSignboardActions: function (prodIndex) {
		var $rows = TsdNewRequest._$("#tsd_nr_sb_table_" + prodIndex + " tbody tr");
		var total = $rows.length;
		$rows.each(function (idx) {
			var $act = $(this).find("td.tsd-nr-sb-act");
			if (idx === total - 1) {
				$act.html('<button type="button" class="btn btn-sm btn-sb-add" title="Add row"'
					+ ' onclick="return TsdNewRequest.AddSignboardRow(' + prodIndex + ');">'
					+ '<i class="ri-add-line" aria-hidden="true"></i></button>');
			} else {
				$act.html('<button type="button" class="btn btn-sm btn-sb-del" title="Delete row"'
					+ ' onclick="return TsdNewRequest.DeleteSignboardRow(this);">'
					+ '<i class="ri-delete-bin-line" aria-hidden="true"></i></button>');
			}
		});
	},

	collectSignboardRows: function (prodIndex) {
		var rows = [];
		var $table = TsdNewRequest._$("#tsd_nr_sb_table_" + prodIndex);
		if (!$table.length) {
			return rows;
		}
		var cols = [];
		$table.find("thead tr.tsd-nr-sb-cols th").each(function (idx, th) {
			if (idx < $table.find("thead tr.tsd-nr-sb-cols th").length - 1) {
				cols.push(String($(th).text() || "").trim());
			}
		});
		$table.find("tbody tr").each(function () {
			var cells = [];
			var fileName = "";
			var filePath = "";
			$(this).find("td").not(".tsd-nr-sb-act").each(function (cIdx) {
				var colName = String(cols[cIdx] || "").trim();
				if (/^document$/i.test(colName)) {
					var $doc = $(this);
					fileName = String($doc.attr("data-filename") || "").trim();
					filePath = String($doc.attr("data-filepath") || "").trim();
					cells.push("");
				} else {
					cells.push($.trim($(this).find("input.tsd-nr-sb-cell").val() || ""));
				}
			});
			rows.push({
				data: cells.join("~"),
				signboard_filename: fileName,
				signboard_filepath: filePath
			});
		});
		return rows;
	},

	/**
	 * Legacy: {@code TsdReqWarranty.GetDocumentList}.
	 * Called on warranty-type change, customer-state change, and PPC onload.
	 * Loads approval matrix + attachment list + ASM/RSM/DM LOVs.
	 */
	GetDocumentList: function () {
		TsdNewRequest.loadApproverDocuments();
	},

	loadApproverDocuments: function () {
		var type = TsdNewRequest.selectedWarrantyType();
		if (!type) {
			TsdNewRequest._$("#tsd_nr_approvers_table tbody").html(
				'<tr><td colspan="3" class="tsd-nr-placeholder">Select warranty type to load approvers.</td></tr>');
			TsdNewRequest._$("#tsd_nr_documents_table tbody").html(
				'<tr><td colspan="2" class="tsd-nr-placeholder">Select warranty type to load attachments.</td></tr>');
			return;
		}
		var custState = TsdNewRequest.val("#tsd_nr_cust_state");
		var isPpc = type === "PPC for Retail Sale";
		/* PQ/Actual: ASM LOV needs customer state (legacy GetDocumentList still runs; ASM may be empty). */
		if (TsdNewRequest._docsAjax && TsdNewRequest._docsAjax.abort) {
			TsdNewRequest._docsAjax.abort();
		}
		TsdNewRequest._$("#tsd_nr_approvers_table tbody").html(
			'<tr><td colspan="3" class="tsd-nr-placeholder">Loading approvers…</td></tr>');
		TsdNewRequest._$("#tsd_nr_documents_table tbody").html(
			'<tr><td colspan="2" class="tsd-nr-placeholder">Loading attachments…</td></tr>');
		showLoader("Loading approvers and documents...", "tsd_new_request_panel");
		TsdNewRequest._docsAjax = $.ajax({
			url: (window.$app_url || "") + TsdNewRequest.API + "/new-request/documents",
			method: "GET",
			data: {
				custCode: TsdNewRequest.custCode,
				loginId: TsdNewRequest.loginId,
				warrType: type,
				custState: custState,
				editIntCode: TsdNewRequest.editIntCode || 0
			},
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (TsdNewRequest.isSessionGone(json)) {
				return;
			}
			if (!TsdNewRequest.ok(json)) {
				var msg = (json && json.message) || "Unable to load approvers/documents.";
				TsdNewRequest._$("#tsd_nr_approvers_table tbody").html(
					'<tr><td colspan="3" class="tsd-nr-placeholder">' + TsdNewRequest.esc(msg) + "</td></tr>");
				TsdNewRequest._$("#tsd_nr_documents_table tbody").html(
					'<tr><td colspan="2" class="tsd-nr-placeholder">' + TsdNewRequest.esc(msg) + "</td></tr>");
				return;
			}
			var data = json.data || {};
			TsdNewRequest.rsmNsmObj = data.rsm_nsm_obj || [];
			TsdNewRequest.divisionObj = data.approval_division_obj || [];
			TsdNewRequest.renderApprovers(data.approval_matrix_obj || [], data.asm_obj || [],
				data.approval_division_obj || []);
			TsdNewRequest.renderDocuments(data.query_docs_obj || []);
			if (!isPpc && !custState) {
				TsdNewRequest.showMsg(
					"Select Customer State to load ASM for Approver Details.", false);
			} else {
				TsdNewRequest.showMsg("", false);
			}
		}).fail(function (_xhr, status) {
			if (status === "abort") {
				return;
			}
			TsdNewRequest._$("#tsd_nr_approvers_table tbody").html(
				'<tr><td colspan="3" class="tsd-nr-placeholder">Unable to load approvers.</td></tr>');
			TsdNewRequest._$("#tsd_nr_documents_table tbody").html(
				'<tr><td colspan="2" class="tsd-nr-placeholder">Unable to load attachments.</td></tr>');
		}).always(function () {
			hideLoader("tsd_new_request_panel");
		});
	},

	renderApprovers: function (matrix, asmObj, divisionObj) {
		if (!matrix.length) {
			TsdNewRequest._$("#tsd_nr_approvers_table tbody").html(
				'<tr><td colspan="3" class="tsd-nr-placeholder">No approver matrix for this warranty type/entity.</td></tr>');
			return;
		}
		var html = "";
		for (var i = 0; i < matrix.length; i++) {
			var v = matrix[i] || {};
			var role = String(v.approver_role || "");
			var sequence = String(v.sequence || "");
			var pending = String(v.pending_with_enl_id || "");
			var cell = TsdNewRequest.esc(v.approver || "");
			if (role === "ASM") {
				var seqNum = Number(sequence);
				cell = TsdNewRequest.asmSelectHtml(asmObj, pending,
					seqNum === 7 ? "ASMUpload" : "ASM");
			} else if (role === "DM") {
				cell = TsdNewRequest.dmSelectHtml(divisionObj, pending);
			}
			html += '<tr class="tsd-nr-appr-row" data-sequence="' + TsdNewRequest.escAttr(sequence)
				+ '" data-role="' + TsdNewRequest.escAttr(role)
				+ '" data-source="' + TsdNewRequest.escAttr(v.approval_source || "")
				+ '" data-ui-status="' + TsdNewRequest.escAttr(v.ui_status || "") + '">'
				+ "<td>" + (i + 1) + "</td>"
				+ "<td>" + TsdNewRequest.esc(role) + "</td>"
				+ '<td class="tsd-nr-appr-name" data-role="' + TsdNewRequest.escAttr(role) + '">'
				+ cell + "</td></tr>";
		}
		TsdNewRequest._$("#tsd_nr_approvers_table tbody").html(html);
		TsdNewRequest._$("#tsd_nr_approvers_table tbody tr.tsd-nr-appr-row:last").hide();
		TsdNewRequest._$("#tsd_nr_approvers_table").off("change.tsdnr", "#ASM").on("change.tsdnr", "#ASM", function () {
			TsdNewRequest.populateRsmNsm();
		});
		TsdNewRequest._$("#tsd_nr_approvers_table").off("change.tsdnr", "#DM").on("change.tsdnr", "#DM", function () {
			TsdNewRequest.populateGroupManager();
		});
		if (asmObj.length === 1) {
			TsdNewRequest.populateRsmNsm();
		}
		if (TsdNewRequest._$("#DM").val()) {
			TsdNewRequest.populateGroupManager();
		}
	},

	asmSelectHtml: function (asmObj, selected, id) {
		var html = '<select id="' + TsdNewRequest.escAttr(id || "ASM")
			+ '" class="form-select form-select-sm"><option value="">Select One</option>';
		for (var i = 0; i < asmObj.length; i++) {
			var a = asmObj[i] || {};
			var enl = String(a.asm || "");
			var sel = (enl === selected || asmObj.length === 1) ? " selected" : "";
			html += '<option value="' + TsdNewRequest.escAttr(enl) + '" data-asm-int="'
				+ TsdNewRequest.escAttr(a.asm_int_code || "") + '"' + sel + ">"
				+ TsdNewRequest.esc(enl + "-" + (a.asm_name || "")) + "</option>";
		}
		return html + "</select>";
	},

	dmSelectHtml: function (divisionObj, selected) {
		var one = divisionObj.length === 1;
		var html = '<select id="DM" class="form-select form-select-sm"'
			+ (one ? " disabled" : "") + '><option value="">Select One</option>';
		for (var i = 0; i < divisionObj.length; i++) {
			var d = divisionObj[i] || {};
			var id = String(d.div_manager_id || "");
			var sel = (id === selected || one) ? " selected" : "";
			html += '<option value="' + TsdNewRequest.escAttr(id)
				+ '" data-grp-id="' + TsdNewRequest.escAttr(d.grp_manager_id || "")
				+ '" data-grp-name="' + TsdNewRequest.escAttr(d.grp_manager_name || "") + '"'
				+ sel + ">"
				+ TsdNewRequest.esc(id + "-" + (d.division_manager_name || "")) + "</option>";
		}
		return html + "</select>";
	},

	populateRsmNsm: function () {
		var $opt = TsdNewRequest._$("#ASM option:selected");
		var asmInt = String($opt.attr("data-asm-int") || "");
		var asmVal = String($opt.val() || "");
		if (TsdNewRequest._$("#ASMUpload").length) {
			TsdNewRequest._$("#ASMUpload").val(asmVal);
		}
		var list = TsdNewRequest.rsmNsmObj || [];
		for (var i = 0; i < list.length; i++) {
			var r = list[i] || {};
			if (String(r.asm || "") === asmInt) {
				TsdNewRequest._$("#tsd_nr_approvers_table td.tsd-nr-appr-name[data-role='RSM']")
					.text((r.rsm || "") + "-" + (r.rsm_name || ""));
				TsdNewRequest._$("#tsd_nr_approvers_table td.tsd-nr-appr-name[data-role='NSM']")
					.text((r.nsm || "") + "-" + (r.nsm_name || ""));
				return;
			}
		}
	},

	populateGroupManager: function () {
		var $opt = TsdNewRequest._$("#DM option:selected");
		var gid = String($opt.attr("data-grp-id") || "");
		var gname = String($opt.attr("data-grp-name") || "");
		TsdNewRequest._$("#tsd_nr_approvers_table td.tsd-nr-appr-name[data-role='GM']")
			.text(gid ? (gid + "-" + gname) : "");
	},

	clearDocPreviews: function () {
		Object.keys(TsdNewRequest._docPreviewUrls || {}).forEach(function (key) {
			TsdNewRequest.revokeDocPreview(key);
		});
	},

	revokeDocPreview: function (key) {
		var id = String(key || "");
		var url = TsdNewRequest._docPreviewUrls[id];
		if (url) {
			try { URL.revokeObjectURL(url); } catch (_e) { /* ignore */ }
			delete TsdNewRequest._docPreviewUrls[id];
		}
	},

	renderDocuments: function (docs) {
		docs = TsdNewRequest.mergeEditDocuments(docs || []);
		if (!docs.length) {
			TsdNewRequest._$("#tsd_nr_documents_table tbody").html(
				'<tr><td colspan="2" class="tsd-nr-placeholder">No attachments for this warranty type.</td></tr>');
			return;
		}
		var reqId = Number(TsdNewRequest.editIntCode) || 0;
		var html = "";
		for (var i = 0; i < docs.length; i++) {
			var d = docs[i] || {};
			var sl = i + 1;
			var docInt = String(d.doc_int_code || "").trim();
			var mandatory = String(d.mandatory || "") === "Yes";
			var removed = !!(TsdNewRequest._docRemoved && TsdNewRequest._docRemoved[docInt]);
			var fileName = removed ? "" : String(d.ftp_file_name || "").trim();
			var filePath = removed ? "" : String(d.ftp_file_path || "").trim();
			var docRowId = removed ? "" : String(d.doc_row_id || "").trim();
			var uploaded = !removed && (fileName !== "" || filePath !== "");
			var label = String(d.document_name || "").trim() || fileName || "Document";
			var viewHref = uploaded && reqId > 0
				? TsdNewRequest.existingDocDownloadUrl(reqId, docRowId, fileName, filePath)
				: "";
			var nameHtml = (mandatory ? '<span class="tsd-nr-req">*</span> ' : "")
				+ TsdNewRequest.esc(label);
			var metaHtml = "";
			if (uploaded && fileName) {
				metaHtml = '<div class="tsd-nr-file-meta text-muted" id="tsd_nr_file_size_' + sl + '">'
					+ "Uploaded: " + TsdNewRequest.esc(fileName)
					+ "</div>";
			} else {
				metaHtml = '<div class="tsd-nr-file-meta" id="tsd_nr_file_size_' + sl + '"></div>';
			}
			html += '<tr class="tsd-nr-doc-row" id="tsd_nr_doc_tr_' + sl + '"'
				+ ' data-doc-int="' + TsdNewRequest.escAttr(docInt)
				+ '" data-short="' + TsdNewRequest.escAttr(d.short_code || "")
				+ '" data-doc-row="' + TsdNewRequest.escAttr(docRowId)
				+ '" data-mandatory="' + (mandatory ? "Yes" : "No")
				+ '" data-uploaded="' + (uploaded ? "Yes" : "No")
				+ '" data-ftp-name="' + TsdNewRequest.escAttr(fileName)
				+ '" data-ftp-path="' + TsdNewRequest.escAttr(filePath)
				+ '" data-view-href="' + TsdNewRequest.escAttr(viewHref) + '">'
				+ "<td>" + nameHtml + metaHtml + "</td>"
				+ '<td><div class="tsd-nr-doc-file-cell">'
				+ '<input type="file" class="tsd-nr-doc-file" id="tsd_nr_document_'
				+ sl + '" accept=".xls,.xlsx,.pdf,.doc,.docx,.png,.jpg,.jpeg,.bmp,.zip"'
				+ ' tabindex="-1" aria-hidden="true"'
				+ (uploaded ? ' title="Choose a file to replace the uploaded document"' : "")
				+ ">"
				+ '<button type="button" class="tsd-nr-doc-browse" data-doc-sl="' + sl
				+ '" title="Browse file"><i class="ri-folder-open-line" aria-hidden="true"></i> Browse File</button>'
				+ TsdNewRequest.docActionsHtml(uploaded)
				+ "</div></td></tr>";
		}
		TsdNewRequest._$("#tsd_nr_documents_table tbody").html(html);
		TsdNewRequest._$("#tsd_nr_documents_table").off("change.tsdnr", ".tsd-nr-doc-file")
			.on("change.tsdnr", ".tsd-nr-doc-file", function () {
				TsdNewRequest.onDocFileChange(this);
			});
		TsdNewRequest._$("#tsd_nr_documents_table").off("click.tsdnrDocBrowse", ".tsd-nr-doc-browse")
			.on("click.tsdnrDocBrowse", ".tsd-nr-doc-browse", function (event) {
				event.preventDefault();
				var sl = String($(this).attr("data-doc-sl") || "");
				var input = TsdNewRequest._$("#tsd_nr_document_" + sl).get(0);
				if (input) {
					input.click();
				}
			});
		TsdNewRequest._$("#tsd_nr_documents_table").off("click.tsdnrDocView", ".tsd-nr-doc-view")
			.on("click.tsdnrDocView", ".tsd-nr-doc-view", function (event) {
				event.preventDefault();
				TsdNewRequest.viewAttachmentDocument($(this).closest("tr.tsd-nr-doc-row"));
			});
		TsdNewRequest._$("#tsd_nr_documents_table").off("click.tsdnrDocRemove", ".tsd-nr-doc-remove")
			.on("click.tsdnrDocRemove", ".tsd-nr-doc-remove", function (event) {
				event.preventDefault();
				TsdNewRequest.removeAttachmentDocument($(this).closest("tr.tsd-nr-doc-row"));
			});
		$(document).off("change.tsdnrSb", ".tsd-nr-sb-file")
			.on("change.tsdnrSb", ".tsd-nr-sb-file", function () {
				TsdNewRequest.onSignboardFileChange(this);
			});
	},

	docActionsHtml: function (show) {
		if (!show) {
			return '<div class="tsd-nr-doc-actions d-none" role="group" aria-label="Attachment actions">'
				+ '<button type="button" class="btn btn-sm btn-outline-primary tsd-nr-doc-view" title="View document" aria-label="View document">'
				+ '<i class="ri-eye-line" aria-hidden="true"></i></button>'
				+ '<button type="button" class="btn btn-sm btn-outline-danger tsd-nr-doc-remove" title="Remove document" aria-label="Remove document">'
				+ '<i class="ri-delete-bin-line" aria-hidden="true"></i></button>'
				+ "</div>";
		}
		return '<div class="tsd-nr-doc-actions" role="group" aria-label="Attachment actions">'
			+ '<button type="button" class="btn btn-sm btn-outline-primary tsd-nr-doc-view" title="View document" aria-label="View document">'
			+ '<i class="ri-eye-line" aria-hidden="true"></i></button>'
			+ '<button type="button" class="btn btn-sm btn-outline-danger tsd-nr-doc-remove" title="Remove document" aria-label="Remove document">'
			+ '<i class="ri-delete-bin-line" aria-hidden="true"></i></button>'
			+ "</div>";
	},

	syncDocActions: function ($tr, hasFile) {
		if (!$tr || !$tr.length) {
			return;
		}
		var $cell = $tr.find(".tsd-nr-doc-file-cell");
		if (!$cell.length) {
			return;
		}
		var $actions = $cell.find(".tsd-nr-doc-actions");
		if (!$actions.length) {
			$cell.append(TsdNewRequest.docActionsHtml(!!hasFile));
			return;
		}
		$actions.toggleClass("d-none", !hasFile);
	},

	viewAttachmentDocument: function ($tr) {
		if (!$tr || !$tr.length) {
			return;
		}
		var sl = String($tr.attr("id") || "").replace("tsd_nr_doc_tr_", "");
		var input = $tr.find(".tsd-nr-doc-file")[0];
		var file = input && input.files && input.files[0];
		// Client-side Browse only: preview from selected File blob.
		if (file) {
			TsdNewRequest.revokeDocPreview(sl);
			var objectUrl = URL.createObjectURL(file);
			TsdNewRequest._docPreviewUrls[sl] = objectUrl;
			window.open(objectUrl, "_blank", "noopener");
			return;
		}
		// Edit mode / already on server: open download URL directly (no blob).
		var href = String($tr.attr("data-view-href") || "").trim();
		if (!href) {
			var reqId = Number(TsdNewRequest.editIntCode) || 0;
			href = TsdNewRequest.existingDocDownloadUrl(
				reqId,
				$tr.attr("data-doc-row"),
				$tr.attr("data-ftp-name"),
				$tr.attr("data-ftp-path"));
		}
		if (!href) {
			TsdNewRequest.showMsg("No document is available to view.", true);
			return;
		}
		window.open(href, "_blank", "noopener");
	},

	removeAttachmentDocument: function ($tr) {
		if (!$tr || !$tr.length) {
			return;
		}
		var doRemove = function () {
			var sl = String($tr.attr("id") || "").replace("tsd_nr_doc_tr_", "");
			var docInt = String($tr.attr("data-doc-int") || "").trim();
			var input = $tr.find(".tsd-nr-doc-file")[0];
			TsdNewRequest.revokeDocPreview(sl);
			if (input) {
				input.value = "";
			}
			TsdNewRequest._$("#tsd_nr_file_size_" + sl).empty();
			if (docInt) {
				TsdNewRequest._docRemoved = TsdNewRequest._docRemoved || {};
				TsdNewRequest._docRemoved[docInt] = true;
			}
			$tr.attr("data-uploaded", "No");
			$tr.attr("data-ftp-name", "");
			$tr.attr("data-ftp-path", "");
			$tr.attr("data-doc-row", "");
			$tr.attr("data-view-href", "");
			TsdNewRequest.syncDocActions($tr, false);
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this document?",
				text: "The selected file will be removed from this request.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "Yes, delete",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#d33",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) {
					doRemove();
				}
			});
			if (window.jQuery) {
				$(".swal2-container").css("z-index", "22222229999");
			}
			return;
		}
		if (window.confirm("Delete this document?")) {
			doRemove();
		}
	},

	/**
	 * Overlay GET-detail documents onto master rows when edit join left them blank.
	 */
	mergeEditDocuments: function (docs) {
		var existing = TsdNewRequest.editDocuments || [];
		if (!existing.length) {
			return docs;
		}
		var byInt = {};
		for (var i = 0; i < existing.length; i++) {
			var e = existing[i] || {};
			var key = String(e.doc_int_code || "").trim();
			if (key) {
				byInt[key] = e;
			}
		}
		for (var j = 0; j < docs.length; j++) {
			var d = docs[j] || {};
			var docInt = String(d.doc_int_code || "").trim();
			var match = byInt[docInt];
			if (!match) {
				continue;
			}
			if (!String(d.ftp_file_name || "").trim()) {
				d.ftp_file_name = match.ftp_file_name || "";
			}
			if (!String(d.ftp_file_path || "").trim()) {
				d.ftp_file_path = match.ftp_file_path || "";
			}
			if (!String(d.doc_row_id || "").trim()) {
				d.doc_row_id = match.doc_row_id || "";
			}
		}
		return docs;
	},

	existingDocDownloadUrl: function (requestId, docRowId, fileName, filePath) {
		var reqId = Number(requestId) || 0;
		if (reqId <= 0) {
			return "";
		}
		var base = (window.$app_url || "") + TsdNewRequest.API + "/requests/"
			+ encodeURIComponent(String(reqId));
		var q = $.param({
			custCode: TsdNewRequest.custCode,
			loginId: TsdNewRequest.loginId || ""
		});
		var rowId = Number(docRowId) || 0;
		if (rowId > 0) {
			return base + "/documents/" + encodeURIComponent(String(rowId)) + "/download?" + q;
		}
		if (String(filePath || "").trim()) {
			return base + "/files/download?" + q + "&"
				+ $.param({ fileName: fileName || "document", filePath: filePath });
		}
		return "";
	},

	downloadExistingDocument: function (link) {
		var url = link.getAttribute("href");
		if (!url || url === "#" || link.getAttribute("aria-busy") === "true") {
			return false;
		}
		var $link = $(link);
		var label = $link.html();
		if (TsdNewRequest._docDownloadAbort) {
			try { TsdNewRequest._docDownloadAbort.abort(); } catch (_e) { /* ignore */ }
		}
		$link.attr("aria-busy", "true");
		showLoader("Downloading document...", "tsd_new_request_panel");
		var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
		TsdNewRequest._docDownloadAbort = controller;
		var fetchOpts = { credentials: "same-origin", cache: "no-store" };
		if (controller) {
			fetchOpts.signal = controller.signal;
		}
		fetch(url, fetchOpts)
			.then(function (response) {
				if (response.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					throw new Error("session");
				}
				if (!response.ok) {
					throw new Error("status");
				}
				var header = response.headers.get("Content-Disposition") || "";
				var encoded = /filename\*=UTF-8''([^;]+)/i.exec(header);
				var plain = /filename="([^"]+)"/i.exec(header);
				var name = encoded ? decodeURIComponent(encoded[1].trim())
					: (plain ? plain[1].trim() : "document");
				return response.blob().then(function (blob) {
					return { blob: blob, name: name };
				});
			})
			.then(function (file) {
				var objectUrl = URL.createObjectURL(file.blob);
				var saver = document.createElement("a");
				saver.href = objectUrl;
				saver.download = file.name || "document";
				document.body.appendChild(saver);
				saver.click();
				saver.remove();
				setTimeout(function () { URL.revokeObjectURL(objectUrl); }, 1500);
			})
			.catch(function (error) {
				if (error && error.name === "AbortError") {
					return;
				}
				if (!error || error.message !== "session") {
					TsdNewRequest.showMsg("The document could not be downloaded.", true);
				}
			})
			.finally(function () {
				$link.attr("aria-busy", "false").html(label);
				TsdNewRequest._docDownloadAbort = null;
				hideLoader("tsd_new_request_panel");
			});
		return false;
	},

	/** 3M portal limit: all attachments in one save must stay under 5 MB. */
	MAX_TOTAL_ATTACH_MB: 5,

	onDocFileChange: function (input) {
		var $input = $(input);
		var id = String($input.attr("id") || "").replace("tsd_nr_document_", "");
		var file = input.files && input.files[0];
		var $meta = TsdNewRequest._$("#tsd_nr_file_size_" + id);
		var $tr = $input.closest("tr.tsd-nr-doc-row");
		var docInt = String($tr.attr("data-doc-int") || "").trim();
		if (!file) {
			$meta.empty();
			var stillPrev = String($tr.attr("data-uploaded") || "") === "Yes";
			TsdNewRequest.syncDocActions($tr, stillPrev);
			return;
		}
		if (!TsdNewRequest.acceptUploadFile($input, file, $meta)) {
			TsdNewRequest.syncDocActions($tr, String($tr.attr("data-uploaded") || "") === "Yes");
			return;
		}
		if (docInt && TsdNewRequest._docRemoved) {
			delete TsdNewRequest._docRemoved[docInt];
		}
		TsdNewRequest.revokeDocPreview(id);
		var mb = file.size / (1024 * 1024);
		$meta.html("Uploaded file Size: " + (Math.round(mb * 100) / 100) + " Mb<br>File Name: "
			+ TsdNewRequest.esc(file.name));
		TsdNewRequest.syncDocActions($tr, true);
	},

	onSignboardFileChange: function (input) {
		var $input = $(input);
		var file = input.files && input.files[0];
		if (!file) {
			return;
		}
		TsdNewRequest.acceptUploadFile($input, file, null);
	},

	/** Extension + per-file size; clears input on reject. */
	acceptUploadFile: function ($input, file, $meta) {
		var ext = String(file.name.split(".").pop() || "").toLowerCase();
		var ok = ["xls", "pdf", "xlsx", "doc", "docx", "png", "jpg", "jpeg", "bmp", "zip"];
		if (ok.indexOf(ext) < 0) {
			$input.val("");
			if ($meta && $meta.length) {
				$meta.empty();
			}
			TsdNewRequest.showMsg("Only Image, PDF, Excel, Word, or Zip files are supported.", true);
			return false;
		}
		var mb = file.size / (1024 * 1024);
		var max = TsdNewRequest.MAX_TOTAL_ATTACH_MB;
		if (mb > max) {
			$input.val("");
			if ($meta && $meta.length) {
				$meta.empty();
			}
			TsdNewRequest.showMsg(
				"Each attachment must be " + max + " MB or smaller.", true);
			return false;
		}
		return true;
	},

	/** Sum Attachment Details + Product Details file sizes (MB). */
	totalSelectedAttachMb: function () {
		var totMb = 0;
		TsdNewRequest._$("#tsd_nr_documents_table tbody tr.tsd-nr-doc-row").each(function () {
			var input = $(this).find(".tsd-nr-doc-file")[0];
			var file = input && input.files && input.files[0];
			if (file) {
				totMb += file.size / (1024 * 1024);
			}
		});
		$(".tsd-nr-sb-file").each(function () {
			var file = this.files && this.files[0];
			if (file) {
				totMb += file.size / (1024 * 1024);
			}
		});
		return totMb;
	},

	radio: function (name) {
		return String(TsdNewRequest._$("input[name='" + name + "']:checked").val() || "").trim();
	},

	val: function (id) {
		return String(TsdNewRequest._$(id).val() || "").trim();
	},

	buildPayload: function (saveType) {
		var type = TsdNewRequest.selectedWarrantyType();
		var d = TsdNewRequest.distributor || {};
		var n = Number(TsdNewRequest.val("#tsd_nr_no_of_products")) || 1;
		var products = [];
		for (var i = 1; i <= n; i++) {
			products.push({
				internal_code: String(i),
				prod_type: TsdNewRequest.val("#tsd_nr_prod_type_" + i),
				prod_int_code: TsdNewRequest.val("#tsd_nr_prod_code_" + i),
				work_order_details: TsdNewRequest.val("#tsd_nr_work_order_" + i),
				project_name: TsdNewRequest.val("#tsd_nr_project_" + i),
				warr_years: TsdNewRequest.val("#tsd_nr_warr_years_" + i),
				remarks: TsdNewRequest.val("#tsd_nr_prod_remarks_" + i),
				actual_date_instal: TsdNewRequest.toUiDate(
					TsdNewRequest.val("#tsd_nr_install_date_" + i)),
				ppc_qty: TsdNewRequest.val("#tsd_nr_ppc_qty_" + i) || "0",
				ppc_uom: TsdNewRequest.val("#tsd_nr_ppc_uom_" + i),
				tender_no: TsdNewRequest.val("#tsd_nr_tender_no"),
				sign_board_table_columns: TsdNewRequest.val("#tsd_nr_prod_sb_cols_" + i),
				table_name: TsdNewRequest.val("#tsd_nr_prod_tbl_name_" + i),
				table_columns: TsdNewRequest.val("#tsd_nr_prod_tbl_cols_" + i),
				signboard_rows: TsdNewRequest.collectSignboardRows(i),
				tender_doc_name: "",
				tender_doc_path: ""
			});
		}
		return {
			header: {
				save_type: saveType,
				editIntCode: TsdNewRequest.editIntCode || 0,
				warr_type: type,
				cust_type: TsdNewRequest.radio("tsd_nr_cust_type"),
				first_pq_warr: TsdNewRequest.radio("tsd_nr_first_pq"),
				conv_relationship: TsdNewRequest.radio("tsd_nr_conv_rel"),
				pq_cert_iss: TsdNewRequest.radio("tsd_nr_pq_cert"),
				agreement_signed: TsdNewRequest.radio("tsd_nr_agreement"),
				signed_current: TsdNewRequest.radio("tsd_nr_sister_cert"),
				conv_sis_certified: TsdNewRequest.radio("tsd_nr_sop_mcs"),
				customer_remarks: TsdNewRequest.val("#tsd_nr_remarks"),
				customer_name: TsdNewRequest.val("#tsd_nr_cust_name"),
				customer_address1: TsdNewRequest.val("#tsd_nr_cust_addr1"),
				customer_address2: TsdNewRequest.val("#tsd_nr_cust_addr2"),
				cust_state: TsdNewRequest.val("#tsd_nr_cust_state"),
				contractor_name: TsdNewRequest.val("#tsd_nr_contractor_name"),
				contractor_address1: TsdNewRequest.val("#tsd_nr_contractor_addr1"),
				contractor_address2: TsdNewRequest.val("#tsd_nr_contractor_addr2"),
				contractor_state: TsdNewRequest.val("#tsd_nr_contractor_state"),
				tender_no: TsdNewRequest.val("#tsd_nr_tender_no"),
				acc_overdue_status: TsdNewRequest.radio("tsd_nr_acc_overdue"),
				due_deligence_status: "",
				other_comments: "",
				fyi: "",
				warranty_exists: TsdNewRequest.radio("tsd_nr_warranty_exists"),
				warranty_no: TsdNewRequest.val("#tsd_nr_warranty_no"),
				first_ppc_cert: TsdNewRequest.radio("tsd_nr_first_ppc"),
				dist_agr_signed: TsdNewRequest.radio("tsd_nr_ppc_agreement"),
				dist_name: TsdNewRequest.val("#tsd_nr_ppc_dist_name") || (d.conv_display || ""),
				buyer_name: TsdNewRequest.val("#tsd_nr_buyer_name"),
				date_of_sale: TsdNewRequest.toUiDate(
					TsdNewRequest.val("#tsd_nr_date_of_sale")),
				no_of_products: String(n),
				dist_int_code: TsdNewRequest.val("#tsd_nr_dist_int_code") || (d.dist_int_code || ""),
				req_dist: d.conv_code || TsdNewRequest.custCode,
				g_tsd_RoleCode: "",
				prod_type: "",
				product_name: "",
				work_order_details: "",
				warr_years: "",
				sign_board_table_columns: "",
				table_name: "",
				table_columns: "",
				ppc_quantity_produced: "0"
			},
			products: products,
			approvers: TsdNewRequest.collectApprovers()
		};
	},

	collectApprovers: function () {
		var list = [];
		TsdNewRequest._$("#tsd_nr_approvers_table tbody tr.tsd-nr-appr-row").each(function () {
			var $tr = $(this);
			var role = String($tr.attr("data-role") || "");
			var approverId = "";
			if (role === "ASM" || role === "DM") {
				approverId = String($tr.find("select").first().val() || "").trim();
			} else {
				approverId = String($tr.find("td.tsd-nr-appr-name").text() || "").split("-")[0].trim();
			}
			list.push({
				sequence: String($tr.attr("data-sequence") || ""),
				approver_role: role,
				approver_id: approverId,
				approval_source: String($tr.attr("data-source") || ""),
				ui_status: String($tr.attr("data-ui-status") || "")
			});
		});
		return list;
	},

	/** Returns null if OK, else { msg, focus }. */
	validateClient: function (payload) {
		var fail = TsdNewRequest.fail;
		var h = payload.header || {};
		var type = h.warr_type;
		if (!type) {
			return fail("Please select Warranty Type.", "#tsd_nr_warranty_types");
		}
		if (type !== "PPC for Retail Sale") {
			if (!h.cust_type) {
				return fail("Please select Converter/Applicator.", "input[name='tsd_nr_cust_type']");
			}
			if (!h.first_pq_warr) {
				return fail("Please answer: first time PQ warranty.", "input[name='tsd_nr_first_pq']");
			}
			if (!h.conv_relationship) {
				return fail("Please answer: relationship with existing 3M converters.",
					"input[name='tsd_nr_conv_rel']");
			}
			if (h.conv_relationship === "Sister Concern") {
				TsdNewRequest._$("input[name='tsd_nr_conv_rel'][value='No Relationship']").prop("checked", true);
				return fail("You cannot raise the request for Sister Concern.",
					"input[name='tsd_nr_conv_rel']");
			}
			if (!h.pq_cert_iss) {
				return fail("Please answer: PQ certificates by competition.",
					"input[name='tsd_nr_pq_cert']");
			}
			if (!h.agreement_signed) {
				return fail("Please answer: converter/applicator agreement.",
					"input[name='tsd_nr_agreement']");
			}
			if (!h.signed_current) {
				return fail("Please answer: sister companies certified by us.",
					"input[name='tsd_nr_sister_cert']");
			}
			if (!h.conv_sis_certified) {
				return fail("Please answer: signboards manufactured per 3M SOP/MCS.",
					"input[name='tsd_nr_sop_mcs']");
			}
			if (!h.customer_name) {
				return fail("Please enter Customer.", "#tsd_nr_cust_name");
			}
			if (!h.customer_address1) {
				return fail("Please enter Customer Address 1 and 2.", "#tsd_nr_cust_addr1");
			}
			if (!h.customer_address2) {
				return fail("Please enter Customer Address 1 and 2.", "#tsd_nr_cust_addr2");
			}
			if (!h.cust_state) {
				return fail("Please select Customer State.", "#tsd_nr_cust_state");
			}
			if (!h.contractor_name) {
				return fail("Please enter Contractor.", "#tsd_nr_contractor_name");
			}
			if (!h.contractor_address1) {
				return fail("Please enter Contractor Address 1 and 2.", "#tsd_nr_contractor_addr1");
			}
			if (!h.contractor_address2) {
				return fail("Please enter Contractor Address 1 and 2.", "#tsd_nr_contractor_addr2");
			}
			if (!h.contractor_state) {
				return fail("Please select Contractor State.", "#tsd_nr_contractor_state");
			}
			if (!h.customer_remarks) {
				return fail("Please enter Remarks.", "#tsd_nr_remarks");
			}
			if (!h.tender_no) {
				return fail("Please enter Tender/Ref No.", "#tsd_nr_tender_no");
			}
		}
		if (type === "Actual Warranty") {
			if (!h.warranty_exists) {
				return fail("Please select Does PQ Warranty Exists?", "#tsd_nr_warranty_exists");
			}
			if (h.warranty_exists === "Yes" && !h.warranty_no) {
				return fail("Please enter Warranty No.", "#tsd_nr_warranty_no");
			}
		}
		if (type === "Actual Warranty" || type === "PPC for Retail Sale") {
			if (!h.acc_overdue_status) {
				return fail("Please select Account Overdue Status.", "#tsd_nr_account_overdue");
			}
			if (h.acc_overdue_status === "Overdue") {
				return fail(
					"You cannot raise this request as you selected account as overdue.",
					"#tsd_nr_account_overdue");
			}
		}
		if (type === "PPC for Retail Sale") {
			if (!h.first_ppc_cert) {
				return fail("Please answer: first time PPC certificate.",
					"input[name='tsd_nr_first_ppc']");
			}
			if (!h.dist_agr_signed) {
				return fail("Please answer: distributor agreement signed and current.",
					"input[name='tsd_nr_ppc_agreement']");
			}
			if (!h.buyer_name) {
				return fail("Please enter Buyer Details.", "#tsd_nr_buyer_name");
			}
			if (!h.date_of_sale) {
				return fail("Please select Date of Sale.", "#tsd_nr_date_of_sale");
			}
		}
		var products = payload.products || [];
		for (var i = 0; i < products.length; i++) {
			var p = products[i];
			var tab = i + 1;
			if (!p.prod_type) {
				return fail("Product " + tab + ": select Product Type.", "#tsd_nr_prod_type_" + tab);
			}
			if (!p.prod_int_code) {
				return fail("Product " + tab + ": select Product Name from the list.",
					"#tsd_nr_prod_name_" + tab);
			}
			if (!p.project_name) {
				return fail("Product " + tab + ": enter Project Name.", "#tsd_nr_project_" + tab);
			}
			if (type !== "PQ Warranty" && !p.work_order_details) {
				return fail("Product " + tab + ": enter WorkOrder/PO Details.",
					"#tsd_nr_work_order_" + tab);
			}
			if (type === "Actual Warranty" && !p.actual_date_instal) {
				return fail("Product " + tab + ": enter Actual Installation Date.",
					"#tsd_nr_install_date_" + tab);
			}
			if (type === "PPC for Retail Sale" && !p.ppc_uom) {
				return fail("Product " + tab + ": enter PPC UOM.", "#tsd_nr_ppc_uom_" + tab);
			}
		}
		var approvers = payload.approvers || [];
		if (!approvers.length) {
			return fail("Please enter Approver Details.", "#tsd_nr_approvers_table");
		}
		for (var a = 0; a < approvers.length; a++) {
			if (!String(approvers[a].approver_id || "").trim()) {
				var $row = TsdNewRequest._$("#tsd_nr_approvers_table tbody tr.tsd-nr-appr-row").eq(a);
				var $sel = $row.find("select").first();
				return fail("Please enter Approver Details.",
					$sel.length ? $sel : "#tsd_nr_approvers_table");
			}
		}
		var $docFail = null;
		TsdNewRequest._$("#tsd_nr_documents_table tbody tr.tsd-nr-doc-row").each(function () {
			var $tr = $(this);
			var mandatory = String($tr.attr("data-mandatory") || "") === "Yes";
			var uploadedEarlier = String($tr.attr("data-uploaded") || "") === "Yes";
			var input = $tr.find(".tsd-nr-doc-file")[0];
			var file = input && input.files && input.files[0];
			if (mandatory && !uploadedEarlier && !file && !$docFail) {
				$docFail = $tr.find(".tsd-nr-doc-file");
			}
		});
		if ($docFail && $docFail.length) {
			return fail("Upload all mandatory attachments.", $docFail);
		}
		var totMb = TsdNewRequest.totalSelectedAttachMb();
		var maxMb = TsdNewRequest.MAX_TOTAL_ATTACH_MB;
		if (totMb > maxMb) {
			return fail(
				"Total size of all attachments (Product Details + Documents) must be "
					+ maxMb + " MB or less. Current: "
					+ (Math.round(totMb * 100) / 100) + " MB.",
				"#tsd_nr_documents_table");
		}
		return null;
	},

	save: function (saveType) {
		if (TsdNewRequest.saving) {
			return;
		}
		if ((window.Tsd && Tsd.needsConverter) || !TsdNewRequest.custCode) {
			TsdNewRequest.showMsg("Select a converter before saving.", true);
			return;
		}
		var payload = TsdNewRequest.buildPayload(saveType);
		var err = TsdNewRequest.validateClient(payload);
		if (err) {
			TsdNewRequest.showMsg(err.msg, true, true);
			TsdNewRequest.highlightField(err.focus);
			return;
		}
		TsdNewRequest.clearFieldErrors();
		var form = new FormData();
		form.append("payload", JSON.stringify(payload));
		TsdNewRequest._$("#tsd_nr_documents_table tbody tr.tsd-nr-doc-row").each(function () {
			var $tr = $(this);
			var input = $tr.find(".tsd-nr-doc-file")[0];
			var file = input && input.files && input.files[0];
			if (!file) {
				return;
			}
			var docInt = String($tr.attr("data-doc-int") || "");
			var shortCode = String($tr.attr("data-short") || docInt);
			form.append("header~" + docInt + "~" + shortCode, file);
		});
		var nProd = Number(TsdNewRequest.val("#tsd_nr_no_of_products")) || 1;
		for (var pi = 1; pi <= nProd; pi++) {
			TsdNewRequest._$("#tsd_nr_sb_table_" + pi + " tbody tr").each(function (idx) {
				var input = $(this).find(".tsd-nr-sb-file")[0];
				var file = input && input.files && input.files[0];
				if (!file) {
					return;
				}
				form.append("signboard~" + pi + "~" + (idx + 1), file);
			});
		}
		TsdNewRequest.saving = true;
		TsdNewRequest._$("#tsd_nr_draft, #tsd_nr_submit").prop("disabled", true);
		showLoader("Saving request...", "tsd_new_request_panel");
		$.ajax({
			url: (window.$app_url || "") + TsdNewRequest.API + "/requests"
				+ "?custCode=" + encodeURIComponent(TsdNewRequest.custCode)
				+ "&loginId=" + encodeURIComponent(TsdNewRequest.loginId || ""),
			method: "POST",
			data: form,
			processData: false,
			contentType: false,
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (TsdNewRequest.isSessionGone(json)) {
				return;
			}
			/* Error → stay on New Request. */
			if (!TsdNewRequest.ok(json)) {
				TsdNewRequest.showMsg((json && json.message) || "Unable to save request.", true);
				return;
			}
			var data = json.data || {};
			var msg = data.message || ("Saved. Request No: " + (data.reqId || ""));
			/* Success → alert OK, then My Requests. */
			TsdNewRequest.afterSaveSuccess(msg, saveType);
		}).fail(function () {
			TsdNewRequest.showMsg("Unable to save request.", true);
		}).always(function () {
			TsdNewRequest.saving = false;
			TsdNewRequest._$("#tsd_nr_draft, #tsd_nr_submit").prop("disabled", false);
			hideLoader("tsd_new_request_panel");
		});
	},

	/** Alert success; after OK go to My Requests. */
	afterSaveSuccess: function (message, saveType) {
		var text = String(message || "Request saved successfully.").trim();
		var title = saveType === "Submit" ? "Submitted" : "Draft saved";
		var goMyRequests = function () {
			if (window.Tsd) {
				Tsd.requestsHtmlLoaded = false;
				TsdNewRequest._$("#tsd_my_requests_panel").empty();
				if (typeof Tsd.showTab === "function") {
					Tsd.showTab("requests");
				}
			}
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: title,
				text: text,
				icon: "success",
				confirmButtonText: "OK",
				confirmButtonColor: "#0b6bcb",
				allowOutsideClick: false,
				allowEscapeKey: false
			}).then(function () {
				goMyRequests();
			});
			if (window.jQuery) {
				$(".swal2-container").css("z-index", "22222229999");
			}
			return;
		}
		window.alert(text);
		goMyRequests();
	},

	ok: function (json) {
		if (!json) {
			return false;
		}
		var code = json.errorCode != null ? json.errorCode : json.error_code;
		return code == null || Number(code) === 0;
	},

	isSessionGone: function (json) {
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			if (window.inpcHandleSessionExpired) {
				window.inpcHandleSessionExpired(json.message || "Please login once again");
			}
			return true;
		}
		return false;
	},

	/**
	 * Page alert — same classes/kind as Ship & Debit {@code Common.showPageMsg}
	 * on a local #tsd_nr_message banner (CSS matches #inpc_page_msg).
	 * Validation/errors → warning; success → success. Scrolls banner into view.
	 */
	showMsg: function (message, isError, skipScroll) {
		var text = String(message || "").trim();
		var $msg = TsdNewRequest._$("#tsd_nr_message");
		if (!$msg.length) {
			return;
		}
		if (!text) {
			$msg.attr("class", "alert d-none tsd-nr-msg mb-2 py-2 px-3").text("");
			return;
		}
		/* Same kind mapping as Ship & Debit validation (warning) / success. */
		var kind = isError ? "warning" : "success";
		$msg.attr("class", "alert alert-" + kind + " tsd-nr-msg mb-2 py-2 px-3").text(text);
		if (!skipScroll) {
			TsdNewRequest.scrollToMsg();
		}
	},

	scrollToMsg: function () {
		var el = TsdNewRequest._$("#tsd_nr_message").get(0);
		if (!el) {
			return;
		}
		try {
			el.scrollIntoView({ behavior: "smooth", block: "start" });
		} catch (e1) {
			try {
				el.scrollIntoView(true);
			} catch (e2) { /* ignore */ }
		}
		/* Also nudge common portal scroll parents (module panel / window). */
		var $panel = TsdNewRequest._$("#tsd_new_request_panel");
		if ($panel.length && $panel[0].scrollHeight > $panel[0].clientHeight) {
			$panel.stop(true).animate({ scrollTop: 0 }, 250);
		}
		var $home = TsdNewRequest._$home();
		if ($home.length && $home[0].scrollHeight > $home[0].clientHeight) {
			$home.stop(true).animate({ scrollTop: 0 }, 250);
		}
		try {
			window.scrollTo({ top: 0, behavior: "smooth" });
		} catch (e3) {
			window.scrollTo(0, 0);
		}
	},

	esc: function (value) {
		return String(value == null ? "" : value)
			.replace(/&/g, "&amp;")
			.replace(/</g, "&lt;")
			.replace(/>/g, "&gt;")
			.replace(/"/g, "&quot;")
			.replace(/'/g, "&#39;");
	},

	escAttr: function (value) {
		return TsdNewRequest.esc(value);
	}
};
