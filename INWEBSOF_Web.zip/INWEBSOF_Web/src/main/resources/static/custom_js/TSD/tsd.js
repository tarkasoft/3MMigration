/**
 * TSD E-Warranty — simple jQuery only.
 * Flow: Load → context → tabs → .load HTML once → list API → DataTable.
 * Change Converter: button on shell (role INPC_TSD_CHANGE_CONVERTER).
 */
Tsd = {
	API: "api/customer/tsd",
	HOME: "m_tsd_home",
	TABLE_ROOT: "m_tsd_requests_table_root",
	custCode: "",
	loginId: "",
	canChangeConverter: false,
	needsConverter: false,
	requestsHtmlLoaded: false,
	newHtmlLoaded: false,
	_acAjax: null,
	_converterPickedCode: "",
	detailRequestId: 0,
	pendingEditIntCode: 0,
	_downloadAbort: null,

	/**
	 * Active TSD shell (multi-tab safe). Prefer InpcTabs active pane, else visible home.
	 */
	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + Tsd.HOME) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $("#" + Tsd.HOME).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $("#" + Tsd.HOME).first();
	},

	/** Find within #m_tsd_home so duplicate ids in other portal tabs are ignored. */
	_$: function (selector) {
		var $home = Tsd._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	/* ---------- start ---------- */
	Load: function () {
		var ctx = Common.GetProcedureCustomerContext
			? (Common.GetProcedureCustomerContext() || {})
			: {};
		Tsd.custCode = String(ctx.custCode || (Common.GetCustCode ? Common.GetCustCode() : "") || "").trim();
		Tsd.loginId = String(ctx.loginId || (Common.GetLoginId ? Common.GetLoginId() : "") || "").trim();
		Tsd.requestsHtmlLoaded = false;
		Tsd.newHtmlLoaded = false;
		Tsd.canChangeConverter = false;
		Tsd.needsConverter = false;

		Tsd._$("#tsd_my_requests_tab").off("click").on("click", function () {
			Tsd.showTab("requests");
		});
		Tsd._$("#tsd_new_request_tab").off("click").on("click", function () {
			Tsd.showTab("new");
		});
		Tsd._$("#tsd_change_converter_btn").off("click").on("click", function () {
			Tsd.openConverterModal();
		});
		/* mousedown preventDefault: AC input blur otherwise eats the first Apply/Clear click */
		Tsd._$("#tsd_converter_apply").off("click.tsdConv mousedown.tsdConv")
			.on("mousedown.tsdConv", function (e) {
				e.preventDefault();
			})
			.on("click.tsdConv", function () {
				Tsd.applyConverter();
			});
		Tsd._$("#tsd_converter_clear").off("click.tsdConv mousedown.tsdConv")
			.on("mousedown.tsdConv", function (e) {
				e.preventDefault();
			})
			.on("click.tsdConv", function () {
				Tsd.clearConverter();
			});

		Tsd.loadContext(function () {
			Tsd.showTab("requests");
			if (Tsd.needsConverter) {
				Tsd.openConverterModal();
			}
		});
	},

	/* ---------- tabs ---------- */
	showTab: function (name) {
		var isRequests = name !== "new";
		Tsd._$("#tsd_my_requests_tab").attr("aria-selected", isRequests ? "true" : "false");
		Tsd._$("#tsd_new_request_tab").attr("aria-selected", isRequests ? "false" : "true");
		Tsd._$("#tsd_my_requests_panel").toggleClass("d-none", !isRequests);
		Tsd._$("#tsd_new_request_panel").toggleClass("d-none", isRequests);
		if (isRequests) {
			Tsd.openRequestsTab();
		} else {
			Tsd.openNewTab();
		}
	},

	openRequestsTab: function () {
		if (Tsd.requestsHtmlLoaded && Tsd._$("#m_tsd_requests").length) {
			return;
		}
		var url = (window.$app_url || "") + "html_files/TSD/tsd_requests.html?r=" + Date.now();
		showLoader("Loading My Requests...", "m_tsd_home");
		Tsd._$("#tsd_my_requests_panel").load(url, function (_html, status) {
			hideLoader("m_tsd_home");
			if (status !== "success") {
				Tsd._$("#tsd_my_requests_panel").html(
					'<div class="alert alert-danger m-3">Unable to load My Requests.</div>');
				return;
			}
			Tsd.requestsHtmlLoaded = true;
			Tsd.initTable();
			Tsd.loadRequests();
		});
	},

	openNewTab: function () {
		var editing = Number(Tsd.pendingEditIntCode) > 0;
		var loaderMsg = editing ? "Loading draft for edit..." : "Loading New Request...";
		if (Tsd.newHtmlLoaded && Tsd._$("#m_tsd_new_request").length) {
			if (editing) {
				showLoader(loaderMsg, "m_tsd_home");
			}
			Tsd.ensureNewRequestJs(function () {
				if (window.TsdNewRequest && typeof TsdNewRequest.Load === "function") {
					TsdNewRequest.Load();
				}
			});
			return;
		}
		var url = (window.$app_url || "") + "html_files/TSD/tsd_new_request.html?r=" + Date.now();
		showLoader(loaderMsg, "m_tsd_home");
		Tsd._$("#tsd_new_request_panel").load(url, function (_html, status) {
			/* Edit keeps home loader until loadEditRequest completes. */
			if (!editing) {
				hideLoader("m_tsd_home");
			}
			if (status !== "success") {
				hideLoader("m_tsd_home");
				Tsd._$("#tsd_new_request_panel").html(
					'<div class="alert alert-danger m-3">Unable to load New Request.</div>');
				return;
			}
			Tsd.newHtmlLoaded = true;
			Tsd.ensureNewRequestJs(function () {
				if (window.TsdNewRequest && typeof TsdNewRequest.Load === "function") {
					TsdNewRequest.Load();
				}
			});
		});
	},

	ensureNewRequestJs: function (done) {
		if (window.TsdNewRequest && typeof TsdNewRequest.Load === "function") {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		if (Tsd._newJsLoading) {
			Tsd._newJsQueue = Tsd._newJsQueue || [];
			Tsd._newJsQueue.push(done);
			return;
		}
		Tsd._newJsLoading = true;
		$.getScript((window.$app_url || "") + "custom_js/TSD/tsd_new_request.js")
			.done(function () {
				Tsd._newJsLoading = false;
				if (typeof done === "function") {
					done();
				}
				var q = Tsd._newJsQueue || [];
				Tsd._newJsQueue = [];
				for (var i = 0; i < q.length; i++) {
					if (typeof q[i] === "function") {
						q[i]();
					}
				}
			})
			.fail(function () {
				Tsd._newJsLoading = false;
				Tsd._newJsQueue = [];
				Tsd._$("#tsd_new_request_panel").prepend(
					'<div class="alert alert-danger m-3">Unable to load New Request script.</div>');
			});
	},

	/* ---------- context ---------- */
	loadContext: function (done) {
		showLoader("Loading TSD E-Warranty...", "m_tsd_home");
		$.ajax({
			url: (window.$app_url || "") + Tsd.API + "/context",
			method: "GET",
			data: { custCode: Tsd.custCode, loginId: Tsd.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (Tsd.isSessionGone(json)) {
				hideLoader("m_tsd_home");
				return;
			}
			if (!Tsd.ok(json)) {
				var msg = (json && json.message) || "Unable to load converter context.";
				Tsd._$("#tsd_context_label").text(msg);
				hideLoader("m_tsd_home");
				return;
			}
			var data = json.data || {};
			Tsd.custCode = String(data.convCode || data.custCode || Tsd.custCode).trim();
			Tsd.canChangeConverter = !!data.canChangeConverter;
			Tsd.needsConverter = !!data.needsConverterSelection;
			Tsd.showConverterButton(Tsd.canChangeConverter);
			if (data.convDisplay) {
				Tsd._$("#tsd_context_label").text("Converter: " + data.convDisplay
					+ (data.source === "change_converter" ? " (module override)" : ""));
			} else if (Tsd.needsConverter) {
				Tsd._$("#tsd_context_label").text("Select a converter to continue");
			} else {
				Tsd._$("#tsd_context_label").text("Converter ready");
			}
			/* Hide before done() so My Requests loader is not cleared. */
			hideLoader("m_tsd_home");
			if (typeof done === "function") {
				done();
			}
		}).fail(function () {
			Tsd._$("#tsd_context_label").text("Unable to load converter context.");
			hideLoader("m_tsd_home");
		});
	},

	showConverterButton: function (show) {
		Tsd._$("#tsd_change_converter_btn").toggleClass("is-visible", !!show);
	},

	/* ---------- Change Converter modal ---------- */
	openConverterModal: function () {
		if (!Tsd.canChangeConverter) {
			return;
		}
		Tsd._$("#tsd_converter_code").val("");
		Tsd._$("#tsd_converter_picked_code").val("");
		Tsd._converterPickedCode = "";
		Tsd.converterMsg("", false);
		if (window.Common && Common.HideAcSpinner) {
			Common.HideAcSpinner("#tsd_converter_modal", "tsd_converter_ac_spinner");
		}
		Tsd.wireConverterAutocomplete();
		var el = Tsd._$("#tsd_converter_modal").get(0);
		if (!el) {
			return;
		}
		if (window.bootstrap && bootstrap.Modal) {
			bootstrap.Modal.getOrCreateInstance(el).show();
		} else if ($.fn.modal) {
			$(el).modal("show");
		}
	},

	hideConverterModal: function () {
		var el = Tsd._$("#tsd_converter_modal").get(0);
		if (!el) {
			return;
		}
		if (window.bootstrap && bootstrap.Modal) {
			bootstrap.Modal.getOrCreateInstance(el).hide();
		} else if ($.fn.modal) {
			$(el).modal("hide");
		}
	},

	wireConverterAutocomplete: function () {
		var $txt = Tsd._$("#tsd_converter_code");
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		try {
			if ($txt.data("ui-autocomplete")) {
				$txt.autocomplete("destroy");
			}
		} catch (e) { /* ignore */ }

		$txt.autocomplete({
			minLength: 1,
			appendTo: Tsd._$("#tsd_converter_modal .modal-body"),
			position: { my: "left top", at: "left bottom", collision: "flip" },
			open: function () {
				$(this).autocomplete("widget").css({ zIndex: 2060, position: "absolute" });
			},
			source: function (request, response) {
				Tsd._$("#tsd_converter_picked_code").val("");
				Tsd._converterPickedCode = "";
				Tsd.converterMsg("", false);
				if (Tsd._acAjax && Tsd._acAjax.abort) {
					Tsd._acAjax.abort();
				}
				if (window.Common && Common.ShowAcSpinner) {
					Common.ShowAcSpinner("#tsd_converter_modal", "tsd_converter_ac_spinner");
				}
				Tsd._acAjax = $.ajax({
					url: (window.$app_url || "") + Tsd.API + "/converters/autocomplete",
					method: "GET",
					data: { value: request.term },
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (Tsd.isSessionGone(json)) {
						response([]);
						return;
					}
					if (!Tsd.ok(json)) {
						Tsd.converterMsg((json && json.message) || "Unable to search converters.", true);
						response([]);
						return;
					}
					var rows = json.data || [];
					if (!rows.length) {
						Tsd.converterMsg("No converter found for \"" + String(request.term || "").trim()
							+ "\". Try another code or name from your mapped list.", true);
						response([]);
						return;
					}
					Tsd.converterMsg("", false);
					response(rows);
				}).fail(function (_xhr, status) {
					if (status !== "abort") {
						Tsd.converterMsg("Unable to search converters.", true);
						response([]);
					}
				}).always(function () {
					if (window.Common && Common.HideAcSpinner) {
						Common.HideAcSpinner("#tsd_converter_modal", "tsd_converter_ac_spinner");
					}
					$txt.removeClass("ui-autocomplete-loading");
				});
			},
			focus: function () {
				return false;
			},
			select: function (_event, ui) {
				var item = ui.item || {};
				var code = String(item.code || "").trim();
				if (!code && item.value) {
					var v = String(item.value);
					code = v.indexOf(" - ") >= 0 ? v.split(" - ")[0].trim() : v.trim();
				}
				Tsd._converterPickedCode = code;
				Tsd._$("#tsd_converter_picked_code").val(code);
				this.value = item.value || item.code || "";
				Tsd.converterMsg("", false);
				return false;
			}
		});
	},

	applyConverter: function () {
		try {
			var $txt = Tsd._$("#tsd_converter_code");
			if ($txt.length && $txt.data("ui-autocomplete")) {
				$txt.autocomplete("close");
			}
		} catch (eClose) { /* ignore */ }
		var code = String(Tsd._converterPickedCode
			|| Tsd._$("#tsd_converter_picked_code").val() || "").trim();
		if (!code) {
			/* allow typing "code - name" or bare code */
			var typed = String(Tsd._$("#tsd_converter_code").val() || "").trim();
			if (typed.indexOf(" - ") >= 0) {
				code = typed.split(" - ")[0].trim();
			} else {
				code = typed;
			}
		}
		if (!code) {
			Tsd.converterMsg("Select a converter from the list.", true);
			return;
		}
		Tsd._$("#tsd_converter_apply").prop("disabled", true);
		Tsd._$("#tsd_converter_clear").prop("disabled", true);
		showLoader("Applying converter...", "tsd_converter_modal");
		$.ajax({
			url: (window.$app_url || "") + Tsd.API + "/converter",
			method: "POST",
			contentType: "application/json",
			data: JSON.stringify({ convCode: code }),
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (Tsd.isSessionGone(json)) {
				return;
			}
			if (!Tsd.ok(json)) {
				Tsd.converterMsg((json && json.message) || "Unable to set converter.", true);
				return;
			}
			var data = json.data || {};
			Tsd.custCode = String(data.convCode || code).trim();
			Tsd.needsConverter = false;
			Tsd._$("#tsd_context_label").text(
				data.convDisplay ? ("Converter: " + data.convDisplay + " (module override)") : ("Converter: " + Tsd.custCode));
			Tsd.converterMsg("Converter applied.", false);
			Tsd.hideConverterModal();
			Tsd.reloadRequestsAfterConverterChange();
		}).fail(function () {
			Tsd.converterMsg("Unable to set converter.", true);
		}).always(function () {
			hideLoader("tsd_converter_modal");
			Tsd._$("#tsd_converter_apply").prop("disabled", false);
			Tsd._$("#tsd_converter_clear").prop("disabled", false);
		});
	},

	clearConverter: function () {
		Tsd._$("#tsd_converter_apply").prop("disabled", true);
		Tsd._$("#tsd_converter_clear").prop("disabled", true);
		showLoader("Clearing converter...", "tsd_converter_modal");
		$.ajax({
			url: (window.$app_url || "") + Tsd.API + "/converter/clear",
			method: "POST",
			data: { custCode: Tsd.custCode, loginId: Tsd.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (Tsd.isSessionGone(json)) {
				return;
			}
			if (!Tsd.ok(json)) {
				Tsd.converterMsg((json && json.message) || "Unable to clear converter.", true);
				return;
			}
			var data = json.data || {};
			Tsd.custCode = String(data.convCode || "").trim();
			Tsd.needsConverter = !!data.needsConverterSelection;
			if (data.convDisplay) {
				Tsd._$("#tsd_context_label").text("Converter: " + data.convDisplay);
			} else {
				Tsd._$("#tsd_context_label").text("Select a converter to continue");
			}
			Tsd.converterMsg("Module converter cleared.", false);
			Tsd.hideConverterModal();
			Tsd.reloadRequestsAfterConverterChange();
		}).fail(function () {
			Tsd.converterMsg("Unable to clear converter.", true);
		}).always(function () {
			hideLoader("tsd_converter_modal");
			Tsd._$("#tsd_converter_apply").prop("disabled", false);
			Tsd._$("#tsd_converter_clear").prop("disabled", false);
		});
	},

	reloadRequestsAfterConverterChange: function () {
		Tsd.newHtmlLoaded = false;
		Tsd._$("#tsd_new_request_panel").empty();
		if (Tsd._$("#m_tsd_requests").length) {
			Tsd.loadRequests();
		} else {
			Tsd.requestsHtmlLoaded = false;
			Tsd.showTab("requests");
		}
	},

	converterMsg: function (message, isError) {
		Tsd._$("#tsd_converter_msg")
			.toggleClass("alert-danger", !!isError)
			.toggleClass("alert-success", !isError)
			.toggleClass("d-none", !message)
			.text(message || "");
	},

	/* ---------- list ---------- */
	loadRequests: function () {
		if (Tsd.needsConverter || !Tsd.custCode) {
			Tsd.showMsg("Use Change Converter (top right) to select a converter first.", true);
			if (Tsd.canChangeConverter) {
				Tsd.openConverterModal();
			}
			return;
		}
		Tsd._$("#tsd_requests_refresh").prop("disabled", true).addClass("is-refreshing");
		showLoader("Loading warranty requests...", "tsd_my_requests_panel");
		$.ajax({
			url: (window.$app_url || "") + Tsd.API + "/requests",
			method: "GET",
			data: { custCode: Tsd.custCode, loginId: Tsd.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (Tsd.isSessionGone(json)) {
				return;
			}
			if (!Tsd.ok(json)) {
				var msg = (json && json.message) || "Unable to load requests.";
				Tsd.showMsg(msg, true);
				if (/Change Converter/i.test(msg) && Tsd.canChangeConverter) {
					Tsd.openConverterModal();
				}
				return;
			}
			var list = (json.data && json.data.header_details) || [];
			var rows = [];
			for (var i = 0; i < list.length; i++) {
				rows.push(Tsd.toRow(list[i]));
			}
			Common.DataTable.setData(Tsd.TABLE_ROOT, rows);
			Tsd.showMsg(rows.length ? "" : "No warranty requests found for this converter.", false);
		}).fail(function () {
			Tsd.showMsg("Unable to load warranty requests.", true);
		}).always(function () {
			hideLoader("tsd_my_requests_panel");
			Tsd._$("#tsd_requests_refresh").prop("disabled", false).removeClass("is-refreshing");
		});
	},

	initTable: function () {
		Common.DataTable.init({
			rootId: Tsd.TABLE_ROOT,
			tableId: "tsd_requests_table",
			tbodyId: "tsd_requests_rows",
			pageSizes: [50, 100, 150, 200],
			pageSize: 50,
			filter_type: "minimal",
			searchPlaceholder: "Search requests...",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "full",
			maxHeight: "520px",
			emptyMessage: "No warranty requests found for this converter.",
			columns: [
				{ title: "View", field: "action_html", type: "html", searchable: false, sortable: false, width: 70 },
				{ title: "Converter/Applicator", field: "dist_name", sortable: true, width: 260 },
				{ title: "Request ID", field: "req_id", sortable: true, width: 140 },
				{ title: "Request Date", field: "req_date", sortable: true, width: 130 },
				{ title: "Warranty Type", field: "wrty_type", sortable: true, width: 180 },
				{ title: "Status", field: "status_html", type: "html", searchable: true, sortable: false, width: 220 }
			],
			rows: []
		});
		Tsd._$("#tsd_requests_table").off("click", ".tsd-view-request")
			.on("click", ".tsd-view-request", function () {
				var id = Number($(this).attr("data-int-code") || 0);
				Tsd.openRequestDetail(id);
			});
		Tsd._$("#tsd_requests_refresh").off("click").on("click", function () {
			Tsd.loadRequests();
		});
	},

	toRow: function (row) {
		var reqId = String(row.req_id == null ? "" : row.req_id);
		var reqDate = String(row.req_date == null ? "" : row.req_date);
		var dist = String(row.dist_name == null ? "" : row.dist_name);
		var type = String(row.wrty_type == null ? "" : row.wrty_type);
		var status = String(row.wrr_status == null ? "" : row.wrr_status);
		var intCode = String(row.req_int_code == null ? "" : row.req_int_code);
		return {
			dist_name: dist,
			req_id: reqId,
			req_date: reqDate,
			wrty_type: type,
			action_html:
				'<button type="button" class="tsd-view-request" title="View request" aria-label="View request"'
				+ ' data-int-code="' + Tsd.esc(intCode) + '"'
				+ ' data-req-id="' + Tsd.esc(reqId) + '">'
				+ '<i class="ri-eye-line" aria-hidden="true"></i></button>',
			status_html: '<span class="tsd-status">' + Tsd.esc(status) + "</span>"
		};
	},

	openRequestDetail: function (internalCode) {
		if (!internalCode) {
			Tsd.showMsg("Request id is missing.", true);
			return;
		}
		Tsd.detailRequestId = Number(internalCode) || 0;
		Tsd.abortDocumentDownload();
		Tsd._$("#tsd_detail_edit_btn").addClass("d-none").off("click.tsdEdit");
		Tsd._$("#tsd_detail_title").text("Request Details");
		Tsd._$("#tsd_detail_content").html('<div class="text-muted small p-2">Loading request details...</div>');
		Tsd.showDetailModal();
		var fragUrl = (window.$app_url || "") + "html_files/TSD/tsd_detail_popup.html?r=" + Date.now();
		Tsd._$("#tsd_detail_content").load(fragUrl, function (_html, status) {
			if (status !== "success") {
				Tsd._$("#tsd_detail_content").html('<div class="alert alert-danger">Unable to load Request Details UI.</div>');
				return;
			}
			Tsd.loadRequestDetail(internalCode);
		});
	},

	showDetailModal: function () {
		var el = Tsd._$("#tsd_detail_modal").get(0);
		if (!el) {
			return;
		}
		if (window.bootstrap && bootstrap.Modal) {
			bootstrap.Modal.getOrCreateInstance(el).show();
		} else if ($.fn.modal) {
			$(el).modal("show");
		}
	},

	hideDetailModal: function () {
		var el = Tsd._$("#tsd_detail_modal").get(0);
		if (!el) {
			return;
		}
		if (window.bootstrap && bootstrap.Modal) {
			var inst = bootstrap.Modal.getInstance(el);
			if (inst) {
				inst.hide();
			}
		} else if ($.fn.modal) {
			$(el).modal("hide");
		}
	},

	/**
	 * Legacy {@code TSDReqPopup.EditRequestData(id)} — Draft/Rework only.
	 * Confirm → close popup → open New Request tab and reload draft for save.
	 */
	EditRequestData: function (internalCode) {
		var id = Number(internalCode || Tsd.detailRequestId) || 0;
		if (!id) {
			Tsd.showMsg("Request id is missing.", true);
			return;
		}
		var proceed = function () {
			Tsd.pendingEditIntCode = id;
			Tsd.hideDetailModal();
			Tsd.newHtmlLoaded = false;
			Tsd._$("#tsd_new_request_panel").empty();
			/* Keep spinner until GET /requests/{id} finishes in loadEditRequest. */
			showLoader("Loading draft for edit...", "m_tsd_home");
			Tsd.showTab("new");
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Edit Request?",
				text: "Open this Draft/Rework request in New Request for update?",
				icon: "question",
				showCancelButton: true,
				confirmButtonText: "Yes, edit",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#0b6bcb",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) {
					proceed();
				}
			});
			if (window.jQuery) {
				$(".swal2-container").css("z-index", "22222229999");
			}
			return;
		}
		if (window.confirm("Open this Draft/Rework request in New Request for update?")) {
			proceed();
		}
	},

	loadRequestDetail: function (internalCode) {
		showLoader("Loading request details...", "tsd_detail_content");
		$.ajax({
			url: (window.$app_url || "") + Tsd.API + "/requests/" + encodeURIComponent(internalCode),
			method: "GET",
			data: { custCode: Tsd.custCode, loginId: Tsd.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (Tsd.isSessionGone(json)) {
				return;
			}
			if (!Tsd.ok(json)) {
				Tsd._$("#tsd_d_msg").removeClass("d-none alert-success").addClass("alert alert-danger")
					.text((json && json.message) || "Unable to load request details.");
				return;
			}
			Tsd.renderRequestDetail(json.data || {});
		}).fail(function () {
			Tsd._$("#tsd_d_msg").removeClass("d-none alert-success").addClass("alert alert-danger")
				.text("Unable to load request details.");
		}).always(function () {
			hideLoader("tsd_detail_content");
		});
	},

	renderRequestDetail: function (data) {
		var h = data.header || {};
		var type = String(h.wrty_type || "");
		var isPpc = type === "PPC for Retail Sale";
		var isActual = type === "Actual Warranty";
		Tsd.detailRequestId = Number(h.internal_code || Tsd.detailRequestId) || 0;

		Tsd._$("#tsd_d_req_id").text(h.req_id || "");
		Tsd._$("#tsd_d_warr_type").text(type);
		Tsd._$("#tsd_d_status").text(h.wrr_status || "");
		Tsd._$("#tsd_detail_title").text("Request Details");

		Tsd._$("#tsd_d_pq_family").toggleClass("tsd-d-hidden", isPpc);
		Tsd._$("#tsd_d_ppc_family").toggleClass("tsd-d-hidden", !isPpc);
		Tsd._$("#tsd_d_actual_extra").toggleClass("tsd-d-hidden", !isActual);
		Tsd._$("#tsd_d_overdue_row").toggleClass("tsd-d-hidden", !(isActual || isPpc));

		Tsd._$("#tsd_d_is_conv").text(h.is_conv_appl || "");
		Tsd._$("#tsd_d_first_pq").text(h.is_first_pq_war || "");
		Tsd._$("#tsd_d_rel").text(h.rel_with_exist_cust || "");
		Tsd._$("#tsd_d_pq_cert").text(h.pq_cert_issued || "");
		Tsd._$("#tsd_d_agreement").text(h.agreement_signed || "");
		Tsd._$("#tsd_d_signed_current").text(h.signed_current || "");
		Tsd._$("#tsd_d_sop").text(h.certified_by_us || "");
		Tsd._$("#tsd_d_remarks").text(h.cust_remarks || "");
		Tsd._$("#tsd_d_pq_exists").text(h.pq_warranty_exists || "");
		Tsd._$("#tsd_d_warranty_no").text(h.warranty_no || "");

		Tsd._$("#tsd_d_dist_name").text(h.distributor || "");
		Tsd._$("#tsd_d_dist_details").html(
			"<b>Address:</b> " + Tsd.esc(h.dist_address || "")
			+ " &nbsp; <b>City:</b> " + Tsd.esc(h.dist_city || "")
			+ " &nbsp; <b>Phone No:</b> " + Tsd.esc(h.dist_phone || "")
			+ " &nbsp; <b>Email:</b> " + Tsd.esc(h.dist_email || ""));
		Tsd._$("#tsd_d_cust_name").text(h.customer_name || "");
		Tsd._$("#tsd_d_cust_details").html(
			"<b>Address:</b> " + Tsd.esc(h.cust_address || "")
			+ " &nbsp; <b>State</b>: " + Tsd.esc(h.cust_state || ""));
		Tsd._$("#tsd_d_contract_name").text(h.contract_name || "");
		Tsd._$("#tsd_d_contract_details").html(
			"<b>Address:</b> " + Tsd.esc(h.contract_address || "")
			+ " &nbsp; <b>State</b>: " + Tsd.esc(h.contract_state || ""));

		Tsd._$("#tsd_d_first_ppc").text(h.is_first_time_ppc || "");
		Tsd._$("#tsd_d_ppc_agr").text(h.is_dist_signed_curr || "");
		Tsd._$("#tsd_d_ppc_dist").text(h.ppc_distibutor || h.distributor || "");
		Tsd._$("#tsd_d_buyer").text(h.buyer_name || "");
		Tsd._$("#tsd_d_sale_date").text(h.date_of_sale || "");
		Tsd._$("#tsd_d_tender").text(h.p_tender_no || "");
		Tsd._$("#tsd_d_overdue").text(h.acc_overdue_status || "");

		Tsd.renderDetailProducts(data.products || [], type);
		Tsd.renderDetailApprovers(data.approvers || []);
		Tsd.renderDetailDocuments(data.documents || [], Tsd.detailRequestId);
		Tsd.renderDetailHistory(data.history || []);

		var status = String(h.wrr_status || "").trim();
		var canEdit = /^(Draft|Rework)$/i.test(status);
		var $editBtn = Tsd._$("#tsd_detail_edit_btn");
		$editBtn.toggleClass("d-none", !canEdit);
		$editBtn.off("click.tsdEdit").on("click.tsdEdit", function () {
			Tsd.EditRequestData(Tsd.detailRequestId);
		});

		Tsd._$("#tsd_detail_modal .tsd-d-bottom-tabs button").off("click.tsdd")
			.on("click.tsdd", function () {
				var pane = $(this).attr("data-pane");
				Tsd._$("#tsd_detail_modal .tsd-d-bottom-tabs button")
					.removeClass("is-active").attr("aria-selected", "false");
				$(this).addClass("is-active").attr("aria-selected", "true");
				Tsd._$("#tsd_detail_modal .tsd-d-pane").removeClass("is-active");
				Tsd._$("#tsd_d_pane_" + pane).addClass("is-active");
			});
		Tsd._$("#tsd_detail_modal").off("click.tsdDoc", "a.tsd-doc-download")
			.on("click.tsdDoc", "a.tsd-doc-download", function (event) {
				event.preventDefault();
				Tsd.downloadDocument(this);
			});
	},

	renderDetailProducts: function (products, type) {
		var colors = ["#e3fdcd", "#dcfccc", "#ecfdcd", "#ecfdb1", "#e4f3b1", "#fcfccc", "#f2fcb8", "#ddfdcd", "#ecfdcd", "#fcfccc"];
		var tabs = "";
		var panels = "";
		var isActual = type === "Actual Warranty";
		var isPpc = type === "PPC for Retail Sale";
		var status = String(Tsd._$("#tsd_d_status").text() || "").trim();
		var showCert = /^Approved$/i.test(status);
		if (!products.length) {
			Tsd._$("#tsd_d_prod_tabs").html("");
			Tsd._$("#tsd_d_prod_panels").html('<div class="text-muted small">No products found.</div>');
			return;
		}
		for (var i = 0; i < products.length; i++) {
			var p = products[i] || {};
			var n = i + 1;
			var bg = colors[i % colors.length];
			var prodRowId = String(p.internal_code || "");
			var slNo = String(p.prod_sl_no || n);
			tabs += '<li><button type="button" class="tsd-d-prod-tab' + (i === 0 ? " is-active" : "")
				+ '" data-prod="' + n + '" style="--tsd-prod-bg:' + bg + '">Product ' + n + "</button></li>";
			panels += '<div class="tsd-d-prod-panel' + (i === 0 ? " is-active" : "")
				+ '" id="tsd_d_prod_' + n + '" style="--tsd-prod-bg:' + bg + '"'
				+ ' data-product-row-id="' + Tsd.escAttr(prodRowId) + '"'
				+ ' data-prod-int-code="' + Tsd.escAttr(p.prod_int_code) + '">'
				+ '<div class="tsd-d-prod-grid">'
				+ "<label>Product Type</label><input class='form-control form-control-sm' disabled value='"
				+ Tsd.escAttr(p.product_type) + "'>"
				+ "<label>Product Name</label><input class='form-control form-control-sm' disabled value='"
				+ Tsd.escAttr(p.product_name) + "'>"
				+ "<label>Work Order Details</label>"
				+ "<textarea class='form-control form-control-sm' rows='2' disabled>"
				+ Tsd.esc(p.work_order_details) + "</textarea>"
				+ "<label>No of warranty years</label><input class='form-control form-control-sm' disabled value='"
				+ Tsd.escAttr(p.no_of_warrnty_years) + "'>"
				+ "<label>Project Name</label>"
				+ "<textarea class='form-control form-control-sm' rows='2' disabled>"
				+ Tsd.esc(p.project_name) + "</textarea>"
				+ "<label>Remarks</label>"
				+ "<textarea class='form-control form-control-sm' rows='2' disabled>"
				+ Tsd.esc(p.comments) + "</textarea>";
			if (isActual) {
				panels += "<label>Actual Installation Date</label><input class='form-control form-control-sm' disabled value='"
					+ Tsd.escAttr(p.actual_date_of_instl) + "'>";
			}
			if (isPpc) {
				panels += "<label>PPC Qty</label><input class='form-control form-control-sm' disabled value='"
					+ Tsd.escAttr(p.ppc_qty) + "'>"
					+ "<label>PPC UOM</label><input class='form-control form-control-sm' disabled value='"
					+ Tsd.escAttr(p.ppc_uom) + "'>";
			}
			panels += "</div>";
			panels += Tsd.renderWarrantyCertificate(p, slNo, showCert);
			panels += Tsd.renderSignboardBlock(p, prodRowId);
			panels += "</div>";
		}
		Tsd._$("#tsd_d_prod_tabs").html(tabs);
		Tsd._$("#tsd_d_prod_panels").html(panels);
		Tsd._$("#tsd_d_prod_tabs").off("click.tsdd", ".tsd-d-prod-tab")
			.on("click.tsdd", ".tsd-d-prod-tab", function () {
				var n = $(this).attr("data-prod");
				Tsd._$("#tsd_d_prod_tabs .tsd-d-prod-tab").removeClass("is-active");
				$(this).addClass("is-active");
				Tsd._$("#tsd_d_prod_panels .tsd-d-prod-panel").removeClass("is-active");
				Tsd._$("#tsd_d_prod_" + n).addClass("is-active");
			});
		Tsd._$("#tsd_detail_modal").off("click.tsdExcel", ".tsd-d-excel-btn")
			.on("click.tsdExcel", ".tsd-d-excel-btn", function () {
				Tsd.openSignboardExcelModal($(this).attr("data-product-row-id"));
			});
		Tsd._$("#tsd_detail_modal").off("click.tsdFile", "a.tsd-file-download")
			.on("click.tsdFile", "a.tsd-file-download", function (event) {
				event.preventDefault();
				Tsd.downloadDocument(this);
			});
	},

	renderWarrantyCertificate: function (product, slNo, showCert) {
		var prodInt = String(product.prod_int_code || product.product_code || "").trim();
		if (!showCert || !prodInt) {
			return "";
		}
		var url = (window.$app_url || "") + Tsd.API + "/requests/"
			+ encodeURIComponent(String(Tsd.detailRequestId))
			+ "/products/" + encodeURIComponent(prodInt) + "/warranty-pdf?"
			+ $.param({
				custCode: Tsd.custCode,
				loginId: Tsd.loginId
			});
		return '<div class="tsd-d-warr-cert">'
			+ '<div class="tsd-d-warr-cert-card">'
			+ '<span class="tsd-d-warr-cert-icon" aria-hidden="true"><i class="ri-award-fill"></i></span>'
			+ '<span class="tsd-d-warr-cert-copy">'
			+ '<span class="tsd-d-warr-cert-title">Warranty Certificate</span>'
			+ '<span class="tsd-d-warr-cert-sub">Product ' + Tsd.esc(slNo)
			+ ' · Approved PDF ready</span>'
			+ "</span>"
			+ '<a class="tsd-d-warr-cert-btn tsd-file-download tsd-doc-download" href="'
			+ Tsd.esc(url) + '" title="Download Warranty Certificate">'
			+ '<i class="ri-download-2-line" aria-hidden="true"></i>'
			+ "<span>Download</span></a>"
			+ "</div></div>";
	},

	renderSignboardBlock: function (product, prodRowId) {
		var columns = String(product.prod_sign_board_table_columns || "").trim();
		var rows = Array.isArray(product.signboard_rows) ? product.signboard_rows : [];
		if (!columns && rows.length && rows[0].table_columns) {
			columns = String(rows[0].table_columns || "").trim();
		}
		var label = String(product.sign_board_table_label || "").trim() || "Product Details";
		var notes = String(product.sign_board_table_remarks || "").trim();
		var html = '<div class="tsd-d-signboard">';
		html += '<div class="tsd-d-signboard-title">' + Tsd.esc(label) + "</div>";
		if (columns) {
			html += Tsd.renderSignboardTable(columns, rows);
		} else if (rows.length) {
			html += '<div class="text-muted small">Signboard column metadata is missing for this product.</div>';
		}
		if (notes) {
			html += '<div class="tsd-d-signboard-notes">Notes:- ' + Tsd.esc(notes) + "</div>";
		}
		html += '<button type="button" class="tsd-d-excel-btn" data-product-row-id="'
			+ Tsd.escAttr(prodRowId) + '">'
			+ '<i class="ri-edit-line" aria-hidden="true"></i> Upload Signboard Excel</button>';
		html += "</div>";
		return html;
	},

	renderSignboardTable: function (columnsCsv, rows) {
		var cols = String(columnsCsv || "").split(",");
		var html = '<div class="tsd-d-signboard-wrap"><table class="tsd-d-signboard"><thead><tr>';
		for (var c = 0; c < cols.length; c++) {
			html += "<th>" + Tsd.esc(cols[c]) + "</th>";
		}
		html += "</tr></thead><tbody>";
		if (!rows.length) {
			html += '<tr><td colspan="' + cols.length
				+ '" class="text-muted">No signboard rows. Use Upload Signboard Excel.</td></tr>';
		} else {
			for (var i = 0; i < rows.length; i++) {
				var r = rows[i] || {};
				var cells = String(r.tr_data || "").split("~");
				var fileName = String(r.signboard_filename || "").trim();
				var filePath = String(r.signboard_filepath || "").trim();
				html += "<tr>";
				for (var j = 0; j < cols.length; j++) {
					var colName = String(cols[j] || "").trim();
					if (/^document$/i.test(colName)) {
						if (fileName && filePath) {
							var url = (window.$app_url || "") + Tsd.API + "/requests/"
								+ encodeURIComponent(String(Tsd.detailRequestId)) + "/files/download?"
								+ $.param({
									fileName: fileName,
									filePath: filePath,
									custCode: Tsd.custCode,
									loginId: Tsd.loginId
								});
							html += '<td><a class="tsd-file-download tsd-doc-download" href="'
								+ Tsd.esc(url) + '">SignBoard Document'
								+ ' <i class="ri-download-2-line" aria-hidden="true"></i></a></td>';
						} else {
							html += "<td></td>";
						}
					} else {
						html += "<td><input class='form-control form-control-sm' disabled value='"
							+ Tsd.escAttr(cells[j] == null ? "" : cells[j]) + "'></td>";
					}
				}
				html += "</tr>";
			}
		}
		html += "</tbody></table></div>";
		return html;
	},

	openSignboardExcelModal: function (productRowId) {
		if (!Tsd.detailRequestId || !productRowId) {
			Tsd.showMsg("Product id is missing for Signboard Excel.", true);
			return;
		}
		Tsd._$("#tsd_sign_product_row_id").val(productRowId);
		Tsd._$("#tsd_sign_header_int_code").val(Tsd.detailRequestId);
		Tsd._$("#tsd_signboard_file").val("");
		Tsd._$("#tsd_signboard_excel_msg").addClass("d-none").removeClass("alert-success alert-danger").text("");
		Tsd._$("#tsd_signboard_download_btn").off("click").on("click", function () {
			Tsd.downloadSignboardExcel();
		});
		Tsd._$("#tsd_signboard_upload_btn").off("click").on("click", function () {
			Tsd.uploadSignboardExcel();
		});
		var el = Tsd._$("#tsd_signboard_excel_modal").get(0);
		if (!el) {
			return;
		}
		if (window.bootstrap && bootstrap.Modal) {
			bootstrap.Modal.getOrCreateInstance(el).show();
		} else if ($.fn.modal) {
			$(el).modal("show");
		}
	},

	downloadSignboardExcel: function () {
		var productRowId = String(Tsd._$("#tsd_sign_product_row_id").val() || "").trim();
		if (!productRowId || !Tsd.detailRequestId) {
			return;
		}
		var url = (window.$app_url || "") + Tsd.API + "/requests/"
			+ encodeURIComponent(String(Tsd.detailRequestId)) + "/products/"
			+ encodeURIComponent(productRowId) + "/signboard/excel?"
			+ $.param({ custCode: Tsd.custCode, loginId: Tsd.loginId });
		window.open(url, "_blank");
	},

	uploadSignboardExcel: function () {
		var productRowId = String(Tsd._$("#tsd_sign_product_row_id").val() || "").trim();
		var fileInput = Tsd._$("#tsd_signboard_file").get(0);
		var file = fileInput && fileInput.files && fileInput.files[0];
		if (!productRowId || !Tsd.detailRequestId) {
			return;
		}
		if (!file) {
			Tsd._$("#tsd_signboard_excel_msg").removeClass("d-none alert-success").addClass("alert alert-danger")
				.text("Choose an Excel file to upload.");
			return;
		}
		var fd = new FormData();
		fd.append("file", file);
		fd.append("custCode", Tsd.custCode || "");
		fd.append("loginId", Tsd.loginId || "");
		Tsd._$("#tsd_signboard_upload_btn").prop("disabled", true);
		showLoader("Uploading signboard Excel...", "tsd_signboard_excel_modal");
		$.ajax({
			url: (window.$app_url || "") + Tsd.API + "/requests/"
				+ encodeURIComponent(String(Tsd.detailRequestId)) + "/products/"
				+ encodeURIComponent(productRowId) + "/signboard/excel",
			method: "POST",
			data: fd,
			processData: false,
			contentType: false,
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (Tsd.isSessionGone(json)) {
				return;
			}
			if (!Tsd.ok(json)) {
				Tsd._$("#tsd_signboard_excel_msg").removeClass("d-none alert-success").addClass("alert alert-danger")
					.text((json && json.message) || "Unable to upload Excel.");
				return;
			}
			Tsd._$("#tsd_signboard_excel_msg").removeClass("d-none alert-danger").addClass("alert alert-success")
				.text((json && json.message) || "Uploaded successfully.");
			Tsd.loadRequestDetail(Tsd.detailRequestId);
		}).fail(function () {
			Tsd._$("#tsd_signboard_excel_msg").removeClass("d-none alert-success").addClass("alert alert-danger")
				.text("Unable to upload Excel.");
		}).always(function () {
			Tsd._$("#tsd_signboard_upload_btn").prop("disabled", false);
			hideLoader("tsd_signboard_excel_modal");
		});
	},

	renderDetailApprovers: function (rows) {
		if (!rows.length) {
			Tsd._$("#tsd_d_approvers_body").html('<tr><td colspan="6" class="text-muted">No approver details.</td></tr>');
			return;
		}
		var html = "";
		for (var i = 0; i < rows.length; i++) {
			var r = rows[i] || {};
			html += "<tr><td>" + (i + 1) + "</td><td>" + Tsd.esc(r.approver_role)
				+ "</td><td>" + Tsd.esc(r.approver)
				+ "</td><td>" + Tsd.esc(r.approval_status)
				+ "</td><td>" + Tsd.esc(r.approval_remarks)
				+ "</td><td>" + Tsd.esc(r.modified_date) + "</td></tr>";
		}
		Tsd._$("#tsd_d_approvers_body").html(html);
	},

	renderDetailDocuments: function (rows, requestId) {
		if (!rows.length) {
			Tsd._$("#tsd_d_documents_body").html('<tr><td colspan="2" class="text-muted">No documents.</td></tr>');
			return;
		}
		var reqId = Number(requestId) || 0;
		var html = "";
		for (var i = 0; i < rows.length; i++) {
			var r = rows[i] || {};
			var name = String(r.document_name || "").trim();
			var file = String(r.ftp_file_name || "").trim();
			var path = String(r.ftp_file_path || "").trim();
			var docId = Number(r.doc_row_id || 0);
			var label = name || file || "Document";
			var cell = Tsd.esc(label);
			if (file && name && file.toLowerCase() !== name.toLowerCase()) {
				cell += " <span class=\"text-muted\">(" + Tsd.esc(file) + ")</span>";
			}
			if (reqId > 0 && docId > 0 && (file || path)) {
				var url = (window.$app_url || "") + Tsd.API + "/requests/"
					+ encodeURIComponent(String(reqId)) + "/documents/"
					+ encodeURIComponent(String(docId)) + "/download?"
					+ $.param({ custCode: Tsd.custCode, loginId: Tsd.loginId });
				cell = '<a class="tsd-doc-download" href="' + Tsd.esc(url) + '">'
					+ Tsd.esc(label)
					+ ' <i class="ri-download-2-line" aria-hidden="true" title="Download"></i></a>';
				if (file && name && file.toLowerCase() !== name.toLowerCase()) {
					cell += ' <span class="text-muted">(' + Tsd.esc(file) + ")</span>";
				}
			}
			html += "<tr><td>" + (i + 1) + "</td><td>" + cell + "</td></tr>";
		}
		Tsd._$("#tsd_d_documents_body").html(html);
	},

	abortDocumentDownload: function () {
		if (Tsd._downloadAbort) {
			try { Tsd._downloadAbort.abort(); } catch (_e) { /* ignore */ }
			Tsd._downloadAbort = null;
		}
	},

	downloadDocument: function (link) {
		var url = link.getAttribute("href");
		if (!url || link.getAttribute("aria-busy") === "true") {
			return false;
		}
		var $link = $(link);
		var label = $link.html();
		Tsd.abortDocumentDownload();
		Tsd._$("#tsd_detail_content .tsd-download-error").remove();
		$link.attr("aria-busy", "true");
		$link.html('<i class="ri-loader-4-line" aria-hidden="true"></i> Downloading');
		showLoader("Downloading document...", "tsd_detail_content");
		var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
		Tsd._downloadAbort = controller;
		var fetchOpts = { credentials: "same-origin", cache: "no-store" };
		if (controller) {
			fetchOpts.signal = controller.signal;
		}
		fetch(url, fetchOpts)
			.then(function (response) {
				if (response.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					throw new Error("session");
				}
				if (!response.ok) {
					throw new Error("status");
				}
				var header = response.headers.get("Content-Disposition") || "";
				var encoded = /filename\*=UTF-8''([^;]+)/i.exec(header);
				var plain = /filename="([^"]+)"/i.exec(header);
				var name = encoded ? decodeURIComponent(encoded[1].trim())
					: (plain ? plain[1].trim() : "document");
				return response.blob().then(function (blob) {
					return { blob: blob, name: name };
				});
			})
			.then(function (file) {
				var objectUrl = URL.createObjectURL(file.blob);
				var saver = document.createElement("a");
				saver.href = objectUrl;
				saver.download = file.name || "document";
				document.body.appendChild(saver);
				saver.click();
				saver.remove();
				setTimeout(function () { URL.revokeObjectURL(objectUrl); }, 1500);
			})
			.catch(function (error) {
				if (error && (error.name === "AbortError" || error.message === "AbortError")) {
					return;
				}
				if (!error || error.message !== "session") {
					Tsd._$("#tsd_detail_content").prepend(
						'<div class="alert alert-danger tsd-download-error mb-2" role="alert">'
						+ "The document could not be downloaded.</div>");
				}
			})
			.finally(function () {
				if (Tsd._downloadAbort === controller) {
					Tsd._downloadAbort = null;
				}
				try {
					$link.attr("aria-busy", "false").html(label);
				} catch (_e) { /* link may be gone */ }
				hideLoader("tsd_detail_content");
			});
		return false;
	},

	renderDetailHistory: function (rows) {
		if (!rows.length) {
			Tsd._$("#tsd_d_history_body").html('<tr><td colspan="7" class="text-muted">No history.</td></tr>');
			return;
		}
		var html = "";
		for (var i = 0; i < rows.length; i++) {
			var r = rows[i] || {};
			html += "<tr><td>" + (i + 1) + "</td><td>" + Tsd.esc(r.approver_src)
				+ "</td><td>" + Tsd.esc(r.approver_role)
				+ "</td><td>" + Tsd.esc(r.updated_by_name)
				+ "</td><td>" + Tsd.esc(r.approver_status)
				+ "</td><td>" + Tsd.esc(r.approver_remarks)
				+ "</td><td>" + Tsd.esc(r.created_date) + "</td></tr>";
		}
		Tsd._$("#tsd_d_history_body").html(html);
	},

	escAttr: function (value) {
		return Tsd.esc(value);
	},

	ok: function (json) {
		if (!json) {
			return false;
		}
		var code = json.errorCode != null ? json.errorCode : json.error_code;
		return code == null || Number(code) === 0;
	},

	isSessionGone: function (json) {
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			if (window.inpcHandleSessionExpired) {
				window.inpcHandleSessionExpired(json.message || "Please login once again");
			}
			return true;
		}
		return false;
	},

	showMsg: function (message, isError) {
		Tsd._$("#tsd_message")
			.toggleClass("alert-danger", !!isError)
			.toggleClass("alert-success", !isError)
			.toggleClass("d-none", !message)
			.text(message || "");
	},

	esc: function (value) {
		return String(value == null ? "" : value)
			.replace(/&/g, "&amp;")
			.replace(/</g, "&lt;")
			.replace(/>/g, "&gt;")
			.replace(/"/g, "&quot;")
			.replace(/'/g, "&#39;");
	}
};

/* Legacy popup name used by older onclick wiring. */
window.TSDReqPopup = window.TSDReqPopup || {};
window.TSDReqPopup.EditRequestData = function (internalCode) {
	return Tsd.EditRequestData(internalCode);
};
