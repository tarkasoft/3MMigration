/**
 * Rebate Programs. The module js_path loads this file before the HTML calls
 * RebateProgram.Load(), following the CertificateOfAnalysis module pattern.
 */
RebateProgram = {
	ROOT: "m_rebate_programs",
	/** Modal host — moved to body on show so CSS stays under this id (not orphaned on body). */
	POPUP_ROOT: "m_rebate_programs_popup",
	_api: "api/customer/rebate",
	_customer: { custCode: "", loginId: "" },
	_loaded: { enrollment: false, ytd: false, claims: false },
	PAGE_SIZES: [50, 100, 150, 200],
	PAGE_SIZE: 50,

	/**
	 * Active Rebate shell (multi-tab safe). Prefer InpcTabs active pane, else visible home.
	 */
	_$home: function () {
		var homeSel = "#" + RebateProgram.ROOT;
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find(homeSel) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $(homeSel).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $(homeSel).first();
	},

	/** Modal host for the active shell (may already sit on document.body after first show). */
	_$popup: function () {
		var popupSel = "#" + RebateProgram.POPUP_ROOT;
		var $home = RebateProgram._$home();
		if ($home.length) {
			var $inHome = $home.find(popupSel);
			if ($inHome.length) {
				return $inHome.first();
			}
		}
		var $onBody = $(document.body).children(popupSel);
		if ($onBody.length) {
			return $onBody.first();
		}
		return $(popupSel).first();
	},

	/** Find within #m_rebate_programs / #m_rebate_programs_popup so duplicate ids in other tabs are ignored. */
	_$: function (selector) {
		var $home = RebateProgram._$home();
		var $popup = RebateProgram._$popup();
		if (!$home.length && !$popup.length) {
			return $(selector);
		}
		if (!selector) {
			return $home.length ? $home : $popup;
		}
		var $found = $home.length ? $home.find(selector) : $();
		if ($found.length) {
			return $found;
		}
		if ($popup.length) {
			if ($popup.is(selector)) {
				return $popup;
			}
			$found = $popup.find(selector);
			if ($found.length) {
				return $found;
			}
		}
		return $(selector);
	},

	_el: function (selector) {
		return RebateProgram._$(selector).get(0) || null;
	},

	/** Claim form root inside the live claim modal (avoids stale duplicate ids after tab reload). */
	_claimContent$: function () {
		var modal = document.querySelector("#rebate_claim_modal.show") ||
			document.getElementById("rebate_claim_modal");
		if (modal) {
			var content = modal.querySelector("#rebate_claim_content");
			if (content) return $(content);
		}
		return RebateProgram._$("#rebate_claim_content");
	},

	/** Drop leftover popup hosts left on body when the menu reloads the module HTML. */
	_scrubOrphanPopups: function () {
		var popups = document.querySelectorAll("#" + RebateProgram.POPUP_ROOT);
		if (popups.length <= 1) return;
		var keep = popups[popups.length - 1];
		for (var i = 0; i < popups.length - 1; i++) {
			if (popups[i].parentNode) popups[i].parentNode.removeChild(popups[i]);
		}
		if (keep.parentNode !== document.body) {
			document.body.appendChild(keep);
		}
	},

	Load: function () {
		RebateProgram._loaded = { enrollment: false, ytd: false, claims: false };
		RebateProgram._ensureCssInHead();
		RebateProgram._scrubOrphanPopups();
		RebateProgram._bindModalViewportGuard();
		RebateProgram._scrubOrphanBackdrops();
		RebateProgram._ensureDatePickers();
		RebateProgram._initTables();
		RebateProgram._customer = RebateProgram._procedureContext();
		RebateProgram._request("/context", "GET", RebateProgram._customer, function (data) {
			RebateProgram._customer.custCode = data.custCode || RebateProgram._customer.custCode;
			RebateProgram._customer.loginId = data.loginId || RebateProgram._customer.loginId;
			RebateProgram.LoadEnrollment();
		}, null, { target: RebateProgram.ROOT, message: "Loading Rebate Programs..." });
	},

	/** Keep latest module <style> in document.head (replace stale copies from prior tab loads). */
	_ensureCssInHead: function () {
		var styles = document.querySelectorAll("style#rebate-programs-css");
		if (!styles.length) return;
		var keep = styles[styles.length - 1];
		for (var i = 0; i < styles.length - 1; i++) {
			if (styles[i].parentNode) styles[i].parentNode.removeChild(styles[i]);
		}
		if (keep.parentNode !== document.head) {
			document.head.appendChild(keep);
		}
	},

	_initTables: function () {
		if (!window.Common || !Common.DataTable) return;
		Common.DataTable.init({
			rootId: "m_rebate_enrollment",
			tableId: "rebate_enrollment_table",
			tbodyId: "rebate_enrollment_rows",
			pageSizes: RebateProgram.PAGE_SIZES,
			pageSize: RebateProgram.PAGE_SIZE,
			filter_type: "minimal",
			searchPlaceholder: "Search programs…",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "full",
			maxHeight: "420px",
			emptyMessage: "No programs are available for enrollment.",
			onRefresh: function () {
				RebateProgram._loaded.enrollment = false;
				RebateProgram.LoadEnrollment();
			},
			columns: [
				{ title: "Program No.", field: "program_no", sortable: true, width: 130 },
				{ title: "Program Name", field: "program_name", sortable: true, width: 300 },
				{ title: "Division", field: "division", sortable: true, width: 110 },
				{ title: "Program Period", field: "pgm_period", sortable: true, width: 180 },
				{ title: "Program Target", field: "target_text", sortable: true, width: 140, textAlign: "right" },
				{ title: "Cut-off Date", field: "cut_off_date", sortable: true, width: 130 },
				{ title: "Participation Status", field: "status_html", type: "html", searchable: false, sortable: false, width: 170 },
				{ title: "Participation Details", field: "action_html", type: "html", searchable: false, sortable: false, width: 220 }
			],
			rows: []
		});
		Common.DataTable.init({
			rootId: "m_rebate_claims",
			tableId: "rebate_claims_table",
			tbodyId: "rebate_claim_rows",
			pageSizes: RebateProgram.PAGE_SIZES,
			pageSize: RebateProgram.PAGE_SIZE,
			filter_type: "minimal",
			searchPlaceholder: "Search claims…",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "full",
			maxHeight: "420px",
			emptyMessage: "No claims are available.",
			columnHideEnabled: true,
			columnDragEnabled: true,
			onRefresh: function () {
				RebateProgram._loaded.claims = false;
				RebateProgram.LoadClaims();
			},
			columns: [
				{ title: "Claim No.", field: "claim_no", sortable: true, width: 200 },
				{ title: "Program No.", field: "program_no", sortable: true, width: 130 },
				{ title: "View", field: "view_html", type: "html", searchable: false, sortable: false, width: 70, hideable: false, reorderable: false },
				{ title: "Program Name", field: "program_name", sortable: true, width: 280 },
				{ title: "Division", field: "division", sortable: true, width: 100 },
				{ title: "Program Period", field: "pgm_period", sortable: true, width: 170 },
				{ title: "Final Payout (INR)", field: "amount_text", sortable: true, width: 140, textAlign: "right" },
				{ title: "Claim Status", field: "status_html", type: "html", searchable: false, sortable: false, width: 190 },
				{ title: "Credit Note No.", field: "credit_note_no", sortable: true, width: 160 },
				{ title: "Program Target", field: "target_text", sortable: true, width: 130, textAlign: "right" },
				{ title: "Final Achievement", field: "acheived_text", sortable: true, width: 140, textAlign: "right" }
			],
			rows: []
		});
	},

	ShowTab: function (which) {
		var tabs = ["enrollment", "ytd", "claims"];
		for (var i = 0; i < tabs.length; i++) {
			var active = tabs[i] === which;
			RebateProgram._$("#rebate_" + tabs[i] + "_tab").toggleClass("active", active)
				.attr("aria-selected", active ? "true" : "false");
			RebateProgram._$("#rebate_" + tabs[i]).toggleClass("active", active);
		}
		if (which === "ytd" && !RebateProgram._loaded.ytd) RebateProgram.LoadYtd();
		if (which === "claims" && !RebateProgram._loaded.claims) RebateProgram.LoadClaims();
		return false;
	},

	LoadEnrollment: function () {
		RebateProgram._loadRows("/enrollment", "m_rebate_enrollment", "enrollment", function (row) {
			var enrolled = !!row.prg_accepted_type;
			var enrollAction = enrolled ? "" :
				'<button type="button" class="rebate-action enroll" onclick="RebateProgram.Enroll(' +
				Number(row.program_int_code) + '); return false;"' +
				(Number(row.cut_off_date_over) === 1 ? " disabled" : "") + ">Enroll</button>";
			var documentAction = row.program_doc_name
				? '<button type="button" class="rebate-action download" onclick="RebateProgram.DownloadProgramFile(' +
					Number(row.program_int_code) + '); return false;"><i class="ri-download-2-line" aria-hidden="true"></i> Download</button>' : "";
			var viewAction = '<button type="button" class="rebate-action view" onclick="RebateProgram.ViewProgram(' +
				Number(row.program_int_code) + '); return false;"><i class="ri-eye-line" aria-hidden="true"></i> View</button>';
			return {
				program_no: row.program_no,
				program_name: row.program_name,
				division: row.division,
				pgm_period: row.pgm_period,
				target_text: row.target_type === "Quantity"
					? RebateProgram._escape(row.target) + " units" : "INR " + RebateProgram._escape(row.target),
				cut_off_date: row.cut_off_date,
				status_html: enrolled
					? '<span class="rebate-status"><i class="ri-checkbox-circle-fill" aria-hidden="true"></i> Enrolled</span>'
					: '<span class="rebate-status pending">Not enrolled</span>',
				action_html: '<div class="rebate-actions">' + enrollAction + documentAction + viewAction + "</div>"
			};
		});
	},

	ViewProgram: function (program) {
		RebateProgram._$("#rebate_program_title").text("Program details");
		RebateProgram._$("#rebate_program_actions").empty();
		RebateProgram._$("#rebate_program_content").html("");
		RebateProgram._showModal("rebate_program_modal");
		RebateProgram._request("/programs/" + encodeURIComponent(program) + "/details", "GET",
			RebateProgram._customer, function (data) {
				var details = data && data.program ? data.program : data || {};
				var target = details.target_type === "Quantity"
					? RebateProgram._escape(details.target) + " units"
					: RebateProgram._money(details.target);
				var period = (details.start_date || details.end_date)
					? (details.start_date || "-") + " - " + (details.end_date || "-") : "-";
				RebateProgram._$("#rebate_program_content").html('<div class="rebate-summary">' +
					RebateProgram._detail("Program number", details.program_no) +
					RebateProgram._detail("Division", details.div_name) +
					RebateProgram._detail("Program type", details.program_type) +
					RebateProgram._detail("Program name", details.program_name, true) +
					RebateProgram._detail("Program description", details.program_desc, true) +
					RebateProgram._detail("Program period", period) +
					RebateProgram._detail("Program target", target) +
					RebateProgram._detail("Cut-off date", details.cut_off_date) +
					RebateProgram._detail("BSO remarks", details.bso_remarks, true) + "</div>");
				RebateProgram._$("#rebate_program_title").text(details.program_name || "Program details");
				RebateProgram._$("#rebate_program_actions").html(details.program_doc_name
					? '<button type="button" class="rebate-action download" onclick="RebateProgram.DownloadProgramFile(' +
						Number(program) + '); return false;"><i class="ri-download-2-line" aria-hidden="true"></i> ' +
						"Download Program Document</button>"
					: "");
			}, function (msg) {
				RebateProgram._$("#rebate_program_content").html(
					'<div class="rebate-note rebate-error"><i class="ri-error-warning-line" aria-hidden="true"></i><span>' +
					RebateProgram._escape(msg || "Unable to load program details.") + "</span></div>");
				RebateProgram._alert(msg || "Unable to load program details.", true);
			}, { target: "rebate_program_modal", message: "Loading program details..." });
		return false;
	},

	LoadYtd: function () {
		RebateProgram._loadHtmlRows("/ytd", "rebate_ytd_rows", "ytd", 7,
			"No YTD achievement is available.", function (row) {
				var discrepancy = row.error_reported
					? '<span class="text-warning">' + RebateProgram._escape(row.error_reported) + "</span>"
					: Number(row.diff_days) <= 7
						? '<button type="button" class="rebate-action" onclick="RebateProgram.OpenDiscrepancy(' +
							Number(row.program_int_code) + ',\'YTD\'); return false;">Report issue</button>'
						: '<span class="text-muted">Reporting window closed</span>';
				return "<tr><td>" + RebateProgram._escape(row.program_no) + "</td><td>" +
					RebateProgram._escape(row.program_name) + "</td><td>" + RebateProgram._escape(row.pgm_period) +
					"</td><td>" + RebateProgram._escape(row.target) + "</td><td>" +
					RebateProgram._escape(row.ytd_achievement) + "</td><td>INR " +
					RebateProgram._escape(row.p_incentive_amt) + "</td><td>" + discrepancy + "</td></tr>";
			});
	},

	LoadClaims: function () {
		RebateProgram._loadRows("/claims", "m_rebate_claims", "claims", function (row) {
			var status = String(row.claim_status || "");
			var pendingErr = String(row.error_reported || "") === "Pending";
			var canClaim = (!status || status === "Draft" || status === "Save") && !pendingErr;
			var canRework = status === "Sent for Rework" && !pendingErr;
			var program = Number(row.prg_int_code);
			var claimCase = RebateProgram._jsString(row.claim_bso_case_no);
			var remarksJs = RebateProgram._jsString(row.inv_approval_remarks || "");
			// Legacy ClaimNowReportError('Normal'|‘Rework’, prg, row, case) → OpenClaim / OpenClaimRework
			var claimNowBtn = "";
			if (!pendingErr && canClaim) {
				claimNowBtn = '<button type="button" class="rebate-action claim-now" onclick="RebateProgram.OpenClaim(' +
					program + "," + claimCase + '); return false;">'
					+ '<i class="ri-file-edit-line" aria-hidden="true"></i> Claim Now</button>';
			} else if (!pendingErr && canRework) {
				claimNowBtn = '<button type="button" class="rebate-action claim-now" onclick="RebateProgram.OpenClaimRework(' +
					program + "," + claimCase + "," + remarksJs + '); return false;">'
					+ '<i class="ri-file-edit-line" aria-hidden="true"></i> Claim Now</button>';
			}
			var viewBtn = "";
			if (!pendingErr) {
				if (canRework) {
					viewBtn = '<button type="button" class="rebate-action view" title="Claim Now" aria-label="Claim Now" onclick="RebateProgram.OpenClaimRework(' +
						program + "," + claimCase + "," + remarksJs + '); return false;">'
						+ '<i class="ri-file-edit-line" aria-hidden="true"></i></button>';
				} else if (canClaim) {
					viewBtn = '<button type="button" class="rebate-action view" title="Claim Now" aria-label="Claim Now" onclick="RebateProgram.OpenClaim(' +
						program + "," + claimCase + '); return false;">'
						+ '<i class="ri-file-edit-line" aria-hidden="true"></i></button>';
				} else {
					viewBtn = '<button type="button" class="rebate-action view" title="View claim" aria-label="View claim" onclick="RebateProgram.OpenClaim(' +
						program + "," + claimCase + '); return false;">'
						+ '<i class="ri-eye-line" aria-hidden="true"></i></button>';
				}
			}
			// Rare discrepancy notes/actions — keep under Claim Status (no empty Action column)
			var discrepancy = pendingErr
				? '<span class="text-warning">Under Review</span>'
				: (row.error_reported
					? '<span class="text-warning">' + RebateProgram._escape(row.error_reported) + "</span>"
					: (Number(row.submitted_diff_days) <= 7 && (!status || status === "Draft" || status === "Save"))
						? '<button type="button" class="rebate-action" onclick="RebateProgram.OpenDiscrepancy(' +
							program + ',\'Invoice\'); return false;">Report issue</button>' : "");
			var statusHtml = claimNowBtn
				? '<div class="rebate-actions">' + claimNowBtn + "</div>"
				: RebateProgram._statusBadge(status);
			if (discrepancy) {
				statusHtml += '<div class="rebate-actions">' + discrepancy + "</div>";
			}
			var targetText = String(row.target_type || "") === "Quantity"
				? RebateProgram._escape(row.target) + " units"
				: RebateProgram._money(row.target);
			return {
				claim_no: row.claim_no,
				program_no: row.program_no,
				view_html: viewBtn ? '<div class="rebate-actions">' + viewBtn + "</div>" : "",
				program_name: row.program_name,
				division: row.division || "",
				pgm_period: row.pgm_period,
				target_text: targetText,
				acheived_text: RebateProgram._money(row.acheived),
				amount_text: RebateProgram._money(row.incentive_amt),
				// Match legacy status column: Claim Now instead of "Not started"
				status_html: statusHtml,
				credit_note_no: row.credit_note_no || ""
			};
		});
	},

	/** Legacy OpenInvReworkPopup → confirm BSO remarks, then open claim. */
	OpenClaimRework: function (program, claimCase, remarks) {
		var text = String(remarks || "").trim() || "This claim was sent for rework. Continue to update the claim?";
		var open = function () {
			RebateProgram.OpenClaim(program, claimCase);
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Claim rework",
				text: text,
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "Claim Now",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#15803d",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) {
					open();
				}
			});
			if (window.jQuery) {
				$(".swal2-container").css("z-index", "22222229999");
			}
			return false;
		}
		if (window.confirm(text + "\n\nClaim Now?")) {
			open();
		}
		return false;
	},

	_statusBadge: function (status) {
		var text = String(status || "");
		if (!text) return '<span class="rebate-status muted">Not started</span>';
		var tone = "muted";
		if (/issued|approved|complete/i.test(text)) tone = "";
		else if (/awaited|processing|pending|submitted/i.test(text)) tone = "warn";
		else if (/rework|reject|cancel/i.test(text)) tone = "danger";
		else if (/draft|save/i.test(text)) tone = "pending";
		else tone = "info";
		return '<span class="rebate-status ' + tone + '">' + RebateProgram._escape(text) + "</span>";
	},

	_filePreviewUrls: {},

	/**
	 * Browse control with CIR/TSD-style View + Delete after a file is chosen or already uploaded.
	 * @param {string} [extraAttrs] optional attributes (e.g. id="..." or class="rebate-inv-file")
	 * @param {object} [opts] { uploaded, fileName, stateCode, kind }
	 */
	_browseFileHtml: function (extraAttrs, opts) {
		opts = opts || {};
		var attrs = String(extraAttrs || "").trim();
		var classAttr = 'class="rebate-file-input"';
		if (/\bclass\s*=/.test(attrs)) {
			attrs = attrs.replace(/\bclass\s*=\s*(['"])([^'"]*)\1/, function (_m, q, cls) {
				classAttr = 'class="rebate-file-input ' + String(cls || "").trim() + '"';
				return "";
			});
			attrs = attrs.replace(/\s+/g, " ").trim();
		}
		var uploaded = !!opts.uploaded;
		var fileName = String(opts.fileName || "").trim();
		var stateCode = String(opts.stateCode || "").trim();
		var kind = String(opts.kind || "").trim();
		var showActions = uploaded || !!fileName;
		var esc = RebateProgram._escape;
		return '<div class="rebate-file-browse" data-uploaded="' + (uploaded ? "1" : "0") + '"'
			+ (stateCode ? ' data-state="' + esc(stateCode) + '"' : "")
			+ (kind ? ' data-kind="' + esc(kind) + '"' : "") + ">"
			+ '<div class="rebate-file-control">'
			+ '<input type="file" ' + classAttr + (attrs ? " " + attrs : "")
			+ ' tabindex="-1" aria-hidden="true"'
			+ ' onchange="RebateProgram._onBrowseFileSelected(this);">'
			+ '<button type="button" class="rebate-browse-btn" title="Browse file"'
			+ ' onclick="var i=this.parentNode.querySelector(\'input.rebate-file-input\');if(i){i.click();}return false;">'
			+ '<i class="ri-folder-open-line" aria-hidden="true"></i> Browse File</button>'
			+ "</div>"
			+ '<div class="rebate-file-meta">'
			+ '<span class="rebate-file-name"' + (fileName ? ' title="' + esc(fileName) + '"' : ' aria-hidden="true"') + ">"
			+ esc(fileName) + "</span>"
			+ '<div class="rebate-file-actions' + (showActions ? "" : " d-none")
			+ '" role="group" aria-label="Attachment actions">'
			+ '<button type="button" class="btn btn-sm btn-outline-primary rebate-file-view" title="View document" '
			+ 'aria-label="View document" onclick="RebateProgram.ViewClaimFile(this); return false;">'
			+ '<i class="ri-eye-line" aria-hidden="true"></i></button>'
			+ '<button type="button" class="btn btn-sm btn-outline-danger rebate-file-remove" title="Delete document" '
			+ 'aria-label="Delete document" onclick="RebateProgram.RemoveClaimFile(this); return false;">'
			+ '<i class="ri-delete-bin-line" aria-hidden="true"></i></button>'
			+ "</div></div></div>";
	},

	_onBrowseFileSelected: function (input) {
		if (!input) return;
		var $wrap = $(input).closest(".rebate-file-browse");
		var file = input.files && input.files[0] ? input.files[0] : null;
		var name = file ? file.name : "";
		var $label = $wrap.find(".rebate-file-name");
		$label.text(name).attr("title", name);
		if (name) {
			$label.removeAttr("aria-hidden");
		} else {
			$label.attr("aria-hidden", "true");
		}
		var hasServer = $wrap.attr("data-uploaded") === "1";
		$wrap.find(".rebate-file-actions").toggleClass("d-none", !(name || hasServer));
		RebateProgram._revokeFilePreview($wrap);
	},

	_revokeFilePreview: function ($wrap) {
		var key = RebateProgram._filePreviewKey($wrap);
		var url = RebateProgram._filePreviewUrls[key];
		if (url) {
			try { URL.revokeObjectURL(url); } catch (ignore) { /* ignore */ }
			delete RebateProgram._filePreviewUrls[key];
		}
	},

	_filePreviewKey: function ($wrap) {
		if (!$wrap || !$wrap.length) return "";
		return String($wrap.attr("data-kind") || "file") + "|" +
			String($wrap.attr("data-state") || "") + "|" +
			String($wrap.find("input.rebate-file-input").attr("id") || $wrap.find("input.rebate-file-input").attr("class") || "");
	},

	ViewClaimFile: function (button) {
		var $wrap = $(button).closest(".rebate-file-browse");
		if (!$wrap.length) return false;
		var input = $wrap.find("input.rebate-file-input").get(0);
		var file = input && input.files && input.files[0] ? input.files[0] : null;
		if (file) {
			RebateProgram._revokeFilePreview($wrap);
			var objectUrl = URL.createObjectURL(file);
			RebateProgram._filePreviewUrls[RebateProgram._filePreviewKey($wrap)] = objectUrl;
			window.open(objectUrl, "_blank", "noopener");
			return false;
		}
		if ($wrap.attr("data-uploaded") === "1") {
			var kind = String($wrap.attr("data-kind") || "").trim();
			var stateCode = String($wrap.attr("data-state") || "").trim();
			if (kind && stateCode) {
				return RebateProgram.DownloadEvidence(stateCode, kind, true);
			}
			var docCode = String($wrap.find("input.rebate-file-input").attr("id") || "").replace("rebate_program_file_", "");
			if (docCode) {
				return RebateProgram.DownloadClaimDocument(docCode);
			}
		}
		RebateProgram._alert("No document is available to view.", true);
		return false;
	},

	RemoveClaimFile: function (button) {
		var $wrap = $(button).closest(".rebate-file-browse");
		if (!$wrap.length) return false;
		var input = $wrap.find("input.rebate-file-input").get(0);
		var hasLocal = !!(input && input.files && input.files.length);
		var uploaded = $wrap.attr("data-uploaded") === "1";
		var kind = String($wrap.attr("data-kind") || "").trim();
		var stateCode = String($wrap.attr("data-state") || "").trim();
		var clearLocal = function () {
			RebateProgram._revokeFilePreview($wrap);
			if (input) input.value = "";
			$wrap.find(".rebate-file-name").text("").attr("title", "").attr("aria-hidden", "true");
			if (!uploaded) {
				$wrap.find(".rebate-file-actions").addClass("d-none");
			}
		};
		if (hasLocal && !uploaded) {
			clearLocal();
			return false;
		}
		if (hasLocal && uploaded) {
			/* Clear replacement selection; keep server file + View/Delete. */
			clearLocal();
			$wrap.find(".rebate-file-actions").removeClass("d-none");
			return false;
		}
		if (!uploaded || !kind || !stateCode) {
			clearLocal();
			return false;
		}
		var doDelete = function () {
			RebateProgram._request("/claim/evidence/" +
				encodeURIComponent(RebateProgram._$("#rebate_claim_content").data("program")) + "/" +
				encodeURIComponent(RebateProgram._$("#rebate_claim_content").data("claimCase")) + "/" +
				encodeURIComponent(stateCode) + "/" + encodeURIComponent(kind),
				"DELETE", {
					custCode: RebateProgram._customer.custCode,
					loginId: RebateProgram._customer.loginId
				}, function () {
					RebateProgram.OpenClaim(
						RebateProgram._$("#rebate_claim_content").data("program"),
						RebateProgram._$("#rebate_claim_content").data("claimCase"));
				}, null, { target: "rebate_claim_modal", message: "Deleting document..." });
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this document?",
				text: "The uploaded file will be removed from this claim.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "Yes, delete",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#d33",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) doDelete();
			});
			if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
			return false;
		}
		if (window.confirm("Delete this document?")) doDelete();
		return false;
	},

	_detail: function (label, value, wide) {
		return '<div class="rebate-detail' + (wide ? " wide" : "") + '"><span class="rebate-k">' +
			RebateProgram._escape(label) + '</span><span class="rebate-v">' +
			RebateProgram._escape((value === 0 || value) ? value : "-") + "</span></div>";
	},

	_money: function (value) {
		if (value === null || value === undefined || value === "") return "-";
		var num = Number(value);
		if (isNaN(num)) return String(value);
		return "INR " + num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
	},

	_date: function (value) {
		if (!value) return "-";
		var parts = String(value).substring(0, 10).split("-");
		if (parts.length !== 3) return String(value);
		var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		var month = months[Number(parts[1]) - 1];
		return month ? parts[2] + " " + month + " " + parts[0] : String(value);
	},

	/** Same standard overlay as TSD / CIR (inpc_loader.js). */
	_showLoader: function (message, targetId) {
		if (typeof window.showLoader === "function") {
			window.showLoader(message || "Please wait…", targetId || RebateProgram.ROOT);
		}
	},

	_hideLoader: function (targetId) {
		if (typeof window.hideLoader === "function") {
			window.hideLoader(targetId || RebateProgram.ROOT);
		}
	},

	_MODAL_IDS: ["rebate_program_modal", "rebate_claim_modal", "rebate_discrepancy_modal", "rebate_claim_terms_modal"],

	/** Remove leftover Bootstrap backdrops that block clicks after close or desktop↔mobile switch. */
	_scrubOrphanBackdrops: function () {
		if (document.querySelector(".modal.show")) return;
		document.querySelectorAll(".modal-backdrop").forEach(function (back) {
			if (back && back.parentNode) back.parentNode.removeChild(back);
		});
		document.body.classList.remove("modal-open");
		document.body.style.removeProperty("overflow");
		document.body.style.removeProperty("padding-right");
	},

	_bindModalViewportGuard: function () {
		if (RebateProgram._viewportGuardBound) return;
		RebateProgram._viewportGuardBound = true;
		var onViewport = function () {
			window.setTimeout(function () {
				RebateProgram._reassertOpenModals();
				RebateProgram._scrubOrphanBackdrops();
			}, 60);
		};
		window.addEventListener("resize", onViewport);
		window.addEventListener("orientationchange", onViewport);
		if (window.matchMedia) {
			try {
				window.matchMedia("(max-width: 991.98px)").addEventListener("change", onViewport);
			} catch (ignore) {
				try {
					window.matchMedia("(max-width: 991.98px)").addListener(onViewport);
				} catch (ignore2) { /* older browsers */ }
			}
		}
	},

	_hostPopupOnBody: function () {
		RebateProgram._ensureCssInHead();
		var popup = RebateProgram._el("#" + RebateProgram.POPUP_ROOT);
		if (!popup) {
			/* Recover if an older build left modals on body without the host. */
			popup = document.createElement("div");
			popup.id = RebateProgram.POPUP_ROOT;
			document.body.appendChild(popup);
		} else if (popup.parentNode !== document.body) {
			document.body.appendChild(popup);
		}
		RebateProgram._MODAL_IDS.forEach(function (id) {
			var el = document.getElementById(id);
			if (el && el.parentNode !== popup) {
				popup.appendChild(el);
			}
		});
		return popup;
	},

	_reassertOpenModals: function () {
		RebateProgram._hostPopupOnBody();
		RebateProgram._MODAL_IDS.forEach(function (id) {
			var el = RebateProgram._el("#" + id);
			if (!el || !el.classList.contains("show")) return;
			el.style.zIndex = id === "rebate_claim_terms_modal" ? "1095" : "1085";
		});
		document.querySelectorAll(".modal-backdrop").forEach(function (back) {
			back.classList.add("rebate-backdrop");
			if (!document.querySelector("#rebate_claim_terms_modal.show")) {
				back.style.zIndex = "1080";
			}
		});
	},

	_showModal: function (id) {
		var modalId = String(id || "").replace(/^#/, "");
		RebateProgram._hostPopupOnBody();
		var el = RebateProgram._el("#" + modalId);
		if (!el || !window.bootstrap || !bootstrap.Modal) return;
		if (!el.getAttribute("data-rebate-bound")) {
			el.setAttribute("data-rebate-bound", "1");
			el.addEventListener("shown.bs.modal", function () {
				var backdrops = document.querySelectorAll(".modal-backdrop");
				if (backdrops.length) {
					var last = backdrops[backdrops.length - 1];
					last.classList.add("rebate-backdrop");
					if (modalId === "rebate_claim_terms_modal") {
						last.style.zIndex = "1090";
					}
				}
				RebateProgram._reassertOpenModals();
			});
			el.addEventListener("hidden.bs.modal", function () {
				RebateProgram._scrubOrphanBackdrops();
			});
		}
		bootstrap.Modal.getOrCreateInstance(el).show();
	},

	_hideModal: function (id) {
		var el = RebateProgram._el("#" + String(id || "").replace(/^#/, ""));
		if (!el || !window.bootstrap || !bootstrap.Modal) {
			RebateProgram._scrubOrphanBackdrops();
			return;
		}
		var inst = bootstrap.Modal.getInstance(el);
		if (inst) {
			inst.hide();
		} else {
			el.classList.remove("show");
			el.style.display = "none";
			RebateProgram._scrubOrphanBackdrops();
		}
	},

	Enroll: function (program) {
		RebateProgram._request("/enroll", "POST", JSON.stringify({
			custCode: RebateProgram._customer.custCode,
			loginId: RebateProgram._customer.loginId,
			program: program
		}), function (data) {
			RebateProgram._message((data && data.message) || "Enrollment completed.", false);
			RebateProgram._loaded.enrollment = false;
			RebateProgram.LoadEnrollment();
		}, null, { target: RebateProgram.ROOT, message: "Enrolling..." });
		return false;
	},

	OpenDiscrepancy: function (program, type) {
		RebateProgram._$("#rebate_discrepancy_program").val(program);
		RebateProgram._$("#rebate_discrepancy_type").val(type);
		RebateProgram._$("#rebate_discrepancy_text").val("");
		RebateProgram._showModal("rebate_discrepancy_modal");
		return false;
	},

	SubmitDiscrepancy: function () {
		RebateProgram._request("/discrepancy", "POST", JSON.stringify({
			custCode: RebateProgram._customer.custCode,
			loginId: RebateProgram._customer.loginId,
			program: RebateProgram._$("#rebate_discrepancy_program").val(),
			type: RebateProgram._$("#rebate_discrepancy_type").val(),
			remarks: RebateProgram._$("#rebate_discrepancy_text").val()
		}), function (data) {
			RebateProgram._hideModal("rebate_discrepancy_modal");
			RebateProgram._message((data && data.message) || "Discrepancy submitted.", false);
			var type = RebateProgram._$("#rebate_discrepancy_type").val();
			if (type === "Invoice") {
				RebateProgram._loaded.claims = false;
				RebateProgram.LoadClaims();
			} else {
				RebateProgram._loaded.ytd = false;
				RebateProgram.LoadYtd();
			}
		}, null, { target: "rebate_discrepancy_modal", message: "Submitting discrepancy..." });
		return false;
	},

	OpenClaim: function (program, claimCase) {
		RebateProgram._scrubOrphanPopups();
		RebateProgram._hostPopupOnBody();
		var $content = RebateProgram._claimContent$();
		RebateProgram._$("#rebate_claim_title").text("Claim details");
		RebateProgram._$("#rebate_claim_actions").empty();
		$content.html("");
		RebateProgram._showModal("rebate_claim_modal");
		var showClaimError = function (message) {
			var text = String(message || "Unable to open this claim.");
			RebateProgram._claimContent$().html(
				'<div class="rebate-note rebate-error"><i class="ri-error-warning-line" aria-hidden="true"></i><span>' +
				RebateProgram._escape(text) + "</span></div>");
			/* Popup above claim modal — not the page banner behind it. */
			RebateProgram._alert(text, true);
		};
		RebateProgram._request("/claims/" + encodeURIComponent(program) + "/" + encodeURIComponent(claimCase),
			"GET", RebateProgram._customer, function (data) {
				var claim = data && data.claim ? data.claim : {};
				var invoices = data && Array.isArray(data.invoices) ? data.invoices : [];
				var docs = data && Array.isArray(data.documents) ? data.documents : [];
				var editable = data && data.editable === true;
				var html = RebateProgram._claimFormHtml(claim, invoices, docs, editable);
				var $claim = RebateProgram._claimContent$();
				$claim.html(html)
					.data("program", program)
					.data("claimCase", claimCase)
					.data("invDateFrom", String(claim.inv_date_from || "").trim());
				RebateProgram._$("#rebate_claim_title").text("Claim " + (claim.claim_no || ""));
				RebateProgram._$("#rebate_claim_actions").html(editable
					? '<button type="button" class="rebate-action save-later" onclick="RebateProgram.SubmitClaim(this,\'Draft\'); return false;">' +
						'<i class="ri-save-line" aria-hidden="true"></i> Save for Later</button>' +
						'<button type="button" class="rebate-action submit-claim" onclick="RebateProgram.SubmitClaim(this,\'Submit\'); return false;">' +
						'<i class="ri-send-plane-line" aria-hidden="true"></i> Submit</button>'
					: "");
				RebateProgram._initClaimDatePickers();
			}, showClaimError, { target: "rebate_claim_modal", message: "Loading claim..." });
		return false;
	},

	_claimFormHtml: function (claim, invoices, docs, editable) {
		var esc = RebateProgram._escape;
		var statusText = claim.claim_status || "Not started";
		var html = '<div class="rebate-claim-shell">';

		html += '<div class="rebate-claim-hero">' +
			'<div class="rebate-claim-hero-grid">' +
			'<div><span class="rebate-k">Program No</span><span class="rebate-v">' + esc(claim.program_no || "-") + "</span></div>" +
			'<div><span class="rebate-k">Claim No</span><span class="rebate-v">' + esc(claim.claim_no || "-") + "</span></div>" +
			'<div class="wide"><span class="rebate-k">Program Name</span><span class="rebate-v">' + esc(claim.program_name || "-") + "</span></div>" +
			'<div><span class="rebate-k">Division</span><span class="rebate-v">' + esc(claim.division || "-") + "</span></div>" +
			'<div><span class="rebate-k">Period</span><span class="rebate-v">' + esc(claim.pgm_period || "-") + "</span></div>" +
			'<div><span class="rebate-k">Status</span><span class="rebate-v">' + esc(statusText) + "</span></div>" +
			"</div></div>";

		html += '<div class="rebate-section"><div class="rebate-section-head"><h6>Upload Service Invoice</h6>' +
			'<span class="hint">' + invoices.length + (invoices.length === 1 ? " invoice" : " invoices") +
			" — read-only details above, enter values in the table below each card</span></div>" +
			'<div class="rebate-claim-inv-list">';

		var totalIncl = 0;
		if (invoices.length) {
			html += invoices.map(function (invoice, idx) {
				var invAmt = RebateProgram._toNumber(invoice.inv_value);
				totalIncl += invAmt;
				var dateId = "rebate_inv_date_" + idx;
				var uiDate = RebateProgram._isoToUiDate(invoice.cust_inv_date);
				var rowKey = idx + 1;
				var hasInv = !!(invoice.u_invoice_doc_path || invoice.u_invoice_doc_name);
				var hasGst = !!(invoice.u_invoice_gst_doc_path || invoice.u_invoice_gst_doc_name);
				var invoiceFile = editable
					? RebateProgram._browseFileHtml('class="rebate-inv-file"', {
						uploaded: hasInv,
						fileName: invoice.u_invoice_doc_name || "",
						stateCode: invoice.state_code,
						kind: "INVOICE"
					})
					: (hasInv
						? '<button type="button" class="rebate-action download" onclick="RebateProgram.DownloadEvidence(' +
							RebateProgram._jsString(invoice.state_code) + ',\'INVOICE\'); return false;">' +
							'<i class="ri-eye-line" aria-hidden="true"></i> View</button>'
						: '<span class="rebate-muted">Not uploaded</span>');
				var gstFile = editable
					? RebateProgram._browseFileHtml('class="rebate-gst-file"', {
						uploaded: hasGst,
						fileName: invoice.u_invoice_gst_doc_name || "",
						stateCode: invoice.state_code,
						kind: "GST"
					})
					: (hasGst
						? '<button type="button" class="rebate-action download" onclick="RebateProgram.DownloadEvidence(' +
							RebateProgram._jsString(invoice.state_code) + ',\'GST\'); return false;">' +
							'<i class="ri-eye-line" aria-hidden="true"></i> View</button>'
						: '<span class="rebate-muted">Not uploaded</span>');
				var uploadAction = editable
					? '<button type="button" class="rebate-upload-row-btn" title="Upload invoice documents" ' +
						'onclick="RebateProgram.UploadInvoiceRow(this); return false;">' +
						'<i class="ri-upload-2-line" aria-hidden="true"></i> Upload</button>'
					: '<span class="rebate-muted">-</span>';
				var taxType = editable
					? '<select class="form-select form-select-sm rebate-tax"><option value="">Select</option><option value="IGST"' +
						(invoice.cust_tax_type === "IGST" ? " selected" : "") + '>IGST - 18%</option><option value="CGSTSGST"' +
						(invoice.cust_tax_type === "CGSTSGST" ? " selected" : "") + ">CGST + SGST - 18%</option></select>"
					: esc(invoice.cust_tax_type || "-");
				var invoiceNo = editable
					? '<input class="form-control form-control-sm rebate-invoice-no" maxlength="50" value="' +
						esc(invoice.cust_inv_no) + '">'
					: esc(invoice.cust_inv_no || "-");
				var invoiceDate = editable
					? '<div class="input-group input-group-sm rebate-date rebate-claim-date">' +
						'<input type="text" class="form-control form-control-sm rebate-invoice-date" id="' + dateId +
						'" data-date-format="dd/mm/yyyy" placeholder="dd/mm/yyyy" value="' + esc(uiDate) + '" readonly>' +
						'<span class="input-group-text" onclick="return RebateProgram._openClaimDatePicker(\'' + dateId +
						'\');"><i class="ri-calendar-line" aria-hidden="true"></i></span></div>'
					: esc(uiDate || "-");
				var invoiceValue = editable
					? '<input class="form-control form-control-sm rebate-invoice-value" type="number" min="0" step="0.01" value="' +
						esc(invoice.inv_value) + '">'
					: esc(RebateProgram._money(invoice.inv_value));
				/* One .rebate-claim-inv card = one invoice. Save/upload still use .closest(".rebate-claim-inv"). */
				return '<div class="rebate-claim-inv" data-state="' + esc(invoice.state_code) +
					'" data-row-key="' + rowKey + '" data-has-invoice="' + (hasInv ? "1" : "0") +
					'" data-has-gst="' + (hasGst ? "1" : "0") + '" data-incentive="' +
					esc(invoice.incentive_amt) + '" data-inv-value="' + esc(invAmt) + '">' +
					'<div class="rebate-claim-inv-banner">' +
					'<span class="rebate-claim-inv-no">Invoice ' + rowKey + "</span>" +
					'<span class="rebate-claim-inv-claimamt">Claim Amt (Excl. GST) ' +
					'<strong id="incentive_amt_' + rowKey + '">' + esc(RebateProgram._money(invoice.incentive_amt)) +
					"</strong></span></div>" +
					'<div class="rebate-claim-inv-facts" aria-label="Read-only invoice details">' +
					'<div class="fact"><span class="rebate-k">State</span><span class="rebate-v">' + esc(invoice.state_code || "-") + "</span></div>" +
					'<div class="fact"><span class="rebate-k">3M GST No</span><span class="rebate-v">' + esc(invoice.mmm_gst_no || "-") + "</span></div>" +
					'<div class="fact fact-hsn"><span class="rebate-k">HSN/SAC</span><span class="rebate-v">' + esc(invoice.hsn_code || "-") + "</span></div>" +
					'<div class="fact fact-desc"><span class="rebate-k">Description</span><span class="rebate-v">' +
					esc(invoice.item_desc || "-") + "</span></div></div>" +
					'<div class="rebate-claim-inv-edit">' +
					'<div class="rebate-table-scroll rebate-claim-scroll">' +
					'<table class="rebate-table rebate-modal-table rebate-claim-entry-table"><thead><tr>' +
					"<th>GST Type</th><th>Cust Inv Number</th><th>Cust Inv Date</th>" +
					'<th class="num">Cust Inv Amt (Incl. GST)</th><th>Inv Copy</th><th>GST Copy</th><th>Action</th>' +
					"</tr></thead><tbody><tr>" +
					'<td data-label="GST Type">' + taxType + "</td>" +
					'<td data-label="Cust Inv Number">' + invoiceNo + "</td>" +
					'<td class="nowrap" data-label="Cust Inv Date">' + invoiceDate + "</td>" +
					'<td class="num" data-label="Cust Inv Amt (Incl. GST)">' + invoiceValue + "</td>" +
					'<td data-label="Inv Copy">' + invoiceFile + "</td>" +
					'<td data-label="GST Copy">' + gstFile + "</td>" +
					'<td class="nowrap" data-label="Action">' + uploadAction + "</td>" +
					"</tr></tbody></table></div></div></div>";
			}).join("");
			html += '<div class="rebate-claim-total-bar">' +
				'<span>Total Claim Amount (Incl. GST)</span>' +
				'<span class="rebate-claim-total-val" id="rebate_claim_total_amt" data-total-incl="' +
				esc(RebateProgram._round2(totalIncl)) + '">' +
				esc(RebateProgram._money(totalIncl)) + "</span></div>";
		} else {
			html += '<div class="rebate-empty">No invoice is available for this claim.</div>';
		}
		html += "</div></div>";

		html += '<div class="rebate-note rebate-claim-warn"><i class="ri-alarm-warning-line" aria-hidden="true"></i>' +
			"<span>Disclaimer: Please upload your invoices within <b>7 working days</b> for smooth processing of your claim.</span></div>";

		/* Legacy: program document types from reb_program_document_group — hide when none configured. */
		if (docs.length) {
			html += '<div class="rebate-section"><div class="rebate-section-head"><h6>Upload Document Type for Claim Settlement</h6>' +
				'<span class="hint">Program-required supporting docs (mandatory marked <span class="rebate-req">*</span>)</span></div>' +
				'<div class="rebate-table-card"><div class="rebate-table-scroll">' +
				'<table class="rebate-table rebate-modal-table"><thead><tr><th>Sl</th><th>Document Name</th><th>File</th>' +
				"<th>Action</th></tr></thead><tbody>";
			html += docs.map(function (doc, idx) {
				var fileCell = doc.doc_name
					? '<button type="button" class="rebate-action download" onclick="RebateProgram.DownloadClaimDocument(' +
						Number(doc.doc_code) + '); return false;"><i class="ri-file-download-line" aria-hidden="true"></i> ' +
						esc(doc.doc_name) + "</button>"
					: (editable ? RebateProgram._browseFileHtml('id="rebate_program_file_' +
						Number(doc.doc_code) + '"') : '<span class="rebate-muted">Not uploaded</span>');
				var action = !editable ? '<span class="rebate-muted">-</span>' : doc.doc_name
					? '<button type="button" class="rebate-action" onclick="RebateProgram.DeleteProgramDocument(' +
						Number(doc.doc_code) + '); return false;"><i class="ri-delete-bin-line" aria-hidden="true"></i> Delete</button>'
					: '<button type="button" class="rebate-action" onclick="RebateProgram.UploadProgramDocument(' +
						Number(doc.doc_code) + '); return false;"><i class="ri-upload-2-line" aria-hidden="true"></i> Upload</button>';
				return "<tr><td>" + (idx + 1) + "</td><td>" + esc(doc.document_name) +
					(String(doc.is_mandatory) === "Yes" ? '<span class="rebate-req">*</span>' : "") +
					"</td><td>" + fileCell + '</td><td class="nowrap">' + action + "</td></tr>";
			}).join("");
			html += "</tbody></table></div></div></div>";
		}

		var bsoRemarks = String(claim.payout_bso_remarks || claim.inv_approval_remarks || "").trim();
		html += '<div class="rebate-claim-meta">' +
			'<div class="rebate-claim-meta-card"><span class="rebate-k">BSO Remarks</span><span class="rebate-v">' +
			esc(bsoRemarks || "-") + "</span></div>" +
			'<div class="rebate-claim-meta-card"><span class="rebate-k">PAN No</span><span class="rebate-v">' +
			esc(claim.cust_pan_no || "-") + "</span></div>" +
			'<div class="rebate-claim-meta-card"><span class="rebate-k">GST No</span><span class="rebate-v">' +
			esc(claim.cust_gst_no || "-") + "</span></div></div>";

		if (editable) {
			html += '<div class="rebate-section"><div class="rebate-section-head"><h6>Declaration</h6></div>' +
				'<div class="rebate-declare">' +
				'<div class="form-check mb-2"><input class="form-check-input" type="checkbox" id="rebate_terms_check">' +
				'<label class="form-check-label" for="rebate_terms_check">I Accept ' +
				'<a href="#" class="rebate-terms-link" onclick="return RebateProgram.ShowClaimTerms();">Terms and Conditions</a></label></div>' +
				'<div class="form-check mb-2"><input class="form-check-input" type="checkbox" id="rebate_pan_check">' +
				'<label class="form-check-label" for="rebate_pan_check">I have verified the GSTN &amp; PAN no and the same is correct and up to date.</label></div>' +
				'<div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="rebate_update_check">' +
				'<label class="form-check-label" for="rebate_update_check">I have made necessary corrections and updated my new GSTN No or PAN No in remarks below.</label></div>' +
				'<div class="mb-0"><label class="form-label" for="rebate_pan_remarks">Remarks</label>' +
				'<textarea class="form-control form-control-sm" id="rebate_pan_remarks" rows="3" maxlength="1000" ' +
				'placeholder="Add PAN / GST update remarks (optional unless you selected the update declaration)"></textarea></div>' +
				"</div></div>";
		}

		html += '<div class="rebate-note rebate-claim-warn"><i class="ri-error-warning-line" aria-hidden="true"></i>' +
			"<span>If 3M records don't have Pan No., and if customer has not provided an update then TDS will be deducted " +
			"<b>@20%</b> as against <b>5%</b> at the time of claim reimbursement.</span></div>";

		html += '<div class="rebate-claim-guide">' +
			'<div class="rebate-claim-guide-head"><i class="ri-book-open-line" aria-hidden="true"></i>' +
			"<h6>Instruction for Submitting Claim</h6></div><ol>" +
			"<li>Please raise a separate invoice by state for each claim.</li>" +
			"<li>Claim amount mentioned above is basic value. Please charge GST as per the current prevailing rules.</li>" +
			"<li>You may use the SAC code and service description as shown in the claim line or as appropriate.</li>" +
			"<li>Don't forget to mention the correct GST registration of 3M on your invoice. The same is also provided at a state level for your reference.</li>" +
			"<li>All fields are mandatory for you to fill except comments.</li>" +
			"<li>Upload the correct invoice copy to avoid delays or rejection of claims.</li>" +
			"</ol>" +
			'<div class="rebate-claim-guide-note"><strong>Important Note</strong><ol>' +
			"<li>Applicable TDS under income tax act, 1961 will be deducted while processing these claims.</li>" +
			"<li>Any loss of tax credit under GST (CGST, SGST or IGST) to 3M due to incorrect invoicing or inaccurate uploading of GSTR-1 at your end will be charged back to you.</li>" +
			"</ol></div>" +
			'<p class="rebate-claim-guide-disclaimer"><strong>Disclaimer:</strong> You are advised to take any tax position including but not limited to GST, income tax after consulting your tax advisor. ' +
			"3M shall in no manner be responsible or financially liable for any consequential hardship to you under any tax laws.</p>" +
			"</div></div>";
		return html;
	},

	ShowClaimTerms: function () {
		RebateProgram._showModal("rebate_claim_terms_modal");
		var el = RebateProgram._el("#rebate_claim_terms_modal");
		if (el) {
			el.style.zIndex = "1095";
		}
		if (window.jQuery) {
			$(".modal-backdrop").last().css("z-index", "1090");
		}
		return false;
	},

	_isoToUiDate: function (value) {
		var text = String(value || "").trim();
		if (!text || text.indexOf("1900") === 0) return "";
		if (/^\d{2}\/\d{2}\/\d{4}$/.test(text)) return text;
		var parts = text.substring(0, 10).split("-");
		if (parts.length !== 3) return text;
		return parts[2] + "/" + parts[1] + "/" + parts[0];
	},

	_uiToIsoDate: function (value) {
		var text = String(value || "").trim();
		if (!text) return "";
		if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
		var parts = text.split("/");
		if (parts.length !== 3) return text;
		return parts[2] + "-" + parts[1] + "-" + parts[0];
	},

	/** Legacy CallTarkaDatePickerNew(start_date, id): startDate=approved-30d, endDate=today. */
	_claimDatePickerOpts: function () {
		var fromUi = String(RebateProgram._$("#rebate_claim_content").data("invDateFrom") || "").trim();
		var opts = {
			format: "dd/mm/yyyy",
			autoclose: true,
			todayHighlight: true,
			todayBtn: "linked",
			forceParse: false,
			endDate: "+0d"
		};
		if (/^\d{2}\/\d{2}\/\d{4}$/.test(fromUi)) {
			opts.startDate = fromUi;
		}
		return opts;
	},

	_openClaimDatePicker: function (inputId) {
		var el = RebateProgram._el("#" + inputId);
		if (!el || !window.jQuery || !$.fn.datepicker) return false;
		var $el = $(el);
		try {
			if ($el.data("datepicker")) $el.datepicker("destroy");
		} catch (ignore) { /* ignore */ }
		$el.datepicker(RebateProgram._claimDatePickerOpts()).on("show", function () {
			$(".datepicker").css("z-index", 3000);
		});
		$el.datepicker("show");
		$(".datepicker").css("z-index", 3000);
		return false;
	},

	/**
	 * Legacy UploadCustInv.GSTValidation:
	 * max = incentive + 18% GST; if |max - value| > 1 and value > 0 → reset to 0.
	 */
	GSTValidation: function (inputOrRow) {
		var $input = inputOrRow && inputOrRow.nodeType
			? $(inputOrRow)
			: (typeof inputOrRow === "number" || /^\d+$/.test(String(inputOrRow || ""))
				? RebateProgram._$("#rebate_claim_content .rebate-claim-inv[data-row-key='" + inputOrRow + "'] .rebate-invoice-value")
				: $(inputOrRow));
		if (!$input.length) $input = $(this);
		var $block = $input.closest(".rebate-claim-inv");
		if (!$block.length) return false;
		var invValue = Number(String($input.val() || "").trim()) || 0;
		var incentive = Number($block.attr("data-incentive")) || 0;
		var maxAllowed = RebateProgram._round2(incentive + (incentive * 0.18));
		var diff = Math.abs(RebateProgram._round2(maxAllowed - invValue));
		if (diff > 1 && invValue > 0) {
			RebateProgram._message(
				"Invoice value cannot exceed " + RebateProgram._money(maxAllowed) +
				" (claim amount + 18% GST).", true);
			$input.val("0");
			$input.css({ "border-color": "#dc2626", "box-shadow": "0 0 0 1px #dc2626" });
			RebateProgram._refreshClaimTotal();
			return false;
		}
		$input.css({ "border-color": "", "box-shadow": "" });
		RebateProgram._refreshClaimTotal();
		return true;
	},

	_round2: function (n) {
		return Math.round((Number(n) || 0) * 100) / 100;
	},

	_toNumber: function (value) {
		if (value === null || value === undefined || value === "") return 0;
		if (typeof value === "number") return isFinite(value) ? value : 0;
		var cleaned = String(value).replace(/,/g, "").replace(/[^\d.-]/g, "").trim();
		var num = Number(cleaned);
		return isFinite(num) ? num : 0;
	},

	_refreshClaimTotal: function () {
		var $content = RebateProgram._claimContent$();
		if (!$content.length) return;
		var $total = $content.find("#rebate_claim_total_amt");
		if (!$total.length) return;
		var total = 0;
		var $inputs = $content.find("input.rebate-invoice-value");
		if ($inputs.length) {
			$inputs.each(function () {
				total += RebateProgram._toNumber(this.value);
			});
			$total.attr("data-total-incl", RebateProgram._round2(total));
			$total.text(RebateProgram._money(total));
			return;
		}
		/* Read-only: keep the amount baked into the form for this claim (never reuse another claim's total). */
		var baked = $total.attr("data-total-incl");
		if (baked !== undefined && baked !== null && String(baked).trim() !== "") {
			$total.text(RebateProgram._money(RebateProgram._toNumber(baked)));
			return;
		}
		$content.find(".rebate-claim-inv").each(function () {
			total += RebateProgram._toNumber($(this).attr("data-inv-value"));
		});
		$total.attr("data-total-incl", RebateProgram._round2(total));
		$total.text(RebateProgram._money(total));
	},

	_initClaimDatePickers: function () {
		var $content = RebateProgram._claimContent$();
		var opts = RebateProgram._claimDatePickerOpts();
		$content.find(".rebate-invoice-date").each(function () {
			var $el = $(this);
			$el.attr("data-date-format", "dd/mm/yyyy").attr("placeholder", "dd/mm/yyyy");
			try {
				if ($el.data("datepicker")) $el.datepicker("destroy");
			} catch (ignore) { /* ignore */ }
			if (window.jQuery && $.fn.datepicker) {
				$el.datepicker(opts);
			}
		});
		var $values = $content.find("input.rebate-invoice-value");
		$values.off("input.rebateTotal blur.rebateGst")
			.on("input.rebateTotal", function () {
				RebateProgram._refreshClaimTotal();
			})
			.on("blur.rebateGst", function () {
				RebateProgram.GSTValidation(this);
			});
		/* Editable only — read-only total is already correct in the rendered HTML. */
		if ($values.length) {
			RebateProgram._refreshClaimTotal();
		}
	},

	/**
	 * Legacy UploadCustInv.SubmitFinalData('Draft'|'Submit').
	 * Draft = Save for Later (light checks). Submit = full T&C / PAN / uploads + confirm.
	 */
	SubmitClaim: function (_button, type) {
		type = type === "Save" ? "Draft" : type;
		if (type !== "Draft" && type !== "Submit") {
			RebateProgram._message("Invalid claim action.", true);
			return false;
		}
		if (type === "Submit" && !RebateProgram._$("#rebate_terms_check").prop("checked")) {
			RebateProgram._message("Please accept T&C to continue.", true);
			return false;
		}
		if (type === "Submit" && !RebateProgram._$("#rebate_pan_check").prop("checked") &&
				!RebateProgram._$("#rebate_update_check").prop("checked")) {
			RebateProgram._message("Please select at least one PAN/GST checkbox.", true);
			return false;
		}
		var invoices = [];
		var missingGst = 0;
		RebateProgram._$("#rebate_claim_content .rebate-claim-inv").each(function () {
			var $block = $(this);
			var taxType = String($block.find(".rebate-tax").val() || "").trim();
			if (!taxType) missingGst++;
			invoices.push({
				stateCode: $block.attr("data-state"), taxType: taxType,
				invoiceNo: $block.find(".rebate-invoice-no").val(),
				invoiceDate: RebateProgram._uiToIsoDate($block.find(".rebate-invoice-date").val()),
				invoiceValue: $block.find(".rebate-invoice-value").val()
			});
		});
		if (!invoices.length) {
			RebateProgram._message("This claim has no invoice payout lines.", true);
			return false;
		}
		if (missingGst > 0) {
			RebateProgram._message("Please select GST Type for all invoices.", true);
			return false;
		}
		var doSubmit = function () {
			RebateProgram._request("/claim/submit", "POST", JSON.stringify({
				custCode: RebateProgram._customer.custCode, loginId: RebateProgram._customer.loginId,
				program: RebateProgram._$("#rebate_claim_content").data("program"),
				claimCase: RebateProgram._$("#rebate_claim_content").data("claimCase"), type: type,
				termsAccepted: RebateProgram._$("#rebate_terms_check").prop("checked"),
				panVerified: RebateProgram._$("#rebate_pan_check").prop("checked"),
				updateRequested: RebateProgram._$("#rebate_update_check").prop("checked"),
				panRemarks: RebateProgram._$("#rebate_pan_remarks").val(), invoices: invoices
			}), function (data) {
				RebateProgram._message((data && data.message) ||
					(type === "Submit" ? "Claim submitted." : "Claim saved for later."), false);
				RebateProgram._hideModal("rebate_claim_modal");
				RebateProgram._loaded.claims = false;
				RebateProgram.LoadClaims();
			}, null, {
				target: "rebate_claim_modal",
				message: type === "Submit" ? "Submitting claim..." : "Saving claim..."
			});
		};
		if (type !== "Submit") {
			doSubmit();
			return false;
		}
		var confirmText = "Do you want to go ahead with the changes in the form? Click Cancel to continue editing, or OK to submit the claim.";
		if (RebateProgram._$("#rebate_update_check").prop("checked") &&
				!String(RebateProgram._$("#rebate_pan_remarks").val() || "").trim()) {
			confirmText += "\n\nIf PAN and GST No is blank and you have not provided an update, TDS will be deducted @20% on your claim reimbursement.";
		}
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				icon: "question",
				title: "Submit claim?",
				text: confirmText,
				showCancelButton: true,
				confirmButtonText: "OK, submit",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#16a34a",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) doSubmit();
			});
			if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
			return false;
		}
		if (window.confirm(confirmText)) doSubmit();
		return false;
	},

	/**
	 * Legacy UploadCustInv.UploadCustomerInvoiceDocument(rowKey, program):
	 * validate line fields, upload Inv copy (required) and optional GST copy.
	 */
	UploadInvoiceRow: function (button) {
		var $block = $(button).closest(".rebate-claim-inv");
		if (!$block.length) return false;
		var taxType = String($block.find(".rebate-tax").val() || "").trim();
		var invoiceNo = String($block.find(".rebate-invoice-no").val() || "").trim();
		var invoiceDate = String($block.find(".rebate-invoice-date").val() || "").trim();
		var invoiceValue = String($block.find(".rebate-invoice-value").val() || "").trim();
		var invInput = $block.find("input.rebate-inv-file").get(0);
		var gstInput = $block.find("input.rebate-gst-file").get(0);
		var hasInvFile = !!(invInput && invInput.files && invInput.files.length);
		var hasGstFile = !!(gstInput && gstInput.files && gstInput.files.length);
		if (!invoiceValue || Number(invoiceValue) === 0) {
			RebateProgram._message("Please enter invoice value.", true);
			return false;
		}
		if (!RebateProgram.GSTValidation($block.find(".rebate-invoice-value").get(0))) {
			return false;
		}
		if (!invoiceDate) {
			RebateProgram._message("Please enter invoice date.", true);
			return false;
		}
		var dateFrom = String(RebateProgram._$("#rebate_claim_content").data("invDateFrom") || "").trim();
		if (dateFrom && /^\d{2}\/\d{2}\/\d{4}$/.test(invoiceDate)) {
			var toParts = invoiceDate.split("/");
			var fromParts = dateFrom.split("/");
			var invDt = new Date(Number(toParts[2]), Number(toParts[1]) - 1, Number(toParts[0]));
			var fromDt = new Date(Number(fromParts[2]), Number(fromParts[1]) - 1, Number(fromParts[0]));
			var today = new Date();
			today.setHours(23, 59, 59, 999);
			if (invDt < fromDt || invDt > today) {
				RebateProgram._message(
					"Invoice date must be between " + dateFrom + " and today.", true);
				return false;
			}
		}
		if (!invoiceNo) {
			RebateProgram._message("Please enter invoice number.", true);
			return false;
		}
		if (!taxType) {
			RebateProgram._message("Please select GST type.", true);
			return false;
		}
		var $invBrowse = $block.find("input.rebate-inv-file").closest(".rebate-file-browse");
		var alreadyHasInvoice = $block.attr("data-has-invoice") === "1" ||
			$invBrowse.attr("data-uploaded") === "1" ||
			!!String($invBrowse.find(".rebate-file-name").text() || "").trim();
		if (!hasInvFile && !alreadyHasInvoice) {
			RebateProgram._message("Please browse and select the invoice copy to upload.", true);
			return false;
		}
		var fields = {
			custCode: RebateProgram._customer.custCode,
			loginId: RebateProgram._customer.loginId,
			program: RebateProgram._$("#rebate_claim_content").data("program"),
			claimCase: RebateProgram._$("#rebate_claim_content").data("claimCase"),
			stateCode: $block.attr("data-state"),
			taxType: taxType,
			invoiceNo: invoiceNo,
			invoiceDate: RebateProgram._uiToIsoDate(invoiceDate),
			invoiceValue: invoiceValue
		};
		var queue = [];
		if (hasInvFile) {
			queue.push({ file: invInput.files[0], kind: "INVOICE" });
		}
		if (hasGstFile) {
			queue.push({ file: gstInput.files[0], kind: "GST" });
		}
		/* Reopen with files already on server: save field changes without requiring a new browse. */
		if (!queue.length) {
			if (!alreadyHasInvoice) {
				RebateProgram._message("Browse a new invoice or GST file before uploading.", true);
				return false;
			}
			$block.attr("data-has-invoice", "1");
			RebateProgram._saveInvoiceDetails(fields);
			return false;
		}
		RebateProgram._uploadQueue(queue, fields, 0);
		return false;
	},

	/** Persist invoice line fields when evidence is already uploaded (no new file). */
	_saveInvoiceDetails: function (fields) {
		RebateProgram._request("/claim/invoice-details", "POST", JSON.stringify({
			custCode: fields.custCode,
			loginId: fields.loginId,
			program: fields.program,
			claimCase: fields.claimCase,
			stateCode: fields.stateCode,
			taxType: fields.taxType,
			invoiceNo: fields.invoiceNo,
			invoiceDate: fields.invoiceDate,
			invoiceValue: fields.invoiceValue
		}), function (data) {
			RebateProgram._alert((data && data.message) || "Invoice details saved.", false);
		}, null, { target: "rebate_claim_modal", message: "Saving invoice details..." });
	},

	UploadInvoice: function (input, kind) {
		if (!input || !input.files || !input.files.length) return false;
		var $block = $(input).closest(".rebate-claim-inv");
		RebateProgram._upload(input.files[0], "/claim/upload", {
			custCode: RebateProgram._customer.custCode, loginId: RebateProgram._customer.loginId,
			program: RebateProgram._$("#rebate_claim_content").data("program"),
			claimCase: RebateProgram._$("#rebate_claim_content").data("claimCase"),
			stateCode: $block.attr("data-state"), kind: kind,
			taxType: $block.find(".rebate-tax").val(), invoiceNo: $block.find(".rebate-invoice-no").val(),
			invoiceDate: RebateProgram._uiToIsoDate($block.find(".rebate-invoice-date").val()),
			invoiceValue: $block.find(".rebate-invoice-value").val()
		});
		return false;
	},

	UploadProgramDocument: function (documentCode) {
		var input = RebateProgram._el("#rebate_program_file_" + documentCode);
		if (!input || !input.files || !input.files.length) {
			RebateProgram._message("Select a document first.", true);
			return false;
		}
		RebateProgram._upload(input.files[0], "/claim/program-document", {
			custCode: RebateProgram._customer.custCode, loginId: RebateProgram._customer.loginId,
			program: RebateProgram._$("#rebate_claim_content").data("program"),
			claimCase: RebateProgram._$("#rebate_claim_content").data("claimCase"), documentCode: documentCode
		});
		return false;
	},

	DeleteProgramDocument: function (documentCode) {
		var doDelete = function () {
			RebateProgram._request("/claim/program-document/" + encodeURIComponent(documentCode), "DELETE", {
				custCode: RebateProgram._customer.custCode, loginId: RebateProgram._customer.loginId,
				program: RebateProgram._$("#rebate_claim_content").data("program"),
				claimCase: RebateProgram._$("#rebate_claim_content").data("claimCase")
			}, function () {
				RebateProgram.OpenClaim(RebateProgram._$("#rebate_claim_content").data("program"),
					RebateProgram._$("#rebate_claim_content").data("claimCase"));
			}, null, { target: "rebate_claim_modal", message: "Deleting document..." });
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this document?",
				text: "The selected file will be removed from this claim.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "Yes, delete",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#d33",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) {
					doDelete();
				}
			});
			if (window.jQuery) {
				$(".swal2-container").css("z-index", "22222229999");
			}
			return false;
		}
		if (window.confirm("Delete this document?")) {
			doDelete();
		}
		return false;
	},

	DownloadProgramFile: function (program) {
		RebateProgram._open("/programs/" + encodeURIComponent(program) + "/document");
		return false;
	},

	DownloadClaimDocument: function (documentCode) {
		RebateProgram._open("/claim/program-document/" + encodeURIComponent(documentCode) +
			"/download?program=" + encodeURIComponent(RebateProgram._$("#rebate_claim_content").data("program")) +
			"&claimCase=" + encodeURIComponent(RebateProgram._$("#rebate_claim_content").data("claimCase")));
		return false;
	},

	DownloadEvidence: function (stateCode, kind, openTab) {
		var path = "/claim/evidence/" +
			encodeURIComponent(RebateProgram._$("#rebate_claim_content").data("program")) + "/" +
			encodeURIComponent(RebateProgram._$("#rebate_claim_content").data("claimCase")) + "/" +
			encodeURIComponent(stateCode) + "/" + encodeURIComponent(kind);
		if (openTab) {
			var context = RebateProgram._procedureContext();
			var url = (window.$app_url || "") + RebateProgram._api + path +
				"?custCode=" + encodeURIComponent(context.custCode) +
				"&loginId=" + encodeURIComponent(context.loginId);
			window.open(url, "_blank", "noopener");
			return false;
		}
		RebateProgram._open(path);
		return false;
	},

	ExportClaims: function () {
		var fromDate = RebateProgram._iso("rebate_export_from");
		var toDate = RebateProgram._iso("rebate_export_to");
		if (!!fromDate !== !!toDate) {
			RebateProgram._message("Select both approval-date limits or leave both blank.", true);
			return false;
		}
		RebateProgram._open("/claims/export?from=" + encodeURIComponent(fromDate) +
			"&to=" + encodeURIComponent(toDate));
		return false;
	},

	_loadRows: function (path, rootId, key, mapRow) {
		var loaderMsg = key === "claims" ? "Loading claims..." :
			(key === "enrollment" ? "Loading enrollment..." : "Loading...");
		RebateProgram._request(path, "GET", RebateProgram._customer, function (data) {
			var list = Array.isArray(data) ? data : (data && data.rows) || [];
			RebateProgram._loaded[key] = true;
			if (window.Common && Common.DataTable) {
				Common.DataTable.setData(rootId, list.map(mapRow));
			}
		}, null, { target: rootId, message: loaderMsg });
	},

	_loadHtmlRows: function (path, targetId, key, columns, emptyText, render) {
		var loaderTarget = targetId === "rebate_ytd_rows" ? "rebate_ytd" : RebateProgram.ROOT;
		RebateProgram._request(path, "GET", RebateProgram._customer, function (data) {
			var list = Array.isArray(data) ? data : (data && data.rows) || [];
			RebateProgram._loaded[key] = true;
			RebateProgram._$("#" + targetId).html(list.length
				? list.map(render).join("")
				: '<tr><td colspan="' + columns + '" class="rebate-empty">' +
					RebateProgram._escape(emptyText) + "</td></tr>");
		}, null, { target: loaderTarget, message: "Loading YTD achievement..." });
	},

	_ensureDatePickers: function () {
		var $root = RebateProgram._$home();
		if (!$root.length || !window.jQuery || !$.fn.datepicker) return;
		$root.find("#rebate_export_from, #rebate_export_to").each(function () {
			var $el = $(this);
			$el.attr("data-date-format", "dd/mm/yyyy");
			$el.attr("placeholder", "dd/mm/yyyy");
			try {
				if ($el.data("datepicker")) $el.datepicker("destroy");
			} catch (eD) { /* Ignore stale picker instances after fragment reload. */ }
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				format: "dd/mm/yyyy",
				orientation: "bottom auto",
				defaultViewDate: new Date()
			});
		});
	},

	_iso: function (id) {
		var raw = $.trim(RebateProgram._$("#" + id).val());
		var parts = raw.split("/");
		if (parts.length !== 3) return "";
		return parts[2] + "-" + parts[1] + "-" + parts[0];
	},

	_upload: function (file, endpoint, fields, onDone) {
		var form = new FormData();
		form.append("file", file);
		Object.keys(fields).forEach(function (key) { form.append(key, fields[key]); });
		var loaderTarget = "rebate_claim_modal";
		RebateProgram._showLoader("Uploading...", loaderTarget);
		$.ajax({
			url: (window.$app_url || "") + RebateProgram._api + endpoint, method: "POST", data: form,
			processData: false, contentType: false, dataType: "json", xhrFields: { withCredentials: true },
			success: function (json) {
				if (RebateProgram._session(json)) return;
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					RebateProgram._alert(
						(json && (json.message || json.status || (json.data && json.data.message))) ||
						"Upload failed.", true);
					return;
				}
				if (typeof onDone === "function") {
					onDone(json);
					return;
				}
				RebateProgram._alert((json.data && json.data.message) || "File uploaded.", false);
				/* Keep claim popup open — update local upload state only. */
				if (fields && (fields.kind === "INVOICE" || fields.kind === "GST")) {
					RebateProgram._afterInvoiceUpload(fields, [{ kind: fields.kind }]);
					return;
				}
				if (fields && fields.documentCode && RebateProgram._isClaimUiOpen()) {
					RebateProgram._markBrowseUploaded(
						RebateProgram._el("#rebate_program_file_" + fields.documentCode));
					return;
				}
				if (!RebateProgram._isClaimUiOpen()) {
					RebateProgram.OpenClaim(fields.program, fields.claimCase);
				}
			},
			error: function (xhr) {
				if (xhr && xhr.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					return;
				}
				var failMsg = "File upload failed.";
				try {
					var body = xhr && xhr.responseJSON;
					if (body && (body.message || body.status)) {
						failMsg = body.message || body.status;
					} else if (xhr && xhr.responseText) {
						var parsed = JSON.parse(xhr.responseText);
						if (parsed && (parsed.message || parsed.status)) {
							failMsg = parsed.message || parsed.status;
						}
					}
				} catch (ignore) { /* keep default */ }
				RebateProgram._alert(failMsg, true);
			},
			complete: function () {
				RebateProgram._hideLoader(loaderTarget);
			}
		});
	},

	_uploadQueue: function (queue, fields, index) {
		if (!queue || !queue.length) return;
		if (index >= queue.length) {
			RebateProgram._alert("Uploaded successfully.", false);
			RebateProgram._afterInvoiceUpload(fields, queue);
			return;
		}
		var item = queue[index];
		var payload = {};
		for (var key in fields) {
			if (Object.prototype.hasOwnProperty.call(fields, key)) {
				payload[key] = fields[key];
			}
		}
		payload.kind = item.kind;
		RebateProgram._upload(item.file, "/claim/upload", payload, function () {
			RebateProgram._uploadQueue(queue, fields, index + 1);
		});
	},

	/** After invoice/GST row upload: keep modal open; mark files uploaded on that card. */
	_afterInvoiceUpload: function (fields, queue) {
		var state = String(fields && fields.stateCode || "").trim();
		if (!state) return;
		var $block = RebateProgram._$("#rebate_claim_content .rebate-claim-inv").filter(function () {
			return String($(this).attr("data-state") || "") === state;
		}).first();
		if (!$block.length) return;
		(queue || []).forEach(function (item) {
			var kind = String(item && item.kind || "").toUpperCase();
			if (kind === "INVOICE") {
				$block.attr("data-has-invoice", "1");
				RebateProgram._markBrowseUploaded($block.find("input.rebate-inv-file").get(0));
			} else if (kind === "GST") {
				$block.attr("data-has-gst", "1");
				RebateProgram._markBrowseUploaded($block.find("input.rebate-gst-file").get(0));
			}
		});
	},

	_markBrowseUploaded: function (input) {
		if (!input) return;
		var $wrap = $(input).closest(".rebate-file-browse");
		if (!$wrap.length) return;
		var name = (input.files && input.files[0] && input.files[0].name) ||
			String($wrap.find(".rebate-file-name").text() || "").trim() || "Uploaded";
		try {
			input.value = "";
		} catch (ignore) { /* IE/Edge guarded clear */ }
		RebateProgram._revokeFilePreview($wrap);
		$wrap.attr("data-uploaded", "1");
		$wrap.find(".rebate-file-name").text(name).attr("title", name).removeAttr("aria-hidden");
		$wrap.find(".rebate-file-actions").removeClass("d-none");
	},

	_request: function (path, method, data, success, onError, opts) {
		opts = opts || null;
		var loaderTarget = opts && opts.target ? opts.target : RebateProgram.ROOT;
		var useLoader = !!(opts && (opts.target || opts.message));
		if (useLoader) {
			RebateProgram._showLoader((opts && opts.message) || "Please wait…", loaderTarget);
		}
		$.ajax({
			url: (window.$app_url || "") + RebateProgram._api + path,
			method: method || "GET", data: data,
			contentType: method === "POST" ? "application/json; charset=utf-8" : undefined,
			dataType: "json", xhrFields: { withCredentials: true },
			success: function (json) {
				if (RebateProgram._session(json)) return;
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					var failMsg = (json && (json.message || json.status)) || "The request could not be completed.";
					if (typeof onError === "function") {
						onError(failMsg);
					} else {
						RebateProgram._message(failMsg, true);
					}
					return;
				}
				success(json.data);
			},
			error: function (xhr) {
				if (xhr.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					return;
				}
				var failMsg = "The Rebate service could not complete the request.";
				try {
					var body = xhr && xhr.responseJSON;
					if (body && (body.message || body.status)) {
						failMsg = body.message || body.status;
					}
				} catch (ignore) { /* use default */ }
				if (typeof onError === "function") {
					onError(failMsg);
				} else {
					RebateProgram._message(failMsg, true);
				}
			},
			complete: function () {
				if (useLoader) {
					RebateProgram._hideLoader(loaderTarget);
				}
			}
		});
	},

	_procedureContext: function () {
		if (Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	},

	_open: function (path) {
		var context = RebateProgram._procedureContext();
		var separator = path.indexOf("?") === -1 ? "?" : "&";
		window.location.href = (window.$app_url || "") + RebateProgram._api + path + separator +
			"custCode=" + encodeURIComponent(context.custCode) +
			"&loginId=" + encodeURIComponent(context.loginId);
	},

	_session: function (json) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return true;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return true;
		}
		return false;
	},

	_message: function (message, isError) {
		/* Page banner — also surface as popup when a claim/program modal is open. */
		RebateProgram._$("#rebate_message").toggleClass("alert-danger", !!isError)
			.toggleClass("alert-success", !isError).removeClass("d-none").text(message || "");
		if (RebateProgram._isClaimUiOpen()) {
			RebateProgram._alert(message, isError);
		}
	},

	_isClaimUiOpen: function () {
		var ids = ["rebate_claim_modal", "rebate_claim_terms_modal", "rebate_program_modal", "rebate_discrepancy_modal"];
		for (var i = 0; i < ids.length; i++) {
			var el = RebateProgram._el("#" + ids[i]);
			if (el && (el.classList.contains("show") || $(el).hasClass("show") ||
					$(el).css("display") === "block")) {
				return true;
			}
		}
		return false;
	},

	/** Always on top of claim modal (legacy bootbox.alert style). */
	_alert: function (message, isError) {
		var text = String(message == null ? "" : message).trim() ||
			(isError ? "Something went wrong." : "Done.");
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				icon: isError ? "error" : "success",
				title: isError ? "Unable to complete" : "Success",
				text: text,
				confirmButtonColor: isError ? "#dc2626" : "#16a34a"
			});
			if (window.jQuery) {
				$(".swal2-container").css("z-index", "22222229999");
			}
			return;
		}
		window.alert(text);
	},

	_escape: function (value) {
		return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
			return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
		});
	},

	_jsString: function (value) {
		return JSON.stringify(String(value == null ? "" : value))
			.replace(/&/g, "&amp;").replace(/"/g, "&quot;")
			.replace(/</g, "&lt;").replace(/>/g, "&gt;");
	}
};
