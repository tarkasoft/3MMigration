/**
 * Shop Order Return interactions.
 */
ShopOrder = {
	HOME: "m_shop_order_home",
	API: "api/customer/shop-order",
	MAX_HEADER_FILE_SIZE_BYTES: 3 * 1024 * 1024,
	docPreviewUrls: {},
	headerDocuments: [],
	nextHeaderDocumentId: 1,
	shopOrderAjax: null,
	detailsAjax: null,
	selectedShopOrder: "",

	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + ShopOrder.HOME) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $("#" + ShopOrder.HOME).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $("#" + ShopOrder.HOME).first();
	},

	_$: function (selector) {
		var $home = ShopOrder._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	Load: function () {
		var $home = ShopOrder._$home();
		if (!$home.length) {
			return;
		}
		$home.off(".shopOrder");
		ShopOrder.wireShopOrderAutocomplete();
		ShopOrder.clearShopOrderDetails();
		ShopOrder.renderVendorNumber();
		$home.on("click.shopOrder", ".so-tab", function () {
			ShopOrder.activateTab($(this).attr("aria-controls"));
		});
		$home.on("keydown.shopOrder", ".so-tab", function (event) {
			var $tabs = ShopOrder._$(".so-tab");
			var index = $tabs.index(this);
			var nextIndex = index;
			if (event.key === "ArrowRight") {
				nextIndex = (index + 1) % $tabs.length;
			} else if (event.key === "ArrowLeft") {
				nextIndex = (index - 1 + $tabs.length) % $tabs.length;
			} else if (event.key === "Home") {
				nextIndex = 0;
			} else if (event.key === "End") {
				nextIndex = $tabs.length - 1;
			} else {
				return;
			}
			event.preventDefault();
			$tabs.eq(nextIndex).trigger("focus").trigger("click");
		});
		$home.on("click.shopOrder", "[data-so-header-browse]", function () {
			var inputId = String($(this).attr("data-so-header-browse") || "");
			var input = ShopOrder._$("#" + inputId).get(0);
			if (input) {
				input.click();
			}
		});
		$home.on("change.shopOrder", ".so-doc-input[data-document-kind]", function () {
			ShopOrder.addHeaderDocuments(this.files, String($(this).attr("data-document-kind") || ""));
			this.value = "";
		});
		$home.on("click.shopOrder", "[data-so-header-view]", function () {
			ShopOrder.viewHeaderDocument(String($(this).attr("data-so-header-view") || ""));
		});
		$home.on("click.shopOrder", "[data-so-header-delete]", function () {
			ShopOrder.deleteHeaderDocument(String($(this).attr("data-so-header-delete") || ""));
		});
		$home.on("click.shopOrder", ".so-calendar", function () {
			var $input = $(this).siblings(".date-picker").first();
			if ($input.length && $.fn.datepicker) {
				$input.datepicker("show");
			}
		});
		$home.on("click.shopOrder", "[data-so-doc-browse]", function () {
			var inputId = String($(this).attr("data-so-doc-browse") || "");
			var input = ShopOrder._$("#" + inputId).get(0);
			if (input) {
				input.click();
			}
		});
		$home.on("change.shopOrder", ".so-doc-input", function () {
			ShopOrder.onDocumentChange(this);
		});
		$home.on("click.shopOrder", "[data-so-doc-view]", function () {
			ShopOrder.viewDocument($(this));
		});
		$home.on("click.shopOrder", "[data-so-doc-delete]", function () {
			ShopOrder.deleteDocument($(this));
		});
		ShopOrder.ensureDatePickers($home);
		ShopOrder.updateLineCount();
		ShopOrder.renderHeaderDocuments();
	},

	renderVendorNumber: function () {
		var vendorCode = "";
		if (window.Common && typeof Common.GetCustCode === "function") {
			vendorCode = String(Common.GetCustCode() || "").trim();
		} else if (window.Common && typeof Common.GetProcedureCustomerContext === "function") {
			var context = Common.GetProcedureCustomerContext() || {};
			vendorCode = String(context.custCode || "").trim();
		}
		var $badge = ShopOrder._$("#so_vendor_number");
		if (!$badge.length) {
			return;
		}
		$badge.find("[data-so-vendor-code]").text(vendorCode);
		$badge.prop("hidden", !vendorCode);
	},

	activateTab: function (panelId) {
		var $tabs = ShopOrder._$(".so-tab");
		var $panels = ShopOrder._$(".so-tab-panel");
		var $target = $panels.filter(function () {
			return this.id === panelId;
		});
		if (!$target.length) {
			return;
		}
		$tabs.each(function () {
			var selected = $(this).attr("aria-controls") === panelId;
			$(this).attr("aria-selected", selected ? "true" : "false")
				.attr("tabindex", selected ? "0" : "-1");
		});
		$panels.each(function () {
			this.hidden = this.id !== panelId;
		});
	},

	requestContext: function () {
		var context = window.Common && Common.GetProcedureCustomerContext
			? (Common.GetProcedureCustomerContext() || {}) : {};
		return {
			custCode: String(context.custCode || "").trim(),
			loginId: String(context.loginId || "").trim()
		};
	},

	wireShopOrderAutocomplete: function () {
		var $input = ShopOrder._$("#so_shop_order");
		if (!$input.length || typeof $input.autocomplete !== "function") {
			ShopOrder._$("#so_shop_order_error").text("Shop Order search is unavailable.");
			return;
		}
		if ($input.data("ui-autocomplete")) {
			$input.autocomplete("destroy");
		}
		$input.off(".shopOrderAc")
			.on("input.shopOrderAc", function () {
				ShopOrder._$("#so_shop_order_error").empty();
				if (String(this.value || "").trim() !== ShopOrder.selectedShopOrder) {
					ShopOrder.clearShopOrderDetails();
				}
			});
		$input.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: "#" + ShopOrder.HOME,
			position: { my: "left top", at: "left bottom", collision: "flip" },
			source: function (request, response) {
				if (ShopOrder.shopOrderAjax && ShopOrder.shopOrderAjax.abort) {
					ShopOrder.shopOrderAjax.abort();
				}
				ShopOrder._$("#so_shop_order_error").empty();
				if (window.Common && Common.ShowAcSpinner) {
					Common.ShowAcSpinner("#" + ShopOrder.HOME, "so_shop_order_ac_spinner");
				}
				ShopOrder.shopOrderAjax = $.ajax({
					url: (window.$app_url || "") + ShopOrder.API + "/autocomplete",
					method: "GET",
					data: $.extend({}, ShopOrder.requestContext(), { term: request.term }),
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
						window.inpcHandleSessionExpired(json && (json.message || json.data));
						response([]);
						return;
					}
					if (!json || Number(json.errorCode) !== 0) {
						ShopOrder._$("#so_shop_order_error").text((json && json.message) || "Unable to search shop orders.");
						response([]);
						return;
					}
					var rows = json.data || [];
					if (!rows.length) {
						ShopOrder._$("#so_shop_order_error").text("No shop orders found.");
					}
					response($.map(rows, function (row) {
						return {
							label: row.shopOrder + " - " + row.jwWarehouseCode + " - "
								+ row.finishedGood + " (" + row.requestedQuantity + ")",
							value: row.shopOrder,
							shopOrder: row.shopOrder
						};
					}));
				}).fail(function (_xhr, status) {
					if (status !== "abort") {
						ShopOrder._$("#so_shop_order_error").text("Unable to search shop orders.");
						response([]);
					}
				}).always(function () {
					if (window.Common && Common.HideAcSpinner) {
						Common.HideAcSpinner("#" + ShopOrder.HOME, "so_shop_order_ac_spinner");
					}
					$input.removeClass("ui-autocomplete-loading");
				});
			},
			select: function (_event, ui) {
				var selected = ui.item || {};
				ShopOrder.selectedShopOrder = String(selected.shopOrder || selected.value || "");
				$input.val(ShopOrder.selectedShopOrder);
				ShopOrder._$("#so_shop_order_error").empty();
				ShopOrder.loadShopOrderDetails(ShopOrder.selectedShopOrder);
				return false;
			}
		});
		$input.autocomplete("widget").css({ zIndex: 1090, position: "absolute" });
	},

	clearShopOrderDetails: function () {
		ShopOrder.selectedShopOrder = "";
		if (ShopOrder.detailsAjax && ShopOrder.detailsAjax.abort) {
			ShopOrder.detailsAjax.abort();
			ShopOrder.detailsAjax = null;
		}
		ShopOrder._$("#so_jw_whs, #so_fg, #so_qty_req").val("");
		ShopOrder.renderShopOrderItems([]);
	},

	loadShopOrderDetails: function (shopOrder) {
		if (!shopOrder) {
			return;
		}
		var requestedShopOrder = shopOrder;
		if (ShopOrder.detailsAjax && ShopOrder.detailsAjax.abort) {
			ShopOrder.detailsAjax.abort();
		}
		ShopOrder.renderShopOrderItems([], "Loading material items...");
		if (typeof showLoader === "function") {
			showLoader("Loading shop order details...", ShopOrder.HOME);
		}
		ShopOrder.detailsAjax = $.ajax({
			url: (window.$app_url || "") + ShopOrder.API + "/details/" + encodeURIComponent(shopOrder),
			method: "GET",
			data: ShopOrder.requestContext(),
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (requestedShopOrder !== ShopOrder.selectedShopOrder) {
				return;
			}
			if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
				window.inpcHandleSessionExpired(json && (json.message || json.data));
				return;
			}
			if (!json || Number(json.errorCode) !== 0 || !json.data) {
				ShopOrder._$("#so_shop_order_error").text((json && json.message) || "Unable to load shop order details.");
				ShopOrder.clearShopOrderDetails();
				ShopOrder._$("#so_shop_order").val(shopOrder);
				ShopOrder.selectedShopOrder = shopOrder;
				return;
			}
			ShopOrder._$("#so_jw_whs").val(json.data.jwWarehouseCode || "");
			ShopOrder._$("#so_fg").val(json.data.finishedGood || "");
			ShopOrder._$("#so_qty_req").val(json.data.requestedQuantity == null ? "" : json.data.requestedQuantity);
			ShopOrder.renderShopOrderItems(json.data.items || []);
		}).fail(function (_xhr, status) {
			if (status !== "abort") {
				ShopOrder._$("#so_shop_order_error").text("Unable to load shop order details.");
			}
		}).always(function () {
			if (typeof hideLoader === "function") {
				hideLoader(ShopOrder.HOME);
			}
		});
	},

	ensureDatePickers: function ($scope) {
		if (typeof window.initDatePickers === "function") {
			window.initDatePickers($scope);
		}
	},

	onDocumentChange: function (input) {
		var file = input && input.files && input.files[0];
		var $cell = $(input).closest(".so-doc-cell");
		if (!file || !$cell.length) {
			return;
		}
		var id = String(input.id || "");
		ShopOrder.revokeDocumentPreview(id);
		$cell.find(".so-doc-name").text(file.name);
		$cell.find(".so-doc-actions").removeClass("d-none");
	},

	viewDocument: function ($button) {
		var $cell = $button.closest(".so-doc-cell");
		var input = $cell.find(".so-doc-input").get(0);
		var file = input && input.files && input.files[0];
		if (!file) {
			return;
		}
		var id = String(input.id || "");
		ShopOrder.revokeDocumentPreview(id);
		var url = URL.createObjectURL(file);
		ShopOrder.docPreviewUrls[id] = url;
		window.open(url, "_blank", "noopener");
	},

	deleteDocument: function ($button) {
		var $cell = $button.closest(".so-doc-cell");
		var input = $cell.find(".so-doc-input").get(0);
		if (!input) {
			return;
		}
		var remove = function () {
			ShopOrder.revokeDocumentPreview(String(input.id || ""));
			input.value = "";
			$cell.find(".so-doc-name").empty();
			$cell.find(".so-doc-actions").addClass("d-none");
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this attachment?",
				text: "The selected file will be removed from this line.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "Yes, delete",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#d33",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) {
					remove();
				}
			});
			return;
		}
		if (window.confirm("Delete this attachment?")) {
			remove();
		}
	},

	revokeDocumentPreview: function (id) {
		var url = ShopOrder.docPreviewUrls[id];
		if (url) {
			URL.revokeObjectURL(url);
			delete ShopOrder.docPreviewUrls[id];
		}
	},

	addHeaderDocuments: function (files, category) {
		if (!files || !files.length) {
			return;
		}
		var oversizedFiles = [];
		for (var i = 0; i < files.length; i++) {
			var file = files[i];
			if (file.size > ShopOrder.MAX_HEADER_FILE_SIZE_BYTES) {
				oversizedFiles.push(file);
				continue;
			}
			ShopOrder.headerDocuments.push({
				id: "header_" + ShopOrder.nextHeaderDocumentId++,
				category: category,
				file: file
			});
		}
		ShopOrder.renderHeaderDocuments();
		if (oversizedFiles.length) {
			ShopOrder.showHeaderDocumentSizeError(oversizedFiles);
		}
	},

	formatHeaderDocumentSize: function (bytes) {
		if (bytes < 1024) {
			return bytes + " B";
		}
		if (bytes < 1024 * 1024) {
			return (bytes / 1024).toFixed(1) + " KB";
		}
		return (bytes / (1024 * 1024)).toFixed(2) + " MB";
	},

	showHeaderDocumentSizeError: function (files) {
		var names = files.map(function (file) {
			return file.name + " (" + ShopOrder.formatHeaderDocumentSize(file.size) + ")";
		});
		var message = (names.length === 1 ? "This file exceeds" : "These files exceed")
			+ " the 3 MB per-file limit and were not added: " + names.join(", ");
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "File size limit exceeded",
				text: message,
				icon: "error",
				confirmButtonText: "OK"
			});
			return;
		}
		window.alert(message);
	},

	renderHeaderDocuments: function () {
		var $lists = ShopOrder._$(".so-header-docs");
		if (!$lists.length) {
			return;
		}
		$lists.empty();
		for (var i = 0; i < ShopOrder.headerDocuments.length; i++) {
			var doc = ShopOrder.headerDocuments[i];
			var $item = $(
				'<div class="so-header-doc">' +
					'<span class="so-header-doc-meta"><span class="so-header-doc-name"></span><span class="so-header-doc-size"></span></span>' +
					'<button type="button" class="so-doc-icon" title="View attachment" aria-label="View attachment" data-so-header-view="' + doc.id + '"><i class="ri-eye-line" aria-hidden="true"></i></button>' +
					'<button type="button" class="so-doc-icon so-doc-delete" title="Delete attachment" aria-label="Delete attachment" data-so-header-delete="' + doc.id + '"><i class="ri-delete-bin-line" aria-hidden="true"></i></button>' +
				'</div>'
			);
			$item.find(".so-header-doc-name").text(doc.file.name).attr("title", doc.file.name);
			$item.find(".so-header-doc-size").text(ShopOrder.formatHeaderDocumentSize(doc.file.size));
			ShopOrder._$('.so-header-docs').filter(function () {
				return String($(this).attr("data-so-header-list") || "") === doc.category;
			}).append($item);
		}
	},

	viewHeaderDocument: function (id) {
		var doc = ShopOrder.headerDocuments.filter(function (item) {
			return item.id === id;
		})[0];
		if (!doc) {
			return;
		}
		ShopOrder.revokeDocumentPreview(id);
		var url = URL.createObjectURL(doc.file);
		ShopOrder.docPreviewUrls[id] = url;
		window.open(url, "_blank", "noopener");
	},

	deleteHeaderDocument: function (id) {
		var doc = ShopOrder.headerDocuments.filter(function (item) {
			return item.id === id;
		})[0];
		if (!doc) {
			return;
		}
		var remove = function () {
			ShopOrder.revokeDocumentPreview(id);
			ShopOrder.headerDocuments = ShopOrder.headerDocuments.filter(function (item) {
				return item.id !== id;
			});
			ShopOrder.renderHeaderDocuments();
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this attachment?",
				text: "The selected file will be removed from this request.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "Yes, delete",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#d33",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) {
					remove();
				}
			});
			return;
		}
		if (window.confirm("Delete this attachment?")) {
			remove();
		}
	},

	documentCellHtml: function (id) {
		return '<td class="so-col-attach"><div class="so-doc-cell">'
			+ '<input type="file" class="so-doc-input" id="so_doc_file_' + id
			+ '" accept=".xls,.xlsx,.pdf,.doc,.docx,.png,.jpg,.jpeg,.bmp,.zip" tabindex="-1" aria-hidden="true">'
			+ '<button type="button" class="so-doc-browse" data-so-doc-browse="so_doc_file_' + id
			+ '" title="Add attachment"><i class="ri-attachment-2" aria-hidden="true"></i> Add</button>'
			+ '<span class="so-doc-name" aria-live="polite"></span>'
			+ '<div class="so-doc-actions d-none" role="group" aria-label="Attachment actions">'
			+ '<button type="button" class="so-doc-icon" data-so-doc-view title="View attachment" aria-label="View attachment"><i class="ri-eye-line" aria-hidden="true"></i></button>'
			+ '<button type="button" class="so-doc-icon so-doc-delete" data-so-doc-delete title="Delete attachment" aria-label="Delete attachment"><i class="ri-delete-bin-line" aria-hidden="true"></i></button>'
			+ '</div></div></td>';
	},

	updateLineCount: function () {
		var $home = ShopOrder._$home();
		var count = $home.find(".so-table tbody tr.so-edit-row").length;
		ShopOrder._$("#so_line_count").text(count
			? count + (count === 1 ? " material line" : " material lines")
			: "Select a shop order to load items");
	},

	renderShopOrderItems: function (items, emptyMessage) {
		var $tbody = ShopOrder._$(".so-table tbody");
		if (!$tbody.length) {
			return;
		}
		$tbody.empty();
		if (!items.length) {
			var message = emptyMessage || (ShopOrder.selectedShopOrder
				? "No material items found for this shop order."
				: "Select a shop order to load material items.");
			$tbody.append($("<tr class=\"so-empty-row\"><td colspan=\"14\"></td></tr>").find("td").text(message).end());
			ShopOrder.updateLineCount();
			return;
		}
		for (var i = 0; i < items.length; i++) {
			var item = items[i] || {};
			var line = i + 1;
			var $row = $(
				'<tr class="so-edit-row">' +
					'<td class="so-col-sl"></td>' +
					'<td><input class="so-entry so-sku-entry" disabled></td>' +
					'<td><input class="so-entry so-qty-entry" inputmode="decimal" disabled></td>' +
					'<td><input class="so-entry so-qty-entry" inputmode="decimal" disabled></td>' +
					'<td><input class="so-entry so-qty-entry" inputmode="decimal"></td>' +
					'<td><input class="so-entry"></td>' +
					'<td><div class="so-date-control"><input class="so-entry so-date-entry date date-picker" type="text" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" autocomplete="off"><button type="button" class="so-calendar"><i class="ri-calendar-2-line"></i></button></div></td>' +
					'<td><input class="so-entry so-qty-entry"></td>' +
					'<td class="so-col-return-doc"><input class="so-entry" placeholder="Enter number"></td>' +
					'<td class="so-col-return-date"><div class="so-date-control"><input class="so-entry so-date-entry date date-picker" type="text" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" autocomplete="off"><button type="button" class="so-calendar"><i class="ri-calendar-2-line"></i></button></div></td>' +
					'<td class="so-col-return-eway"><input class="so-entry" placeholder="Enter number"></td>' +
					'<td class="so-col-return-qty"><input class="so-entry so-qty-entry" inputmode="decimal"></td>' +
					'<td class="so-col-return-date"><div class="so-date-control"><input class="so-entry so-date-entry date date-picker" type="text" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" autocomplete="off"><button type="button" class="so-calendar"><i class="ri-calendar-2-line"></i></button></div></td>' +
					ShopOrder.documentCellHtml("order_" + line) +
				'</tr>'
			);
			var values = [
				item.childSku, item.requiredQuantity, item.issueQuantity, item.consumedQuantity,
				item.dcNumber, item.dcDate, item.indicator
			];
			var inputLabels = [
				"child SKU", "required quantity", "issue quantity", "consumed quantity",
				"3M DC number", "3M DC date", "indicator", "return delivery challan number",
				"return DC date", "return e-way bill number", "return quantity", "e-way bill date"
			];
			$row.find(".so-col-sl").text(line);
			$row.find(".so-entry").each(function (index) {
				if (index < values.length) {
					$(this).val(values[index] == null ? "" : values[index]);
				} else if (index === 10) {
					$(this).val("0");
				}
				$(this).attr("aria-label", "Item " + line + " " + inputLabels[index]);
			});
			$row.find(".so-calendar").each(function (index) {
				$(this).attr("aria-label", "Choose item " + line + " date " + (index + 1));
			});
			$tbody.append($row);
			ShopOrder.ensureDatePickers($row);
		}
		ShopOrder.updateLineCount();
	}
};
