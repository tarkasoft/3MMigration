/**
 * CIR customer requests, using the Rebate module's customer context,
 * request handling, and shared DataTable conventions.
 */
Cir = {
	ROOT: "m_cir_requests_table_root",
	_api: "api/customer/cir",
	_customer: { custCode: "", loginId: "" },
	_lookups: {},
	_loading: false,
	_requestsLoaded: false,
	_requestsViewLoaded: false,
	_dashboardViewLoaded: false,
	_pendingViewId: 0,
	_newRequestLoadSeq: 0,
	_requestsViewLoadSeq: 0,
	PAGE_SIZES: [50, 100, 150, 200],
	PAGE_SIZE: 50,

	Load: function () {
		Cir._hideAllCirLoaders();
		Cir._customer = Cir._procedureContext();
		Cir._loading = false;
		Cir._requestsLoaded = false;
		Cir._requestsViewLoaded = false;
		Cir._dashboardViewLoaded = false;
		Cir._newRequestLoadSeq += 1;
		Cir._requestsViewLoadSeq += 1;
		var $home = Cir._$home();
		$home.find("#cir_dashboard_tab").off("click.cir").on("click.cir", function () {
			Cir._activateTab("dashboard");
		});
		$home.find("#cir_new_request_tab").off("click.cir").on("click.cir", function () {
			Cir._activateTab("new");
		});
		$home.find("#cir_my_requests_tab").off("click.cir").on("click.cir", function () {
			Cir._activateTab("requests");
		});
		$(document).off("click.cirDownload").on("click.cirDownload", "a.cir-doc-download", function (event) {
			event.preventDefault();
			Cir._downloadDocument(this);
		});
		$(document).off("hidden.bs.modal.cirDetail", "#cir_detail_modal")
			.on("hidden.bs.modal.cirDetail", "#cir_detail_modal", function () {
				/* Only the active CIR shell (multi-tab safe). */
				if (!Cir._$home().has(this).length && !Cir._$home().is(this)) {
					return;
				}
				Cir._abortDocumentDownload();
				Cir._hideLoader("cir_detail_content");
			});
		Cir._bindModuleTabRefresh();
		Cir._activateTab("dashboard");
	},

	/** Active CIR shell inside the current InpcTabs pane (avoids multi-tab ID collisions). */
	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#m_cir_home") : $();
				if ($inPane && $inPane.length) return $inPane.first();
			}
		} catch (ignore) {
			// Fall through to document lookup.
		}
		var $visible = $("#m_cir_home").filter(":visible");
		if ($visible.length) return $visible.first();
		return $("#m_cir_home").first();
	},

	_$: function (selector) {
		var $home = Cir._$home();
		if (!$home.length) return $(selector);
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	_hostId: function () {
		var id = Cir._$home().attr("id");
		return id || "m_cir_home";
	},

	_panelEmpty: function ($panel) {
		if (!$panel || !$panel.length) return true;
		return !$.trim(String($panel.html() || "")).length;
	},

	_bindModuleTabRefresh: function () {
		if (Cir._moduleTabRefreshBound) return;
		Cir._moduleTabRefreshBound = true;
		$(document).on("click.cirModuleTab", "#inpc_module_tab_bar .inpc-tab-link", function () {
			var key = String($(this).attr("data-tab-key") || "");
			if (!/cir/i.test(key)) return;
			Cir._hideAllCirLoaders();
			setTimeout(function () {
				Cir._hideAllCirLoaders();
				if (!Cir._$home().length) return;
				var $dash = Cir._$("#cir_dashboard_panel");
				if (!$dash.find("#m_cir_dashboard").length) {
					Cir._dashboardViewLoaded = false;
					Cir._requestsLoaded = false;
					Cir._requestsViewLoaded = false;
					Cir._activateTab("dashboard");
				}
			}, 0);
		});
	},

	_activateTab: function (tab) {
		var which = tab === "new" || tab === "requests" ? tab : "dashboard";
		var $home = Cir._$home();
		$home.find("#cir_dashboard_tab").attr("aria-selected", which === "dashboard" ? "true" : "false");
		$home.find("#cir_new_request_tab").attr("aria-selected", which === "new" ? "true" : "false");
		$home.find("#cir_my_requests_tab").attr("aria-selected", which === "requests" ? "true" : "false");
		$home.find("#cir_dashboard_panel").toggleClass("d-none", which !== "dashboard");
		$home.find("#cir_new_request_panel").toggleClass("d-none", which !== "new");
		$home.find("#cir_my_requests_panel").toggleClass("d-none", which !== "requests");

		if (which === "dashboard") {
			var $dash = $home.find("#cir_dashboard_panel");
			if ($dash.find("#m_cir_dashboard").length) {
				Cir._dashboardViewLoaded = true;
				return;
			}
			if (window.CirDashboard && typeof CirDashboard.Load === "function") {
				CirDashboard.Load();
				Cir._dashboardViewLoaded = true;
			} else {
				$dash.html('<div class="alert alert-danger m-3">Dashboard script is not loaded.</div>');
			}
			return;
		}

		if (which === "new") {
			var $newPanel = $home.find("#cir_new_request_panel");
			if (!$newPanel.find("#m_cir_new_request").length) {
				Cir._loadNewRequest();
			}
			return;
		}

		var $reqPanel = $home.find("#cir_my_requests_panel");
		if (Cir._requestsViewLoaded) {
			if (Cir._panelEmpty($reqPanel) || !$reqPanel.find("#" + Cir.ROOT).length) {
				Cir._requestsViewLoaded = false;
			} else {
				if (!Cir._requestsLoaded) Cir.LoadRequests();
				else Cir._openPendingView();
				return;
			}
		}
		var viewSeq = ++Cir._requestsViewLoadSeq;
		Cir._showLoader("Loading your CIR requests...", Cir._hostId());
		$reqPanel.load(
			(window.$app_url || "") + "html_files/CIR/cir_requests.html?r=" + Date.now(),
			function (_response, status) {
				if (viewSeq !== Cir._requestsViewLoadSeq) return;
				var $panel = Cir._$("#cir_my_requests_panel");
				Cir._hideLoader(Cir._hostId());
				if (status !== "success") {
					$panel.html(
						'<div class="alert alert-danger">Unable to load CIR My Requests.</div>');
					return;
				}
				Cir._requestsViewLoaded = true;
				Cir._initTable();
				Cir._showPanelLoader($panel, "Loading your CIR requests...");
				Cir.LoadRequests();
			});
	},

	_openPendingView: function () {
		var requestId = Number(Cir._pendingViewId || 0);
		if (!Number.isSafeInteger(requestId) || requestId <= 0) return;
		Cir._pendingViewId = 0;
		Cir.ViewRequest(requestId);
	},

	_loadNewRequest: function () {
		var loadSeq = ++Cir._newRequestLoadSeq;
		var $panel = Cir._$("#cir_new_request_panel");
		if (!$panel.length) return;
		Cir._showLoader("Loading customer details...", Cir._hostId());
		$panel.load(
			(window.$app_url || "") + "html_files/CIR/cir_new_request.html?r=" + Date.now(),
			function (_response, status) {
				if (loadSeq !== Cir._newRequestLoadSeq) return;
				$panel = Cir._$("#cir_new_request_panel");
				Cir._hideLoader(Cir._hostId());
				if (status !== "success" || !$panel.length) {
					Cir._newRequestMessage("Unable to load the CIR New Request form.");
					return;
				}
				Cir._showPanelLoader($panel, "Loading customer details...");
				Cir._request("/new-request/lookups", Cir._customer, function (data) {
					if (loadSeq !== Cir._newRequestLoadSeq) return;
					$panel = Cir._$("#cir_new_request_panel");
					Cir._assignNewRequestLookups(data || {});
					Cir._hidePanelLoader($panel);
				}, function (message) {
					if (loadSeq !== Cir._newRequestLoadSeq) return;
					$panel = Cir._$("#cir_new_request_panel");
					Cir._hidePanelLoader($panel);
					Cir._newRequestMessage(message);
				});
			});
	},

	_assignNewRequestLookups: function (data) {
			Cir._lookups = {
				causes: Array.isArray(data.g_cir_cause_details) ? data.g_cir_cause_details : [],
				stockCategories: Array.isArray(data.g_cir_stock_category_details)
					? data.g_cir_stock_category_details : []
			};
			var customers = Array.isArray(data.g_customer_details) ? data.g_customer_details : [];
			var customer = customers.length ? customers[0] : {};
			Cir._$("#cir_customer").val(customer.value || "");
			Cir._$("#cir_customer_type").val(customer.CTYPE || "");
			Cir._$("#cir_contact").val(customer.customer_contact_name || "");
			Cir._$("#cir_phone").val(customer.CPHON || "");
			Cir._$("#cir_email").val(customer.email || "");
			Cir._$("#cir_customer_region").val(customer.customer_region || "");
			Cir._$("#cir_requester_warehouse").val(data.requester_wharehouse || "");

			Cir._populateLookupSelect("#cir_complaint_type", data.g_cir_reason_details,
				"Select Type", "internal_code", "reason_code", function (option, row) {
					option.attr("data-ticket-type", row.ticket_type || "")
						.attr("data-code", row.code || "")
						.attr("data-oop-days", row.oop_days || "");
				});
			Cir._populateLookupSelect("#cir_customer_reason", data.g_customer_reason_details,
				"Select Reason", "reason_int_code", "reason_code", function (option, row) {
					option.attr("data-category", row.category || "")
						.attr("data-subcategory", row.sub_categoty || "");
				});
			Cir._populateLookupSelect("#cir_stock_category", Cir._lookups.stockCategories,
				"Select Category", "internal_code", "stock_category", function (option, row) {
					option.attr("data-division", row.div_code || "");
				});
			Cir._bindNewRequestLookupEvents();
			Cir._bindInvoiceAutocomplete();
			Cir._bindLoadInvoiceButton();
			Cir._applyCustomerReason();
			Cir._showClosedDayNotice(data.g_cir_closed_days);
	},

	_populateLookupSelect: function (selector, rows, placeholder, valueField, labelField, setAttributes, divisionCode) {
			var $select = Cir._$(selector).empty().append($("<option>").val("").text(placeholder));
			if (!Array.isArray(rows)) return;
			rows.forEach(function (row) {
				if (divisionCode && row.div_code && String(row.div_code) !== divisionCode) return;
				var $option = $("<option>").val(row[valueField] == null ? "" : String(row[valueField]))
					.text(row[labelField] == null ? "" : String(row[labelField]));
				if (setAttributes) setAttributes($option, row);
				$select.append($option);
			});
	},

	_bindNewRequestLookupEvents: function () {
			Cir._$("#cir_complaint_type").off("change.cir").on("change.cir", function () {
				Cir._applyComplaintType();
			});
			Cir._$("#cir_cause_code").off("change.cir").on("change.cir", function () {
				Cir._applyCauseDetails();
			});
			Cir._$("#cir_customer_reason").off("change.cir").on("change.cir", function () {
				Cir._applyCustomerReason();
			});
			Cir._$("input[name=cir_material_return]")
				.off("change.cir").on("change.cir", function () {
					Cir._applyCirType();
				});
			Cir._$("input[name=cir_amount_type]")
				.off("change.cir").on("change.cir", function () {
					Cir._onCirTypeRadioChange();
				});
			Cir._$("input[name=cir_sent_sample]").off("change.cir").on("change.cir", function () {
				Cir._applySampleFields();
			});
	},

	_bindInvoiceAutocomplete: function () {
			var $invoice = Cir._$("#cir_invoice_no");
			if (!$invoice.length || typeof $invoice.autocomplete !== "function") return;
			try {
				$invoice.autocomplete("destroy");
			} catch (ignore) {
				// The autocomplete may not have been initialized yet.
			}
			$invoice.off("input.cirInvoice").on("input.cirInvoice", function () {
				var selectedInvoice = String($invoice.data("cirSelectedInvoice") || "");
				var cached = $invoice.data("cirInvoiceResults");
				var term = $.trim(String($invoice.val() || ""));
				var contextKey = Cir._invoiceAutocompleteContextKey();
				if (cached && (cached.term !== term || cached.contextKey !== contextKey)) {
					$invoice.removeData("cirInvoiceResults");
				}
				if (selectedInvoice && selectedInvoice !== String($invoice.val() || "")) {
					$invoice.removeData("cirSelectedInvoice");
					Cir._clearInvoiceSelection();
				}
				Cir._$("#cir_invoice_error").addClass("d-none").text("");
			});
			// Re-open cached suggestions only. A second network search here races the
			// in-flight request; abort used to call response([]) and close the menu.
			$invoice.off("focus.cirInvoice click.cirInvoice").on("focus.cirInvoice click.cirInvoice", function () {
				var term = $.trim(String($invoice.val() || ""));
				if (term.length < 1) return;
				var contextKey = Cir._invoiceAutocompleteContextKey();
				var cached = $invoice.data("cirInvoiceResults");
				if (!cached || cached.term !== term || cached.contextKey !== contextKey) return;
				if ($invoice.autocomplete("widget").is(":visible")) return;
				Cir._scheduleInvoiceSuggestions($invoice, term, contextKey);
			});
			$invoice.autocomplete({
				minLength: 1,
				delay: 250,
				appendTo: "#m_cir_new_request",
				position: { my: "left top", at: "left bottom", collision: "flip" },
				open: function () {
					$(this).autocomplete("widget").css({ zIndex: 1090, position: "absolute" });
				},
				source: function (request, response) {
					var term = $.trim(String(request.term || ""));
					var contextKey = Cir._invoiceAutocompleteContextKey();
					var requestId = Number($invoice.data("cirInvoiceRequestId") || 0) + 1;
					$invoice.data("cirInvoiceRequestId", requestId);
					var cached = $invoice.data("cirInvoiceResults");
					if (cached && cached.term === term && cached.contextKey === contextKey) {
						response(cached.rows);
						return;
					}
					var previous = $invoice.data("cirInvoiceXhr");
					if (previous && previous.abort) previous.abort();
					Cir._$("#cir_invoice_ac_spinner").removeClass("d-none");
					var xhr = $.ajax({
						url: (window.$app_url || "") + Cir._api + "/new-request/invoices",
						method: "GET",
						dataType: "json",
						data: $.extend({}, Cir._customer, { phrase: request.term }),
						xhrFields: { withCredentials: true },
						success: function (json) {
							if (Number($invoice.data("cirInvoiceRequestId") || 0) !== requestId) {
								return;
							}
							if (Cir._session(json)) {
								response([]);
								return;
							}
							var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
							if (!json || (code != null && Number(code) !== 0)) {
								Cir._$("#cir_invoice_error").text(
									(json && (json.message || json.status)) || "Unable to search invoices.")
									.removeClass("d-none");
								response([]);
								return;
							}
							var rows = json.data && Array.isArray(json.data) ? json.data : [];
							if (!rows.length) {
								Cir._$("#cir_invoice_error").text("No eligible invoices found.")
									.removeClass("d-none");
							}
							var suggestions = $.map(rows, function (row) {
								return {
									label: String(row.value || ""),
									value: String(row.value || ""),
									inv_date: row.inv_date || "",
									warehouse: row.warehouse || "",
									group_code: row.group_code || "",
									division: row.division || "",
									out_of_policy: row.out_of_policy || "No",
									nine_mth_tax_applicable: row.nine_mth_tax_applicable || "No",
									inv_oop_days: row.inv_oop_days == null ? "" : row.inv_oop_days
								};
							});
							if ($.trim(String($invoice.val() || "")) === term
								&& Cir._invoiceAutocompleteContextKey() === contextKey) {
								$invoice.data("cirInvoiceResults", {
									term: term,
									contextKey: contextKey,
									rows: suggestions
								});
							}
							response(suggestions);
						},
						error: function (xhr, status) {
							if (status === "abort"
								|| Number($invoice.data("cirInvoiceRequestId") || 0) !== requestId) {
								return;
							}
							if (xhr.status === 401 && window.inpcHandleSessionExpired) {
								window.inpcHandleSessionExpired("Please login once again");
							} else {
								Cir._$("#cir_invoice_error").text("Unable to search invoices.")
									.removeClass("d-none");
							}
							response([]);
						},
						complete: function (completedXhr) {
							if ($invoice.data("cirInvoiceXhr") === completedXhr) {
								$invoice.removeData("cirInvoiceXhr");
								Cir._$("#cir_invoice_ac_spinner").addClass("d-none");
							}
						}
					});
					$invoice.data("cirInvoiceXhr", xhr);
				},
				select: function (_event, ui) {
					var item = ui && ui.item ? ui.item : {};
					$invoice.removeData("cirInvoiceResults");
					$invoice.val(item.value || "");
					$invoice.data("cirSelectedInvoice", String(item.value || ""));
					Cir._$("#cir_invoice_date").val(item.inv_date || "");
					Cir._$("#cir_invoice_group").val(item.group_code || "");
					Cir._$("#cir_invoice_division").val(item.division || "");
					Cir._$("#cir_invoice_warehouse").val(item.warehouse || "");
					Cir._$("#cir_inv_out_of_policy").val(item.out_of_policy || "No");
					Cir._$("#cir_inv_nine_month_tax").val(item.nine_mth_tax_applicable || "No");
					Cir._$("#cir_inv_oop_days").val(item.inv_oop_days || "");
					Cir._$("#cir_invoice_error").addClass("d-none").text("");
					Cir._filterStockCategories(item.division || "");
					Cir._toggleOutOfPolicy();
					Cir._applyCfrFields();
					return false;
				}
			});
	},

	_scheduleInvoiceSuggestions: function ($invoice, term, contextKey) {
			var previousTimer = $invoice.data("cirInvoiceShowTimer");
			if (previousTimer) window.clearTimeout(previousTimer);
			var timer = window.setTimeout(function () {
				if (document.activeElement !== $invoice[0]
					|| $.trim(String($invoice.val() || "")) !== term
					|| Cir._invoiceAutocompleteContextKey() !== contextKey
					|| !$invoice.is(":visible")) {
					return;
				}
				var cached = $invoice.data("cirInvoiceResults");
				if (!cached || cached.term !== term || cached.contextKey !== contextKey) return;
				$invoice.autocomplete("search", term);
			}, 0);
			$invoice.data("cirInvoiceShowTimer", timer);
	},

	_invoiceAutocompleteContextKey: function () {
			var customer = Cir._customer || {};
			return JSON.stringify(Object.keys(customer).sort().map(function (key) {
				return [key, String(customer[key] == null ? "" : customer[key])];
			}));
	},

	_clearInvoiceSelection: function () {
			Cir._$("#cir_invoice_date,#cir_invoice_group,#cir_invoice_division,#cir_invoice_warehouse").val("");
			Cir._$("#cir_inv_out_of_policy,#cir_inv_nine_month_tax,#cir_inv_oop_days").val("");
			Cir._filterStockCategories("");
				Cir._invoiceLines = [];
			Cir._$("#cir_select_all_lines").prop("checked", false).prop("indeterminate", false);
			Cir._$("#cir_invoice_lines_body").empty().append(
				'<tr class="cir-empty-row"><td colspan="21" class="text-center text-muted">Load an invoice to display eligible invoice lines.</td></tr>');
			Cir._updateTotalAmount();
			Cir._updateInvoiceTableColumns();
			Cir._applyCfrFields();
	},

	_invoiceGroupName: function () {
			var group = String(Cir._$("#cir_invoice_group").val() || "").trim();
			var split = group.indexOf("-");
			return split < 0 ? group : group.substring(split + 1).trim();
	},

	_filterStockCategories: function (division) {
			var divisionCode = String(division || "").split("-")[0].trim();
			var $select = Cir._$("#cir_stock_category");
			var selected = String($select.val() || "");
			Cir._populateLookupSelect("#cir_stock_category", Cir._lookups.stockCategories,
				"Select Category", "internal_code", "stock_category", function (option, row) {
					option.attr("data-division", row.div_code || "");
				}, divisionCode);
			if (selected && $select.find("option").filter(function () {
				return this.value === selected;
			}).length) {
				$select.val(selected);
			}
	},

	// ---- Load Invoice: fetch billed lines for the selected invoice and let the user enter return quantities. ----

	_bindLoadInvoiceButton: function () {
			Cir._$("#cir_load_invoice_btn").off("click.cir").on("click.cir", Cir._loadInvoiceLines);
			Cir._$("#cir_submit_btn").off("click.cir").on("click.cir", Cir._submitRequest);
			Cir._$("#cir_cancel_btn").off("click.cir").on("click.cir", Cir._cancelNewRequest);
			Cir._$("#cir_select_all_lines").off("change.cir").on("change.cir", function () {
				Cir._selectAllInvoiceLines(this.checked);
			});
			Cir._bindContentTabs();
	},

	_cancelNewRequest: function () {
			Cir._invoiceLines = [];
			Cir._documentCatalog = [];
			Cir._documentFiles = {};
			Cir._documentRemoved = {};
			Cir._clearDocumentPreviews();
			Cir._activeCirType = null;
			Cir._activateTab("new");
			Cir._loadNewRequest();
	},

	_bindContentTabs: function () {
			Cir._$("#m_cir_new_request .cir-content-tabs").off("click.cirTab").on("click.cirTab", "[data-cir-tab]", function () {
				Cir._showContentTab($(this).attr("data-cir-tab"));
			});
	},

	_showContentTab: function (tabId) {
			var target = tabId === "attachments" ? "attachments" : "items";
			Cir._$("#m_cir_new_request .cir-content-tabs [data-cir-tab]").each(function () {
				var active = $(this).attr("data-cir-tab") === target;
				$(this).toggleClass("active", active).attr("aria-selected", active ? "true" : "false");
			});
			Cir._$("#cir_tab_items").toggleClass("active", target === "items");
			Cir._$("#cir_tab_attachments").toggleClass("active", target === "attachments");
			if (target === "items") {
				Cir._updateInvoiceTableColumns();
			}
	},

	_selectAllInvoiceLines: function (checked) {
			if (Cir._selectedCirType() === "Flat") {
				Cir._applyFlatLineSelection();
				return;
			}
			var lockRows = checked && String(Cir._$("#cir_complaint_type option:selected").attr("data-code") || "") === "INVOICE_CANCELLATION";
			Cir._$("#cir_invoice_lines_body .cir-line-select").each(function () {
				$(this).prop("checked", checked).prop("disabled", lockRows);
				Cir._applyInvoiceLineSelection($(this).closest("tr"), checked);
			});
			Cir._applyCirType();
	},

	_syncSelectAll: function () {
			var $boxes = Cir._$("#cir_invoice_lines_body .cir-line-select");
			var checkedCount = $boxes.filter(":checked").length;
			Cir._$("#cir_select_all_lines")
				.prop("checked", $boxes.length > 0 && checkedCount === $boxes.length)
				.prop("indeterminate", checkedCount > 0 && checkedCount < $boxes.length);
	},

	_documentCatalog: [],
	_documentFiles: {},
	/** Doc type ids whose previously saved file was cleared in this session (edit). */
	_documentRemoved: {},
	_documentPreviewUrls: {},

	_isMandatoryDocument: function (isMandatory) {
			var value = String(isMandatory || "").trim().toLowerCase();
			return value === "document" || value === "yes";
	},

	_revokeDocumentPreview: function (docId) {
			var key = String(docId || "");
			var url = Cir._documentPreviewUrls[key];
			if (url) {
				try { URL.revokeObjectURL(url); } catch (_e) { /* ignore */ }
				delete Cir._documentPreviewUrls[key];
			}
	},

	_clearDocumentPreviews: function () {
			Object.keys(Cir._documentPreviewUrls || {}).forEach(function (key) {
				Cir._revokeDocumentPreview(key);
			});
	},

	_loadRequiredDocuments: function () {
			var reasonCode = String(Cir._$("#cir_complaint_type").val() || "").trim();
			var causeCode = String(Cir._$("#cir_cause_code").val() || "").trim();
			if (!reasonCode || !causeCode) {
				Cir._documentCatalog = [];
				Cir._documentFiles = {};
				Cir._documentRemoved = {};
				Cir._clearDocumentPreviews();
				Cir._renderDocumentCatalog();
				return;
			}
			var params = $.extend({}, Cir._customer || {}, {
				reasonCode: reasonCode,
				causeCode: causeCode,
				editRequestId: String(Cir._$("#cir_edit_internal_code").val() || "0")
			});
			Cir._request("/new-request/required-documents", params, function (data) {
				var previous = Cir._documentFiles || {};
				var nextFiles = {};
				Cir._documentCatalog = Array.isArray(data && data.documents) ? data.documents : [];
				Cir._documentCatalog.forEach(function (row) {
					var id = String(row.document_type_id || "");
					if (id && previous[id]) nextFiles[id] = previous[id];
				});
				Cir._documentFiles = nextFiles;
				Cir._renderDocumentCatalog();
			}, function () {
				Cir._documentCatalog = [];
				Cir._documentFiles = {};
				Cir._documentRemoved = {};
				Cir._clearDocumentPreviews();
				Cir._renderDocumentCatalog();
			});
	},

	_renderDocumentCatalog: function () {
			var rows = Cir._documentCatalog || [];
			var $body = Cir._$("#cir_documents_body");
			if (!$body.length) return;
			if (!rows.length) {
				$body.html('<tr><td colspan="2" class="text-center text-muted">Select Customer Reason / Cause to load required documents.</td></tr>');
				return;
			}
			var html = "";
			rows.forEach(function (row) {
				var id = String(row.document_type_id || "");
				var name = String(row.document || "");
				var mandatory = Cir._isMandatoryDocument(row.is_mandatory);
				var removed = !!(Cir._documentRemoved && Cir._documentRemoved[id]);
				var uploadedPath = removed ? "" : String(row.uploaded_path || "").trim();
				var uploadedName = removed ? "" : String(row.uploaded_name || "").trim();
				var uploadedDocId = removed ? 0 : (Number(row.uploaded_doc_id) || 0);
				var extension = String(row.extension || "All");
				var selected = Cir._documentFiles[id];
				var hasFile = !!(selected || (uploadedPath && uploadedName));
				html += '<tr class="cir-doc-row" data-doc-id="' + Cir._escape(id) + '" data-mandatory="' +
					(mandatory ? "Yes" : "No") + '" data-extension="' + Cir._escape(extension) +
					'" data-uploaded="' + (uploadedPath ? "Yes" : "No") +
					'" data-uploaded-doc-id="' + Cir._escape(String(uploadedDocId || "")) + '">';
				html += '<td class="cir-doc-name">' + (mandatory ? '<span class="cir-doc-required">*</span>' : "") +
					Cir._escape(name);
				if (selected) {
					html += '<span class="cir-doc-file-meta">Uploaded file Size: ' +
						Cir._escape((selected.size / 1024 / 1024).toFixed(2)) + " MB<br>File Name: " +
						Cir._escape(selected.name) + "</span>";
				} else if (uploadedName) {
					html += '<span class="cir-doc-uploaded">Previously uploaded: ' + Cir._escape(uploadedName) + "</span>";
				}
				html += "</td>";
				html += '<td><div class="cir-doc-file-cell">';
				html += '<input type="file" class="cir-doc-file" data-doc-id="' +
					Cir._escape(id) + '" tabindex="-1" aria-hidden="true">';
				html += '<button type="button" class="cir-doc-browse" data-doc-id="' +
					Cir._escape(id) + '" title="Browse file">'
					+ '<i class="ri-folder-open-line" aria-hidden="true"></i> Browse File</button>';
				if (hasFile) {
					html += '<div class="cir-doc-actions" role="group" aria-label="Attachment actions">';
					html += '<button type="button" class="btn btn-sm btn-outline-primary cir-doc-view" data-doc-id="' +
						Cir._escape(id) + '" title="View document" aria-label="View document">' +
						'<i class="ri-eye-line" aria-hidden="true"></i></button>';
					html += '<button type="button" class="btn btn-sm btn-outline-danger cir-doc-remove" data-doc-id="' +
						Cir._escape(id) + '" title="Remove document" aria-label="Remove document">' +
						'<i class="ri-delete-bin-line" aria-hidden="true"></i></button>';
					html += "</div>";
				}
				html += "</div></td>";
				html += "</tr>";
			});
			$body.html(html)
				.off("change.cirDoc").on("change.cirDoc", ".cir-doc-file", function () {
					Cir._onDocumentFileChange(this);
				})
				.off("click.cirDocBrowse").on("click.cirDocBrowse", ".cir-doc-browse", function (event) {
					event.preventDefault();
					var id = String($(this).attr("data-doc-id") || "");
					var input = Cir._$("#cir_documents_body .cir-doc-file").filter(function () {
						return String($(this).attr("data-doc-id") || "") === id;
					}).get(0);
					if (input) {
						input.click();
					}
				})
				.off("click.cirDocView").on("click.cirDocView", ".cir-doc-view", function (event) {
					event.preventDefault();
					Cir._viewAttachmentDocument(String($(this).attr("data-doc-id") || ""));
				})
				.off("click.cirDocRemove").on("click.cirDocRemove", ".cir-doc-remove", function (event) {
					event.preventDefault();
					Cir._removeAttachmentDocument(String($(this).attr("data-doc-id") || ""));
				});
	},

	_viewAttachmentDocument: function (docId) {
			var id = String(docId || "");
			if (!id) return;
			// Client-side Browse only: preview from in-memory File blob.
			var file = Cir._documentFiles[id];
			if (file) {
				Cir._revokeDocumentPreview(id);
				var objectUrl = URL.createObjectURL(file);
				Cir._documentPreviewUrls[id] = objectUrl;
				window.open(objectUrl, "_blank", "noopener");
				return;
			}
			// Edit mode / already on server: open download URL directly (no blob).
			var $row = Cir._$("#cir_documents_body tr.cir-doc-row").filter(function () {
				return String($(this).attr("data-doc-id") || "") === id;
			});
			var uploadedDocId = Number($row.attr("data-uploaded-doc-id") || 0) || 0;
			var requestId = Number(Cir._$("#cir_edit_internal_code").val() || 0) || 0;
			if (!(requestId > 0) || !(uploadedDocId > 0)) {
				Cir._alert("No document is available to view.");
				return;
			}
			var url = (window.$app_url || "") + Cir._api + "/requests/" +
				encodeURIComponent(String(requestId)) + "/documents/" +
				encodeURIComponent(String(uploadedDocId)) + "/download?" +
				$.param(Cir._customer || {});
			window.open(url, "_blank", "noopener");
	},

	_removeAttachmentDocument: function (docId) {
			var id = String(docId || "");
			if (!id) return;
			var doRemove = function () {
				Cir._revokeDocumentPreview(id);
				delete Cir._documentFiles[id];
				Cir._documentRemoved = Cir._documentRemoved || {};
				Cir._documentRemoved[id] = true;
				Cir._renderDocumentCatalog();
			};
			if (window.Swal && typeof Swal.fire === "function") {
				Swal.fire({
					title: "Delete this document?",
					text: "The selected file will be removed from this request.",
					icon: "warning",
					showCancelButton: true,
					confirmButtonText: "Yes, delete",
					cancelButtonText: "Cancel",
					confirmButtonColor: "#d33",
					cancelButtonColor: "#94a3b8",
					reverseButtons: true,
					focusCancel: true
				}).then(function (result) {
					if (result && result.isConfirmed) {
						doRemove();
					}
				});
				if (window.jQuery) {
					$(".swal2-container").css("z-index", "22222229999");
				}
				return;
			}
			if (window.confirm("Delete this document?")) {
				doRemove();
			}
	},

	_onDocumentFileChange: function (input) {
			var $input = $(input);
			var id = String($input.attr("data-doc-id") || "");
			var file = input.files && input.files[0] ? input.files[0] : null;
			var $row = $input.closest("tr");
			if (!id) return;
			if (!file) {
				Cir._revokeDocumentPreview(id);
				delete Cir._documentFiles[id];
				Cir._renderDocumentCatalog();
				return;
			}
			if (file.size > 5 * 1024 * 1024) {
				Cir._alert("Attachment size should be less than 5MB");
				input.value = "";
				Cir._revokeDocumentPreview(id);
				delete Cir._documentFiles[id];
				Cir._renderDocumentCatalog();
				return;
			}
			var allowed = String($row.attr("data-extension") || "All").toLowerCase();
			var parts = allowed.split("|").map(function (part) { return $.trim(part); }).filter(Boolean);
			var ext = String(file.name || "").split(".").pop().toLowerCase();
			if (parts.length && parts.indexOf("all") < 0 && parts.indexOf(ext) < 0) {
				Cir._alert("You can Upload " + allowed + " Formats only.");
				input.value = "";
				Cir._revokeDocumentPreview(id);
				delete Cir._documentFiles[id];
				Cir._renderDocumentCatalog();
				return;
			}
			Cir._revokeDocumentPreview(id);
			Cir._documentFiles[id] = file;
			if (Cir._documentRemoved) {
				delete Cir._documentRemoved[id];
			}
			Cir._renderDocumentCatalog();
	},

	_validateDocuments: function () {
			var missing = false;
			var totalMb = 0;
			Cir._$("#cir_documents_body .cir-doc-row").each(function () {
				var $row = $(this);
				var id = String($row.attr("data-doc-id") || "");
				var mandatory = String($row.attr("data-mandatory") || "") === "Yes";
				var uploadedEarlier = String($row.attr("data-uploaded") || "") === "Yes";
				var file = Cir._documentFiles[id];
				$row.find(".cir-doc-name").removeClass("cir-doc-missing");
				if (mandatory && !file && !uploadedEarlier) {
					$row.find(".cir-doc-name").addClass("cir-doc-missing");
					missing = true;
				}
				if (file) totalMb += file.size / 1024 / 1024;
			});
			if (missing) {
				Cir._showContentTab("attachments");
				return "Please Upload the Highlighted Documents";
			}
			if (totalMb > 5) {
				Cir._showContentTab("attachments");
				return "Total Attachment size should be less than 5MB";
			}
			return "";
	},

	_selectedDocuments: function () {
			var selected = [];
			(Cir._documentCatalog || []).forEach(function (row) {
				var id = String(row.document_type_id || "");
				var file = Cir._documentFiles[id];
				if (id && file) selected.push({ documentTypeId: id, file: file });
			});
			return selected;
	},

	_uploadDocuments: function (requestId, savedMessage) {
			var files = Cir._selectedDocuments();
			if (!requestId || !files.length) {
				Cir._$("#cir_submit_btn").prop("disabled", false);
				return;
			}
			var index = 0;
			var failed = [];
			var next = function () {
				if (index >= files.length) {
					Cir._hideLoader("m_cir_new_request");
					Cir._$("#cir_submit_btn").prop("disabled", false);
					var message = savedMessage;
					if (failed.length) {
						message += " These documents were not uploaded: " + failed.join("; ");
					} else {
						message += " All documents were uploaded.";
						Cir._documentFiles = {};
						Cir._documentRemoved = {};
						Cir._clearDocumentPreviews();
						Cir._renderDocumentCatalog();
					}
					Cir._$("#cir_submit_notice").text(message);
					Cir._alert(message);
					return;
				}
				var item = files[index];
				index += 1;
				Cir._$("#cir_submit_notice").text(savedMessage + " Uploading document " + index + " of " + files.length + ".");
				Cir._showLoader("Uploading document " + index + " of " + files.length + "...", "m_cir_new_request");
				var form = new FormData();
				form.append("file", item.file);
				form.append("documentTypeId", item.documentTypeId);
				var query = $.extend({}, Cir._customer || {}, { documentTypeId: item.documentTypeId });
				$.ajax({
					url: (window.$app_url || "") + Cir._api + "/requests/" +
						encodeURIComponent(String(requestId)) + "/documents?" + $.param(query),
					method: "POST",
					data: form,
					processData: false,
					contentType: false,
					dataType: "json",
					xhrFields: { withCredentials: true },
					success: function (json) {
						if (Cir._session(json)) {
							failed.push(item.file.name);
							next();
							return;
						}
						var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
						if (!json || (code != null && Number(code) !== 0)) {
							failed.push(item.file.name + " (" + ((json && (json.message || json.status)) || "upload failed") + ")");
						} else {
							delete Cir._documentFiles[item.documentTypeId];
						}
						next();
					},
					error: function () {
						failed.push(item.file.name + " (upload failed)");
						next();
					}
				});
			};
			next();
	},

	_toggleOutOfPolicy: function () {
			var show = String(Cir._$("#cir_inv_out_of_policy").val() || "") === "Yes";
			Cir._$("#cir_oop_row").prop("hidden", !show);
			if (!show) Cir._$("#cir_oop_justification").val("");
	},

	_alert: function (message) {
			if (typeof ShowAlertMsg === "function") ShowAlertMsg(message);
			else alert(message);
	},

	_submitRequest: function () {
			var message = Cir._loadInvoiceMessage();
			if (!message && !String(Cir._$("#cir_contact").val() || "").trim()) message = "Customer Contact Name cannot be empty";
			var email = String(Cir._$("#cir_email").val() || "").trim();
			if (!message && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) message = "Please enter a valid customer email";
			if (!message && String(Cir._$("#cir_complaint_type option:selected").attr("data-code") || "") === "STOCK"
					&& !String(Cir._$("#cir_stock_category").val() || "").trim()) {
				message = "Please select Stock Category";
			}
			if (!message && String(Cir._$("#cir_complaint_type option:selected").attr("data-code") || "") === "PRDQUA"
					&& !Cir._$("input[name=cir_sent_sample]:checked").length) {
				message = "Please select Sent Samples";
			}
			if (!message && Cir._$("input[name=cir_sent_sample]:checked").val() === "Yes"
					&& !String(Cir._$("#cir_sample_docket_no").val() || "").trim()) {
				message = "Please enter Sent Docket No";
			}
			if (!message && String(Cir._$("#cir_complaint_type option:selected").attr("data-code") || "") === "PRDQUA"
					&& Cir._invoiceGroupName() === "HCBG"
					&& !String(Cir._$("#cir_cfr_number").val() || "").trim()) {
				message = "Please Enter CFR Number";
			}
			if (!message && String(Cir._$("input[name=cir_credit_debit]:checked").val() || "") === "Debit"
					&& Cir._$("input[name=cir_material_return]:checked").val() === "Yes") {
				message = "Material Return cannot be Yes for a Debit Note";
			}
			if (!message && String(Cir._$("input[name=cir_material_return]:checked").val() || "") === "Yes"
					&& Cir._selectedCirType() === "Flat") {
				message = "CIR Type should be Normal when Material Return is Yes";
			}
			if (!message && Cir._selectedCirType() === "Flat") {
				var $flatRow = Cir._$("#cir_invoice_lines_body tr[data-line-index]").filter(function () {
					return $(this).find(".cir-line-select").prop("checked");
				}).first();
				if (!$flatRow.length || Cir._toNumber($flatRow.find(".cir-line-flat-amount").val()) <= 0) {
					message = "Please Enter Flat Amount for the selected item";
				}
			}
			if (!message && !String(Cir._$("#cir_description").val() || "").trim()) message = "Please enter a description";
			if (!message && String(Cir._$("#cir_inv_out_of_policy").val() || "") === "Yes"
					&& String(Cir._$("#cir_oop_justification").val() || "").replace(/[^A-Za-z0-9]/g, "").length < 20) {
				message = "Out of policy justification should be at least 20 characters";
			}
			var lines = [];
			Cir._$("#cir_invoice_lines_body tr[data-line-index]").each(function () {
				var $row = $(this);
				if (!$row.find(".cir-line-select").prop("checked")) return;
				var line = Cir._invoiceLines[Number($row.attr("data-line-index"))] || {};
				lines.push({
					itemCode: line.item_code,
					lineNo: line.line_no,
					quantity: Cir._plainNumber($row.find(".cir-line-qty").val()),
					differencePrice: Cir._plainNumber($row.find(".cir-line-difference-price").val()),
					flatAmount: Cir._plainNumber($row.find(".cir-line-flat-amount").val()),
					cgstRate: Cir._plainNumber($row.find(".cir-line-cgst-rate").val()),
					sgstRate: Cir._plainNumber($row.find(".cir-line-sgst-rate").val()),
					igstRate: Cir._plainNumber($row.find(".cir-line-igst-rate").val())
				});
			});
			if (!message && !lines.length) message = "Select at least one invoice line";
			if (!message && Cir._toNumber(Cir._$("#cir_total_amount").val()) <= 0) {
				message = "Total Amount should be greater than zero";
			}
			if (!message) message = Cir._validateDocuments();
			if (message) {
				Cir._alert(message);
				return;
			}
			var editId = Number(Cir._$("#cir_edit_internal_code").val() || 0);
			var payload = {
				internalCode: editId > 0 ? editId : 0,
				contactName: Cir._$("#cir_contact").val(),
				email: email,
				phone: Cir._$("#cir_phone").val(),
				invoiceNo: Cir._$("#cir_invoice_no").val(),
				invoiceDate: Cir._$("#cir_invoice_date").val(),
				group: Cir._$("#cir_invoice_group").val(),
				division: Cir._$("#cir_invoice_division").val(),
				warehouse: Cir._$("#cir_invoice_warehouse").val(),
				customerReason: Cir._$("#cir_customer_reason").val(),
				complaintType: Cir._$("#cir_complaint_type").val(),
				causeCode: Cir._$("#cir_cause_code").val(),
				reasonCode: Cir._$("#cir_complaint_type option:selected").attr("data-code") || "",
				stockCategory: Cir._$("#cir_stock_category").val(),
				creditDebit: Cir._$("input[name=cir_credit_debit]:checked").val(),
				materialReturn: Cir._$("input[name=cir_material_return]:checked").val(),
				amountType: Cir._selectedCirType(),
				sentSample: Cir._$("input[name=cir_sent_sample]:checked").val() || "",
				sampleDocket: Cir._$("#cir_sample_docket_no").val(),
				cfrNumber: Cir._$("#cir_cfr_number").val(),
				customerType: Cir._$("#cir_customer_type").val(),
				outOfPolicy: Cir._$("#cir_inv_out_of_policy").val() || "No",
				oopJustification: Cir._$("#cir_oop_justification").val(),
				remarks: Cir._$("#cir_description").val(),
				lines: lines
			};
			Cir._$("#cir_submit_btn").prop("disabled", true);
			Cir._showLoader(editId > 0 ? "Resubmitting request..." : "Saving request...", "m_cir_new_request");
			$.ajax({
				url: (window.$app_url || "") + Cir._api + "/requests",
				method: "POST",
				contentType: "application/json",
				data: JSON.stringify(payload),
				dataType: "json",
				xhrFields: { withCredentials: true },
				success: function (json) {
					Cir._hideLoader("m_cir_new_request");
					Cir._$("#cir_submit_btn").prop("disabled", false);
					if (Cir._session(json)) return;
					var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
					if (!json || (code != null && Number(code) !== 0)) {
						Cir._alert((json && (json.message || json.status)) || "Unable to save the CIR request.");
						return;
					}
					var saved = json.data || {};
					var savedMessage = saved.message || "Request saved.";
					Cir._$("#cir_edit_internal_code").val("0");
					Cir._$("#cir_submit_btn").html('<i class="ri-send-plane-line me-1" aria-hidden="true"></i>Submit');
					Cir._$("#cir_submit_notice").text(savedMessage);
					var queries = Array.isArray(saved.queries) ? saved.queries.join("\n\n") : "";
					Cir._$("#cir_sql_preview").val(queries).prop("hidden", !queries);
					if (typeof ShowSuccessMsg === "function") ShowSuccessMsg(savedMessage);
					Cir._requestsLoaded = false;
					Cir._$("#cir_submit_btn").prop("disabled", Cir._selectedDocuments().length > 0);
					Cir._uploadDocuments(Number(saved.internal_code), savedMessage);
				},
				error: function (xhr) {
					Cir._hideLoader("m_cir_new_request");
					Cir._$("#cir_submit_btn").prop("disabled", false);
					if (xhr.status === 401 && window.inpcHandleSessionExpired) {
						window.inpcHandleSessionExpired("Please login once again");
						return;
					}
					Cir._alert("The CIR service could not save this request.");
				}
			});
	},

	_loadInvoiceMessage: function () {
			var customer = String((Cir._customer && Cir._customer.custCode) || Cir._$("#cir_customer").val() || "").trim();
			if (!customer) return "Customer cannot be empty";
			if (!String(Cir._$("#cir_invoice_no").val() || "").trim()) return "Please enter Invoice No.";
			if (!String(Cir._$("#cir_invoice_group").val() || "").trim()) {
				return "Invoice Group cannot be empty. Please reselect the invoice from the search list.";
			}
			if (!String(Cir._$("#cir_invoice_division").val() || "").trim()) {
				return "Invoice Division cannot be empty. Please reselect the invoice from the search list.";
			}
			if (!String(Cir._$("#cir_customer_reason").val() || "").trim() || !String(Cir._$("#cir_complaint_type").val() || "").trim()) {
				return "Please select Customer Reason";
			}
			if (!String(Cir._$("#cir_cause_code").val() || "").trim()) return "Please select Cause Code";
			if (!Cir._$("input[name=cir_credit_debit]:checked").length) return "Please select Credit/Debit";
			if (!Cir._$("input[name=cir_material_return]:checked").length) return "Please select Material Return";
			if (!Cir._$("input[name=cir_amount_type]:checked").length) return "Please select CIR Type";
			if (!String(Cir._$("#cir_invoice_date").val() || "").trim()) return "Invoice Date cannot be empty";
			return "";
	},

	_loadInvoiceLines: function () {
			var invoiceNo = String(Cir._$("#cir_invoice_no").val() || "").trim();
			var invoiceDate = String(Cir._$("#cir_invoice_date").val() || "").trim();
			var message = Cir._loadInvoiceMessage();
			Cir._$("#cir_invoice_error").addClass("d-none").text("");
			if (message) {
				if (typeof ShowAlertMsg === "function") ShowAlertMsg(message);
				else alert(message);
				return;
			}
			var $button = Cir._$("#cir_load_invoice_btn").prop("disabled", true);
			Cir._showLoader("Loading invoice lines...", "m_cir_new_request");
			var params = $.extend({}, Cir._customer, { invoiceNo: invoiceNo, invoiceDate: invoiceDate });
			Cir._request("/new-request/invoice-items", params, function (data) {
				Cir._hideLoader("m_cir_new_request");
				$button.prop("disabled", false);
				Cir._renderInvoiceLines((data && data.lines) || []);
			}, function (message) {
				Cir._hideLoader("m_cir_new_request");
				$button.prop("disabled", false);
				Cir._$("#cir_invoice_error").text(message || "Unable to load invoice lines.").removeClass("d-none");
			});
	},

	_causeTaxApplies: function () {
			var materialReturn = String(Cir._$("input[name=cir_material_return]:checked").val() || "");
			var flag = materialReturn === "No"
				? Cir._$("#cir_cause_tax_for_non_material_return").val()
				: Cir._$("#cir_cause_tax_for_material_return").val();
			return String(flag || "Yes") !== "No";
	},

	_selectedCirType: function () {
			return String(Cir._$("input[name=cir_amount_type]:checked").val() || "Normal");
	},

	_onCirTypeRadioChange: function () {
			var previous = Cir._activeCirType;
			var selectedType = Cir._selectedCirType();
			var hadLines = (Cir._invoiceLines || []).length > 0;
			Cir._applyCirType();
			// Like legacy: switching Normal <-> Flat after Load Invoice reloads lines.
			if (hadLines && previous && previous !== selectedType
					&& (selectedType === "Flat" || previous === "Flat")) {
				Cir._loadInvoiceLines();
			}
	},

	_applyCirType: function () {
			var causeAmountType = String(Cir._$("#cir_cause_amount_type").val() || "");
			var materialReturn = String(Cir._$("input[name=cir_material_return]:checked").val() || "");
			var amountType = materialReturn === "No"
				? String(Cir._$("#cir_cause_amount_type_non_material").val() || causeAmountType)
				: causeAmountType;
			var $row = Cir._$("#cir_amount_type_row");
			var $normal = Cir._$("input[name=cir_amount_type][value=Normal]");
			var $flat = Cir._$("input[name=cir_amount_type][value=Flat]");
			var normalized = amountType.toLowerCase();
			var isNormal = normalized === "normal";
			var isFlatAllowed = normalized === "flat";
			var isBoth = normalized === "both";
			var allowed = isNormal || isFlatAllowed || isBoth;
			var selectedTypeBeforeUpdate = Cir._activeCirType;
			$row.prop("hidden", !allowed);
			$normal.prop("disabled", !isNormal && !isBoth);
			$flat.prop("disabled", !isFlatAllowed && !isBoth);
			if (isFlatAllowed) $flat.prop("checked", true);
			else if (isNormal) $normal.prop("checked", true);
			else if (isBoth && !Cir._$("input[name=cir_amount_type]:checked").length) $normal.prop("checked", true);
			else if (!allowed) Cir._$("input[name=cir_amount_type]").prop("checked", false);
			var selectedType = Cir._selectedCirType();
			if (selectedTypeBeforeUpdate !== selectedType) {
				Cir._$("#cir_invoice_lines_body tr[data-line-index]").each(function () {
					var $line = $(this);
					var line = Cir._invoiceLines[Number($line.attr("data-line-index"))] || {};
					if (selectedType === "Flat") {
						$line.find(".cir-line-qty,.cir-line-difference-price,.cir-line-cgst-rate,.cir-line-sgst-rate,.cir-line-igst-rate").val("0");
					} else {
						["cgst", "sgst", "igst"].forEach(function (tax) {
							$line.find(".cir-line-" + tax + "-rate").val(Cir._plainNumber(line[tax + "_rate"]) + "%");
						});
					}
				});
			}
			Cir._activeCirType = selectedType;

			if (selectedType === "Flat") {
				Cir._applyFlatLineSelection();
			} else {
				Cir._$("#cir_select_all_lines").prop("disabled", false);
				Cir._$("#cir_invoice_lines_body tr[data-line-index]").each(function () {
					var $line = $(this);
					var $cb = $line.find(".cir-line-select");
					if ($cb.length) $cb.prop("disabled", false);
					var selected = $cb.prop("checked");
					var taxEditable = String(Cir._$("#cir_cause_edit_type").val() || "") === "Tax";
					$line.find(".cir-line-qty,.cir-line-difference-price").prop("disabled", !selected);
					$line.find(".cir-line-cgst-rate,.cir-line-sgst-rate,.cir-line-igst-rate")
						.prop("disabled", !selected || !taxEditable);
					$line.find(".cir-line-flat-amount").prop("disabled", true);
					Cir._recalculateLine($line);
				});
			}
			Cir._updateInvoiceTableColumns();
	},

	/**
	 * Flat Amount: only the first claimable line is selected; other lines are disabled.
	 * Only that first line's Flat Amount input is editable.
	 */
	_applyFlatLineSelection: function () {
			var $rows = Cir._$("#cir_invoice_lines_body tr[data-line-index]");
			if (!$rows.length) return;
			Cir._$("#cir_select_all_lines").prop("checked", false).prop("disabled", true);
			var firstSelectableFound = false;
			$rows.each(function () {
				var $line = $(this);
				var $cb = $line.find(".cir-line-select");
				if (!$cb.length) {
					Cir._recalculateLine($line);
					return;
				}
				var isFirst = !firstSelectableFound;
				if (isFirst) firstSelectableFound = true;
				$cb.prop("checked", isFirst).prop("disabled", true);
				Cir._applyInvoiceLineSelection($line, isFirst);
				$line.find(".cir-line-qty,.cir-line-difference-price,.cir-line-cgst-rate,.cir-line-sgst-rate,.cir-line-igst-rate")
					.prop("disabled", true)
					.val(isFirst ? "0" : "");
				if (isFirst) {
					$line.find(".cir-line-flat-amount").prop("disabled", false);
					if (!String($line.find(".cir-line-flat-amount").val() || "").trim()) {
						$line.find(".cir-line-flat-amount").val("0");
					}
				} else {
					$line.find(".cir-line-flat-amount").prop("disabled", true).val("0");
				}
				Cir._recalculateLine($line);
			});
			Cir._syncSelectAll();
	},

	_renderInvoiceLines: function (lines) {
			Cir._invoiceLines = Array.isArray(lines) ? lines : [];
			var $body = Cir._$("#cir_invoice_lines_body").empty();
			if (!Cir._invoiceLines.length) {
				$body.append('<tr class="cir-empty-row"><td colspan="21" class="text-center text-muted">'
					+ "No claimable lines were found on this invoice.</td></tr>");
				Cir._updateTotalAmount();
				Cir._updateInvoiceTableColumns();
				return;
			}
			Cir._invoiceLines.forEach(function (line, index) {
				var billQty = Cir._toNumber(line.bill_qty);
				var balanceQty = Cir._toNumber(line.balance_qty);
				var rate = Cir._toNumber(line.bill_rate);
				var billedTax = Cir._money(Cir._toNumber(line.sgst) + Cir._toNumber(line.cgst) + Cir._toNumber(line.igst));
				var claimed = balanceQty <= 0;
				var $row = $("<tr>").attr("data-line-index", index);
				if (claimed) {
					$row.append($("<td>").addClass("text-danger fw-bold cir-select-col").text("Claimed"));
				} else {
					$row.append($("<td>").addClass("cir-select-col").append($("<input>").attr({
						type: "checkbox",
						"aria-label": "Select " + String(line.item_code || "invoice item")
					}).addClass("cir-line-select")));
				}
				$row.append($("<td>").html("<strong>" + Cir._escapeHtml(line.item_code)
					+ (line.line_no == null || line.line_no === "" ? "" : " - " + Cir._escapeHtml(line.line_no))
					+ "</strong><br>" + '<span class="text-muted">' + Cir._escapeHtml(line.item_desc) + "</span>"));
				$row.append($("<td>").addClass("cir-num cir-col-qty cir-col-billed-qty").text(Cir._formatNumber(billQty)));
				$row.append($("<td>").addClass("cir-num cir-col-qty").text(Cir._formatNumber(balanceQty)));
				$row.append($("<td>").addClass("cir-num").text(Cir._formatNumber(rate)));
				$row.append($("<td>").addClass("cir-num").text(Cir._formatNumber(Cir._toNumber(line.bill_val))));
				$row.append($("<td>").addClass("cir-num cir-cgst-col").text(Cir._formatNumber(line.cgst_rate) + "%"));
				$row.append($("<td>").addClass("cir-num cir-sgst-col").text(Cir._formatNumber(line.sgst_rate) + "%"));
				$row.append($("<td>").addClass("cir-num cir-igst-col").text(Cir._formatNumber(line.igst_rate) + "%"));
				$row.append($("<td>").addClass("cir-num").text(Cir._formatNumber(billedTax)));
				$row.append($("<td>").addClass("cir-num").text(Cir._formatNumber(Cir._toNumber(line.bill_val) + billedTax)));
				$row.append($("<td>").addClass("cir-num").append($("<input>").attr({ type: "number", min: 0, max: balanceQty, step: "any", disabled: true })
					.addClass("form-control form-control-sm cir-line-qty")));
				$row.append($("<td>").addClass("cir-num cir-line-grn-cell").prop("hidden", true).text("0"));
				$row.append($("<td>").addClass("cir-num").append($("<input>").attr({ type: "number", min: 0, max: Cir._toNumber(line.bill_rate), step: "any", disabled: true })
					.addClass("form-control form-control-sm cir-line-difference-price")));
				$row.append($("<td>").addClass("cir-num cir-line-actual-value").text("—"));
				["sgst", "cgst", "igst"].forEach(function (tax) {
					var rateField = tax + "_rate";
					var hasTax = Cir._toNumber(line[rateField]) > 0;
					$row.append($("<td>").addClass("cir-num cir-" + tax + "-col").append($("<input>").attr({
						type: "text", disabled: true
					}).val(hasTax ? Cir._plainNumber(line[rateField]) + "%" : "0%")
						.addClass("form-control form-control-sm cir-line-" + tax + "-rate")));
				});
				$row.append($("<td>").addClass("cir-num cir-line-tax-amount").text("—"));
				$row.append($("<td>").addClass("cir-num cir-line-flat-cell cir-flat-col").prop("hidden", true)
					.append($("<input>").attr({ type: "number", min: 0, step: "any", disabled: true })
						.addClass("form-control form-control-sm cir-line-flat-amount")));
				$row.append($("<td>").addClass("cir-num cir-line-claim-amount fw-bold").text("—"));
				$body.append($row);
				$body.append($("<tr>").addClass("cir-line-error-row d-none")
					.append($("<td>").attr("colspan", "21").addClass("cir-line-error text-danger small")));
			});
			$body.append($("<tr>").addClass("cir-claim-total-row")
				.append($("<td>").attr("colspan", "19"))
				.append($("<td>").addClass("cir-claim-total-label").text("Claim Total"))
				.append($("<td>").addClass("cir-claim-total-value fw-bold").text("0.00")));
			$body.off(".cirLine")
				.on("change.cirLine", ".cir-line-select", function () {
					Cir._toggleInvoiceLine($(this).closest("tr"), this.checked);
					Cir._syncSelectAll();
				})
				.on("input.cirLine", ".cir-line-qty,.cir-line-difference-price,.cir-line-flat-amount,.cir-line-cgst-rate,.cir-line-sgst-rate,.cir-line-igst-rate", function () {
					$(this).closest("tr").next(".cir-line-error-row").addClass("d-none")
						.find(".cir-line-error").text("");
					Cir._recalculateLine($(this).closest("tr"));
				})
				.on("change.cirLine", ".cir-line-qty,.cir-line-difference-price", function () {
					Cir._validateInvoiceLineInput($(this));
				});
			Cir._updateTotalAmount();
			Cir._syncSelectAll();
			Cir._applyCirType();
	},

	_applyInvoiceLineSelection: function ($row, isSelected) {
			var index = Number($row.attr("data-line-index"));
			var line = Cir._invoiceLines[index] || {};
			var $inputs = $row.find(".cir-line-qty,.cir-line-difference-price,.cir-line-flat-amount,.cir-line-cgst-rate,.cir-line-sgst-rate,.cir-line-igst-rate");
			if (isSelected) {
				var isFlat = Cir._selectedCirType() === "Flat";
				$row.find(".cir-line-qty").val(isFlat ? "0" : Cir._plainNumber(line.balance_qty));
				$row.find(".cir-line-difference-price").val(isFlat ? "0" : Cir._plainNumber(line.bill_rate));
				$row.find(".cir-line-flat-amount").val("0");
				["cgst", "sgst", "igst"].forEach(function (tax) {
					var value = Cir._selectedCirType() === "Flat" ? "0%" : Cir._plainNumber(line[tax + "_rate"]) + "%";
					$row.find(".cir-line-" + tax + "-rate").val(value);
				});
			} else {
				$inputs.val("");
				$row.removeAttr("data-claim-amount");
			}
			$row.next(".cir-line-error-row").addClass("d-none").find(".cir-line-error").text("");
	},

	_toggleInvoiceLine: function ($row, isSelected) {
			if (Cir._selectedCirType() === "Flat") {
				Cir._applyFlatLineSelection();
				return;
			}
			Cir._applyInvoiceLineSelection($row, isSelected);
			Cir._applyCirType();
	},

	_validateInvoiceLineInput: function ($input) {
			var $row = $input.closest("tr");
			var index = Number($row.attr("data-line-index"));
			var line = Cir._invoiceLines[index] || {};
			var value = Cir._toNumber($input.val());
			var max = $input.hasClass("cir-line-qty")
				? Cir._toNumber(line.balance_qty)
				: Cir._toNumber(line.bill_rate);
			var message = "";
			if ($input.hasClass("cir-line-qty") && value < 0) {
				message = "Actual quantity cannot be negative.";
			} else if ($input.hasClass("cir-line-qty") && value > max) {
				message = "Actual quantity cannot exceed the balance quantity.";
			} else if ($input.hasClass("cir-line-difference-price") && (value < 0 || value > max)) {
				message = value < 0
					? "Difference price cannot be negative."
					: "Difference price cannot exceed the billed price.";
			}
			if (message) {
				$input.val("0");
				$row.next(".cir-line-error-row").removeClass("d-none")
					.find(".cir-line-error").text(message);
			}
			Cir._recalculateLine($row);
	},

	_recalculateLine: function ($row) {
			if (!$row.find(".cir-line-select").prop("checked")) {
				$row.find(".cir-line-actual-value,.cir-line-tax-amount,.cir-line-claim-amount").text("—");
				$row.find(".cir-line-flat-amount:not(input)").text("—");
				$row.removeAttr("data-claim-amount");
				Cir._updateTotalAmount();
				return;
			}
			var index = Number($row.attr("data-line-index"));
			var line = Cir._invoiceLines[index] || {};
			var rate = Cir._toNumber($row.find(".cir-line-difference-price").val());
			var qty = Cir._toNumber($row.find(".cir-line-qty").val());
			var isFlat = Cir._selectedCirType() === "Flat";
			var actualValue = isFlat ? 0 : Cir._money(qty * rate);
			var taxRate = Cir._toNumber($row.find(".cir-line-cgst-rate").val())
				+ Cir._toNumber($row.find(".cir-line-sgst-rate").val())
				+ Cir._toNumber($row.find(".cir-line-igst-rate").val());
			var taxAmount = !isFlat && Cir._causeTaxApplies() ? Cir._money(actualValue * taxRate / 100) : 0;
			var $flatAmount = $row.find(".cir-line-flat-amount");
			var flatAmount = isFlat ? Cir._toNumber($flatAmount.val()) : 0;
			var claimAmount = Cir._money(isFlat ? flatAmount : actualValue + taxAmount);
			$row.find(".cir-line-actual-value").text(Cir._formatNumber(actualValue));
			$row.find(".cir-line-tax-amount").text(Cir._formatNumber(taxAmount));
			$row.attr("data-claim-amount", claimAmount);
			$row.find(".cir-line-claim-amount").text(Cir._formatNumber(claimAmount));
			Cir._updateTotalAmount();
	},

	_updateTotalAmount: function () {
			var total = 0;
			Cir._$("#cir_invoice_lines_body tr[data-claim-amount]").filter(function () {
				return $(this).find(".cir-line-select").prop("checked");
			}).each(function () {
				total += Cir._toNumber($(this).attr("data-claim-amount"));
			});
			total = Cir._money(total);
			// Legacy rounds Total CIR Amount to whole rupees; Claim Total keeps paise.
			var roundedTotal = Math.round(total);
			Cir._$("#cir_total_amount").val(Cir._formatNumber(roundedTotal));
			$(".cir-claim-total-value").text(Cir._formatNumber(total))
				.attr("data-claim-total", String(total));
	},

	_updateInvoiceTableColumns: function () {
			var lines = Cir._invoiceLines || [];
			var type = String(lines.length ? lines[0].tax_type || "" : "");
			var hideCgstSgst = type === "IGST";
			var hideIgst = type === "SCGST";
			var isFlat = Cir._selectedCirType() === "Flat";
			var $table = Cir._$("#cir_invoice_lines_body").closest("table");
			$table.find(".cir-cgst-col").prop("hidden", hideCgstSgst);
			$table.find(".cir-sgst-col").prop("hidden", hideCgstSgst);
			$table.find(".cir-igst-col").prop("hidden", hideIgst);
			$table.find(".cir-flat-col").prop("hidden", !isFlat);
			$table.find(".cir-grn-col,.cir-line-grn-cell").prop("hidden", true);
			var billedCount = $table.find("thead tr:eq(1) .cir-billed-col").filter(function () {
				return !$(this).prop("hidden");
			}).length;
			var actualCount = $table.find("thead tr:eq(1) .cir-actual-col").filter(function () {
				return !$(this).prop("hidden");
			}).length;
			$table.find(".cir-billed-group").attr("colspan", billedCount);
			$table.find(".cir-actual-group").attr("colspan", actualCount);
			var visibleCount = $table.find("thead tr:eq(1) th").filter(function () {
				return !$(this).prop("hidden");
			}).length;
			$table.find(".cir-line-error").attr("colspan", visibleCount);
			$table.find(".cir-empty-row td").attr("colspan", visibleCount);
			var $totalRow = $table.find(".cir-claim-total-row");
			// Spacer + "Claim Total" under Tax Amount + value under Claim Amount.
			var claimTotalText = $(".cir-claim-total-value").attr("data-claim-total");
			var claimTotalDisplay = claimTotalText != null && claimTotalText !== ""
				? Cir._formatNumber(claimTotalText)
				: ($(".cir-claim-total-value").first().text() || Cir._formatNumber(0));
			$totalRow.empty()
				.append($("<td>").attr("colspan", Math.max(1, visibleCount - 2)))
				.append($("<td>").addClass("cir-claim-total-label").text("Claim Total"))
				.append($("<td>").addClass("cir-claim-total-value fw-bold")
					.attr("data-claim-total", claimTotalText || "0")
					.text(claimTotalDisplay));
			var headHeight = $table.find("thead tr:first-child").outerHeight();
			if (headHeight) $table.closest(".cir-invoice-lines").css("--cir-head-1", headHeight + "px");
	},

	_toNumber: function (value) {
			if (value == null || value === "") return 0;
			var text = String(value).replace(/,/g, "").replace(/%/g, "").trim();
			var number = parseFloat(text);
			return isNaN(number) ? 0 : number;
	},

	_money: function (value) {
			return Math.round((Cir._toNumber(value) + Number.EPSILON) * 100) / 100;
	},

	/** Display amounts with thousands separators (like legacy). */
	_formatNumber: function (value) {
			return Cir._toNumber(value).toLocaleString("en-US", {
				minimumFractionDigits: 2,
				maximumFractionDigits: 2
			});
	},

	/** Plain numeric text for editable inputs / API payload (no commas). */
	_plainNumber: function (value) {
			return Cir._toNumber(value).toFixed(2);
	},

	_escapeHtml: function (value) {
			return $("<div>").text(value == null ? "" : String(value)).html();
	},

	_applyComplaintType: function () {
			var selectedType = String(Cir._$("#cir_complaint_type").val() || "");
			var selectedCode = String(Cir._$("#cir_complaint_type option:selected").attr("data-code") || "");
			var oopDays = Cir._$("#cir_complaint_type option:selected").attr("data-oop-days") || "";
			Cir._$("#cir_oop_days").val(oopDays);
			var $cause = Cir._$("#cir_cause_code").empty().append($("<option>").val("").text("Select Cause"));
			(Cir._lookups.causes || []).forEach(function (cause) {
				if (String(cause.reason_int_code) !== selectedType) return;
				var $option = $("<option>").val(String(cause.cause_int_code))
					.text(cause.cause_code == null ? "" : String(cause.cause_code));
				$option.data("cir-cause", cause);
				$cause.append($option);
			});
			$cause.prop("disabled", !selectedType || !$cause.find("option").eq(1).length);
			Cir._$("#cir_stock_category_row").prop("hidden", selectedCode !== "STOCK");
			if (selectedCode !== "STOCK") Cir._$("#cir_stock_category").val("");
			else Cir._filterStockCategories(Cir._$("#cir_invoice_division").val());
			Cir._applySampleFields();
			Cir._applyCauseDetails();
			Cir._applyCfrFields();
			var lockRows = Cir._$("#cir_select_all_lines").prop("checked") && selectedCode === "INVOICE_CANCELLATION";
			Cir._$("#cir_invoice_lines_body .cir-line-select").prop("disabled", lockRows);
	},

	_applyCustomerReason: function () {
			var $option = Cir._$("#cir_customer_reason option:selected");
			var category = String($option.attr("data-category") || "");
			var subcategory = String($option.attr("data-subcategory") || "");
			Cir._$("#cir_customer_reason_category").val(category);
			Cir._$("#cir_customer_reason_subcategory").val(subcategory);
			Cir._$("#cir_complaint_type").val(category);
			Cir._applyComplaintType();
			Cir._$("#cir_cause_code").val(subcategory);
			Cir._applyCauseDetails();
	},

	_applyCauseDetails: function () {
			var cause = Cir._$("#cir_cause_code option:selected").data("cir-cause") || {};
			var fields = {
				sap_reason_code: "sap_reason_code",
				sap_category: "sap_category",
				edit_type: "edit_type",
				amount_type: "amount_type",
				tax_appl_on_flat: "tax_appl_on_flat",
				sp_line_calc_type: "sp_line_calc_type",
				return_material: "return_material",
				credit_debit: "credit_debit",
				return_type: "return_type",
				tax_for_material_return: "tax_for_material_return",
				tax_for_non_material_return: "tax_for_non_material_return",
				c_amount_type_for_non_mat_return: "c_amount_type_for_non_mat_return",
				usage_example: "usage_example",
				einstien_report_category: "einstien_report_category"
			};
			Object.keys(fields).forEach(function (id) {
				Cir._$("#cir_cause_" + ({
					sp_line_calc_type: "line_calc_type",
					return_material: "return_material",
					credit_debit: "credit_debit",
					return_type: "return_type",
					tax_for_material_return: "tax_for_material_return",
					tax_for_non_material_return: "tax_for_non_material_return",
					c_amount_type_for_non_mat_return: "amount_type_non_material",
					usage_example: "usage_example",
					einstien_report_category: "einstein_category"
				}[id] || id)).val(cause[fields[id]] || "");
			});
			Cir._renderUsageExample(cause.usage_example || "");
			if (cause.credit_debit && cause.credit_debit !== "Both") {
				Cir._$("input[name=cir_credit_debit][value='" + Cir._escapeSelector(cause.credit_debit) + "']")
					.prop("checked", true);
			} else {
				Cir._$("input[name=cir_credit_debit]").prop("checked", false);
			}
			if (cause.return_material && cause.return_material !== "Both") {
				Cir._$("input[name=cir_material_return][value='" + Cir._escapeSelector(cause.return_material) + "']")
					.prop("checked", true);
			} else {
				Cir._$("input[name=cir_material_return]").prop("checked", false);
			}
			Cir._$("input[name=cir_amount_type]").prop("checked", false);
			Cir._activeCirType = null;
			Cir._applyCirType();
			Cir._applyCfrFields();
			Cir._loadRequiredDocuments();
	},

	_renderUsageExample: function (usageExample) {
			var text = String(usageExample || "").trim();
			Cir._$("#cir_usage_example").text(text);
			Cir._$("#cir_usage_ex").prop("hidden", !text);
	},

	_applySampleFields: function () {
			var code = String(Cir._$("#cir_complaint_type option:selected").attr("data-code") || "");
			var showSample = code === "PRDQUA";
			Cir._$("#cir_sample_row").prop("hidden", !showSample);
			if (!showSample) Cir._$("input[name=cir_sent_sample]").prop("checked", false);
			var showDocket = showSample && Cir._$("input[name=cir_sent_sample]:checked").val() === "Yes";
			Cir._$("#cir_sample_docket_row").prop("hidden", !showDocket);
			if (!showDocket) Cir._$("#cir_sample_docket_no").val("");
			Cir._applyCfrFields();
	},

	/** Legacy: CFR number + note when reason is PRDQUA and invoice group is HCBG. */
	_applyCfrFields: function () {
			var code = String(Cir._$("#cir_complaint_type option:selected").attr("data-code") || "");
			var showCfr = code === "PRDQUA" && Cir._invoiceGroupName() === "HCBG";
			Cir._$("#cir_cfr_row").prop("hidden", !showCfr);
			if (!showCfr) Cir._$("#cir_cfr_number").val("");
	},

	_showClosedDayNotice: function (closedDays) {
			var days = String(closedDays || "").split(",").map(function (day) {
				return day.trim();
			});
			var today = String(new Date().getDate());
			if (days.indexOf(today) !== -1) {
				Cir._$("#cir_setup_notice").text(
					"System is closed for month end today. You cannot raise a CIR request.")
					.removeClass("d-none");
			} else {
				Cir._$("#cir_setup_notice").addClass("d-none").text("");
			}
	},

	_escapeSelector: function (value) {
			return String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
	},

	_showPanelLoader: function ($panel, message) {
		Cir._showLoader(message, $panel.attr("id"));
	},

	_hidePanelLoader: function ($panel) {
		Cir._hideLoader($panel.attr("id"));
	},

	_newRequestMessage: function (message) {
		Cir._$("#cir_new_request_panel").prepend(
			'<div class="alert alert-danger cir-context-error">' + Cir._escape(message) + "</div>");
	},

	_initTable: function () {
		if (!window.Common || !Common.DataTable) return;
		Common.DataTable.init({
			rootId: Cir.ROOT,
			tableId: "cir_requests_table",
			tbodyId: "cir_requests_rows",
			pageSizes: Cir.PAGE_SIZES,
			pageSize: Cir.PAGE_SIZE,
			filter_type: "minimal",
			searchPlaceholder: "Search requests...",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "full",
			maxHeight: "520px",
			emptyMessage: "No CIR requests were found for this customer.",
			columns: [
				{ title: "View", field: "action_html", type: "html", searchable: false, sortable: false, width: 70 },
				{ title: "Request ID", field: "cir_no", sortable: true, width: 140 },
				{ title: "Request Date", field: "cir_date", sortable: true, width: 130 },
				{ title: "Invoice No.", field: "invoice_no", sortable: true, width: 160 },
				{ title: "Invoice Date", field: "invoice_date", sortable: true, width: 130 },
				{ title: "Reason", field: "customer_reason", sortable: true, width: 260 },
				{ title: "Total Amount", field: "total_amt", sortable: true, width: 150, "text-align": "right" },
				{ title: "Status", field: "status_html", type: "html", searchable: true, sortable: false, width: 150 }
			],
			rows: []
		});
		Cir._$("#cir_requests_table").off("click.cir", ".cir-view-request")
			.on("click.cir", ".cir-view-request", function () {
				var requestId = Number($(this).attr("data-request-id"));
				if (Number.isSafeInteger(requestId) && requestId > 0) Cir.ViewRequest(requestId);
			});
		Cir._$("#cir_requests_refresh").off("click.cir").on("click.cir", function () {
			Cir.LoadRequests();
		});
		Cir._$("#cir_detail_content").off("click.cir", ".cir-answer-submit")
			.on("click.cir", ".cir-answer-submit", function () {
				var requestId = Number($(this).attr("data-request-id"));
				var clarificationId = Number($(this).attr("data-clarification-id"));
				var answer = Cir._$("#cir_answer_" + String(clarificationId)).val();
				Cir._answerClarification(requestId, clarificationId, answer);
			});
		Cir._$("#cir_detail_content").off("click.cir", "#cir_addl_upload_btn")
			.on("click.cir", "#cir_addl_upload_btn", function () {
				var requestId = Number($(this).attr("data-request-id"));
				Cir._uploadAdditionalDocument(requestId);
			});
		Cir._$("#cir_detail_content").off("click.cirAddlBrowse", "#cir_addl_browse")
			.on("click.cirAddlBrowse", "#cir_addl_browse", function (event) {
				event.preventDefault();
				var input = Cir._$("#cir_addl_file").get(0);
				if (input) {
					input.click();
				}
			});
		Cir._$("#cir_detail_content").off("click.cir", ".cir-detail-tab")
			.on("click.cir", ".cir-detail-tab", function () {
				Cir._activateDetailTab($(this).attr("data-tab"));
			})
			.off("keydown.cir", ".cir-detail-tab")
			.on("keydown.cir", ".cir-detail-tab", function (event) {
				var $tabs = Cir._$("#cir_detail_content .cir-detail-tab");
				var index = $tabs.index(this);
				if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
					event.preventDefault();
					index = (index + (event.key === "ArrowRight" ? 1 : $tabs.length - 1)) % $tabs.length;
					$tabs.eq(index).trigger("click").trigger("focus");
				} else if (event.key === "Home" || event.key === "End") {
					event.preventDefault();
					index = event.key === "Home" ? 0 : $tabs.length - 1;
					$tabs.eq(index).trigger("click").trigger("focus");
				}
			});
	},

	LoadRequests: function () {
		if (Cir._loading) return;
		Cir._loading = true;
		Cir._requestsLoaded = false;
		Cir._$("#cir_requests_refresh").prop("disabled", true).addClass("is-refreshing");
		Cir._showPanelLoader(Cir._$("#cir_my_requests_panel"), "Loading your CIR requests...");
		Cir._request("/requests", Cir._customer, function (data) {
			var source = data && Array.isArray(data.header_details) ? data.header_details : [];
			var rows = source.map(function (row) {
				return {
					cir_no: row.cir_no == null ? "" : String(row.cir_no),
					action_html: '<button type="button" class="cir-view-request" title="View request" aria-label="View request" data-request-id="' +
						String(Number(row.internal_code)) + '"><i class="ri-eye-line" aria-hidden="true"></i></button>',
					cir_date: row.cir_date || "",
					invoice_no: row.invoice_no || "",
					invoice_date: row.invoice_date || "",
					customer_reason: row.customer_reason || "",
					total_amt: Cir._formatAmount(row.total_amt),
					status_html: Cir._status(row.ui_status, row.credit_note_no, row.credit_note_date)
				};
			});
			Common.DataTable.setData(Cir.ROOT, rows);
			Cir._requestsLoaded = true;
			Cir._hidePanelLoader(Cir._$("#cir_my_requests_panel"));
			Cir._message(rows.length ? "" : "No CIR requests were found for this customer.", false);
			Cir._openPendingView();
		}, function (message) {
			Cir._hidePanelLoader(Cir._$("#cir_my_requests_panel"));
			Cir._message(message, true);
		}, function () {
			Cir._loading = false;
			Cir._$("#cir_requests_refresh").prop("disabled", false).removeClass("is-refreshing");
		});
	},

	ViewRequest: function (requestId) {
		Cir._message("", false);
		Cir._$("#cir_detail_title").text("CIR Request details");
		Cir._$("#cir_detail_content").empty();
		Cir._showModal();
		Cir._showLoader("Loading request details...", "cir_detail_content");
		Cir._request("/requests/" + encodeURIComponent(String(requestId)), Cir._customer,
			function (data) {
				Cir._hideLoader("cir_detail_content");
				Cir._renderDetail(data || {});
				if (Cir._pendingDetailTab) {
					var tab = Cir._pendingDetailTab;
					Cir._pendingDetailTab = "";
					Cir._activateDetailTab(tab);
				}
			}, function (message) {
				Cir._hideLoader("cir_detail_content");
				Cir._$("#cir_detail_content").text(message);
			});
	},

	_renderDetail: function (data) {
		var header = data.header || {};
		var requestId = Number(header.internal_code);
		var totalText = Cir._formatAmount(header.total_amt) || "0.00";
		var html = '<div class="cir-detail-banner"><div><span class="cir-request-number">CIR NO : ' +
			Cir._escape(header.cir_no || header.ticket_number || "") + '</span><span class="cir-request-date">' +
			Cir._escape(header.cir_date || "") + '</span></div>' +
			Cir._status(header.ui_status) + "</div>";
		html += Cir._legacyHeader(header);
		html += '<div class="cir-header-total"><strong>Total CIR Amount: ' +
			Cir._escape(totalText) + "</strong>" +
			'<span class="cir-header-total-words">' + Cir._escape(Cir._amountInWords(header.total_amt)) +
			"</span></div>";
		var tabs = [
			{ id: "invoice", title: "Invoice Details" },
			{ id: "lots", title: "Lot Details" },
			{ id: "documents", title: "Documents" },
			{ id: "credit", title: "Credit Details" }
		];
		html += '<div class="cir-detail-tabs" role="tablist" aria-label="CIR request details">';
		for (var i = 0; i < tabs.length; i++) {
			html += '<button type="button" class="cir-detail-tab" role="tab" id="cir_detail_tab_' +
				tabs[i].id + '" aria-controls="cir_detail_pane_' + tabs[i].id +
				'" aria-selected="' + (i === 0 ? "true" : "false") + '" tabindex="' +
				(i === 0 ? "0" : "-1") + '" data-tab="' + tabs[i].id + '">' +
				tabs[i].title + "</button>";
		}
		html += "</div>";
		html += '<section class="cir-detail-pane" id="cir_detail_pane_invoice" role="tabpanel" aria-labelledby="cir_detail_tab_invoice">';
		html += Cir._detailInvoiceLinesTable(data.invoice_details || []);
		html += Cir._detailTable("Freight Details", data.frieght_details, [
			["Type", "type"], ["Description", "frieght_desc"], ["Tax As Applicable", "gst_applicable"],
			["Base Value", "item_base_value"], ["Freight Percentage", "frieght_perc"],
			["Tax Amount", "item_tax_amount"], ["Flat Amount", "frieght_flat_amount"],
			["Freight Value", "total_frieght_amount"]
		], "cir-tbl-freight");
		html += "</section>";
		html += '<section class="cir-detail-pane d-none" id="cir_detail_pane_lots" role="tabpanel" aria-labelledby="cir_detail_tab_lots">';
		html += Cir._detailLotTable(data.lot_details || []);
		html += "</section>";
		html += '<section class="cir-detail-pane d-none" id="cir_detail_pane_documents" role="tabpanel" aria-labelledby="cir_detail_tab_documents">';
		html += Cir._documentTables(requestId, data.document_details, data.additional_documents);
		html += "</section>";
		html += '<section class="cir-detail-pane d-none" id="cir_detail_pane_credit" role="tabpanel" aria-labelledby="cir_detail_tab_credit">';
		html += Cir._summaryCards([
			["Total CIR Amount", Cir._formatAmount(header.total_amt)],
			["Claim Amount", Cir._formatAmount(header.claim_amt)],
			["Credit / Debit", header.credit_debit], ["Material Return", header.material_return],
			["Credit Note", header.credit_note_no], ["Credit Note Date", header.credit_note_date],
			["Debit Note", header.debit_no], ["Debit Date", header.debit_date],
			["Pending With", header.pending_with], ["Pending Role", header.pending_with_role],
			["Rework Remarks", header.rework_remarks]
		]);
		var creditNoteIssued = !!String(header.credit_note_no || "").trim();
		if (!creditNoteIssued) {
			html += Cir._detailTable("Approvals", data.approver_details, [
				["Type", "approval_type"], ["Role", "approver_role"], ["Approver", "approver"],
				["Sequence", "sequence"], ["Status", "approval_status"],
				["Remarks", "approval_remarks"], ["Modified", "modified_date"]
			], "cir-tbl-approvals");
			html += Cir._detailTable("History", data.history_details, [
				["Date", "updated_date"], ["Updated By", "updated_by"], ["Type", "approver_type"],
				["Status", "approver_status"], ["Remarks", "approver_remarks"]
			], "cir-tbl-history");
		}
		html += Cir._detailTable("Clarifications", data.clarification_details, [
			["Question", "clarification_question"], ["Raised By", "clarification_raised_by"],
			["Raised", "raised_date"], ["Answer", "answer"], ["Answered By", "answered_by"],
			["Answered", "answered_date"]
		], "cir-tbl-clarifications");
		html += Cir._clarificationReplies(header.internal_code, data.clarification_details);
		html += "</section>";
		Cir._$("#cir_detail_title").text("CIR Request " + String(header.ticket_number || ""));
		Cir._$("#cir_detail_content").html(html);
	},

	_legacyHeader: function (header) {
		var contactDetails = [header.customer_phone, header.customer_email]
			.filter(function (value) { return String(value || "").trim(); });
		var displayDetails = contactDetails.length > 1
			? contactDetails[0] + " (" + contactDetails[1] + ")"
			: contactDetails.join("");
		return '<div class="cir-legacy-header-wrap"><table class="cir-legacy-header" aria-label="CIR request header">' +
			"<tbody>" +
			Cir._legacyHeaderRow([
				["Name of the requester", header.requester],
				["Customer", header.customer_display || header.cust_name],
				["Customer Type", header.customer_type]
			]) +
			Cir._legacyHeaderRow([
				["Customer Contact Name", header.customer_contact_name],
				["Customer Contact Details", displayDetails],
				["Material Return", header.material_return]
			]) +
			Cir._legacyHeaderRow([
				["Invoice", header.invoice_no],
				["Invoice Date", header.invoice_date],
				["Customer Reason", header.customer_reason]
			]) +
			Cir._legacyHeaderRow([
				["Business Group", header.business_group],
				["Business Division", header.business_division],
				["Warehouse", header.warehouse]
			]) +
			'<tr><th>Credit/Debit</th><td>' + Cir._escape(header.credit_debit) +
			'</td><th>Complaint Details</th><td class="cir-complaint" colspan="3">' +
			Cir._escape(header.cust_remarks) + "</td></tr>" +
			"</tbody></table></div>";
	},

	_legacyHeaderRow: function (fields) {
		var html = "<tr>";
		for (var i = 0; i < fields.length; i++) {
			html += "<th>" + Cir._escape(fields[i][0]) + "</th><td>" +
				Cir._escape(fields[i][1]) + "</td>";
		}
		return html + "</tr>";
	},

	_summaryCards: function (items) {
		var html = '<div class="cir-detail-summary">';
		for (var i = 0; i < items.length; i++) {
			html += '<div class="cir-detail"><span class="label">' + Cir._escape(items[i][0]) +
				'</span><span class="value">' + Cir._escape(items[i][1]) + "</span></div>";
		}
		return html + "</div>";
	},

	_documentTables: function (requestId, documents, attachments) {
		var html = '<div class="cir-document-grid">';
		html += Cir._documentTable("Required Documents", documents, requestId, false);
		html += Cir._documentTable("Additional Documents", attachments, requestId, true);
		html += Cir._additionalUploadForm(requestId);
		return html + "</div>";
	},

	_documentTable: function (title, rows, requestId, attachment) {
		var tableClass = attachment ? "cir-detail-table cir-tbl-addl-docs" : "cir-detail-table cir-tbl-req-docs";
		var html = '<section class="cir-detail-section"><h3>' + Cir._escape(title) + "</h3>";
		var list = Array.isArray(rows) ? rows : [];
		if (!attachment && !list.length) {
			return html + '<div class="cir-detail-scroll cir-doc-empty p-3">No documents are attached.</div></section>';
		}
		html += '<div class="cir-detail-scroll"><table class="' + tableClass + '"><thead><tr>';
		html += attachment
			? "<th>Sl No</th><th>File Name</th><th>Remarks</th><th>Uploaded By</th><th>Uploaded Date</th><th>Download</th>"
			: "<th>Sl No</th><th>Document</th><th>Uploaded File</th><th>Remarks</th><th>Download</th>";
		html += "</tr></thead><tbody>";
		if (attachment && !list.length) {
			html += '<tr><td colspan="6" class="cir-doc-empty">No additional documents uploaded.</td></tr>';
		}
		for (var i = 0; i < list.length; i++) {
			var row = list[i] || {};
			var fileName = attachment ? row.file_name : (row.file_name || row.mmm_file_name);
			var hasFile = Number(row.has_file) === 1 || !!String(fileName || "").trim();
			var fileId = Number(attachment ? row.attachment_id : row.document_id);
			var fileUrl = "";
			if (Number.isSafeInteger(requestId) && requestId > 0 &&
				Number.isSafeInteger(fileId) && fileId > 0 && hasFile) {
				var kind = attachment ? "attachments/" : "documents/";
				fileUrl = (window.$app_url || "") + Cir._api + "/requests/" +
					encodeURIComponent(String(requestId)) + "/" + kind +
					encodeURIComponent(String(fileId)) + "/download?" + $.param(Cir._customer);
			}
			html += "<tr><td>" + Cir._escape(String(i + 1)) + "</td>";
			if (!attachment) html += "<td>" + Cir._escape(row.doc_name) + "</td>";
			if (attachment && fileUrl) {
				html += '<td><a class="cir-doc-download" href="' + Cir._escape(fileUrl) + '">' +
					Cir._escape(fileName || "document") + "</a></td>";
			} else {
				html += "<td>" + Cir._escape(fileName || "Not uploaded") + "</td>";
			}
			html += "<td>" + Cir._escape(row.remarks) + "</td>";
			if (attachment) {
				html += "<td>" + Cir._escape(row.uploaded_by || "") + "</td>";
				html += "<td>" + Cir._escape(row.uploaded_date || row.created_date || "") + "</td>";
			}
			html += '<td>' + (fileUrl
				? '<a class="cir-doc-download" href="' + Cir._escape(fileUrl) +
					'"><i class="ri-download-2-line" aria-hidden="true"></i> Download</a>'
				: '<span class="text-muted">—</span>') + "</td></tr>";
		}
		return html + "</tbody></table></div></section>";
	},

	_additionalUploadForm: function (requestId) {
		if (!Number.isSafeInteger(requestId) || requestId <= 0) return "";
		return '<section class="cir-detail-section cir-addl-upload">' +
			"<h3>Upload Additional Documents</h3>" +
			'<div class="cir-addl-upload-grid">' +
			'<label class="cir-addl-field"><span>File Name</span>' +
			'<input type="text" id="cir_addl_file_name" class="form-control form-control-sm" maxlength="120" placeholder="Display name"></label>' +
			'<label class="cir-addl-field"><span>Attachment</span>' +
			'<span class="cir-doc-file-cell">' +
			'<input type="file" id="cir_addl_file" class="cir-doc-file" tabindex="-1" aria-hidden="true">' +
			'<button type="button" class="cir-doc-browse" id="cir_addl_browse" title="Browse file">' +
			'<i class="ri-folder-open-line" aria-hidden="true"></i> Browse File</button></span></label>' +
			'<label class="cir-addl-field"><span>Remarks</span>' +
			'<input type="text" id="cir_addl_remarks" class="form-control form-control-sm" maxlength="500"></label>' +
			'<div class="cir-addl-actions">' +
			'<button type="button" class="btn btn-success btn-sm" id="cir_addl_upload_btn" data-request-id="' +
			Cir._escape(String(requestId)) + '">' +
			'<i class="ri-upload-2-line" aria-hidden="true"></i> Upload</button>' +
			"</div></div>" +
			'<div id="cir_addl_upload_msg" class="cir-addl-msg d-none" role="status"></div>' +
			"</section>";
	},

	_uploadAdditionalDocument: function (requestId) {
		var fileInput = Cir._$("#cir_addl_file").get(0);
		var file = fileInput && fileInput.files && fileInput.files[0];
		var $msg = Cir._$("#cir_addl_upload_msg");
		var showMsg = function (text, isError) {
			$msg.toggleClass("d-none", !text)
				.toggleClass("alert-danger", !!isError)
				.toggleClass("alert-success", !isError)
				.text(text || "");
		};
		if (!Number.isSafeInteger(requestId) || requestId <= 0) {
			showMsg("CIR request is invalid.", true);
			return;
		}
		if (!file) {
			showMsg("Choose a file to upload.", true);
			return;
		}
		if (file.size > 5 * 1024 * 1024) {
			showMsg("Each document must be 5 MB or smaller.", true);
			return;
		}
		var form = new FormData();
		form.append("file", file);
		form.append("fileName", String(Cir._$("#cir_addl_file_name").val() || "").trim() || file.name);
		form.append("remarks", String(Cir._$("#cir_addl_remarks").val() || "").trim());
		var query = $.extend({}, Cir._customer || {});
		var $btn = Cir._$("#cir_addl_upload_btn").prop("disabled", true);
		showMsg("Uploading via SMB3...", false);
		Cir._showLoader("Uploading additional document...", "cir_detail_content");
		$.ajax({
			url: (window.$app_url || "") + Cir._api + "/requests/" +
				encodeURIComponent(String(requestId)) + "/attachments?" + $.param(query),
			method: "POST",
			data: form,
			processData: false,
			contentType: false,
			dataType: "json",
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (Cir._session(json)) return;
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					showMsg((json && (json.message || json.status)) ||
						"Unable to upload the additional document.", true);
					return;
				}
				showMsg("Additional document uploaded.", false);
				Cir._pendingDetailTab = "documents";
				Cir.ViewRequest(requestId);
			},
			error: function (xhr) {
				if (xhr.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					return;
				}
				showMsg("The CIR service could not upload the document.", true);
			},
			complete: function () {
				$btn.prop("disabled", false);
				Cir._hideLoader("cir_detail_content");
			}
		});
	},

	/** Lot Details — same column names/order as legacy CIR Details popup. */
	_detailLotTable: function (rows) {
		if (!Array.isArray(rows) || !rows.length) {
			return '<section class="cir-detail-section">' +
				'<div class="cir-detail-scroll cir-doc-empty p-3">No lot details found.</div></section>';
		}
		var html = '<section class="cir-detail-section">' +
			'<div class="cir-detail-scroll"><table class="cir-detail-table cir-tbl-lots">' +
			"<thead><tr>" +
			"<th>Sl.No</th>" +
			"<th>Item/LOT Mismatch</th>" +
			"<th>Item No.</th>" +
			"<th>Description</th>" +
			"<th>Line No.</th>" +
			'<th class="cir-num">Invoice Billed Qty</th>' +
			'<th class="cir-num">Returned Qty</th>' +
			'<th class="cir-num">WH. Approved Qty</th>' +
			"<th>LOT No.</th>" +
			"<th>LOT Wh.</th>" +
			"<th>LOT Location</th>" +
			"<th>Overridden Loc.</th>" +
			'<th class="cir-num">Billed Loc. Qty</th>' +
			'<th class="cir-num">Returned Qty</th>' +
			"</tr></thead><tbody>";
		for (var r = 0; r < rows.length; r++) {
			var row = rows[r] || {};
			html += "<tr>" +
				"<td>" + Cir._escape(String(r + 1)) + "</td>" +
				"<td>" + Cir._escape(row.mismatch_type || "No") + "</td>" +
				"<td>" + Cir._escape(row.item_code) + "</td>" +
				"<td>" + Cir._escape(row.item_desc) + "</td>" +
				"<td>" + Cir._escape(row.item_line_no) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatLotQty(row.billed_qty)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatLotQty(row.approved_qty)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatLotQty(row.wh_appr_qty, 2)) + "</td>" +
				"<td>" + Cir._escape(row.lot_no) + "</td>" +
				"<td>" + Cir._escape(row.lot_wh_code) + "</td>" +
				"<td>" + Cir._escape(row.lot_location) + "</td>" +
				"<td>" + Cir._escape(row.sel_location) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatLotQty(row.lot_qty, 2)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatLotQty(row.lot_act_aty, 2)) + "</td>" +
				"</tr>";
		}
		return html + "</tbody></table></div></section>";
	},

	_formatLotQty: function (value, fractionDigits) {
		if (value == null || value === "") return "";
		var qty = Number(value);
		if (!Number.isFinite(qty)) return String(value);
		var digits = fractionDigits == null ? 3 : fractionDigits;
		return qty.toLocaleString("en-IN", {
			minimumFractionDigits: digits,
			maximumFractionDigits: digits
		});
	},

	_downloadAbort: null,

	_abortDocumentDownload: function () {
		if (Cir._downloadAbort) {
			try { Cir._downloadAbort.abort(); } catch (_e) { /* ignore */ }
			Cir._downloadAbort = null;
		}
	},

	_downloadDocument: function (link) {
		var url = link.getAttribute("href");
		if (!url || link.getAttribute("aria-busy") === "true") return false;
		var $link = $(link);
		var label = $link.html();
		Cir._abortDocumentDownload();
		Cir._clearDetailDownloadError();
		$link.attr("aria-busy", "true");
		$link.html('<i class="ri-loader-4-line" aria-hidden="true"></i> Downloading');
		Cir._showLoader("Downloading document...", "cir_detail_content");
		var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
		Cir._downloadAbort = controller;
		var fetchOpts = { credentials: "same-origin", cache: "no-store" };
		if (controller) fetchOpts.signal = controller.signal;
		fetch(url, fetchOpts)
			.then(function (response) {
				if (response.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					throw new Error("session");
				}
				if (!response.ok) throw new Error("status");
				var header = response.headers.get("Content-Disposition") || "";
				var encoded = /filename\*=UTF-8''([^;]+)/i.exec(header);
				var plain = /filename="([^"]+)"/i.exec(header);
				var name = encoded ? decodeURIComponent(encoded[1].trim())
					: (plain ? plain[1].trim() : "document");
				return response.blob().then(function (blob) {
					return { blob: blob, name: name };
				});
			})
			.then(function (file) {
				var objectUrl = URL.createObjectURL(file.blob);
				var saver = document.createElement("a");
				saver.href = objectUrl;
				saver.download = file.name || "document";
				document.body.appendChild(saver);
				saver.click();
				saver.remove();
				setTimeout(function () { URL.revokeObjectURL(objectUrl); }, 1500);
			})
			.catch(function (error) {
				if (error && (error.name === "AbortError" || error.message === "AbortError")) return;
				if (!error || error.message !== "session") {
					Cir._showDetailDownloadError("The document could not be downloaded.");
				}
			})
			.finally(function () {
				if (Cir._downloadAbort === controller) Cir._downloadAbort = null;
				try {
					$link.attr("aria-busy", "false").html(label);
				} catch (_e) { /* link may be gone if modal closed */ }
				Cir._hideLoader("cir_detail_content");
			});
		return false;
	},

	_clearDetailDownloadError: function () {
		Cir._$("#cir_detail_content .cir-download-error").remove();
	},

	_showDetailDownloadError: function (message) {
		Cir._clearDetailDownloadError();
		var $content = Cir._$("#cir_detail_content");
		if (!$content.length) return;
		$content.prepend(
			'<div class="alert alert-danger cir-download-error mb-2" role="alert">' +
			Cir._escape(message || "The document could not be downloaded.") +
			"</div>");
		var docsPane = Cir._$("#cir_detail_pane_documents").get(0);
		if (docsPane && docsPane.classList.contains("d-none") && typeof Cir._activateDetailTab === "function") {
			Cir._activateDetailTab("documents");
		}
		try {
			$content[0].scrollTop = 0;
		} catch (_e) { /* ignore */ }
	},

	_activateDetailTab: function (tab) {
		Cir._$("#cir_detail_content .cir-detail-tab").each(function () {
			var selected = $(this).attr("data-tab") === tab;
			$(this).attr("aria-selected", selected ? "true" : "false")
				.attr("tabindex", selected ? "0" : "-1");
		});
		Cir._$("#cir_detail_content .cir-detail-pane").addClass("d-none");
		Cir._$("#cir_detail_pane_" + tab).removeClass("d-none");
	},

	/** Detail popup invoice lines — same grouped columns as legacy CIR Details. */
	_detailInvoiceLinesTable: function (rows) {
		if (!Array.isArray(rows) || !rows.length) {
			return '<section class="cir-detail-section"><h3>Invoice Details</h3>' +
				'<div class="cir-detail-scroll cir-doc-empty p-3">No invoice lines found.</div></section>';
		}
		var html = '<section class="cir-detail-section"><h3>Invoice Details</h3>' +
			'<div class="cir-detail-scroll"><table class="cir-detail-table cir-detail-invoice-table">' +
			"<thead>" +
			'<tr class="cir-inv-group-row">' +
			'<th class="cir-inv-group cir-inv-group-item" colspan="2">Item Details</th>' +
			'<th class="cir-inv-group cir-inv-group-billed" colspan="7">3M Billed Invoice Details</th>' +
			'<th class="cir-inv-group cir-inv-group-actual" colspan="7">Customer Actual Return/Refund Details</th>' +
			"</tr>" +
			"<tr>" +
			"<th>SI No.</th>" +
			"<th>SKU No./Desc</th>" +
			'<th class="cir-num">Billed Qty</th>' +
			'<th class="cir-num">Price per Unit</th>' +
			'<th class="cir-num">Billed Value</th>' +
			'<th class="cir-num">CGST</th>' +
			'<th class="cir-num">SGST</th>' +
			'<th class="cir-num">Tax Amount</th>' +
			'<th class="cir-num">Total Inv. Amount</th>' +
			'<th class="cir-num">Actual Return Qty</th>' +
			'<th class="cir-num">Difference Price</th>' +
			'<th class="cir-num">Actual Value</th>' +
			'<th class="cir-num">Actual CGST</th>' +
			'<th class="cir-num">Actual SGST</th>' +
			'<th class="cir-num">Tax Amount</th>' +
			'<th class="cir-num">Claim Amount</th>' +
			"</tr></thead><tbody>";
		for (var r = 0; r < rows.length; r++) {
			var row = rows[r] || {};
			var sku = String(row.item_code || "").trim();
			var desc = String(row.item_desc || "").trim();
			var skuDesc = sku && desc ? (sku + "-" + desc) : (sku || desc || "");
			var billedTax = row.bill_tax_val;
			var totalInv = row.item_val;
			if (totalInv == null || totalInv === "") {
				var billVal = Number(row.bill_val);
				var taxVal = Number(billedTax);
				totalInv = (Number.isFinite(billVal) ? billVal : 0) + (Number.isFinite(taxVal) ? taxVal : 0);
			}
			html += "<tr>" +
				"<td>" + Cir._escape(String(r + 1)) + "</td>" +
				"<td>" + Cir._escape(skuDesc) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatQty(row.bill_qty)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(row.bill_rate)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(row.bill_val)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatTaxRate(row.tax_rate1)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatTaxRate(row.tax_rate2)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(billedTax)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(totalInv)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatQty(row.act_qty)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(row.act_rate)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(row.act_val)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatTaxRate(row.act_tax_rate1)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatTaxRate(row.act_tax_rate2)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(row.act_tax_val)) + "</td>" +
				'<td class="cir-num">' + Cir._escape(Cir._formatAmount(row.claim_amt)) + "</td>" +
				"</tr>";
		}
		return html + "</tbody></table></div></section>";
	},

	_formatTaxRate: function (value) {
		if (value == null || value === "") return "";
		var rate = Number(value);
		if (!Number.isFinite(rate)) return String(value);
		return rate.toLocaleString("en-IN", {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2
		}) + "%";
	},

	_formatQty: function (value) {
		if (value == null || value === "") return "";
		var qty = Number(value);
		return Number.isFinite(qty)
			? qty.toLocaleString("en-IN", { maximumFractionDigits: 3 })
			: String(value);
	},

	_amountInWords: function (value) {
		var amount = Math.round(Number(value));
		if (!Number.isFinite(amount) || amount < 0) return "";
		if (amount === 0) return "Zero only";
		var ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
			"Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
			"Seventeen", "Eighteen", "Nineteen"];
		var tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
		function two(n) {
			if (n < 20) return ones[n];
			return tens[Math.floor(n / 10)] + (n % 10 ? " " + ones[n % 10] : "");
		}
		function three(n) {
			if (!n) return "";
			if (n < 100) return two(n);
			return ones[Math.floor(n / 100)] + " Hundred" + (n % 100 ? " " + two(n % 100) : "");
		}
		var crore = Math.floor(amount / 10000000);
		var lakh = Math.floor((amount % 10000000) / 100000);
		var thousand = Math.floor((amount % 100000) / 1000);
		var rest = amount % 1000;
		var parts = [];
		if (crore) parts.push(two(crore) + " Crore");
		if (lakh) parts.push(two(lakh) + " Lakh");
		if (thousand) parts.push(two(thousand) + " Thousand");
		if (rest) parts.push(three(rest));
		return parts.join(" ") + " only";
	},

	_detailTable: function (title, rows, columns, tableClass) {
		if (!Array.isArray(rows) || rows.length === 0) return "";
		var cls = "cir-detail-table" + (tableClass ? (" " + tableClass) : "");
		var html = '<section class="cir-detail-section"><h3>' + Cir._escape(title) + "</h3>" +
			'<div class="cir-detail-scroll"><table class="' + cls + '"><thead><tr>';
		for (var i = 0; i < columns.length; i++) html += "<th>" + Cir._escape(columns[i][0]) + "</th>";
		html += "</tr></thead><tbody>";
		for (var r = 0; r < rows.length; r++) {
			html += "<tr>";
			for (var c = 0; c < columns.length; c++) {
				html += "<td>" + Cir._escape(rows[r][columns[c][1]]) + "</td>";
			}
			html += "</tr>";
		}
		return html + "</tbody></table></div></section>";
	},

	_clarificationReplies: function (requestId, rows) {
		if (!Array.isArray(rows)) return "";
		var pending = rows.filter(function (row) {
			return row && row.clarification_type === "Request" && !String(row.answer || "").trim();
		});
		if (!pending.length) return "";
		var html = '<section class="cir-detail-section"><h3>Answer a clarification</h3>';
		for (var i = 0; i < pending.length; i++) {
			var id = Number(pending[i].clarification_id);
			if (!Number.isSafeInteger(id) || id <= 0) continue;
			html += '<label class="cir-answer-label" for="cir_answer_' + id + '">' +
				Cir._escape(pending[i].clarification_question) + '</label>' +
				'<textarea class="form-control cir-answer-input" id="cir_answer_' + id +
				'" maxlength="4000" rows="3"></textarea>' +
				'<button type="button" class="btn btn-success btn-sm cir-answer-submit" data-request-id="' +
				String(Number(requestId)) + '" data-clarification-id="' + id +
				'">Submit answer</button>';
		}
		return html + "</section>";
	},

	_answerClarification: function (requestId, clarificationId, answer) {
		var text = String(answer || "").trim();
		if (!Number.isSafeInteger(requestId) || requestId <= 0 ||
			!Number.isSafeInteger(clarificationId) || clarificationId <= 0 ||
			!text || text.length > 4000) {
			Cir._message("Enter an answer of up to 4,000 characters.", true);
			return;
		}
		$.ajax({
			url: (window.$app_url || "") + Cir._api + "/requests/" +
				encodeURIComponent(String(requestId)) + "/clarifications/" +
				encodeURIComponent(String(clarificationId)) + "/answer",
			method: "POST",
			contentType: "application/json",
			data: JSON.stringify({ answer: text }),
			dataType: "json",
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (Cir._session(json)) return;
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					Cir._$("#cir_detail_content").prepend('<div class="alert alert-danger">' +
						Cir._escape((json && (json.message || json.status)) ||
							"Unable to submit the clarification answer.") + "</div>");
					return;
				}
				Cir.ViewRequest(requestId);
			},
			error: function (xhr) {
				if (xhr.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					return;
				}
				Cir._$("#cir_detail_content").prepend(
					'<div class="alert alert-danger">The CIR service could not submit your answer.</div>');
			}
		});
	},

	_showModal: function () {
		var element = Cir._$("#cir_detail_modal").get(0);
		if (!element) {
			return;
		}
		if (window.bootstrap && bootstrap.Modal) {
			bootstrap.Modal.getOrCreateInstance(element).show();
		} else if ($.fn.modal) {
			$(element).modal("show");
		}
	},

	_request: function (path, data, success, failure, complete) {
		$.ajax({
			url: (window.$app_url || "") + Cir._api + path,
			method: "GET",
			data: data,
			dataType: "json",
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (Cir._session(json)) {
					failure("Your session has expired. Please sign in again.");
					return;
				}
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					failure((json && (json.message || json.status)) || "Unable to load CIR requests.");
					return;
				}
				success(json.data);
			},
			error: function (xhr) {
				if (xhr.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					failure("Your session has expired. Please sign in again.");
					return;
				}
				failure("The CIR service could not load your requests.");
			},
			complete: complete
		});
	},

	_showLoader: function (message, targetId) {
		if (typeof window.showLoader === "function") {
			window.showLoader(message, targetId);
		}
	},

	_hideLoader: function (targetId) {
		if (typeof window.hideLoader === "function") {
			window.hideLoader(targetId);
		}
	},

	/** Clears CIR loaders, including orphan body panels left after modal/HTML reload. */
	_hideAllCirLoaders: function () {
		Cir._abortDocumentDownload();
		var targets = [
			Cir._hostId(),
			"m_cir_home",
			"m_cir_dashboard",
			"m_cir_new_request",
			"m_cir_requests",
			"cir_detail_content",
			"cir_dashboard_panel",
			"cir_new_request_panel",
			"cir_my_requests_panel"
		];
		for (var i = 0; i < targets.length; i++) {
			Cir._hideLoader(targets[i]);
		}
		try {
			document.querySelectorAll(
				'[id^="inpc-loader-cir"],[id^="inpc-loader-m_cir"],[id^="inpc-loader-cir_"]'
			).forEach(function (el) {
				if (el && el.parentNode) el.parentNode.removeChild(el);
			});
		} catch (_e) { /* ignore */ }
	},

	_procedureContext: function () {
		if (Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	},

	_session: function (json) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return true;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return true;
		}
		return false;
	},

	_status: function (value, creditNoteNo, creditNoteDate) {
		var status = String(value || "");
		var kind = {
			"Rework": "warn",
			"Rejected": "danger",
			"Closed": "muted",
			"In Progress": "info"
		}[status] || "pending";
		var html = '<span class="cir-status ' + kind + '">' + Cir._escape(status) + "</span>";
		if (status === "Closed") {
			var note = String(creditNoteNo == null ? "" : creditNoteNo).trim();
			var date = String(creditNoteDate == null ? "" : creditNoteDate).trim();
			if (note || date) {
				var creditLine = note;
				if (note && date) creditLine += " - ";
				creditLine += date;
				html += '<div class="cir-credit-no">' + Cir._escape(creditLine) + "</div>";
			}
		}
		return html;
	},

	_formatAmount: function (value) {
		if (value == null || value === "") return "";
		var amount = Number(value);
		return Number.isFinite(amount)
			? amount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
			: String(value);
	},

	_message: function (message, isError) {
		var $message = Cir._$("#cir_message");
		$message.toggleClass("alert-danger", !!isError)
			.toggleClass("alert-success", !isError)
			.toggleClass("d-none", !message)
			.text(message || "");
	},

	_escape: function (value) {
		return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
			return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
		});
	}
};
