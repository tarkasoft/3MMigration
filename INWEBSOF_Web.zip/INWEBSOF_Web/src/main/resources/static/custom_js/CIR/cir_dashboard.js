/**
 * CIR customer dashboard. Loaded with cir.js / cir_home.html.
 * GET api/customer/cir/dashboard
 */
CirDashboard = {
	_api: "api/customer/cir",
	_loadSeq: 0,
	_loaded: false,
	_selectedYear: null,
	_statusChart: null,
	_mixColors: {
		"In Progress": "#168779",
		"Closed": "#3b82f6",
		"Rework": "#f59e0b",
		"Rejected": "#9ca3af"
	},

	Load: function () {
		if (!window.Cir) return;
		var $panel = Cir._$("#cir_dashboard_panel");
		if (!$panel.length) return;
		var seq = ++CirDashboard._loadSeq;
		CirDashboard._destroyStatusChart();
		Cir._showLoader("Loading dashboard...", Cir._hostId());
		$panel.load(
			(window.$app_url || "") + "html_files/CIR/cir_dashboard.html?r=" + Date.now(),
			function (_response, status) {
				if (seq !== CirDashboard._loadSeq) return;
				Cir._hideLoader(Cir._hostId());
				if (status !== "success") {
					$panel.html('<div class="alert alert-danger m-3">Unable to load CIR Dashboard.</div>');
					return;
				}
				CirDashboard._initYearSelect();
				CirDashboard._bindActions();
				CirDashboard._fetch(seq);
			});
	},

	Refresh: function () {
		CirDashboard._fetch(++CirDashboard._loadSeq);
	},

	_initYearSelect: function () {
		var current = new Date().getFullYear();
		var previous = current - 1;
		var selected = CirDashboard._selectedYear || current;
		if (selected !== current && selected !== previous) selected = current;
		CirDashboard._selectedYear = selected;
		var $year = Cir._$("#cir_dash_year");
		$year.empty()
			.append($("<option>").val(String(current)).text(String(current)))
			.append($("<option>").val(String(previous)).text(String(previous)))
			.val(String(selected));
	},

	_bindActions: function () {
		var $root = Cir._$("#m_cir_dashboard");
		$root.find("#cir_dash_refresh_btn").off("click.cirDash").on("click.cirDash", function () {
			CirDashboard.Refresh();
		});
		$root.find("#cir_dash_year").off("change.cirDash").on("change.cirDash", function () {
			CirDashboard._selectedYear = Number($(this).val()) || new Date().getFullYear();
			CirDashboard.Refresh();
		});
		$root.find("#cir_dash_new_btn").off("click.cirDash").on("click.cirDash", function () {
			if (window.Cir) Cir._activateTab("new");
		});
		$root.find("#cir_dash_all_btn").off("click.cirDash").on("click.cirDash", function () {
			if (window.Cir) Cir._activateTab("requests");
		});
		$root.off("click.cirDashView").on("click.cirDashView", ".cir-view-request", function () {
			var requestId = Number($(this).attr("data-request-id"));
			if (!Number.isSafeInteger(requestId) || requestId <= 0 || !window.Cir) return;
			Cir._pendingViewId = requestId;
			Cir._activateTab("requests");
		});
	},

	_fetch: function (seq) {
		var customer = (window.Cir && Cir._customer) || {};
		var year = CirDashboard._selectedYear || Number(Cir._$("#cir_dash_year").val()) || new Date().getFullYear();
		CirDashboard._selectedYear = year;
		if (typeof showLoader === "function") {
			showLoader("Loading dashboard...", "m_cir_dashboard");
		}
		$.ajax({
			url: (window.$app_url || "") + CirDashboard._api + "/dashboard",
			method: "GET",
			dataType: "json",
			data: $.extend({}, customer, { year: year }),
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (seq !== CirDashboard._loadSeq) return;
				if (window.Cir && Cir._session && Cir._session(json)) return;
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					Cir._$("#cir_dash_actions").html(
						'<div class="cir-dash-error">' +
						CirDashboard._escape((json && (json.message || json.status)) || "Unable to load dashboard.") +
						"</div>");
					Cir._$("#cir_dash_status_mix").html("");
					Cir._$("#cir_dash_recent_rows").html('<tr><td colspan="6" class="cir-dash-empty">—</td></tr>');
					return;
				}
				CirDashboard._render(json.data || {});
				CirDashboard._loaded = true;
			},
			error: function (xhr, status) {
				if (seq !== CirDashboard._loadSeq || status === "abort") return;
				Cir._$("#cir_dash_actions").html('<div class="cir-dash-error">Network error loading dashboard.</div>');
			},
			complete: function () {
				if (typeof hideLoader === "function") hideLoader("m_cir_dashboard");
			}
		});
	},

	_render: function (data) {
		var summary = data.summary || {};
		var year = Number(data.year) || CirDashboard._selectedYear || new Date().getFullYear();
		var currentYear = Number(data.current_year) || new Date().getFullYear();
		CirDashboard._selectedYear = year;
		if (Cir._$("#cir_dash_year").length && String(Cir._$("#cir_dash_year").val()) !== String(year)) {
			Cir._$("#cir_dash_year").val(String(year));
		}
		Cir._$("#cir_dash_cards [data-k]").each(function () {
			var key = $(this).attr("data-k");
			$(this).text(CirDashboard._count(summary[key]));
		});
		Cir._$("#cir_dash_closed_label").text(year === currentYear ? "Closed this month" : "Closed in " + year);
		Cir._$("#cir_dash_ytd_label").text(year === currentYear ? "Total claimed (YTD)" : "Total claimed (" + year + ")");
		Cir._$("#cir_dash_ytd").text("₹ " + CirDashboard._amount(summary.ytd_claim_amt));

		CirDashboard._renderStatusMix(summary);
		CirDashboard._renderActions(Array.isArray(data.action_items) ? data.action_items : []);
		CirDashboard._renderRecent(Array.isArray(data.recent_requests) ? data.recent_requests : []);
	},

	_renderStatusMix: function (summary) {
		var slices = [
			{ label: "In Progress", value: Number(summary.in_progress_count) || 0, color: CirDashboard._mixColors["In Progress"] },
			{ label: "Closed", value: Number(summary.closed_count) || 0, color: CirDashboard._mixColors.Closed },
			{ label: "Rework", value: Number(summary.rework_count) || 0, color: CirDashboard._mixColors.Rework },
			{ label: "Rejected", value: Number(summary.rejected_count) || 0, color: CirDashboard._mixColors.Rejected }
		];
		var total = 0;
		for (var i = 0; i < slices.length; i++) total += slices[i].value;
		var legend = "<ul class=\"cir-dash-legend\">";
		for (var s = 0; s < slices.length; s++) {
			var pct = total > 0 ? Math.round((slices[s].value * 100) / total) : 0;
			legend += '<li><span class="left"><span class="cir-dash-dot" style="background:' +
				slices[s].color + '"></span>' + CirDashboard._escape(slices[s].label) +
				'</span><strong>' + CirDashboard._count(slices[s].value) +
				" (" + pct + "%)</strong></li>";
		}
		legend += "</ul>";
		Cir._$("#cir_dash_status_mix").html('<div class="cir-dash-donut-wrap" id="cir_dash_status_chart"></div>' + legend);
		CirDashboard._renderStatusChart(slices, total);
	},

	_destroyStatusChart: function () {
		if (CirDashboard._statusChart) {
			try { CirDashboard._statusChart.destroy(); } catch (_e) { /* ignore */ }
			CirDashboard._statusChart = null;
		}
	},

	_renderStatusChart: function (slices, total) {
		CirDashboard._destroyStatusChart();
		var el = Cir._$("#cir_dash_status_chart").get(0);
		if (!el) return;
		if (typeof ApexCharts === "undefined") {
			el.innerHTML = '<div class="cir-dash-empty">Chart library not loaded.</div>';
			return;
		}
		var labels = [];
		var series = [];
		var colors = [];
		for (var i = 0; i < slices.length; i++) {
			labels.push(slices[i].label);
			series.push(slices[i].value);
			colors.push(slices[i].color);
		}
		var chartSeries = total > 0 ? series : [1];
		var chartLabels = total > 0 ? labels : ["No data"];
		var chartColors = total > 0 ? colors : ["#e5e7eb"];
		CirDashboard._statusChart = new ApexCharts(el, {
			chart: {
				type: "donut",
				height: 200,
				fontFamily: "inherit",
				foreColor: "#64748b",
				animations: { enabled: true, speed: 650 },
				toolbar: { show: false }
			},
			series: chartSeries,
			labels: chartLabels,
			colors: chartColors,
			stroke: { width: 2, colors: ["#fff"] },
			dataLabels: { enabled: false },
			legend: { show: false },
			tooltip: {
				enabled: total > 0,
				y: {
					formatter: function (val) {
						var pct = total > 0 ? Math.round((Number(val) * 100) / total) : 0;
						return CirDashboard._count(val) + " (" + pct + "%)";
					}
				}
			},
			states: {
				hover: { filter: { type: "lighten", value: 0.08 } },
				active: { filter: { type: "darken", value: 0.12 } }
			},
			plotOptions: {
				pie: {
					expandOnClick: total > 0,
					donut: {
						size: "68%",
						labels: {
							show: true,
							name: { show: true, fontSize: "12px", color: "#6b7280", offsetY: -2 },
							value: {
								show: true,
								fontSize: "1.35rem",
								fontWeight: 750,
								color: "#111827",
								offsetY: 4,
								formatter: function (v) {
									return total > 0 ? CirDashboard._count(v) : "0";
								}
							},
							total: {
								show: true,
								showAlways: true,
								label: "Total",
								fontSize: "12px",
								fontWeight: 600,
								color: "#6b7280",
								formatter: function () {
									return CirDashboard._count(total);
								}
							}
						}
					}
				}
			}
		});
		CirDashboard._statusChart.render();
	},

	_renderActions: function (actions) {
		if (!actions.length) {
			Cir._$("#cir_dash_actions").html('<div class="cir-dash-empty">No items need your attention.</div>');
			return;
		}
		var html = "";
		for (var a = 0; a < actions.length; a++) {
			var row = actions[a] || {};
			var type = String(row.action_type || "Action");
			var badgeClass = /clarif/i.test(type) ? "clarification" : "rework";
			html += '<div class="cir-dash-action">' +
				'<div class="meta"><span class="id">' + CirDashboard._escape(row.cir_no) + "</span>" +
				'<span class="submitted">Submitted on ' + CirDashboard._escape(CirDashboard._prettyDate(row.cir_date)) +
				"</span></div>" +
				'<div class="reason">' + CirDashboard._escape(row.customer_reason || row.invoice_no || "—") + "</div>" +
				'<span class="cir-dash-badge ' + badgeClass + '">' + CirDashboard._escape(type) + "</span>" +
				'<button type="button" class="cir-dash-link cir-view-request" data-request-id="' +
				CirDashboard._escape(row.internal_code) + '">View &gt;</button></div>';
		}
		Cir._$("#cir_dash_actions").html(html);
	},

	_renderRecent: function (recent) {
		if (!recent.length) {
			Cir._$("#cir_dash_recent_rows").html('<tr><td colspan="6" class="cir-dash-empty">No CIR requests found.</td></tr>');
			return;
		}
		var html = "";
		for (var r = 0; r < recent.length; r++) {
			var item = recent[r] || {};
			var credit = String(item.credit_note_no || "").trim() || "—";
			html += "<tr>" +
				'<td><button type="button" class="cir-dash-link cir-view-request" data-request-id="' +
				CirDashboard._escape(item.internal_code) + '">View &gt;</button></td>' +
				"<td>" + CirDashboard._escape(item.cir_no) + "</td>" +
				"<td>" + CirDashboard._escape(item.invoice_no || "—") + "</td>" +
				'<td class="cir-num">₹ ' + CirDashboard._escape(CirDashboard._amount(item.total_amt)) + "</td>" +
				"<td>" + CirDashboard._statusPill(item.ui_status) + "</td>" +
				"<td>" + CirDashboard._escape(credit) + "</td></tr>";
		}
		Cir._$("#cir_dash_recent_rows").html(html);
	},

	_statusPill: function (value) {
		var status = String(value || "");
		var kind = {
			"Rework": "warn",
			"Rejected": "danger",
			"Closed": "muted",
			"In Progress": "info"
		}[status] || "muted";
		return '<span class="cir-status ' + kind + '">' + CirDashboard._escape(status || "—") + "</span>";
	},

	_prettyDate: function (value) {
		var raw = String(value || "").trim();
		if (!raw) return "—";
		// Accept dd/MM/yyyy from API
		var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(raw);
		if (m) {
			var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			var month = months[Number(m[2]) - 1] || m[2];
			return Number(m[1]) + " " + month + " " + m[3];
		}
		return raw;
	},

	_count: function (value) {
		var n = Number(value);
		return Number.isFinite(n) ? String(Math.round(n)) : "0";
	},

	_amount: function (value) {
		if (window.Cir && typeof Cir._formatAmount === "function") {
			return Cir._formatAmount(value) || "0.00";
		}
		var n = Number(value);
		return Number.isFinite(n)
			? n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
			: "0.00";
	},

	_escape: function (value) {
		if (window.Cir && typeof Cir._escape === "function") return Cir._escape(value);
		return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
			return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
		});
	}
};
