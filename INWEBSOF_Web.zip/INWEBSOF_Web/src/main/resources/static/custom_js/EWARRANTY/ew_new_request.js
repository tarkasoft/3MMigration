/**
 * Converter Request New Warranty — plain jQuery.
 * Host: m_ew_new_request under m_ew_conv_home.
 */
EwNewRequest = {
	API: "api/customer/ewarranty/new-request",
	HOME: "m_ew_new_request",
	CHAIN: [
		"application",
		"graphic_conv_method",
		"type_of_exposure",
		"substrate",
		"m_flexible_substrate",
		"vinyl",
		"overlaminate",
		"printer_format",
		"printing_hardware",
		"ink"
	],
	TEMPLATES: [
		{ flag: "special_warranty_graphics", name: "Special Warranty - Graphics" },
		{ flag: "mcs_warranty_printed", name: "MCS Warranty-Printed" },
		{ flag: "mcs_warranty_colored_signage", name: "MCS Warranty-Colored & Signage" },
		{ flag: "building_window_film_warranty", name: "Building Window Film Warranty" },
		{ flag: "paint_protection_film", name: "Paint Protection Film" },
		{ flag: "di_noc_warranty", name: "DI-NOC Warranty" }
	],
	lookupData: [],
	prodMaster: [],
	_acAjax: {},

	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + EwNewRequest.HOME) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $conv = window.EwConv && typeof EwConv._$home === "function" ? EwConv._$home() : $();
		if ($conv && $conv.length) {
			var $in = $conv.find("#" + EwNewRequest.HOME);
			if ($in.length) {
				return $in.first();
			}
		}
		var $visible = $("#" + EwNewRequest.HOME).filter(":visible");
		return $visible.length ? $visible.first() : $("#" + EwNewRequest.HOME).first();
	},

	_$: function (selector) {
		var $home = EwNewRequest._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		return $home.find(selector);
	},

	ctx: function () {
		return window.EwConv
			? { custCode: EwConv.custCode, loginId: EwConv.loginId }
			: EwCommon.procedureContext();
	},

	apiUrl: function (suffix) {
		var ctx = EwNewRequest.ctx();
		return (window.$app_url || "") + EwNewRequest.API + suffix
			+ (suffix.indexOf("?") >= 0 ? "&" : "?")
			+ "custCode=" + encodeURIComponent(ctx.custCode || "")
			+ "&loginId=" + encodeURIComponent(ctx.loginId || "");
	},

	Load: function () {
		EwNewRequest.ensureFragments(function () {
			if (window.EwCommon && typeof EwCommon.bindPortalDates === "function") {
				EwCommon.bindPortalDates();
			}
			EwNewRequest.bindHost();
			EwNewRequest.loadOnload();
		});
	},

	ensureFragments: function (done) {
		if (EwNewRequest._$("#ew_shared_products").length
				&& EwNewRequest._$("#ew_ppf_product").length) {
			EwNewRequest.buildSlots();
			if (typeof done === "function") {
				done();
			}
			return;
		}
		var base = (window.$app_url || "") + "html_files/EWARRANTY/";
		showLoader("Loading Request New Warranty...", EwConv.HOME);
		EwNewRequest._$("#ew_products_host").load(base + "ew_req_products.html?r=" + Date.now(), function (_h, st1) {
			if (st1 !== "success") {
				hideLoader(EwConv.HOME);
				EwNewRequest.showMsg("Unable to load product screens.", true);
				return;
			}
			EwNewRequest._$("#ew_ppf_host").load(base + "ew_req_ppf.html?r=" + Date.now(), function (_h2, st2) {
				hideLoader(EwConv.HOME);
				if (st2 !== "success") {
					EwNewRequest.showMsg("Unable to load PPF screen.", true);
					return;
				}
				EwNewRequest.buildSlots();
				if (typeof done === "function") {
					done();
				}
			});
		});
	},

	buildSlots: function () {
		var tpl = EwNewRequest._$("#ew_prod_slot_tpl").get(0);
		if (!tpl) {
			return;
		}
		EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel").each(function () {
			var $panel = $(this);
			if (!$panel.children().length) {
				$panel.append($(tpl.content.cloneNode(true)));
			}
			EwNewRequest.stampSlotIds($panel);
		});
	},

	stampSlotIds: function ($panel) {
		var slot = String($panel.attr("data-slot") || "1");
		/* Cascade / life fields only — vinyl multi-rows stamped per line. */
		$panel.find("[class*='ew-p-']").not(".ew-gfx-vinyl-line *, .ew-gfx-sec-vinyl-line *").each(function () {
			var match = String(this.className || "").match(/(?:^|\s)(ew-p-[\w]+)/);
			if (!match) {
				return;
			}
			this.id = "ew_p" + slot + "_" + match[1].replace("ew-p-", "");
		});
	},

	isBwfOrDinoc: function (template) {
		var t = String(template || EwNewRequest._$("#ew_wrty_template").val() || "");
		return t === "Building Window Film Warranty" || t === "DI-NOC Warranty";
	},

	bindHost: function () {
		EwNewRequest._$("#ew_wrty_template").off("change.ewnr").on("change.ewnr", function () {
			EwNewRequest.onTemplateChange();
		});
		EwNewRequest._$("#ew_no_of_products").off("change.ewnr").on("change.ewnr", function () {
			/* Legacy: onchange='EWReqWarranty.AssignTabsForProducts();' */
			EwNewRequest.assignTabsForProducts(true);
		});
		EwNewRequest._$("#ew_prod_tabs").off("click.ewnr", "button").on("click.ewnr", "button", function () {
			var slot = Number($(this).attr("data-slot") || "1");
			EwNewRequest.activateSlot(slot);
		});
		EwNewRequest.captureNoOfProducts();
		EwNewRequest._$("#ew_nr_draft").off("click.ewnr").on("click.ewnr", function () {
			EwNewRequest.save("Draft");
		});
		EwNewRequest._$("#ew_nr_submit").off("click.ewnr").on("click.ewnr", function () {
			EwNewRequest.save("Submit");
		});
		EwNewRequest._$home().off("input.ewerr change.ewerr", "input, select, textarea")
			.on("input.ewerr change.ewerr", "input, select, textarea", function () {
				var $el = $(this);
				if ($el.hasClass("is-invalid") || $el.hasClass("ew-nr-invalid")) {
					if (String($el.val() || "").trim()) {
						$el.removeClass("is-invalid ew-nr-invalid");
					}
				}
			});
		EwNewRequest._$home().off("blur.ewppfbill", ".ew-ppf-bill").on("blur.ewppfbill", ".ew-ppf-bill", function () {
			EwNewRequest.assignPpfVehicleInfo();
		});
		EwNewRequest.wirePartyAutocomplete("ew_distributor", "distributors", "ew_dist_int_code", true);
		EwNewRequest.wirePartyAutocomplete("ew_customer", "customers", "ew_cust_int_code", false);
		EwNewRequest.wirePartyAutocomplete("ew_applicator", "applicators", "ew_applicator_int_code", false);
		EwNewRequest.wireSegmentLeaderAutocomplete();
		EwNewRequest._$("#ew_ppf_application").off("change.ewtoapp").on("change.ewtoapp", function () {
			EwNewRequest.togglePartialRemarks();
		});
		var $home = EwNewRequest._$home();
		if (window.EwCommon && typeof EwCommon.bindPortalDates === "function") {
			EwCommon.bindPortalDates();
		}
		$home.off("click.ewnrdate", ".ew-nr-date-btn").on("click.ewnrdate", ".ew-nr-date-btn", function (event) {
			event.preventDefault();
			event.stopPropagation();
			EwNewRequest.openDate(String($(this).attr("data-date-id")
				|| $(this).closest(".input-group").find("input.datepicker").attr("id")
				|| "ew_date_of_inst"));
		});
		EwNewRequest.bindDatePickers();
	},

	bindDatePickers: function () {
		/* Do not pre-bind. Bootstrap datepicker can mark the field readonly;
		   CallTarkaDatePickerNew then exits. Open on icon click only. */
	},

	openDate: function (fieldId) {
		if (window.EwCommon && typeof EwCommon.openModuleDate === "function") {
			return EwCommon.openModuleDate("ew_new_request", fieldId);
		}
		return false;
	},

	openInstallDate: function () {
		EwNewRequest.openDate("ew_date_of_inst");
	},

	loadOnload: function () {
		var ctx = EwNewRequest.ctx();
		showLoader("Loading warranty form...", EwConv.HOME);
		$.ajax({
			url: (window.$app_url || "") + EwNewRequest.API + "/onload",
			method: "GET",
			data: ctx,
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			hideLoader(EwConv.HOME);
			if (EwCommon.isSessionGone(json)) {
				return;
			}
			if (!EwCommon.ok(json)) {
				EwNewRequest.showMsg((json && json.message) || "Unable to load New Request.", true);
				return;
			}
			var data = json.data || {};
			EwNewRequest.lookupData = data.lookupData || [];
			EwNewRequest.prodMaster = data.prodMasterDataSet || [];
			EwNewRequest._$("#ew_auto_closed").val(data.auto_closed || "");
			var approvers = data.converter_approver_object || [];
			if (approvers.length) {
				EwNewRequest._$("#ew_asm_kam_approver").val(approvers[0].asm_kam_enl || "");
			}
			EwNewRequest.fillTemplates(data.warranty_templates || []);
			EwNewRequest.fillLookups();
			EwNewRequest.fillStates(data.stateDataSet || []);
			EwNewRequest.onTemplateChange();
		}).fail(function () {
			hideLoader(EwConv.HOME);
			EwNewRequest.showMsg("Unable to load New Request.", true);
		});
	},

	fillTemplates: function (rows) {
		var flags = rows[0] || {};
		var $sel = EwNewRequest._$("#ew_wrty_template").empty();
		$sel.append('<option value="">Select</option>');
		EwNewRequest.TEMPLATES.forEach(function (item) {
			var raw = flags[item.flag];
			var n = Number(raw);
			var s = String(raw == null ? "" : raw).toLowerCase();
			if (n === 1 || s === "1" || s === "true" || s === "yes") {
				$sel.append($("<option></option>").val(item.name).text(item.name));
			}
		});
	},

	fillLookups: function () {
		EwNewRequest._$("[data-lookup]").each(function () {
			var key = String($(this).attr("data-lookup") || "");
			EwNewRequest.fillSelect($(this), EwNewRequest.lookupValues(key));
		});
	},

	lookupValues: function (lookupKey) {
		var key = String(lookupKey || "").toLowerCase();
		var out = [];
		var seen = {};
		(EwNewRequest.lookupData || []).forEach(function (row) {
			if (String(row.lookupKey || "").toLowerCase() !== key) {
				return;
			}
			var val = String(row.lookupValue || "");
			if (!val || seen[val]) {
				return;
			}
			seen[val] = true;
			out.push(val);
		});
		return out;
	},

	fillStates: function (rows) {
		var ids = ["#ew_state", "#ew_ppf_cust_state"];
		ids.forEach(function (id) {
			var $sel = EwNewRequest._$(id).empty().append(
				id === "#ew_ppf_cust_state" ? '<option value="">Select State</option>' : '<option value="">Select</option>'
			);
			(rows || []).forEach(function (row) {
				var name = String(row.name || "");
				$sel.append($("<option></option>").val(name).text(name));
			});
		});
	},

	fillSelect: function ($sel, values) {
		var current = $sel.val();
		var first = $sel.attr("id") === "ew_ppf_application" ? "Select Type of Application" : "Select";
		$sel.empty().append('<option value="">' + first + "</option>");
		(values || []).forEach(function (val) {
			if (!val) {
				return;
			}
			$sel.append($("<option></option>").val(val).text(val));
		});
		if (current && $sel.find("option[value='" + current.replace(/'/g, "\\'") + "']").length) {
			$sel.val(current);
		}
		if (values && values.length === 1) {
			$sel.val(values[0]);
		}
	},

	isPpf: function () {
		return EwNewRequest._$("#ew_wrty_template").val() === "Paint Protection Film";
	},

	assignPpfVehicleInfo: function () {
		if (!EwNewRequest.isPpf()) {
			return;
		}
		EwNewRequest._$("#ew_v_end_cust_name").val(EwNewRequest._$("#ew_ppf_cust_company_name").val());
		EwNewRequest._$("#ew_v_address_1").val(EwNewRequest._$("#ew_ppf_cust_address_1").val());
		EwNewRequest._$("#ew_v_address_2").val(EwNewRequest._$("#ew_ppf_cust_address_2").val());
		EwNewRequest._$("#ew_v_city").val(EwNewRequest._$("#ew_ppf_cust_city").val());
		EwNewRequest._$("#ew_v_state").val(EwNewRequest._$("#ew_ppf_cust_state").val());
		EwNewRequest._$("#ew_v_postal_code").val(EwNewRequest._$("#ew_ppf_cust_pin").val());
		EwNewRequest._$("#ew_v_email_id").val(EwNewRequest._$("#ew_ppf_cust_email").val());
		EwNewRequest._$("#ew_v_cust_mob_no").val(EwNewRequest._$("#ew_ppf_cust_phone").val());
	},

	/**
	 * Legacy EWReqWarranty.ActionsOnChangeWarrantyTemplate — host + product family
	 * for all 6 Warranty Template values.
	 */
	onTemplateChange: function () {
		var ppf = EwNewRequest.isPpf();
		var template = String(EwNewRequest._$("#ew_wrty_template").val() || "");
		var dinoc = template === "DI-NOC Warranty";
		EwNewRequest._$home().toggleClass("is-ppf", ppf);
		EwNewRequest._$("#ew_applicator_lbl").text("Applicator/Store");
		EwNewRequest._$("#ew_ppf_host").toggleClass("d-none", !ppf);
		EwNewRequest._$("#ew_products_host").toggleClass("d-none", ppf);
		EwNewRequest._$("#ew_dist_invoice_section").toggleClass("d-none", ppf);
		EwNewRequest._$("#ew_no_of_products").prop("disabled", ppf || dinoc);
		EwNewRequest._$("input[name='ew_inst_mode']").off("change.ewinst").on("change.ewinst", function () {
			EwNewRequest.onInstTypeChange();
		});
		if (ppf) {
			/* PPF: applicator + Vehicle; hide dist / invoice / print service / multi-product. */
			EwNewRequest._$("#ew_distributor_details").empty();
			EwNewRequest._$("#ew_dist_invoice_host").empty();
			EwNewRequest._$("#ew_no_of_products").val("1");
			EwNewRequest._$("#ew_no_of_products_wrap").removeClass("d-none");
			EwNewRequest._$("#ew_print_service_wrap").removeClass("d-none");
			EwNewRequest._$("#ew_vehicle_radio").prop("checked", true);
			EwNewRequest._$("#ew_non_vehicle_radio").prop("disabled", true);
			EwNewRequest.onInstTypeChange();
			EwNewRequest.wirePpfProduct();
			EwNewRequest.bindDatePickers();
			EwNewRequest.togglePartialRemarks();
		} else {
			/* Graphics families: Dist + invoice; Address of Installation default; hide applicator. */
			EwNewRequest._$("#ew_applicator_details").empty();
			EwNewRequest._$("#ew_applicator").val("");
			EwNewRequest._$("#ew_applicator_int_code").val("");
			EwNewRequest._$("#ew_non_vehicle_radio").prop("disabled", false).prop("checked", true);
			EwNewRequest._$("#ew_vehicle_radio").prop("checked", false);
			EwNewRequest.onInstTypeChange();
			if (dinoc) {
				EwNewRequest._$("#ew_no_of_products").val("1");
			}
			EwNewRequest.loadGraphicsInvoice(function () {
				EwNewRequest.applyFamilyLabels(template);
				EwNewRequest.assignTabsForProducts(false);
				EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel").each(function () {
					var $panel = $(this);
					var slot = Number($panel.attr("data-slot") || "0");
					var n = Number(EwNewRequest._$("#ew_no_of_products").val() || "1");
					if (slot < 1 || slot > n) {
						return;
					}
					if ($panel.data("ewWired")) {
						EwNewRequest.resetSlotCascade($panel);
					} else {
						EwNewRequest.wireSlot($panel);
					}
				});
				EwNewRequest.bindDatePickers();
			});
		}
	},

	loadGraphicsInvoice: function (done) {
		var $host = EwNewRequest._$("#ew_dist_invoice_host");
		if (!$host.length) {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		if ($host.find("#ew_gfx_invoice_block").length) {
			EwNewRequest.wireGraphicsInvoice();
			if (typeof done === "function") {
				done();
			}
			return;
		}
		var url = (window.$app_url || "") + "html_files/EWARRANTY/ew_dist_cust_graphics_invoice_details.html?r="
			+ Date.now();
		$host.load(url, function (_h, st) {
			if (st !== "success") {
				EwNewRequest.showMsg("Unable to load distributor invoice details.", true);
			} else {
				EwNewRequest.wireGraphicsInvoice();
			}
			if (typeof done === "function") {
				done();
			}
		});
	},

	wireGraphicsInvoice: function () {
		var $host = EwNewRequest._$("#ew_dist_invoice_host");
		if (!$host.length) {
			return;
		}
		var $tbody = EwNewRequest._$("#ew_gfx_addnl_lines");
		if (!$tbody.children().length) {
			EwNewRequest.addGfxInvoiceLine();
		}
		$host.off("click.ewaddnl", ".ew-gfx-addnl-add").on("click.ewaddnl", ".ew-gfx-addnl-add", function (e) {
			if (e) {
				e.preventDefault();
			}
			EwNewRequest.addGfxInvoiceLine();
		});
		$host.off("click.ewaddnldel", ".ew-gfx-addnl-del").on("click.ewaddnldel", ".ew-gfx-addnl-del", function () {
			$(this).closest("tr").remove();
			EwNewRequest.refreshGfxInvoiceActions();
		});
		$host.off("click.ewaddnldate", ".ew-gfx-addnl-date-btn").on("click.ewaddnldate", ".ew-gfx-addnl-date-btn", function (e) {
			e.preventDefault();
			var $inp = $(this).closest(".input-group").find(".ew-gfx-addnl-inv-date");
			if ($inp.length && typeof EwCommon.openModuleDate === "function") {
				/* openModuleDate needs id — stamp if missing */
				if (!$inp.attr("id")) {
					$inp.attr("id", "ew_gfx_addnl_date_" + Date.now());
				}
				return EwCommon.openModuleDate("ew_new_request", $inp.attr("id"));
			}
			return false;
		});
		EwNewRequest.bindPpfDocuments($host);
		EwNewRequest.bindDatePickers();
	},

	addGfxInvoiceLine: function () {
		var tpl = EwNewRequest._$("#ew_gfx_addnl_line_tpl").get(0);
		if (!tpl || !tpl.content) {
			return;
		}
		var $rows = EwNewRequest._$("#ew_gfx_addnl_lines .ew-gfx-addnl-line");
		if ($rows.length >= 5) {
			EwNewRequest.showMsg("Maximum 5 distributor invoices allowed.", true);
			return;
		}
		var $row = $(tpl.content.cloneNode(true)).find("tr");
		var n = $rows.length + 1;
		$row.find(".ew-doc-field").attr("data-ew-doc", "gfx_addnl_" + n);
		$row.find(".ew-gfx-addnl-inv-date").attr("id", "ew_gfx_addnl_date_" + n + "_" + Date.now());
		EwNewRequest._$("#ew_gfx_addnl_lines").append($row);
		EwNewRequest.refreshGfxInvoiceActions();
		EwNewRequest.bindDatePickers();
	},

	refreshGfxInvoiceActions: function () {
		var $rows = EwNewRequest._$("#ew_gfx_addnl_lines .ew-gfx-addnl-line");
		$rows.find(".ew-gfx-addnl-del").toggleClass("d-none", $rows.length < 2);
		$rows.find(".ew-gfx-addnl-add").addClass("d-none");
		$rows.last().find(".ew-gfx-addnl-add").removeClass("d-none");
	},

	/**
	 * Legacy ChangeLabelsBasedOnWarranty + HideForBuildingOrDiNoc + DI-NOC host bits.
	 * Templates:
	 *  - Special Warranty - Graphics / MCS Warranty-Printed / MCS Warranty-Colored & Signage
	 *  - Building Window Film Warranty
	 *  - DI-NOC Warranty
	 *  - Paint Protection Film (handled in onTemplateChange / is-ppf)
	 */
	applyFamilyLabels: function (template) {
		var t = String(template || "");
		var bwf = t === "Building Window Film Warranty";
		var dinoc = t === "DI-NOC Warranty";
		/* HideForBuildingOrDiNoc: graphic_conv, flexible-substrate block, sec vinyl, overlam, printing. */
		var hideBwfBlocks = bwf || dinoc;
		var hideColor = bwf || dinoc;
		var labels;
		if (bwf) {
			labels = {
				title: "Building Window Film Information",
				film: "3M Building Window Film Series",
				lot: "3M Building Window Film LOT NO.",
				qty: "3M Building Window Film Quantity (sq.ft)"
			};
		} else if (dinoc) {
			labels = {
				title: "DI-NOC Information",
				film: "3M DI-NOC Series",
				lot: "3M DI-NOC LOT NO.",
				qty: "3M DI-NOC Quantity (sq.ft)"
			};
		} else {
			/* Special Warranty - Graphics, MCS Printed, MCS Colored & Signage */
			labels = {
				title: "3M Primary Film / Vinyl 1 Information",
				film: "3M Primary Film / Vinyl 1",
				lot: "3M Primary Film Lot No",
				qty: "3M Primary Film / Vinyl 1 Quantity (sq.ft)",
				color: "3M Primary Film / Vinyl 1 Color"
			};
		}
		EwNewRequest._$(".ew-nr-print").toggleClass("d-none", hideBwfBlocks);
		EwNewRequest._$(".ew-gfx-hide-bwf").toggleClass("d-none", hideBwfBlocks);
		EwNewRequest._$(".ew-gfx-sec-vinyl-block").toggleClass("d-none", hideBwfBlocks);
		EwNewRequest._$(".ew-gfx-color-col").toggleClass("d-none", hideColor);
		EwNewRequest._$(".ew-gfx-edge-sealer").toggleClass("d-none", !hideBwfBlocks);
		EwNewRequest._$(".ew-p-vinyl-block-title").text(labels.title);
		EwNewRequest._$(".ew-p-vinyl-th").html(labels.film + ' <span class="ew-nr-req">*</span>');
		EwNewRequest._$(".ew-p-vinyl-lot-th").text(labels.lot);
		EwNewRequest._$(".ew-p-vinyl-qty-th").text(labels.qty);
		if (labels.color) {
			EwNewRequest._$(".ew-p-vinyl-color-th").text(labels.color);
		}
		/* Tab labels — legacy product_li_N_a */
		if (dinoc) {
			EwNewRequest._$("#ew_no_of_products").val("1");
			EwNewRequest._$("#ew_prod_tabs button[data-slot='1']").text("Di-Noc Installation");
		} else {
			EwNewRequest._$("#ew_prod_tabs button").each(function () {
				var slot = Number($(this).attr("data-slot") || "1");
				$(this).text("Graphic Element" + slot + " / Signage" + slot);
			});
		}
		if (hideBwfBlocks) {
			EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel").each(function () {
				var $p = $(this);
				$p.find(".ew-p-graphic_conv_method").val("NA");
				$p.find(".ew-p-sec_vinyl").val("NA");
			});
		}
		/* Host: DI-NOC hides Print Service + No. of Graphic Elements (legacy no_of_products_div / Print_Service_Provider_div). */
		EwNewRequest._$("#ew_print_service_wrap").toggleClass("d-none", dinoc);
		EwNewRequest._$("#ew_no_of_products_wrap").toggleClass("d-none", dinoc);
		EwNewRequest._$("#ew_no_of_products").prop("disabled", dinoc);
	},

	captureNoOfProducts: function () {
		var $sel = EwNewRequest._$("#ew_no_of_products");
		if ($sel.length) {
			$sel.attr("data-previous-val", String($sel.val() || "1"));
		}
	},

	/**
	 * Legacy EWReqWarranty.AssignTabsForProducts — show product tabs 1..N,
	 * confirm when changing count, refresh LOVs / cascade for visible slots.
	 * @param {boolean} askConfirm — true when user changes No. of products
	 */
	assignTabsForProducts: function (askConfirm) {
		var $sel = EwNewRequest._$("#ew_no_of_products");
		var n = Number($sel.val() || "1");
		if (n < 1) {
			n = 1;
		}
		if (n > 5) {
			n = 5;
		}
		var previous = Number($sel.attr("data-previous-val") || "0");
		var template = String(EwNewRequest._$("#ew_wrty_template").val() || "");

		/* Hide 2–5 first (legacy), then show 1..N if confirmed. */
		EwNewRequest._$("#ew_prod_tabs button").each(function () {
			var slot = Number($(this).attr("data-slot") || "0");
			$(this).closest("li").toggle(slot === 1);
		});

		if (askConfirm && previous > 0 && previous !== n) {
			var applyTabs = function (count) {
				EwNewRequest._applyProductTabs(count, template, askConfirm, previous);
			};
			var cancelChange = function () {
				$sel.val(String(previous));
				EwNewRequest._applyProductTabs(previous, template, false, previous);
			};
			if (window.Swal && typeof Swal.fire === "function") {
				Swal.fire({
					title: "Change No. of Graphic Elements?",
					text: "All entered Product Details will be deleted. Do you want to change?",
					icon: "warning",
					showCancelButton: true,
					confirmButtonText: "Yes, change",
					cancelButtonText: "Cancel",
					confirmButtonColor: "#d33",
					cancelButtonColor: "#94a3b8",
					reverseButtons: true,
					focusCancel: true
				}).then(function (result) {
					if (result && result.isConfirmed) {
						applyTabs(n);
					} else {
						cancelChange();
					}
				});
				if (window.jQuery) {
					$(".swal2-container").css("z-index", "22222229999");
				}
				return;
			}
			var ok = window.confirm("All entered Product Details will be deleted. Do you want to change?");
			if (!ok) {
				$sel.val(String(previous));
				n = previous;
			}
		}

		EwNewRequest._applyProductTabs(n, template, askConfirm, previous);
	},

	_applyProductTabs: function (n, template, askConfirm, previous) {
		EwNewRequest._$("#ew_prod_tabs button").each(function () {
			var slot = Number($(this).attr("data-slot") || "0");
			$(this).closest("li").toggle(slot >= 1 && slot <= n);
		});

		EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel").each(function () {
			var $panel = $(this);
			var slot = Number($panel.attr("data-slot") || "0");
			if (slot < 1 || slot > n) {
				$panel.removeClass("active");
				return;
			}
			if (!$panel.data("ewWired")) {
				EwNewRequest.wireSlot($panel);
			} else if (askConfirm && previous > 0 && previous !== n) {
				/* User confirmed count change — clear product details like legacy. */
				EwNewRequest.resetSlotCascade($panel);
			} else if (!$panel.find(".ew-p-vinyl-lines .ew-gfx-vinyl-line").length) {
				EwNewRequest.resetSlotCascade($panel);
			}
			$panel.find(".ew-gfx-edge-sealer").addClass("d-none");
			$panel.find(".ew-p-sec_vinyl").val("NA");
		});

		EwNewRequest.applyFamilyLabels(template);
		EwNewRequest.activateSlot(1);
		EwNewRequest.captureNoOfProducts();
	},

	showProductSlots: function () {
		EwNewRequest.assignTabsForProducts(false);
	},

	activateSlot: function (slot) {
		EwNewRequest._$("#ew_prod_tabs button").removeClass("active");
		EwNewRequest._$("#ew_prod_tabs button[data-slot='" + slot + "']").addClass("active");
		EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel").removeClass("active");
		EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel[data-slot='" + slot + "']").addClass("active");
	},

	wireSlot: function ($panel) {
		if ($panel.data("ewWired")) {
			return;
		}
		$panel.data("ewWired", true);
		$panel.find("select[data-life]").on("change", function () {
			var col = String($(this).attr("data-life") || "");
			EwNewRequest.onLifeChange($panel, col);
		});
		$panel.off("click.ewgfxv", ".ew-gfx-vinyl-add").on("click.ewgfxv", ".ew-gfx-vinyl-add", function (e) {
			if (e) {
				e.preventDefault();
			}
			/* Lot / qty not required before add. */
			EwNewRequest.addGfxVinylLine($panel);
		});
		$panel.off("click.ewgfxvd", ".ew-gfx-vinyl-del").on("click.ewgfxvd", ".ew-gfx-vinyl-del", function () {
			$(this).closest("tr").remove();
			EwNewRequest.refreshGfxVinylActions($panel);
		});
		$panel.off("click.ewgfxs", ".ew-gfx-sec-add").on("click.ewgfxs", ".ew-gfx-sec-add", function (e) {
			if (e) {
				e.preventDefault();
			}
			EwNewRequest.addGfxSecVinylLine($panel);
		});
		$panel.off("click.ewgfxsd", ".ew-gfx-sec-del").on("click.ewgfxsd", ".ew-gfx-sec-del", function () {
			$(this).closest("tr").remove();
			EwNewRequest.refreshGfxSecVinylActions($panel);
		});
		$panel.off("click.ewrecheck", ".ew-p-recheck-life").on("click.ewrecheck", ".ew-p-recheck-life", function () {
			EwNewRequest.calcLife($panel);
		});
		$panel.off("blur.ewpoi change.ewpoi", ".ew-p-poi-width, .ew-p-poi-height, .ew-p-poi-unit")
			.on("blur.ewpoi change.ewpoi", ".ew-p-poi-width, .ew-p-poi-height, .ew-p-poi-unit", function () {
				EwNewRequest.updatePoiArea($panel);
			});
		$panel.find("[data-lookup]").each(function () {
			EwNewRequest.fillSelect($(this), EwNewRequest.lookupValues($(this).attr("data-lookup")));
		});
		EwNewRequest.bindPpfDocuments($panel);
		EwNewRequest.resetSlotCascade($panel);
	},

	updatePoiArea: function ($panel) {
		var w = parseFloat(String($panel.find(".ew-p-poi-width").val() || "").replace(/,/g, ""));
		var h = parseFloat(String($panel.find(".ew-p-poi-height").val() || "").replace(/,/g, ""));
		if (!isFinite(w) || !isFinite(h) || w <= 0 || h <= 0) {
			$panel.find(".ew-p-poi-area").val("");
			return;
		}
		var area = Math.round(w * h * 100) / 100;
		$panel.find(".ew-p-poi-area").val(String(area));
	},

	resetSlotCascade: function ($panel) {
		$panel.find("select[data-life]").each(function () {
			$(this).empty().append('<option value="">Select</option>');
		});
		$panel.find(".ew-p-warranty_life").val("");
		$panel.find(".ew-p-vinyl-lines").empty();
		$panel.find(".ew-p-sec-vinyl-lines").empty();
		EwNewRequest.addGfxVinylLine($panel);
		if (!EwNewRequest.isBwfOrDinoc()) {
			EwNewRequest.addGfxSecVinylLine($panel);
		}
		EwNewRequest.cascadeField($panel, "application");
	},

	addGfxVinylLine: function ($panel) {
		var tpl = EwNewRequest._$("#ew_gfx_vinyl_line_tpl").get(0);
		if (!tpl || !tpl.content) {
			return;
		}
		var $tbody = $panel.find(".ew-p-vinyl-lines");
		var $rows = $tbody.find(".ew-gfx-vinyl-line");
		if ($rows.length >= 5) {
			EwNewRequest.showMsg("Maximum 5 film lines per product.", true);
			return;
		}
		var firstName = String($rows.first().find(".ew-p-vinyl").val() || "").trim();
		var firstColor = String($rows.first().find(".ew-p-vinyl_color").val() || "");
		var $row = $(tpl.content.cloneNode(true)).find("tr");
		$tbody.append($row);
		var $name = $row.find(".ew-p-vinyl");
		if ($rows.length === 0) {
			EwNewRequest.wireVinylAc($name, "vinyl", $panel);
			$name.off("change.ewgfxsync input.ewgfxsync").on("change.ewgfxsync input.ewgfxsync", function () {
				EwNewRequest.syncGfxVinylToExtraRows($panel);
			});
		} else {
			/* Legacy AddVinylGroupRow — all families: copy first-row film, disable rows 2+. */
			$name.val(firstName).prop("disabled", true)
				.attr("title", "Same as first film row for this product");
			$row.find(".ew-p-vinyl_color").val(firstColor);
		}
		EwNewRequest.refreshGfxVinylActions($panel);
	},

	syncGfxVinylToExtraRows: function ($panel) {
		var $rows = $panel.find(".ew-p-vinyl-lines .ew-gfx-vinyl-line");
		if ($rows.length < 2) {
			return;
		}
		var firstName = String($rows.first().find(".ew-p-vinyl").val() || "");
		var firstColor = String($rows.first().find(".ew-p-vinyl_color").val() || "");
		$rows.slice(1).each(function () {
			$(this).find(".ew-p-vinyl").val(firstName).prop("disabled", true);
			$(this).find(".ew-p-vinyl_color").val(firstColor);
		});
	},

	refreshGfxVinylActions: function ($panel) {
		var $rows = $panel.find(".ew-p-vinyl-lines .ew-gfx-vinyl-line");
		$rows.find(".ew-gfx-vinyl-del").toggleClass("d-none", $rows.length < 2);
		$rows.find(".ew-gfx-vinyl-add").addClass("d-none");
		$rows.last().find(".ew-gfx-vinyl-add").removeClass("d-none");
		$rows.each(function (idx) {
			var $name = $(this).find(".ew-p-vinyl");
			if (idx === 0) {
				$name.prop("disabled", false).removeAttr("title");
			} else {
				var firstName = String($rows.first().find(".ew-p-vinyl").val() || "");
				$name.val(firstName).prop("disabled", true)
					.attr("title", "Same as first film row for this product");
			}
		});
	},

	addGfxSecVinylLine: function ($panel) {
		var tpl = EwNewRequest._$("#ew_gfx_sec_vinyl_line_tpl").get(0);
		if (!tpl || !tpl.content) {
			return;
		}
		var $tbody = $panel.find(".ew-p-sec-vinyl-lines");
		var $rows = $tbody.find(".ew-gfx-sec-vinyl-line");
		if ($rows.length >= 5) {
			EwNewRequest.showMsg("Maximum 5 secondary film lines per product.", true);
			return;
		}
		var firstName = String($rows.first().find(".ew-p-sec_vinyl").val() || "NA").trim() || "NA";
		var $row = $(tpl.content.cloneNode(true)).find("tr");
		$tbody.append($row);
		var $name = $row.find(".ew-p-sec_vinyl");
		if ($rows.length === 0) {
			EwNewRequest.wireVinylAc($name, "sec_vinyl", $panel);
			$name.off("change.ewgfxssync input.ewgfxssync").on("change.ewgfxssync input.ewgfxssync", function () {
				EwNewRequest.syncGfxSecVinylToExtraRows($panel);
			});
		} else {
			/* Legacy AddSecondaryVinylGroupRow: copy+disable rows 2+. */
			$name.val(firstName).prop("disabled", true)
				.attr("title", "Same as first secondary film row");
		}
		EwNewRequest.refreshGfxSecVinylActions($panel);
	},

	syncGfxSecVinylToExtraRows: function ($panel) {
		var $rows = $panel.find(".ew-p-sec-vinyl-lines .ew-gfx-sec-vinyl-line");
		if ($rows.length < 2) {
			return;
		}
		var firstName = String($rows.first().find(".ew-p-sec_vinyl").val() || "NA");
		$rows.slice(1).each(function () {
			$(this).find(".ew-p-sec_vinyl").val(firstName).prop("disabled", true);
		});
	},

	refreshGfxSecVinylActions: function ($panel) {
		var $rows = $panel.find(".ew-p-sec-vinyl-lines .ew-gfx-sec-vinyl-line");
		$rows.find(".ew-gfx-sec-del").toggleClass("d-none", $rows.length < 2);
		$rows.find(".ew-gfx-sec-add").addClass("d-none");
		$rows.last().find(".ew-gfx-sec-add").removeClass("d-none");
		$rows.each(function (idx) {
			var $name = $(this).find(".ew-p-sec_vinyl");
			if (idx === 0) {
				$name.prop("disabled", false).removeAttr("title");
			} else {
				var firstName = String($rows.first().find(".ew-p-sec_vinyl").val() || "NA");
				$name.val(firstName).prop("disabled", true)
					.attr("title", "Same as first secondary film row");
			}
		});
	},

	onLifeChange: function ($panel, col) {
		var idx = EwNewRequest.CHAIN.indexOf(col);
		if (idx < 0) {
			return;
		}
		var next = EwNewRequest.CHAIN[idx + 1];
		if (next) {
			EwNewRequest.cascadeField($panel, next);
		}
		if (col === "substrate" || col === "m_flexible_substrate" || col === "ink" || col === "vinyl") {
			EwNewRequest.calcLife($panel);
		}
	},

	slotFilters: function ($panel, untilCol) {
		var filters = { warr_temp: EwNewRequest._$("#ew_wrty_template").val() };
		var stop = untilCol || "";
		/*
		 * Legacy GetJsonArrayforCascading(fin_prod_info_app): loads graphic_conv_method
		 * with warranty_type only — so product master / life rows add NA as an extra LOV
		 * (Cut & Paste, NA, Printing). Do not send application for that step.
		 */
		var skipApp = stop === "graphic_conv_method";
		for (var i = 0; i < EwNewRequest.CHAIN.length; i++) {
			var col = EwNewRequest.CHAIN[i];
			if (col === stop) {
				break;
			}
			if (skipApp && col === "application") {
				continue;
			}
			var $el = $panel.find(".ew-p-" + col);
			var val = $el.length ? String($el.val() || "") : "";
			if (val) {
				filters[col] = val;
			}
		}
		var sec = String($panel.find(".ew-p-sec_vinyl").val() || "");
		if (sec) {
			filters.sec_vinyl = sec;
		}
		return filters;
	},

	cascadeField: function ($panel, outParam) {
		var $el = $panel.find(".ew-p-" + outParam);
		if (!$el.length || $el.is("input")) {
			EwNewRequest.clearDownstream($panel, outParam);
			return;
		}
		if (!String(EwNewRequest._$("#ew_wrty_template").val() || "")) {
			EwNewRequest.fillSelect($el, []);
			EwNewRequest.clearDownstream($panel, outParam);
			return;
		}
		var body = EwNewRequest.slotFilters($panel, outParam);
		body.out_param = outParam;
		var prev = $panel.data("ewCascadeXhr");
		if (prev && typeof prev.abort === "function") {
			prev.abort();
		}
		var spinId = EwCommon.ensureAcLoader($el);
		EwCommon.clearAcFieldError($el);
		EwCommon.showAcLoader($el, spinId);
		$el.prop("disabled", true);
		var xhr = $.ajax({
			url: EwNewRequest.apiUrl("/cascade"),
			method: "POST",
			data: JSON.stringify(body),
			contentType: "application/json",
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (EwCommon.isSessionGone(json)) {
				return;
			}
			if (!EwCommon.ok(json)) {
				EwCommon.showAcFieldError($el, (json && json.message) || "Unable to load filter values.");
				return;
			}
			EwCommon.clearAcFieldError($el);
			var values = [];
			(json.data || []).forEach(function (row) {
				var v = String(row.value || row.VALUE || "");
				if (v) {
					values.push(v);
				}
			});
			/* Legacy product-master LOV always includes NA for Graphic Conversion Method. */
			if (outParam === "graphic_conv_method" && values.indexOf("NA") < 0) {
				values.push("NA");
				values.sort();
			}
			EwNewRequest.fillSelect($el, values);
			EwNewRequest.clearDownstream($panel, outParam);
			if (values.length === 1) {
				$el.val(values[0]);
				EwNewRequest.onLifeChange($panel, outParam);
			}
		}).fail(function (xhr) {
			if (xhr && xhr.statusText === "abort") {
				return;
			}
			EwCommon.showAcFieldError($el, EwNewRequest.ajaxError(xhr, "Unable to load filter values."));
		}).always(function () {
			EwCommon.hideAcLoader($el, spinId);
			$el.prop("disabled", false);
		});
		$panel.data("ewCascadeXhr", xhr);
	},

	clearDownstream: function ($panel, fromCol) {
		var idx = EwNewRequest.CHAIN.indexOf(fromCol);
		for (var i = idx + 1; i < EwNewRequest.CHAIN.length; i++) {
			var col = EwNewRequest.CHAIN[i];
			var $el = $panel.find(".ew-p-" + col);
			if ($el.is("select")) {
				$el.empty().append('<option value="">Select</option>');
			} else if (col !== "vinyl" && col !== "sec_vinyl") {
				$el.val("");
			}
		}
		$panel.find(".ew-p-warranty_life").val("");
	},

	calcLife: function ($panel) {
		var body = EwNewRequest.slotFilters($panel, "");
		var $life = $panel.find(".ew-p-warranty_life");
		var spinId = EwCommon.ensureAcLoader($life);
		EwCommon.clearAcFieldError($life);
		EwCommon.showAcLoader($life, spinId);
		$.ajax({
			url: EwNewRequest.apiUrl("/warranty-life"),
			method: "POST",
			data: JSON.stringify(body),
			contentType: "application/json",
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (EwCommon.isSessionGone(json)) {
				return;
			}
			if (!EwCommon.ok(json)) {
				EwCommon.showAcFieldError($life, (json && json.message) || "Unable to calculate warranty life.");
				return;
			}
			EwCommon.clearAcFieldError($life);
			var rows = json.data || [];
			var life = rows.length ? String(rows[0].warranty_life || rows[0].WARRANTY_LIFE || "") : "";
			$life.val(life);
		}).fail(function (xhr) {
			EwCommon.showAcFieldError($life, EwNewRequest.ajaxError(xhr, "Unable to calculate warranty life."));
		}).always(function () {
			EwCommon.hideAcLoader($life, spinId);
		});
	},

	wirePpfProduct: function () {
		var $host = EwNewRequest._$("#ew_ppf_product");
		if (!$host.length) {
			return;
		}
		var $tbody = EwNewRequest._$("#ew_ppf_lines");
		if (!$tbody.children().length) {
			EwNewRequest.addPpfLine();
		}
		$host.off("click.ewppf", ".ew-ppf-add").on("click.ewppf", ".ew-ppf-add", function (e) {
			if (e) {
				e.preventDefault();
			}
			/* Do not require lot / unique lot / qty before add (unlike legacy ValidateVinylGroupRow). */
			EwNewRequest.addPpfLine();
		});
		$host.off("click.ewppfdel", ".ew-ppf-del").on("click.ewppfdel", ".ew-ppf-del", function () {
			$(this).closest("tr").remove();
			EwNewRequest.refreshPpfActions();
			EwNewRequest.calcPpfLife();
		});
		EwNewRequest._$("#ew_ppf_application").off("change.ewlife").on("change.ewlife", function () {
			EwNewRequest.calcPpfLife();
		});
		EwNewRequest.bindPpfDocuments($host);
		EwNewRequest.onInstTypeChange();
		EwNewRequest.bindDatePickers();
	},

	bindPpfDocuments: function ($host) {
		var $root = $host && $host.length ? $host : EwNewRequest._$("#ew_ppf_product");
		if (!$root.length) {
			return;
		}
		if (!EwNewRequest._docUrls) {
			EwNewRequest._docUrls = {};
		}
		$root.off("click.ewdocbrowse", ".ew-nr-doc-browse").on("click.ewdocbrowse", ".ew-nr-doc-browse", function (event) {
			event.preventDefault();
			var input = $(this).closest(".ew-doc-field").find(".ew-doc-input").get(0);
			if (input) {
				input.click();
			}
		});
		$root.off("change.ewdoc", ".ew-doc-input").on("change.ewdoc", ".ew-doc-input", function () {
			EwNewRequest.onPpfDocChange($(this).closest(".ew-doc-field"));
		});
		$root.off("click.ewdocview", ".ew-doc-view").on("click.ewdocview", ".ew-doc-view", function (event) {
			event.preventDefault();
			var key = String($(this).closest(".ew-doc-field").attr("data-ew-doc") || "");
			var url = EwNewRequest._docUrls[key];
			if (url) {
				window.open(url, "_blank", "noopener");
			}
		});
		$root.off("click.ewdocdel", ".ew-doc-del").on("click.ewdocdel", ".ew-doc-del", function (event) {
			event.preventDefault();
			EwNewRequest.clearPpfDoc($(this).closest(".ew-doc-field"));
		});
		$root.find(".ew-doc-field").each(function () {
			EwNewRequest.refreshPpfDocMeta($(this));
		});
	},

	onPpfDocChange: function ($field) {
		if (!$field || !$field.length) {
			return;
		}
		var key = String($field.attr("data-ew-doc") || "");
		var input = $field.find(".ew-doc-input").get(0);
		var file = input && input.files && input.files[0] ? input.files[0] : null;
		if (EwNewRequest._docUrls[key]) {
			try {
				window.URL.revokeObjectURL(EwNewRequest._docUrls[key]);
			} catch (e) { /* ignore */ }
			delete EwNewRequest._docUrls[key];
		}
		if (file) {
			EwNewRequest._docUrls[key] = window.URL.createObjectURL(file);
		}
		EwNewRequest.refreshPpfDocMeta($field);
	},

	clearPpfDoc: function ($field) {
		if (!$field || !$field.length) {
			return;
		}
		var key = String($field.attr("data-ew-doc") || "");
		var $input = $field.find(".ew-doc-input");
		$input.val("");
		if (EwNewRequest._docUrls[key]) {
			try {
				window.URL.revokeObjectURL(EwNewRequest._docUrls[key]);
			} catch (e) { /* ignore */ }
			delete EwNewRequest._docUrls[key];
		}
		EwNewRequest.refreshPpfDocMeta($field);
	},

	refreshPpfDocMeta: function ($field) {
		var key = String($field.attr("data-ew-doc") || "");
		var input = $field.find(".ew-doc-input").get(0);
		var file = input && input.files && input.files[0] ? input.files[0] : null;
		var $actions = $field.find(".ew-nr-doc-actions");
		if (!file) {
			$actions.addClass("d-none");
			$actions.find(".ew-doc-name").text("");
			return;
		}
		$actions.removeClass("d-none");
		$actions.find(".ew-doc-name").text(file.name).attr("title", file.name);
		if (!EwNewRequest._docUrls[key]) {
			EwNewRequest._docUrls[key] = window.URL.createObjectURL(file);
		}
	},

	addPpfLine: function () {
		var tpl = EwNewRequest._$("#ew_ppf_line_tpl").get(0);
		if (!tpl || !tpl.content) {
			return;
		}
		var $rows = EwNewRequest._$("#ew_ppf_lines .ew-ppf-line");
		if ($rows.length >= 5) {
			EwNewRequest.showMsg("Maximum 5 PPF lines allowed.", true);
			return;
		}
		var firstName = String($rows.first().find(".ew-ppf-name").val() || "").trim();
		var $row = $(tpl.content.cloneNode(true)).find("tr");
		EwNewRequest._$("#ew_ppf_lines").append($row);
		var $name = $row.find(".ew-ppf-name");
		if ($rows.length === 0) {
			EwNewRequest.wireVinylAc($name, "vinyl", null);
			$name.off("change.ewppfsync input.ewppfsync").on("change.ewppfsync input.ewppfsync", function () {
				EwNewRequest.syncPpfProductToExtraRows();
			});
		} else {
			/* Copy first-row PPF and disable rows 2+; lot / unique / qty stay blank for user. */
			$name.val(firstName).prop("disabled", true).attr("title", "Same as first PPF row");
		}
		EwNewRequest.refreshPpfActions();
	},

	syncPpfProductToExtraRows: function () {
		var $rows = EwNewRequest._$("#ew_ppf_lines .ew-ppf-line");
		if ($rows.length < 2) {
			return;
		}
		var firstName = String($rows.first().find(".ew-ppf-name").val() || "");
		$rows.slice(1).each(function () {
			$(this).find(".ew-ppf-name").val(firstName).prop("disabled", true);
		});
	},

	refreshPpfActions: function () {
		var $rows = EwNewRequest._$("#ew_ppf_lines .ew-ppf-line");
		$rows.find(".ew-ppf-del").toggleClass("d-none", $rows.length < 2);
		$rows.find(".ew-ppf-add").addClass("d-none");
		$rows.last().find(".ew-ppf-add").removeClass("d-none");
		$rows.each(function (idx) {
			var $name = $(this).find(".ew-ppf-name");
			if (idx === 0) {
				$name.prop("disabled", false).removeAttr("title");
			} else {
				var firstName = String($rows.first().find(".ew-ppf-name").val() || "");
				$name.val(firstName).prop("disabled", true).attr("title", "Same as first PPF row");
			}
		});
	},

	/** Legacy EWReqWarranty.OnInstTypeChange */
	onInstTypeChange: function () {
		var mode = String(EwNewRequest._$("input[name='ew_inst_mode']:checked").val() || "Non Vehicle");
		var vehicle = mode === "Vehicle";
		EwNewRequest._$("#ew_non_veh_inst_div").toggleClass("d-none", vehicle);
		EwNewRequest._$("#ew_veh_inst_div").toggleClass("d-none", !vehicle);
	},

	calcPpfLife: function () {
		var vinyl = EwNewRequest._$("#ew_ppf_lines .ew-ppf-name").first().val();
		var body = {
			warr_temp: "Paint Protection Film",
			vinyl: vinyl
		};
		var $life = EwNewRequest._$("#ew_ppf_warranty_life");
		var spinId = EwCommon.ensureAcLoader($life);
		EwCommon.clearAcFieldError($life);
		EwCommon.showAcLoader($life, spinId);
		$.ajax({
			url: EwNewRequest.apiUrl("/warranty-life"),
			method: "POST",
			data: JSON.stringify(body),
			contentType: "application/json",
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (EwCommon.isSessionGone(json)) {
				return;
			}
			if (!EwCommon.ok(json)) {
				EwCommon.showAcFieldError($life, (json && json.message) || "Unable to calculate warranty life.");
				return;
			}
			EwCommon.clearAcFieldError($life);
			var rows = json.data || [];
			var life = rows.length ? String(rows[0].warranty_life || "") : "";
			$life.val(life || "");
		}).fail(function (xhr) {
			EwCommon.showAcFieldError($life, EwNewRequest.ajaxError(xhr, "Unable to calculate warranty life."));
		}).always(function () {
			EwCommon.hideAcLoader($life, spinId);
		});
	},

	wirePartyAutocomplete: function (inputId, path, hiddenId, withType) {
		var $txt = EwNewRequest._$("#" + inputId);
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		try {
			if ($txt.data("ui-autocomplete")) {
				$txt.autocomplete("destroy");
			}
		} catch (e) { /* first bind */ }
		var spinId = EwCommon.ensureAcLoader($txt);
		$txt.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: EwNewRequest._$home(),
			source: function (request, response) {
				var data = $.extend({ phrase: request.term }, EwNewRequest.ctx());
				if (withType) {
					data.warrantyType = EwNewRequest._$("#ew_wrty_template").val();
				}
				EwCommon.clearAcFieldError($txt);
				EwCommon.showAcLoader($txt, spinId);
				$.ajax({
					url: (window.$app_url || "") + EwNewRequest.API + "/" + path,
					method: "GET",
					data: data,
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (EwCommon.isSessionGone(json)) {
						response([]);
						return;
					}
					if (!EwCommon.ok(json)) {
						EwCommon.showAcFieldError($txt, (json && json.message) || "Search failed.");
						response([]);
						return;
					}
					EwCommon.clearAcFieldError($txt);
					response($.map(json.data || [], function (row) {
						return {
							label: row.value,
							value: row.value,
							internal_code: row.internal_code,
							row: row
						};
					}));
				}).fail(function (xhr) {
					EwCommon.showAcFieldError($txt, EwNewRequest.ajaxError(xhr, "Search failed."));
					response([]);
				}).always(function () {
					EwCommon.hideAcLoader($txt, spinId);
					$txt.removeClass("ui-autocomplete-loading");
				});
			},
			select: function (_e, ui) {
				EwCommon.clearAcFieldError($txt);
				EwNewRequest._$("#" + hiddenId).val(ui.item.internal_code || "");
				var row = ui.item.row || {};
				if (inputId === "ew_customer") {
					EwNewRequest._$("#ew_end_cust_name").val(row.customer_name || "");
					EwNewRequest._$("#ew_address_1").val(row.address1 || "");
					EwNewRequest._$("#ew_address_2").val(row.address || "");
					EwNewRequest._$("#ew_city").val(row.city || "");
					EwNewRequest._$("#ew_state").val(row.state || "");
					EwNewRequest._$("#ew_postal_code").val(row.pin || "");
					EwNewRequest._$("#ew_cust_int_code").val(row.internal_code || "");
				}
				if (inputId === "ew_applicator") {
					EwNewRequest.showPartyDetails("ew_applicator_details", row);
				}
				if (inputId === "ew_distributor") {
					/* Legacy ewcommon GetDistributorAutoComplete select → Address/City/Phone/Email beside field. */
					EwNewRequest.showPartyDetails("ew_distributor_details", row);
				}
			}
		});
		$txt.off("input.ewclear").on("input.ewclear", function () {
			EwCommon.clearAcFieldError($txt);
			EwNewRequest._$("#" + hiddenId).val("");
			if (inputId === "ew_applicator") {
				EwNewRequest._$("#ew_applicator_details").empty();
			}
			if (inputId === "ew_distributor") {
				EwNewRequest._$("#ew_distributor_details").empty();
			}
		});
	},

	/** Legacy party detail strip: Address / City / Phone No / Email (Distributor + Applicator). */
	showPartyDetails: function (targetId, row) {
		var address = String((row && row.address) || "");
		var city = String((row && row.city) || "");
		var phone = String((row && (row.phone_no != null ? row.phone_no : row.phone)) || "");
		var email = String((row && row.email) || "");
		var $out = EwNewRequest._$("#" + targetId);
		if (!$out.length) {
			return;
		}
		if (!address && !city && !phone && !email) {
			$out.empty();
			return;
		}
		$out.html(
			"<span><b>Address:</b>" + EwNewRequest.esc(address)
			+ "   <b>City:</b>" + EwNewRequest.esc(city)
			+ "   <b>Phone No:</b>" + EwNewRequest.esc(phone)
			+ "   <b>Email:</b>" + EwNewRequest.esc(email) + "</span>"
		);
	},

	showApplicatorDetails: function (row) {
		EwNewRequest.showPartyDetails("ew_applicator_details", row);
	},

	esc: function (value) {
		return String(value == null ? "" : value)
			.replace(/&/g, "&amp;").replace(/</g, "&lt;")
			.replace(/>/g, "&gt;").replace(/"/g, "&quot;");
	},

	wireSegmentLeaderAutocomplete: function () {
		var $txt = EwNewRequest._$("#ew_segment_leader");
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		try {
			if ($txt.data("ui-autocomplete")) {
				$txt.autocomplete("destroy");
			}
		} catch (e) { /* first bind */ }
		var spinId = EwCommon.ensureAcLoader($txt);
		$txt.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: EwNewRequest._$home(),
			source: function (request, response) {
				var template = String(EwNewRequest._$("#ew_wrty_template").val() || "");
				if (!template) {
					response([]);
					return;
				}
				EwCommon.clearAcFieldError($txt);
				EwCommon.showAcLoader($txt, spinId);
				$.ajax({
					url: (window.$app_url || "") + EwNewRequest.API + "/segment-leaders",
					method: "GET",
					data: $.extend({
						phrase: request.term,
						warrantyType: template
					}, EwNewRequest.ctx()),
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (EwCommon.isSessionGone(json)) {
						response([]);
						return;
					}
					if (!EwCommon.ok(json)) {
						EwCommon.showAcFieldError($txt, (json && json.message) || "Segment Leader search failed.");
						response([]);
						return;
					}
					EwCommon.clearAcFieldError($txt);
					response($.map(json.data || [], function (row) {
						return {
							label: row.value,
							value: row.value,
							internal_code: row.internal_code,
							enl_id: row.enl_id,
							row: row
						};
					}));
				}).fail(function (xhr) {
					EwCommon.showAcFieldError($txt, EwNewRequest.ajaxError(xhr, "Segment Leader search failed."));
					response([]);
				}).always(function () {
					EwCommon.hideAcLoader($txt, spinId);
					$txt.removeClass("ui-autocomplete-loading");
				});
			},
			select: function (_e, ui) {
				EwCommon.clearAcFieldError($txt);
				var row = ui.item.row || {};
				var enl = String(ui.item.enl_id || row.enl_id || "").trim();
				if (!enl) {
					enl = String(ui.item.value || "").split("-")[0].trim();
				}
				EwNewRequest._$("#ew_segment_leader_enl").val(enl);
				EwNewRequest._$("#ew_segment_leader_int_code").val(ui.item.internal_code || "");
			}
		});
		$txt.off("input.ewslclear").on("input.ewslclear", function () {
			EwCommon.clearAcFieldError($txt);
			EwNewRequest.clearSegmentLeader(true);
		});
	},

	clearSegmentLeader: function (keepText) {
		if (!keepText) {
			EwNewRequest._$("#ew_segment_leader").val("");
		}
		EwNewRequest._$("#ew_segment_leader_enl").val("");
		EwNewRequest._$("#ew_segment_leader_int_code").val("");
	},

	togglePartialRemarks: function () {
		var val = String(EwNewRequest._$("#ew_ppf_application").val() || "");
		var show = val === "Partial Car Application";
		var $remarks = EwNewRequest._$("#ew_partial_application_remarks");
		$remarks.toggleClass("d-none", !show);
		$remarks.closest(".ew-nr-field").toggleClass("d-none", !show);
		if (!show) {
			$remarks.val("");
		}
	},

	wireVinylAc: function ($txt, systemName, $panel) {
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		try {
			if ($txt.data("ui-autocomplete")) {
				$txt.autocomplete("destroy");
			}
		} catch (e) { /* first bind */ }
		var spinId = EwCommon.ensureAcLoader($txt);
		$txt.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: EwNewRequest._$home(),
			source: function (request, response) {
				/* PPF Type of Application is v_to_app — do not send as ew_warranty_life filter. */
				var filters = $panel ? EwNewRequest.slotFilters($panel, systemName) : {
					warr_temp: EwNewRequest._$("#ew_wrty_template").val()
				};
				EwCommon.clearAcFieldError($txt);
				EwCommon.showAcLoader($txt, spinId);
				$.ajax({
					url: EwNewRequest.apiUrl("/vinyl"),
					method: "POST",
					contentType: "application/json",
					data: JSON.stringify({
						phrase: request.term,
						warrantyType: EwNewRequest._$("#ew_wrty_template").val(),
						systemName: systemName,
						filters: filters
					}),
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (EwCommon.isSessionGone(json)) {
						response([]);
						return;
					}
					if (!EwCommon.ok(json)) {
						EwCommon.showAcFieldError($txt, (json && json.message) || "Product search failed.");
						response([]);
						return;
					}
					EwCommon.clearAcFieldError($txt);
					response($.map(json.data || [], function (row) {
						return {
							label: row.value,
							value: row.value,
							color: row.color
						};
					}));
				}).fail(function (xhr) {
					EwCommon.showAcFieldError($txt, EwNewRequest.ajaxError(xhr, "Product search failed."));
					response([]);
				}).always(function () {
					EwCommon.hideAcLoader($txt, spinId);
					$txt.removeClass("ui-autocomplete-loading");
				});
			},
			select: function (_e, ui) {
				EwCommon.clearAcFieldError($txt);
				if ($panel) {
					var color = ui.item.color || "";
					$panel.find(".ew-p-vinyl-lines .ew-gfx-vinyl-line").first()
						.find(".ew-p-vinyl_color").val(color);
					EwNewRequest.syncGfxVinylToExtraRows($panel);
					EwNewRequest.calcLife($panel);
					EwNewRequest.cascadeField($panel, "overlaminate");
				} else {
					EwNewRequest.calcPpfLife();
					setTimeout(function () {
						EwNewRequest.syncPpfProductToExtraRows();
					}, 0);
				}
			}
		});
	},

	collectProducts: function () {
		if (EwNewRequest.isPpf()) {
			var life = EwNewRequest._$("#ew_ppf_warranty_life").val();
			var app = EwNewRequest._$("#ew_ppf_application").val();
			var list = [];
			/* Legacy: PPF is one product (prod_ref_code=1); each film line is a vinyl row. */
			EwNewRequest._$("#ew_ppf_lines .ew-ppf-line").each(function () {
				var $r = $(this);
				list.push({
					prod_sl_no: "1",
					application: app,
					vinyl: $r.find(".ew-ppf-name").val(),
					vinyl_lot_no: $r.find(".ew-ppf-lot").val(),
					vinyl_unique_lot_no: $r.find(".ew-ppf-unique-lot").val(),
					vinyl_qty: $r.find(".ew-ppf-qty").val(),
					warranty_life: life
				});
			});
			return list;
		}
		var n = Number(EwNewRequest._$("#ew_no_of_products").val() || "1");
		var list = [];
		EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel").each(function () {
			var slot = Number($(this).attr("data-slot") || "0");
			if (slot < 1 || slot > n) {
				return;
			}
			var $p = $(this);
			var shared = {
				application: $p.find(".ew-p-application").val(),
				graphic_conv_method: $p.find(".ew-p-graphic_conv_method").val(),
				type_of_exposure: $p.find(".ew-p-type_of_exposure").val(),
				substrate: $p.find(".ew-p-substrate").val(),
				m_flexible_substrate: $p.find(".ew-p-m_flexible_substrate").val(),
				substrate_lot_no: $p.find(".ew-p-substrate_lot_no").val(),
				substrate_qty: $p.find(".ew-p-substrate_qty").val(),
				sec_vinyl: $p.find(".ew-p-sec-vinyl-lines .ew-p-sec_vinyl").first().val() || "NA",
				overlaminate: $p.find(".ew-p-overlaminate").val(),
				overlaminate_lot_no: $p.find(".ew-p-overlaminate_lot_no").val(),
				overlaminate_qty: $p.find(".ew-p-overlaminate_qty").val(),
				printer_format: $p.find(".ew-p-printer_format").val(),
				printing_hardware: $p.find(".ew-p-printing_hardware").val(),
				ink: $p.find(".ew-p-ink").val(),
				edge_sealer: $p.find(".ew-p-edge_sealer").val(),
				warranty_life: $p.find(".ew-p-warranty_life").val(),
				poi_width: $p.find(".ew-p-poi-width").val(),
				poi_height: $p.find(".ew-p-poi-height").val(),
				poi_unit: $p.find(".ew-p-poi-unit").val(),
				poi_area: $p.find(".ew-p-poi-area").val(),
				poi_qty: $p.find(".ew-p-poi-qty").val(),
				poi_remarks: $p.find(".ew-p-poi-remarks").val()
			};
			var $lines = $p.find(".ew-p-vinyl-lines .ew-gfx-vinyl-line");
			if (!$lines.length) {
				list.push($.extend({
					prod_sl_no: String(slot),
					vinyl: "",
					vinyl_color: "",
					vinyl_lot_no: "",
					vinyl_qty: "",
					vinyl_unique_lot_no: ""
				}, shared));
				return;
			}
			/* Legacy GetVinylGroupObj: many vinyl rows share the same prod_sl_no (product tab). */
			$lines.each(function () {
				var $r = $(this);
				list.push($.extend({
					prod_sl_no: String(slot),
					vinyl: $r.find(".ew-p-vinyl").val(),
					vinyl_color: $r.find(".ew-p-vinyl_color").val(),
					vinyl_lot_no: $r.find(".ew-p-vinyl_lot_no").val(),
					vinyl_qty: $r.find(".ew-p-vinyl_qty").val(),
					vinyl_unique_lot_no: ""
				}, shared));
			});
		});
		return list;
	},

	/** Legacy GetSecVinylGroupObj — secondary film rows per product tab. */
	collectSecVinyl: function () {
		if (EwNewRequest.isPpf()) {
			return [];
		}
		var n = Number(EwNewRequest._$("#ew_no_of_products").val() || "1");
		var list = [];
		EwNewRequest._$("#ew_shared_products .ew-nr-prod-panel").each(function () {
			var slot = Number($(this).attr("data-slot") || "0");
			if (slot < 1 || slot > n) {
				return;
			}
			var $p = $(this);
			if ($p.find(".ew-gfx-sec-vinyl-block").hasClass("d-none")) {
				return;
			}
			var $lines = $p.find(".ew-p-sec-vinyl-lines .ew-gfx-sec-vinyl-line");
			if (!$lines.length) {
				var v = String($p.find(".ew-p-sec_vinyl").first().val() || "").trim();
				if (v && v !== "NA") {
					list.push({
						prod_sl_no: String(slot),
						vinyl: v,
						color: $p.find(".ew-p-sec_vinyl_color").first().val() || "",
						lot_no: $p.find(".ew-p-vinyl_sec_lot_no").first().val() || "",
						quantity: $p.find(".ew-p-sec_vinyl_qty").first().val() || ""
					});
				}
				return;
			}
			$lines.each(function () {
				var $r = $(this);
				var vinyl = String($r.find(".ew-p-sec_vinyl").val() || "").trim();
				if (!vinyl || vinyl === "NA") {
					return;
				}
				list.push({
					prod_sl_no: String(slot),
					vinyl: vinyl,
					color: $r.find(".ew-p-sec_vinyl_color").val() || "",
					lot_no: $r.find(".ew-p-vinyl_sec_lot_no").val() || "",
					quantity: $r.find(".ew-p-sec_vinyl_qty").val() || ""
				});
			});
		});
		return list;
	},

	/** Legacy Dist→Converter invoice lines (ew_new_request_addnl_inv_details). */
	collectAddnlInvoices: function () {
		if (EwNewRequest.isPpf()) {
			return [];
		}
		var list = [];
		EwNewRequest._$("#ew_gfx_addnl_lines .ew-gfx-addnl-line").each(function () {
			var $r = $(this);
			var invNo = String($r.find(".ew-gfx-addnl-inv-no").val() || "").trim();
			var invDate = String($r.find(".ew-gfx-addnl-inv-date").val() || "").trim();
			if (!invNo && !invDate) {
				return;
			}
			list.push({
				invoice_no: invNo,
				invoice_date: invDate
			});
		});
		return list;
	},

	collectHeader: function (saveType) {
		var template = String(EwNewRequest._$("#ew_wrty_template").val() || "");
		var ppf = EwNewRequest.isPpf();
		return {
			save_type: saveType,
			wrty_template: template,
			wrty_type: ppf ? "PPF" : "Graphics",
			date_of_inst: EwNewRequest._$("#ew_date_of_inst").val(),
			no_of_products: ppf ? "1" : EwNewRequest._$("#ew_no_of_products").val(),
			dist_int_code: EwNewRequest._$("#ew_dist_int_code").val(),
			cust_int_code: EwNewRequest._$("#ew_cust_int_code").val(),
			applicator_int_code: EwNewRequest._$("#ew_applicator_int_code").val(),
			end_cust_int_code: EwNewRequest._$("#ew_end_cust_int_code").val(),
			end_cust_name: EwNewRequest._$("#ew_end_cust_name").val(),
			address_1: EwNewRequest._$("#ew_address_1").val(),
			address_2: EwNewRequest._$("#ew_address_2").val(),
			city: EwNewRequest._$("#ew_city").val(),
			state: EwNewRequest._$("#ew_state").val(),
			postal_code: EwNewRequest._$("#ew_postal_code").val(),
			inst_type: String(EwNewRequest._$("input[name='ew_inst_mode']:checked").val() || "Non Vehicle"),
			market_cat: EwNewRequest._$("#ew_market_cat").val(),
			project_name: EwNewRequest._$("#ew_project_name").val(),
			print_service_provider: EwNewRequest._$("#ew_print_service_provider").val(),
			branch_site_name: EwNewRequest._$("#ew_branch_site_name").val(),
			branch_id: EwNewRequest._$("#ew_branch_id").val(),
			ew_remarks: EwNewRequest._$("#ew_remarks").val(),
			auto_closed: EwNewRequest._$("#ew_auto_closed").val(),
			asm_kam_approver: EwNewRequest._$("#ew_asm_kam_approver").val(),
			segment_leader: (function () {
				var enl = String(EwNewRequest._$("#ew_segment_leader_enl").val() || "").trim();
				if (enl) {
					return enl;
				}
				return String(EwNewRequest._$("#ew_segment_leader").val() || "").split("-")[0].trim();
			})(),
			partial_application_remarks: EwNewRequest._$("#ew_partial_application_remarks").val(),
			g_ew_user_type: "Converter",
			vehicle: EwNewRequest._$("#ew_vehicle").val(),
			reg_no: EwNewRequest._$("#ew_reg_no").val(),
			v_car_model: EwNewRequest._$("#ew_v_car_model").val(),
			v_vin_no: EwNewRequest._$("#ew_v_vin_no").val(),
			v_odometer_rd: EwNewRequest._$("#ew_v_odometer_rd").val(),
			v_inst_place: EwNewRequest._$("#ew_v_inst_place").val(),
			ppf_cust_company_name: EwNewRequest._$("#ew_ppf_cust_company_name").val(),
			ppf_cust_phone: EwNewRequest._$("#ew_ppf_cust_phone").val(),
			ppf_cust_email: EwNewRequest._$("#ew_ppf_cust_email").val(),
			ppf_cust_address_1: EwNewRequest._$("#ew_ppf_cust_address_1").val(),
			ppf_cust_city: EwNewRequest._$("#ew_ppf_cust_city").val(),
			ppf_cust_state: EwNewRequest._$("#ew_ppf_cust_state").val(),
			ppf_cust_pin: EwNewRequest._$("#ew_ppf_cust_pin").val(),
			ppf_cust_address_2: EwNewRequest._$("#ew_ppf_cust_address_2").val(),
			v_end_cust_name: EwNewRequest._$("#ew_v_end_cust_name").val(),
			v_address_1: EwNewRequest._$("#ew_v_address_1").val(),
			v_address_2: EwNewRequest._$("#ew_v_address_2").val(),
			v_city: EwNewRequest._$("#ew_v_city").val(),
			v_state: EwNewRequest._$("#ew_v_state").val(),
			v_postal_code: EwNewRequest._$("#ew_v_postal_code").val(),
			v_email_id: EwNewRequest._$("#ew_v_email_id").val(),
			v_cust_mob_no: EwNewRequest._$("#ew_v_cust_mob_no").val(),
			v_fax_no: EwNewRequest._$("#ew_v_fax_no").val(),
			v_applicator_name: EwNewRequest._$("#ew_v_applicator_name").val(),
			v_appl_cert_no: EwNewRequest._$("#ew_v_appl_cert_no").val(),
			v_to_app: EwNewRequest._$("#ew_ppf_application").val()
		};
	},

	save: function (saveType) {
		EwNewRequest.clearFieldErrors();
		if (!EwNewRequest._$("#ew_wrty_template").val()) {
			return EwNewRequest.fail("Select a warranty template.", "ew_wrty_template");
		}
		if (EwNewRequest.isPpf()) {
			if (!String(EwNewRequest._$("#ew_ppf_cust_company_name").val() || "").trim()) {
				return EwNewRequest.fail("Billing Customer Name cannot be empty.", "ew_ppf_cust_company_name");
			}
			if (!String(EwNewRequest._$("#ew_applicator").val() || "").trim()
					|| !String(EwNewRequest._$("#ew_applicator_int_code").val() || "").trim()) {
				return EwNewRequest.fail("Applicator/Store cannot be empty.", "ew_applicator");
			}
			if (!String(EwNewRequest._$("#ew_segment_leader_enl").val() || "").trim()
					&& !String(EwNewRequest._$("#ew_segment_leader").val() || "").trim()) {
				return EwNewRequest.fail("Segment Leader cannot be empty.", "ew_segment_leader");
			}
			if (!String(EwNewRequest._$("#ew_ppf_application").val() || "").trim()) {
				return EwNewRequest.fail("Please enter Type of Application.", "ew_ppf_application");
			}
			if (EwNewRequest._$("#ew_ppf_application").val() === "Partial Car Application"
					&& !String(EwNewRequest._$("#ew_partial_application_remarks").val() || "").trim()) {
				return EwNewRequest.fail("Please enter Partial Remarks.", "ew_partial_application_remarks");
			}
		} else {
			if (!String(EwNewRequest._$("#ew_ppf_cust_company_name").val() || "").trim()) {
				return EwNewRequest.fail("Billing Customer Name cannot be empty.", "ew_ppf_cust_company_name");
			}
			if (!EwNewRequest._$("#ew_dist_int_code").val()) {
				return EwNewRequest.fail("Distributor cannot be empty.", "ew_distributor");
			}
			if (!String(EwNewRequest._$("#ew_segment_leader_enl").val() || "").trim()
					&& !String(EwNewRequest._$("#ew_segment_leader").val() || "").trim()) {
				return EwNewRequest.fail("Segment Leader cannot be empty.", "ew_segment_leader");
			}
		}
		if (!EwNewRequest._$("#ew_date_of_inst").val()) {
			return EwNewRequest.fail("Enter installation date.", "ew_date_of_inst");
		}
		var payload = {
			header: EwNewRequest.collectHeader(saveType),
			products: EwNewRequest.collectProducts(),
			secVinyl: EwNewRequest.collectSecVinyl(),
			addnlInvoices: EwNewRequest.collectAddnlInvoices()
		};
		var url = EwNewRequest.apiUrl("");
		showLoader(saveType === "Submit" ? "Submitting warranty..." : "Saving draft...", EwConv.HOME);
		$.ajax({
			url: url,
			method: "POST",
			contentType: "application/json",
			data: JSON.stringify(payload),
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			hideLoader(EwConv.HOME);
			if (EwCommon.isSessionGone(json)) {
				return;
			}
			if (!EwCommon.ok(json)) {
				EwNewRequest.showMsg((json && json.message) || "Unable to save the warranty request.", true);
				return;
			}
			var data = json.data || {};
			EwNewRequest.showMsg(data.message || "Warranty saved.", false);
			EwConv.requestsHtmlLoaded = false;
			EwConv.showTab("requests");
			if (typeof EwConv.loadRequests === "function" && EwConv._$(".ew-requests-shell").length) {
				EwConv.loadRequests();
			}
		}).fail(function () {
			hideLoader(EwConv.HOME);
			EwNewRequest.showMsg("Unable to save the warranty request.", true);
		});
	},

	fail: function (message, fieldId) {
		EwNewRequest.showMsg(message, true);
		if (fieldId) {
			EwNewRequest.markField(fieldId);
		}
		return false;
	},

	markField: function (fieldId) {
		var $el = EwNewRequest._$("#" + fieldId);
		if (!$el.length) {
			return;
		}
		$el.addClass("is-invalid ew-nr-invalid");
		try {
			var node = $el.get(0);
			if (node && typeof node.scrollIntoView === "function") {
				node.scrollIntoView({ behavior: "smooth", block: "center" });
			}
			$el.trigger("focus");
		} catch (e) { /* ignore */ }
	},

	clearFieldErrors: function () {
		EwNewRequest._$home().find(".is-invalid, .ew-nr-invalid").removeClass("is-invalid ew-nr-invalid");
	},

	ajaxError: function (xhr, fallback) {
		try {
			var json = xhr && xhr.responseJSON;
			if (json && json.message) {
				return String(json.message);
			}
			if (xhr && xhr.responseText) {
				var parsed = JSON.parse(xhr.responseText);
				if (parsed && parsed.message) {
					return String(parsed.message);
				}
			}
		} catch (e) { /* ignore */ }
		return fallback || "Request failed.";
	},

	showMsg: function (message, isError) {
		var text = String(message || "").trim();
		var $msg = EwNewRequest._$("#inpc_page_msg");
		if (!$msg.length) {
			$msg = EwNewRequest._$("#ew_nr_message");
		}
		if (!text) {
			$msg.addClass("d-none").removeClass("alert-warning alert-danger alert-success").empty();
			return;
		}
		var kind = isError ? "warning" : "success";
		var icon = isError ? "ri-error-warning-line" : "ri-checkbox-circle-line";
		$msg
			.removeClass("d-none alert-info alert-warning alert-danger alert-success")
			.addClass("alert alert-" + kind + " mb-2 py-2 px-3 ew-nr-msg")
			.html("<i class=\"" + icon + " me-1\" aria-hidden=\"true\"></i>" + EwNewRequest.esc(text));
		try {
			var box = $msg.get(0);
			if (box && typeof box.scrollIntoView === "function") {
				box.scrollIntoView({ behavior: "smooth", block: "nearest" });
			}
		} catch (e2) { /* ignore */ }
	}
};
