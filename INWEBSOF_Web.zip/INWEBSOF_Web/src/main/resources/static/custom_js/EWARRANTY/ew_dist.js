/**
 * E-Warranty Distributor — plain jQuery.
 * Flow: Load → context → tabs → .load HTML once → list API → DataTable.
 * No Request New Warranty tab (legacy).
 */
EwDist = {
	API: "api/customer/ewarranty/distributor",
	HOME: "m_ew_dist_home",
	TABLE_ROOT: "m_ew_dist_table_root",
	TABLE_ID: "ew_dist_requests_table",
	TBODY_ID: "ew_dist_requests_rows",
	custCode: "",
	loginId: "",
	requestsHtmlLoaded: false,

	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + EwDist.HOME) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $("#" + EwDist.HOME).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $("#" + EwDist.HOME).first();
	},

	_$: function (selector) {
		var $home = EwDist._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		return $home.find(selector);
	},

	Load: function () {
		EwDist.ensureCommon(function () {
			if (window.EwCommon && typeof EwCommon.bindPortalDates === "function") {
				EwCommon.bindPortalDates();
			}
			var ctx = EwCommon.procedureContext();
			EwDist.custCode = ctx.custCode;
			EwDist.loginId = ctx.loginId;
			EwDist.requestsHtmlLoaded = false;

			EwDist._$("#ew_dist_requests_tab").off("click").on("click", function () {
				EwDist.showTab("requests");
			});

			EwDist.loadContext(function () {
				EwDist.showTab("requests");
			});
		});
	},

	ensureCommon: function (done) {
		if (window.EwCommon && typeof EwCommon.procedureContext === "function") {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		$.getScript((window.$app_url || "") + "custom_js/EWARRANTY/ew_common.js")
			.done(function () {
				if (typeof done === "function") {
					done();
				}
			})
			.fail(function () {
				EwDist.setContext("Unable to load E-Warranty common script.", true);
			});
	},

	showTab: function (name) {
		EwDist._$("#ew_dist_requests_tab").attr("aria-selected", "true");
		EwDist._$("#ew_dist_requests_panel").removeClass("d-none");
		EwDist.openRequestsTab();
	},

	openRequestsTab: function () {
		if (EwDist.requestsHtmlLoaded && EwDist._$(".ew-requests-shell").length) {
			return;
		}
		var url = (window.$app_url || "") + "html_files/EWARRANTY/ew_requests.html?r=" + Date.now();
		showLoader("Loading Warranty Requests...", EwDist.HOME);
		EwDist._$("#ew_dist_requests_panel").load(url, function (_html, status) {
			hideLoader(EwDist.HOME);
			if (status !== "success") {
				EwDist._$("#ew_dist_requests_panel").html(
					'<div class="alert alert-danger m-3">Unable to load Warranty Requests.</div>');
				return;
			}
			EwDist.requestsHtmlLoaded = true;
			EwCommon.stampListIds(EwDist._$home(), {
				rootId: EwDist.TABLE_ROOT,
				tableId: EwDist.TABLE_ID,
				tbodyId: EwDist.TBODY_ID,
				dateId: "ew_dist_req_date",
				reqIdAc: "ew_dist_f_req_id",
				distAc: "ew_dist_f_dist",
				convAc: "ew_dist_f_conv",
				custAc: "ew_dist_f_cust"
			});
			EwDist._$(".ew-requests-eyebrow").text("Requests for the working distributor");
			EwCommon.initTable({
				rootId: EwDist.TABLE_ROOT,
				tableId: EwDist.TABLE_ID,
				tbodyId: EwDist.TBODY_ID,
				emptyMessage: "No warranty requests found for this distributor."
			});
			EwCommon.bindFilters(EwDist._$(".ew-requests-shell"), EwDist.TABLE_ROOT, {
				persona: "distributor",
				custCode: EwDist.custCode,
				loginId: EwDist.loginId
			});
			EwDist._$(".ew-requests-table").off("click", ".ew-view-request")
				.on("click", ".ew-view-request", function () {
					var id = String($(this).attr("data-int-code") || "");
					EwDist.openView(id);
				});
			EwDist._$(".ew-requests-refresh").off("click").on("click", function () {
				EwDist.loadRequests();
			});
			EwDist.loadRequests();
		});
	},

	openView: function (internalCode) {
		EwDist.ensurePopupJs(function () {
			EwReqPopup.open({
				$home: EwDist._$home(),
				api: EwDist.API,
				custCode: EwDist.custCode,
				loginId: EwDist.loginId,
				internalCode: internalCode
			});
		});
	},

	ensurePopupJs: function (done) {
		if (window.EwReqPopup && typeof EwReqPopup.open === "function") {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		$.getScript((window.$app_url || "") + "custom_js/EWARRANTY/ew_req_popup.js")
			.done(function () {
				if (typeof done === "function") {
					done();
				}
			})
			.fail(function () {
				alert("Unable to load request details.");
			});
	},

	loadContext: function (done) {
		showLoader("Loading E-Warranty Distributor...", EwDist.HOME);
		$.ajax({
			url: (window.$app_url || "") + EwDist.API + "/context",
			method: "GET",
			data: { custCode: EwDist.custCode, loginId: EwDist.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (EwCommon.isSessionGone(json)) {
				hideLoader(EwDist.HOME);
				return;
			}
			if (!EwCommon.ok(json)) {
				EwDist.setContext(
					(json && json.message) || "Unable to load distributor context.", true);
				hideLoader(EwDist.HOME);
				return;
			}
			var data = json.data || {};
			EwDist.custCode = String(data.custCode || data.distCode || EwDist.custCode).trim();
			if (data.distDisplay) {
				EwDist.setContext(
					"Distributor: " + data.distDisplay
					+ (data.source === "change_customer" ? " (Change Customer)" : ""), false);
			} else {
				EwDist.setContext("Distributor ready", false);
			}
			hideLoader(EwDist.HOME);
			if (typeof done === "function") {
				done();
			}
		}).fail(function () {
			EwDist.setContext("Unable to load distributor context.", true);
			hideLoader(EwDist.HOME);
		});
	},

	setContext: function (message, isError) {
		EwDist._$("#ew_dist_context_label")
			.toggleClass("is-error", !!isError)
			.attr("role", isError ? "alert" : null)
			.text(message || "");
	},

	loadRequests: function () {
		EwDist._$(".ew-requests-refresh").prop("disabled", true).addClass("is-refreshing");
		showLoader("Loading warranty requests...", "ew_dist_requests_panel");
		$.ajax({
			url: (window.$app_url || "") + EwDist.API + "/requests",
			method: "GET",
			data: { custCode: EwDist.custCode, loginId: EwDist.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (EwCommon.isSessionGone(json)) {
				return;
			}
			if (!EwCommon.ok(json)) {
				EwDist.showMsg((json && json.message) || "Unable to load requests.", true);
				return;
			}
			var list = (json.data && json.data.requests) || [];
			var rows = [];
			for (var i = 0; i < list.length; i++) {
				rows.push(EwCommon.toRow(list[i]));
			}
			var $shell = EwDist._$(".ew-requests-shell");
			$shell.data("ewAllRows", rows);
			EwCommon.fillStatusOptions($shell, rows);
			EwCommon.applyFilters($shell, EwDist.TABLE_ROOT);
			EwDist.showMsg(rows.length ? "" : "No warranty requests found for this distributor.", false);
		}).fail(function () {
			EwDist.showMsg("Unable to load warranty requests.", true);
		}).always(function () {
			hideLoader("ew_dist_requests_panel");
			EwDist._$(".ew-requests-refresh").prop("disabled", false).removeClass("is-refreshing");
		});
	},

	showMsg: function (message, isError) {
		EwDist._$(".ew-requests-msg")
			.toggleClass("alert-warning", !isError)
			.toggleClass("alert-danger", !!isError)
			.toggleClass("alert-success", false)
			.toggleClass("d-none", !message)
			.text(message || "");
	}
};
