/**
 * CSD graphic E-Warranty search autocompletes.
 * List shows code + name; the hidden field stores code only for the filter query.
 * Every AC field must show ac_loader (inpc-ac-spinner) while the request is in flight.
 */
CsdAutocomplete = {
	API: "api/customer/ewarranty/autocomplete",

	bind: function ($txt, opts) {
		opts = opts || {};
		if (!$txt || !$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		try {
			if ($txt.data("ui-autocomplete")) {
				$txt.autocomplete("destroy");
			}
		} catch (ignore) { /* first bind */ }
		var $hidden = opts.$hidden && opts.$hidden.length ? opts.$hidden : $();
		var $home = opts.$home && opts.$home.length ? opts.$home : $txt.closest(".ew-requests-shell");
		var spinId = "";
		if (window.EwCommon && typeof EwCommon.ensureAcLoader === "function") {
			spinId = EwCommon.ensureAcLoader($txt);
		}
		var $spin = opts.spinnerSel ? $home.find(opts.spinnerSel) : $();
		if ($spin.length && $spin.attr("id")) {
			spinId = $spin.attr("id");
		}
		$txt.attr("autocomplete", "off");
		$txt.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: $home.length ? $home : "body",
			position: { my: "left top", at: "left bottom", collision: "flip" },
			open: function () {
				$(this).autocomplete("widget").css({ zIndex: 4000, position: "absolute" });
			},
			source: function (request, response) {
				$hidden.val("");
				if (window.EwCommon && spinId) {
					EwCommon.showAcLoader($txt, spinId);
				}
				$.ajax({
					url: (window.$app_url || "") + CsdAutocomplete.API,
					method: "GET",
					data: {
						type: opts.type || "",
						phrase: request.term,
						persona: opts.persona || "converter",
						custCode: opts.custCode || "",
						loginId: opts.loginId || ""
					},
					dataType: "json",
					xhrFields: { withCredentials: true }
				}).done(function (json) {
					if (window.EwCommon && EwCommon.isSessionGone(json)) {
						response([]);
						return;
					}
					if (!window.EwCommon || !EwCommon.ok(json)) {
						response([]);
						return;
					}
					response($.map(json.data || [], function (row) {
						var code = String(row.code == null ? "" : row.code);
						var name = String(row.name == null ? "" : row.name);
						var value = String(row.value == null || row.value === ""
							? (code && name ? code + "-" + name : (code || name))
							: row.value);
						return {
							label: value,
							value: value,
							code: code,
							name: name
						};
					}));
				}).fail(function () {
					response([]);
				}).always(function () {
					if (window.EwCommon && spinId) {
						EwCommon.hideAcLoader($txt, spinId);
					}
					$txt.removeClass("ui-autocomplete-loading");
				});
			},
			select: function (_event, ui) {
				var item = ui.item || {};
				$hidden.val(String(item.code || "").trim());
				this.value = item.value || item.code || "";
				return false;
			}
		});
		$txt.off("input.csdac").on("input.csdac", function () {
			$hidden.val("");
		});
	}
};
