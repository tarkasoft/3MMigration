/**
 * Shared helpers for CSD graphic E-Warranty (not TSD).
 */
EwCommon = {
	TABLE_ROOT: "m_ew_requests_table_root",

	stampListIds: function ($scope, ids) {
		ids = ids || {};
		if (!$scope || !$scope.length) {
			return;
		}
		$scope.find(".ew-requests-table-root").attr("id", ids.rootId || "m_ew_requests_table_root");
		$scope.find(".ew-requests-table").attr("id", ids.tableId || "ew_requests_table");
		$scope.find(".ew-requests-rows").attr("id", ids.tbodyId || "ew_requests_rows");
		if (ids.dateId) {
			$scope.find(".ew-f-req-date").attr("id", ids.dateId);
		}
		if (ids.reqIdAc) {
			$scope.find(".ew-f-req-id").attr("id", ids.reqIdAc);
			$scope.find(".ew-f-req-id-spin").attr("id", ids.reqIdAc + "_ac_spinner");
		}
		if (ids.distAc) {
			$scope.find(".ew-f-dist").attr("id", ids.distAc);
			$scope.find(".ew-f-dist-spin").attr("id", ids.distAc + "_ac_spinner");
		}
		if (ids.convAc) {
			$scope.find(".ew-f-conv").attr("id", ids.convAc);
			$scope.find(".ew-f-conv-spin").attr("id", ids.convAc + "_ac_spinner");
		}
		if (ids.custAc) {
			$scope.find(".ew-f-cust").attr("id", ids.custAc);
			$scope.find(".ew-f-cust-spin").attr("id", ids.custAc + "_ac_spinner");
		}
	},

	procedureContext: function () {
		if (window.Common && Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	},

	ok: function (json) {
		return !!(json && (json.errorCode === 0 || json.errorCode === "0"));
	},

	isSessionGone: function (json) {
		if (!json) {
			return false;
		}
		var code = Number(json.errorCode);
		if (code === -9) {
			if (window.MainPage && typeof MainPage.handleSessionExpired === "function") {
				MainPage.handleSessionExpired(json.message || "Please login once again");
			} else if (typeof alert === "function") {
				alert(json.message || "Please login once again");
			}
			return true;
		}
		return false;
	},

	esc: function (value) {
		return String(value == null ? "" : value)
			.replace(/&/g, "&amp;")
			.replace(/</g, "&lt;")
			.replace(/>/g, "&gt;")
			.replace(/"/g, "&quot;")
			.replace(/'/g, "&#39;");
	},

	statusClass: function (status) {
		var s = String(status || "").toLowerCase();
		if (s.indexOf("closed") >= 0 || s.indexOf("approved") >= 0) {
			return "ok";
		}
		if (s.indexOf("reject") >= 0 || s.indexOf("cancel") >= 0) {
			return "muted";
		}
		if (s.indexOf("pending") >= 0 || s.indexOf("draft") >= 0 || s.indexOf("rework") >= 0) {
			return "warn";
		}
		return "info";
	},

	toRow: function (row) {
		var reqId = String(row.req_id == null ? "" : row.req_id);
		var reqDate = String(row.request_date == null ? "" : row.request_date);
		var dist = String(row.distributor == null ? "" : row.distributor);
		var conv = String(row.converter == null ? "" : row.converter);
		var cust = String(row.customer == null ? "" : row.customer);
		var template = String(row.wrty_template == null ? "" : row.wrty_template);
		var status = String(row.status == null ? "" : row.status);
		var intCode = String(row.req_int_code == null ? "" : row.req_int_code);
		var cls = EwCommon.statusClass(status);
		return {
			req_id: reqId,
			request_date: EwCommon.displayDate(reqDate),
			distributor: dist,
			dist_code: String(row.dist_code == null ? "" : row.dist_code),
			converter: conv,
			conv_code: String(row.conv_code == null ? "" : row.conv_code),
			customer: cust,
			cust_code: String(row.cust_code == null ? "" : row.cust_code),
			wrty_template: template,
			status: status,
			status_html:
				'<span class="ew-status ' + cls + '">' + EwCommon.esc(status) + "</span>",
			action_html:
				'<button type="button" class="ew-view-request" title="View request" aria-label="View request"'
				+ ' data-int-code="' + EwCommon.esc(intCode) + '"'
				+ ' data-req-id="' + EwCommon.esc(reqId) + '"'
				+ ' data-wrty-template="' + EwCommon.esc(template) + '">'
				+ '<i class="ri-eye-line" aria-hidden="true"></i></button>'
		};
	},

	displayDate: function (value) {
		var raw = String(value == null ? "" : value).trim();
		if (!raw) {
			return "";
		}
		var iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
		if (iso) {
			return iso[3] + "/" + iso[2] + "/" + iso[1];
		}
		return raw;
	},

	dateKey: function (value) {
		var raw = String(value == null ? "" : value).trim();
		if (!raw) {
			return "";
		}
		var dmy = raw.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
		if (dmy) {
			return dmy[3] + ("0" + dmy[2]).slice(-2) + ("0" + dmy[1]).slice(-2);
		}
		var iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
		if (iso) {
			return iso[1] + iso[2] + iso[3];
		}
		return raw;
	},

	contains: function (hay, needle) {
		if (!needle) {
			return true;
		}
		return String(hay || "").toLowerCase().indexOf(String(needle).toLowerCase()) >= 0;
	},

	codeMatch: function (rowCode, hiddenCode, displayText, typed) {
		var code = String(hiddenCode || "").trim();
		if (code) {
			return String(rowCode || "") === code;
		}
		return EwCommon.contains(displayText, typed);
	},

	initTable: function (opts) {
		var rootId = (opts && opts.rootId) || EwCommon.TABLE_ROOT;
		var emptyMessage = (opts && opts.emptyMessage) || "No warranty requests found.";
		Common.DataTable.init({
			rootId: rootId,
			tableId: (opts && opts.tableId) || "ew_requests_table",
			tbodyId: (opts && opts.tbodyId) || "ew_requests_rows",
			pageSizes: [50, 100, 150, 200],
			pageSize: 50,
			filter_type: "minimal",
			searchPlaceholder: "Search requests...",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "full",
			maxHeight: "520px",
			emptyMessage: emptyMessage,
			columns: [
				{ title: "View", field: "action_html", type: "html", searchable: false, sortable: false, width: 70 },
				{ title: "Request ID", field: "req_id", sortable: true, width: 130 },
				{ title: "Request Date", field: "request_date", sortable: true, width: 120 },
				{ title: "Customer", field: "customer", sortable: true, width: 200 },
				{ title: "Distributor", field: "distributor", sortable: true, width: 200 },
				{ title: "Converter", field: "converter", sortable: true, width: 200 },
				{ title: "Warranty Template", field: "wrty_template", sortable: true, width: 200 },
				{ title: "Status", field: "status_html", type: "html", searchable: true, sortable: false, width: 180 }
			],
			rows: []
		});
	},

	bindFilters: function ($scope, tableRoot, opts) {
		if (!$scope || !$scope.length) {
			return;
		}
		opts = opts || {};
		EwCommon.ensureAutocomplete(function () {
			if (!window.CsdAutocomplete) {
				return;
			}
			var ac = {
				persona: opts.persona || "converter",
				custCode: opts.custCode || "",
				loginId: opts.loginId || "",
				$home: $scope
			};
			CsdAutocomplete.bind($scope.find(".ew-f-req-id"), {
				type: "requestid",
				persona: ac.persona,
				custCode: ac.custCode,
				loginId: ac.loginId,
				$hidden: $scope.find(".ew-f-req-id-code"),
				$home: ac.$home,
				spinnerSel: ".ew-f-req-id-spin"
			});
			CsdAutocomplete.bind($scope.find(".ew-f-dist"), {
				type: "distributor",
				persona: ac.persona,
				custCode: ac.custCode,
				loginId: ac.loginId,
				$hidden: $scope.find(".ew-f-dist-code"),
				$home: ac.$home,
				spinnerSel: ".ew-f-dist-spin"
			});
			CsdAutocomplete.bind($scope.find(".ew-f-conv"), {
				type: "converter",
				persona: ac.persona,
				custCode: ac.custCode,
				loginId: ac.loginId,
				$hidden: $scope.find(".ew-f-conv-code"),
				$home: ac.$home,
				spinnerSel: ".ew-f-conv-spin"
			});
			CsdAutocomplete.bind($scope.find(".ew-f-cust"), {
				type: "customer",
				persona: ac.persona,
				custCode: ac.custCode,
				loginId: ac.loginId,
				$hidden: $scope.find(".ew-f-cust-code"),
				$home: ac.$home,
				spinnerSel: ".ew-f-cust-spin"
			});
		});
		$scope.find(".ew-f-search").off("click.ewf").on("click.ewf", function () {
			EwCommon.applyFilters($scope, tableRoot);
		});
		$scope.find(".ew-f-reset").off("click.ewf").on("click.ewf", function () {
			$scope.find(".ew-f-req-id, .ew-f-req-date, .ew-f-dist, .ew-f-conv, .ew-f-cust").val("");
			$scope.find(".ew-f-req-id-code, .ew-f-dist-code, .ew-f-conv-code, .ew-f-cust-code").val("");
			$scope.find(".ew-f-status").val("");
			EwCommon.applyFilters($scope, tableRoot);
		});
		$scope.find(".ew-f-req-id, .ew-f-req-date, .ew-f-dist, .ew-f-conv, .ew-f-cust")
			.off("keydown.ewf").on("keydown.ewf", function (event) {
				if (event.key === "Enter") {
					event.preventDefault();
					EwCommon.applyFilters($scope, tableRoot);
				}
			});
		$scope.off("click.ewfdate").on("click.ewfdate", ".ew-f-date-btn", function (event) {
			event.preventDefault();
			event.stopPropagation();
			EwCommon.openClosestDate(this);
		});
	},

	ensureAutocomplete: function (done) {
		if (window.CsdAutocomplete && typeof CsdAutocomplete.bind === "function") {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		$.getScript((window.$app_url || "") + "custom_js/EWARRANTY/csd_autocomplete.js")
			.done(function () {
				if (typeof done === "function") {
					done();
				}
			})
			.fail(function () {
				if (typeof done === "function") {
					done();
				}
			});
	},

	ensureAcLoader: function ($txt) {
		if (!$txt || !$txt.length) {
			return "";
		}
		$txt.addClass("pe-4 ac_loader");
		var id = String($txt.attr("id") || "").trim();
		if (!id) {
			id = "ew_ac_" + String(Date.now()) + String(Math.floor(Math.random() * 1000));
			$txt.attr("id", id);
		}
		var spinId = id + "_ac_spinner";
		var $parent = $txt.parent();
		if (!$parent.hasClass("inpc-ac-field-wrap") && !$parent.hasClass("ew-nr-ac-wrap") && !$parent.hasClass("ew-ac-wrap")) {
			$txt.wrap('<div class="position-relative inpc-ac-field-wrap ew-ac-wrap"></div>');
			$parent = $txt.parent();
		}
		if ($parent.css("position") === "static") {
			$parent.css("position", "relative");
		}
		if (!$parent.find("#" + spinId).length) {
			$txt.after(
				'<span id="' + spinId + '" class="inpc-ac-spinner ac_loader" role="status" aria-hidden="true" hidden>'
				+ '<span class="spinner-border spinner-border-sm text-primary"></span></span>'
			);
		}
		var errId = id + "_ac_error";
		if (!$parent.siblings("#" + errId).length && !$parent.parent().find("#" + errId).length) {
			$parent.after(
				'<div id="' + errId + '" class="ew-nr-ac-error text-danger small mt-1 d-none" role="alert"></div>'
			);
		}
		return spinId;
	},

	/** Show DB / AC failures next to the autocomplete input (not only top banner). */
	showAcFieldError: function ($txt, message) {
		if (!$txt || !$txt.length) {
			return;
		}
		var id = String($txt.attr("id") || "").trim();
		if (!id) {
			return;
		}
		var $err = $("#" + id + "_ac_error");
		if (!$err.length) {
			var $wrap = $txt.closest(".inpc-ac-field-wrap, .ew-nr-ac-wrap, .ew-ac-wrap");
			if ($wrap.length) {
				$wrap.after(
					'<div id="' + id + '_ac_error" class="ew-nr-ac-error text-danger small mt-1" role="alert"></div>'
				);
				$err = $("#" + id + "_ac_error");
			}
		}
		var text = String(message || "").trim();
		if (!text) {
			$err.addClass("d-none").empty();
			$txt.removeClass("is-invalid ew-nr-invalid");
			return;
		}
		$err.removeClass("d-none").text(text);
		$txt.addClass("is-invalid ew-nr-invalid");
	},

	clearAcFieldError: function ($txt) {
		EwCommon.showAcFieldError($txt, "");
	},

	showAcLoader: function ($txt, spinId) {
		if (window.Common && typeof Common.ShowAcSpinner === "function") {
			var $home = $txt.closest("[id^='m_ew_']");
			Common.ShowAcSpinner($home.length ? ("#" + $home.attr("id")) : null, spinId);
			return;
		}
		$("#" + spinId).prop("hidden", false).attr("aria-hidden", "false");
	},

	hideAcLoader: function ($txt, spinId) {
		if (window.Common && typeof Common.HideAcSpinner === "function") {
			var $home = $txt.closest("[id^='m_ew_']");
			Common.HideAcSpinner($home.length ? ("#" + $home.attr("id")) : null, spinId);
			return;
		}
		$("#" + spinId).prop("hidden", true).attr("aria-hidden", "true");
	},

	openModuleDate: function (moduleName, fieldId) {
		fieldId = String(fieldId || "").replace(/^#/, "");
		moduleName = String(moduleName || "ew_new_request").replace(/^m_/, "");
		var $el = $("#m_" + moduleName + " #" + fieldId);
		if (!$el.length) {
			$el = $("#" + fieldId);
		}
		$el = $el.first();
		if (!$el.length) {
			return false;
		}
		$el.removeAttr("readonly").prop("readonly", false).prop("disabled", false);
		var v = String($el.val() || "").trim();
		if (!v || v === "00/00/0000" || v === "00-00-0000" || /^0+[\/\-]0+[\/\-]0+$/.test(v)) {
			$el.val("");
		}
		if (typeof $el.datepicker !== "function") {
			return false;
		}
		try {
			if ($el.data("datepicker")) {
				$el.datepicker("destroy");
			}
		} catch (ignore) { /* first open */ }
		$el.datepicker({
			autoclose: true,
			format: "dd/mm/yyyy",
			todayBtn: "linked",
			todayHighlight: true,
			forceParse: false,
			enableOnReadonly: true,
			container: "body",
			zIndexOffset: 4000,
			orientation: "bottom auto",
			defaultViewDate: new Date()
		}).on("show", function () {
			$(".datepicker").css("z-index", 5000);
		});
		$el.datepicker("show");
		$(".datepicker").css({ zIndex: 5000, cursor: "pointer" });
		$(".prev, .next").css("cursor", "pointer");
		return false;
	},

	openClosestDate: function (el) {
		var $btn = $(el);
		var $input = $btn.closest(".input-group").find("input");
		var id = String($input.attr("id") || $btn.attr("data-date-id") || "").trim();
		var $home = $input.closest("[id^='m_ew_']");
		var module = String($home.attr("id") || "ew_new_request").replace(/^m_/, "");
		if (id) {
			return EwCommon.openModuleDate(module, id);
		}
		EwCommon.openFilterDate($input);
		return false;
	},

	findDateInput: function (fromEl) {
		var $src = $(fromEl);
		var id = String($src.attr("data-date-id") || $src.find("[data-date-id]").attr("data-date-id") || "").trim();
		var module = String($src.attr("data-date-module") || $src.find("[data-date-module]").attr("data-date-module") || "").trim();
		if (id) {
			if (module) {
				return $("#m_" + module.replace(/^m_/, "") + " #" + id).add("#" + id).first();
			}
			return $("#m_ew_new_request #" + id)
				.add("#m_ew_conv_home #" + id)
				.add("#m_ew_dist_home #" + id)
				.add("#" + id)
				.first();
		}
		return $src.closest(".input-group").find("input.datepicker, input.date-picker").first();
	},

	bindPortalDates: function () {
		$(document).off("click.ewdate").on("click.ewdate",
			".ew-nr-date-btn, .ew-f-date-btn",
			function (event) {
				event.preventDefault();
				event.stopImmediatePropagation();
				var $btn = $(this);
				var id = String($btn.attr("data-date-id") || $btn.find("[data-date-id]").attr("data-date-id") || "").trim();
				var module = String($btn.attr("data-date-module") || "ew_new_request").replace(/^m_/, "");
				if (!id) {
					id = String($btn.closest(".input-group").find("input").attr("id") || "");
				}
				if (id) {
					EwCommon.openModuleDate(module, id);
				}
			});
	},

	initFilterDate: function ($el) {
		if (!$el || !$el.length) {
			return;
		}
		$el = $el.first();
		$el.prop("readonly", false).prop("disabled", false);
		if (typeof $el.datepicker !== "function") {
			return;
		}
		try {
			if ($el.data("datepicker")) {
				$el.datepicker("destroy");
			}
		} catch (ignore) { /* first bind */ }
		try {
			if ($el.data("ui-datepicker")) {
				$el.datepicker("destroy");
			}
		} catch (ignore2) { /* not jquery-ui */ }
		var opts = {
			autoclose: true,
			format: "dd/mm/yyyy",
			dateFormat: "dd/mm/yy",
			todayBtn: "linked",
			todayHighlight: true,
			forceParse: false,
			enableOnReadonly: true,
			container: "body",
			orientation: "bottom auto",
			defaultViewDate: new Date()
		};
		try {
			$el.datepicker(opts);
		} catch (ex) {
			try {
				$el.datepicker({ dateFormat: "dd/mm/yy", changeMonth: true, changeYear: true });
			} catch (ex2) { /* no picker plugin */ }
		}
		$el.off("show.ewz").on("show.ewz", function () {
			$("div.datepicker.datepicker-dropdown, #ui-datepicker-div").css("z-index", 5000);
		});
	},

	openFilterDate: function ($el) {
		if (!$el || !$el.length || $el.prop("disabled")) {
			return;
		}
		EwCommon.initFilterDate($el);
		var v = String($el.val() || "").trim();
		if (!v || v === "00/00/0000" || v === "00-00-0000" || /^0+[\/\-]0+[\/\-]0+$/.test(v)) {
			$el.val("");
		}
		try {
			$el.datepicker("show");
		} catch (ex) { /* ignore */ }
		$("div.datepicker.datepicker-dropdown, #ui-datepicker-div").css("z-index", 5000);
	},

	fillStatusOptions: function ($scope, rows) {
		var $sel = $scope.find(".ew-f-status");
		if (!$sel.length) {
			return;
		}
		var current = $sel.val();
		var seen = {};
		var statuses = [];
		(rows || []).forEach(function (row) {
			var status = String(row.status || "").trim();
			if (!status || seen[status]) {
				return;
			}
			seen[status] = true;
			statuses.push(status);
		});
		statuses.sort();
		$sel.empty().append('<option value="">All</option>');
		statuses.forEach(function (status) {
			$sel.append($("<option></option>").val(status).text(status));
		});
		if (current && seen[current]) {
			$sel.val(current);
		}
	},

	applyFilters: function ($scope, tableRoot) {
		var all = $scope.data("ewAllRows") || [];
		var reqId = String($scope.find(".ew-f-req-id-code").val() || $scope.find(".ew-f-req-id").val() || "").trim();
		var reqDate = EwCommon.dateKey($scope.find(".ew-f-req-date").val());
		var distCode = String($scope.find(".ew-f-dist-code").val() || "").trim();
		var convCode = String($scope.find(".ew-f-conv-code").val() || "").trim();
		var custCode = String($scope.find(".ew-f-cust-code").val() || "").trim();
		var dist = String($scope.find(".ew-f-dist").val() || "").trim();
		var conv = String($scope.find(".ew-f-conv").val() || "").trim();
		var cust = String($scope.find(".ew-f-cust").val() || "").trim();
		var status = String($scope.find(".ew-f-status").val() || "").trim();
		var filtered = all.filter(function (row) {
			if (reqId && String(row.req_id || "") !== reqId && !EwCommon.contains(row.req_id, reqId)) {
				return false;
			}
			if (reqDate && EwCommon.dateKey(row.request_date) !== reqDate) {
				return false;
			}
			if (!EwCommon.codeMatch(row.dist_code, distCode, row.distributor, dist)) {
				return false;
			}
			if (!EwCommon.codeMatch(row.conv_code, convCode, row.converter, conv)) {
				return false;
			}
			if (!EwCommon.codeMatch(row.cust_code, custCode, row.customer, cust)) {
				return false;
			}
			if (status && String(row.status || "") !== status) {
				return false;
			}
			return true;
		});
		Common.DataTable.setData(tableRoot, filtered);
	},

	comingSoonHtml: function (title) {
		return '<div class="alert alert-info m-3 mb-0" role="status">'
			+ '<strong>' + EwCommon.esc(title) + '</strong> — coming in the next phase.</div>';
	}
};
