/**
 * E-Warranty Converter — plain jQuery.
 * Flow: Load → context → tabs → .load HTML once → list API → DataTable.
 */
EwConv = {
	API: "api/customer/ewarranty/converter",
	HOME: "m_ew_conv_home",
	TABLE_ROOT: "m_ew_conv_table_root",
	TABLE_ID: "ew_conv_requests_table",
	TBODY_ID: "ew_conv_requests_rows",
	custCode: "",
	loginId: "",
	requestsHtmlLoaded: false,
	newHtmlLoaded: false,

	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + EwConv.HOME) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $("#" + EwConv.HOME).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $("#" + EwConv.HOME).first();
	},

	_$: function (selector) {
		var $home = EwConv._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		return $home.find(selector);
	},

	Load: function () {
		EwConv.ensureCommon(function () {
			if (window.EwCommon && typeof EwCommon.bindPortalDates === "function") {
				EwCommon.bindPortalDates();
			}
			var ctx = EwCommon.procedureContext();
			EwConv.custCode = ctx.custCode;
			EwConv.loginId = ctx.loginId;
			EwConv.requestsHtmlLoaded = false;
			EwConv.newHtmlLoaded = false;

			EwConv._$("#ew_conv_requests_tab").off("click").on("click", function () {
				EwConv.showTab("requests");
			});
			EwConv._$("#ew_conv_new_tab").off("click").on("click", function () {
				EwConv.showTab("new");
			});

			EwConv.loadContext(function () {
				EwConv.showTab("requests");
			});
		});
	},

	ensureCommon: function (done) {
		if (window.EwCommon && typeof EwCommon.procedureContext === "function") {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		$.getScript((window.$app_url || "") + "custom_js/EWARRANTY/ew_common.js")
			.done(function () {
				if (typeof done === "function") {
					done();
				}
			})
			.fail(function () {
				EwConv.setContext("Unable to load E-Warranty common script.", true);
			});
	},

	showTab: function (name) {
		var tabs = {
			requests: { tab: "ew_conv_requests_tab", panel: "ew_conv_requests_panel" },
			new: { tab: "ew_conv_new_tab", panel: "ew_conv_new_panel" }
		};
		var active = tabs[name] || tabs.requests;
		Object.keys(tabs).forEach(function (key) {
			var t = tabs[key];
			var selected = t.tab === active.tab;
			EwConv._$("#" + t.tab).attr("aria-selected", selected ? "true" : "false");
			EwConv._$("#" + t.panel).toggleClass("d-none", !selected);
		});
		if (name === "new") {
			EwConv.openNewTab();
		} else {
			EwConv.openRequestsTab();
		}
	},

	openRequestsTab: function () {
		if (EwConv.requestsHtmlLoaded && EwConv._$(".ew-requests-shell").length) {
			return;
		}
		var url = (window.$app_url || "") + "html_files/EWARRANTY/ew_requests.html?r=" + Date.now();
		showLoader("Loading Warranty Requests...", EwConv.HOME);
		EwConv._$("#ew_conv_requests_panel").load(url, function (_html, status) {
			hideLoader(EwConv.HOME);
			if (status !== "success") {
				EwConv._$("#ew_conv_requests_panel").html(
					'<div class="alert alert-danger m-3">Unable to load Warranty Requests.</div>');
				return;
			}
			EwConv.requestsHtmlLoaded = true;
			EwCommon.stampListIds(EwConv._$home(), {
				rootId: EwConv.TABLE_ROOT,
				tableId: EwConv.TABLE_ID,
				tbodyId: EwConv.TBODY_ID,
				dateId: "ew_conv_req_date",
				reqIdAc: "ew_conv_f_req_id",
				distAc: "ew_conv_f_dist",
				convAc: "ew_conv_f_conv",
				custAc: "ew_conv_f_cust"
			});
			EwConv._$(".ew-requests-eyebrow").text("Requests for the working converter");
			EwCommon.initTable({
				rootId: EwConv.TABLE_ROOT,
				tableId: EwConv.TABLE_ID,
				tbodyId: EwConv.TBODY_ID,
				emptyMessage: "No warranty requests found for this converter."
			});
			EwCommon.bindFilters(EwConv._$(".ew-requests-shell"), EwConv.TABLE_ROOT, {
				persona: "converter",
				custCode: EwConv.custCode,
				loginId: EwConv.loginId
			});
			EwConv._$(".ew-requests-table").off("click", ".ew-view-request")
				.on("click", ".ew-view-request", function () {
					var id = String($(this).attr("data-int-code") || "");
					EwConv.openView(id);
				});
			EwConv._$(".ew-requests-refresh").off("click").on("click", function () {
				EwConv.loadRequests();
			});
			EwConv.loadRequests();
		});
	},

	openNewTab: function () {
		if (EwConv.newHtmlLoaded && EwConv._$("#m_ew_new_request").length) {
			EwConv.ensureNewRequestJs(function () {
				if (window.EwNewRequest && typeof EwNewRequest.Load === "function") {
					EwNewRequest.Load();
				}
			});
			return;
		}
		var url = (window.$app_url || "") + "html_files/EWARRANTY/ew_new_request.html?r=" + Date.now();
		showLoader("Loading Request New Warranty...", EwConv.HOME);
		EwConv._$("#ew_conv_new_panel").load(url, function (_html, status) {
			hideLoader(EwConv.HOME);
			if (status !== "success") {
				EwConv._$("#ew_conv_new_panel").html(
					'<div class="alert alert-danger m-3">Unable to load Request New Warranty.</div>');
				return;
			}
			EwConv.newHtmlLoaded = true;
			EwConv.ensureNewRequestJs(function () {
				if (window.EwNewRequest && typeof EwNewRequest.Load === "function") {
					EwNewRequest.Load();
				}
			});
		});
	},

	ensureNewRequestJs: function (done) {
		if (window.EwNewRequest && typeof EwNewRequest.Load === "function") {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		$.getScript((window.$app_url || "") + "custom_js/EWARRANTY/ew_new_request.js")
			.done(function () {
				if (typeof done === "function") {
					done();
				}
			})
			.fail(function () {
				EwConv._$("#ew_conv_new_panel").prepend(
					'<div class="alert alert-danger m-3">Unable to load New Request script.</div>');
			});
	},

	openView: function (internalCode) {
		EwConv.ensurePopupJs(function () {
			EwReqPopup.open({
				$home: EwConv._$home(),
				api: EwConv.API,
				custCode: EwConv.custCode,
				loginId: EwConv.loginId,
				internalCode: internalCode
			});
		});
	},

	ensurePopupJs: function (done) {
		if (window.EwReqPopup && typeof EwReqPopup.open === "function") {
			if (typeof done === "function") {
				done();
			}
			return;
		}
		$.getScript((window.$app_url || "") + "custom_js/EWARRANTY/ew_req_popup.js")
			.done(function () {
				if (typeof done === "function") {
					done();
				}
			})
			.fail(function () {
				alert("Unable to load request details.");
			});
	},

	loadContext: function (done) {
		showLoader("Loading E-Warranty Converter...", EwConv.HOME);
		$.ajax({
			url: (window.$app_url || "") + EwConv.API + "/context",
			method: "GET",
			data: { custCode: EwConv.custCode, loginId: EwConv.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (EwCommon.isSessionGone(json)) {
				hideLoader(EwConv.HOME);
				return;
			}
			if (!EwCommon.ok(json)) {
				EwConv.setContext(
					(json && json.message) || "Unable to load converter context.", true);
				hideLoader(EwConv.HOME);
				return;
			}
			var data = json.data || {};
			EwConv.custCode = String(data.custCode || data.convCode || EwConv.custCode).trim();
			if (data.convDisplay) {
				EwConv.setContext(
					"Converter: " + data.convDisplay
					+ (data.source === "change_customer" ? " (Change Customer)" : ""), false);
			} else {
				EwConv.setContext("Converter ready", false);
			}
			hideLoader(EwConv.HOME);
			if (typeof done === "function") {
				done();
			}
		}).fail(function () {
			EwConv.setContext("Unable to load converter context.", true);
			hideLoader(EwConv.HOME);
		});
	},

	setContext: function (message, isError) {
		EwConv._$("#ew_conv_context_label")
			.toggleClass("is-error", !!isError)
			.attr("role", isError ? "alert" : null)
			.text(message || "");
	},

	loadRequests: function () {
		EwConv._$(".ew-requests-refresh").prop("disabled", true).addClass("is-refreshing");
		showLoader("Loading warranty requests...", "ew_conv_requests_panel");
		$.ajax({
			url: (window.$app_url || "") + EwConv.API + "/requests",
			method: "GET",
			data: { custCode: EwConv.custCode, loginId: EwConv.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			if (EwCommon.isSessionGone(json)) {
				return;
			}
			if (!EwCommon.ok(json)) {
				EwConv.showMsg((json && json.message) || "Unable to load requests.", true);
				return;
			}
			var list = (json.data && json.data.requests) || [];
			var rows = [];
			for (var i = 0; i < list.length; i++) {
				rows.push(EwCommon.toRow(list[i]));
			}
			var $shell = EwConv._$(".ew-requests-shell");
			$shell.data("ewAllRows", rows);
			EwCommon.fillStatusOptions($shell, rows);
			EwCommon.applyFilters($shell, EwConv.TABLE_ROOT);
			EwConv.showMsg(rows.length ? "" : "No warranty requests found for this converter.", false);
		}).fail(function () {
			EwConv.showMsg("Unable to load warranty requests.", true);
		}).always(function () {
			hideLoader("ew_conv_requests_panel");
			EwConv._$(".ew-requests-refresh").prop("disabled", false).removeClass("is-refreshing");
		});
	},

	showMsg: function (message, isError) {
		EwConv._$(".ew-requests-msg")
			.toggleClass("alert-warning", !isError)
			.toggleClass("alert-danger", !!isError)
			.toggleClass("alert-success", false)
			.toggleClass("d-none", !message)
			.text(message || "");
	}
};
