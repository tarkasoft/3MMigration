/**
 * E-Warranty View — legacy EWReqPopup.GetApprovalDetailsForPopup
 * (ew_my_approval_popup + product 1–5 / PPF popup fragments).
 */
EwReqPopup = {
	open: function (opts) {
		opts = opts || {};
		var $home = opts.$home;
		var internalCode = String(opts.internalCode || "").trim();
		if (!$home || !$home.length || !internalCode) {
			return;
		}
		var $modal = $home.find(".ew-detail-modal").first();
		var $body = $modal.find(".ew-detail-content");
		$body.html('<div class="text-muted small p-2">Loading request details...</div>');
		EwReqPopup.show($modal);
		var target = $body.attr("id") || $home.attr("id");
		showLoader("Loading request details...", target);
		var fragUrl = (window.$app_url || "") + "html_files/EWARRANTY/ew_req_popup.html?r=" + Date.now();
		var htmlReq = $.get(fragUrl);
		var dataReq = $.ajax({
			url: (window.$app_url || "") + opts.api + "/requests/" + encodeURIComponent(internalCode),
			method: "GET",
			data: { custCode: opts.custCode || "", loginId: opts.loginId || "" },
			dataType: "json",
			xhrFields: { withCredentials: true }
		});
		$.when(htmlReq, dataReq).done(function (htmlRes, dataRes) {
			$body.html(htmlRes[0] || htmlRes);
			var json = dataRes[0] || dataRes;
			if (window.EwCommon && EwCommon.isSessionGone(json)) {
				return;
			}
			if (!window.EwCommon || !EwCommon.ok(json)) {
				EwReqPopup.msg($home.find(".ew-d-root"),
					(json && json.message) || "Unable to load request details.", true);
				return;
			}
		EwReqPopup.fill($home.find(".ew-d-root"), json.data || {}, opts);
		}).fail(function () {
			$body.html('<div class="alert alert-danger">Unable to load request details.</div>');
		}).always(function () {
			hideLoader(target);
		});
	},

	show: function ($modal) {
		var el = $modal && $modal.get ? $modal.get(0) : null;
		if (!el) {
			return;
		}
		if (window.bootstrap && bootstrap.Modal) {
			bootstrap.Modal.getOrCreateInstance(el).show();
		} else if ($.fn.modal) {
			$(el).modal("show");
		}
	},

	msg: function ($root, text, isError) {
		$root.find(".ew-d-msg")
			.toggleClass("d-none", !text)
			.toggleClass("alert-danger", !!isError)
			.toggleClass("alert-warning", !isError)
			.text(text || "");
	},

	txt: function (value) {
		return String(value == null ? "" : value);
	},

	empty: function (value) {
		return !EwReqPopup.txt(value).trim();
	},

	join: function () {
		var parts = [];
		for (var i = 0; i < arguments.length; i++) {
			var s = EwReqPopup.txt(arguments[i]).trim();
			if (s && s !== "null" && s !== "undefined") {
				parts.push(s);
			}
		}
		return parts.join(", ");
	},

	esc: function (value) {
		if (window.EwCommon && EwCommon.esc) {
			return EwCommon.esc(value);
		}
		return EwReqPopup.txt(value)
			.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	},

	fileCell: function (name, path) {
		var n = EwReqPopup.txt(name);
		if (!n) {
			return "";
		}
		return '<a href="#" class="ew-d-file" data-name="' + EwReqPopup.esc(n)
			+ '" data-path="' + EwReqPopup.esc(path || "") + '">'
			+ EwReqPopup.esc(n) + "</a>";
	},

	first: function (list) {
		return (list && list.length) ? list[0] : {};
	},

	header: function (data) {
		if (data.header && typeof data.header === "object" && !Array.isArray(data.header)) {
			return data.header;
		}
		return EwReqPopup.first(data.header_details);
	},

	grepProd: function (rows, slot) {
		var want = String(slot);
		return (rows || []).filter(function (item) {
			return String(item.prod_ref_code || "") === want;
		});
	},

	isPpf: function (h) {
		return String(h.wrty_template || "").indexOf("Paint Protection") >= 0
			|| String(h.wrty_type || "").toUpperCase() === "PPF";
	},

	invTable: function (rows) {
		var html = "<table><thead><tr>"
			+ "<th>Invoice No</th><th>Invoice Date</th><th>Invoice Document</th>"
			+ "</tr></thead><tbody>";
		if (!rows || !rows.length) {
			html += "<tr><td></td><td></td><td></td></tr>";
		} else {
			for (var i = 0; i < rows.length; i++) {
				var r = rows[i];
				html += "<tr><td>" + EwReqPopup.esc(r.ctc_invoice_no || r.invoice_no)
					+ "</td><td>" + EwReqPopup.esc(r.ctc_invoice_date || r.invoice_date)
					+ "</td><td>" + EwReqPopup.fileCell(
						r.ftp_file_name || r.file_name,
						r.ftp_file_path || r.file_path)
					+ "</td></tr>";
			}
		}
		return html + "</tbody></table>";
	},

	vinylTable: function (products, ppf, labels) {
		labels = labels || {};
		var html = "<table><thead><tr>"
			+ "<th>" + EwReqPopup.esc(labels.film || "3M Primary Film/Vinyl") + "</th>";
		if (!ppf) {
			html += "<th>Color</th>";
		}
		html += "<th>" + EwReqPopup.esc(labels.lot || "LOT NO.") + "</th>";
		if (ppf) {
			html += "<th>PPF Unique Lot No</th>";
		}
		html += "<th>" + EwReqPopup.esc(labels.qty || "Quantity (sq.ft)") + "</th>"
			+ "</tr></thead><tbody>";
		if (!products || !products.length) {
			html += ppf ? "<tr><td></td><td></td><td></td><td></td></tr>"
				: "<tr><td></td><td></td><td></td><td></td></tr>";
		} else {
			for (var i = 0; i < products.length; i++) {
				var p = products[i];
				html += "<tr><td>" + EwReqPopup.esc(p.vinyl) + "</td>";
				if (!ppf) {
					html += "<td>" + EwReqPopup.esc(p.color) + "</td>";
				}
				html += "<td>" + EwReqPopup.esc(p.lot_no) + "</td>";
				if (ppf) {
					html += "<td>" + EwReqPopup.esc(p.vinyl_unique_lot_no) + "</td>";
				}
				html += "<td>" + EwReqPopup.esc(p.quantity) + "</td></tr>";
			}
		}
		return html + "</tbody></table>";
	},

	secVinylTable: function (rows) {
		var html = "<table><thead><tr>"
			+ "<th>3M Secondary Film / Vinyl</th><th>Color</th>"
			+ "<th>Lot No</th><th>Quantity</th></tr></thead><tbody>";
		if (!rows || !rows.length) {
			html += "<tr><td></td><td></td><td></td><td></td></tr>";
		} else {
			for (var i = 0; i < rows.length; i++) {
				var r = rows[i];
				html += "<tr><td>" + EwReqPopup.esc(r.vinyl)
					+ "</td><td>" + EwReqPopup.esc(r.color)
					+ "</td><td>" + EwReqPopup.esc(r.lot_no)
					+ "</td><td>" + EwReqPopup.esc(r.quantity) + "</td></tr>";
			}
		}
		return html + "</tbody></table>";
	},

	/**
	 * Graphics (legacy popup): Width, Height, Unit, Area, Quantity(pcs), Picture, Remarks,If Any.
	 * PPF: Picture + Area of Application only.
	 * DB: dimension = area; description = remarks.
	 */
	proofTable: function (rows, ppf) {
		var html = "<table><thead><tr>";
		if (!ppf) {
			html += "<th>Width</th><th>Height</th><th>Unit</th><th>Area</th>"
				+ "<th>Quantity(pcs)</th><th>Picture</th><th>Remarks, If Any</th>";
		} else {
			html += "<th>Picture</th><th>Area of Application</th>";
		}
		html += "</tr></thead><tbody>";
		if (!rows || !rows.length) {
			html += ppf
				? "<tr><td></td><td></td></tr>"
				: "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
		} else {
			for (var i = 0; i < rows.length; i++) {
				var r = rows[i];
				var pic = EwReqPopup.fileCell(r.picture_name || r.picture, r.picture_path);
				var area = r.dimension || r.area || "";
				var remarks = r.description || r.remarks || r.area_of_application || "";
				html += "<tr>";
				if (!ppf) {
					html += "<td>" + EwReqPopup.esc(r.width) + "</td>"
						+ "<td>" + EwReqPopup.esc(r.height) + "</td>"
						+ "<td>" + EwReqPopup.esc(r.unit) + "</td>"
						+ "<td>" + EwReqPopup.esc(area) + "</td>"
						+ "<td>" + EwReqPopup.esc(r.quantity) + "</td>"
						+ "<td>" + pic + "</td>"
						+ "<td>" + EwReqPopup.esc(remarks) + "</td>";
				} else {
					html += "<td>" + pic + "</td>"
						+ "<td>" + EwReqPopup.esc(remarks) + "</td>";
				}
				html += "</tr>";
			}
		}
		return html + "</tbody></table>";
	},

	pair: function (label, value) {
		return "<td class='lbl'>" + EwReqPopup.esc(label) + "</td><td class='val'>"
			+ EwReqPopup.esc(value) + "</td>";
	},

	projectTable: function (p, sub, over, ppf) {
		p = p || {};
		sub = sub || {};
		over = over || {};
		if (ppf) {
			return "<table><tbody><tr>"
				+ EwReqPopup.pair("Warranty Life", p.warranty_life)
				+ "<td class='lbl'></td><td class='val'></td></tr></tbody></table>";
		}
		return "<table class='ew-d-g-proj'><tbody>"
			+ "<tr>" + EwReqPopup.pair("Application", p.application)
			+ EwReqPopup.pair("Graphic Conversion Method", p.graphic_conv_method) + "</tr>"
			+ "<tr>" + EwReqPopup.pair("Type of Exposure", p.type_of_exposure)
			+ EwReqPopup.pair("Application Substrate", p.substrate) + "</tr>"
			+ "<tr>" + EwReqPopup.pair("Overlaminate", over.overlaminate)
			+ EwReqPopup.pair("Overlaminate Lot No", over.overlaminate_lot_no) + "</tr>"
			+ "<tr>" + EwReqPopup.pair("3M Flexible Substrate", sub.m_flexible_substrate)
			+ EwReqPopup.pair("3M Flexible Substrate Lot No", sub.substrate_lot_no) + "</tr>"
			+ "<tr>" + EwReqPopup.pair("Printer Model", p.printer_format)
			+ EwReqPopup.pair("Print Platform", p.printing_hardware) + "</tr>"
			+ "<tr>" + EwReqPopup.pair("Ink", p.ink)
			+ EwReqPopup.pair("Edge Sealer", p.edge_sealer) + "</tr>"
			+ "<tr>" + EwReqPopup.pair("Warranty Life", p.warranty_life)
			+ "<td class='lbl'></td><td class='val'></td></tr>"
			+ "</tbody></table>";
	},

	vinylLabels: function (template, slot, ppf) {
		if (ppf) {
			return {
				film: "3M Primary Film/Vinyl " + slot,
				lot: "3M Primary Film/Vinyl " + slot + " LOT NO.",
				qty: "3M Primary Film/Vinyl " + slot + " Quantity (sq.ft)",
				title: "3M Primary Film/Vinyl " + slot + " Information"
			};
		}
		if (template === "Building Window Film Warranty") {
			return { film: "3M Building Window Film Series",
				lot: "3M Building Window Film LOT NO.",
				qty: "3M Building Window Film Quantity (sq.ft)",
				title: "Building Window Film Information" };
		}
		if (template === "DI-NOC Warranty") {
			return { film: "3M DI-NOC Series", lot: "3M DI-NOC LOT NO.",
				qty: "3M DI-NOC Quantity (sq.ft)", title: "DI-NOC Information" };
		}
		return {
			film: "3M Primary Film/Vinyl " + slot,
			lot: "3M Primary Film/Vinyl " + slot + " LOT NO.",
			qty: "3M Primary Film/Vinyl " + slot + " Quantity (sq.ft)",
			title: "3M Primary Film/Vinyl " + slot + " Information"
		};
	},

	productHtml: function (slot, ppf, template, data) {
		var vinyl = EwReqPopup.grepProd(data.vinyl_edit_obj || data.products, slot);
		if (!vinyl.length) {
			vinyl = data.vinyl_edit_obj || data.products || [];
		}
		var sec = EwReqPopup.grepProd(data.sec_vinyl_edit_obj, slot);
		var ctc = EwReqPopup.grepProd(data.ctc_doc_obj, slot);
		if (!ctc.length) {
			ctc = data.ctc_doc_obj || [];
		}
		var addnl = data.addnl_doc_obj || [];
		var poi = EwReqPopup.grepProd(data.poi_details || data.proof, slot);
		if (!poi.length) {
			poi = data.poi_details || data.proof || [];
		}
		var sub = EwReqPopup.first(EwReqPopup.grepProd(data.substrate_edit_obj, slot));
		var over = EwReqPopup.first(EwReqPopup.grepProd(data.overlaminate_edit_obj, slot));
		var labels = EwReqPopup.vinylLabels(template, slot, ppf);
		var storeTitle = ppf ? "Store Invoice Details" : "Converter to Customer Invoice Details";
		var distTitle = ppf ? "Distributor to Store Invoice Details"
			: "Distributor to Converter Invoice Details";
		var html = '<div class="ew-d-prod-pane' + (slot === 1 ? " is-on" : "")
			+ '" data-slot="' + slot + '">';
		if (ppf) {
			html += '<div class="ew-d-inv-wrap"><div class="ew-d-inv"><h4>'
				+ EwReqPopup.esc(storeTitle) + "</h4>"
				+ EwReqPopup.invTable(ctc) + "</div>"
				+ '<div class="ew-d-inv"><h4>' + EwReqPopup.esc(distTitle) + "</h4>"
				+ EwReqPopup.invTable(addnl) + "</div></div>";
		} else {
			html += '<div class="ew-d-inv ew-d-inv-yellow"><h4>'
				+ EwReqPopup.esc(distTitle) + "</h4>"
				+ EwReqPopup.invTable(addnl) + "</div>";
		}
		html += '<div class="ew-d-h-cyan">Project Information</div><div class="ew-d-proj">'
			+ EwReqPopup.projectTable(vinyl[0] || {}, sub, over, ppf) + "</div>";
		html += '<div class="ew-d-proof"><h4>Proof of Installation</h4>'
			+ EwReqPopup.proofTable(poi, ppf) + "</div>";
		html += '<div class="ew-d-h-cyan">' + EwReqPopup.esc(labels.title) + "</div>"
			+ '<div class="ew-d-vinyl">' + EwReqPopup.vinylTable(vinyl, ppf, labels) + "</div>";
		if (!ppf && template !== "Building Window Film Warranty" && template !== "DI-NOC Warranty") {
			html += '<div class="ew-d-h-cyan">Secondary Film / Vinyl</div>'
				+ '<div class="ew-d-sec-vinyl">' + EwReqPopup.secVinylTable(sec) + "</div>";
		}
		html += "</div>";
		return html;
	},

	fillApprovers: function ($root, rows) {
		var html = "";
		(rows || []).forEach(function (v, idx) {
			var dt = EwReqPopup.txt(v.modified_date);
			if (dt.indexOf("1900-01-01") === 0) {
				dt = "";
			}
			html += "<tr><td>" + (idx + 1) + "</td><td>" + EwReqPopup.esc(v.approver_role)
				+ "</td><td>" + EwReqPopup.esc(v.approver)
				+ "</td><td>" + EwReqPopup.esc(v.approval_status)
				+ "</td><td>" + EwReqPopup.esc(v.approval_remarks)
				+ "</td><td>" + EwReqPopup.esc(dt) + "</td></tr>";
		});
		$root.find(".ew-d-approvers").html(html);
	},

	fillHistory: function ($root, rows) {
		var html = "";
		(rows || []).forEach(function (v, idx) {
			html += "<tr><td>" + (idx + 1) + "</td><td>" + EwReqPopup.esc(v.approver_src)
				+ "</td><td>" + EwReqPopup.esc(v.approver_role)
				+ "</td><td>" + EwReqPopup.esc(v.updated_by_name)
				+ "</td><td>" + EwReqPopup.esc(v.created_date)
				+ "</td><td>" + EwReqPopup.esc(v.approver_status)
				+ "</td><td>" + EwReqPopup.esc(v.approver_remarks) + "</td></tr>";
		});
		$root.find(".ew-d-history").html(html);
	},

	fill: function ($root, data, opts) {
		opts = opts || {};
		$root.attr("data-ew-api", String(opts.api || "").replace(/\/$/, ""));
		$root.attr("data-ew-id", String(opts.internalCode || "").trim());
		$root.attr("data-ew-cust", opts.custCode || "");
		$root.attr("data-ew-login", opts.loginId || "");
		var h = EwReqPopup.header(data);
		var products = data.vinyl_edit_obj || data.products || [];
		var ppf = EwReqPopup.isPpf(h);
		var template = EwReqPopup.txt(h.wrty_template);
		var reqNo = EwReqPopup.txt(h.req_id);
		var reqDate = h.req_date || h.request_date || "";
		if (reqDate) {
			reqNo += (reqNo ? "-" : "") + reqDate;
		}
		$root.find(".ew-d-req-id").text(reqNo);
		$root.find(".ew-d-status-val").text(h.status || "");
		$root.find(".ew-d-wrty-type").text(template || h.wrty_type || "");
		$root.find(".ew-d-remarks").text(h.remarks || "");
		var nProd = parseInt(h.no_of_products, 10);
		if (!nProd || nProd < 1) {
			nProd = ppf ? 1 : Math.max(1, products.length || 1);
		}
		if (ppf) {
			nProd = 1;
		}
		$root.find(".ew-d-prod-count").text(String(nProd));
		$root.find(".ew-d-conv-row").toggleClass("d-none", ppf);
		$root.find(".ew-d-bill-lbl").text(ppf ? "Billing Customer Name" : "Customer");
		$root.find(".ew-d-dist-name").text(h.distributor || "");
		$root.find(".ew-d-dist-detail").text(EwReqPopup.join(
			h.dist_address, h.dist_city, h.dist_state, h.dist_email, h.dist_phone_no));
		$root.find(".ew-d-conv-name").text(h.converter || h.conv_name || "");
		$root.find(".ew-d-conv-detail").text(EwReqPopup.join(
			h.conv_address, h.conv_city, h.conv_state, h.conv_email, h.conv_phone_no));
		$root.find(".ew-d-bill-name").text(h.customer || h.ppf_cust_company_name || "");
		if (!EwReqPopup.empty(h.ppf_cust_address_1)) {
			$root.find(".ew-d-bill-detail").text(EwReqPopup.join(
				h.ppf_cust_address_1, h.ppf_cust_address_2, h.ppf_cust_city,
				h.ppf_cust_state, h.ppf_cust_email, h.ppf_cust_phone));
		} else {
			$root.find(".ew-d-bill-detail").text(EwReqPopup.join(
				h.cust_address, h.cust_city, h.cust_state, h.cust_email, h.cust_phone_no));
		}
		$root.find(".ew-d-appl-name").text(h.applicator || h.v_applicator_name || "");
		$root.find(".ew-d-appl-detail").text(EwReqPopup.empty(h.applicator) ? ""
			: EwReqPopup.join(h.app_address, h.app_city, h.app_state, h.app_email, h.app_phone_no));
		$root.find(".ew-d-psp").text(h.print_service_provider || "");
		$root.find(".ew-d-project").text(h.project_name || "");
		$root.find(".ew-d-inst-date").text(h.date_of_inst || "");
		$root.find(".ew-d-inst-type").text(h.inst_type || "");
		var vehicle = String(h.inst_type || "") === "Vehicle"
			&& (ppf || template === "Vehicle Personalization");
		var brand = String(h.inst_type || "") !== "Vehicle";
		$root.find(".ew-d-inst-vehicle").toggleClass("d-none", !vehicle);
		$root.find(".ew-d-inst-brand").toggleClass("d-none", !brand);
		$root.find(".ew-d-reg-no").text(h.reg_no || "");
		$root.find(".ew-d-end-cust").text(h.v_end_cust_name || "");
		$root.find(".ew-d-inst-place").text(h.v_inst_place || "");
		$root.find(".ew-d-vin").text(h.v_vin_no || "");
		$root.find(".ew-d-odo").text(h.v_odometer_rd || "");
		$root.find(".ew-d-model").text(h.v_car_model || "");
		$root.find(".ew-d-mobile").text(h.v_cust_mob_no || "");
		$root.find(".ew-d-email").text(h.v_email_id || "");
		$root.find(".ew-d-state").text(h.v_state || "");
		$root.find(".ew-d-addr1").text(h.v_address_1 || "");
		$root.find(".ew-d-addr2").text(h.v_address_2 || "");
		$root.find(".ew-d-app-type").text(h.v_to_app || "");
		$root.find(".ew-d-partial").text(h.partial_application_remarks || "");
		$root.find(".ew-d-partial-row").toggleClass("d-none",
			EwReqPopup.empty(h.partial_application_remarks) || !vehicle);
		$root.find(".ew-d-brand-name").text(h.end_cust_name || "");
		$root.find(".ew-d-brand-addr1").text(h.address_1 || "");
		$root.find(".ew-d-brand-addr2").text(h.address_2 || "");
		$root.find(".ew-d-branch-name").text(h.branch_site_name || "");
		$root.find(".ew-d-branch-id").text(h.branch_id || "");
		$root.find(".ew-d-brand-city").text(h.city || "");
		$root.find(".ew-d-brand-state").text(h.state || "");
		$root.find(".ew-d-brand-pin").text(h.postal_code || "");
		var tabs = "";
		var panes = "";
		for (var i = 1; i <= nProd; i++) {
			tabs += '<button type="button" class="' + (i === 1 ? "is-on" : "")
				+ '" data-slot="' + i + '">Graphic Element' + i + " / Signage" + i + "</button>";
			panes += EwReqPopup.productHtml(i, ppf, template, data);
		}
		$root.find(".ew-d-prod-tabs").html(tabs);
		$root.find(".ew-d-prod-host").html(panes);
		$root.find(".ew-d-prod-tabs").off("click.ewd").on("click.ewd", "button", function () {
			var slot = String($(this).attr("data-slot") || "1");
			$root.find(".ew-d-prod-tabs button").removeClass("is-on");
			$(this).addClass("is-on");
			$root.find(".ew-d-prod-pane").removeClass("is-on");
			$root.find('.ew-d-prod-pane[data-slot="' + slot + '"]').addClass("is-on");
		});
		$root.find(".ew-d-appr-tabs").off("click.ewa").on("click.ewa", "button", function () {
			var pane = String($(this).attr("data-pane") || "approvers");
			$root.find(".ew-d-appr-tab").removeClass("is-on");
			$(this).addClass("is-on");
			$root.find(".ew-d-appr-pane").removeClass("is-on");
			$root.find('.ew-d-appr-pane[data-pane="' + pane + '"]').addClass("is-on");
		});
		EwReqPopup.fillApprovers($root, data.approval_details);
		EwReqPopup.fillHistory($root, data.history_details);
		var closed = String(h.status || "").toLowerCase().indexOf("closed") >= 0;
		var $cert = $root.find(".ew-d-cert");
		var canPdf = closed;
		$cert.toggleClass("is-off", !canPdf);
		if (canPdf) {
			$cert.attr("href", "#");
			$cert.removeAttr("title");
		} else {
			$cert.attr("href", "#");
			$cert.attr("title", "Warranty PDF is available after the request is Closed");
		}
		EwReqPopup.bindDownloads($root, opts, h);
	},

	fileUrl: function (opts, h, name, path) {
		opts = opts || {};
		h = h || {};
		var id = String(h.req_int_code || opts.internalCode || "").trim();
		var api = String(opts.api || "").replace(/\/$/, "");
		if (!id || !api) {
			return "#";
		}
		return (window.$app_url || "") + api + "/requests/" + encodeURIComponent(id)
			+ "/files/download?" + $.param({
				fileName: name || "",
				filePath: path || "",
				custCode: opts.custCode || "",
				loginId: opts.loginId || ""
			});
	},

	bindDownloads: function ($root, opts, h) {
		var target = $root.closest(".ew-detail-content").attr("id")
			|| $root.closest(".modal-body").attr("id")
			|| $root.attr("id");
		$root.off("click.ewdl").on("click.ewdl", "a.ew-d-file, a.ew-d-cert", function (event) {
			event.preventDefault();
			event.stopPropagation();
			var $a = $(this);
			if ($a.hasClass("is-off") || $a.attr("aria-busy") === "true") {
				return;
			}
			var url = $a.hasClass("ew-d-cert")
				? EwReqPopup.certUrl(opts, h, "1")
				: EwReqPopup.fileUrl(opts, h, $a.attr("data-name"), $a.attr("data-path"));
			EwReqPopup.downloadBlob(url, target, $a);
		});
	},

	downloadBlob: function (url, target, $link) {
		if (!url || url === "#") {
			return;
		}
		var label = $link && $link.length ? $link.html() : "";
		if ($link && $link.length) {
			$link.attr("aria-busy", "true");
		}
		showLoader("Downloading...", target);
		fetch(url, { credentials: "same-origin", cache: "no-store" })
			.then(function (response) {
				if (response.status === 401 && window.inpcHandleSessionExpired) {
					window.inpcHandleSessionExpired("Please login once again");
					throw new Error("session");
				}
				if (!response.ok) {
					throw new Error("status");
				}
				var header = response.headers.get("Content-Disposition") || "";
				var encoded = /filename\*=UTF-8''([^;]+)/i.exec(header);
				var plain = /filename="([^"]+)"/i.exec(header);
				var name = encoded ? decodeURIComponent(encoded[1].trim())
					: (plain ? plain[1].trim() : "document");
				return response.blob().then(function (blob) {
					return { blob: blob, name: name };
				});
			})
			.then(function (file) {
				var objectUrl = URL.createObjectURL(file.blob);
				var saver = document.createElement("a");
				saver.href = objectUrl;
				saver.download = file.name || "document";
				document.body.appendChild(saver);
				saver.click();
				saver.remove();
				setTimeout(function () { URL.revokeObjectURL(objectUrl); }, 1500);
			})
			.catch(function (error) {
				if (error && error.message === "session") {
					return;
				}
				alert("The document could not be downloaded.");
			})
			.finally(function () {
				if ($link && $link.length) {
					$link.attr("aria-busy", "false").html(label);
				}
				hideLoader(target);
			});
	},

	certUrl: function (opts, h, slot) {
		opts = opts || {};
		var id = String((h && h.req_int_code) || opts.internalCode || "").trim();
		var api = String(opts.api || "").replace(/\/$/, "");
		if (!id || !api) {
			return "#";
		}
		return (window.$app_url || "") + api + "/requests/" + encodeURIComponent(id)
			+ "/products/" + encodeURIComponent(slot || "1") + "/warranty-pdf?"
			+ $.param({
				custCode: opts.custCode || "",
				loginId: opts.loginId || ""
			});
	}
};
