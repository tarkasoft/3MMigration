/**
 * Account Status (CUST_SERVICE/account_status.html).
 * One file for every tab. Page script calls AccountStatus.LoadAccountStatus().
 * First visit to a tab loads once. Coming back does not. Refresh loads again.
 * Date fields use the framework picker (dd/mm/yyyy): from = 1st of month, to = today.
 */
AccountStatus = {
	ROOT: "m_account_status",
	_busy: {},
	_tableReady: {},

	LoadAccountStatus: function () {
		var custCode = String(Common.GetCustCode() || "").trim();
		if (!custCode) {
			Common.showPageMsg(AccountStatus.ROOT, "Customer code is missing. Please re-login or select a customer.", "warning");
			return;
		}
		AccountStatus._bindOnce();
		AccountStatus._ensureDatePickers();
		AccountStatus._setDefaultDates();
		AccountStatus._showCustLine();
		AccountStatus._load("summary", false);
	},

	/**
	 * Override values are sent only for an authorised active override, and they
	 * are always a matched custCode + loginId pair. Empty values tell Java to use
	 * the authenticated session customer/login. Same contract as my_orders.js.
	 */
	_procedureContext: function () {
		if (Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	},

	ShowTab: function (btn) {
		var root = document.getElementById(AccountStatus.ROOT);
		if (!root || !btn) return false;
		var key = btn.getAttribute("data-as-tab");
		if (!key) return false;
		var tabs = root.querySelectorAll("#asTabs .nav-link");
		for (var i = 0; i < tabs.length; i++) {
			tabs[i].classList.remove("active");
			tabs[i].setAttribute("aria-selected", "false");
		}
		btn.classList.add("active");
		btn.setAttribute("aria-selected", "true");
		var panels = root.querySelectorAll(".as-panel");
		for (var j = 0; j < panels.length; j++) panels[j].classList.remove("active");
		var panel = root.querySelector("#as_panel_" + key);
		if (panel) panel.classList.add("active");
		if (key !== "summary") AccountStatus._load(key, false);
		return false;
	},

	_bindOnce: function () {
		if (window.__inpcAccountStatusBound) return;
		window.__inpcAccountStatusBound = true;
		$(document).on("click", "#m_account_status [data-as-refresh]", function (e) {
			e.preventDefault();
			AccountStatus._load($(this).attr("data-as-refresh"), true);
		});
		$(document).on("click", "#m_account_status [data-as-get]", function (e) {
			e.preventDefault();
			AccountStatus._load($(this).attr("data-as-get"), true);
		});
		$(document).on("click", "#m_account_status [data-as-filter]", function (e) {
			e.preventDefault();
			Common.DataTable.toggleFilters($(this).attr("data-as-filter"));
		});
	},

	_ensureDatePickers: function () {
		var $root = $("#" + AccountStatus.ROOT);
		if (!$root.length || !$.fn.datepicker) return;
		$root.find(".as-date").each(function () {
			var $el = $(this);
			$el.attr("data-date-format", "dd/mm/yyyy");
			$el.attr("placeholder", "dd/mm/yyyy");
			try { if ($el.data("datepicker")) $el.datepicker("destroy"); } catch (eD) { /* ignore */ }
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				format: "dd/mm/yyyy",
				orientation: "bottom auto",
				defaultViewDate: new Date()
			});
		});
	},

	_pad2: function (n) { return (Number(n) < 10 ? "0" : "") + Number(n); },

	_fmtDmy: function (d) {
		return AccountStatus._pad2(d.getDate()) + "/" + AccountStatus._pad2(d.getMonth() + 1) + "/" + d.getFullYear();
	},

	/** Empty date fields: from = beginning of month, to = today. */
	_setDefaultDates: function () {
		var today = new Date();
		var start = new Date(today.getFullYear(), today.getMonth(), 1);
		var fromText = AccountStatus._fmtDmy(start);
		var toText = AccountStatus._fmtDmy(today);
		function apply(id, text) {
			var $el = $("#" + id);
			if (!$el.length || String($el.val() || "").trim()) return;
			$el.val(text);
			try { $el.datepicker("update", text); } catch (eU) { /* ignore */ }
		}
		apply("as_paid_from", fromText);
		apply("as_paid_to", toText);
		apply("as_hist_from", fromText);
		apply("as_hist_to", toText);
	},

	_apiDate: function (id) {
		var ui = String($("#" + id).val() || "").trim();
		if (!ui || ui === "00/00/0000" || ui === "00-00-0000") return "";
		var api = (typeof DateFormatYYYYMMDD === "function") ? DateFormatYYYYMMDD(ui) : ui;
		return api === "00000000" ? "" : api;
	},

	_fmtAmt: function (n) {
		var num = Number(n);
		if (isNaN(num)) return n == null ? "" : String(n);
		try { return num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
		catch (e) { return String(num); }
	},

	_rupee: function (n) { return "\u20B9" + AccountStatus._fmtAmt(n); },

	_tabs: {
		summary: { api: "api/customer/account-status/summary" },
		payments_due: {
			api: "api/customer/account-status/payments-due",
			rootId: "m_as_payments_due",
			tableId: "as_payments_due_table",
			tbodyId: "as_payments_due_tbody",
			searchPlaceholder: "Filter payments due…",
			emptyMessage: "No payments due",
			money: ["invAmount", "balanceAmt", "amountToDebit", "balanceAfterDebit"],
			columns: [
				{ title: "Division", field: "division", sortable: true, width: 110 },
				{ title: "Type", field: "type", sortable: true, width: 100 },
				{ title: "Inv #", field: "invNo", sortable: true, width: 140 },
				{ title: "PO #", field: "poNo", sortable: true, width: 140 },
				{ title: "Payment Term", field: "paymentTerm", width: 130 },
				{ title: "Inv Date", field: "invDate", sortable: true, width: 110 },
				{ title: "Due Dt", field: "dueDate", sortable: true, width: 110 },
				{ title: "Inv Amount (Rs)", field: "invAmount", "text-align": "right", width: 140 },
				{ title: "Balance Amt (Rs)", field: "balanceAmt", "text-align": "right", width: 140 },
				{ title: "Amount to Debit (Rs)", field: "amountToDebit", "text-align": "right", width: 150 },
				{ title: "Balance After Debit (Rs)", field: "balanceAfterDebit", "text-align": "right", width: 160 }
			]
		},
		paid_invoices: {
			api: "api/customer/account-status/paid-invoices",
			rootId: "m_as_paid",
			tableId: "as_paid_table",
			tbodyId: "as_paid_tbody",
			searchPlaceholder: "Filter paid invoices…",
			emptyMessage: "No paid invoices",
			fromId: "as_paid_from",
			toId: "as_paid_to",
			money: ["invoiceAmount", "amount", "creditNoteAmount"],
			columns: [
				{ title: "Invoice Number", field: "invoiceNo", sortable: true },
				{ title: "Invoice Date", field: "invoiceDate", sortable: true },
				{ title: "PO Number", field: "poNo", sortable: true },
				{ title: "Invoice Amount", field: "invoiceAmount", "text-align": "right" },
				{ title: "Payment Reference", field: "paymentRef", sortable: true },
				{ title: "Amount (Rs)", field: "amount", "text-align": "right" },
				{ title: "Credit Note Adjusted", field: "creditNoteAdj" },
				{ title: "Amount (Rs)", field: "creditNoteAmount", "text-align": "right" },
				{ title: "Closed Date", field: "closedDate" },
				{ title: "Days To Pay", field: "daysToPay", "text-align": "right", sortable: true }
			]
		},
		unapplied: {
			api: "api/customer/account-status/unapplied",
			rootId: "m_as_unapplied",
			tableId: "as_unapplied_table",
			tbodyId: "as_unapplied_tbody",
			searchPlaceholder: "Filter unapplied…",
			emptyMessage: "No unapplied amounts",
			money: ["appliedAmount", "unappliedAmount"],
			columns: [
				{ title: "Payment Reference", field: "paymentRef", sortable: true },
				{ title: "Applied Amount (Rs)", field: "appliedAmount", "text-align": "right" },
				{ title: "Unapplied Amount (Rs)", field: "unappliedAmount", "text-align": "right" }
			]
		},
		payment_history: {
			api: "api/customer/account-status/payment-history",
			rootId: "m_as_history",
			tableId: "as_hist_table",
			tbodyId: "as_hist_tbody",
			searchPlaceholder: "Filter payment history…",
			emptyMessage: "No payment history",
			fromId: "as_hist_from",
			toId: "as_hist_to",
			money: ["receivedAmount", "appliedAmount", "unappliedAmount"],
			columns: [
				{ title: "Payment Reference", field: "paymentRef", sortable: true },
				{ title: "Received Date", field: "receivedDate", sortable: true },
				{ title: "Received Amount (Rs)", field: "receivedAmount", "text-align": "right" },
				{ title: "Applied Amount (Rs)", field: "appliedAmount", "text-align": "right" },
				{ title: "Invoice Number", field: "invoiceNo", sortable: true },
				{ title: "Invoice Date", field: "invoiceDate" },
				{ title: "Unapplied Amount (Rs)", field: "unappliedAmount", "text-align": "right" }
			]
		},
		instrument_return: {
			api: "api/customer/account-status/instrument-return",
			rootId: "m_as_instrument",
			tableId: "as_instrument_table",
			tbodyId: "as_instrument_tbody",
			searchPlaceholder: "Filter instrument returns…",
			emptyMessage: "No instrument returns",
			money: ["amount"],
			columns: [
				{ title: "Payment Reference", field: "paymentRef", sortable: true },
				{ title: "Date", field: "txnDate", sortable: true },
				{ title: "Amount (Rs)", field: "amount", "text-align": "right" },
				{ title: "Status", field: "status", sortable: true },
				{ title: "Reason", field: "reason" }
			]
		},
		statement: {
			api: "api/customer/account-status/statement",
			rootId: "m_as_statement",
			tableId: "as_statement_table",
			tbodyId: "as_statement_tbody",
			searchPlaceholder: "Filter statement…",
			emptyMessage: "No statement rows",
			money: ["opening", "charges", "payments", "closing"],
			columns: [
				{ title: "Period", field: "period", sortable: true },
				{ title: "Opening Balance", field: "opening", "text-align": "right" },
				{ title: "Charges", field: "charges", "text-align": "right" },
				{ title: "Payments", field: "payments", "text-align": "right" },
				{ title: "Closing Balance", field: "closing", "text-align": "right" },
				{ title: "Action", field: "action" }
			]
		}
	},

	_load: function (key, force) {
		var spec = AccountStatus._tabs[key];
		if (!spec) return;
		var $root = $("#" + AccountStatus.ROOT);
		if (!force && $root.data(key + "Loaded")) return;
		if (AccountStatus._busy[key]) return;
		var custCode = String(Common.GetCustCode() || "").trim();
		if (!custCode) {
			Common.showPageMsg(AccountStatus.ROOT, "Customer code is missing.", "warning");
			return;
		}
		if (spec.rootId && !AccountStatus._tableReady[key]) {
			AccountStatus._initTable(key, spec);
			AccountStatus._tableReady[key] = true;
		}
		var context = AccountStatus._procedureContext();
		var data = {
			custCode: context.custCode,
			loginId: context.loginId,
			dummy: window.as400_dummy_data_required === true
		};
		if (spec.fromId) data.fromDate = AccountStatus._apiDate(spec.fromId);
		if (spec.toId) data.toDate = AccountStatus._apiDate(spec.toId);
		AccountStatus._busy[key] = true;
		showLoader("Loading…", AccountStatus.ROOT);
		$.ajax({
			url: ($app_url ? String($app_url) : "") + spec.api,
			method: "GET",
			dataType: "json",
			data: data,
			xhrFields: { withCredentials: true },
			success: function (json) {
				AccountStatus._handle(json, "Unable to load " + key + ".", function (payload) {
					if (key === "summary") AccountStatus._fillSummary(payload);
					else AccountStatus._fillTable(key, spec, payload);
					$root.data(key + "Loaded", true);
				});
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				var msg = "Network error";
				if (xhr && xhr.status) msg += " (HTTP " + xhr.status + ")";
				Common.showPageMsg(AccountStatus.ROOT, msg + ".", "danger");
			},
			complete: function () {
				AccountStatus._busy[key] = false;
				hideLoader(AccountStatus.ROOT);
			}
		});
	},

	_handle: function (json, failMsg, onOk) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		if (!json || (code != null && Number(code) !== 0)) {
			Common.showPageMsg(AccountStatus.ROOT, (json && (json.message || json.status)) || failMsg, "danger");
			return;
		}
		Common.clearPageMsg(AccountStatus.ROOT);
		onOk(json.data != null ? json.data : json);
	},

	_initTable: function (key, spec) {
		Common.DataTable.init({
			rootId: spec.rootId,
			tableId: spec.tableId,
			tbodyId: spec.tbodyId,
			infoId: spec.rootId + "_info",
			pagerId: spec.rootId + "_pager",
			searchId: spec.rootId + "_search",
			pageSizeId: spec.rootId + "_page_size",
			pageSizes: [10, 15, 25, 50],
			pageSize: 15,
			filter_type: "full",
			searchPlaceholder: spec.searchPlaceholder,
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "full",
			maxHeight: "420px",
			emptyMessage: spec.emptyMessage,
			columns: spec.columns,
			rows: []
		});
	},

	_fillTable: function (key, spec, payload) {
		var list = Array.isArray(payload) ? payload : (payload && payload.rows) || [];
		var rows = [];
		for (var i = 0; i < list.length; i++) {
			var src = list[i] || {};
			var row = {};
			for (var f in src) {
				if (!Object.prototype.hasOwnProperty.call(src, f)) continue;
				row[f] = src[f];
			}
			var money = spec.money || [];
			for (var m = 0; m < money.length; m++) {
				if (row[money[m]] != null && row[money[m]] !== "") row[money[m]] = AccountStatus._fmtAmt(row[money[m]]);
			}
			rows.push(row);
		}
		Common.DataTable.setData(spec.rootId, rows);
	},

	_showCustLine: function () {
		var code = String(Common.GetCustCode() || "").trim();
		var name = String(Common.GetCustName() || "").trim();
		$("#as_cust_line").text(name ? (code + " \u2014 " + name) : code);
	},

	_fillSummary: function (d) {
		d = d || {};
		$("#as_as_on").text("Account Status as on " + (d.asOn || ""));
		AccountStatus._showCustLine();
		$("#as_terms").text(d.paymentTerms || "");
		$("#as_status_text").text(d.status || "");
		$("#as_out_total").text(AccountStatus._rupee(d.outstandingTotal));
		$("#as_out_current").text(AccountStatus._rupee(d.outstandingCurrent));
		$("#as_unapp_cash").text(AccountStatus._rupee(d.unappliedCash));
		$("#as_unapp_cn").text(AccountStatus._rupee(d.unappliedCreditNotes));
		$("#as_overdue_total").text(AccountStatus._rupee(d.overdueTotal));
		$("#as_snap_open").text(d.openBalanceLabel || "");
		$("#as_snap_overdue").text(d.overdueLabel || "");
		$("#as_snap_unapplied").text(d.unappliedLabel || "");
		$("#as_snap_terms").text(d.termsShort || "");
		var aging = Array.isArray(d.aging) ? d.aging : [];
		for (var i = 0; i < 4; i++) {
			var a = aging[i] || {};
			$("#as_age_lbl_" + i).text(a.label || "");
			$("#as_age_amt_" + i).text(a.amount == null ? "" : AccountStatus._rupee(a.amount));
			$("#as_age_bar_" + i).css({ width: (a.pct || 0) + "%", background: a.color || "#0b5fff" });
		}
	}
};

window.AccountStatus = AccountStatus;
