/**
 * My Orders module (CUST_SERVICE).
 * Depends: js/inpc_loader.js, custom_js/common.js (Common.GetCustCode / GetLoginId / DataTable),
 * then this file via menu js_path. my_orders.html calls MyOrders.LoadMyOrders() on page load.
 * Uses global $app_url from fw-globals.js — never redefine host here.
 */
MyOrders = {
	LOADER_TARGET: "m_my_orders",
	API_OPEN: "api/customer/my-orders/open",
	API_INVOICED: "api/customer/my-orders/invoiced",
	_openInited: false,
	_invInited: false,
	_openInFlight: false,
	_invInFlight: false,

	LoadMyOrders: function () {
		var custCode = String(Common.GetCustCode() || "").trim();

		if (!custCode) {
			Common.showPageMsg(MyOrders.LOADER_TARGET, "Customer code is missing. Please re-login or select a customer.", "warning");
			return;
		}
		MyOrders._bindUiOnce();
		/* Same page already has open-order rows. Tab switches must not call the server again. */
		if ($("#m_my_orders").data("openLoaded")) return;
		if (MyOrders._openInFlight) return;

		MyOrders._ensureOpenTable();
		MyOrders._ensureInvTable();
		MyOrders._ensureDatePickers();
		MyOrders._setDefaultInvDates();
		MyOrders._openInFlight = true;
		var context = MyOrders._procedureContext();
		MyOrders._loadOpen(context.custCode, context.loginId);
	},

	_procedureContext: function () {
		if (Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	},

	/** Framework date format: dd/mm/yyyy (slashes). Re-bind after HTML load. */
	_ensureDatePickers: function () {
		var $root = $("#m_my_orders");
		if (!$root.length || !window.jQuery || !$.fn.datepicker) return;
		$root.find("#mo_from_date, #mo_to_date").each(function () {
			var $el = $(this);
			$el.attr("data-date-format", "dd/mm/yyyy");
			$el.attr("placeholder", "dd/mm/yyyy");
			try {
				if ($el.data("datepicker")) $el.datepicker("destroy");
			} catch (eD) { /* ignore */ }
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				format: "dd/mm/yyyy",
				orientation: "bottom auto",
				defaultViewDate: new Date()
			});
		});
	},

	_pad2: function (n) {
		n = Number(n);
		return (n < 10 ? "0" : "") + n;
	},

	/** dd/mm/yyyy */
	_fmtDmy: function (d) {
		return MyOrders._pad2(d.getDate()) + "/" + MyOrders._pad2(d.getMonth() + 1) + "/" + d.getFullYear();
	},

	/** Legacy default: from = 1st of previous month, to = today. Fills only empty fields. */
	_setDefaultInvDates: function () {
		var $from = $("#mo_from_date");
		var $to = $("#mo_to_date");
		if (!$from.length || !$to.length) return;
		var today = new Date();
		var start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
		function apply($el, text) {
			if (String($el.val() || "").trim()) return;
			$el.val(text);
			try { $el.datepicker("update", text); } catch (eU) { /* ignore */ }
		}
		apply($from, MyOrders._fmtDmy(start));
		apply($to, MyOrders._fmtDmy(today));
	},

	_bindUiOnce: function () {
		if (window.__inpcMyOrdersUiBound) return;
		window.__inpcMyOrdersUiBound = true;

		$(document).on("click", "#mo_get_orders_btn", function () {
			MyOrders._loadInvoiced(true);
		});
		$(document).on("click", "#mo_open_refresh_btn", function (e) {
			e.preventDefault();
			MyOrders._refreshOpen();
		});
		$(document).on("click", "#mo_inv_refresh_btn", function (e) {
			e.preventDefault();
			MyOrders._loadInvoiced(true);
		});

		$(document).on("shown.bs.tab", "#mo_tab_inv_btn", function () {
			MyOrders._setDefaultInvDates();
			/* First visit only. Returning from Open Orders does not call the server. */
			if (!$("#m_my_orders").data("invLoaded")) {
				MyOrders._loadInvoiced(false);
			}
		});

		$(document).on("click", "#mo_open_filter_btn", function (e) {
			e.preventDefault();
			e.stopImmediatePropagation();
			$("#m_my_orders_open > .dt-toolbar").toggleClass("d-none");
		});
		$(document).on("click", "#mo_inv_filter_btn", function (e) {
			e.preventDefault();
			e.stopImmediatePropagation();
			$("#m_my_orders_inv > .dt-toolbar").toggleClass("d-none");
		});
	},

	_ensureOpenTable: function () {
		MyOrders._openInited = true;
		Common.DataTable.init({
			rootId: "m_my_orders_open",
			tableId: "mo_open_table",
			tbodyId: "mo_open_tbody",
			infoId: "mo_open_info",
			pagerId: "mo_open_pager",
			searchId: "mo_open_search",
			pageSizeId: "mo_open_page_size",
			pageSizes: [10, 15, 25, 50],
			pageSize: 15,
			searchPlaceholder: "Filter open orders…",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "row",
			maxHeight: "420px",
			emptyMessage: "No open orders",
			columns: [
				{ title: "PO #", field: "poNo", sortable: true, width: 120 },
				{ title: "PODate", field: "poDate", sortable: true, width: 105 },
				{ title: "Stock #", field: "stockNo", sortable: true, width: 110 },
				{ title: "Description", field: "description", width: 240 },
				{ title: "Status", field: "status", sortable: true, width: 100 },
				{ title: "Order Qty", field: "orderQty", sortable: true, "text-align": "right", width: 100 },
				{ title: "Allocated Qty", field: "allocatedQty", "text-align": "right", width: 110 },
				{ title: "Shipped Qty", field: "shippedQty", "text-align": "right", width: 100 },
				{ title: "Open Qty", field: "openQty", sortable: true, "text-align": "right", width: 90 },
				{ title: "Unit Price(Rs)", field: "unitPrice", "text-align": "right", width: 110 },
				{ title: "Amount(Rs)", field: "amount", "text-align": "right", width: 120 },
				{ title: "3M Order #", field: "orderNo3m", sortable: true, width: 120 },
				{ title: "Expected Ship Date", field: "expectedShipDate", width: 145 }
			],
			rows: []
		});
	},

	_ensureInvTable: function () {
		MyOrders._invInited = true;
		Common.DataTable.init({
			rootId: "m_my_orders_inv",
			tableId: "mo_inv_table",
			tbodyId: "mo_inv_tbody",
			infoId: "mo_inv_info",
			pagerId: "mo_inv_pager",
			searchId: "mo_inv_search",
			pageSizeId: "mo_inv_page_size",
			pageSizes: [10, 15, 25, 50],
			pageSize: 15,
			searchPlaceholder: "Filter invoice rows…",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "row",
			maxHeight: "420px",
			emptyMessage: "No invoice / shipped rows — click GetOrders",
			columns: [
				{ title: "PO #", field: "poNo", sortable: true },
				{ title: "PODate", field: "poDate", sortable: true },
				{ title: "Stock #", field: "stockNo", sortable: true },
				{ title: "Description", field: "description" },
				{ title: "Order Qty", field: "orderQty", "text-align": "right" },
				{ title: "Shipped Qty", field: "shippedQty", "text-align": "right" },
				{ title: "Unit Price(Rs)", field: "unitPrice", "text-align": "right" },
				{ title: "Amount(Rs)", field: "amount", "text-align": "right" },
				{ title: "3M Order #", field: "orderNo3m", sortable: true },
				{ title: "Invoice #", field: "invoiceNo", sortable: true },
				{ title: "Invoice Date", field: "invoiceDate" },
				{ title: "Carrier", field: "carrier" },
				{ title: "LR #", field: "lrNo" },
				{ title: "LR Date", field: "lrDate" },
				{ title: "Exp Del Date", field: "expectedDeliveryDate" },
				{ title: "Actual Del Date", field: "actualDeliveryDate" }
			],
			rows: []
		});
	},

	_fmtAmt: function (n) {
		var num = Number(n);
		if (isNaN(num)) return String(n == null ? "" : n);
		try {
			return num.toLocaleString("en-IN", { minimumFractionDigits: 1, maximumFractionDigits: 2 });
		} catch (e) {
			return String(num);
		}
	},

	_pick: function (obj, keys) {
		if (!obj || typeof obj !== "object") return undefined;
		for (var i = 0; i < keys.length; i++) {
			if (obj[keys[i]] != null && obj[keys[i]] !== "") return obj[keys[i]];
		}
		return undefined;
	},

	_zero: function (v) {
		if (v == null || String(v).trim() === "") return 0;
		return v;
	},

	_normalizeOpen: function (r) {
		r = r || {};
		var unit = MyOrders._pick(r, ["unitPrice", "unit_price"]);
		var amt = MyOrders._pick(r, ["amount", "amt"]);
		return {
			poNo: MyOrders._pick(r, ["poNo", "po_no", "po"]) || "",
			poDate: MyOrders._pick(r, ["poDate", "po_date"]) || "",
			stockNo: MyOrders._pick(r, ["stockNo", "stock_no", "stock"]) || "",
			description: MyOrders._pick(r, ["description", "desc"]) || "",
			status: MyOrders._pick(r, ["status"]) || "",
			orderQty: MyOrders._zero(MyOrders._pick(r, ["orderQty", "order_qty"])),
			allocatedQty: MyOrders._zero(MyOrders._pick(r, ["allocatedQty", "allocated_qty"])),
			shippedQty: MyOrders._zero(MyOrders._pick(r, ["shippedQty", "shipped_qty"])),
			openQty: MyOrders._zero(MyOrders._pick(r, ["openQty", "open_qty"])),
			unitPrice: MyOrders._fmtAmt(MyOrders._zero(unit)),
			amount: MyOrders._fmtAmt(MyOrders._zero(amt)),
			orderNo3m: MyOrders._pick(r, ["orderNo3m", "order_no_3m", "mmmOrderNo"]) || "",
			expectedShipDate: MyOrders._pick(r, ["expectedShipDate", "expected_ship_date"]) || ""
		};
	},

	_normalizeInv: function (r) {
		r = r || {};
		var unit = MyOrders._pick(r, ["unitPrice", "unit_price"]);
		var amt = MyOrders._pick(r, ["amount", "amt"]);
		return {
			poNo: MyOrders._pick(r, ["poNo", "po_no", "po"]) || "",
			poDate: MyOrders._pick(r, ["poDate", "po_date"]) || "",
			stockNo: MyOrders._pick(r, ["stockNo", "stock_no", "stock"]) || "",
			description: MyOrders._pick(r, ["description", "desc"]) || "",
			orderQty: MyOrders._zero(MyOrders._pick(r, ["orderQty", "order_qty"])),
			shippedQty: MyOrders._zero(MyOrders._pick(r, ["shippedQty", "shipped_qty"])),
			unitPrice: MyOrders._fmtAmt(MyOrders._zero(unit)),
			amount: MyOrders._fmtAmt(MyOrders._zero(amt)),
			orderNo3m: MyOrders._pick(r, ["orderNo3m", "order_no_3m", "mmmOrderNo"]) || "",
			invoiceNo: MyOrders._pick(r, ["invoiceNo", "invoice_no", "invNo"]) || "",
			invoiceDate: MyOrders._pick(r, ["invoiceDate", "invoice_date"]) || "",
			carrier: MyOrders._pick(r, ["carrier", "transporter"]) || "",
			lrNo: MyOrders._pick(r, ["lrNo", "lr_no", "lr"]) || "",
			lrDate: MyOrders._pick(r, ["lrDate", "lr_date"]) || "",
			expectedDeliveryDate: MyOrders._pick(r, [
				"expectedDeliveryDate", "expected_delivery_date", "expectedShipDate"
			]) || "",
			actualDeliveryDate: MyOrders._pick(r, [
				"actualDeliveryDate", "actual_delivery_date"
			]) || ""
		};
	},

	_handleAjaxJson: function (json, failMsg, onOk) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		if (!json || (code != null && Number(code) !== 0)) {
			var bizMsg = (json && (json.message || json.status)) || failMsg;
			Common.showPageMsg(MyOrders.LOADER_TARGET, bizMsg, "danger");
			return;
		}
		Common.clearPageMsg(MyOrders.LOADER_TARGET);
		onOk(json.data != null ? json.data : json);
	},

	_refreshOpen: function () {
		if (!String(Common.GetCustCode() || "").trim()) {
			Common.showPageMsg(MyOrders.LOADER_TARGET, "Customer code is missing. Please re-login or select a customer.", "warning");
			return;
		}
		if (MyOrders._openInFlight) return;
		MyOrders._openInFlight = true;
		var context = MyOrders._procedureContext();
		MyOrders._loadOpen(context.custCode, context.loginId);
	},

	_loadOpen: function (custCode, loginId) {
		var base = $app_url ? String($app_url) : "";
		showLoader("Loading open orders…", MyOrders.LOADER_TARGET);
		$.ajax({
			url: base + MyOrders.API_OPEN,
			method: "GET",
			dataType: "json",
			data: {
				custCode: custCode,
				loginId: loginId,
				dummy: window.as400_dummy_data_required === true
			},
			xhrFields: { withCredentials: true },
			success: function (json) {
				MyOrders._handleAjaxJson(json, "Unable to load open orders.", function (data) {
					var list = Array.isArray(data) ? data : (data && data.rows) || [];
					var rows = [];
					for (var i = 0; i < list.length; i++) rows.push(MyOrders._normalizeOpen(list[i]));
					MyOrders._ensureOpenTable();
					Common.DataTable.setData("m_my_orders_open", rows);
					$("#m_my_orders").data("openLoaded", true);
				});
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				var httpMsg = "Network error loading open orders";
				if (xhr && xhr.status) httpMsg += " (HTTP " + xhr.status + ")";
				Common.showPageMsg(MyOrders.LOADER_TARGET, httpMsg + ".", "danger");
			},
			complete: function () {
				MyOrders._openInFlight = false;
				hideLoader(MyOrders.LOADER_TARGET);
			}
		});
	},

	_loadInvoiced: function (fromButton) {
		if (!String(Common.GetCustCode() || "").trim()) {
			Common.showPageMsg(MyOrders.LOADER_TARGET, "Customer code is missing.", "warning");
			return;
		}
		var context = MyOrders._procedureContext();
		if (MyOrders._invInFlight) return;
		MyOrders._invInFlight = true;
		var fromDateUi = String($("#mo_from_date").val() || "").trim();
		var toDateUi = String($("#mo_to_date").val() || "").trim();
		var stock = String($("#mo_stock").val() || "").trim();
		/* UI is dd/mm/yyyy — API expects yyyy-mm-dd via Framework date_format() */
		var fromDate = "";
		var toDate = "";
		if (fromDateUi && fromDateUi !== "00/00/0000" && fromDateUi !== "00-00-0000") {
			fromDate = (typeof date_format === "function") ? date_format(fromDateUi) : fromDateUi;
			if (fromDate === "0000-00-00") fromDate = "";
		}
		if (toDateUi && toDateUi !== "00/00/0000" && toDateUi !== "00-00-0000") {
			toDate = (typeof date_format === "function") ? date_format(toDateUi) : toDateUi;
			if (toDate === "0000-00-00") toDate = "";
		}

		var base = $app_url ? String($app_url) : "";
		showLoader(fromButton ? "Getting orders…" : "Loading invoice & shipped…", MyOrders.LOADER_TARGET);
		$.ajax({
			url: base + MyOrders.API_INVOICED,
			method: "GET",
			dataType: "json",
			data: {
				custCode: context.custCode,
				loginId: context.loginId,
				fromDate: fromDate,
				toDate: toDate,
				stock: stock,
				dummy: window.as400_dummy_data_required === true
			},
			xhrFields: { withCredentials: true },
			success: function (json) {
				MyOrders._handleAjaxJson(json, "Unable to load invoice / shipped orders.", function (data) {
					var list = Array.isArray(data) ? data : (data && data.rows) || [];
					var rows = [];
					for (var i = 0; i < list.length; i++) rows.push(MyOrders._normalizeInv(list[i]));
					MyOrders._ensureInvTable();
					Common.DataTable.setData("m_my_orders_inv", rows);
					$("#m_my_orders").data("invLoaded", true);
				});
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				var httpMsg = "Network error loading invoice orders";
				if (xhr && xhr.status) httpMsg += " (HTTP " + xhr.status + ")";
				Common.showPageMsg(MyOrders.LOADER_TARGET, httpMsg + ".", "danger");
			},
			complete: function () {
				MyOrders._invInFlight = false;
				hideLoader(MyOrders.LOADER_TARGET);
			}
		});
	}
};

window.MyOrders = MyOrders;
window.LoadMyOrders = function () {
	MyOrders.LoadMyOrders();
};