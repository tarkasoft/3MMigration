/**
 * Customer Payment Summary module.
 * Depends (MainPage script order): js/inpc_loader.js, custom_js/common.js (Common.GetCustCode / Common.GetLoginId),
 * then this file via menu js_path before customer_payment.html calls LoadCustomerPayment().
 * Uses global $app_url from fw-globals.js â€” never redefine host here.
 */
CustomerPayment =
{
	LOADER_TARGET: "m_customer_payment",
	API_SUMMARY: "api/customer/customer-payment/summary",
	_requestInFlight: false,

	/**
	 * Page entry: called once HTML is in #home_dashboard.
	 * MainPage loads this file via JS Path before HTML.
	 */
	LoadCustomerPayment: function () {
		if (CustomerPayment._requestInFlight) {
			return;
		}
		var custCode = String(Common.GetCustCode() || "").trim();

		if (!custCode) {
			Common.showPageMsg(CustomerPayment.LOADER_TARGET || 'm_customer_payment', "Customer code is missing. Please re-login or select a customer.", "warning");
			return;
		}
		CustomerPayment._requestInFlight = true;
		$("#cp_refresh").prop("disabled", true);
		var context = (Common.GetProcedureCustomerContext
			? Common.GetProcedureCustomerContext()
			: null) || {};

		var base = $app_url ? String($app_url) : "";
		var url = base + CustomerPayment.API_SUMMARY;

		showLoader("Loading payment summary¦", CustomerPayment.LOADER_TARGET);

		$.ajax({
			url: url,
			method: "GET",
			dataType: "json",
			data: {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim(),
				dummy: window.as400_dummy_data_required === true
			},
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (window.inpcIsSessionExpiredPayload(json)) {
					window.inpcHandleSessionExpired(json && (json.message || json.data));
					return;
				}
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (code === -9 || code === "-9") {
					window.inpcHandleSessionExpired(json && (json.message || json.data));
					return;
				}
				if (!json || (code != null && Number(code) !== 0)) {
					var bizMsg =
						(json && (json.message || json.status)) ||
						"Unable to load payment summary.";
					Common.showPageMsg(CustomerPayment.LOADER_TARGET || 'm_customer_payment', bizMsg, "danger");
					return;
				}
				Common.clearPageMsg(CustomerPayment.LOADER_TARGET || 'm_customer_payment');
				CustomerPayment._applySummary(json.data != null ? json.data : json);
			},
			error: function (xhr, status) {
				if (status === "abort") {
					return;
				}
				var httpMsg = "Network error loading payment summary";
				if (xhr && xhr.status) {
					httpMsg += " (HTTP " + xhr.status + ")";
				}
				Common.showPageMsg(CustomerPayment.LOADER_TARGET || 'm_customer_payment', httpMsg + ".", "danger");
			},
			complete: function () {
				CustomerPayment._requestInFlight = false;
				$("#cp_refresh").prop("disabled", false);
				hideLoader(CustomerPayment.LOADER_TARGET);
			}
		});
	},

	Refresh: function () {
		if (CustomerPayment._requestInFlight) {
			return;
		}
		CustomerPayment.LoadCustomerPayment();
	},

	_fmtInr: function (n) {
		var num = Number(n);
		if (isNaN(num)) {
			return String(n == null ? "" : n);
		}
		try {
			return "₹" + num.toLocaleString("en-IN", {
				minimumFractionDigits: 2,
				maximumFractionDigits: 2
			});
		} catch (eFmt) {
			return "₹" + num.toFixed(2);
		}
	},

	_pick: function (obj, keys) {
		if (!obj || typeof obj !== "object") {
			return undefined;
		}
		for (var i = 0; i < keys.length; i++) {
			if (obj[keys[i]] != null && obj[keys[i]] !== "") {
				return obj[keys[i]];
			}
		}
		return undefined;
	},

	_paymentsList: function (section) {
		if (!section) {
			return [];
		}
		if (Array.isArray(section)) {
			return section;
		}
		var list = CustomerPayment._pick(section, [
			"payments",
			"items",
			"cycles",
			"rows",
			"dates"
		]);
		return Array.isArray(list) ? list : [];
	},

	_renderCycleSection: function ($section, sectionData) {
		if (!$section || !$section.length || sectionData == null) {
			return;
		}
		var label = CustomerPayment._pick(sectionData, [
			"label",
			"monthLabel",
			"month_label",
			"title",
			"period"
		]);
		if (label != null) {
			$section.find(".cp-section-h .meta").first().text(String(label));
		}
		var payments = CustomerPayment._paymentsList(sectionData);
		var $grid = $section.find(".cp-grid").first();
		if ($grid.length) {
			var html = "";
			for (var i = 0; i < payments.length; i++) {
				var p = payments[i] || {};
				var date =
					CustomerPayment._pick(p, [
						"date",
						"paymentDate",
						"payment_date",
						"dueDate",
						"due_date"
					]) || "";
				var amt = CustomerPayment._pick(p, [
					"amount",
					"amt",
					"value",
					"paymentAmount",
					"payment_amount"
				]);
				html +=
					'<div class="cp-item">' +
					'<div class="date"><span class="dot"><i class="ri-calendar-event-line"></i></span> ' +
					$("<div/>").text(String(date)).html() +
					"</div>" +
					'<div class="amt">' +
					$("<div/>").text(amt != null ? CustomerPayment._fmtInr(amt) : "â€”").html() +
					"</div></div>";
			}
			$grid.html(html || '<div class="cp-empty">No payment dates available.</div>');
		}
		var holdAmount = CustomerPayment._pick(sectionData, [
			"holdAmount",
			"hold_amount",
			"onHold",
			"on_hold"
		]);
		var $hold = $section.find(".cp-hold").first();
		if ($hold.length) {
			if (holdAmount != null) {
				$hold.text("On-hold: " + CustomerPayment._fmtInr(holdAmount)).removeClass("d-none");
			} else {
				$hold.addClass("d-none").text("");
			}
		}
		var total = CustomerPayment._pick(sectionData, [
			"total",
			"monthTotal",
			"month_total",
			"sum"
		]);
		var $totals = $section.find(".cp-totals .cp-total");
		if ($totals.length) {
			$totals.eq(0).find(".v").text(CustomerPayment._fmtInr(total != null ? total : 0));
		}
		if ($totals.length > 1) {
			$totals
				.eq(1)
				.find(".v")
				.text(payments.length + " cycle" + (payments.length === 1 ? "" : "s"));
		}
	},

	/**
	 * Flexible apply: only updates DOM nodes that exist under #m_customer_payment.
	 * Expected (optional) data keys: companyLevel/company_level/companyCode,
	 * asOf/as_on/asOfDate, currentMonth/current_month, nextMonth/next_month,
	 * currency/chip.
	 */
	_applySummary: function (data) {
		var rootId = CustomerPayment.LOADER_TARGET || "m_customer_payment";
		var $root = $("#" + rootId);
		if (!$root.length || data == null) {
			return;
		}
		if (typeof data !== "object") {
			return;
		}

		var company = CustomerPayment._pick(data, [
			"companyLevel",
			"company_level",
			"companyCode",
			"company_code",
			"company",
			"level"
		]);
		if (company != null) {
			var custCode = CustomerPayment._pick(data, ["custCode", "cust_code"]);
			var companyLabel = String(company);
			if (custCode != null && String(custCode).trim() !== "") {
				var codeLabel = String(custCode).trim();
				if (companyLabel !== codeLabel && companyLabel.indexOf(codeLabel + " - ") !== 0) {
					companyLabel = codeLabel + " - " + companyLabel;
				}
			}
			$root.find(".cp-company .val").first().text(companyLabel);
		}

		var asOf = CustomerPayment._pick(data, [
			"asOf",
			"as_on",
			"asOfDate",
			"as_of",
			"asOn"
		]);
		if (asOf != null) {
			var $asof = $root.find(".cp-asof").first();
			if ($asof.length) {
				$asof.html(
					'<i class="ri-calendar-check-line" aria-hidden="true"></i> As on ' +
						$("<div/>").text(String(asOf)).html()
				);
			}
		}

		var currency = CustomerPayment._pick(data, ["currency", "curr", "chip"]);
		if (currency != null) {
			$root.find(".cp-main-h .chip").first().text(String(currency));
		}

		var $sections = $root.find(".cp-section");
		var current = CustomerPayment._pick(data, [
			"currentMonth",
			"current_month",
			"current",
			"currentCycle"
		]);
		var next = CustomerPayment._pick(data, [
			"nextMonth",
			"next_month",
			"next",
			"nextDue",
			"next_due"
		]);
		if ($sections.length) {
			CustomerPayment._renderCycleSection($sections.eq(0), current);
		}
		if ($sections.length > 1) {
			CustomerPayment._renderCycleSection($sections.eq(1), next);
		}
	}
};
