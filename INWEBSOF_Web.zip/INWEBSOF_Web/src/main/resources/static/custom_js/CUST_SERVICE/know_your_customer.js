/**
 * Know Your Customer.
 * Menu js_path loads this file. know_your_customer.html calls KnowYourCustomer.Load().
 */
KnowYourCustomer = {
	ROOT: "m_know_your_customer",
	API: "api/customer/know-your-customer",
	_busy: false,

	_customerContext: function () {
		var context = (Common.GetProcedureCustomerContext
			? Common.GetProcedureCustomerContext()
			: null) || {};
		return {
			custCode: String(context.custCode || "").trim(),
			loginId: String(context.loginId || "").trim()
		};
	},

	Load: function () {
		var context = KnowYourCustomer._customerContext();
		var custCode = context.custCode || String(Common.GetCustCode() || "").trim();
		if (!custCode) {
			Common.showPageMsg(KnowYourCustomer.ROOT, "Customer code is missing. Please re-login or select a customer.", "warning");
			return;
		}
		KnowYourCustomer._bindOnce();
		KnowYourCustomer._load();
	},

	_bindOnce: function () {
		if (window.__inpcKycBound) return;
		window.__inpcKycBound = true;
		$(document).on("click", "#kyc_new_btn", function (e) {
			e.preventDefault();
			if (KnowYourCustomer._openRow()) return;
			KnowYourCustomer._addRow({}, true);
		});
		$(document).on("click", "#kyc_rows .kyc-row-edit", function (e) {
			e.preventDefault();
			if (KnowYourCustomer._openRow()) return;
			$(this).closest("tr").addClass("is-edit");
			$(this).closest("tr").find("input").first().trigger("focus");
		});
		$(document).on("click", "#kyc_rows .kyc-row-save", function (e) {
			e.preventDefault();
			KnowYourCustomer._saveRow($(this).closest("tr"));
		});
		$(document).on("click", "#kyc_rows .kyc-row-delete", function (e) {
			e.preventDefault();
			KnowYourCustomer._removeNewRow($(this).closest("tr"));
		});
		$(document).on("click", "#kyc_update_btn", function (e) {
			e.preventDefault();
			KnowYourCustomer._save();
		});
		$(document).on("input", "#kyc_proprietor", function () {
			var name = String($(this).val() || "").trim();
			$("#kyc_hero_name").text(name || "Customer");
		});
		$(document).on("input", "#kyc_gst, #kyc_pan, #kyc_rows input[data-field='gstNo'], #kyc_rows input[data-field='panNo']", function () {
			var el = this;
			var start = el.selectionStart;
			var upper = String(el.value || "").toUpperCase();
			if (el.value !== upper) {
				el.value = upper;
				if (start != null) el.setSelectionRange(start, start);
			}
			KnowYourCustomer._clearOne(el);
		});
		$(document).on("input", "#kyc_primary_contact, #kyc_alternate_contact, #kyc_rows input[data-field='phoneNo']", function () {
			KnowYourCustomer._clearOne(this);
		});
	},

	_load: function () {
		if (KnowYourCustomer._busy) return;
		var context = KnowYourCustomer._customerContext();
		KnowYourCustomer._busy = true;
		showLoader("Loading customer...", KnowYourCustomer.ROOT);
		$.ajax({
			url: ($app_url ? String($app_url) : "") + KnowYourCustomer.API,
			method: "GET",
			dataType: "json",
			data: {
				custCode: context.custCode,
				loginId: context.loginId,
				dummy: window.as400_dummy_data_required === true
			},
			xhrFields: { withCredentials: true },
			success: function (json) {
				KnowYourCustomer._handle(json, "Unable to load customer.", function (data) {
					KnowYourCustomer._fill(data || {});
				});
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				var msg = "Network error";
				if (xhr && xhr.status) msg += " (HTTP " + xhr.status + ")";
				Common.showPageMsg(KnowYourCustomer.ROOT, msg + ".", "danger");
			},
			complete: function () {
				KnowYourCustomer._busy = false;
				hideLoader(KnowYourCustomer.ROOT);
			}
		});
	},

	_save: function () {
		if (KnowYourCustomer._busy) return;
		var context = KnowYourCustomer._customerContext();
		var custCode = context.custCode || String(Common.GetCustCode() || "").trim();
		if (!custCode) {
			Common.showPageMsg(KnowYourCustomer.ROOT, "Customer code is missing.", "warning");
			return;
		}
		if (KnowYourCustomer._openRow()) return;
		if (!KnowYourCustomer._validate()) return;
		KnowYourCustomer._busy = true;
		showLoader("Updating customer...", KnowYourCustomer.ROOT);
		$.ajax({
			url: ($app_url ? String($app_url) : "") + KnowYourCustomer.API,
			method: "POST",
			contentType: "application/json; charset=UTF-8",
			dataType: "json",
			data: JSON.stringify(KnowYourCustomer._collect(context)),
			xhrFields: { withCredentials: true },
			success: function (json) {
				KnowYourCustomer._handle(json, "Unable to update customer.", function (data) {
					KnowYourCustomer._fill(data || {});
					var message = window.as400_dummy_data_required === true
						? "Sample KYC data updated in memory."
						: "Customer updated.";
					Common.showPageMsg(KnowYourCustomer.ROOT, message, "success");
				});
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				var msg = "Network error";
				if (xhr && xhr.status) msg += " (HTTP " + xhr.status + ")";
				Common.showPageMsg(KnowYourCustomer.ROOT, msg + ".", "danger");
			},
			complete: function () {
				KnowYourCustomer._busy = false;
				hideLoader(KnowYourCustomer.ROOT);
			}
		});
	},

	_handle: function (json, failMsg, onOk) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		if (!json || (code != null && Number(code) !== 0)) {
			Common.showPageMsg(KnowYourCustomer.ROOT, (json && (json.message || json.status)) || failMsg, "danger");
			return;
		}
		Common.clearPageMsg(KnowYourCustomer.ROOT);
		onOk(json.data != null ? json.data : json);
	},

	_set: function (id, value) {
		$("#" + id).val(value == null ? "" : value);
	},

	_fill: function (data) {
		var code = String(data.custCode || Common.GetCustCode() || "").trim();
		var name = String(data.proprietorName || "").trim();
		$("#kyc_hero_code").text(code);
		$("#kyc_hero_name").text(name || "Customer");
		KnowYourCustomer._set("kyc_proprietor", data.proprietorName);
		KnowYourCustomer._set("kyc_cust_code", code);
		KnowYourCustomer._set("kyc_business_address", data.businessAddress);
		KnowYourCustomer._set("kyc_billing_address", data.billingAddress);
		KnowYourCustomer._set("kyc_gst", data.gstNo);
		KnowYourCustomer._set("kyc_pan", data.panNo);
		KnowYourCustomer._set("kyc_primary_contact", data.primaryContact);
		KnowYourCustomer._set("kyc_alternate_contact", data.alternateContact);
		KnowYourCustomer._set("kyc_email_accounting", data.emailAccounting);
		KnowYourCustomer._set("kyc_email_transaction", data.emailTransaction);
		KnowYourCustomer._set("kyc_remarks", data.remarks);
		KnowYourCustomer._set("kyc_drug_license", data.drugLicenseNo);
		$("#kyc_rows").empty();
		var rows = Array.isArray(data.rows) ? data.rows : [];
		if (!rows.length) KnowYourCustomer._addRow({});
		for (var i = 0; i < rows.length; i++) KnowYourCustomer._addRow(rows[i] || {});
		$("#kyc_row_count").text($("#kyc_rows tr").length + " locations");
		var status = String(data.status || "New").trim();
		var approved = status.toLowerCase() === "approved";
		$("#kyc_status")
			.text(status)
			.toggleClass("is-saved", status.toLowerCase() === "saved")
			.toggleClass("is-approved", approved)
			.toggle(status.length > 0);
		$("#kyc_update_btn").toggle(!approved);
		var approvalRemarks = String(data.approvalRemarks || "").trim();
		$("#kyc_approved_remarks")
			.text(approvalRemarks ? "Approver remarks: " + approvalRemarks : "")
			.toggle(approvalRemarks.length > 0);
	},

	_gstOk: function (value) {
		return /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(value);
	},

	_panOk: function (value) {
		return /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(value);
	},

	_phoneDigits: function (value) {
		var digits = String(value || "").replace(/[\s\-()]/g, "");
		if (digits.indexOf("+91") === 0) digits = digits.substring(3);
		else if (digits.indexOf("91") === 0 && digits.length === 12) digits = digits.substring(2);
		else if (digits.indexOf("0") === 0 && digits.length === 11) digits = digits.substring(1);
		return digits;
	},

	_phoneOk: function (value) {
		return /^[6-9][0-9]{9}$/.test(KnowYourCustomer._phoneDigits(value));
	},

	_clearOne: function (el) {
		$(el).removeClass("is-invalid");
		var id = el.id;
		if (id) $("#" + id + "_err").text("");
	},

	_mark: function (el, message) {
		$(el).addClass("is-invalid");
		var id = el && el.id;
		if (id) $("#" + id + "_err").text(message);
		return message;
	},

	_validate: function () {
		$("#m_know_your_customer .is-invalid").removeClass("is-invalid");
		$("#m_know_your_customer .kyc-err").text("");
		var problems = [];
		var gst = String($("#kyc_gst").val() || "").trim().toUpperCase();
		var pan = String($("#kyc_pan").val() || "").trim().toUpperCase();
		var primary = String($("#kyc_primary_contact").val() || "").trim();
		var alternate = String($("#kyc_alternate_contact").val() || "").trim();
		$("#kyc_gst").val(gst);
		$("#kyc_pan").val(pan);
		if (!gst) problems.push(KnowYourCustomer._mark(document.getElementById("kyc_gst"), "GST No is required."));
		else if (!KnowYourCustomer._gstOk(gst)) problems.push(KnowYourCustomer._mark(document.getElementById("kyc_gst"), "Enter a 15-character GST number."));
		if (!pan) problems.push(KnowYourCustomer._mark(document.getElementById("kyc_pan"), "PAN No is required."));
		else if (!KnowYourCustomer._panOk(pan)) problems.push(KnowYourCustomer._mark(document.getElementById("kyc_pan"), "Enter a 10-character PAN."));
		if (KnowYourCustomer._gstOk(gst) && KnowYourCustomer._panOk(pan) && gst.substring(2, 12) !== pan) {
			problems.push(KnowYourCustomer._mark(document.getElementById("kyc_gst"), "GST number does not match the PAN."));
		}
		if (!primary) problems.push(KnowYourCustomer._mark(document.getElementById("kyc_primary_contact"), "Primary contact number is required."));
		else if (!KnowYourCustomer._phoneOk(primary)) problems.push(KnowYourCustomer._mark(document.getElementById("kyc_primary_contact"), "Enter a 10-digit mobile number."));
		if (alternate && !KnowYourCustomer._phoneOk(alternate)) problems.push(KnowYourCustomer._mark(document.getElementById("kyc_alternate_contact"), "Enter a 10-digit mobile number, or leave it blank."));
		$("#kyc_rows tr").each(function (index) {
			var rowProblems = KnowYourCustomer._rowProblems($(this), index + 1);
			for (var p = 0; p < rowProblems.length; p++) problems.push(rowProblems[p]);
		});
		if (!problems.length) return true;
		Common.showPageMsg(KnowYourCustomer.ROOT, problems[0], "warning");
		var first = $("#m_know_your_customer .is-invalid").get(0);
		if (first && first.scrollIntoView) first.scrollIntoView({ block: "center", behavior: "smooth" });
		return false;
	},

	_openRow: function () {
		var open = $("#kyc_rows tr.is-edit");
		if (!open.length) return false;
		Common.showPageMsg(KnowYourCustomer.ROOT, "Save the open ship-to row first.", "warning");
		var input = open.find("input").get(0);
		if (input && input.scrollIntoView) input.scrollIntoView({ block: "center", behavior: "smooth" });
		return true;
	},

	_rowProblems: function (tr, rowNo) {
		var problems = [];
		var hasDetails = false;
		tr.find("input").each(function () {
			if (String($(this).val() || "").trim()) hasDetails = true;
		});
		var shipCode = tr.find("input[data-field='shipToCode']").get(0);
		if (hasDetails && !String($(shipCode).val() || "").trim()) {
			problems.push(KnowYourCustomer._mark(shipCode, "Ship-to row " + rowNo + ": ship-to code is required."));
		}
		tr.find("input").each(function () {
			var field = $(this).attr("data-field");
			var value = String($(this).val() || "").trim();
			if (field === "gstNo" || field === "panNo") {
				value = value.toUpperCase();
				$(this).val(value);
			}
			if (!value) return;
			if (field === "gstNo" && !KnowYourCustomer._gstOk(value)) {
				problems.push(KnowYourCustomer._mark(this, "Ship-to row " + rowNo + ": enter a 15-character GST number."));
			} else if (field === "panNo" && !KnowYourCustomer._panOk(value)) {
				problems.push(KnowYourCustomer._mark(this, "Ship-to row " + rowNo + ": enter a 10-character PAN."));
			} else if (field === "phoneNo" && !KnowYourCustomer._phoneOk(value)) {
				problems.push(KnowYourCustomer._mark(this, "Ship-to row " + rowNo + ": enter a 10-digit mobile number."));
			}
		});
		var rowGst = String(tr.find("input[data-field='gstNo']").val() || "");
		var rowPan = String(tr.find("input[data-field='panNo']").val() || "");
		if (KnowYourCustomer._gstOk(rowGst) && KnowYourCustomer._panOk(rowPan) && rowGst.substring(2, 12) !== rowPan) {
			problems.push(KnowYourCustomer._mark(tr.find("input[data-field='gstNo']")[0], "Ship-to row " + rowNo + ": GST number does not match the PAN."));
		}
		return problems;
	},

	_saveRow: function (tr) {
		tr.find("input").removeClass("is-invalid");
		var rowNo = tr.index() + 1;
		var any = false;
		tr.find("input").each(function () {
			if (String($(this).val() || "").trim()) any = true;
		});
		if (!any) {
			Common.showPageMsg(KnowYourCustomer.ROOT, "Enter the ship-to details before saving this row.", "warning");
			return;
		}
		var problems = KnowYourCustomer._rowProblems(tr, rowNo);
		if (problems.length) {
			Common.showPageMsg(KnowYourCustomer.ROOT, problems[0], "warning");
			return;
		}
		tr.find("input").each(function () {
			$(this).siblings(".kyc-view").text($(this).val());
		});
		tr.removeClass("is-edit");
		Common.showPageMsg(KnowYourCustomer.ROOT, "Ship-to row saved in the list. Update sends the customer.", "success");
	},

	_removeNewRow: function (tr) {
		if (!tr.hasClass("is-new")) return;
		tr.remove();
		$("#kyc_row_count").text($("#kyc_rows tr").length + " locations");
		Common.showPageMsg(KnowYourCustomer.ROOT, "New ship-to row removed. Update has not been sent.", "success");
	},

	_addRow: function (row, editing) {
		var fields = ["shipToCode", "shipToAddress", "gstNo", "phoneNo", "emailId", "panNo", "contactPerson", "remarks"];
		var maxLen = { gstNo: "15", phoneNo: "14", panNo: "10" };
		var tr = document.createElement("tr");
		if (editing) tr.className = "is-edit is-new";
		for (var i = 0; i < fields.length; i++) {
			var td = document.createElement("td");
			var value = row[fields[i]] == null ? "" : String(row[fields[i]]);
			var view = document.createElement("span");
			view.className = "kyc-view";
			view.textContent = value;
			var input = document.createElement("input");
			input.type = "text";
			input.setAttribute("data-field", fields[i]);
			if (maxLen[fields[i]]) input.maxLength = maxLen[fields[i]];
			if (fields[i] === "phoneNo") input.setAttribute("inputmode", "tel");
			input.value = value;
			td.appendChild(view);
			td.appendChild(input);
			tr.appendChild(td);
		}
		var act = document.createElement("td");
		act.className = "kyc-row-act";
		act.innerHTML = "<button type='button' class='kyc-row-btn kyc-row-edit' title='Edit row' aria-label='Edit row'><i class='ri-edit-2-line'></i></button><button type='button' class='kyc-row-btn kyc-row-save' title='Save row' aria-label='Save row'><i class='ri-check-line'></i></button><button type='button' class='kyc-row-btn kyc-row-delete' title='Remove new row' aria-label='Remove new row'><i class='ri-delete-bin-line'></i></button>";
		tr.appendChild(act);
		document.getElementById("kyc_rows").appendChild(tr);
		$("#kyc_row_count").text($("#kyc_rows tr").length + " locations");
		if (editing) {
			var first = tr.querySelector("input");
			if (first && first.scrollIntoView) first.scrollIntoView({ block: "center", behavior: "smooth" });
			if (first) first.focus();
		}
	},

	_collect: function (context) {
		var rows = [];
		$("#kyc_rows tr").each(function () {
			var row = {};
			$(this).find("input").each(function () {
				row[$(this).attr("data-field")] = $(this).val();
			});
			rows.push(row);
		});
		return {
			custCode: context.custCode,
			loginId: context.loginId,
			proprietorName: $("#kyc_proprietor").val(),
			businessAddress: $("#kyc_business_address").val(),
			billingAddress: $("#kyc_billing_address").val(),
			gstNo: $("#kyc_gst").val(),
			panNo: $("#kyc_pan").val(),
			primaryContact: $("#kyc_primary_contact").val(),
			alternateContact: $("#kyc_alternate_contact").val(),
			emailAccounting: $("#kyc_email_accounting").val(),
			emailTransaction: $("#kyc_email_transaction").val(),
			remarks: $("#kyc_remarks").val(),
			drugLicenseNo: $("#kyc_drug_license").val(),
			rows: rows,
			dummy: window.as400_dummy_data_required === true
		};
	}
};

window.KnowYourCustomer = KnowYourCustomer;
