/**
 * Certificate of Analysis.
 * Menu js_path loads this file before the HTML calls CertificateOfAnalysis.Load().
 */
CertificateOfAnalysis = {
	ROOT: "m_certificate_of_analysis",
	_mandatory: false,
	_reportTab: false,

	/**
	 * Active COA shell (multi-tab safe). Prefer InpcTabs active pane, else visible home.
	 */
	_$home: function () {
		var homeSel = "#" + CertificateOfAnalysis.ROOT;
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find(homeSel) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $(homeSel).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $(homeSel).first();
	},

	/** Find within #m_certificate_of_analysis so duplicate ids in other portal tabs are ignored. */
	_$: function (selector) {
		var $home = CertificateOfAnalysis._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	_el: function (selector) {
		return CertificateOfAnalysis._$(selector).get(0) || null;
	},

	Load: function () {
		CertificateOfAnalysis._ensureTable();
		CertificateOfAnalysis._wireSuggest();
		CertificateOfAnalysis._ensureDatePickers();
		CertificateOfAnalysis._wireFileBrowse();
		CertificateOfAnalysis._loadContext();
	},

	_wireFileBrowse: function () {
		CertificateOfAnalysis._$("#coa_label_browse").off("click.coaBrowse")
			.on("click.coaBrowse", function (event) {
				event.preventDefault();
				var input = CertificateOfAnalysis._el("#coa_label_file");
				if (input) {
					input.click();
				}
			});
		CertificateOfAnalysis._$("#coa_label_file").off("change.coaBrowse")
			.on("change.coaBrowse", function () {
				var file = this.files && this.files[0];
				CertificateOfAnalysis._$("#coa_label_file_name").text(file ? file.name : "");
			});
	},

	ShowTab: function (which) {
		var report = which === "report" && CertificateOfAnalysis._reportTab;
		CertificateOfAnalysis._$("#coa_tab").toggleClass("active", !report);
		CertificateOfAnalysis._$("#coa_report_tab").toggleClass("active", report);
		CertificateOfAnalysis._$("#coa_panel").toggleClass("d-none", report);
		CertificateOfAnalysis._$("#coa_report_panel").toggleClass("d-none", !report);
	},

	Submit: function () {
		var stock = $.trim(CertificateOfAnalysis._$("#coa_stock_code").val());
		var batch = $.trim(CertificateOfAnalysis._$("#coa_batch_id").val());
		if (!stock) { ShowErrorMsg("Please Enter Stock Code"); return false; }
		if (!batch) { ShowErrorMsg("Please Enter Batch ID"); return false; }
		CertificateOfAnalysis._hideResult();
		var base = window.$app_url ? String(window.$app_url) : "";
		showLoader("Looking up certificate…", CertificateOfAnalysis.ROOT);
		$.ajax({
			url: base + "api/customer/coa/list",
			method: "GET",
			dataType: "json",
			data: { stockCode: stock, batchId: batch },
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (CertificateOfAnalysis._session(json)) return;
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					ShowErrorMsg((json && (json.message || json.status)) || "Unable to look up the certificate.");
					return;
				}
				Common.clearPageMsg(CertificateOfAnalysis.ROOT);
				CertificateOfAnalysis._$("#coa_stock_error,#coa_batch_error").removeClass("on");
				var payload = json.data != null ? json.data : {};
				CertificateOfAnalysis._mandatory = payload.mandatory === true || payload.mandatory === 1 || payload.mandatory === "1";
				CertificateOfAnalysis._$("#coa_file_required").toggleClass("d-none", !CertificateOfAnalysis._mandatory);
				var list = payload.rows || [];
				if (!list.length) {
					CertificateOfAnalysis._$("#coa_miss").removeClass("d-none");
					return;
				}
				var rows = [];
				for (var i = 0; i < list.length; i++) {
					var name = String((list[i] && list[i].fileName) || "").trim();
					if (!name) continue;
					rows.push({
						fileName: name,
						skuCode: list[i].skuCode || stock,
						batchCode: list[i].batchCode || batch,
						action: "<button type=\"button\" class=\"btn btn-sm btn-primary coa-download\" data-coa-name=\""
							+ encodeURIComponent(name) + "\">Download</button>"
					});
				}
				CertificateOfAnalysis._$("#coa_found").removeClass("d-none");
				Common.DataTable.setData("coa_found", rows);
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				ShowErrorMsg("Network error" + (xhr && xhr.status ? " (HTTP " + xhr.status + ")" : "") + ".");
			},
			complete: function () { hideLoader(CertificateOfAnalysis.ROOT); }
		});
		return false;
	},

	SendRequest: function () {
		var stock = $.trim(CertificateOfAnalysis._$("#coa_stock_code").val());
		var batch = $.trim(CertificateOfAnalysis._$("#coa_batch_id").val());
		var invoice = $.trim(CertificateOfAnalysis._$("#coa_invoice_no").val());
		var date = $.trim(CertificateOfAnalysis._$("#coa_invoice_date").val());
		var message = $.trim(CertificateOfAnalysis._$("#coa_message").val());
		var fileInput = CertificateOfAnalysis._el("#coa_label_file");
		if (!invoice) { ShowErrorMsg("Please Enter Invoice No."); return false; }
		if (!date) { ShowErrorMsg("Invoice Date Cannot be Empty"); return false; }
		if (!message) { ShowErrorMsg("Please Enter Message"); return false; }
		if (CertificateOfAnalysis._mandatory && (!fileInput || !fileInput.files || !fileInput.files.length)) {
			ShowErrorMsg("Please Upload Photo Copy");
			return false;
		}
		var form = new FormData();
		form.append("stockCode", stock);
		form.append("batchId", batch);
		form.append("invoiceNo", invoice);
		form.append("invoiceDate", date);
		form.append("message", message);
		if (fileInput && fileInput.files && fileInput.files[0]) form.append("file", fileInput.files[0]);
		var base = window.$app_url ? String(window.$app_url) : "";
		showLoader("Sending request…", CertificateOfAnalysis.ROOT);
		$.ajax({
			url: base + "api/customer/coa/request",
			method: "POST",
			data: form,
			processData: false,
			contentType: false,
			dataType: "json",
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (CertificateOfAnalysis._session(json)) return;
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (!json || (code != null && Number(code) !== 0)) {
					ShowErrorMsg((json && (json.message || json.data)) || "Unable to submit the request");
					return;
				}
				CertificateOfAnalysis._$("#coa_stock_code").val("");
				CertificateOfAnalysis._$("#coa_batch_id").val("");
				CertificateOfAnalysis._hideResult();
				ShowSuccessMsg((json && json.data) || "Your Request is submitted successfully.");
			},
			error: function (xhr, status) {
				if (status !== "abort") ShowErrorMsg("Unable to submit the request");
			},
			complete: function () { hideLoader(CertificateOfAnalysis.ROOT); }
		});
		return false;
	},

	DownloadReport: function (type) {
		if (!CertificateOfAnalysis._reportTab) { ShowErrorMsg("Not authorized to generate the report"); return false; }
		CertificateOfAnalysis._open("api/customer/coa/report/log?type=" + encodeURIComponent(type)
			+ "&from=" + encodeURIComponent(CertificateOfAnalysis._iso("coa_from_date"))
			+ "&to=" + encodeURIComponent(CertificateOfAnalysis._iso("coa_to_date")));
		return false;
	},

	DownloadErrorFiles: function () {
		if (!CertificateOfAnalysis._reportTab) { ShowErrorMsg("Not authorized to generate the report"); return false; }
		CertificateOfAnalysis._open("api/customer/coa/report/errors?from="
			+ encodeURIComponent(CertificateOfAnalysis._iso("coa_from_date"))
			+ "&to=" + encodeURIComponent(CertificateOfAnalysis._iso("coa_to_date")));
		return false;
	},

	_loadContext: function () {
		var base = window.$app_url ? String(window.$app_url) : "";
		$.ajax({
			url: base + "api/customer/coa/context",
			method: "GET",
			dataType: "json",
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (CertificateOfAnalysis._session(json)) return;
				var payload = json && json.data ? json.data : {};
				CertificateOfAnalysis._reportTab = payload.reportTab === true || payload.reportTab === "true";
				CertificateOfAnalysis._$("#coa_report_tab").toggleClass("d-none", !CertificateOfAnalysis._reportTab);
			}
		});
	},

	_ensureDatePickers: function () {
		var $root = CertificateOfAnalysis._$home();
		if (!$root.length || !window.jQuery || !$.fn.datepicker) return;
		$root.find("#coa_invoice_date, #coa_from_date, #coa_to_date").each(function () {
			var $el = $(this);
			$el.attr("data-date-format", "dd/mm/yyyy");
			$el.attr("placeholder", "dd/mm/yyyy");
			try {
				if ($el.data("datepicker")) $el.datepicker("destroy");
			} catch (eD) { /* Ignore stale picker instances after fragment reload. */ }
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				format: "dd/mm/yyyy",
				orientation: "bottom auto",
				defaultViewDate: new Date()
			});
		});
	},

	_ensureTable: function () {
		if (!CertificateOfAnalysis._clickBound) {
			CertificateOfAnalysis._clickBound = true;
			$(document).on("click", "#m_certificate_of_analysis .coa-download", function (e) {
				e.preventDefault();
				/* Only the active COA shell (multi-tab safe). */
				if (!CertificateOfAnalysis._$home().has(this).length) return;
				var name = "";
				try { name = decodeURIComponent($(this).attr("data-coa-name") || ""); } catch (err) { name = ""; }
				if (!name) return;
				CertificateOfAnalysis._open("api/customer/coa/file?name=" + encodeURIComponent(name));
			});
		}
		Common.DataTable.init({
			rootId: "coa_found",
			tableId: "coa_table",
			tbodyId: "coa_tbody",
			filter_type: "minimal",
			searchPlaceholder: "Filter documents…",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "full",
			maxHeight: "320px",
			emptyMessage: "No certificate found",
			columns: [
				{ title: "Document", field: "fileName", sortable: true },
				{ title: "Stock Code", field: "skuCode", sortable: true },
				{ title: "Batch ID", field: "batchCode", sortable: true },
				{ title: "Action", field: "action", type: "html", searchable: false, sortable: false, width: 120 }
			],
			rows: []
		});
	},

	_wireSuggest: function () {
		CertificateOfAnalysis._auto("#coa_stock_code", "api/customer/coa/sku", function (item) {
			CertificateOfAnalysis._$("#coa_stock_code").val(item.value || "");
			CertificateOfAnalysis._mandatory = String(item.is_mandatory) === "1";
			CertificateOfAnalysis._$("#coa_file_required").toggleClass("d-none", !CertificateOfAnalysis._mandatory);
		}, {
			errorSelector: "#coa_stock_error",
			spinnerId: "coa_stock_ac_spinner",
			reuseResultsOnFocus: true,
			extra: function () { return {}; }
		});
		CertificateOfAnalysis._auto("#coa_batch_id", "api/customer/coa/batch", function (item) {
			CertificateOfAnalysis._$("#coa_batch_id").val(item.value || "");
		}, {
			errorSelector: "#coa_batch_error",
			spinnerId: "coa_batch_ac_spinner",
			reuseResultsOnFocus: true,
			extra: function () { return { stockCode: $.trim(CertificateOfAnalysis._$("#coa_stock_code").val()) }; },
			before: function () {
				if (!$.trim(CertificateOfAnalysis._$("#coa_stock_code").val())) { ShowErrorMsg("Please select Stock Code"); return false; }
				return true;
			}
		});
		CertificateOfAnalysis._auto("#coa_invoice_no", "api/customer/coa/invoice", function (item) {
			CertificateOfAnalysis._$("#coa_invoice_no").val(item.value || "");
			CertificateOfAnalysis._$("#coa_invoice_date").val(CertificateOfAnalysis._uiDate(item.name || item.inv_date || ""));
		}, {
			errorSelector: "#coa_invoice_error",
			spinnerId: "coa_invoice_ac_spinner",
			reuseResultsOnFocus: true,
			extra: function () { return { stockCode: $.trim(CertificateOfAnalysis._$("#coa_stock_code").val()) }; }
		});
	},

	_autocompleteContextKey: function (opts) {
		var extra = opts && opts.extra ? opts.extra() : {};
		var keys = Object.keys(extra || {}).sort();
		return JSON.stringify(keys.map(function (key) {
			return [key, String(extra[key] == null ? "" : extra[key])];
		}));
	},

	_auto: function (selector, path, onSelect, opts) {
		var $txt = $(selector);
		if (!$txt.length || typeof $txt.autocomplete !== "function") return;
		opts = opts || {};
		$txt.off("input.coaAutocomplete").on("input.coaAutocomplete", function () {
			var cached = $txt.data("coaAutocompleteResults");
			if (cached && cached.term !== $.trim(String($txt.val() || ""))) {
				$txt.removeData("coaAutocompleteResults");
			}
			if (opts.errorSelector) $(opts.errorSelector).removeClass("on");
		});
		$txt.off("focus.coaAutocomplete").on("focus.coaAutocomplete", function () {
			if (!opts.reuseResultsOnFocus) return;
			var cached = $txt.data("coaAutocompleteResults");
			var term = $.trim(String($txt.val() || ""));
			var contextKey = CertificateOfAnalysis._autocompleteContextKey(opts);
			if (cached && cached.term === term && cached.contextKey === contextKey && term.length >= 1) {
				$txt.autocomplete("search", term);
			}
		});
		try { $txt.autocomplete("destroy"); } catch (e) { /* first bind */ }
		$txt.autocomplete({
			minLength: 1,
			appendTo: "#m_certificate_of_analysis",
			source: function (request, response) {
				if (opts.before && opts.before() === false) { response([]); return; }
				var term = $.trim(String(request.term || ""));
				var contextKey = CertificateOfAnalysis._autocompleteContextKey(opts);
				var cached = $txt.data("coaAutocompleteResults");
				if (opts.reuseResultsOnFocus && cached && cached.term === term && cached.contextKey === contextKey) {
					response(cached.rows);
					return;
				}
				var previous = $txt.data("coaAutocompleteXhr");
				if (previous && previous.abort) previous.abort();
				var base = window.$app_url ? String(window.$app_url) : "";
				var context = CertificateOfAnalysis._procedureContext();
				var extraData = opts.extra ? opts.extra() : {};
				var data = $.extend({
					phrase: request.term,
					custCode: context.custCode,
					loginId: context.loginId
				}, extraData);
				var xhr = $.ajax({
					url: base + path,
					method: "GET",
					dataType: "json",
					data: data,
					xhrFields: { withCredentials: true },
					beforeSend: function () {
						if (opts.spinnerId) Common.ShowAcSpinner("#m_certificate_of_analysis", opts.spinnerId);
					},
					success: function (json) {
						if (CertificateOfAnalysis._session(json)) {
							response([]);
							return;
						}
						var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
						if (!json || (code != null && Number(code) !== 0)) {
							ShowErrorMsg((json && (json.message || json.status)) || "Unable to search");
							response([]);
							return;
						}
						var payload = json && json.data != null ? json.data : [];
						var list = Array.isArray(payload) ? payload : [];
						if (list.length && opts.errorSelector) $(opts.errorSelector).removeClass("on");
						if (!list.length) {
							if (selector === "#coa_stock_code") CertificateOfAnalysis._$("#coa_stock_error").addClass("on");
							if (selector === "#coa_batch_id") CertificateOfAnalysis._$("#coa_batch_error").addClass("on");
							if (selector === "#coa_invoice_no") CertificateOfAnalysis._$("#coa_invoice_error").addClass("on");
							response([]);
							return;
						}
						CertificateOfAnalysis._$("#coa_stock_error,#coa_batch_error,#coa_invoice_error").removeClass("on");
						var suggestions = $.map(list, function (row) {
							return { label: row.value, value: row.value, name: row.name || row.inv_date || "", is_mandatory: row.is_mandatory };
						});
						if (opts.reuseResultsOnFocus && $.trim(String($txt.val() || "")) === term
							&& CertificateOfAnalysis._autocompleteContextKey(opts) === contextKey) {
							$txt.data("coaAutocompleteResults", {
								term: term,
								contextKey: contextKey,
								rows: suggestions
							});
						}
						response(suggestions);
					},
					error: function (_xhr, status) {
						if (status !== "abort") ShowErrorMsg("Unable to search for matches.");
						response([]);
					},
					complete: function (xhr) {
						if ($txt.data("coaAutocompleteXhr") === xhr) {
							$txt.removeData("coaAutocompleteXhr");
							if (opts.spinnerId) Common.HideAcSpinner("#m_certificate_of_analysis", opts.spinnerId);
						}
						$txt.removeClass("ui-autocomplete-loading");
					}
				});
				$txt.data("coaAutocompleteXhr", xhr);
			},
			select: function (event, ui) {
				$txt.removeData("coaAutocompleteResults");
				if (onSelect) onSelect(ui.item || {});
				return false;
			}
		});
	},

	_procedureContext: function () {
		if (Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	},

	_hideResult: function () {
		CertificateOfAnalysis._$("#coa_found,#coa_miss").addClass("d-none");
		CertificateOfAnalysis._$("#coa_invoice_no,#coa_invoice_date,#coa_message").val("");
		var file = CertificateOfAnalysis._el("#coa_label_file");
		if (file) file.value = "";
		Common.DataTable.setData("coa_found", []);
	},

	_open: function (path) {
		var base = window.$app_url ? String(window.$app_url) : "";
		window.location.href = base + path;
	},

	_iso: function (id) {
		var raw = $.trim(CertificateOfAnalysis._$("#" + id).val());
		var parts = raw.split("/");
		if (parts.length !== 3) return "";
		return parts[2] + "-" + parts[1] + "-" + parts[0];
	},

	_uiDate: function (value) {
		var text = String(value || "").trim();
		if (/^\d{8}$/.test(text)) return text.substr(6, 2) + "/" + text.substr(4, 2) + "/" + text.substr(0, 4);
		if (/^\d{4}-\d{2}-\d{2}/.test(text)) {
			var bits = text.substring(0, 10).split("-");
			return bits[2] + "/" + bits[1] + "/" + bits[0];
		}
		return text;
	},

	_session: function (json) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return true;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return true;
		}
		return false;
	}
};

window.CertificateOfAnalysis = CertificateOfAnalysis;
