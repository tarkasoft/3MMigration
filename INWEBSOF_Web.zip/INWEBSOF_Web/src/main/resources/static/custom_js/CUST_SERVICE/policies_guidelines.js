/**
 * Policies & Guidelines. Responsive document cards from the COMAGM share.
 * Menu js_path loads this file before the HTML calls PoliciesGuidelines.Load().
 */
PoliciesGuidelines = {
	ROOT: "m_policies_guidelines",
	_documents: [],

	Load: function () {
		PoliciesGuidelines._bindOnce();
		PoliciesGuidelines._load();
	},

	_bindOnce: function () {
		if (!PoliciesGuidelines._clickBound) {
			PoliciesGuidelines._clickBound = true;
			$(document).on("click", "#m_policies_guidelines .pg-download", function (e) {
				e.preventDefault();
				var name = String($(this).data("pgName") || "");
				if (!name) return;
				var context = PoliciesGuidelines._login();
				var base = window.$app_url ? String(window.$app_url) : "";
				var dummy = window.as400_dummy_data_required === true ? "true" : "false";
				window.location.href = base + "api/customer/policies/file?name="
					+ encodeURIComponent(name)
					+ "&custCode=" + encodeURIComponent(context.custCode || "")
					+ "&loginId=" + encodeURIComponent(context.loginId || "")
					+ "&dummy=" + dummy;
			});

			$(document).on("input", "#m_policies_guidelines #pg_search", function () {
				PoliciesGuidelines._render();
			});
		}
		PoliciesGuidelines._render();
	},

	_render: function () {
		var query = String($("#pg_search").val() || "").trim().toLowerCase();
		var documents = PoliciesGuidelines._documents.filter(function (document) {
			return !query || document.name.toLowerCase().indexOf(query) !== -1;
		});
		var $grid = $("#pg_grid").empty();
		for (var i = 0; i < documents.length; i++) {
			var item = documents[i];
			var name = item.name;
			var isPdf = /\.pdf$/i.test(name);
			var $card = $("<article>").addClass("pg-card");
			var $icon = $("<span>").addClass("pg-file-icon").attr("aria-hidden", "true");
			$("<i>").addClass(isPdf ? "ri-file-pdf-2-line" : "ri-file-text-line").appendTo($icon);
			var $content = $("<div>").addClass("pg-card-content");
			$("<div>").addClass("pg-card-name").text(name).appendTo($content);
			$("<button>")
				.attr("type", "button")
				.addClass("btn btn-sm btn-primary pg-download")
				.data("pgName", name)
				.append($("<i>").addClass("ri-download-2-line").attr("aria-hidden", "true"))
				.append(window.document.createTextNode(" Download"))
				.appendTo($content);
			$card.append($icon, $content).appendTo($grid);
		}
		$("#pg_count").text(documents.length + (documents.length === 1 ? " document" : " documents"));
		$("#pg_empty").toggleClass("d-none", documents.length !== 0);
		$grid.toggleClass("d-none", documents.length === 0);
	},

	_load: function () {
		var context = PoliciesGuidelines._login();
		var base = window.$app_url ? String(window.$app_url) : "";
		showLoader("Loading policies…", PoliciesGuidelines.ROOT);
		$.ajax({
			url: base + "api/customer/policies/list",
			method: "GET",
			dataType: "json",
			data: {
				custCode: context.custCode,
				loginId: context.loginId,
				dummy: window.as400_dummy_data_required === true
			},
			xhrFields: { withCredentials: true },
			success: function (json) {
				if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
					window.inpcHandleSessionExpired(json && (json.message || json.data));
					return;
				}
				var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
				if (code === -9 || code === "-9") {
					window.inpcHandleSessionExpired(json && (json.message || json.data));
					return;
				}
				if (!json || (code != null && Number(code) !== 0)) {
					Common.showPageMsg(PoliciesGuidelines.ROOT, (json && (json.message || json.status)) || "Unable to load policies and guidelines.", "danger");
					return;
				}
				Common.clearPageMsg(PoliciesGuidelines.ROOT);
				var payload = json.data != null ? json.data : json;
				var list = (payload && payload.rows) || [];
				var documents = [];
				for (var i = 0; i < list.length; i++) {
					var name = String((list[i] && list[i].name) || "").trim();
					if (!name) continue;
					documents.push({ name: name });
				}
				PoliciesGuidelines._documents = documents;
				PoliciesGuidelines._render();
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				var msg = "Network error";
				if (xhr && xhr.status) msg += " (HTTP " + xhr.status + ")";
				Common.showPageMsg(PoliciesGuidelines.ROOT, msg + ".", "danger");
			},
			complete: function () {
				hideLoader(PoliciesGuidelines.ROOT);
			}
		});
	},

	_login: function () {
		if (Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	}
};

window.PoliciesGuidelines = PoliciesGuidelines;
