ChangeCustomer =
{
	_pendingCode: "",
	_pendingName: "",
	_pendingLoginId: "",
	_pendingInternal: "",
	_acAjax: null,
	_acWired: false,

	/**
	 * Decode URI-encoded cookie/API values for display; safe if already plain text.
	 */
	SafeDecode: function (s) {
		if (s == null || s === "") {
			return "";
		}
		s = String(s);
		try {
			return decodeURIComponent(s.replace(/\+/g, " "));
		} catch (eDec) {
			return s;
		}
	},

	/**
	 * Show/hide profile dropdown "Change Customer Code" when see_other_cust_data is Yes.
	 * Prefer explicit flag from menus/me response; otherwise fall back to cookie fw_see_other_cust_data.
	 */
	ApplyVisibility: function (seeOther) {
		var flag = seeOther;
		if (flag == null || String(flag).trim() === "") {
			try {
				if (typeof getCookie === "function") {
					flag = getCookie("fw_see_other_cust_data");
				}
			} catch (e0) { /* ignore */ }
		}
		var show = String(flag == null ? "" : flag).trim().toLowerCase() === "yes";
		var $item = $("#change_customer_code_menu_item");
		if (!$item.length) {
			return;
		}
		if (show) {
			$item.removeClass("d-none");
		} else {
			$item.addClass("d-none");
		}
	},

	Open: function () {
		var el = document.getElementById("change_customer_modal");
		if (!el) {
			return;
		}
		ChangeCustomer._pendingCode = "";
		ChangeCustomer._pendingName = "";
		ChangeCustomer._pendingLoginId = "";
		ChangeCustomer._pendingInternal = "";
		$("#change_customer_code").val("");
		$("#change_customer_internal").val("0");
		ChangeCustomer._showError("");
		Common.HideAcSpinner("#change_customer_modal", "change_customer_ac_spinner");
		ChangeCustomer.WireAutocomplete();
		try {
			bootstrap.Modal.getOrCreateInstance(el).show();
		} catch (e1) {
			$(el).modal("show");
		}
	},

	_showError: function (message, alertUser) {
		var text = message == null ? "" : String(message).trim();
		var $err = $("#change_customer_error");
		if ($err.length) {
			if (text) {
				$err.removeClass("d-none").text(text);
			} else {
				$err.addClass("d-none").text("");
			}
		}
		if (text && alertUser !== false) {
			if (typeof ShowAlertMsg === "function") {
				ShowAlertMsg(text);
			} else {
				alert(text);
			}
		}
	},

	_errorMessage: function (xhr, status) {
		if (status === "abort") {
			return "";
		}
		var msg = "Unable to search customers.";
		if (xhr) {
			if (xhr.status === 401) {
				msg = "Please login once again";
			} else if (xhr.status === 403) {
				msg = "Change Customer is not permitted.";
			} else if (xhr.status === 404) {
				msg = "Customer search is unavailable (404). Please contact administrator.";
			} else if (xhr.status === 0) {
				msg = "Network error while searching customers. Please try again.";
			} else if (xhr.status) {
				msg = "Customer search failed (" + xhr.status + ").";
			}
			var body = xhr.responseJSON;
			if (!body && xhr.responseText) {
				try {
					body = JSON.parse(xhr.responseText);
				} catch (eParse) {
					body = null;
				}
			}
			if (body) {
				var apiMsg = body.message || body.status;
				if (apiMsg && String(apiMsg).trim()) {
					msg = String(apiMsg).trim();
				}
			}
		}
		return msg;
	},

	/**
	 * Self-contained jQuery UI autocomplete (does NOT call POPUP / AssignJqueryAutoCompleteNew).
	 * Uses global $app_url (from fw-globals via MainPage) — never redefine host here.
	 * AJAX sends only the typed term as {@code value}.
	 */
	WireAutocomplete: function () {
		var $txt = $("#change_customer_code");
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			console.warn("ChangeCustomer: jQuery UI autocomplete not available");
			return;
		}
		if (ChangeCustomer._acWired) {
			try {
				$txt.autocomplete("destroy");
			} catch (e2) { /* ignore */ }
			ChangeCustomer._acWired = false;
		}

		$txt.off("keydown.changeCust").on("keydown.changeCust", function (event) {
			if (event.keyCode === 8 || event.keyCode === 46) {
				$("#change_customer_internal").val("0");
				ChangeCustomer._pendingCode = "";
				ChangeCustomer._pendingName = "";
				ChangeCustomer._pendingLoginId = "";
				ChangeCustomer._pendingInternal = "";
			}
		});

		$txt.autocomplete({
			minLength: 1,
			/* Append inside modal so menu stacks above Bootstrap backdrop (~1055) and stays in focus trap */
			appendTo: "#change_customer_modal .modal-body",
			position: { my: "left top", at: "left bottom", collision: "flip" },
			open: function () {
				var $menu = $(this).autocomplete("widget");
				$menu.css({ zIndex: 2060, position: "absolute" });
			},
			source: function (request, response) {
				$("#change_customer_internal").val("0");
				ChangeCustomer._showError("");
				if (ChangeCustomer._acAjax && ChangeCustomer._acAjax.abort) {
					ChangeCustomer._acAjax.abort();
				}
				var base = window.$app_url || "";
				ChangeCustomer._acAjax = $.ajax({
					dataType: "json",
					type: "GET",
					url: base + "api/portal/change-customer/autocomplete",
					data: { value: request.term },
					xhrFields: { withCredentials: true },
					beforeSend: function () {
						Common.ShowAcSpinner("#change_customer_modal", "change_customer_ac_spinner");
					},
					complete: function () {
						Common.HideAcSpinner("#change_customer_modal", "change_customer_ac_spinner");
						$txt.removeClass("ui-autocomplete-loading");
					},
					error: function (xhr, status) {
						if (status === "abort") {
							response([]);
							return;
						}
						var msg = ChangeCustomer._errorMessage(xhr, status);
						if (xhr && xhr.status === 401 && window.inpcHandleSessionExpired) {
							window.inpcHandleSessionExpired(msg || "Please login once again");
						} else if (msg) {
							ChangeCustomer._showError(msg);
						}
						response([]);
					},
					success: function (v_response) {
						var code = v_response && (v_response.errorCode != null
							? v_response.errorCode : v_response.error_code);
						if (code != null && Number(code) !== 0) {
							var msg = (v_response && (v_response.message || v_response.status))
								|| "Customer search failed.";
							if (Number(code) === 401 || /session/i.test(String(msg))) {
								if (window.inpcHandleSessionExpired) {
									window.inpcHandleSessionExpired(msg);
								} else {
									ChangeCustomer._showError(msg);
								}
							} else {
								ChangeCustomer._showError(msg);
							}
							response([]);
							return;
						}
						var rows =
							v_response && v_response.data ? v_response.data : [];
						if (!rows.length) {
							ChangeCustomer._showError("No customers found for this search.", false);
						}
						response(rows);
					}
				});
			},
			focus: function () {
				return false;
			},
			select: function (event, ui) {
				if (!ui || !ui.item) {
					return false;
				}
				ChangeCustomer._showError("");
				var v = String(ui.item.value == null ? "" : ui.item.value);
				var parts = v.split(" - ");
				var code = (parts[0] || "").trim();
				var name =
					parts.length > 1
						? parts.slice(1).join(" - ").trim()
						: v.trim();

				ChangeCustomer._pendingCode =
					ui.item.code != null && String(ui.item.code).trim() !== ""
						? String(ui.item.code).trim()
						: code;
				ChangeCustomer._pendingName =
					ui.item.name != null && String(ui.item.name).trim() !== ""
						? String(ui.item.name).trim()
						: name;
				ChangeCustomer._pendingLoginId =
					ui.item.loginId != null ? String(ui.item.loginId).trim() : "";
				ChangeCustomer._pendingInternal = "";

				$("#change_customer_internal").val("0");
				this.value = v;
				return false;
			}
		});
		ChangeCustomer._acWired = true;
	},
	Apply: function () {
		var code = ChangeCustomer._pendingCode;
		var name = ChangeCustomer._pendingName;
		var loginId = ChangeCustomer._pendingLoginId;
		var txt = ($("#change_customer_code").val() || "").trim();

		if ((!code || !name) && txt.indexOf(" - ") >= 0) {
			var p = txt.split(" - ");
			code = code || (p[0] || "").trim();
			name = name || p.slice(1).join(" - ").trim();
		}
		if (!name && txt) {
			name = txt;
		}
		if (!code && txt && txt.indexOf(" - ") < 0) {
			code = txt;
		}
		if (!code) {
			ChangeCustomer._showError("Please select a customer code");
			return;
		}
		if (!loginId) {
			ChangeCustomer._showError("Please select a customer from the list");
			return;
		}

		/* Decode first so inpcSetCookie does not double-encode (%2C etc.) */
		code = ChangeCustomer.SafeDecode(code);
		name = ChangeCustomer.SafeDecode(name || "");
		loginId = ChangeCustomer.SafeDecode(loginId);

		/* Override cookies Ã¢â‚¬â€ only via inpcSetCookie */
		inpcSetCookie("fw_override_cust_code", code);
		inpcSetCookie("fw_override_cust_name", name || "");
		inpcSetCookie("fw_override_loginId", loginId);
		inpcSetCookie("fw_customer_overridden", "Yes");

		ChangeCustomer.RefreshHeaderDisplay(name);

		ChangeCustomer.Close();
	},

	Close: function () {
		var el = document.getElementById("change_customer_modal");
		if (!el) {
			return;
		}
		try {
			bootstrap.Modal.getOrCreateInstance(el).hide();
		} catch (e3) {
			$(el).modal("hide");
		}
	},

	ResetToHomeCustomer: function () {
		var homeCode = "";
		var homeName = "";
		var homeLoginId = "";
		if (typeof getCookie === "function") {
			homeCode = ChangeCustomer.SafeDecode(getCookie("fw_cust_code") || "");
			homeName = ChangeCustomer.SafeDecode(getCookie("fw_cust_name") || "");
			homeLoginId = ChangeCustomer.SafeDecode(getCookie("fw_loginId") || "");
		}
		inpcSetCookie("fw_override_cust_code", homeCode);
		inpcSetCookie("fw_override_cust_name", homeName);
		inpcSetCookie("fw_override_loginId", homeLoginId);
		inpcSetCookie("fw_customer_overridden", "");
		ChangeCustomer.RefreshHeaderDisplay(homeName);
	},

	/**
	 * Show only the home customer name; show code and name for an active override.
	 */
	RefreshHeaderDisplay: function (fallbackName) {
		var code = "";
		var name = "";
		var overridden = false;
		try {
			if (typeof getCookie === "function") {
				overridden = String(getCookie("fw_customer_overridden") || "").trim().toLowerCase() === "yes";
				if (overridden) {
					code = getCookie("fw_override_cust_code") || "";
					name = getCookie("fw_override_cust_name") || "";
				} else {
					code = getCookie("fw_cust_code") || getCookie("fw_override_cust_code") || "";
					name = getCookie("fw_cust_name") || getCookie("fw_override_cust_name") || "";
				}
			}
		} catch (eRef) { /* ignore */ }
		if (!name && fallbackName) {
			name = fallbackName;
		}
		code = ChangeCustomer.SafeDecode(code).trim();
		name = ChangeCustomer.SafeDecode(name);
		var display = name;
		if (overridden && code && name && name.indexOf(code + " - ") !== 0 && name !== code) {
			display = code + " - " + name;
		} else if (overridden && code && !name) {
			display = code;
		}
		if (display) {
			$("#customer_name_display").text(display);
		}
		if (typeof window.inpcRefreshHeaderTitleColor === "function") {
			try { window.inpcRefreshHeaderTitleColor(); } catch (eColor) { /* ignore */ }
		}
	}
};


/* Safety net: if cookie already set (or menus raced), sync dropdown before/alongside menus callback */
$(function () {
	try {
		ChangeCustomer.ApplyVisibility();
	} catch (eReady) { /* ignore */ }
});
