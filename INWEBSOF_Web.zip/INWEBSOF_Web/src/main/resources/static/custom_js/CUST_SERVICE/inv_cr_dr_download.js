/**
 * Invoice / Credit Note / Debit Note download.
 * Menu js_path loads this file. inv_cr_dr_download.html calls InvCrDrDownload.Load().
 * First open loads once. Search loads again with the current type and dates.
 */
InvCrDrDownload = {
	ROOT: "m_inv_cr_dr_download",
	API_LIST: "api/customer/inv-cr-dr/list",
	API_DOWNLOAD: "api/customer/inv-cr-dr/download",
	_busy: false,
	_tableReady: false,

	Load: function () {
		var custCode = String(Common.GetCustCode() || "").trim();
		if (!custCode) {
			Common.showPageMsg(InvCrDrDownload.ROOT, "Customer code is missing. Please re-login or select a customer.", "warning");
			return;
		}
		InvCrDrDownload._bindOnce();
		InvCrDrDownload._ensureDatePickers();
		InvCrDrDownload._setDefaultDates();
		if (!$("#icd_table thead th").length) InvCrDrDownload._tableReady = false;
		InvCrDrDownload._load(false);
	},

	_procedureContext: function () {
		if (Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return {
				custCode: String(context.custCode || "").trim(),
				loginId: String(context.loginId || "").trim()
			};
		}
		return { custCode: "", loginId: "" };
	},

	_bindOnce: function () {
		if (window.__inpcInvCrDrBound) return;
		window.__inpcInvCrDrBound = true;
		$(document).on("click", "#icd_search_btn, #icd_refresh_btn", function (e) {
			e.preventDefault();
			InvCrDrDownload._load(true);
		});
		$(document).on("click", "#icd_filter_btn", function (e) {
			e.preventDefault();
			$("#m_icd_grid > .dt-toolbar").toggleClass("d-none");
		});
	},

	_ensureDatePickers: function () {
		var $root = $("#" + InvCrDrDownload.ROOT);
		if (!$root.length || !$.fn.datepicker) return;
		$root.find(".icd-date").each(function () {
			var $el = $(this);
			$el.attr("data-date-format", "dd/mm/yyyy");
			$el.attr("placeholder", "dd/mm/yyyy");
			try { if ($el.data("datepicker")) $el.datepicker("destroy"); } catch (eD) { /* ignore */ }
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				format: "dd/mm/yyyy",
				orientation: "bottom auto",
				defaultViewDate: new Date()
			});
		});
	},

	_pad2: function (n) { return (Number(n) < 10 ? "0" : "") + Number(n); },

	_fmtDmy: function (d) {
		return InvCrDrDownload._pad2(d.getDate()) + "/" + InvCrDrDownload._pad2(d.getMonth() + 1) + "/" + d.getFullYear();
	},

	_setDefaultDates: function () {
		var today = new Date();
		var start = new Date(today.getFullYear(), today.getMonth(), 1);
		function apply(id, text) {
			var $el = $("#" + id);
			if (!$el.length || String($el.val() || "").trim()) return;
			$el.val(text);
			try { $el.datepicker("update", text); } catch (eU) { /* ignore */ }
		}
		apply("icd_from_date", InvCrDrDownload._fmtDmy(start));
		apply("icd_to_date", InvCrDrDownload._fmtDmy(today));
	},

	_apiDate: function (id) {
		var ui = String($("#" + id).val() || "").trim();
		if (!ui || ui === "00/00/0000" || ui === "00-00-0000") return "";
		var api = (typeof DateFormatYYYYMMDD === "function") ? DateFormatYYYYMMDD(ui) : ui;
		return api === "00000000" ? "" : api;
	},

	_parseDmy: function (id) {
		var ui = String($("#" + id).val() || "").trim();
		var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(ui);
		if (!m) return null;
		var day = Number(m[1]);
		var month = Number(m[2]);
		var year = Number(m[3]);
		var d = new Date(year, month - 1, day);
		if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
		return d;
	},

	_dateRangeError: function () {
		var from = InvCrDrDownload._parseDmy("icd_from_date");
		var to = InvCrDrDownload._parseDmy("icd_to_date");
		if (!from || !to) return "Enter From Date and To Date.";
		var days = Math.round((to.getTime() - from.getTime()) / 86400000);
		if (days < 0) return "From Date must be on or before To Date.";
		if (days >= 60) return "Date difference must be less than 60 days.";
		return "";
	},

	_fmtAmt: function (n) {
		var num = Number(n);
		if (isNaN(num)) return n == null ? "" : String(n);
		try { return num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
		catch (e) { return String(num); }
	},

	_downloadHref: function (docNo, docType, invoiceDate) {
		var base = $app_url ? String($app_url) : "";
		var context = InvCrDrDownload._procedureContext();
		return base + InvCrDrDownload.API_DOWNLOAD
			+ "?custCode=" + encodeURIComponent(context.custCode)
			+ "&loginId=" + encodeURIComponent(context.loginId)
			+ "&docNo=" + encodeURIComponent(docNo || "")
			+ "&docType=" + encodeURIComponent(docType || "")
			+ "&invoiceDate=" + encodeURIComponent(invoiceDate || "")
			+ "&dummy=" + encodeURIComponent(window.as400_dummy_data_required === true);
	},

	_load: function (force) {
		var $root = $("#" + InvCrDrDownload.ROOT);
		if (!force && $root.data("listLoaded")) return;
		if (InvCrDrDownload._busy) return;
		if (!String(Common.GetCustCode() || "").trim()) {
			Common.showPageMsg(InvCrDrDownload.ROOT, "Customer code is missing.", "warning");
			return;
		}
		var context = InvCrDrDownload._procedureContext();
		var docType = String($("#icd_doc_type").val() || "").trim();
		if (!docType) {
			Common.showPageMsg(InvCrDrDownload.ROOT, "Choose Sales Invoice, Credit Note, or Debit Note.", "warning");
			return;
		}
		var rangeError = InvCrDrDownload._dateRangeError();
		if (rangeError) {
			Common.showPageMsg(InvCrDrDownload.ROOT, rangeError, "warning");
			return;
		}
		if (!InvCrDrDownload._tableReady) {
			InvCrDrDownload._initTable();
			InvCrDrDownload._tableReady = true;
		}
		InvCrDrDownload._busy = true;
		showLoader("Loading documents…", InvCrDrDownload.ROOT);
		$.ajax({
			url: ($app_url ? String($app_url) : "") + InvCrDrDownload.API_LIST,
			method: "GET",
			dataType: "json",
			data: {
				custCode: context.custCode,
				loginId: context.loginId,
				docType: docType,
				fromDate: String($("#icd_from_date").val() || "").trim(),
				toDate: String($("#icd_to_date").val() || "").trim(),
				dummy: window.as400_dummy_data_required === true
			},
			xhrFields: { withCredentials: true },
			success: function (json) {
				InvCrDrDownload._handle(json, "Unable to load documents.", function (payload) {
					var list = Array.isArray(payload) ? payload : (payload && payload.rows) || [];
					var rows = [];
					for (var i = 0; i < list.length; i++) {
						var src = list[i] || {};
						var docNo = String(src.docNo || "");
						var type = String(src.docType || docType);
						var invoiceDateRaw = src.invoiceDateRaw || src.invoiceDate || "";
						var href = InvCrDrDownload._downloadHref(docNo, type, invoiceDateRaw);
						rows.push({
							docNo: docNo,
							invoiceDate: src.invoiceDate || "",
							orderNo: src.orderNo || "",
							orgInvoice: src.orgInvoice || "",
							amount: src.amount == null ? "" : InvCrDrDownload._fmtAmt(src.amount),
							pdf: '<a href="' + href + '" target="_blank" rel="noopener">Download</a>'
						});
					}
					Common.DataTable.setData("m_icd_grid", rows);
					$root.data("listLoaded", true);
				});
			},
			error: function (xhr, status) {
				if (status === "abort") return;
				var msg = "Network error";
				if (xhr && xhr.status) msg += " (HTTP " + xhr.status + ")";
				Common.showPageMsg(InvCrDrDownload.ROOT, msg + ".", "danger");
			},
			complete: function () {
				InvCrDrDownload._busy = false;
				hideLoader(InvCrDrDownload.ROOT);
			}
		});
	},

	_handle: function (json, failMsg, onOk) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (code === -9 || code === "-9") {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			return;
		}
		if (!json || (code != null && Number(code) !== 0)) {
			Common.showPageMsg(InvCrDrDownload.ROOT, (json && (json.message || json.status)) || failMsg, "danger");
			return;
		}
		Common.clearPageMsg(InvCrDrDownload.ROOT);
		onOk(json.data != null ? json.data : json);
	},

	_initTable: function () {
		Common.DataTable.init({
			rootId: "m_icd_grid",
			tableId: "icd_table",
			tbodyId: "icd_tbody",
			infoId: "m_icd_grid_info",
			pagerId: "m_icd_grid_pager",
			searchId: "m_icd_grid_search",
			pageSizeId: "m_icd_grid_page_size",
			pageSizes: [10, 15, 25, 50],
			pageSize: 15,
			searchPlaceholder: "Filter documents…",
			stickyHeader: true,
			fillWidth: true,
			cellBorder: "row",
			maxHeight: "420px",
			emptyMessage: "No documents in this range",
			columns: [
				{ title: "Invoice/Credit Note", field: "docNo", sortable: true },
				{ title: "Invoice Date", field: "invoiceDate", sortable: true },
				{ title: "ORDER", field: "orderNo", sortable: true },
				{ title: "ORG Invoice", field: "orgInvoice", sortable: true },
				{ title: "Amount", field: "amount", sortable: true, "text-align": "right" },
				{ title: "PDF", field: "pdf", type: "html", sortable: false, searchable: false }
			],
			rows: []
		});
	}
};

window.InvCrDrDownload = InvCrDrDownload;
