﻿/**
 * Common.DataTable — shared searchable / sortable / paginated table.
 * Loaded after custom_js/common.js (requires window.Common).
 * Page owns HTML shell + AJAX; this module owns filter, sort, pager, render.
 *
 * Usage:
 *   Common.DataTable.init({ rootId, tableId, tbodyId, infoId, pagerId, searchId, pageSizeId, pageSizes, pageSize, filter_type, stickyHeader, fillWidth, cellBorder, serverSide, loadData, columns, rows, columnHideEnabled, columnDragEnabled, onRefresh });
 *   columnHideEnabled / columnDragEnabled / onRefresh are opt-in (default off).
 *   Hide/drag are session-only (not persisted); reload restores original columns.
 *   filter_type: "minimal" (default single search) | "full" (one filter per column)
 *   cellBorder: "row" (default) | "full"
 *   maxHeight: "400px" | "50vh" | "min(60vh, 560px)" — resolved to px for the scroll panel
 *   Common.DataTable.setData(rootId, rows);
 *   Loads css/common_table.css once on first init.
 *   Toolbar/footer HTML is optional — init creates missing controls when chrome !== false.
 */
(function (global) {
	"use strict";
	var Common = global.Common;
	if (!Common) {
		if (typeof console !== "undefined" && console.error) {
			console.error("tarka_common_datatable.js requires custom_js/common.js (window.Common) to load first.");
		}
		return;
	}

	Common.DataTable = {
		_instances: {},

		_id: function (v) {
			return String(v == null ? "" : v).replace(/^#/, "");
		},

		_esc: function (v) {
			return $("<div/>").text(v == null ? "" : String(v)).html();
		},

		/**
		 * Column text-align: columns[].text-align | textAlign | align.
		 * Empty / missing / unknown → "left".
		 */
		_colAlign: function (col) {
			var raw = "";
			if (col) {
				if (col["text-align"] != null && String(col["text-align"]).trim() !== "") {
					raw = String(col["text-align"]);
				} else if (col.textAlign != null && String(col.textAlign).trim() !== "") {
					raw = String(col.textAlign);
				} else if (col.align != null && String(col.align).trim() !== "") {
					raw = String(col.align);
				}
			}
			var a = String(raw || "").trim().toLowerCase();
			if (a === "right" || a === "center" || a === "left") {
				return a;
			}
			return "left";
		},

		_alignAttr: function (col) {
			var a = Common.DataTable._colAlign(col);
			return " style=\"text-align:" + a + "\" class=\"dt-align-" + a + "\"";
		},

		_widthPx: function (value, fallback) {
			if (value == null || String(value).trim() === "") {
				return fallback;
			}
			var raw = String(value).trim().toLowerCase();
			if (!/^\d+(\.\d+)?(px)?$/.test(raw)) {
				return fallback;
			}
			var width = Math.round(parseFloat(raw));
			return width > 0 ? width : fallback;
		},

		_defaultColumnWidth: function (col) {
			var title = String((col && (col.title || col.field)) || "").replace(/<[^>]*>/g, "").trim();
			return Math.max(90, Math.min(220, (title.length * 7) + 42));
		},

		_columnLimits: function (col) {
			var min = Common.DataTable._widthPx(col && col.minWidth, 70);
			var max = Common.DataTable._widthPx(col && col.maxWidth, 600);
			if (max < min) {
				max = min;
			}
			return { min: min, max: max };
		},

		_ensureColumnWidths: function (inst) {
			if (!Array.isArray(inst.columnWidths)) {
				inst.columnWidths = [];
			}
			for (var i = 0; i < inst.columns.length; i++) {
				var col = inst.columns[i] || {};
				var limits = Common.DataTable._columnLimits(col);
				var fallback = Common.DataTable._defaultColumnWidth(col);
				var width = Common.DataTable._widthPx(col.width, fallback);
				if (!(inst.columnWidths[i] > 0)) {
					inst.columnWidths[i] = Math.max(limits.min, Math.min(limits.max, width));
				}
			}
		},

		_applyColumnWidths: function (inst) {
			if (!inst || !inst.tableId) {
				return;
			}
			var table = document.getElementById(inst.tableId);
			if (!table) {
				return;
			}
			Common.DataTable._ensureColumnWidths(inst);
			var colgroup = table.querySelector("colgroup.dt-colgroup");
			if (!colgroup) {
				colgroup = document.createElement("colgroup");
				colgroup.className = "dt-colgroup";
				table.insertBefore(colgroup, table.firstChild);
			}
			var html = "";
			var total = 0;
			var paintCols = Common.DataTable._paintColumns(inst);
			for (var i = 0; i < paintCols.length; i++) {
				var src = Common.DataTable._sourceIndex(inst, Common.DataTable._fieldKey(paintCols[i]));
				var width = Math.round(inst.columnWidths[src] || Common.DataTable._defaultColumnWidth(paintCols[i]));
				total += width;
				html += '<col data-col-index="' + src + '" data-field="' + Common.DataTable._esc(Common.DataTable._fieldKey(paintCols[i])) + '" style="width:' + width + 'px;min-width:' + width + 'px;max-width:' + width + 'px">';
			}
			colgroup.innerHTML = html;
			table.style.setProperty("table-layout", "fixed", "important");
			if (inst.fillWidth) {
				table.style.setProperty("width", "max(" + Math.max(1, total) + "px, 100%)", "important");
				table.style.setProperty("min-width", "100%", "important");
			} else {
				table.style.setProperty("width", Math.max(1, total) + "px", "important");
				table.style.setProperty("min-width", Math.max(1, total) + "px", "important");
			}
		},


		_fieldKey: function (col) {
			return String((col && col.field) || "").trim();
		},

		_defaultVisible: function (col) {
			if (!col) return true;
			if (col.visible === false || col.hidden === true) return false;
			return true;
		},

		_isHideable: function (inst, col) {
			return !!(inst && inst.columnHideEnabled && col && col.hideable !== false && Common.DataTable._fieldKey(col));
		},

		_isReorderable: function (inst, col) {
			return !!(inst && inst.columnDragEnabled && col && col.reorderable !== false && Common.DataTable._fieldKey(col));
		},

		_initLayout: function (inst) {
			/* Session-only: drag order + visibility reset when the page/table is reloaded. */
			inst.columnOrder = [];
			inst.columnVisibility = {};
			for (var i = 0; i < inst.columns.length; i++) {
				var col = inst.columns[i] || {};
				var field = Common.DataTable._fieldKey(col);
				if (!field) {
					field = "__col_" + i;
					col.field = field;
				}
				inst.columnOrder.push(field);
				inst.columnVisibility[field] = Common.DataTable._defaultVisible(col);
			}
			try {
				if (typeof window !== "undefined" && window.localStorage && inst.rootId) {
					localStorage.removeItem("inpc.dt.layout." + String(inst.rootId));
				}
			} catch (ignore) { /* ignore */ }
		},

		_resetLayout: function (inst) {
			inst.columnOrder = [];
			inst.columnVisibility = {};
			for (var i = 0; i < inst.columns.length; i++) {
				var col = inst.columns[i] || {};
				var field = Common.DataTable._fieldKey(col);
				inst.columnOrder.push(field);
				inst.columnVisibility[field] = Common.DataTable._defaultVisible(col);
			}
			Common.DataTable._render(inst);
		},

		_columnByField: function (inst, field) {
			field = String(field || "");
			for (var i = 0; i < inst.columns.length; i++) {
				if (Common.DataTable._fieldKey(inst.columns[i]) === field) return inst.columns[i];
			}
			return null;
		},

		_sourceIndex: function (inst, field) {
			field = String(field || "");
			for (var i = 0; i < inst.columns.length; i++) {
				if (Common.DataTable._fieldKey(inst.columns[i]) === field) return i;
			}
			return -1;
		},

		_orderedColumns: function (inst) {
			var byField = {};
			for (var i = 0; i < inst.columns.length; i++) {
				byField[Common.DataTable._fieldKey(inst.columns[i])] = inst.columns[i];
			}
			var out = [];
			var order = inst.columnOrder || [];
			for (var o = 0; o < order.length; o++) {
				if (byField[order[o]]) out.push(byField[order[o]]);
			}
			for (var c = 0; c < inst.columns.length; c++) {
				var f = Common.DataTable._fieldKey(inst.columns[c]);
				if (order.indexOf(f) < 0) out.push(inst.columns[c]);
			}
			return out;
		},

		_paintColumns: function (inst) {
			return Common.DataTable._orderedColumns(inst).filter(function (col) {
				var field = Common.DataTable._fieldKey(col);
				return inst.columnVisibility[field] !== false;
			});
		},

		_moveColumnBefore: function (inst, dragField, targetField) {
			if (!dragField || !targetField || dragField === targetField) return false;
			var dragCol = Common.DataTable._columnByField(inst, dragField);
			var targetCol = Common.DataTable._columnByField(inst, targetField);
			if (!Common.DataTable._isReorderable(inst, dragCol) || !Common.DataTable._isReorderable(inst, targetCol)) {
				return false;
			}
			var order = inst.columnOrder.slice();
			var from = order.indexOf(dragField);
			var to = order.indexOf(targetField);
			if (from < 0 || to < 0) return false;
			order.splice(from, 1);
			to = order.indexOf(targetField);
			order.splice(to, 0, dragField);
			inst.columnOrder = order;
			Common.DataTable._render(inst);
			return true;
		},

		_getToolbar: function (inst) {
			var $root = $("#" + inst.rootId);
			if (!$root.length) return $();
			var $tb = $root.children(".dt-toolbar").first();
			if ($tb.length) return $tb;
			$tb = $('<div class="dt-toolbar"></div>');
			var $wrap0 = $root.find(".dt-table-wrap, .cu-table-wrap").first();
			if ($wrap0.length) {
				$wrap0.before($tb);
			} else if (inst.tableId && $("#" + inst.tableId).length) {
				$("#" + inst.tableId).before($tb);
			} else {
				$root.append($tb);
			}
			return $tb;
		},

		_ensureToolbarTools: function (inst) {
			if (!inst || (!inst.columnHideEnabled && typeof inst.onRefresh !== "function")) {
				return;
			}
			var $tb = Common.DataTable._getToolbar(inst);
			if (!$tb.length) return;
			var $tools = $tb.children(".dt-tools").first();
			if (!$tools.length) {
				$tools = $('<div class="dt-tools"></div>');
				$tb.append($tools);
			}

			if (typeof inst.onRefresh === "function" && !$tools.find(".dt-refresh-btn").length) {
				var $refresh = $(
					'<button type="button" class="dt-tool-btn dt-refresh-btn" title="Refresh" aria-label="Refresh">' +
					'<i class="ri-refresh-line" aria-hidden="true"></i></button>'
				);
				$refresh.on("click", function (e) {
					e.preventDefault();
					try { inst.onRefresh(inst); } catch (err) { /* page handler owns errors */ }
				});
				$tools.append($refresh);
			}

			if (inst.columnHideEnabled && !$tools.find(".dt-columns-btn").length) {
				var $btn = $(
					'<button type="button" class="dt-tool-btn dt-columns-btn" title="Columns" aria-label="Show or hide columns">' +
					'<i class="ri-layout-column-line" aria-hidden="true"></i><span>Columns</span></button>'
				);
				$btn.on("click", function (e) {
					e.preventDefault();
					Common.DataTable._openColumnsPopup(inst);
				});
				$tools.append($btn);
			}
		},

		_ensureColumnsPopup: function () {
			var $popup = $("#dt_columns_popup");
			if ($popup.length) return $popup;
			$popup = $(
				'<div id="dt_columns_popup" class="dt-columns-popup d-none" aria-hidden="true">' +
				'<div class="dt-columns-popup-backdrop" data-dt-columns-close="1"></div>' +
				'<div class="dt-columns-popup-dialog" role="dialog" aria-modal="true" aria-labelledby="dt_columns_popup_title">' +
				'<div class="dt-columns-popup-head">' +
				'<h6 id="dt_columns_popup_title">Show / hide columns</h6>' +
				'<button type="button" class="dt-columns-popup-x" data-dt-columns-close="1" aria-label="Close">&times;</button>' +
				"</div>" +
				'<p class="dt-columns-popup-hint">Choose which columns to display. Locked columns stay visible.</p>' +
				'<div class="dt-columns-popup-body" id="dt_columns_popup_body"></div>' +
				'<div class="dt-columns-popup-foot">' +
				'<button type="button" class="dt-columns-popup-btn ghost" id="dt_columns_popup_reset">Reset</button>' +
				'<button type="button" class="dt-columns-popup-btn" data-dt-columns-close="1">Cancel</button>' +
				'<button type="button" class="dt-columns-popup-btn primary" id="dt_columns_popup_apply">Apply</button>' +
				"</div></div></div>"
			);
			$("body").append($popup);
			$popup.on("click", "[data-dt-columns-close]", function (e) {
				e.preventDefault();
				Common.DataTable._closeColumnsPopup();
			});
			$popup.on("click", "#dt_columns_popup_apply", function (e) {
				e.preventDefault();
				Common.DataTable._applyColumnsPopup();
			});
			$popup.on("click", "#dt_columns_popup_reset", function (e) {
				e.preventDefault();
				Common.DataTable._resetColumnsPopupDraft();
			});
			$(document).on("keydown.dtColumnsPopup", function (e) {
				if (e.key === "Escape" && !$("#dt_columns_popup").hasClass("d-none")) {
					Common.DataTable._closeColumnsPopup();
				}
			});
			return $popup;
		},

		_openColumnsPopup: function (inst) {
			if (!inst || !inst.columnHideEnabled) return;
			var $popup = Common.DataTable._ensureColumnsPopup();
			Common.DataTable._columnsPopupInst = inst;
			var ordered = Common.DataTable._orderedColumns(inst);
			var html = "";
			for (var i = 0; i < ordered.length; i++) {
				var col = ordered[i] || {};
				var field = Common.DataTable._fieldKey(col);
				var title = Common.DataTable._esc(col.title || field);
				var checked = inst.columnVisibility[field] !== false;
				var disabled = col.hideable === false;
				html +=
					'<label class="dt-columns-item' + (disabled ? " is-locked" : "") + '">' +
					'<input type="checkbox" data-field="' + Common.DataTable._esc(field) + '"' +
					(checked ? " checked" : "") + (disabled ? " disabled" : "") + "> " +
					"<span>" + title + "</span>" +
					(disabled ? '<em class="dt-columns-lock">Required</em>' : "") +
					"</label>";
			}
			$popup.find("#dt_columns_popup_body").html(html);
			$popup.removeClass("d-none").attr("aria-hidden", "false");
			$("body").addClass("dt-columns-popup-open");
		},

		_closeColumnsPopup: function () {
			$("#dt_columns_popup").addClass("d-none").attr("aria-hidden", "true");
			$("body").removeClass("dt-columns-popup-open");
			Common.DataTable._columnsPopupInst = null;
		},

		_resetColumnsPopupDraft: function () {
			var inst = Common.DataTable._columnsPopupInst;
			if (!inst) return;
			var $body = $("#dt_columns_popup_body");
			$body.find('input[type="checkbox"]').each(function () {
				var field = String($(this).attr("data-field") || "");
				var col = Common.DataTable._columnByField(inst, field);
				if (!col || col.hideable === false) {
					this.checked = true;
					return;
				}
				this.checked = Common.DataTable._defaultVisible(col);
			});
		},

		_applyColumnsPopup: function () {
			var inst = Common.DataTable._columnsPopupInst;
			if (!inst) return;
			var next = {};
			var anyVisible = false;
			$("#dt_columns_popup_body").find('input[type="checkbox"]').each(function () {
				var field = String($(this).attr("data-field") || "");
				if (!field) return;
				var col = Common.DataTable._columnByField(inst, field);
				if (col && col.hideable === false) {
					next[field] = true;
					anyVisible = true;
					return;
				}
				next[field] = !!this.checked;
				if (this.checked) anyVisible = true;
			});
			if (!anyVisible) {
				var first = inst.columnOrder[0];
				if (first) next[first] = true;
			}
			inst.columnVisibility = next;
			Common.DataTable._closeColumnsPopup();
			Common.DataTable._render(inst);
		},

		_bindColumnDrag: function (inst, thead) {
			if (!inst.columnDragEnabled || inst._columnDragBound) return;
			inst._columnDragBound = true;
			var dragField = null;
			$(thead)
				.on("dragstart", ".dt-col-drag", function (event) {
					dragField = String($(this).attr("data-field") || "");
					var oe = event.originalEvent || event;
					if (oe.dataTransfer) {
						oe.dataTransfer.effectAllowed = "move";
						try { oe.dataTransfer.setData("text/plain", dragField); } catch (ignore) { /* IE */ }
					}
					$(this).closest("th").addClass("dt-col-dragging");
				})
				.on("dragend", ".dt-col-drag", function () {
					dragField = null;
					$(thead).find("th").removeClass("dt-col-dragging dt-col-drop-target");
				})
				.on("dragover", "th[data-field]", function (event) {
					var field = String($(this).attr("data-field") || "");
					var col = Common.DataTable._columnByField(inst, field);
					if (!dragField || !Common.DataTable._isReorderable(inst, col)) return;
					event.preventDefault();
					$(thead).find("th").removeClass("dt-col-drop-target");
					$(this).addClass("dt-col-drop-target");
				})
				.on("dragleave", "th[data-field]", function () {
					$(this).removeClass("dt-col-drop-target");
				})
				.on("drop", "th[data-field]", function (event) {
					event.preventDefault();
					var targetField = String($(this).attr("data-field") || "");
					var from = dragField;
					dragField = null;
					$(thead).find("th").removeClass("dt-col-dragging dt-col-drop-target");
					Common.DataTable._moveColumnBefore(inst, from, targetField);
				});
		},
		_get: function (rootId) {
			return Common.DataTable._instances[Common.DataTable._id(rootId)] || null;
		},

		init: function (opts) {
			opts = opts || {};
			Common.DataTable._ensureCss();
			var rootId = Common.DataTable._id(opts.rootId);
			if (!rootId) {
				return null;
			}
			var previous = Common.DataTable._instances[rootId];
			if (previous) {
				if (previous._serverTimer) {
					clearTimeout(previous._serverTimer);
				}
				if (previous._serverHandle && typeof previous._serverHandle.abort === "function") {
					try { previous._serverHandle.abort(); } catch (eAbort) { /* ignore */ }
				}
			}
			var columns = Array.isArray(opts.columns) ? opts.columns : [];
			var filterType = String(opts.filter_type || opts.filterType || "minimal").trim().toLowerCase();
			filterType = filterType === "full" ? "full" : "minimal";
			var inst = {
				rootId: rootId,
				tableId: Common.DataTable._id(opts.tableId),
				tbodyId: Common.DataTable._id(opts.tbodyId),
				infoId: Common.DataTable._id(opts.infoId),
				pagerId: Common.DataTable._id(opts.pagerId),
				searchId: filterType === "full" ? "" : Common.DataTable._id(opts.searchId),
				pageSizeId: Common.DataTable._id(opts.pageSizeId),
				pageSizes: Array.isArray(opts.pageSizes) && opts.pageSizes.length
					? opts.pageSizes.map(function (n) { return Number(n); }).filter(function (n) { return n > 0; })
					: [10, 25, 50, 100],
				pageSize: opts.pageSize > 0 ? Number(opts.pageSize) : 10,
				filterType: filterType,
				columnFilters: {},
				filtersVisible: true,
				columnWidths: [],
				fillWidth: opts.fillWidth === true,
				cellBorder: (String(opts.cellBorder || "row").toLowerCase() === "full") ? "full" : "row",
				maxHeight: opts.maxHeight != null && String(opts.maxHeight).trim() !== ""
					? String(opts.maxHeight).trim()
					: "min(60vh, 560px)",
				columns: columns,
				emptyMessage: opts.emptyMessage || "No data found",
				rows: Array.isArray(opts.rows) ? opts.rows.slice() : [],
				serverSide: opts.serverSide === true,
				loadData: typeof opts.loadData === "function" ? opts.loadData : null,
				onServerError: typeof opts.onServerError === "function" ? opts.onServerError : null,
				searchDelay: opts.searchDelay >= 0 ? Number(opts.searchDelay) : 300,
				totalRecords: 0,
				page: 1,
				sortField: opts.sortField ? String(opts.sortField) : null,
				sortDir: String(opts.sortDir || "asc").toLowerCase() === "desc" ? "desc" : "asc",
				_serverSequence: 0,
				_serverHandle: null,
				_serverTimer: null,
				_searchBound: false,
				_pageSizeBound: false,
				_headerBound: false,
				_columnFilterBound: false,
				_columnResizeBound: false,
				columnHideEnabled: opts.columnHideEnabled === true,
				columnDragEnabled: opts.columnDragEnabled === true,
				onRefresh: typeof opts.onRefresh === "function" ? opts.onRefresh : null,
				columnOrder: [],
				columnVisibility: {},
				_columnDragBound: false
			};
			if (inst.pageSizes.indexOf(inst.pageSize) < 0) {
				inst.pageSizes = [inst.pageSize].concat(inst.pageSizes);
			}
			Common.DataTable._instances[rootId] = inst;
			Common.DataTable._initLayout(inst);
			Common.DataTable._ensureChrome(inst, opts);
			Common.DataTable._ensureToolbarTools(inst);
			var $table = inst.tableId ? $("#" + inst.tableId) : $();
			if ($table.length) {
				$table.addClass("dt-table");
				$table.removeClass("dt-border-row dt-border-full");
				$table.addClass(inst.cellBorder === "full" ? "dt-border-full" : "dt-border-row");
				var $wrap = $table.closest(".dt-table-wrap, .cu-table-wrap");
				if (!$wrap.length) {
					$table.wrap('<div class="dt-table-wrap"></div>');
					$wrap = $table.parent();
				} else {
					$wrap.addClass("dt-table-wrap");
				}
				inst._$wrap = $wrap;
				inst.stickyHeader = opts.stickyHeader !== false;
				if (inst.stickyHeader) {
					$table.addClass("dt-sticky-head");
					$wrap.addClass("dt-sticky-wrap");
				}
				Common.DataTable._applyScrollBox(inst);
			}
			if (inst.pagerId) {
				$("#" + inst.pagerId).addClass("dt-pager");
			}
			Common.DataTable._buildHeader(inst);
			Common.DataTable._bindSearch(inst);
			Common.DataTable._bindPageSize(inst);
			Common.DataTable._render(inst);
			Common.DataTable._applyScrollBox(inst);
			setTimeout(function () { Common.DataTable._applyScrollBox(inst); }, 0);
			return inst;
		},

		setData: function (rootId, rows) {
			var inst = Common.DataTable._get(rootId);
			if (!inst) {
				return;
			}
			inst.rows = Array.isArray(rows) ? rows.slice() : [];
			inst.page = 1;
			Common.DataTable._render(inst);
			Common.DataTable._applyScrollBox(inst);
			setTimeout(function () { Common.DataTable._applyScrollBox(inst); }, 0);
		},

		/**
		 * Reload an opt-in server-side table. Existing client-side tables are
		 * unaffected and continue using setData().
		 */
		refresh: function (rootId) {
			var inst = Common.DataTable._get(rootId);
			if (!inst || typeof inst.onRefresh !== "function") {
				return;
			}
			inst.onRefresh(inst);
		},

		reload: function (rootId, resetPage) {
			var inst = Common.DataTable._get(rootId);
			if (!inst || !inst.serverSide) {
				return;
			}
			if (resetPage === true) {
				inst.page = 1;
			}
			Common.DataTable._loadServer(inst);
		},

		_serverRequest: function (inst) {
			var globalFilter = "";
			if (inst.searchId) {
				globalFilter = String($("#" + inst.searchId).val() || "").trim();
			}
			var filters = {};
			var source = inst.columnFilters || {};
			for (var field in source) {
				if (Object.prototype.hasOwnProperty.call(source, field)) {
					var value = String(source[field] || "").trim();
					if (value) {
						filters[field] = value;
					}
				}
			}
			return {
				page: inst.page,
				pageSize: inst.pageSize,
				sortField: inst.sortField || "",
				sortDir: inst.sortDir || "asc",
				globalFilter: globalFilter,
				columnFilters: filters
			};
		},

		_scheduleServerLoad: function (inst) {
			if (inst._serverTimer) {
				clearTimeout(inst._serverTimer);
			}
			if (inst._serverHandle && typeof inst._serverHandle.abort === "function") {
				try { inst._serverHandle.abort(); } catch (eAbort) { /* ignore */ }
				inst._serverHandle = null;
				inst._serverSequence++;
			}
			inst._serverTimer = setTimeout(function () {
				inst._serverTimer = null;
				Common.DataTable._loadServer(inst);
			}, inst.searchDelay);
		},

		_loadServer: function (inst) {
			if (!inst || !inst.serverSide || typeof inst.loadData !== "function") {
				return;
			}
			if (inst._serverTimer) {
				clearTimeout(inst._serverTimer);
				inst._serverTimer = null;
			}
			if (inst._serverHandle && typeof inst._serverHandle.abort === "function") {
				try { inst._serverHandle.abort(); } catch (eAbort) { /* ignore */ }
			}
			var sequence = ++inst._serverSequence;
			var handle;
			try {
				handle = inst.loadData(Common.DataTable._serverRequest(inst));
			} catch (error) {
				if (inst.onServerError) {
					inst.onServerError(error);
				}
				return;
			}
			inst._serverHandle = handle;
			$.when(handle)
				.done(function (response) {
					if (sequence !== inst._serverSequence) {
						return;
					}
					response = response || {};
					inst.rows = Array.isArray(response.rows) ? response.rows.slice() : [];
					inst.totalRecords = Math.max(0, Number(response.totalRecords) || 0);
					if (Number(response.page) > 0) {
						inst.page = Number(response.page);
					}
					if (Number(response.pageSize) > 0) {
						inst.pageSize = Number(response.pageSize);
					}
					Common.DataTable._render(inst);
					Common.DataTable._applyScrollBox(inst);
				})
				.fail(function (xhr, status, error) {
					if (sequence !== inst._serverSequence || status === "abort") {
						return;
					}
					if (inst.onServerError) {
						inst.onServerError(error || xhr);
					}
				})
				.always(function () {
					if (sequence === inst._serverSequence) {
						inst._serverHandle = null;
					}
				});
		},

		/** Show/hide the active filter UI for a table. */
		toggleFilters: function (rootId) {
			var inst = Common.DataTable._get(rootId);
			if (!inst) {
				return;
			}
			if (inst.filterType === "full") {
				inst.filtersVisible = !inst.filtersVisible;
				$("#" + inst.tableId + " thead .dt-column-filters").toggleClass("d-none", !inst.filtersVisible);
			} else {
				$("#" + inst.rootId + " > .dt-toolbar").toggleClass("d-none");
			}
		},


		/**
		 * Build toolbar / footer DOM when missing.
		 * Page HTML only needs root + table (+ tbody). Pass searchId/pageSizeId/infoId/pagerId
		 * (or leave chrome:true defaults) and missing nodes are created under rootId.
		 * Set chrome: false to skip auto UI (table only).
		 */
		_ensureChrome: function (inst, opts) {
			opts = opts || {};
			if (opts.chrome === false) {
				return;
			}
			var $root = $("#" + inst.rootId);
			if (!$root.length) {
				return;
			}

			// Default control ids from root when chrome is on and id omitted
			var prefix = inst.rootId;
			if (inst.filterType !== "full" && !inst.searchId && opts.search !== false) {
				inst.searchId = prefix + "_search";
			}
			if (!inst.pageSizeId && opts.pageSizeControl !== false) {
				inst.pageSizeId = prefix + "_page_size";
			}
			if (!inst.infoId && opts.info !== false) {
				inst.infoId = prefix + "_info";
			}
			if (!inst.pagerId && opts.pager !== false) {
				inst.pagerId = prefix + "_pager";
			}

			var needToolbar = false;
			var needPageSize = !!(inst.pageSizeId && !$("#" + inst.pageSizeId).length);
			var needSearch = !!(inst.searchId && !$("#" + inst.searchId).length);
			needToolbar = needPageSize || needSearch;

			if (needToolbar) {
				var $tb = $root.children(".dt-toolbar").first();
				if (!$tb.length) {
					$tb = $('<div class="dt-toolbar"></div>');
					var $wrap0 = $root.find(".dt-table-wrap, .cu-table-wrap").first();
					if ($wrap0.length) {
						$wrap0.before($tb);
					} else if (inst.tableId && $("#" + inst.tableId).length) {
						$("#" + inst.tableId).before($tb);
					} else {
						$root.append($tb);
					}
				}
				if (needPageSize) {
					var sizesHtml = "";
					for (var i = 0; i < inst.pageSizes.length; i++) {
						var n = inst.pageSizes[i];
						sizesHtml += '<option value="' + n + '"' + (n === inst.pageSize ? " selected" : "") + ">" + n + "</option>";
					}
					$tb.append(
						$('<label class="dt-pagesize">Show </label>').append(
							$("<select></select>")
								.attr({ id: inst.pageSizeId, "aria-label": "Rows per page" })
								.html(sizesHtml)
						).append(document.createTextNode(" entries"))
					);
				}
				if (needSearch) {
					var ph = opts.searchPlaceholder != null ? String(opts.searchPlaceholder) : "Searchâ€¦";
					$tb.append(
						$('<label class="dt-search">Search: </label>').append(
							$('<input type="search" autocomplete="off" />').attr({
								id: inst.searchId,
								placeholder: ph
							})
						)
					);
				}
			}

			var needInfo = !!(inst.infoId && !$("#" + inst.infoId).length);
			var needPager = !!(inst.pagerId && !$("#" + inst.pagerId).length);
			if (needInfo || needPager) {
				var $foot = $root.children(".dt-foot").first();
				if (!$foot.length) {
					$foot = $('<div class="dt-foot"></div>');
					var $legal = $root.children(".cu-legal").first();
					var $wrap1 = $root.find(".dt-table-wrap, .cu-table-wrap").first();
					if ($legal.length) {
						$legal.before($foot);
					} else if ($wrap1.length) {
						$wrap1.after($foot);
					} else {
						$root.append($foot);
					}
				}
				if (needInfo) {
					$foot.append($("<div></div>").attr("id", inst.infoId).text("Showing 0 entries"));
				}
				if (needPager) {
					$foot.append($("<div class=\"dt-pager\"></div>").attr("id", inst.pagerId));
				}
			}
		},


		/**
		 * Resolve maxHeight option to a pixel number for reliable inline style.
		 * Supports: number, "400px", "50vh", "min(60vh, 560px)".
		 */
		_resolveMaxHeightPx: function (raw) {
			var s = String(raw == null ? "" : raw).trim();
			if (!s) {
				s = "min(60vh, 560px)";
			}
			var vh = (typeof window !== "undefined" && window.innerHeight) ? window.innerHeight : 800;
			var minM = s.match(/^min\(\s*([0-9.]+)vh\s*,\s*([0-9.]+)px\s*\)$/i);
			if (minM) {
				return Math.max(120, Math.round(Math.min(vh * (parseFloat(minM[1]) / 100), parseFloat(minM[2]))));
			}
			var maxM = s.match(/^max\(\s*([0-9.]+)vh\s*,\s*([0-9.]+)px\s*\)$/i);
			if (maxM) {
				return Math.max(120, Math.round(Math.max(vh * (parseFloat(maxM[1]) / 100), parseFloat(maxM[2]))));
			}
			var vhM = s.match(/^([0-9.]+)vh$/i);
			if (vhM) {
				return Math.max(120, Math.round(vh * (parseFloat(vhM[1]) / 100)));
			}
			var pxM = s.match(/^([0-9.]+)px$/i);
			if (pxM) {
				return Math.max(120, Math.round(parseFloat(pxM[1])));
			}
			var num = parseFloat(s);
			if (!isNaN(num) && num > 0) {
				return Math.max(120, Math.round(num));
			}
			return Math.max(120, Math.round(Math.min(vh * 0.6, 560)));
		},

		_applyScrollBox: function (inst) {
			if (!inst || !inst.tableId) {
				return;
			}
			var $t = $("#" + inst.tableId);
			if (!$t.length) {
				return;
			}
			// Always re-query live DOM (page HTML is swapped on menu navigation)
			var $wrap = $t.closest(".dt-table-wrap, .cu-table-wrap");
			if (!$wrap.length) {
				$t.wrap('<div class="dt-table-wrap dt-sticky-wrap"></div>');
				$wrap = $t.parent();
			}
			inst._$wrap = $wrap;
			$wrap.addClass("dt-table-wrap");
			$t.addClass("dt-table");

			var el = $wrap.get(0);
			if (!el) {
				return;
			}
			var px = Common.DataTable._resolveMaxHeightPx(inst.maxHeight || "420px");
			// Hard clip: fixed height + both overflows. Width 100% so table min-width triggers H-scroll.
			el.setAttribute(
				"style",
				"display:block!important;width:100%!important;max-width:100%!important;min-width:0!important;" +
					"box-sizing:border-box!important;height:" +
					px +
					"px!important;max-height:" +
					px +
					"px!important;overflow-x:auto!important;overflow-y:auto!important;-webkit-overflow-scrolling:touch!important;"
			);
			if (inst.stickyHeader !== false) {
				$wrap.addClass("dt-sticky-wrap");
				$t.addClass("dt-sticky-head");
			}
			var $root = inst.rootId ? $("#" + inst.rootId) : $();
			if ($root.length) {
				$root.get(0).style.setProperty("min-width", "0", "important");
				$root.get(0).style.setProperty("max-width", "100%", "important");
			}
		},

		_cssHref: "css/common_table.css",
		_cssLoaded: false,

		/** Ensure shared DataTable stylesheet is on the page (idempotent). */
		_ensureCss: function () {
			if (Common.DataTable._cssLoaded) {
				Common.DataTable._injectScrollForceStyle();
				return;
			}
			if (document.getElementById("common-table-css")) {
				Common.DataTable._cssLoaded = true;
				Common.DataTable._injectScrollForceStyle();
				return;
			}
			// Same relative root as MainPage.css links (css/...).
			var href = Common.DataTable._cssHref + "?v=202610041320";
			var link = document.createElement("link");
			link.id = "common-table-css";
			link.rel = "stylesheet";
			link.href = href;
			(document.head || document.getElementsByTagName("head")[0]).appendChild(link);
			Common.DataTable._cssLoaded = true;
			Common.DataTable._injectScrollForceStyle();
		},

		_injectScrollForceStyle: function () {
			var existing = document.getElementById("common-table-scroll-force");
			if (existing) {
				existing.parentNode.removeChild(existing);
			}
			var s = document.createElement("style");
			s.id = "common-table-scroll-force";
			s.type = "text/css";
			s.appendChild(document.createTextNode('.dt-table-wrap,.dt-table-wrap.dt-sticky-wrap{display:block!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;height:420px!important;max-height:420px!important;overflow-x:auto!important;overflow-y:auto!important;-webkit-overflow-scrolling:touch!important;scrollbar-gutter:stable;scrollbar-width:thin!important;}.dt-table-wrap::-webkit-scrollbar,.dt-table-wrap.dt-sticky-wrap::-webkit-scrollbar{width:6px!important;height:6px!important;display:block!important;background:transparent!important;}.dt-table-wrap::-webkit-scrollbar-track,.dt-table-wrap.dt-sticky-wrap::-webkit-scrollbar-track{background:transparent!important;}.dt-table-wrap::-webkit-scrollbar-thumb,.dt-table-wrap.dt-sticky-wrap::-webkit-scrollbar-thumb{background:rgba(100,116,139,.55)!important;border-radius:999px!important;border:none!important;min-height:24px!important;}.dt-table-wrap::-webkit-scrollbar-thumb:hover,.dt-table-wrap.dt-sticky-wrap::-webkit-scrollbar-thumb:hover{background:rgba(71,85,105,.85)!important;}.dt-table,#m_contact_us .dt-table{width:max-content!important;min-width:100%!important;}'));
			(document.head || document.getElementsByTagName("head")[0]).appendChild(s);
		},

		_sortIconHtml: function (inst, field) {
			var active = inst.sortField && inst.sortField === field;
			if (active) {
				/* HTML entities — avoid raw Unicode (file encoding breaks arrows into â–² etc.) */
				var mark = inst.sortDir === "desc" ? "&#9660;" : "&#9650;";
				return (
					"<span class=\"dt-sort-ico dt-sort-active\" aria-hidden=\"true\">" +
					mark +
					"</span>"
				);
			}
			return "<span class=\"dt-sort-ico\" aria-hidden=\"true\">&#8645;</span>";
		},

		_syncStickyOffsets: function (inst) {
			if (!inst || inst.stickyHeader === false || !inst.tableId) {
				return;
			}
			var apply = function () {
				var table = document.getElementById(inst.tableId);
				if (!table) {
					return;
				}
				var title = table.querySelector("thead tr:first-child");
				var filters = table.querySelector("thead .dt-column-filters");
				if (!title || !filters) {
					return;
				}
				var height = Math.ceil(title.getBoundingClientRect().height);
				if (height <= 0) {
					return;
				}
				var cells = filters.querySelectorAll("th");
				for (var i = 0; i < cells.length; i++) {
					cells[i].style.top = height + "px";
				}
			};
			if (typeof window.requestAnimationFrame === "function") {
				window.requestAnimationFrame(apply);
			} else {
				apply();
			}
		},

		_buildHeader: function (inst) {
			if (!inst.tableId || !inst.columns.length) {
				return;
			}
			var table = document.getElementById(inst.tableId);
			if (!table) {
				return;
			}
			var thead = table.querySelector("thead");
			if (!thead) {
				thead = document.createElement("thead");
				table.insertBefore(thead, table.firstChild);
			}
			Common.DataTable._ensureColumnWidths(inst);
			var paint = Common.DataTable._paintColumns(inst);
			var html = "<tr>";
			for (var i = 0; i < paint.length; i++) {
				var col = paint[i] || {};
				var sortable = col.sortable !== false;
				var field = Common.DataTable._fieldKey(col);
				var srcIndex = Common.DataTable._sourceIndex(inst, field);
				var title = Common.DataTable._esc(col.title || field);
				var dragHandle = Common.DataTable._isReorderable(inst, col)
					? '<span class="dt-col-drag" draggable="true" data-field="' +
						Common.DataTable._esc(field) +
						'" title="Drag to reorder" aria-hidden="true">&#8942;</span>'
					: "";
				var resizeHandle =
					'<span class="dt-col-resizer" data-col-index="' +
					srcIndex +
					'" title="Drag to resize column" aria-hidden="true"></span>';
				if (sortable && field) {
					var ariaSort = "none";
					if (inst.sortField === field) {
						ariaSort = inst.sortDir === "desc" ? "descending" : "ascending";
					}
					html +=
						'<th data-col-index="' +
						srcIndex +
						'" data-field="' +
						Common.DataTable._esc(field) +
						'" data-sortable="1" aria-sort="' +
						ariaSort +
						'" title="Sort"' +
						Common.DataTable._alignAttr(col) +
						">" +
						dragHandle +
						'<span class="dt-sort-label">' +
						title +
						"</span>" +
						Common.DataTable._sortIconHtml(inst, field) +
						resizeHandle +
						"</th>";
				} else {
					html +=
						'<th data-col-index="' +
						srcIndex +
						'" data-field="' +
						Common.DataTable._esc(field) +
						'"' +
						Common.DataTable._alignAttr(col) +
						">" +
						dragHandle +
						title +
						resizeHandle +
						"</th>";
				}
			}
			html += "</tr>";
			if (inst.filterType === "full") {
				html += '<tr class="dt-column-filters' + (inst.filtersVisible ? "" : " d-none") + '">';
				for (var j = 0; j < paint.length; j++) {
					var filterCol = paint[j] || {};
					var filterField = Common.DataTable._fieldKey(filterCol);
					var filterSrc = Common.DataTable._sourceIndex(inst, filterField);
					html += '<th data-col-index="' + filterSrc + '" data-field="' + Common.DataTable._esc(filterField) + '"' + Common.DataTable._alignAttr(filterCol) + ">";
					if (filterField && filterCol.searchable !== false) {
						var filterTitle = String(filterCol.title || filterField);
						html +=
							'<input type="search" class="dt-column-filter" autocomplete="off" data-field="' +
							Common.DataTable._esc(filterField) +
							'" aria-label="Filter ' +
							Common.DataTable._esc(filterTitle) +
							'" placeholder="Filter..." value="' +
							Common.DataTable._esc(inst.columnFilters[filterField] || "") +
							'">';
					}
					html += "</th>";
				}
				html += "</tr>";
			}
			thead.innerHTML = html;
			Common.DataTable._applyColumnWidths(inst);
			Common.DataTable._syncStickyOffsets(inst);
			Common.DataTable._bindColumnDrag(inst, thead);

			if (!inst._headerBound) {
				inst._headerBound = true;
				$(thead).on("click", "th[data-sortable]", function (event) {
					if ($(event.target).closest(".dt-col-resizer, .dt-col-drag").length) {
						return;
					}
					var field = $(this).attr("data-field");
					if (!field) {
						return;
					}
					if (inst.sortField === field) {
						inst.sortDir = inst.sortDir === "asc" ? "desc" : "asc";
					} else {
						inst.sortField = field;
						inst.sortDir = "asc";
					}
					inst.page = 1;
					if (inst.serverSide) {
						Common.DataTable._loadServer(inst);
					} else {
						Common.DataTable._render(inst);
					}
				});
			}
			if (!inst._columnFilterBound) {
				inst._columnFilterBound = true;
				$(thead).on("input", ".dt-column-filter", function () {
					var field = String($(this).attr("data-field") || "");
					if (!field) {
						return;
					}
					inst.columnFilters[field] = String($(this).val() || "");
					inst.page = 1;
					if (inst.serverSide) {
						Common.DataTable._scheduleServerLoad(inst);
					} else {
						// Keep the live inputs in place so focus is not lost while typing.
						Common.DataTable._render(inst, true);
					}
				});
			}
			if (!inst._columnResizeBound) {
				inst._columnResizeBound = true;
				$(thead)
					.on("click", ".dt-col-resizer", function (event) {
						event.preventDefault();
						event.stopPropagation();
					})
					.on("mousedown", ".dt-col-resizer", function (event) {
						event.preventDefault();
						event.stopPropagation();
						var index = parseInt($(this).attr("data-col-index"), 10);
						if (isNaN(index) || !inst.columns[index]) {
							return;
						}
						var startX = event.clientX;
						var startWidth = inst.columnWidths[index];
						var limits = Common.DataTable._columnLimits(inst.columns[index]);
						$("body").addClass("dt-column-resizing");
						$(document)
							.off(".dtColumnResize")
							.on("mousemove.dtColumnResize", function (moveEvent) {
								moveEvent.preventDefault();
								var nextWidth = startWidth + (moveEvent.clientX - startX);
								inst.columnWidths[index] = Math.max(limits.min, Math.min(limits.max, nextWidth));
								Common.DataTable._applyColumnWidths(inst);
							})
							.on("mouseup.dtColumnResize", function () {
								$(document).off(".dtColumnResize");
								$("body").removeClass("dt-column-resizing");
							});
					});
			}
		},

		_bindSearch: function (inst) {
			if (!inst.searchId || inst._searchBound) {
				return;
			}
			var $search = $("#" + inst.searchId);
			if (!$search.length) {
				return;
			}
			inst._searchBound = true;
			$search.on("input", function () {
				inst.page = 1;
				if (inst.serverSide) {
					Common.DataTable._scheduleServerLoad(inst);
				} else {
					Common.DataTable._render(inst);
				}
			});
		},

		_bindPageSize: function (inst) {
			if (!inst.pageSizeId) {
				return;
			}
			var $sel = $("#" + inst.pageSizeId);
			if (!$sel.length) {
				return;
			}
			// Fill options once (or refresh if empty)
			if (!$sel.children("option").length) {
				var optsHtml = "";
				for (var i = 0; i < inst.pageSizes.length; i++) {
					var n = inst.pageSizes[i];
					optsHtml += "<option value=\"" + n + "\">" + n + "</option>";
				}
				$sel.html(optsHtml);
			}
			$sel.val(String(inst.pageSize));
			if (inst._pageSizeBound) {
				return;
			}
			inst._pageSizeBound = true;
			$sel.on("change", function () {
				var n = parseInt($sel.val(), 10);
				if (!n || n < 1) {
					n = inst.pageSizes[0] || 10;
				}
				inst.pageSize = n;
				inst.page = 1;
				if (inst.serverSide) {
					Common.DataTable._loadServer(inst);
				} else {
					Common.DataTable._render(inst);
				}
			});
		},

		_cellValue: function (row, field) {
			if (!row || !field) {
				return "";
			}
			var v = row[field];
			return v == null ? "" : v;
		},

		_filtered: function (inst) {
			var rows = inst.rows || [];
			var cols = Common.DataTable._paintColumns(inst);
			if (inst.filterType === "full") {
				var filters = inst.columnFilters || {};
				return rows.filter(function (r) {
					for (var i = 0; i < cols.length; i++) {
						var col = cols[i] || {};
						var field = String(col.field || "");
						if (!field || col.searchable === false) {
							continue;
						}
						var filterValue = String(filters[field] || "").toLowerCase().trim();
						if (
							filterValue &&
							String(Common.DataTable._cellValue(r, field)).toLowerCase().indexOf(filterValue) < 0
						) {
							return false;
						}
					}
					return true;
				});
			}
			var q = "";
			if (inst.searchId) {
				q = String($("#" + inst.searchId).val() || "").toLowerCase().trim();
			}
			if (!q) {
				return rows.slice();
			}
			return rows.filter(function (r) {
				for (var i = 0; i < cols.length; i++) {
					var col = cols[i] || {};
					if (col.searchable === false) {
						continue;
					}
					var v = Common.DataTable._cellValue(r, col.field);
					if (String(v).toLowerCase().indexOf(q) >= 0) {
						return true;
					}
				}
				return false;
			});
		},

		_sorted: function (inst, rows) {
			if (!inst.sortField) {
				return rows;
			}
			var field = inst.sortField;
			var dir = inst.sortDir === "desc" ? -1 : 1;
			return rows.slice().sort(function (a, b) {
				var av = Common.DataTable._cellValue(a, field);
				var bv = Common.DataTable._cellValue(b, field);
				var an = Number(av);
				var bn = Number(bv);
				var cmp;
				if (av !== "" && bv !== "" && !isNaN(an) && !isNaN(bn)) {
					cmp = an < bn ? -1 : an > bn ? 1 : 0;
				} else {
					av = String(av).toLowerCase();
					bv = String(bv).toLowerCase();
					cmp = av < bv ? -1 : av > bv ? 1 : 0;
				}
				return cmp * dir;
			});
		},

		_highlightText: function (value, searchTerm) {
			var text = String(value == null ? "" : value);
			var term = String(searchTerm || "");
			if (!term) {
				return Common.DataTable._esc(text);
			}
			var escapedTerm = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
			var matcher = new RegExp(escapedTerm, "gi");
			var html = "";
			var lastIndex = 0;
			var match;
			while ((match = matcher.exec(text)) !== null) {
				html += Common.DataTable._esc(text.slice(lastIndex, match.index));
				html += '<mark class="dt-search-highlight">' + Common.DataTable._esc(match[0]) + "</mark>";
				lastIndex = matcher.lastIndex;
			}
			return html + Common.DataTable._esc(text.slice(lastIndex));
		},

		_highlightHtml: function (value, searchTerm) {
			if (!searchTerm) {
				return value == null ? "" : String(value);
			}
			var container = document.createElement("div");
			container.innerHTML = value == null ? "" : String(value);
			var walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null, false);
			var textNodes = [];
			var node;
			while ((node = walker.nextNode())) {
				textNodes.push(node);
			}
			for (var i = 0; i < textNodes.length; i++) {
				var textNode = textNodes[i];
				var highlighted = document.createElement("span");
				highlighted.innerHTML = Common.DataTable._highlightText(textNode.nodeValue, searchTerm);
				textNode.parentNode.replaceChild(highlighted, textNode);
				while (highlighted.firstChild) {
					highlighted.parentNode.insertBefore(highlighted.firstChild, highlighted);
				}
				highlighted.parentNode.removeChild(highlighted);
			}
			return container.innerHTML;
		},

		_formatCell: function (col, value, searchTerm) {
			var type = col && col.type ? String(col.type) : "text";
			if (type === "html") {
				return Common.DataTable._highlightHtml(value, searchTerm);
			}
			if (type === "email") {
				var email = String(value == null ? "" : value).trim();
				if (!email) {
					return "";
				}
				var safe = Common.DataTable._esc(email);
				return "<a href=\"mailto:" + safe + "\">" +
					Common.DataTable._highlightText(email, searchTerm) + "</a>";
			}
			return Common.DataTable._highlightText(value, searchTerm);
		},

		_render: function (inst, keepHeader) {
			if (!keepHeader) {
				Common.DataTable._buildHeader(inst);
			}
			var pageSize = inst.pageSize || 10;
			var data = inst.serverSide
				? (inst.rows || []).slice()
				: Common.DataTable._sorted(inst, Common.DataTable._filtered(inst));
			var totalEntries = inst.serverSide ? (Number(inst.totalRecords) || 0) : data.length;
			var pages = Math.max(1, Math.ceil(totalEntries / pageSize) || 1);
			if (inst.page > pages) {
				inst.page = pages;
			}
			if (inst.page < 1) {
				inst.page = 1;
			}
			var start = (inst.page - 1) * pageSize;
			var slice = inst.serverSide ? data : data.slice(start, start + pageSize);
			var searchTerm = "";
			if (inst.filterType === "minimal" && inst.searchId) {
				searchTerm = String($("#" + inst.searchId).val() || "").trim();
			}
			/* Same visibility + order as the header (hide / drag). */
			var cols = Common.DataTable._paintColumns(inst);
			var tb = inst.tbodyId ? document.getElementById(inst.tbodyId) : null;
			if (tb) {
				if (!slice.length) {
					tb.innerHTML =
						"<tr><td colspan=\"" +
						Math.max(1, cols.length) +
						"\" style=\"text-align:center;color:#64748b\">" +
						Common.DataTable._esc(inst.emptyMessage) +
						"</td></tr>";
				} else {
					var html = "";
					for (var r = 0; r < slice.length; r++) {
						var row = slice[r] || {};
						html += "<tr>";
						for (var c = 0; c < cols.length; c++) {
							var col = cols[c] || {};
							html +=
								"<td" +
								Common.DataTable._alignAttr(col) +
								">" +
								Common.DataTable._formatCell(
									col,
									Common.DataTable._cellValue(row, col.field),
									col.searchable === false ? "" : searchTerm
								) +
								"</td>";
						}
						html += "</tr>";
					}
					tb.innerHTML = html;
				}
			}

			var from = totalEntries && slice.length ? start + 1 : 0;
			var to = totalEntries ? Math.min(start + slice.length, totalEntries) : 0;
			var info = inst.infoId ? document.getElementById(inst.infoId) : null;
			if (info) {
				info.textContent = "Showing " + from + " to " + to + " of " + totalEntries + " entries";
			}

			var pager = inst.pagerId ? document.getElementById(inst.pagerId) : null;
			if (!pager) {
				return;
			}
			var phtml = "<button type=\"button\" data-p=\"prev\">Previous</button>";
			var maxButtons = 8;
			var firstButton = 1;
			if (inst.serverSide && pages > maxButtons) {
				firstButton = Math.max(1, Math.min(inst.page - 3, pages - maxButtons + 1));
			}
			var lastButton = Math.min(pages, firstButton + maxButtons - 1);
			for (var i = firstButton; i <= lastButton; i++) {
				phtml +=
					"<button type=\"button\" data-p=\"" +
					i +
					"\"" +
					(i === inst.page ? " class=\"active\"" : "") +
					">" +
					i +
					"</button>";
			}
			phtml += "<button type=\"button\" data-p=\"next\">Next</button>";
			pager.innerHTML = phtml;
			pager.querySelectorAll("button").forEach(function (btn) {
				btn.onclick = function () {
					var v = btn.getAttribute("data-p");
					if (v === "prev") {
						inst.page = Math.max(1, inst.page - 1);
					} else if (v === "next") {
						inst.page = Math.min(pages, inst.page + 1);
					} else {
						inst.page = parseInt(v, 10) || 1;
					}
					if (inst.serverSide) {
						Common.DataTable._loadServer(inst);
					} else {
						Common.DataTable._render(inst);
					}
				};
			});
			Common.DataTable._applyScrollBox(inst);
		}
	};
})(typeof window !== "undefined" ? window : this);

