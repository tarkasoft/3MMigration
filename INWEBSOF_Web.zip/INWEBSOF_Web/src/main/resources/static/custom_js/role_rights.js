/**
 * Role Rights — page module for role permissions and user-role Excel upload.
 * Page: html_files/INPC/ia_role_rights.html
 */
window.RoleRights = {
	HOME: "m_ia_role_rights_home",
	availableRoles: [],
	roleNameChoices: null,
	userRoleTomSelect: null,
	userSearchRequestId: 0,
	assignmentViewRequestId: 0,
	assignmentTableInitialized: false,

	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $home = $pane && $pane.find ? $pane.find("#" + RoleRights.HOME) : $();
				if ($home && $home.length) return $home.first();
			}
		} catch (ignore) {
			// Fall through to the visible page instance.
		}
		var $visible = $("#" + RoleRights.HOME).filter(":visible");
		return $visible.length ? $visible.first() : $("#" + RoleRights.HOME).first();
	},

	_$: function (selector) {
		var $home = RoleRights._$home();
		if (!$home.length) return $(selector);
		if (!selector) return $home;
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	Load: function () {
		RoleRights.GetRoleNamesLov();
		RoleRights.bindMenuGroupAutocomplete();
		RoleRights.bindUserRoleDownloadTomSelect();
		RoleRights.bindUserRoleFilters();
		RoleRights._ensureTomSelectCss();
	},

	_host: function () {
		var host = (typeof window.$host_url !== "undefined" && window.$host_url)
			? window.$host_url
			: (window.host_url || "");
		if (host && host.slice(-1) !== "/") host += "/";
		return host;
	},

	_block: function (message, targetId) {
		if (typeof showLoader === "function") showLoader(message || "Please wait...", targetId || RoleRights.HOME);
		else if (typeof App !== "undefined" && typeof App.blockUI === "function") {
			App.blockUI({ boxed: true, message: message || "Please wait..." });
		}
	},

	_unblock: function (targetId) {
		if (typeof hideLoader === "function") hideLoader(targetId || RoleRights.HOME);
		else if (typeof App !== "undefined" && typeof App.unblockUI === "function") App.unblockUI();
	},

	_isEmpty: function (value) {
		return value === undefined || value === null || String(value).trim() === "";
	},

	bindMenuGroupAutocomplete: function () {
		var $input = RoleRights._$("#menu_group");
		if (!$input.length || typeof $input.autocomplete !== "function") return;
		try {
			if ($input.data("ui-autocomplete")) $input.autocomplete("destroy");
		} catch (ignore) {
			// The widget may not have been initialized yet.
		}
		$input.autocomplete({
			minLength: 1,
			delay: 250,
			appendTo: RoleRights._$home(),
			position: { my: "left top", at: "left bottom", collision: "flip" },
			source: function (request, respond) {
				var requestId = Number($input.data("roleRightsMenuGroupRequestId") || 0) + 1;
				$input.data("roleRightsMenuGroupRequestId", requestId);
				$.ajax({
					type: "GET",
					url: RoleRights._host() + "role_rights/GetMenuGroupNamesLov",
					data: {
						app_type: RoleRights._$("#app_type").val() || "",
						term: request.term
					},
					dataType: "json"
				}).done(function (result) {
					if (requestId !== Number($input.data("roleRightsMenuGroupRequestId"))) {
						respond([]);
						return;
					}
					var code = result && (result.error_code != null ? result.error_code : result.errorCode);
					if (code !== 0 && code !== "0") {
						respond([]);
						return;
					}
					respond($.map(result.data || [], function (row) {
						var name = row.name != null ? row.name : row.NAME;
						return name ? { label: name, value: name } : null;
					}));
				}).fail(function (xhr) {
					if (requestId !== Number($input.data("roleRightsMenuGroupRequestId"))) {
						respond([]);
						return;
					}
					console.error("GetMenuGroupNamesLov failed", xhr && xhr.status);
					respond([]);
				});
			},
			select: function (_event, ui) {
				RoleRights._$("#menu_group").val(ui.item.value);
				return false;
			},
			open: function () {
				$(this).autocomplete("widget").css({ zIndex: 1090, position: "absolute" });
			}
		});
		RoleRights._$("#app_type").off("change.roleRights").on("change.roleRights", function () {
			RoleRights._$("#menu_group").val("");
		});
	},

	_ensureTomSelectCss: function () {
		if (document.getElementById("role_rights_tom_select_css")) return;
		var appRoot = String(window.$app_url || "");
		if (!appRoot) appRoot = window.location.pathname.replace(/[^/]*$/, "");
		if (appRoot.slice(-1) !== "/") appRoot += "/";
		var link = document.createElement("link");
		link.id = "role_rights_tom_select_css";
		link.rel = "stylesheet";
		link.href = appRoot + "nuiassets/libs/tom-select/css/tom-select.default.min.css";
		document.head.appendChild(link);
	},

	_ensureChoicesCss: function () {
		if (document.getElementById("role_rights_choices_css")) return;
		var appRoot = String(window.$app_url || "");
		if (!appRoot) appRoot = window.location.pathname.replace(/[^/]*$/, "");
		if (appRoot.slice(-1) !== "/") appRoot += "/";
		var link = document.createElement("link");
		link.id = "role_rights_choices_css";
		link.rel = "stylesheet";
		link.href = appRoot + "nuiassets/libs/choices.js/public/assets/styles/choices.min.css";
		document.head.appendChild(link);
	},

	bindUserRoleDownloadTomSelect: function () {
		var select = RoleRights._$("#user_role_download_users").get(0);
		if (!select || typeof window.TomSelect !== "function") return;
		if (select.tomselect) {
			select.tomselect.destroy();
		}
		if (RoleRights.userRoleTomSelect) {
			RoleRights.userRoleTomSelect = null;
		}

		RoleRights.userRoleTomSelect = new window.TomSelect(select, {
			valueField: "value",
			labelField: "text",
			searchField: ["text"],
			plugins: {
				remove_button: {
					title: "Remove this user"
				}
			},
			create: false,
			maxOptions: 25,
			maxItems: null,
			loadThrottle: 250,
			shouldLoad: function (query) {
				return query.length >= 2;
			},
			load: function (query, callback) {
				RoleRights.searchUsersForDownload(query, callback);
			},
			onChange: function () {
				RoleRights.loadSelectedRoleAssignments();
			},
			render: {
				option: function (item, escape) {
					return "<div>" + escape(item.text) + "</div>";
				},
				item: function (item, escape) {
					return "<div>" + escape(item.text) + "</div>";
				},
				no_results: function () {
					return "<div class='no-results'>No matching users found</div>";
				}
			}
		});
	},

	bindUserRoleFilters: function () {
		RoleRights._$("#user_role_filter").off("change.roleRights")
			.on("change.roleRights", function () {
				RoleRights.loadSelectedRoleAssignments();
			});
	},

	loadSelectedRoleAssignments: function () {
		var roleCode = RoleRights._$("#user_role_filter").val() || "";
		var $panel = RoleRights._$("#user_role_assignments_panel");
		var requestId = ++RoleRights.assignmentViewRequestId;
		var selectedEnlIds = RoleRights.userRoleTomSelect
			? RoleRights.userRoleTomSelect.getValue()
			: [];
		if (!Array.isArray(selectedEnlIds)) selectedEnlIds = selectedEnlIds ? [selectedEnlIds] : [];
		if (!roleCode && !selectedEnlIds.length) {
			$panel.addClass("d-none");
			return;
		}

		$panel.removeClass("d-none");
		RoleRights._ensureAssignmentTable();
		RoleRights._setAssignmentTableStatus("Loading user-role assignments...");
		$.ajax({
			type: "GET",
			url: RoleRights._host() + "role_rights_upload_dowload/getUserRoleAssignments",
			data: {
				role_code: roleCode,
				enl_ids: selectedEnlIds.join(",")
			},
			dataType: "json"
		}).done(function (result) {
			if (requestId !== RoleRights.assignmentViewRequestId) return;
			if (!result || result.success !== true) {
				RoleRights._setAssignmentTableStatus(
					(result && result.message) || "Could not load user-role assignments."
				);
				return;
			}
			var rows = result.data || [];
			RoleRights._setAssignmentTableStatus("");
			if (window.Common && Common.DataTable) {
				Common.DataTable.setData("user_role_assignments_table_root", $.map(rows, function (row) {
					return {
						enl_id: row.enl_id || row.ENL_ID || "",
						cust_code: row.cust_code || row.CUST_CODE || "",
						cust_name: row.cust_name || row.CUST_NAME || "",
						name: row.name || row.NAME || "",
						role_name: row.role_name || row.ROLE_NAME || "",
						last_login_time: row.last_login_time || row.LAST_LOGIN_TIME || "",
						status: row.status || row.STATUS || ""
					};
				}));
			}
		}).fail(function (xhr) {
			if (requestId !== RoleRights.assignmentViewRequestId) return;
			console.error("getUserRoleAssignments failed", xhr && xhr.status);
			RoleRights._setAssignmentTableStatus("Could not load assigned users. Try selecting the role again.");
		});
	},

	_ensureAssignmentTable: function () {
		if (RoleRights.assignmentTableInitialized || !window.Common || !Common.DataTable) return;
		Common.DataTable.init({
			rootId: "user_role_assignments_table_root",
			tableId: "user_role_assignments_table",
			tbodyId: "user_role_assignments_table_body",
			pageSizes: [10, 25, 50, 100],
			pageSize: 10,
			filter_type: "minimal",
			searchId: "user_role_assignments_search",
			searchPlaceholder: "Search assigned users...",
			pageSizeId: "user_role_assignments_page_size",
			infoId: "user_role_assignments_info",
			pagerId: "user_role_assignments_pager",
			stickyHeader: true,
			fillWidth: true,
			maxHeight: "280px",
			emptyMessage: "No user-role assignments found for the selected filters.",
			columns: [
				{ title: "ENL ID", field: "enl_id", sortable: true, width: 150 },
				{ title: "cust_code", field: "cust_code", sortable: true, width: 150 },
				{ title: "Customer Name", field: "cust_name", sortable: true, width: 220 },
				{ title: "User Name", field: "name", sortable: true, width: 220 },
				{ title: "Role Name", field: "role_name", sortable: true, width: 220 },
				{ title: "Last Login Time", field: "last_login_time", sortable: true, width: 180 },
				{ title: "Status", field: "status", sortable: true, width: 100 }
			],
			rows: []
		});
		RoleRights.assignmentTableInitialized = true;
	},

	_setAssignmentTableStatus: function (message) {
		var $status = RoleRights._$("#user_role_assignments_status");
		var $tableRoot = RoleRights._$("#user_role_assignments_table_root");
		$status.text(message || "").toggleClass("d-none", !message);
		$tableRoot.toggleClass("d-none", !!message);
	},

	searchUsersForDownload: function (term, callback) {
		var tomSelect = RoleRights.userRoleTomSelect;
		if (!tomSelect) {
			callback();
			return;
		}
		var requestId = ++RoleRights.userSearchRequestId;
		$.ajax({
			type: "GET",
			url: RoleRights._host() + "role_rights/GetUsersForRoleDownloadLov",
			data: { term: term },
			dataType: "json"
		}).done(function (result) {
			if (requestId !== RoleRights.userSearchRequestId || tomSelect !== RoleRights.userRoleTomSelect) {
				callback();
				return;
			}
			var code = result && (result.error_code != null ? result.error_code : result.errorCode);
			if (code !== 0 && code !== "0") {
				RoleRights._setUploadModalMessage(
					(result && result.message) || "Could not load matching users.",
					"alert-danger"
				);
				callback();
				return;
			}
			var options = $.map(result.data || [], function (row) {
				var enlId = row.enl_id != null ? row.enl_id : row.ENL_ID;
				var name = row.name != null ? row.name : row.NAME;
				if (!enlId) return null;
				return {
					value: String(enlId),
					text: String(enlId) + " - " + String(name || "")
				};
			});
			callback(options);
		}).fail(function (xhr) {
			if (requestId === RoleRights.userSearchRequestId && tomSelect === RoleRights.userRoleTomSelect) {
				console.error("GetUsersForRoleDownloadLov failed", xhr && xhr.status);
				RoleRights._setUploadModalMessage("Could not load matching users. Try the search again.", "alert-danger");
			}
			callback();
		});
	},

	_fillRoleSelect: function (data) {
		var $select = RoleRights._$("#role_name");
		var $userRoleFilter = RoleRights._$("#user_role_filter");
		if (RoleRights.roleNameChoices) {
			RoleRights.roleNameChoices.destroy();
			RoleRights.roleNameChoices = null;
		}
		RoleRights.availableRoles = [];
		$select.empty().append($("<option></option>").attr("value", "").text("Select Role"));
		$userRoleFilter.empty().append($("<option></option>").attr("value", "").text("Select a role to view its users..."));
		$.each(data || [], function (_index, row) {
			var name = row.name != null ? row.name : row.NAME;
			var value = row.val != null ? row.val : row.VAL;
			if (name == null && row.role_name != null) {
				name = row.role_name;
				value = row.internal_code != null ? row.internal_code : row.val;
			}
			if (name != null && String(name).trim() !== "") {
				RoleRights.availableRoles.push({
					name: String(name).trim(),
					value: value == null ? "" : String(value)
				});
				$userRoleFilter.append($("<option></option>")
					.attr("value", value == null ? "" : String(value))
					.text(String(name).trim()));
			}
			$select.append($("<option></option>").attr("value", value).text(name));
		});
		RoleRights.bindRoleNameChoices();
		RoleRights._renderAvailableRoles();
	},

	bindRoleNameChoices: function () {
		var select = RoleRights._$("#role_name").get(0);
		if (!select || typeof window.Choices !== "function") return;
		RoleRights._ensureChoicesCss();
		RoleRights.roleNameChoices = new window.Choices(select, {
			searchEnabled: true,
			searchChoices: true,
			searchFields: ["label", "value"],
			searchFloor: 0,
			searchResultLimit: 100,
			searchPlaceholderValue: "Type to search roles...",
			shouldSort: false,
			itemSelectText: "",
			position: "bottom",
			allowHTML: false
		});
	},

	_renderAvailableRoles: function () {
		var $body = RoleRights._$("#available_user_roles_table tbody").empty();
		if (!RoleRights.availableRoles.length) {
			$("<tr></tr>").append(
				$("<td></td>").attr("colspan", 2).addClass("text-muted text-center py-3")
					.text("No roles are available.")
			).appendTo($body);
			return;
		}
		$.each(RoleRights.availableRoles, function (index, role) {
			var $row = $("<tr></tr>");
			$("<td></td>").addClass("text-muted").text(index + 1).appendTo($row);
			$("<td></td>").text(role.name).appendTo($row);
			$body.append($row);
		});
	},

	GetRoleNamesLov: function () {
		$.ajax({
			type: "GET",
			url: RoleRights._host() + "role_rights/GetRoleNamesLov",
			dataType: "json"
		}).done(function (response) {
			var code = response && (response.error_code != null ? response.error_code : response.errorCode);
			if (code === 0 || code === "0") RoleRights._fillRoleSelect(response.data);
			else RoleRights._showMessage("error", "Unable to load roles", (response && response.message) || "The role list could not be loaded.");
		}).fail(function (xhr) {
			console.error("GetRoleNamesLov failed", xhr && xhr.status);
			RoleRights._showMessage("error", "Unable to load roles", "Role list request failed.");
		});
	},

	SelctAllChackbox: function () {
		var checked = RoleRights._$("#select_all_check_box").is(":checked");
		RoleRights._$home().find("[id^=chk_]").prop("checked", checked);
	},

	GetModuleNamesRoles: function () {
		var appType = RoleRights._$("#app_type").val();
		var roleCode = RoleRights._$("#role_name").val();
		var menuGroup = RoleRights._$("#menu_group").val() || "";
		if (RoleRights._isEmpty(roleCode)) {
			RoleRights._showMessage("warning", "Select a role", "Select Role Name before getting details.");
			return false;
		}

		RoleRights._block("Loading role rights...");
		$.ajax({
			type: "GET",
			url: RoleRights._host() + "role_rights/GetModuleNamesforSelectedRoles",
			data: { app_type: appType, role_name: roleCode, menu_group: menuGroup },
			dataType: "json"
		}).done(function (response) {
			var code = response && (response.error_code != null ? response.error_code : response.errorCode);
			if (code !== 0 && code !== "0") {
				RoleRights._showMessage("error", "Unable to load role rights", (response && response.message) || "The request failed.");
				return;
			}

			var $body = RoleRights._$("#role_rights_table tbody").empty();
			$.each(response.data || [], function (_index, value) {
				var moduleCode = value.internal_code != null ? value.internal_code : value.INTERNAL_CODE;
				var mappedCode = value.ref_menu_code != null ? value.ref_menu_code : value.REF_MENU_CODE;
				var $row = $("<tr></tr>");
				$("<td></td>").text(value.menu_name || value.MENU_NAME || "").appendTo($row);
				$("<td></td>").text(value.sub_menu_name || value.SUB_MENU_NAME || "").appendTo($row);
				$("<td></td>").text(value.display_name || value.DISPLAY_NAME || "").appendTo($row);
				var $checkbox = $("<input type='checkbox'>")
					.attr("id", "chk_" + moduleCode)
					.prop("checked", mappedCode != null && String(mappedCode) !== "0");
				$("<td></td>").append($checkbox).appendTo($row);
				$body.append($row);
			});
			RoleRights._$("#role_save_div").show();
			RoleRights._$("#role_rights_div").show();
		}).fail(function (xhr) {
			RoleRights._showMessage("error", "Unable to load role rights",
				"Request failed (" + (xhr && xhr.status ? xhr.status : "network error") + ").");
		}).always(function () {
			RoleRights._unblock();
		});
		return false;
	},

	SaveRoleDetails: function () {
		var roleCode = RoleRights._$("#role_name").val();
		if (RoleRights._isEmpty(roleCode)) {
			RoleRights._showMessage("warning", "Select a role", "Select Role Name before saving.");
			return false;
		}

		var $home = RoleRights._$home();
		var checkedValues = $home.find("input[id^='chk_']:checked").map(function () {
			return this.id.substring(4);
		}).get();
		var uncheckedValues = $home.find("input[id^='chk_']:not(:checked)").map(function () {
			return this.id.substring(4);
		}).get();

		RoleRights._block("Saving role rights...");
		$.ajax({
			type: "GET",
			url: RoleRights._host() + "role_rights/SaveRoleDetails",
			data: {
				role_name: roleCode,
				checkedVals: checkedValues.join(","),
				NoncheckedVals: uncheckedValues.join(",")
			},
			dataType: "json"
		}).done(function (response) {
			var code = response && (response.error_code != null ? response.error_code : response.errorCode);
			if (code === 0 || code === "0") {
				RoleRights._showMessage("success", "Saved", response.data || response.message || "Mapped successfully.");
			} else {
				RoleRights._showMessage("error", "Save failed", (response && response.message) || "Role rights were not saved.");
			}
		}).fail(function (xhr) {
			RoleRights._showMessage("error", "Save failed",
				"Request failed (" + (xhr && xhr.status ? xhr.status : "network error") + ").");
		}).always(function () {
			RoleRights._unblock();
		});
		return false;
	},

	chooseUserRoleExcel: function () {
		var $input = RoleRights._$("#user_role_excel_file");
		$input.off("change.roleRights").on("change.roleRights", function () {
			var file = this.files && this.files[0];
			this.value = "";
			if (file) {
				RoleRights._setUploadModalMessage("Validating workbook...", "alert-info");
				RoleRights.previewUserRoleExcel(file);
			}
		});
		$input.trigger("click");
		return false;
	},

	openUserRoleUploadModal: function () {
		RoleRights._setUploadModalMessage("", "");
		var modalElement = RoleRights._$("#user_role_upload_modal").get(0);
		var originalParent = modalElement && modalElement.parentNode;
		var originalNextSibling = modalElement && modalElement.nextSibling;
		if (modalElement && modalElement.parentNode !== document.body) {
			document.body.appendChild(modalElement);
		}
		if (modalElement) {
			$(modalElement)
				.off(".roleRightsModal")
				.on("shown.bs.modal.roleRightsModal", function () {
					$("body").addClass("role-rights-upload-open");
				})
				.on("hidden.bs.modal.roleRightsModal", function () {
					$("body").removeClass("role-rights-upload-open");
					if (originalParent && document.documentElement.contains(originalParent)) {
						originalParent.insertBefore(
							modalElement,
							originalNextSibling && originalNextSibling.parentNode === originalParent
								? originalNextSibling
								: null
						);
					}
				});
		}
		if (modalElement && window.bootstrap && window.bootstrap.Modal) {
			window.bootstrap.Modal.getOrCreateInstance(modalElement).show();
		} else if (modalElement && window.jQuery && typeof window.jQuery.fn.modal === "function") {
			$(modalElement).modal("show");
		}
		return false;
	},

	downloadUserRoleFormat: function () {
		RoleRights._setUploadModalMessage("Preparing Excel format...", "alert-info");
		window.location.href = RoleRights._host() + "role_rights_upload_dowload/downloadUserRoleUploadFormat";
		return false;
	},

	downloadExistingUserRoles: function () {
		var enlIds = RoleRights.userRoleTomSelect
			? RoleRights.userRoleTomSelect.getValue()
			: [];
		if (!Array.isArray(enlIds)) enlIds = enlIds ? [enlIds] : [];
		enlIds = $.map(enlIds, function (enlId) {
			return String(enlId || "").trim();
		}).filter(function (enlId) {
			return enlId !== "";
		});
		var roleCode = String(RoleRights._$("#user_role_filter").val() || "").trim();
		if (enlIds.length > 500) {
			RoleRights._setUploadModalErrors("Too many users selected", [
				"Select no more than 500 users per download."
			]);
			return false;
		}
		RoleRights._setUploadModalMessage(
			"Preparing existing role assignments" +
				(roleCode ? " for the selected role" : " for all roles") +
				(enlIds.length ? " and " + enlIds.length + " selected user(s)..." : "..."),
			"alert-info"
		);
		var url = RoleRights._host() + "role_rights_upload_dowload/downloadExistingUserRoles";
		if (!enlIds.length && !roleCode) {
			window.location.href = url;
			return false;
		}
		var form = document.createElement("form");
		form.method = "POST";
		form.action = url;
		form.style.display = "none";
		$.each([
			{ name: "enl_ids", value: enlIds.join(",") },
			{ name: "role_code", value: roleCode }
		], function (_index, field) {
			var input = document.createElement("input");
			input.type = "hidden";
			input.name = field.name;
			input.value = field.value;
			form.appendChild(input);
		});
		document.body.appendChild(form);
		form.submit();
		form.remove();
		return false;
	},

	_setUploadModalMessage: function (message, cssClass) {
		var $message = RoleRights._$("#user_role_upload_message");
		$message.removeClass("alert-info alert-success alert-danger alert-warning d-none")
			.addClass(cssClass || "alert-info");
		$message.text(message || "");
		if (!message) $message.addClass("d-none");
	},

	_setUploadModalErrors: function (title, errors) {
		var $message = RoleRights._$("#user_role_upload_message").empty();
		$message.removeClass("alert-info alert-success alert-warning d-none").addClass("alert-danger");
		$("<div></div>").addClass("fw-semibold mb-1").text(title).appendTo($message);
		var $list = $("<ul></ul>").addClass("mb-0 ps-3");
		$.each(errors || [], function (_index, error) {
			$("<li></li>").text(error).appendTo($list);
		});
		$message.append($list);
	},

	previewUserRoleExcel: function (file) {
		if (!/\.xlsx$/i.test(file.name || "")) {
			RoleRights._setUploadModalErrors("Invalid file", [
				"Choose an .xlsx workbook. Use Download Format for the supported template."
			]);
			return;
		}

		var form = new FormData();
		form.append("file", file);
		RoleRights._block("Validating user-role workbook...", "user_role_upload_modal");
		$.ajax({
			type: "POST",
			url: RoleRights._host() + "role_rights_upload_dowload/uploadUserRoles",
			data: form,
			processData: false,
			contentType: false,
			dataType: "json"
		}).done(function (response) {
			if (!response || response.success !== true) {
				RoleRights._showUploadErrors(response);
				return;
			}
			RoleRights._setUploadModalMessage("Workbook validated. Review the changes before applying.", "alert-success");
			RoleRights._confirmUserRoleUpload(file, response);
		}).fail(function (xhr) {
			RoleRights._setUploadModalErrors("Upload validation failed", [
				"Could not validate the workbook (" + (xhr && xhr.status ? xhr.status : "network error") + ")."
			]);
		}).always(function () {
			RoleRights._unblock("user_role_upload_modal");
		});
	},

	_confirmUserRoleUpload: function (file, response) {
		var rows = response.rows || [];
		var additions = 0;
		var removals = 0;
		$.each(rows, function (_index, row) {
			if (row.operation === "Add mapping") additions++;
			if (row.operation === "Remove mapping") removals++;
		});

		var table = "<div style='max-height:40vh;overflow:auto;text-align:left'><table class='table table-sm'><thead><tr>" +
			"<th>ENL ID</th><th>Role</th><th>Action</th><th>Result</th></tr></thead><tbody>";
		$.each(rows.slice(0, 40), function (_index, row) {
			table += "<tr><td>" + RoleRights._escapeHtml(row.enlId) + "</td><td>" +
				RoleRights._escapeHtml(row.roleName) + "</td><td>" +
				RoleRights._escapeHtml(row.action) + "</td><td>" +
				RoleRights._escapeHtml(row.operation) + "</td></tr>";
		});
		table += "</tbody></table></div>";
		if (rows.length > 40) table += "<div class='small text-muted'>Showing 40 of " + rows.length + " rows.</div>";
		var summary = "<p>Rows: " + rows.length + " &middot; Add: " + additions + " &middot; Remove: " +
			removals + "</p>" + table +
			"<p class='small text-muted'>Only the listed user-role mappings are changed. Confirm to continue.</p>";

		if (window.Swal && typeof window.Swal.fire === "function") {
			window.Swal.fire({
				title: "Review user-role changes",
				html: summary,
				icon: "info",
				showCancelButton: true,
				confirmButtonText: "Apply upload",
				cancelButtonText: "Cancel",
				width: "850px"
			}).then(function (result) {
				if (result && result.isConfirmed) RoleRights.applyUserRoleExcel(file);
			});
		} else if (window.confirm("Apply " + rows.length + " user-role rows? Add: " + additions + ", remove: " + removals)) {
			RoleRights.applyUserRoleExcel(file);
		}
	},

	applyUserRoleExcel: function (file) {
		var form = new FormData();
		form.append("file", file);
		RoleRights._block("Applying user-role changes...", "user_role_upload_modal");
		$.ajax({
			type: "POST",
			url: RoleRights._host() + "role_rights_upload_dowload/applyUserRoles",
			data: form,
			processData: false,
			contentType: false,
			dataType: "json"
		}).done(function (response) {
			if (response && response.success === true) {
				RoleRights._setUploadModalMessage("Upload complete. Added: " + response.added +
					", removed: " + response.deleted + ", unchanged: " + response.unchanged + ".", "alert-success");
				return;
			}
			RoleRights._showUploadErrors(response);
		}).fail(function (xhr) {
			RoleRights._setUploadModalErrors("Upload failed", [
				"Could not apply the workbook (" + (xhr && xhr.status ? xhr.status : "network error") + ")."
			]);
		}).always(function () {
			RoleRights._unblock("user_role_upload_modal");
		});
	},

	_showUploadErrors: function (response) {
		var errors = response && response.errors ? response.errors : ["The server rejected this workbook."];
		RoleRights._setUploadModalErrors("Workbook needs correction", errors);
	},

	_escapeHtml: function (value) {
		return $("<div></div>").text(value == null ? "" : String(value)).html();
	},

	_showMessage: function (icon, title, message) {
		if (window.Swal && typeof window.Swal.fire === "function") {
			window.Swal.fire({ icon: icon, title: title, text: message });
		} else {
			window.alert(title + ": " + message);
		}
	}
};
