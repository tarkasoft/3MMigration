﻿$g_cmn_clicked_module_name="";
$g_cmn_clicked_system_name="";
$g_cmn_added_action_lister=0;
function toSentenceCase(inputString) 
{
	if (!inputString) return inputString;
	return inputString.toLowerCase().replace(/(^|\s)\S/g, (char) => char.toUpperCase());
}

function toTitleCase(inputString) 
{
	if (!inputString) return inputString;
	return inputString.toLowerCase().replace(/(^|\s)\S/g, (char) => char.toUpperCase());
}

/**
 * Shared helpers under one global: Common.xxx
 * Cookie readers prefer inpcGetCookie (inpc-portal-cookies.js), else getCookie (common-helpers.js).
 *
 * Usage:
 *   Common.GetCustCode(); Common.GetCustName(); Common.GetLoginId();
 *   Common.ShowAcSpinner("#change_customer_modal", "change_customer_ac_spinner");
 *   Common.HideAcSpinner("#change_customer_modal", "change_customer_ac_spinner");
 *   Common.ShowAcSpinner(null, "my_spinner_id");
 *   Common.IsMobile(); Common.IsDesktop(); Common.GetDeviceType();
 *   Common.DataTable — see custom_js/tarka_common_datatable.js (loaded after this file).
 */
var Common = {
	AcknowledgeWelcome: function (welcomeInternalCode, onSuccess, onError) {
		var base = window.$app_url || "";
		$.ajax({
			url: base + "api/portal/welcome-ack",
			method: "POST",
			data: { welcomeInternalCode: welcomeInternalCode },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
			if (!json || (code != null && Number(code) !== 0)) {
				if (typeof onError === "function") {
					onError((json && (json.message || json.status)) || "Unable to save the acknowledgement.");
				}
				return;
			}
			if (typeof onSuccess === "function") onSuccess(json);
		}).fail(function () {
			if (typeof onError === "function") onError("Unable to save the acknowledgement.");
		});
	},

	_resolveAcSpinner: function (parentDivId, elementId) {
		var eid = String(elementId == null ? "" : elementId).replace(/^#/, "");
		if (!eid) {
			return $();
		}
		if (parentDivId) {
			var sel = String(parentDivId);
			var $parent = (sel.charAt(0) === "#" || sel.charAt(0) === ".") ? $(sel) : $("#" + sel);
			if ($parent.length) {
				var $sp = $parent.find("#" + eid);
				if ($sp.length) {
					return $sp;
				}
			}
		}
		return $("#" + eid);
	},

	ShowAcSpinner: function (parentDivId, elementId) {
		var $sp = Common._resolveAcSpinner(parentDivId, elementId);
		if ($sp.length) {
			$sp.prop("hidden", false).attr("aria-hidden", "false");
		}
	},

	HideAcSpinner: function (parentDivId, elementId) {
		var $sp = Common._resolveAcSpinner(parentDivId, elementId);
		if ($sp.length) {
			$sp.prop("hidden", true).attr("aria-hidden", "true");
		}
	},


	/**
	 * Load shared Bootstrap modals from inpc_modal_popup.html once into document.body.
	 * Includes: announce, welcome, FW lookup, change customer, Sync Module Layout form/preview.
	 * Call early on MainPage; optional callback runs after append (or immediately if already loaded).
	 */
	LoadSharedModals: function (done) {
		var cb = typeof done === "function" ? done : function () {};
		if (window.__inpcSharedModalsLoaded) {
			cb();
			return;
		}
		if (window.__inpcSharedModalsLoading) {
			$(document).one("inpc:shared-modals-ready", cb);
			return;
		}
		window.__inpcSharedModalsLoading = true;
		var url = "inpc_modal_popup.html?v=202609202150";
		$.ajax({
			url: url,
			method: "GET",
			dataType: "html",
			cache: true
		})
			.done(function (html) {
				try {
					$("body").append(html);
				} catch (eApp) { /* ignore */ }
				window.__inpcSharedModalsLoaded = true;
				window.__inpcSharedModalsLoading = false;
				try {
					Common._bindSyncModuleLayoutButtons();
				} catch (eBind) { /* ignore */ }
				$(document).trigger("inpc:shared-modals-ready");
				cb();
			})
			.fail(function () {
				window.__inpcSharedModalsLoading = false;
				console.warn("INPC: failed to load inpc_modal_popup.html");
				cb();
			});
	},

	_bindSyncModuleLayoutButtons: function () {
		if (window.__inpcSyncLayoutBtnsBound) return;
		if (!$("#inpc_sync_layout_form_modal").length) return;
		window.__inpcSyncLayoutBtnsBound = true;
		$(document).on("click", "#inpc_sync_preview_btn", function () {
			Common._syncModuleLayoutPreview();
		});
		$(document).on("click", "#inpc_sync_proceed_btn", function () {
			Common._syncModuleLayoutProceed();
		});
		$(document).on("click", "#inpc_sync_goback_btn", function () {
			Common._syncModuleLayoutGoBack();
		});
		Common._wireSyncModuleLayoutFileAutocomplete();
	},

	/** Viewport breakpoint (px). Width below this counts as mobile. */
	MOBILE_MAX_WIDTH: 767,

	/**
	 * True when viewport is mobile-sized.
	 * Prefer this over user-agent so DevTools device mode works.
	 * Override: Common.MOBILE_MAX_WIDTH = 991;
	 */
	IsMobile: function () {
		var w = window.innerWidth || document.documentElement.clientWidth || 0;
		var max = Number(Common.MOBILE_MAX_WIDTH);
		if (!isFinite(max) || max <= 0) max = 767;
		return w <= max;
	},

	/** True when viewport is desktop-sized (not mobile). */
	IsDesktop: function () {
		return !Common.IsMobile();
	},

	/** "mobile" | "desktop" */
	GetDeviceType: function () {
		return Common.IsMobile() ? "mobile" : "desktop";
	},

	/**
	 * Mobile: keep column widths and allow horizontal scroll (CreateGridFiles grids use shrinkToFit).
	 * Desktop: restore shrink-to-fit within the parent width.
	 */
	EnableJqGridMobileHScroll: function ($grid) {
		if (typeof jQuery === "undefined" || !$grid || !$grid.length || typeof $grid.jqGrid !== "function") {
			return;
		}
		if (!$grid[0].grid) {
			return;
		}
		var $gbox = $grid.closest(".ui-jqgrid");
		var $parent = $gbox.parent();
		var parentW = Math.floor(($parent.innerWidth && $parent.innerWidth()) || $parent.width() || 0);
		if (parentW < 40) {
			parentW = Math.floor(window.innerWidth || document.documentElement.clientWidth || 0);
		}
		if (parentW < 40) {
			return;
		}
		try {
			if (Common.IsMobile()) {
				$grid.jqGrid("setGridParam", { shrinkToFit: false });
				$grid.jqGrid("setGridWidth", parentW, false);
				$gbox.find(".ui-jqgrid-bdiv").css({
					"overflow-x": "auto",
					"overflow-y": "auto",
					"-webkit-overflow-scrolling": "touch"
				});
			} else {
				$grid.jqGrid("setGridParam", { shrinkToFit: true });
				$grid.jqGrid("setGridWidth", parentW, true);
			}
		} catch (ignore) {}
	},

	/**
	 * Narrow layout (991px and below): put original column widths back and scroll sideways.
	 * shrinkToFit has already overwritten colModel.width, so width alone does not unsqueeze.
	 */
	inpcElementsGridNoSqueeze: function ($grid) {
		if (typeof jQuery === "undefined" || !$grid || !$grid.length || typeof $grid.jqGrid !== "function" || !$grid[0].grid) {
			return;
		}
		var p = $grid[0].p;
		if (!p || !p.colModel) {
			return;
		}
		var viewW = window.innerWidth || document.documentElement.clientWidth || 0;
		var $gbox = $grid.closest(".ui-jqgrid");
		var $parent = $gbox.parent();
		var parentW = Math.floor(($parent.innerWidth && $parent.innerWidth()) || $parent.width() || viewW);
		if (parentW < 40) {
			parentW = Math.floor(viewW);
		}
		if (parentW < 40) {
			return;
		}
		var cm = p.colModel;
		try {
			if (!$grid.data("inpcColWidths")) {
				var saved = [];
				for (var s = 0; s < cm.length; s++) {
					var org = parseInt(cm[s].widthOrg, 10);
					if (!org || org < 40) {
						org = parseInt(cm[s].width, 10) || 120;
					}
					saved.push(org);
				}
				$grid.data("inpcColWidths", saved);
			}
			var widths = $grid.data("inpcColWidths");
			var $labels = $gbox.find(".ui-jqgrid-htable tr.ui-jqgrid-labels > th");
			var need = 0;
			for (var n = 0; n < cm.length; n++) {
				if (cm[n].hidden) {
					continue;
				}
				var base = widths[n] || parseInt(cm[n].widthOrg, 10) || 120;
				var lab = jQuery.trim(($labels.eq(n).text() || "").replace(/\s+/g, " "));
				var labW = lab.length ? (lab.length * 8 + 48) : base;
				need += (base < labW ? labW : base);
			}
			if (viewW > 991 && need <= parentW) {
				for (var d = 0; d < cm.length; d++) {
					if (cm[d].name === "cb" || cm[d].name === "rn" || cm[d].name === "subgrid") {
						continue;
					}
					cm[d].fixed = false;
				}
				$grid.jqGrid("setGridParam", { shrinkToFit: true });
				$grid.jqGrid("setGridWidth", parentW, true);
				return;
			}
			var $search = $gbox.find(".ui-jqgrid-htable tr.ui-search-toolbar > th");
			var $first = $grid.find("tr.jqgfirstrow > td");
			var tbl = 0;
			for (var i = 0; i < cm.length; i++) {
				if (cm[i].hidden) {
					continue;
				}
				var w = widths[i] || parseInt(cm[i].widthOrg, 10) || 120;
				var label = jQuery.trim(($labels.eq(i).text() || "").replace(/\s+/g, " "));
				var textW = label.length ? (label.length * 8 + 48) : w;
				if (w < textW) {
					w = textW;
				}
				cm[i].width = w;
				cm[i].widthOrg = w;
				cm[i].fixed = true;
				tbl += w;
				var px = w + "px";
				$labels.eq(i).css({ width: px, minWidth: px });
				$labels.eq(i).children("div").css({ width: px, minWidth: px });
				if ($search.length) {
					$search.eq(i).css({ width: px, minWidth: px });
				}
				if ($first.length) {
					$first.eq(i).css({ width: px, minWidth: px });
				}
			}
			p.shrinkToFit = false;
			p.tblwidth = tbl;
			$grid.jqGrid("setGridWidth", parentW, false);
			var tw = tbl + "px";
			$gbox.find(".ui-jqgrid-htable, .ui-jqgrid-btable").css({ width: tw, minWidth: tw });
			for (var r = 0; r < cm.length; r++) {
				if (cm[r].hidden) {
					continue;
				}
				var rpx = cm[r].width + "px";
				$labels.eq(r).css({ width: rpx, minWidth: rpx });
				$labels.eq(r).children("div").css({ width: rpx, minWidth: rpx });
				if ($search.length) {
					$search.eq(r).css({ width: rpx, minWidth: rpx });
				}
				if ($first.length) {
					$first.eq(r).css({ width: rpx, minWidth: rpx });
				}
			}
			$gbox.find(".ui-jqgrid-bdiv").css({ overflowX: "auto", overflowY: "auto" });
		} catch (ignore) {}
	},

	/**
	 * cellEdit grids often skip row highlight on click — force selection so ui-state-highlight always applies.
	 */
	EnsureJqGridRowSelect: function ($grid) {
		if (typeof jQuery === "undefined" || !$grid || !$grid.length || !$grid[0].grid) {
			return;
		}
		if ($grid.data("inpcRowSelectBound")) {
			return;
		}
		$grid.data("inpcRowSelectBound", true);
		try {
			$grid.jqGrid("setGridParam", {
				beforeSelectRow: function () {
					return true;
				},
				onCellSelect: function (rowid) {
					try {
						jQuery(this).jqGrid("setSelection", rowid, false);
					} catch (ignore) {}
				}
			});
		} catch (ignore2) {}
		$grid.on("click.inpcRowSelect", "tr.jqgrow > td", function (e) {
			if (jQuery(e.target).closest("input,select,textarea,button,a,.ui-icon").length) {
				return;
			}
			var rowid = jQuery(this).closest("tr.jqgrow").attr("id");
			if (!rowid) {
				return;
			}
			try {
				$grid.jqGrid("setSelection", rowid, false);
			} catch (ignore3) {}
		});
	},

	BindJqGridMobileHScroll: function () {
		if (Common._jqGridHScrollBound || typeof jQuery === "undefined") {
			return;
		}
		Common._jqGridHScrollBound = true;
		var applyAll = function () {
			if (!jQuery.fn || !jQuery.fn.jqGrid) {
				return;
			}
			jQuery(".ui-jqgrid-btable").each(function () {
				var $g = jQuery(this);
				Common.EnableJqGridMobileHScroll($g);
				Common.inpcElementsGridNoSqueeze($g);
				Common.EnsureJqGridRowSelect($g);
			});
		};
		jQuery(window).on("resize.inpcGridHScroll orientationchange.inpcGridHScroll", function () {
			clearTimeout(Common._jqGridHScrollTimer);
			Common._jqGridHScrollTimer = setTimeout(applyAll, 160);
		});
		jQuery(document).on("jqGridLoadComplete.inpcGridHScroll", ".ui-jqgrid-btable", function () {
			var $g = jQuery(this);
			Common.EnableJqGridMobileHScroll($g);
			Common.inpcElementsGridNoSqueeze($g);
			Common.EnsureJqGridRowSelect($g);
		});
		setTimeout(applyAll, 300);
		setTimeout(applyAll, 1000);
		setTimeout(applyAll, 2000);
	},

	/** Cache of announcements by internal_code (filled by FillAnnouncementsData). */
	_announcementById: {},

	/**
	 * Load active announcements for All + logged-in user type (order by sequence).
	 * Call after MenuLoad: Common.FillAnnouncementsData();
	 * API: system/getAnnouncements (via $host_url which already includes titpl/) (com.mmm.system.Announcements)
	 */
	FillAnnouncementsData: function () {
		var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
		if (h && h.slice(-1) !== "/") {
			h += "/";
		}
		$.ajax({
			url: h + "system/getAnnouncements",
			method: "GET",
			dataType: "json",
			xhrFields: { withCredentials: true }
		})
			.done(function (json) {
				var ok = json && (json.errorCode === 0 || json.error_code === 0);
				var rows = (ok && json.data && json.data.announcements) ? json.data.announcements : [];
				Common._renderAnnouncementsList(rows);
			})
			.fail(function () {
				Common._renderAnnouncementsList([]);
			});
	},

	_snipText: function (html, n) {
		var t = $("<div/>").html(String(html == null ? "" : html)).text().replace(/\s+/g, " ").trim();
		n = n || 100;
		return t.length > n ? t.slice(0, n) + "..." : t;
	},

	/**
	 * Fill megaphone dropdown with jQuery (empty + append). Row click uses onclick attribute (no .on bind).
	 */
	_renderAnnouncementsList: function (rows) {
		Common._ensureAnnounceDropdownGuard();
		Common._announcementById = {};
		var $bell = $("#inpc_announce_header_li");
		var $list = $("#inpc_announce_list");
		var $badge = $("#inpc_announce_badge");
		var $countLabel = $("#inpc_announce_count_label");
		var $footer = $("#inpc_announce_footer");
		if (!$list.length && !$bell.length) {
			return;
		}

		if ($list.length) {
			$list.empty();
		}

		if (!rows || !rows.length) {
			$bell.hide();
			if ($list.length) {
				$list.empty();
			}
			$badge.hide().text("0");
			$countLabel.text("0 new");
			$footer.text("");
			return;
		}

		$bell.show();
		$.each(rows, function (_i, a) {
			var id = a.internal_code != null ? String(a.internal_code) : "";
			Common._announcementById[id] = a;
			var $btn = $("<button/>", {
				type: "button",
				"class": "list-group-item list-group-item-action text-start inpc-announce-row",
				title: "View full details"
			});
			$btn.on("click", function (e) {
				e.preventDefault();
				e.stopPropagation();
				Common.OpenAnnouncementPopup(id);
			});
			var $text = $("<div/>", { "class": "ann-text flex-grow-1 pe-2" });
			$text.append($("<div/>", { "class": "ann-title", text: a.title || "" }));
			$text.append($("<div/>", { "class": "ann-snip", text: Common._snipText(a.description || a.full_desc || "", 100) }));
			var $affordance = $("<span/>", {
				"class": "ann-open-hint",
				"aria-hidden": "true"
			});
			$affordance.append($("<i/>", { "class": "ri-arrow-right-s-line" }));
			$btn.append($text);
			$btn.append($affordance);
			$list.append($btn);
		});

		$badge.show().text(String(rows.length));
		$countLabel.text(rows.length + " new");
		$footer.text("");
	},

	/**
	 * Open announcement detail modal (jQuery + Bootstrap Modal).
	 * Body = full_desc when present, else description.
	 * Use from onclick: Common.OpenAnnouncementPopup(internal_code)
	 */
	_ensureAnnounceDropdownGuard: function () {
		if (Common._announceDropdownGuardBound) {
			return;
		}
		Common._announceDropdownGuardBound = true;
		var $li = $("#inpc_announce_header_li");
		var $modal = $("#inpc_announce_modal");
		if ($li.length) {
			// Block hide while detail is up (no close/reopen flicker on Got it)
			$li.on("hide.bs.dropdown.inpcGuard", function (e) {
				if (Common._announceKeepList) {
					e.preventDefault();
				}
			});
		}
		if ($modal.length) {
			// Got it / X / backdrop clicks stay inside the modal tree — don't treat as outside the list
			$modal.on("click.inpcAnnounceKeepList mousedown.inpcAnnounceKeepList", function (e) {
				e.stopPropagation();
			});
		}
	},

	OpenAnnouncementPopup: function (internalCode) {
		var id = String(internalCode == null ? "" : internalCode);
		var a = Common._announcementById[id];
		if (!a) {
			return;
		}
		Common._ensureAnnounceDropdownGuard();
		Common._announceKeepList = true;
		$("#inpc_announce_modal_title").text(a.title || "");
		$("#inpc_announce_modal_group").text("");
		var bodyHtml = $.trim(String(a.full_desc || ""));
		if (!bodyHtml) {
			bodyHtml = String(a.description || "");
		}
		$("#inpc_announce_modal_body").html(bodyHtml);
		$("#inpc_announce_modal_dates").text("").addClass("d-none");
		var $modal = $("#inpc_announce_modal");
		$modal.addClass("inpc-announce-modal-anim");
		var el = $modal[0];
		if (el && window.bootstrap && bootstrap.Modal) {
			var inst = bootstrap.Modal.getOrCreateInstance(el);
			$modal.off("hidden.bs.modal.inpcKeepList");
			$modal.one("hidden.bs.modal.inpcKeepList", function () {
				$modal.removeClass("inpc-announce-modal-anim");
				// List never closed — only release the guard so a later outside click can dismiss it
				setTimeout(function () {
					Common._announceKeepList = false;
				}, 0);
			});
			inst.show();
		}
	},

	_readPortalCookie: function (name) {
		if (typeof inpcGetCookie === "function") {
			return String(inpcGetCookie(name) || "");
		}
		if (typeof getCookie === "function") {
			return String(getCookie(name) || "");
		}
		return "";
	},

	/** Effective customer code: override when fw_customer_overridden is Yes. */
	GetCustCode: function () {
		var overridden = String(Common._readPortalCookie("fw_customer_overridden") || "").trim().toLowerCase() === "yes";
		if (overridden) {
			return Common._readPortalCookie("fw_override_cust_code");
		}
		return Common._readPortalCookie("fw_cust_code");
	},

	/** Effective customer name: same override pattern as GetCustCode. */
	GetCustName: function () {
		var overridden = String(Common._readPortalCookie("fw_customer_overridden") || "").trim().toLowerCase() === "yes";
		if (overridden) {
			return Common._readPortalCookie("fw_override_cust_name");
		}
		return Common._readPortalCookie("fw_cust_name");
	},

	/** Login id from fw_loginId cookie. */
	GetLoginId: function () {
		return Common._readPortalCookie("fw_loginId");
	},

	/** Server-backed permission stored at login/menu load. */
	CanChangeCustomer: function () {
		return String(Common._readPortalCookie("fw_see_other_cust_data") || "").trim().toLowerCase() === "yes";
	},

	IsCustomerOverridden: function () {
		return String(Common._readPortalCookie("fw_customer_overridden") || "").trim().toLowerCase() === "yes";
	},

	GetOverrideLoginId: function () {
		if (!Common.CanChangeCustomer() || !Common.IsCustomerOverridden()) {
			return "";
		}
		return Common._readPortalCookie("fw_override_loginId");
	},

	/**
	 * Procedure override values are sent only for an authorized active override.
	 * Empty values tell Java to use the authenticated session customer/login.
	 */
	GetProcedureCustomerContext: function () {
		if (!Common.CanChangeCustomer() || !Common.IsCustomerOverridden()) {
			return { custCode: "", loginId: "" };
		}
		return {
			custCode: Common._readPortalCookie("fw_override_cust_code"),
			loginId: Common._readPortalCookie("fw_override_loginId")
		};
	},

	/**
	 * Page-level alert inside a root div.
	 * Uses #inpc_page_msg under the root (creates if missing).
	 * kind: info|danger|warning|success
	 */
	showPageMsg: function (rootDivId, text, kind) {
		var rid = String(rootDivId == null ? "" : rootDivId).replace(/^#/, "");
		var $root = rid ? $("#" + rid) : $();
		if (!$root.length) {
			return;
		}
		var cls = "alert alert-" + (kind || "info") + " mb-2 py-2 px-3";
		var $msg = $root.find("#inpc_page_msg");
		if (!$msg.length) {
			$msg = $('<div id="inpc_page_msg" role="alert"></div>');
			$root.prepend($msg);
		}
		$msg.attr("class", cls).text(String(text || ""));
	},

	clearPageMsg: function (rootDivId) {
		var rid = String(rootDivId == null ? "" : rootDivId).replace(/^#/, "");
		if (!rid) {
			return;
		}
		$("#" + rid).find("#inpc_page_msg").remove();
	},

	/** Download role-rights workbook (xlsx). HTML calls Common.userRoleRightsUploadDownlaod(). */
	userRoleRightsUploadDownlaod: function () {
		var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
		if (h && h.slice(-1) !== "/") h += "/";
		window.location.href = h + "role_rights_upload_dowload/userRoleRightsDownlaod";
	},
	/**
	 * Generate jqGrid JS files (server: titpl/system/createGridFiles).
	 * Call from HTML/onclick: Common.CreateGridFiles();
	 */
	CreateGridFiles: function () {
		var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
		if (h && h.slice(-1) !== "/") h += "/";
		var url = h + "system/createGridFiles";
		try {
			if (typeof showLoader === "function") showLoader("Creating grid files...", "home_dashboard");
		} catch (eL) { /* ignore */ }
		$.ajax({
			url: url,
			method: "GET",
			dataType: "json",
			xhrFields: { withCredentials: true }
		})
			.done(function (json) {
				var ok = json && (json.error_code === 0 || json.errorCode === 0 || String(json.status || "").toLowerCase() === "success");
				var created = (json && (json.created_count != null ? json.created_count : (json.created && json.created.length))) || 0;
				var skipped = (json && (json.skipped_count != null ? json.skipped_count : (json.skipped && json.skipped.length))) || 0;
				var msg = (json && (json.message || json.status)) || (ok ? "Grid files generated" : "Create grid files failed");
				if (ok) {
					msg = msg + "\nCreated: " + created + "\nSkipped: " + skipped;
					if (json && json.out_dir) {
						msg = msg + "\nFolder: " + json.out_dir;
					}
				}
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, ok ? "success" : "danger");
				} else if (typeof bootbox !== "undefined" && bootbox.alert) {
					bootbox.alert(String(msg).replace(/\n/g, "<br>"));
				} else {
					alert(msg);
				}
			})
			.fail(function (xhr) {
				var msg = "Create grid files failed (" + (xhr && xhr.status ? xhr.status : "network") + ")";
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, "danger");
				} else {
					alert(msg);
				}
			})
			.always(function () {
				try {
					if (typeof hideLoader === "function") hideLoader("home_dashboard");
				} catch (eH) { /* ignore */ }
			});
	},
	/**
	 * Generate module HTML files (server: titpl/system/createHtmlFiles).
	 * Call from HTML/onclick: Common.CreateHtmlFiles();
	 */
	CreateHtmlFiles: function () {
		var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
		if (h && h.slice(-1) !== "/") h += "/";
		var url = h + "system/createHtmlFiles";
		try {
			if (typeof showLoader === "function") showLoader("Creating HTML files...", "home_dashboard");
		} catch (eL) { /* ignore */ }
		$.ajax({
			url: url,
			method: "GET",
			dataType: "json",
			xhrFields: { withCredentials: true }
		})
			.done(function (json) {
				var ok = json && (json.error_code === 0 || json.errorCode === 0 || String(json.status || "").toLowerCase() === "success");
				var created = (json && (json.created_count != null ? json.created_count : (json.created && json.created.length))) || 0;
				var skipped = (json && (json.skipped_count != null ? json.skipped_count : (json.skipped && json.skipped.length))) || 0;
				var msg = (json && (json.message || json.status)) || (ok ? "HTML files generated" : "Create HTML files failed");
				if (ok) {
					msg = msg + "\nCreated: " + created + "\nSkipped: " + skipped;
					if (json && json.out_dir) {
						msg = msg + "\nFolder: " + json.out_dir;
					}
				}
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, ok ? "success" : "danger");
				} else if (typeof bootbox !== "undefined" && bootbox.alert) {
					bootbox.alert(String(msg).replace(/\n/g, "<br>"));
				} else {
					alert(msg);
				}
			})
			.fail(function (xhr) {
				var msg = "Create HTML files failed (" + (xhr && xhr.status ? xhr.status : "network") + ")";
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, "danger");
				} else {
					alert(msg);
				}
			})
			.always(function () {
				try {
					if (typeof hideLoader === "function") hideLoader("home_dashboard");
				} catch (eH) { /* ignore */ }
			});
	},

	/**
	 * Rebuild ia_module_meta_columns (server: titpl/metacolumns/createModuleMetaColumns).
	 * Call from HTML/onclick: Common.CreateMetaColumns(); or Common.CreateMeta();
	 */
	CreateMetaColumns: function () {
		var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
		if (h && h.slice(-1) !== "/") h += "/";
		var url = h + "metacolumns/createModuleMetaColumns";
		try {
			if (typeof showLoader === "function") showLoader("Creating meta columns...", "home_dashboard");
		} catch (eL) { /* ignore */ }
		$.ajax({
			url: url,
			method: "GET",
			dataType: "json",
			xhrFields: { withCredentials: true }
		})
			.done(function (json) {
				var ok = json && (json.error_code === 0 || json.errorCode === 0 || String(json.status || "").toLowerCase() === "success");
				var processed = (json && (json.processed && json.processed.length)) || 0;
				var skipped = (json && (json.skipped && json.skipped.length)) || 0;
				var msg = (json && (json.message || json.status)) || (ok ? "Meta columns generated" : "Create meta columns failed");
				if (ok) {
					msg = msg + "\nProcessed: " + processed + "\nSkipped: " + skipped;
				}
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, ok ? "success" : "danger");
				} else if (typeof bootbox !== "undefined" && bootbox.alert) {
					bootbox.alert(String(msg).replace(/\n/g, "<br>"));
				} else {
					alert(msg);
				}
			})
			.fail(function (xhr) {
				var msg = "Create meta columns failed (" + (xhr && xhr.status ? xhr.status : "network") + ")";
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, "danger");
				} else {
					alert(msg);
				}
			})
			.always(function () {
				try {
					if (typeof hideLoader === "function") hideLoader("home_dashboard");
				} catch (eH) { /* ignore */ }
			});
	},

	/** Short aliases for framework page buttons */
	/**
	 * Generate popup jqGrid JS files (server: titpl/system/createPopupFiles).
	 * Writes pop_up_{file_name}.js — elements with include_in_popup=1.
	 * Call from HTML/onclick: Common.CreatePopupFiles(); or Common.CreatePopup();
	 */
	CreatePopupFiles: function () {
		var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
		if (h && h.slice(-1) !== "/") h += "/";
		var url = h + "system/createPopupFiles";
		try {
			if (typeof showLoader === "function") showLoader("Creating popup files...", "home_dashboard");
		} catch (eL) { /* ignore */ }
		$.ajax({
			url: url,
			method: "GET",
			dataType: "json",
			xhrFields: { withCredentials: true }
		})
			.done(function (json) {
				var ok = json && (json.error_code === 0 || json.errorCode === 0 || String(json.status || "").toLowerCase() === "success");
				var created = (json && (json.created_count != null ? json.created_count : (json.created && json.created.length))) || 0;
				var skipped = (json && (json.skipped_count != null ? json.skipped_count : (json.skipped && json.skipped.length))) || 0;
				var msg = (json && (json.message || json.status)) || (ok ? "Popup files generated" : "Create popup files failed");
				if (ok) {
					msg = msg + "\nCreated: " + created + "\nSkipped: " + skipped;
					if (json && json.out_dirs && json.out_dirs.length) {
						msg = msg + "\nFolder: " + json.out_dirs[0];
					} else if (json && json.out_dir) {
						msg = msg + "\nFolder: " + json.out_dir;
					}
				}
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, ok ? "success" : "danger");
				} else if (typeof bootbox !== "undefined" && bootbox.alert) {
					bootbox.alert(String(msg).replace(/\n/g, "<br>"));
				} else {
					alert(msg);
				}
			})
			.fail(function (xhr) {
				var msg = "Create popup files failed (" + (xhr && xhr.status ? xhr.status : "network") + ")";
				if (typeof ShowAlertMsg === "function") {
					ShowAlertMsg(msg, "danger");
				} else {
					alert(msg);
				}
			})
			.always(function () {
				try {
					if (typeof hideLoader === "function") hideLoader("home_dashboard");
				} catch (eH) { /* ignore */ }
			});
	},

	CreateHtml: function () { return Common.CreateHtmlFiles(); },
	CreateGrid: function () { return Common.CreateGridFiles(); },
/**
	 * Sync one module layout into ia_menu_options + ia_s_user_schema_elements.
	 * One form popup for params, then a preview popup of UPDATE SQL; Proceed writes DB.
	 * field_width: TopBottom=12 / LeftRight=3. LOV + order from existing HTML.
	 * Call: Common.SyncModuleLayout();
	 */
	SyncModuleLayout: function (opts) {
		opts = opts || {};
		/* Modals already in DOM via LoadSharedModals on page ready. */
		Common._bindSyncModuleLayoutButtons();
		Common._wireSyncModuleLayoutFileAutocomplete();
		var $form = $("#inpc_sync_layout_form_modal");
		$("#inpc_sync_file_name").val(opts.file_name || "");
		$("#inpc_sync_field_position").val(opts.field_position || "TopBottom");
		$("#inpc_sync_grid_position").val(opts.grid_position || "Bottom");
		$("#inpc_sync_html_width").val(opts.html_width != null ? opts.html_width : "6");
		$("#inpc_sync_grid_width").val(opts.grid_width != null ? opts.grid_width : "6");
		$("#inpc_sync_generate_html").val(opts.generate_html || "Yes");
		$("#inpc_sync_generate_grid").val(opts.generate_grid || "Yes");
		$form.data("inpcApplyOpts", null);
		if (opts.file_name) {
			Common._syncModuleLayoutFillFromMenu(opts);
		}
		if (window.bootstrap && bootstrap.Modal) {
			bootstrap.Modal.getOrCreateInstance($form[0]).show();
		} else {
			$form.modal("show");
		}
	},


	/**
	 * jQuery UI autocomplete on #inpc_sync_file_name from ia_menu_options.
	 * On select, fills field_position / grid_* / generate_* from the chosen row.
	 */
	_wireSyncModuleLayoutFileAutocomplete: function () {
		var $txt = $("#inpc_sync_file_name");
		if (!$txt.length || typeof $txt.autocomplete !== "function") {
			return;
		}
		if (window.__inpcSyncFileAcWired) {
			try {
				$txt.autocomplete("destroy");
			} catch (eDes) { /* ignore */ }
			window.__inpcSyncFileAcWired = false;
		}
		$txt.attr("autocomplete", "off");
		$txt.autocomplete({
			minLength: 1,
			appendTo: "#inpc_sync_layout_form_modal .modal-body",
			position: { my: "left top", at: "left bottom", collision: "flip" },
			open: function () {
				var $menu = $(this).autocomplete("widget");
				$menu.css({ zIndex: 2060, position: "absolute" });
			},
			source: function (request, response) {
				if (Common._syncFileAcAjax && Common._syncFileAcAjax.abort) {
					Common._syncFileAcAjax.abort();
				}
				var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
				if (h && h.slice(-1) !== "/") h += "/";
				Common._syncFileAcAjax = $.ajax({
					url: h + "system/syncModuleLayoutFiles",
					method: "GET",
					dataType: "json",
					data: { value: request.term },
					xhrFields: { withCredentials: true }
				})
					.done(function (json) {
						var rows = (json && json.data) ? json.data : [];
						response($.map(rows, function (r) {
							var fn = String((r && (r.file_name || r.value)) || "").replace(/\.html$/i, "").trim();
							if (!fn) return null;
							return {
								label: fn,
								value: fn,
								file_name: fn,
								field_position: r.field_position,
								grid_position: r.grid_position,
								html_width: r.html_width,
								grid_width: r.grid_width,
								generate_html: r.generate_html,
								generate_grid: r.generate_grid
							};
						}).filter(Boolean));
						$("ul.ui-autocomplete li a").css("color", "#403849");
					})
					.fail(function () {
						response([]);
					});
			},
			focus: function () {
				return false;
			},
			select: function (event, ui) {
				if (!ui || !ui.item) return false;
				this.value = ui.item.value || ui.item.file_name || "";
				Common._syncModuleLayoutFillFromMenu(ui.item);
				return false;
			}
		});
		window.__inpcSyncFileAcWired = true;
	},

	/** Apply ia_menu_options layout columns onto the Sync Module Layout form. */
	_syncModuleLayoutFillFromMenu: function (row) {
		if (!row) return;
		var fpRaw = String(row.field_position == null ? "" : row.field_position).replace(/\s+/g, "");
		var fp = "";
		if (/^leftright$/i.test(fpRaw) || /^lefttoright$/i.test(fpRaw) || /^ltor$/i.test(fpRaw)) {
			fp = "LeftRight";
		} else if (fpRaw) {
			fp = "TopBottom";
		}
		var gpSrc = String(row.grid_position == null ? "" : row.grid_position).trim();
		var gp = "Bottom";
		if (/^top$/i.test(gpSrc)) gp = "Top";
		else if (/^left$/i.test(gpSrc)) gp = "Left";
		else if (/^right$/i.test(gpSrc)) gp = "Right";
		else gp = "Bottom";

		var yn = function (v) {
			var s = String(v == null ? "" : v).trim();
			if (!s) return "Yes";
			if (/^(no|0|false|n)$/i.test(s)) return "No";
			return "Yes";
		};
		if (fp) $("#inpc_sync_field_position").val(fp);
		$("#inpc_sync_grid_position").val(gp);
		if (row.html_width != null && String(row.html_width).trim() !== "") {
			$("#inpc_sync_html_width").val(row.html_width);
		}
		if (row.grid_width != null && String(row.grid_width).trim() !== "") {
			$("#inpc_sync_grid_width").val(row.grid_width);
		}
		$("#inpc_sync_generate_html").val(yn(row.generate_html));
		$("#inpc_sync_generate_grid").val(yn(row.generate_grid));
	},
	_ensureSyncModuleLayoutModals: function () {
		Common._bindSyncModuleLayoutButtons();
	},



	_syncModuleLayoutReadForm: function () {
		return {
			file_name: $.trim($("#inpc_sync_file_name").val() || ""),
			field_position: $("#inpc_sync_field_position").val() || "TopBottom",
			grid_position: $("#inpc_sync_grid_position").val() || "Bottom",
			html_width: $("#inpc_sync_html_width").val() || "6",
			grid_width: $("#inpc_sync_grid_width").val() || "6",
			generate_html: $("#inpc_sync_generate_html").val() || "Yes",
			generate_grid: $("#inpc_sync_generate_grid").val() || "Yes"
		};
	},

	_syncModuleLayoutCall: function (data, onOk) {
		var h = (typeof window.$host_url !== "undefined" && window.$host_url) ? window.$host_url : (window.host_url || "");
		if (h && h.slice(-1) !== "/") h += "/";
		var url = h + "system/syncModuleLayout";
		try {
			if (typeof showLoader === "function") showLoader(data.dry_run === "1" ? "Building preview..." : "Updating DB...", "home_dashboard");
		} catch (eL) { /* ignore */ }
		$.ajax({
			url: url,
			method: "GET",
			data: data,
			dataType: "json",
			xhrFields: { withCredentials: true }
		})
			.done(function (json) {
				var ok = json && (json.error_code === 0 || json.errorCode === 0 || String(json.status || "").toLowerCase() === "success");
				if (!ok) {
					var msg = (json && (json.message || json.status)) || "Sync failed";
					if (typeof ShowAlertMsg === "function") ShowAlertMsg(msg, "danger");
					else alert(msg);
					return;
				}
				if (typeof onOk === "function") onOk(json);
			})
			.fail(function (xhr) {
				var msg = "Sync module layout failed (" + (xhr && xhr.status ? xhr.status : "network") + ")";
				if (typeof ShowAlertMsg === "function") ShowAlertMsg(msg, "danger");
				else alert(msg);
			})
			.always(function () {
				try {
					if (typeof hideLoader === "function") hideLoader("home_dashboard");
				} catch (eH) { /* ignore */ }
			});
	},

	_syncModuleLayoutPreview: function () {
		var form = Common._syncModuleLayoutReadForm();
		if (!form.file_name) {
			if (typeof ShowAlertMsg === "function") ShowAlertMsg("file_name is required", "danger");
			else alert("file_name is required");
			return;
		}
		form.dry_run = "1";
		Common._syncModuleLayoutCall(form, function (json) {
			var cmds = (json && json.update_commands) || [];
			var meta = "file: <b>" + (json.file_name || form.file_name) + "</b>"
				+ " &nbsp;|&nbsp; html_found: <b>" + (!!json.html_found) + "</b>"
				+ " &nbsp;|&nbsp; elements: <b>" + (json.elements_parsed || 0) + "</b>"
				+ " &nbsp;|&nbsp; field_position: <b>" + form.field_position + "</b>"
				+ " (width " + (form.field_position === "LeftRight" ? "3" : "12") + ")";
			$("#inpc_sync_preview_meta").html(meta);
			$("#inpc_sync_preview_sql").text(cmds.length ? cmds.join("\n\n") : "(no UPDATE commands)");
			$("#inpc_sync_layout_form_modal").data("inpcApplyOpts", form);
			var $formModal = $("#inpc_sync_layout_form_modal");
			var $prev = $("#inpc_sync_layout_preview_modal");
			if (window.bootstrap && bootstrap.Modal) {
				var fm = bootstrap.Modal.getInstance($formModal[0]);
				if (fm) fm.hide();
				bootstrap.Modal.getOrCreateInstance($prev[0]).show();
			} else {
				$formModal.modal("hide");
				$prev.modal("show");
			}
		});
	},

	_syncModuleLayoutGoBack: function () {
		var $formModal = $("#inpc_sync_layout_form_modal");
		var $prev = $("#inpc_sync_layout_preview_modal");
		if (!$prev.length || !$formModal.length) return;
		if (window.bootstrap && bootstrap.Modal) {
			var pm = bootstrap.Modal.getInstance($prev[0]);
			var showForm = function () {
				bootstrap.Modal.getOrCreateInstance($formModal[0]).show();
			};
			if (pm) {
				$prev.one("hidden.bs.modal", showForm);
				pm.hide();
			} else {
				showForm();
			}
		} else {
			$prev.modal("hide");
			$formModal.modal("show");
		}
	},

	_syncModuleLayoutProceed: function () {
		var form = $("#inpc_sync_layout_form_modal").data("inpcApplyOpts") || Common._syncModuleLayoutReadForm();
		if (!form || !form.file_name) {
			alert("Nothing to apply — run Preview first");
			return;
		}
		form.dry_run = "0";
		Common._syncModuleLayoutCall(form, function (json) {
			var cmds = (json && json.update_commands) || [];
			$("#inpc_sync_preview_meta").html(
				"<span class=\"text-success\">Applied to DB.</span> Updated elements: <b>" +
					(json.elements_updated || 0) +
					"</b>, menu rows: <b>" +
					(json.menu_rows || 0) +
					"</b>"
			);
			$("#inpc_sync_preview_sql").text(cmds.length ? cmds.join("\n\n") : "(done)");
			if (typeof ShowAlertMsg === "function") {
				ShowAlertMsg("Module layout updated for " + (json.file_name || form.file_name), "success");
			}
		});
	},

	CreatePopup: function () { return Common.CreatePopupFiles(); },
	CreatePopup: function () { return Common.CreatePopupFiles(); },
	CreateMeta: function () { return Common.CreateMetaColumns(); }

	// DataTable lives in custom_js/tarka_common_datatable.js (Common.DataTable)
};



/**
 * Welcome Message action (ia_menu_options.custom_links: Preview~PreviewWelcomeMessage();).
 * Reads the open form title + html_body and shows them in #inpc_welcome_modal.
 */
function PreviewWelcomeMessage() {
	var $root = $("#m_welcome_msg_module");
	var html = "";
	var title = "Welcome";
	var $html = $root.length ? $root.find("#html_body") : $("#html_body");
	var $title = $root.length ? $root.find("#title") : $("#title");
	if ($html.length) {
		html = String($html.val() == null ? "" : $html.val()).trim();
	}
	if ($title.length) {
		var t = String($title.val() == null ? "" : $title.val()).trim();
		if (t) title = t;
	}
	var el = document.getElementById("inpc_welcome_modal");
	if (!el || typeof bootstrap === "undefined" || !bootstrap.Modal) return;
	el.setAttribute("data-ack-lock", "No");
	$("#inpc_welcome_ack_row").addClass("d-none");
	$("#inpc_welcome_ack_check").prop("checked", false);
	$("#inpc_welcome_ack_done").addClass("d-none").text("");
	$("#inpc_welcome_ok_btn").prop("disabled", false).text("OK");
	$("#inpc_welcome_modal_title").text(title);
	$("#inpc_welcome_modal_body").html(html || "<p class=\"text-muted mb-0\">Enter HTML Body to preview.</p>");
	var modal = bootstrap.Modal.getOrCreateInstance(el, { backdrop: "static", keyboard: false });
	$("#inpc_welcome_ok_btn")
		.off("click.inpcWelcome")
		.on("click.inpcWelcome", function () {
			try { modal.hide(); } catch (eHide) { /* ignore */ }
		});
	try { modal.show(); } catch (eShow) { /* ignore */ }
}

if (typeof jQuery !== "undefined") {
	jQuery(function () {
		if (window.Common && Common.LoadSharedModals) {
			Common.LoadSharedModals();
		}
		if (window.Common && Common.BindJqGridMobileHScroll) {
			Common.BindJqGridMobileHScroll();
		}
	});
}
