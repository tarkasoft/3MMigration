/**
 * Contract Claim Management. Menu file: SHIPANDDEBIT/ship_and_debit
 * js_path: custom_js/SHIPANDDEBIT/ship_and_debit.js
 */
ShipAndDebit = {
	ROOT: "m_ship_and_debit",
	_api: "api/customer/ship-and-debit",
	_accepted: false,
	_ready: {},
	_statusBuckets: null,
	_docProgressState: null,
	DOC_REQUEST_FILE_LIMIT_BYTES: 4.5 * 1024 * 1024,
	_editDocumentQueue: [],
	_editUploadOnlyQueue: [],
	_editStoredDocuments: [],
	_editUploadOnlyListReady: false,
	_editLateStatus: "idle",
	_editLateLookupToken: 0,

	/**
	 * Active Ship & Debit shell (multi-tab safe). Prefer InpcTabs active pane, else visible home.
	 */
	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + ShipAndDebit.ROOT) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $("#" + ShipAndDebit.ROOT).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $("#" + ShipAndDebit.ROOT).first();
	},

	/** Find within #m_ship_and_debit so duplicate ids in other portal tabs are ignored. */
	_$: function (selector) {
		var $home = ShipAndDebit._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	_el: function (selector) {
		return ShipAndDebit._$(selector).get(0) || null;
	},

	_sanitizeQuantityInput: function (input) {
		if (!input) return "";
		var value = String(input.value || "").replace(/[^0-9.]/g, "");
		var decimal = value.indexOf(".");
		if (decimal >= 0) {
			value = value.substring(0, decimal + 1)
				+ value.substring(decimal + 1).replace(/\./g, "").substring(0, 2);
		}
		input.value = value;
		return value;
	},

	_showDocumentError: function (selector, message) {
		var $message = ShipAndDebit._$(selector);
		$message.text(message || "").toggleClass("d-none", !message);
	},

	_validateClaimComment: function (selector) {
		var $comment = ShipAndDebit._$(selector);
		if ($.trim($comment.val() || "")) {
			$comment.removeClass("is-invalid");
			return true;
		}
		$comment.addClass("is-invalid")
			.off("input.sdRequired")
			.on("input.sdRequired", function () {
				if ($.trim(this.value || "")) $(this).removeClass("is-invalid");
			})
			.trigger("focus");
		Common.showPageMsg(ShipAndDebit.ROOT, "Claim comments are required.", "warning");
		return false;
	},

	_showRequestError: function (title, message) {
		var text = message || "The request could not be completed. Please try again.";
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: title,
				text: text,
				icon: "error",
				confirmButtonText: "OK",
				confirmButtonColor: "#b42318",
				customClass: { popup: "sd-request-error" }
			});
			if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
			return;
		}
		Common.showPageMsg(ShipAndDebit.ROOT, text, "danger");
	},

	Load: function () {
		ShipAndDebit._reset();
		ShipAndDebit._popupCss();
		ShipAndDebit._claimTableCss();
		ShipAndDebit._bindPageMsg();
		ShipAndDebit._loadScripts(function () {
			ShipAndDebit._lock(true);
			ShipAndDebit._get("/open", function (data) {
				ShipAndDebit._accepted = !!(data && data.accepted);
				ShipAndDebit._lock(!ShipAndDebit._accepted);
				if (ShipAndDebit._accepted) {
					ShipAndDebit.ShowTab(ShipAndDebit._el("[data-sd-tab='pending']"));
					return;
				}
				ShipAndDebit._showTerms();
			});
		});
	},

	ShowTab: function (btn) {
		if (!btn || !ShipAndDebit._accepted) return false;
		var key = btn.getAttribute("data-sd-tab");
		var root = ShipAndDebit._$home().get(0);
		if (!root) return false;
		var tabs = root.querySelectorAll(".sd-tab");
		for (var i = 0; i < tabs.length; i++) tabs[i].setAttribute("aria-selected", "false");
		btn.setAttribute("aria-selected", "true");
		var panels = root.querySelectorAll(".sd-panel");
		for (var j = 0; j < panels.length; j++) panels[j].classList.remove("active");
		var panel = ShipAndDebit._el("#sd_panel_" + key);
		if (panel) panel.classList.add("active");
		ShipAndDebit._activeTab = key;
		if (key === "create") ShipAndDebit.HideMsg();
		else ShipAndDebit._applyTabMsg();
		if (key === "create") ShipAndDebit._openCreate();
		if (key === "edit") ShipAndDebit._loadEdit();
		if (key === "status") ShipAndDebit.LoadStatus(false);
		if (key === "accepted") ShipAndDebit._rates("m_sd_accepted", "sd_accepted_table", "sd_accepted_tbody", "A");
		if (key === "report") ShipAndDebit._ensureDates();
		if (key === "pending") ShipAndDebit._rates("m_sd_pending", "sd_pending_table", "sd_pending_tbody", "P");
		return false;
	},

	_popupCss: function () {
		if (document.getElementById("sd_popup_css")) return;
		var css = document.createElement("style");
		css.id = "sd_popup_css";
		css.textContent = ""
			+ "#sd_claim_modal .modal-dialog{width:min(95vw,1197px)!important;max-width:min(95vw,1197px)!important}"
			+ "#sd_rate_modal .sd-rate-head,#sd_claim_modal .sd-rate-head,#sd_terms_modal .sd-terms-head{display:flex!important;align-items:center;gap:.75rem;padding:.9rem 1.15rem;border:0!important;background:linear-gradient(120deg,#4aa3e8,#7ec8f5)!important;color:#12324d!important}"
			+ "#sd_rate_modal .sd-rate-kicker,#sd_claim_modal .sd-rate-kicker,#sd_terms_modal .sd-terms-kicker{display:block;margin:0;color:#1d4f78!important;font-size:.72rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase}"
			+ "#sd_rate_modal .modal-title,#sd_claim_modal .modal-title,#sd_terms_modal .modal-title{margin:0;color:#0e3354!important;font-size:1.05rem;font-weight:700}"
			+ "#sd_rate_modal .modal-body,#sd_claim_modal .modal-body{background:#f7fafc!important}"
			+ "#sd_rate_modal .sd-rate-facts,#sd_claim_modal .sd-rate-facts{display:grid!important;grid-template-columns:1fr 1fr;gap:.65rem;margin:0 0 .9rem}"
			+ "#sd_rate_modal .sd-rate-fact,#sd_claim_modal .sd-rate-fact{display:block!important;padding:.65rem .75rem;border:1px solid #d7e8f6;border-radius:.7rem;background:#fff!important}"
			+ "#sd_rate_modal .sd-rate-fact span,#sd_claim_modal .sd-rate-fact span{display:block!important;margin:0 0 .2rem;color:#5b7290!important;font-size:.72rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase}"
			+ "#sd_rate_modal .sd-rate-fact strong,#sd_claim_modal .sd-rate-fact strong{display:block;color:#16324a!important;font-size:.92rem;font-weight:650}"
			+ "#sd_rate_modal .sd-rate-section,#sd_claim_modal .sd-rate-section{display:flex!important;align-items:center;gap:.45rem;margin:0 0 .45rem;padding:.45rem .7rem;border-radius:.55rem;background:linear-gradient(120deg,#4aa3e8,#7ec8f5)!important;color:#0e3354!important;font-size:.92rem;font-weight:700}"
			+ "#sd_rate_modal .sd-rate-table thead th,#sd_claim_modal .sd-rate-table thead th{background:#eef6fc!important;color:#1d4f78!important;font-weight:700}"
			+ ".swal2-popup.sd-request-error{border:1px solid #f1c8c8;border-radius:1rem;box-shadow:0 1rem 3rem rgba(31,54,78,.2)}"
			+ ".swal2-popup.sd-request-error .swal2-title{color:#7f1d1d;font-size:1.2rem}"
			+ ".swal2-popup.sd-request-error .swal2-html-container{color:#334155;line-height:1.55;white-space:pre-line}"
			+ ".swal2-popup .sd-claim-confirm-amount{color:#b42318;font-weight:800;font-size:1.12em;white-space:nowrap}"
			+ "@media(max-width:640px){#sd_rate_modal .sd-rate-facts,#sd_claim_modal .sd-rate-facts{grid-template-columns:1fr!important}}";
		document.head.appendChild(css);
	},

	_claimTableCss: function () {
		if (document.getElementById("sd_claim_table_css")) return;
		var css = document.createElement("link");
		css.id = "sd_claim_table_css";
		css.rel = "stylesheet";
		css.href = (window.$app_url || "") + "css/ship_and_debit_claims.css";
		document.head.appendChild(css);
	},

	_reset: function () {
		["sd_terms_modal", "sd_rate_modal", "sd_claim_modal", "sd_edit_upload_modal", "sd_doc_progress_modal"].forEach(function (id) {
			document.querySelectorAll("#" + id).forEach(function (node) {
				if (node.parentNode !== document.body) return;
				var inst = window.bootstrap && bootstrap.Modal.getInstance(node);
				if (inst) {
					try { inst.dispose(); } catch (e) { /* ignore */ }
				}
				node.remove();
			});
		});
		document.querySelectorAll(".modal-backdrop").forEach(function (back) { back.remove(); });
		document.body.classList.remove("modal-open");
		document.body.style.removeProperty("padding-right");
		ShipAndDebit._accepted = false;
		ShipAndDebit._ready = {};
		ShipAndDebit._statusBuckets = null;
		ShipAndDebit._pendingOpen = "";
		ShipAndDebit._pendingTold = false;
		ShipAndDebit._msgTab = "";
		ShipAndDebit._openClaimNumber = "";
		ShipAndDebit._editRows = [];
		ShipAndDebit._editDeleted = [];
		ShipAndDebit._editIndex = -1;
		ShipAndDebit._docProgressState = null;
		ShipAndDebit._clearEditDocumentQueue();
		ShipAndDebit._clearEditUploadOnlyQueue();
		ShipAndDebit._editStoredDocuments = [];
		ShipAndDebit._editUploadOnlyListReady = false;
		ShipAndDebit._editSaveInProgress = false;
		ShipAndDebit._editConfirmingSubmit = false;
		ShipAndDebit._editLateStatus = "idle";
		ShipAndDebit._editLookupToken = (ShipAndDebit._editLookupToken || 0) + 1;
		ShipAndDebit._editLateLookupToken = (ShipAndDebit._editLateLookupToken || 0) + 1;
		if (window.ShipAndDebitCreate) {
			ShipAndDebitCreate._clearDocuments();
			ShipAndDebitCreate._ready = false;
			ShipAndDebitCreate._lines = [];
			ShipAndDebitCreate._claimNumber = "";
			ShipAndDebitCreate._late = "N";
			ShipAndDebitCreate._lateStatus = "idle";
			ShipAndDebitCreate._lateLookupToken++;
		}
		ShipAndDebit.HideMsg();
	},

	_bindPageMsg: function () {
		if (ShipAndDebit._msgBound || !window.Common || !Common.showPageMsg) return;
		ShipAndDebit._msgBound = true;
		var show = Common.showPageMsg;
		Common.showPageMsg = function (rootDivId, text, kind) {
			show.apply(Common, arguments);
			var rid = String(rootDivId == null ? "" : rootDivId).replace(/^#/, "");
			if (rid !== ShipAndDebit.ROOT) return;
			ShipAndDebit._msgTab = ShipAndDebit._activeTab || "";
			ShipAndDebit._applyTabMsg();
		};
		if (Common.clearPageMsg) {
			var clear = Common.clearPageMsg;
			Common.clearPageMsg = function (rootDivId) {
				clear.apply(Common, arguments);
				var rid = String(rootDivId == null ? "" : rootDivId).replace(/^#/, "");
				if (rid === ShipAndDebit.ROOT) ShipAndDebit._msgTab = "";
			};
		}
	},

	/** Empty the banner without removing it, so it stays above the tab strip. */
	HideMsg: function () {
		ShipAndDebit._msgTab = "";
		var root = ShipAndDebit._$home().get(0);
		var box = root && root.querySelector("#inpc_page_msg");
		if (!box) return;
		box.textContent = "";
		box.classList.add("d-none");
	},

	_applyTabMsg: function () {
		var root = ShipAndDebit._$home().get(0);
		var box = root && root.querySelector("#inpc_page_msg");
		if (!box) return;
		var text = String(box.textContent || "").trim();
		var mine = text && (!ShipAndDebit._msgTab || ShipAndDebit._msgTab === ShipAndDebit._activeTab);
		box.classList.toggle("d-none", !mine);
	},

	AcceptTerms: function () {
		if (!ShipAndDebit._$("#sd_terms_check").prop("checked")) return false;
		ShipAndDebit._termsMsg("");
		ShipAndDebit._post("/terms", ShipAndDebit._context(), function () {
			ShipAndDebit._accepted = true;
			var modal = ShipAndDebit._el("#sd_terms_modal");
			if (modal) modal.setAttribute("data-ack-lock", "No");
			var inst = window.bootstrap && bootstrap.Modal.getInstance(modal);
			if (inst) inst.hide();
			ShipAndDebit._lock(false);
			ShipAndDebit.ShowTab(ShipAndDebit._el("[data-sd-tab='pending']"));
		});
		return false;
	},

	GoHome: function () {
		var modal = ShipAndDebit._el("#sd_terms_modal");
		if (modal) modal.setAttribute("data-ack-lock", "No");
		if (modal && window.bootstrap) {
			var inst = bootstrap.Modal.getInstance(modal);
			if (inst) inst.hide();
		}
		document.querySelectorAll(".modal-backdrop").forEach(function (back) { back.remove(); });
		document.body.classList.remove("modal-open");
		document.body.style.removeProperty("overflow");
		document.body.style.removeProperty("padding-right");
		var homeMod = "Home";
		if (window.inpcHomeModuleForUserType && window.inpcGetLoginUserType) {
			homeMod = window.inpcHomeModuleForUserType(window.inpcGetLoginUserType()) || "Home";
		}
		if (window.LoadHtmlFiles) window.LoadHtmlFiles(homeMod, "Home", "Home", "0");
		return false;
	},

	OpenClaim: function (number) {
		number = String(number || ShipAndDebit._openClaimNumber || "").trim();
		if (!number) return false;
		if (ShipAndDebit._openClaimNumber !== number) {
			ShipAndDebit._clearEditDocumentQueue();
			ShipAndDebit._clearEditUploadOnlyQueue();
			ShipAndDebit._editStoredDocuments = [];
			ShipAndDebit._editUploadOnlyListReady = false;
		}
		ShipAndDebit._openClaimNumber = number;
		ShipAndDebit._bindEditDocuments();
		ShipAndDebit._editSaveInProgress = false;
		ShipAndDebit._editContext = null;
		ShipAndDebit._editRows = [];
		ShipAndDebit._editLookupToken = (ShipAndDebit._editLookupToken || 0) + 1;
		var lookupToken = ShipAndDebit._editLookupToken;
		ShipAndDebit._editLateStatus = "loading";
		ShipAndDebit._editLateLookupToken = lookupToken;
		ShipAndDebit._$("#sd_edit_late").prop("required", false).attr("aria-required", "false");
		ShipAndDebit._get("/claims/" + encodeURIComponent(number), function (rows) {
			if (lookupToken !== ShipAndDebit._editLookupToken) return;
			ShipAndDebit._editRows = (rows || []).map(function (row) { return ShipAndDebit._claimLine(row); });
			var firstLine = ShipAndDebit._editRows[0] || {};
			ShipAndDebit._editContext = {
				endCustomerCode: firstLine.endCustomerCode || "",
				division: firstLine.division || "",
				claimMonthRaw: firstLine.claimMonthRaw || ""
			};
			ShipAndDebit._loadEditLateFlag(lookupToken);
			ShipAndDebit._editDeleted = [];
			ShipAndDebit._editIndex = -1;
			ShipAndDebit._editAddDetail = null;
			ShipAndDebit._editAddDetailKey = "";
			ShipAndDebit._editAddCheckKey = "";
			ShipAndDebit._$("#sd_retry_edit_docs").toggleClass("d-none",
				!ShipAndDebit._editDocumentQueue.some(function (entry) { return entry.status === "failed"; }));
			ShipAndDebit._$("#sd_edit_grid").addClass("d-none");
			ShipAndDebit._$("#sd_edit_detail").removeClass("d-none");
			ShipAndDebit._renderEditDocuments();
			ShipAndDebit._fillEditHeader();
			ShipAndDebit._clearNewEditLine();
			ShipAndDebit._loadEditAddProducts();
			ShipAndDebit._paintEditLines();
			ShipAndDebit._files(number);
		}, function () {
			if (lookupToken === ShipAndDebit._editLookupToken) ShipAndDebit._editLateStatus = "error";
		});
		return false;
	},

	_loadEditLateFlag: function (lookupToken) {
		if (lookupToken !== ShipAndDebit._editLookupToken
				|| lookupToken !== ShipAndDebit._editLateLookupToken) return;
		var context = ShipAndDebit._editContext || {};
		ShipAndDebit._editLateStatus = "loading";
		ShipAndDebit._get("/late-flag?division=" + encodeURIComponent(context.division || "")
			+ "&claimMonth=" + encodeURIComponent(context.claimMonthRaw || ""), function (rows) {
			if (lookupToken !== ShipAndDebit._editLookupToken
					|| lookupToken !== ShipAndDebit._editLateLookupToken) return;
			var row = rows && rows[0];
			var flag = row ? ShipAndDebit._lookupColumn(row, ["LSSTS"], 0).toUpperCase() : "";
			if (flag !== "Y" && flag !== "N") {
				ShipAndDebit._editLateStatus = "error";
				Common.showPageMsg(ShipAndDebit.ROOT, "Late submission status could not be verified. Please try again.", "danger");
				return;
			}
			var required = flag === "Y";
			ShipAndDebit._editLateStatus = required ? "required" : "ready";
			ShipAndDebit._$("#sd_edit_late").prop("required", required)
				.attr("aria-required", required ? "true" : "false");
		}, function () {
			if (lookupToken === ShipAndDebit._editLookupToken
					&& lookupToken === ShipAndDebit._editLateLookupToken) ShipAndDebit._editLateStatus = "error";
		});
	},

	CloseEdit: function () {
		ShipAndDebit._editIndex = -1;
		ShipAndDebit._$("#sd_edit_detail").addClass("d-none");
		ShipAndDebit._$("#sd_edit_grid").removeClass("d-none");
		ShipAndDebit._claims("m_sd_edit", "sd_edit_table", "sd_edit_tbody", "P");
		return false;
	},

	EditLine: function (index) {
		var line = (ShipAndDebit._editRows || [])[index];
		if (!line) return false;
		ShipAndDebit._editIndex = index;
		ShipAndDebit._editAddDetail = null;
		ShipAndDebit._editAddDetailKey = "";
		ShipAndDebit._clearNewEditDetails();
		var $product = ShipAndDebit._$("#sd_e_add_product");
		if (!$product.find("option").filter(function () { return this.value === line.sku; }).length) {
			$("<option>").val(line.sku).attr("data-description", line.description)
				.text((line.sku + " - " + line.description).trim()).appendTo($product);
		}
		$product.val(line.sku).prop("disabled", true);
		ShipAndDebit._$("#sd_e_add_sku").val(line.sku);
		var $invoice = ShipAndDebit._$("#sd_e_add_invoice").empty();
		$("<option>").val(line.invoiceNumber).attr("data-ymd", line.invoiceDate)
			.text(line.invoiceNumber).appendTo($invoice);
		$invoice.val(line.invoiceNumber).prop("disabled", true);
		ShipAndDebit._$("#sd_e_add_inv_date").val(ShipAndDebit._date(line.invoiceDate));
		ShipAndDebit._settingEditDistDate = true;
		ShipAndDebit._editDatePicker(line.invoiceDate);
		ShipAndDebit._$("#sd_e_add_dist_inv").val(line.distInvoiceNumber);
		ShipAndDebit._$("#sd_e_add_dist_date").val(ShipAndDebit._dateInput(line.distInvoiceDate));
		if (ShipAndDebit._$("#sd_e_add_dist_date").data("datepicker")) {
			ShipAndDebit._$("#sd_e_add_dist_date").datepicker("update", ShipAndDebit._$("#sd_e_add_dist_date").val());
		}
		ShipAndDebit._settingEditDistDate = false;
		ShipAndDebit._$("#sd_e_add_avail").val(line.availQty);
		ShipAndDebit._$("#sd_e_add_qty").val(line.distBillQty);
		ShipAndDebit._$("#sd_e_add_uom").val(line.uom);
		ShipAndDebit._$("#sd_e_add_sales").val(line.salesPerson);
		ShipAndDebit._$("#sd_e_add_rc").val(line.rcPrice);
		ShipAndDebit._$("#sd_e_add_price").val(line.distBillPrice);
		ShipAndDebit._$("#sd_e_add_tax").val(line.taxRate);
		ShipAndDebit._$("#sd_e_add_cgst").val(line.cgst);
		ShipAndDebit._$("#sd_e_add_igst").val(line.igst);
		ShipAndDebit._$("#sd_e_add_freight").val(line.freight);
		ShipAndDebit._$("#sd_e_add_discount").val(line.discount);
		ShipAndDebit._$("#sd_e_add_value").val(line.claimValue);
		ShipAndDebit._$("#sd_e_add_line").html("<i class='ri-save-line' aria-hidden='true'></i> Save");
		ShipAndDebit._$("#sd_edit_entry_hint").text("Update distributor invoice details or quantity, then Save.");
		return false;
	},

	_loadEditAddProducts: function () {
		var context = ShipAndDebit._editContext || {};
		var lookupToken = ShipAndDebit._editLookupToken;
		var $product = ShipAndDebit._$("#sd_e_add_product").empty()
			.append("<option value=''>Loading products...</option>").prop("disabled", true);
		ShipAndDebit._editDatePicker("");
		if (!context.endCustomerCode || !context.division) {
			$product.empty().append("<option value=''>Product details unavailable</option>").prop("disabled", true);
			Common.showPageMsg(ShipAndDebit.ROOT,
				"Product details could not be loaded because the claim division or end customer is missing.", "warning");
			return;
		}
		ShipAndDebit._get("/skus?endCustomer=" + encodeURIComponent(context.endCustomerCode)
			+ "&division=" + encodeURIComponent(context.division), function (rows) {
			if (lookupToken !== ShipAndDebit._editLookupToken) return;
			$product.empty().append("<option value=''>Choose your option</option>").prop("disabled", false);
			var productCount = 0;
			(rows || []).forEach(function (row) {
				var code = ShipAndDebit._lookupColumn(row, ["SKUCODE"], 0);
				var description = ShipAndDebit._lookupColumn(row, ["SKUDES"], 1);
				if (!code) return;
				$("<option>").val(code).attr("data-description", description)
					.text((code + " - " + description).trim()).appendTo($product);
				productCount++;
			});
			if (!productCount) {
				$product.prop("disabled", true);
				Common.showPageMsg(ShipAndDebit.ROOT,
					"No products were found for this claim's division and end customer.", "warning");
			} else {
				ShipAndDebit.HideMsg();
			}
		});
		ShipAndDebit._$("#sd_e_add_product").off("change.sdEditAdd").on("change.sdEditAdd", function () {
			ShipAndDebit._editAddDetail = null;
			ShipAndDebit._editAddDetailKey = "";
			ShipAndDebit._editAddCheckKey = "";
			ShipAndDebit._$("#sd_e_add_sku").val(this.value || "");
			ShipAndDebit._$("#sd_e_add_invoice").empty().append("<option value=''>Choose your option</option>");
			ShipAndDebit._$("#sd_e_add_dist_inv,#sd_e_add_dist_date,#sd_e_add_qty").val("");
			if (ShipAndDebit._$("#sd_e_add_dist_date").data("datepicker")) {
				ShipAndDebit._$("#sd_e_add_dist_date").datepicker("clearDates");
			}
			ShipAndDebit._clearNewEditDetails();
			if (!this.value) return;
			var selectedSku = String(this.value);
			ShipAndDebit._get("/invoices?sku=" + encodeURIComponent(this.value)
				+ "&claimMonth=" + encodeURIComponent(context.claimMonthRaw || ""), function (invoices) {
				if (lookupToken !== ShipAndDebit._editLookupToken
					|| String(ShipAndDebit._$("#sd_e_add_product").val() || "") !== selectedSku) return;
				if (!invoices || !invoices.length) {
					ShipAndDebit._$("#sd_e_add_invoice").empty().append("<option value=''>Choose your option</option>");
					Common.showPageMsg(ShipAndDebit.ROOT, "No invoice number found for this SKU Code.", "warning");
					return;
				}
				(invoices || []).forEach(function (invoice) {
					var number = ShipAndDebit._lookupColumn(invoice, ["INVOICENUM"], 0);
					var date = String(ShipAndDebit._lookupColumn(invoice, ["INVOICEDATE"], 1)).replace(/\D/g, "");
					if (number) $("<option>").val(number).attr("data-ymd", date).text(number)
						.appendTo(ShipAndDebit._$("#sd_e_add_invoice"));
				});
			});
		});
		ShipAndDebit._$("#sd_e_add_invoice").off("change.sdEditAdd").on("change.sdEditAdd", function () {
			var date = ShipAndDebit._$("#sd_e_add_invoice option:selected").attr("data-ymd") || "";
			ShipAndDebit._$("#sd_e_add_inv_date").val(ShipAndDebit._date(date));
			ShipAndDebit._editAddDetail = null;
			ShipAndDebit._editAddDetailKey = "";
			ShipAndDebit._editAddCheckKey = "";
			ShipAndDebit._$("#sd_e_add_dist_inv,#sd_e_add_dist_date,#sd_e_add_qty").val("");
			if (ShipAndDebit._$("#sd_e_add_dist_date").data("datepicker")) {
				ShipAndDebit._$("#sd_e_add_dist_date").datepicker("clearDates");
			}
			ShipAndDebit._editDatePicker(date);
			ShipAndDebit._clearNewEditDetails();
		});
		ShipAndDebit._$("#sd_e_add_dist_date").prop("readonly", true);
		ShipAndDebit._$("#sd_e_add_qty").off("input.sdEditAdd").on("input.sdEditAdd", function () {
			ShipAndDebit._sanitizeQuantityInput(this);
			ShipAndDebit._paintNewEditValue();
		}).off("blur.sdEditAdd").on("blur.sdEditAdd", function () {
			ShipAndDebit._validateEditQuantity();
		});
		ShipAndDebit._$("#sd_e_add_dist_inv").off("input.sdEditAdd change.sdEditAdd")
			.on("input.sdEditAdd change.sdEditAdd", function () {
				if (ShipAndDebit._editIndex >= 0) return;
				ShipAndDebit._editAddDetail = null;
				ShipAndDebit._editAddDetailKey = "";
				ShipAndDebit._editAddCheckKey = "";
				ShipAndDebit._clearNewEditDetails();
			}).on("blur.sdEditAdd", function () {
				if (ShipAndDebit._editIndex < 0) ShipAndDebit.CheckNewEditLine();
			});
		ShipAndDebit._$("#sd_e_add_inv_date").off("change.sdEditAdd").on("change.sdEditAdd", function () {
			ShipAndDebit._editAddDetail = null;
			ShipAndDebit._editAddDetailKey = "";
			ShipAndDebit._editAddCheckKey = "";
			ShipAndDebit._clearNewEditDetails();
			ShipAndDebit.CheckNewEditLine();
		});
	},

	_editDatePicker: function (invoiceDate) {
		var $date = ShipAndDebit._$("#sd_e_add_dist_date");
		if (!window.jQuery || !$.fn.datepicker || !$date.length) return;
		$date.prop("readonly", true);
		var context = ShipAndDebit._editContext || {};
		var bounds = ShipAndDebit._claimMonthDateBounds(context.claimMonthRaw, invoiceDate);
		if ($date.data("datepicker")) {
			$date.datepicker("setStartDate", bounds ? bounds.startDate : false)
				.datepicker("setEndDate", bounds ? bounds.endDate : new Date());
			if ($date.val()) $date.datepicker("update", $date.val());
			else $date.datepicker("clearDates");
		} else {
			$date.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				showOnFocus: false,
				format: "dd/mm/yyyy",
				endDate: bounds ? bounds.endDate : new Date(),
				startDate: bounds ? bounds.startDate : false,
				orientation: "bottom auto"
			});
		}
		$date.off("changeDate.sdEditDate").on("changeDate.sdEditDate", function () {
			if (ShipAndDebit._settingEditDistDate) return;
			if (ShipAndDebit._editIndex >= 0) {
				ShipAndDebit._validateEditDistDate(ShipAndDebit._editRows[ShipAndDebit._editIndex]);
				return;
			}
			ShipAndDebit._editAddDetail = null;
			ShipAndDebit._editAddDetailKey = "";
			ShipAndDebit._editAddCheckKey = "";
			ShipAndDebit._clearNewEditDetails();
			ShipAndDebit.CheckNewEditLine();
		});
	},

	_validateEditDistDate: function (line) {
		var rawInvoiceDate = String(line ? line.invoiceDate
			: ShipAndDebit._$("#sd_e_add_invoice option:selected").attr("data-ymd") || "").replace(/\D/g, "");
		var distDate = ShipAndDebit._ymd("sd_e_add_dist_date");
		if (!/^\d{8}$/.test(rawInvoiceDate) || !/^\d{8}$/.test(distDate)) return false;
		var context = ShipAndDebit._editContext || {};
		var dateError = ShipAndDebit._claimDistDateError(context.claimMonthRaw, rawInvoiceDate, distDate);
		if (dateError) {
			Common.showPageMsg(ShipAndDebit.ROOT, dateError, "warning");
			return false;
		}
		var today = new Date();
		var todayYmd = String(today.getFullYear()) + String(today.getMonth() + 1).padStart(2, "0")
			+ String(today.getDate()).padStart(2, "0");
		if (distDate < rawInvoiceDate || distDate > todayYmd) {
			Common.showPageMsg(ShipAndDebit.ROOT,
				"Distributor invoice date must be on or after the 3M invoice date and cannot be later than today.", "warning");
			return false;
		}
		return true;
	},

	ShowEditDistDate: function () {
		var date = ShipAndDebit._$("#sd_e_add_dist_date");
		ShipAndDebit._editDatePicker(ShipAndDebit._$("#sd_e_add_invoice option:selected").attr("data-ymd") || "");
		if (date.data("datepicker")) date.datepicker("show");
		return false;
	},

	_clearNewEditDetails: function () {
		ShipAndDebit._$("#sd_e_add_avail,#sd_e_add_uom,#sd_e_add_sales,#sd_e_add_rc,#sd_e_add_price,#sd_e_add_tax,#sd_e_add_cgst,#sd_e_add_igst,#sd_e_add_freight,#sd_e_add_discount").val("");
		ShipAndDebit._$("#sd_e_add_value").val("0.00");
	},

	_clearNewEditLine: function () {
		ShipAndDebit._$("#sd_e_add_product,#sd_e_add_sku,#sd_e_add_invoice,#sd_e_add_inv_date,#sd_e_add_dist_inv,#sd_e_add_dist_date,#sd_e_add_qty").val("");
		if (ShipAndDebit._$("#sd_e_add_dist_date").data("datepicker")) {
			ShipAndDebit._$("#sd_e_add_dist_date").datepicker("clearDates");
		}
		ShipAndDebit._clearNewEditDetails();
		ShipAndDebit._editAddDetail = null;
		ShipAndDebit._editAddDetailKey = "";
		ShipAndDebit._editAddCheckKey = "";
		ShipAndDebit._editIndex = -1;
		ShipAndDebit._$("#sd_e_add_product,#sd_e_add_invoice").prop("disabled", false);
		ShipAndDebit._$("#sd_e_add_line").prop("disabled", false);
		ShipAndDebit._$("#sd_e_add_line").html("<i class='ri-add-line' aria-hidden='true'></i> Add");
		ShipAndDebit._$("#sd_edit_entry_hint").text("Select a product and invoice, then enter distributor invoice details and quantity.");
	},

	_paintNewEditValue: function () {
		if (ShipAndDebit._editIndex >= 0) {
			var current = (ShipAndDebit._editRows || [])[ShipAndDebit._editIndex];
			var currentQty = ShipAndDebit._number(ShipAndDebit._$("#sd_e_add_qty").val());
			var baseQty = ShipAndDebit._number(current && current.originalQty);
			if (current && baseQty > 0) {
				ShipAndDebit._$("#sd_e_add_value").val(
					((ShipAndDebit._number(current.originalClaimValue) * currentQty) / baseQty).toFixed(2));
			}
			return;
		}
		var detail = ShipAndDebit._editAddDetail;
		var quantity = Number(String(ShipAndDebit._$("#sd_e_add_qty").val() || "").replace(/,/g, ""));
		if (!detail || !isFinite(quantity)) {
			ShipAndDebit._$("#sd_e_add_value").val("0.00");
			return;
		}
		ShipAndDebit._$("#sd_e_add_value").val(ShipAndDebit._newEditClaimValue(detail, quantity));
	},

	_validateEditQuantity: function () {
		var qtyText = $.trim(ShipAndDebit._$("#sd_e_add_qty").val() || "");
		if (!qtyText) return;
		var qty = Number(qtyText);
		if (!isFinite(qty) || qty <= 0 || !/^\d+(?:\.\d{1,2})?$/.test(qtyText)) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Enter a valid quantity with no more than 2 decimal places.", "warning");
			return;
		}
		var line = ShipAndDebit._editIndex >= 0
			? (ShipAndDebit._editRows || [])[ShipAndDebit._editIndex] : null;
		var sku = line ? line.sku : String(ShipAndDebit._$("#sd_e_add_product").val() || "").trim();
		var invoice = line ? line.invoiceNumber : String(ShipAndDebit._$("#sd_e_add_invoice").val() || "").trim();
		var available = line ? ShipAndDebit._number(line.availQty)
			: ShipAndDebit._number(ShipAndDebit._editAddDetail && ShipAndDebit._editAddDetail.AQTY);
		if (!sku || !invoice || !available) return;
		var used = 0;
		(ShipAndDebit._editRows || []).forEach(function (other, index) {
			if (line && index === ShipAndDebit._editIndex) return;
			if (String(other.sku || "").trim() === sku && String(other.invoiceNumber || "").trim() === invoice) {
				used += ShipAndDebit._number(other.distBillQty);
			}
		});
		if (qty > available || used + qty > available) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Stock Code: " + sku + ". Available Qty: " + available
				+ ". Total Billed Quantity: " + (used + qty) + ". Kindly Modify Distributor Billed Quantity.", "warning");
		}
	},

	_newEditClaimValue: function (detail, quantity) {
		var difference = quantity * (ShipAndDebit._number(detail.RCPRICE) - ShipAndDebit._number(detail.DISTPPRICE));
		var freight = difference * ShipAndDebit._number(detail.FRIEGHT) / 100;
		var discount = difference * ShipAndDebit._number(detail.DISCOUNT) / 100;
		var tax = difference * ShipAndDebit._number(detail.TAX) / 100;
		var extraTax = 0;
		var taxType = String(detail.VATCST || "").trim().toUpperCase();
		if (taxType === "SGST" || taxType === "UGST" || taxType === "IGST") {
			tax = difference * (ShipAndDebit._number(detail.TAX) + ShipAndDebit._number(detail.CGST)
				+ ShipAndDebit._number(detail.IGST)) / 100;
			extraTax = (freight + discount) * ShipAndDebit._number(detail.extTaxPc) / 100;
		} else if (taxType === "VAT") {
			tax = (difference + freight + discount) * ShipAndDebit._number(detail.TAX) / 100;
		} else if (taxType === "CST") {
			tax = (difference + discount) * ShipAndDebit._number(detail.TAX) / 100;
		}
		if (new Date() > new Date(2017, 6, 25) && (taxType === "VAT" || taxType === "CST")) {
			tax = 0;
			extraTax = 0;
		}
		return (difference + tax + freight + discount + extraTax).toFixed(2);
	},

	_newEditLineMatches: function (sku, invoice, distInvoice, distDate) {
		return String(ShipAndDebit._$("#sd_e_add_product").val() || "").trim() === sku
			&& String(ShipAndDebit._$("#sd_e_add_invoice").val() || "").trim() === invoice
			&& $.trim(ShipAndDebit._$("#sd_e_add_dist_inv").val() || "") === distInvoice
			&& ShipAndDebit._ymd("sd_e_add_dist_date") === distDate;
	},

	CheckNewEditLine: function (done) {
		if (ShipAndDebit._editIndex >= 0) return false;
		var lookupToken = ShipAndDebit._editLookupToken;
		var sku = String(ShipAndDebit._$("#sd_e_add_product").val() || "").trim();
		var invoice = String(ShipAndDebit._$("#sd_e_add_invoice").val() || "").trim();
		var invoiceDate = ShipAndDebit._$("#sd_e_add_invoice option:selected").attr("data-ymd") || "";
		var distInvoice = $.trim(ShipAndDebit._$("#sd_e_add_dist_inv").val() || "");
		var distDate = ShipAndDebit._ymd("sd_e_add_dist_date");
		if (!sku || !invoice || !distInvoice || !/^\d{8}$/.test(distDate)) return false;
		var today = new Date();
		var todayYmd = String(today.getFullYear()) + String(today.getMonth() + 1).padStart(2, "0")
			+ String(today.getDate()).padStart(2, "0");
		var month = (ShipAndDebit._editContext || {}).claimMonthRaw || "";
		if (!/^\d{8}$/.test(invoiceDate) || distDate > todayYmd || distDate < invoiceDate) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Distributor invoice date must be on or after the 3M invoice date and cannot be later than today.", "warning");
			return false;
		}
		var dateError = ShipAndDebit._claimDistDateError(month, invoiceDate, distDate);
		if (dateError) {
			Common.showPageMsg(ShipAndDebit.ROOT, dateError, "warning");
			return false;
		}
		if (month && invoiceDate.substr(0, 6) > month) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Select a 3M invoice dated within the claim month.", "warning");
			return false;
		}
		var key = [sku, invoice, invoiceDate, distInvoice, distDate].join("|");
		if (ShipAndDebit._editAddDetail && ShipAndDebit._editAddDetailKey === key) {
			if (typeof done === "function") done(ShipAndDebit._editAddDetail);
			return true;
		}
		if (ShipAndDebit._editAddCheckKey === key) return false;
		ShipAndDebit._editAddCheckKey = key;
		ShipAndDebit._$("#sd_e_add_line").prop("disabled", true);
		var query = "/claim-check?sku=" + encodeURIComponent(sku)
			+ "&invoiceNumber=" + encodeURIComponent(invoice)
			+ "&invoiceDate=" + encodeURIComponent(invoiceDate)
			+ "&distInvoiceNumber=" + encodeURIComponent(distInvoice)
			+ "&distInvoiceDate=" + encodeURIComponent(distDate);
		ShipAndDebit._get(query, function (checked) {
			if (lookupToken !== ShipAndDebit._editLookupToken) return;
			if (!ShipAndDebit._newEditLineMatches(sku, invoice, distInvoice, distDate)) {
				ShipAndDebit._$("#sd_e_add_line").prop("disabled", false);
				ShipAndDebit._editAddCheckKey = "";
				return;
			}
			var posDate = String((checked && checked.posInvDate) || "").replace(/\D/g, "");
			if (posDate && distDate > posDate) {
				ShipAndDebit._$("#sd_e_add_line").prop("disabled", false);
				ShipAndDebit._editAddCheckKey = "";
				Common.showPageMsg(ShipAndDebit.ROOT, "POS data is collected till " + posDate
					+ ". Claims can be submitted only till this period.", "warning");
				return;
			}
			if (checked && String(checked.claimStatus || "").trim().toUpperCase() === "Y") {
				ShipAndDebit._$("#sd_e_add_line").prop("disabled", false);
				ShipAndDebit._editAddCheckKey = "";
				Common.showPageMsg(ShipAndDebit.ROOT, "A claim is already raised for this stock code and invoice"
					+ (checked.claimNumber ? " (claim " + checked.claimNumber + ")." : "."), "warning");
				return;
			}
			var context = ShipAndDebit._editContext || {};
			ShipAndDebit._get("/invoice-details?endCustomer=" + encodeURIComponent(context.endCustomerCode || "")
				+ "&sku=" + encodeURIComponent(sku)
				+ "&invoiceNumber=" + encodeURIComponent(invoice)
				+ "&invoiceDate=" + encodeURIComponent(invoiceDate)
				+ "&distInvoiceDate=" + encodeURIComponent(distDate), function (result) {
				if (lookupToken !== ShipAndDebit._editLookupToken) return;
				ShipAndDebit._$("#sd_e_add_line").prop("disabled", false);
				ShipAndDebit._editAddCheckKey = "";
				if (!ShipAndDebit._newEditLineMatches(sku, invoice, distInvoice, distDate)) {
					ShipAndDebit._editAddDetail = null;
					return;
				}
				result = result || {};
				ShipAndDebit._editAddDetail = result;
				ShipAndDebit._editAddDetailKey = key;
				ShipAndDebit._$("#sd_e_add_avail").val(result.AQTY || "");
				ShipAndDebit._$("#sd_e_add_uom").val(result.UMO || "");
				ShipAndDebit._$("#sd_e_add_sales").val(result.SPERSON || "");
				ShipAndDebit._$("#sd_e_add_rc").val(result.RCPRICE || "");
				ShipAndDebit._$("#sd_e_add_price").val(result.DISTPPRICE || "");
				ShipAndDebit._$("#sd_e_add_tax").val(result.TAX || "");
				ShipAndDebit._$("#sd_e_add_cgst").val(result.CGST || "");
				ShipAndDebit._$("#sd_e_add_igst").val(result.IGST || "");
				ShipAndDebit._$("#sd_e_add_freight").val(result.FRIEGHT || "");
				ShipAndDebit._$("#sd_e_add_discount").val(result.DISCOUNT || "");
				ShipAndDebit._paintNewEditValue();
				ShipAndDebit.HideMsg();
				if (typeof done === "function") done(ShipAndDebit._editAddDetail);
			}, function () {
				if (lookupToken !== ShipAndDebit._editLookupToken) return;
				ShipAndDebit._$("#sd_e_add_line").prop("disabled", false);
				ShipAndDebit._editAddCheckKey = "";
			});
		}, function () {
			if (lookupToken !== ShipAndDebit._editLookupToken) return;
			ShipAndDebit._$("#sd_e_add_line").prop("disabled", false);
			ShipAndDebit._editAddCheckKey = "";
		});
		return false;
	},

	AddNewLine: function () {
		var sku = String(ShipAndDebit._$("#sd_e_add_product").val() || "").trim();
		var invoice = String(ShipAndDebit._$("#sd_e_add_invoice").val() || "").trim();
		var invoiceDate = ShipAndDebit._$("#sd_e_add_invoice option:selected").attr("data-ymd") || "";
		var distInvoice = $.trim(ShipAndDebit._$("#sd_e_add_dist_inv").val() || "");
		var distDate = ShipAndDebit._ymd("sd_e_add_dist_date");
		var qtyText = $.trim(ShipAndDebit._$("#sd_e_add_qty").val() || "");
		var qty = Number(qtyText.replace(/,/g, ""));
		if (!sku || !invoice || !distInvoice || !/^\d{8}$/.test(distDate) || !qtyText || !isFinite(qty) || qty <= 0
			|| !/^\d+(?:\.\d{1,2})?$/.test(qtyText)) {
			Common.showPageMsg(ShipAndDebit.ROOT,
				"Select a product and invoice, then enter distributor invoice number, date, and a valid quantity.", "warning");
			return false;
		}
		if ((ShipAndDebit._editRows || []).length >= 35) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Maximum 35 lines can be added per claim.", "warning");
			return false;
		}
		var detail = ShipAndDebit._editAddDetail;
		if (!detail || !ShipAndDebit._editAddDetailKey) {
			ShipAndDebit.CheckNewEditLine(function (checkedDetail) {
				if (checkedDetail) ShipAndDebit.AddNewLine();
			});
			return false;
		}
		ShipAndDebit._appendNewEditLine(detail, sku, invoice, invoiceDate, distInvoice, distDate, qty, qtyText);
		return false;
	},

	_appendNewEditLine: function (detail, sku, invoice, invoiceDate, distInvoice, distDate, qty, qtyText) {
		var available = ShipAndDebit._number(detail.AQTY);
		var used = 0;
		(ShipAndDebit._editRows || []).forEach(function (line) {
			if (String(line.sku || "").trim() === sku && String(line.invoiceNumber || "").trim() === invoice) {
				used += ShipAndDebit._number(line.distBillQty);
			}
		});
		if (available <= 0 || used + qty > available) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Stock Code: " + sku + ". Available Qty: " + available
				+ ". Total Billed Quantity: " + (used + qty) + ". Kindly Modify Distributor Billed Quantity.", "warning");
			return;
		}
		var $selectedProduct = ShipAndDebit._$("#sd_e_add_product option:selected");
		var description = $selectedProduct.attr("data-description") || $selectedProduct.text() || "";
		var claimValue = ShipAndDebit._newEditClaimValue(detail, qty);
		var newLine = {
			sku: sku, description: description, invoiceNumber: invoice, invoiceDate: invoiceDate,
			uom: detail.UMO || "", availQty: detail.AQTY || "", salesPerson: detail.SPERSON || "",
			rcPrice: detail.RCPRICE || "", distInvoiceNumber: distInvoice, distInvoiceDate: distDate,
			distBillQty: qtyText, distBillPrice: detail.DISTPPRICE || "",
			claimValue: claimValue,
			taxRate: detail.TAX || "", taxType: detail.VATCST || "", cgst: detail.CGST || "",
			igst: detail.IGST || "", freight: detail.FRIEGHT || "", discount: detail.DISCOUNT || "",
			extraTax: detail.extTaxPc || "", lineComments: "", action: "I", isNewLine: true
		};
		ShipAndDebit._editRows.push(newLine);
		ShipAndDebit._clearNewEditLine();
		ShipAndDebit._paintEditLines();
		ShipAndDebit._fillEditTotal();
		ShipAndDebit.HideMsg();
	},

	SaveLine: function () {
		var index = ShipAndDebit._editIndex;
		var line = (ShipAndDebit._editRows || [])[index];
		if (!line) return false;
		var invoice = $.trim(ShipAndDebit._$("#sd_e_add_invoice").val() || "");
		var distInvoice = $.trim(ShipAndDebit._$("#sd_e_add_dist_inv").val() || "");
		var distDate = ShipAndDebit._ymd("sd_e_add_dist_date");
		var qty = $.trim(ShipAndDebit._$("#sd_e_add_qty").val() || "");
		if (!invoice || !distInvoice || !/^\d{8}$/.test(distDate) || !qty) {
			Common.showPageMsg(ShipAndDebit.ROOT,
				"Enter distributor invoice number, invoice date, and quantity before saving.", "warning");
			return false;
		}
		var billed = Number(String(qty).replace(/,/g, ""));
		var available = ShipAndDebit._number(line.availQty);
		if (!isFinite(billed) || billed <= 0 || !/^\d+(?:\.\d{1,2})?$/.test(qty)) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Enter a valid quantity with no more than 2 decimal places.", "warning");
			return false;
		}
		if (!ShipAndDebit._validateEditDistDate(line)) return false;
		var used = 0;
		(ShipAndDebit._editRows || []).forEach(function (other, otherIndex) {
			if (otherIndex === index) return;
			if (String(other.sku || "").trim() === String(line.sku || "").trim()
				&& String(other.invoiceNumber || "").trim() === invoice) {
				used += ShipAndDebit._number(other.distBillQty);
			}
		});
		if (available <= 0 || billed > available || used + billed > available) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Stock Code: " + line.sku + ". Available Qty: " + available
				+ ". Total Billed Quantity: " + (used + billed) + ". Kindly Modify Distributor Billed Quantity.", "warning");
			return false;
		}
		var oldQty = Number(line.originalQty);
		var newQty = billed;
		if (oldQty) line.claimValue = ((Number(String(line.originalClaimValue).replace(/,/g, "")) || 0) * newQty / oldQty).toFixed(2);
		line.invoiceNumber = invoice;
		line.distInvoiceNumber = distInvoice;
		line.distInvoiceDate = distDate;
		line.distBillQty = qty;
		line.action = line.action === "I" ? "I" : "U";
		ShipAndDebit._clearNewEditLine();
		ShipAndDebit._paintEditLines();
		ShipAndDebit._fillEditTotal();
		return false;
	},

	SaveStockEntry: function () {
		return ShipAndDebit._editIndex >= 0 ? ShipAndDebit.SaveLine() : ShipAndDebit.AddNewLine();
	},

	DeleteLine: function (index) {
		var line = (ShipAndDebit._editRows || [])[index];
		if (!line) return false;
		var remove = function () {
			line.action = "D";
			if (!line.isNewLine) ShipAndDebit._editDeleted.push(line);
			ShipAndDebit._editRows.splice(index, 1);
			if (ShipAndDebit._editIndex === index) {
				ShipAndDebit._clearNewEditLine();
			} else if (ShipAndDebit._editIndex > index) {
				ShipAndDebit._editIndex--;
			}
			ShipAndDebit._paintEditLines();
			ShipAndDebit._fillEditTotal();
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this line?",
				text: "The line is removed from the claim when you click OK.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "OK",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#d33",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) remove();
			});
			if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
		} else if (window.confirm("Delete this line?")) {
			remove();
		}
		return false;
	},

	_validateDocumentFiles: function (files) {
		var allowed = /\.(zip|7z|jpe?g|png|gif|pdf|tiff?|bmp|bpg|fax|img)$/i;
		for (var i = 0; i < files.length; i++) {
			var file = files[i];
			if (!allowed.test(file.name || "")) return "Only images, PDF, ZIP, or 7Z documents are allowed.";
			if (!file.size) return "Selected documents cannot be empty.";
			var safeName = ShipAndDebit._safeDocumentFileName(file.name);
			if (!safeName) {
				return "A selected document has an invalid filename. Rename it and try again.";
			}
			if (file.size > ShipAndDebit.DOC_REQUEST_FILE_LIMIT_BYTES) {
				return "Each document must be 4.5 MB or smaller. Larger files cannot fit within the 5 MB request limit.";
			}
		}
		return "";
	},

	_safeDocumentFileName: function (name) {
		var safeName = String(name || "").replace(/^.*[\\/]/, "").replace(/[^A-Za-z0-9._-]/g, "_");
		return !safeName || safeName.length > 120 || safeName.indexOf("..") >= 0 ? "" : safeName;
	},

	_clearEditDocumentQueue: function () {
		(ShipAndDebit._editDocumentQueue || []).forEach(function (entry) {
			if (entry.url) window.URL.revokeObjectURL(entry.url);
		});
		ShipAndDebit._editDocumentQueue = [];
		ShipAndDebit._renderEditDocuments();
	},

	_bindEditDocuments: function () {
		var $detail = ShipAndDebit._$("#sd_edit_detail");
		var $uploadModal = ShipAndDebit._$("#sd_edit_upload_modal");
		$detail.off("click.sdEditDocs", "#sd_edit_browse_files")
			.on("click.sdEditDocs", "#sd_edit_browse_files", function () {
				ShipAndDebit._$("#sd_edit_file").trigger("click");
			});
		$detail.off("change.sdEditDocs", "#sd_edit_file")
			.on("change.sdEditDocs", "#sd_edit_file", function () {
				ShipAndDebit._addEditDocuments(this.files);
				this.value = "";
			});
		$detail.off("click.sdEditDocs", "[data-sd-edit-remove-file]")
			.on("click.sdEditDocs", "[data-sd-edit-remove-file]", function () {
				ShipAndDebit._removeEditDocument(Number(this.getAttribute("data-sd-edit-remove-file")));
			});
		$detail.off("click.sdEditDocs", "[data-sd-edit-view-file]")
			.on("click.sdEditDocs", "[data-sd-edit-view-file]", function (event) {
				event.preventDefault();
				var entry = ShipAndDebit._editDocumentQueue[Number(this.getAttribute("data-sd-edit-view-file"))];
				if (entry && entry.url) window.open(entry.url, "_blank", "noopener");
			});
		$detail.off("click.sdEditDocs", "[data-sd-delete-existing]")
			.on("click.sdEditDocs", "[data-sd-delete-existing]", function () {
				ShipAndDebit._confirmDeleteStoredDocument(Number(this.getAttribute("data-sd-delete-existing")));
			});
		$detail.off("click.sdEditDocs", "#sd_edit_upload_only")
			.on("click.sdEditDocs", "#sd_edit_upload_only", function () {
				ShipAndDebit._openEditUploadModal();
			});
		$uploadModal.off("click.sdEditUploadOnly", "#sd_edit_upload_browse")
			.on("click.sdEditUploadOnly", "#sd_edit_upload_browse", function () {
				ShipAndDebit._$("#sd_edit_upload_picker").trigger("click");
			});
		$uploadModal.off("change.sdEditUploadOnly", "#sd_edit_upload_picker")
			.on("change.sdEditUploadOnly", "#sd_edit_upload_picker", function () {
				ShipAndDebit._addEditUploadOnlyDocuments(this.files);
				this.value = "";
			});
		$uploadModal.off("click.sdEditUploadOnly", "[data-sd-edit-upload-remove]")
			.on("click.sdEditUploadOnly", "[data-sd-edit-upload-remove]", function () {
				ShipAndDebit._removeEditUploadOnlyDocument(Number(this.getAttribute("data-sd-edit-upload-remove")));
			});
		$uploadModal.off("click.sdEditUploadOnly", "[data-sd-edit-upload-view]")
			.on("click.sdEditUploadOnly", "[data-sd-edit-upload-view]", function (event) {
				event.preventDefault();
				var entry = ShipAndDebit._editUploadOnlyQueue[Number(this.getAttribute("data-sd-edit-upload-view"))];
				if (entry && entry.url) window.open(entry.url, "_blank", "noopener");
			});
		$uploadModal.off("click.sdEditUploadOnly", "[data-sd-delete-existing]")
			.on("click.sdEditUploadOnly", "[data-sd-delete-existing]", function () {
				ShipAndDebit._confirmDeleteStoredDocument(Number(this.getAttribute("data-sd-delete-existing")));
			});
		$uploadModal.off("click.sdEditUploadOnly", "#sd_edit_upload_start")
			.on("click.sdEditUploadOnly", "#sd_edit_upload_start", function () {
				ShipAndDebit._startEditUploadOnly();
			});
	},

	_openEditUploadModal: function () {
		var claimNumber = String(ShipAndDebit._openClaimNumber || "").trim();
		var modal = ShipAndDebit._el("#sd_edit_upload_modal");
		if (!claimNumber || ShipAndDebit._editSaveInProgress || ShipAndDebit._editUploadOnlyRunning
				|| !modal || !window.bootstrap || !bootstrap.Modal) return;
		if (modal.parentNode !== document.body) document.body.appendChild(modal);
		modal.style.zIndex = "2085";
		if (!modal.dataset.sdUploadLayerBound) {
			modal.addEventListener("shown.bs.modal", function () {
				var backdrops = document.querySelectorAll(".modal-backdrop");
				if (backdrops.length) backdrops[backdrops.length - 1].style.zIndex = "2080";
			});
			modal.dataset.sdUploadLayerBound = "true";
		}
		ShipAndDebit._$("#sd_edit_upload_claim").text(claimNumber);
		ShipAndDebit._$("#sd_edit_upload_start").prop("disabled", true);
		ShipAndDebit._showDocumentError("#sd_edit_upload_error", "");
		ShipAndDebit._editUploadOnlyListReady = false;
		ShipAndDebit._$("#sd_edit_upload_existing").html("<div class='text-muted'>Loading stored documents...</div>");
		ShipAndDebit._renderEditUploadOnlyDocuments();
		bootstrap.Modal.getOrCreateInstance(modal).show();
		ShipAndDebit._files(claimNumber, function (names) {
			if (claimNumber !== ShipAndDebit._openClaimNumber) return;
			ShipAndDebit._editStoredDocuments = names || [];
			ShipAndDebit._editUploadOnlyListReady = true;
			ShipAndDebit._reconcileEditUploadOnlyQueue();
			ShipAndDebit._renderEditUploadOnlyExisting();
			ShipAndDebit._renderEditUploadOnlyDocuments();
			ShipAndDebit._$("#sd_edit_upload_start").prop("disabled",
				!ShipAndDebit._editUploadOnlyQueue.some(function (entry) { return entry.status !== "done"; }));
		}, function () {
			ShipAndDebit._$("#sd_edit_upload_existing").html(
				"<div class='text-danger'>Stored documents could not be loaded. Close and reopen this window to try again.</div>");
		});
	},

	_editStoredNameKey: function (name, claimNumber) {
		var key = String(name || "").toLowerCase();
		var prefix = String(claimNumber || "").toLowerCase() + "_";
		return key.indexOf(prefix) === 0 ? key.slice(prefix.length) : key;
	},

	_confirmDeleteStoredDocument: function (index) {
		var name = (ShipAndDebit._editStoredDocuments || [])[index];
		var claimNumber = String(ShipAndDebit._openClaimNumber || "").trim();
		if (!name || !claimNumber) return false;
		var remove = function () {
			var body = ShipAndDebit._context();
			body.claimNumber = claimNumber;
			body.name = name;
			ShipAndDebit._post("/documents/delete", body, function () {
				Common.showPageMsg(ShipAndDebit.ROOT, "Document " + name + " was deleted from claim " + claimNumber + ".", "success");
				ShipAndDebit._files(claimNumber);
			});
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this document?",
				text: name + " will be permanently deleted from the claim folder.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "Delete",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#b42318"
			}).then(function (result) {
				if (result && result.isConfirmed) remove();
			});
			if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
		} else if (window.confirm("Permanently delete " + name + " from this claim?")) {
			remove();
		}
		return false;
	},

	_reconcileEditUploadOnlyQueue: function () {
		var claimNumber = ShipAndDebit._openClaimNumber;
		var stored = {};
		(ShipAndDebit._editStoredDocuments || []).forEach(function (name) {
			stored[ShipAndDebit._editStoredNameKey(name, claimNumber)] = true;
		});
		(ShipAndDebit._editUploadOnlyQueue || []).forEach(function (entry) {
			if (stored[ShipAndDebit._editStoredNameKey(entry.file.name, claimNumber)]) entry.status = "done";
		});
	},

	_addEditUploadOnlyDocuments: function (fileList) {
		var added = Array.prototype.slice.call(fileList || []);
		if (!added.length) return;
		var queue = ShipAndDebit._editUploadOnlyQueue || [];
		var remaining = queue.filter(function (entry) { return entry.status !== "done"; });
		var validation = ShipAndDebit._validateDocumentFiles(remaining.map(function (entry) {
			return entry.file;
		}).concat(added));
		if (validation) {
			ShipAndDebit._showDocumentError("#sd_edit_upload_error", validation);
			return;
		}
		ShipAndDebit._showDocumentError("#sd_edit_upload_error", "");
		added.forEach(function (file) {
			queue.push({ file: file, status: "pending", url: window.URL.createObjectURL(file) });
		});
		ShipAndDebit._editUploadOnlyQueue = queue;
		ShipAndDebit._renderEditUploadOnlyDocuments();
	},

	_removeEditUploadOnlyDocument: function (index) {
		var entry = ShipAndDebit._editUploadOnlyQueue[index];
		if (!entry || entry.status === "done" || ShipAndDebit._editUploadOnlyRunning) return;
		if (entry.url) window.URL.revokeObjectURL(entry.url);
		ShipAndDebit._editUploadOnlyQueue.splice(index, 1);
		ShipAndDebit._renderEditUploadOnlyDocuments();
		ShipAndDebit._showDocumentError("#sd_edit_upload_error", "");
	},

	_renderEditUploadOnlyDocuments: function () {
		var queue = ShipAndDebit._editUploadOnlyQueue || [];
		var html = "";
		if (!queue.length) html = "<tr><td colspan='5' class='text-muted'>No files selected.</td></tr>";
		queue.forEach(function (entry, index) {
			var status = entry.status === "done" ? "Already uploaded" : entry.status === "failed" ? "Failed"
				: entry.status === "uploading" ? "In progress" : "Ready";
			html += "<tr><td class='text-center'>" + (index + 1) + "</td><td class='sd-file-name'>"
				+ ShipAndDebit._esc(entry.file.name) + "</td>"
				+ "<td class='text-nowrap'>" + ShipAndDebitCreate._formatSize(entry.file.size) + "</td><td>" + status + "</td><td class='text-nowrap'>"
				+ (entry.url ? "<button type='button' class='btn btn-sm btn-outline-primary me-1' data-sd-edit-upload-view='"
					+ index + "' title='View " + ShipAndDebit._esc(entry.file.name) + "' aria-label='View " + ShipAndDebit._esc(entry.file.name)
					+ "'><i class='ri-eye-line' aria-hidden='true'></i></button>" : "")
				+ "<button type='button' class='btn btn-sm btn-outline-danger' data-sd-edit-upload-remove='"
				+ index + "' title='Remove " + ShipAndDebit._esc(entry.file.name) + "' aria-label='Remove "
				+ ShipAndDebit._esc(entry.file.name) + "'"
				+ (entry.status === "done" || ShipAndDebit._editUploadOnlyRunning ? " disabled" : "")
				+ "><i class='ri-delete-bin-line' aria-hidden='true'></i></button></td></tr>";
		});
		ShipAndDebit._$("#sd_edit_upload_selected").html(html);
		var hasPending = queue.some(function (entry) { return entry.status !== "done"; });
		ShipAndDebit._$("#sd_edit_upload_start")
			.prop("disabled", !hasPending || ShipAndDebit._editUploadOnlyRunning || !ShipAndDebit._editUploadOnlyListReady)
			.text(queue.some(function (entry) { return entry.status === "failed"; }) ? "Retry failed uploads" : "Upload documents");
	},

	_renderEditUploadOnlyExisting: function () {
		var names = ShipAndDebit._editStoredDocuments || [];
		var claimNumber = ShipAndDebit._openClaimNumber;
		var context = ShipAndDebit._context();
		var html = "<div class='table-responsive'><table class='table table-sm table-bordered mb-0 sd-document-table'>"
			+ "<thead><tr><th>Sl No</th><th>File</th><th>Actions</th></tr></thead><tbody>";
		if (!names.length) html += "<tr><td colspan='3' class='text-muted'>No documents stored for this claim.</td></tr>";
		names.forEach(function (name, index) {
			html += "<tr><td class='text-center'>" + (index + 1) + "</td><td class='sd-file-name'>" + ShipAndDebit._esc(name) + "</td><td>"
				+ "<a class='btn btn-sm btn-outline-primary' target='_blank' rel='noopener' title='View "
				+ ShipAndDebit._esc(name) + "' aria-label='View " + ShipAndDebit._esc(name) + "' href='"
				+ (window.$app_url || "") + ShipAndDebit._api + "/documents?name="
				+ encodeURIComponent(name) + "&claimNumber=" + encodeURIComponent(claimNumber)
				+ "&custCode=" + encodeURIComponent(context.custCode)
				+ "&loginId=" + encodeURIComponent(context.loginId) + "'><i class='ri-eye-line' aria-hidden='true'></i></a> "
				+ "<button type='button' class='btn btn-sm btn-outline-danger' data-sd-delete-existing='" + index
				+ "' title='Delete " + ShipAndDebit._esc(name) + "' aria-label='Delete " + ShipAndDebit._esc(name)
				+ "'><i class='ri-delete-bin-line' aria-hidden='true'></i></button></td></tr>";
		});
		html += "</tbody></table></div>";
		ShipAndDebit._$("#sd_edit_upload_existing").html(html);
	},

	_clearEditUploadOnlyQueue: function () {
		(ShipAndDebit._editUploadOnlyQueue || []).forEach(function (entry) {
			if (entry.url) window.URL.revokeObjectURL(entry.url);
		});
		ShipAndDebit._editUploadOnlyQueue = [];
		ShipAndDebit._editUploadOnlyRunning = false;
		ShipAndDebit._renderEditUploadOnlyDocuments();
	},

	_startEditUploadOnly: function () {
		var claimNumber = String(ShipAndDebit._openClaimNumber || "").trim();
		var queue = (ShipAndDebit._editUploadOnlyQueue || []).filter(function (entry) { return entry.status !== "done"; });
		if (!claimNumber || !queue.length || ShipAndDebit._editUploadOnlyRunning || ShipAndDebit._editSaveInProgress) return false;
		var validation = ShipAndDebit._validateDocumentFiles(queue.map(function (entry) { return entry.file; }));
		if (validation) {
			ShipAndDebit._showDocumentError("#sd_edit_upload_error", validation);
			return false;
		}
		ShipAndDebit._showDocumentError("#sd_edit_upload_error", "");
		ShipAndDebit._reconcileEditUploadOnlyQueue();
		queue = (ShipAndDebit._editUploadOnlyQueue || []).filter(function (entry) { return entry.status !== "done"; });
		if (!queue.length) {
			ShipAndDebit._renderEditUploadOnlyDocuments();
			return false;
		}
		ShipAndDebit._editUploadOnlyRunning = true;
		ShipAndDebit._$("#sd_edit_update").prop("disabled", true);
		ShipAndDebit._$("#sd_edit_upload_only").prop("disabled", true);
		ShipAndDebit._renderEditUploadOnlyDocuments();
		var modal = ShipAndDebit._el("#sd_edit_upload_modal");
		var start = function () {
			ShipAndDebit._startDocumentProgress(claimNumber, "documents-only", queue, function (uploaded) {
				ShipAndDebit._editUploadOnlyRunning = false;
				ShipAndDebit._$("#sd_edit_update").prop("disabled", false);
				ShipAndDebit._$("#sd_edit_upload_only").prop("disabled", false);
				if (uploaded) {
					ShipAndDebit._clearEditUploadOnlyQueue();
					ShipAndDebit._files(claimNumber);
					Common.showPageMsg(ShipAndDebit.ROOT, "Supporting documents uploaded for claim " + claimNumber + ".", "success");
				} else {
					ShipAndDebit._renderEditUploadOnlyDocuments();
					Common.showPageMsg(ShipAndDebit.ROOT,
						"One or more documents could not be uploaded for claim " + claimNumber + ". Retry the failed uploads.", "warning");
				}
			}, {
				title: "Uploading documents for claim " + claimNumber,
				runningMessage: "Uploading documents for claim " + claimNumber + "...",
				failedMessage: "Some documents failed for claim " + claimNumber + "; retry failed uploads or close this window.",
				pendingMessage: "Preparing document uploads for claim " + claimNumber + "...",
				completeMessage: "All documents uploaded for claim " + claimNumber + ". You can close this window now."
			});
		};
		if (modal && window.bootstrap && bootstrap.Modal) {
			modal.addEventListener("hidden.bs.modal", start, { once: true });
			bootstrap.Modal.getOrCreateInstance(modal).hide();
		} else {
			start();
		}
		return false;
	},

	_addEditDocuments: function (fileList) {
		var added = Array.prototype.slice.call(fileList || []);
		if (!added.length) return;
		var queue = ShipAndDebit._editDocumentQueue || [];
		var remaining = queue.filter(function (entry) { return entry.status !== "done"; });
		var validation = ShipAndDebit._validateDocumentFiles(remaining.map(function (entry) {
			return entry.file;
		}).concat(added));
		if (validation) {
			ShipAndDebit._showDocumentError("#sd_edit_document_error", validation);
			return;
		}
		ShipAndDebit._showDocumentError("#sd_edit_document_error", "");
		added.forEach(function (file) {
			queue.push({ file: file, status: "pending", url: window.URL.createObjectURL(file) });
		});
		ShipAndDebit._editDocumentQueue = queue;
		ShipAndDebit._renderEditDocuments();
	},

	_removeEditDocument: function (index) {
		var entry = ShipAndDebit._editDocumentQueue[index];
		if (!entry || entry.status === "done" || ShipAndDebit._editSaveInProgress) return;
		if (entry.url) window.URL.revokeObjectURL(entry.url);
		ShipAndDebit._editDocumentQueue.splice(index, 1);
		ShipAndDebit._renderEditDocuments();
		ShipAndDebit._showDocumentError("#sd_edit_document_error", "");
	},

	_renderEditDocuments: function () {
		var files = ShipAndDebit._editDocumentQueue || [];
		var html = "";
		if (!files.length) html = "<tr><td colspan='5' class='text-muted'>No new documents selected.</td></tr>";
		files.forEach(function (entry, index) {
			var status = entry.status === "done" ? "Uploaded" : entry.status === "failed" ? "Upload failed"
				: entry.status === "uploading" ? "Uploading" : "Ready";
			var removeDisabled = entry.status === "done" || ShipAndDebit._editSaveInProgress ? " disabled" : "";
			html += "<tr><td class='text-center'>" + (index + 1) + "</td><td class='sd-file-name'>"
				+ ShipAndDebit._esc(entry.file.name) + "</td>"
				+ "<td class='text-nowrap'>" + ShipAndDebitCreate._formatSize(entry.file.size) + "</td>"
				+ "<td>" + status + "</td><td class='text-nowrap'>"
				+ (entry.url ? "<button type='button' class='btn btn-sm btn-outline-primary me-1' data-sd-edit-view-file='"
					+ index + "' title='View " + ShipAndDebit._esc(entry.file.name) + "' aria-label='View " + ShipAndDebit._esc(entry.file.name)
					+ "'><i class='ri-eye-line' aria-hidden='true'></i></button>" : "")
				+ "<button type='button' class='btn btn-sm btn-outline-danger' data-sd-edit-remove-file='"
				+ index + "' title='Remove " + ShipAndDebit._esc(entry.file.name) + "' aria-label='Remove "
				+ ShipAndDebit._esc(entry.file.name) + "'" + removeDisabled + "><i class='ri-delete-bin-line' aria-hidden='true'></i></button>"
				+ "</td></tr>";
		});
		ShipAndDebit._$("#sd_edit_selected_files").html(html);
		ShipAndDebit._$("#sd_retry_edit_docs").toggleClass("d-none",
			!files.some(function (entry) { return entry.status === "failed"; }));
	},

	_startDocumentProgress: function (claimNumber, operation, entries, afterClose, messages) {
		var modal = ShipAndDebit._el("#sd_doc_progress_modal");
		if (!modal || !window.bootstrap || !bootstrap.Modal) {
			Common.showPageMsg(ShipAndDebit.ROOT, messages && messages.title
				? messages.title + ". The document progress window is unavailable."
				: "Claim " + claimNumber + " was saved, but the document progress window is unavailable.", "warning");
			if (typeof afterClose === "function") afterClose(false);
			return;
		}
		if (modal.parentNode !== document.body) document.body.appendChild(modal);
		modal.style.zIndex = "2090";
		if (!modal.dataset.sdProgressBound) {
			modal.addEventListener("shown.bs.modal", function () {
				var backdrops = document.querySelectorAll(".modal-backdrop");
				if (backdrops.length) backdrops[backdrops.length - 1].style.zIndex = "2085";
			});
			modal.addEventListener("hide.bs.modal", function (event) {
				if (ShipAndDebit._docProgressState && ShipAndDebit._docProgressState.running) {
					event.preventDefault();
				}
			});
			modal.addEventListener("hidden.bs.modal", function () {
				var state = ShipAndDebit._docProgressState;
				if (!state) return;
				ShipAndDebit._docProgressState = null;
				if (typeof state.afterClose === "function") state.afterClose(state.success);
			});
			modal.dataset.sdProgressBound = "true";
		}
		var normalized = (entries || []).map(function (entry) {
			if (entry.file) {
				if (!entry.status) entry.status = "pending";
				return entry;
			}
			return { file: entry, status: "pending" };
		});
		ShipAndDebit._docProgressState = {
			claimNumber: claimNumber,
			operation: operation,
			entries: normalized,
			running: false,
			success: false,
			messages: messages || {},
			afterClose: afterClose
		};
		ShipAndDebit._$("#sd_doc_progress_title").text(
			messages && messages.title ? messages.title : "Your claim was " + operation + " successfully - Claim " + claimNumber);
		ShipAndDebit._$("#sd_doc_progress_footer_message").text("");
		ShipAndDebit._$("#sd_doc_progress_retry").off("click.sdDocProgress").on("click.sdDocProgress", function () {
			ShipAndDebit._runDocumentUploads();
		});
		ShipAndDebit._$("#sd_doc_progress_close").prop("disabled", false).text("Close");
		ShipAndDebit._$("#sd_doc_progress_footer_message").text(
			normalized.length ? "Preparing to upload " + normalized.length + " document(s)..." : "");
		ShipAndDebit._renderDocumentProgress();
		bootstrap.Modal.getOrCreateInstance(modal, { backdrop: "static", keyboard: false }).show();
		if (normalized.length) ShipAndDebit._runDocumentUploads();
		else {
			ShipAndDebit._docProgressState.success = true;
			ShipAndDebit._$("#sd_doc_progress_footer_message").text(
				"Claim " + claimNumber + " was saved. No supporting documents were selected. You can close this window now.");
		}
	},

	_renderDocumentProgress: function () {
		var state = ShipAndDebit._docProgressState;
		if (!state) return;
		var done = 0;
		var failed = 0;
		var pending = 0;
		var uploading = 0;
		var html = "";
		state.entries.forEach(function (entry) {
			var status = entry.status || "pending";
			if (status === "done") done++;
			else if (status === "failed") failed++;
			else if (status === "pending") pending++;
			else if (status === "uploading") uploading++;
			var label = status === "done" ? "Done" : status === "failed" ? "Failed"
				: status === "uploading" ? "In progress" : "Waiting";
			var icon = status === "done" ? "ri-check-line text-success"
				: status === "failed" ? "ri-error-warning-line text-danger"
				: status === "uploading" ? "ri-loader-4-line text-primary"
				: "ri-time-line text-muted";
			html += "<div class='list-group-item d-flex align-items-center gap-2'>"
				+ "<span class='text-truncate flex-grow-1'>" + ShipAndDebit._esc(entry.file.name)
				+ " <span class='sd-doc-progress-size'>(" + ShipAndDebitCreate._formatSize(entry.file.size) + ")</span></span>"
				+ "<span class='sd-doc-progress-status" + (status === "done" ? " is-done" : "") + "'><i class='" + icon + "' aria-hidden='true'></i> "
				+ label + "</span></div>";
		});
		ShipAndDebit._$("#sd_doc_progress_list").html(html);
		ShipAndDebit._$("#sd_doc_progress_retry").toggleClass("d-none", state.running || !failed);
		ShipAndDebit._$("#sd_doc_progress_close").prop("disabled", state.running)
			.text(state.running ? "Uploading..." : "Close");
		var message;
		if (state.running) {
			var activeIndex = state.entries.findIndex(function (entry) { return entry.status === "uploading"; });
			var active = activeIndex >= 0 ? state.entries[activeIndex] : null;
			message = "Uploading batch " + state.currentBatch + " of " + state.totalBatches
				+ " (" + uploading + " document" + (uploading === 1 ? "" : "s") + ")...";
			if (uploading === 1 && active) {
				message += " " + active.file.name;
			}
		} else if (failed) {
			message = state.messages.failedMessage || (done + " of " + state.entries.length
				+ " documents uploaded. Some documents failed; retry failed uploads or close this window.");
		} else if (pending) {
			state.success = false;
			message = state.messages.pendingMessage || ("Claim " + state.claimNumber + " was saved. Preparing document uploads...");
		} else {
			state.success = true;
			message = state.messages.completeMessage || (failed
				? done + " of " + state.entries.length
					+ " documents uploaded. Some documents failed; retry failed uploads or close this window."
				: (state.entries.length
					? "All documents uploaded. You can close this window now."
					: "Claim " + state.claimNumber + " was saved. No supporting documents were selected. You can close this window now."));
		}
		ShipAndDebit._$("#sd_doc_progress_footer_message").text(message);
		ShipAndDebit._$("#sd_doc_progress_spinner").toggleClass("d-none", !state.running);
		if (state.operation === "updated") ShipAndDebit._renderEditDocuments();
		if (state.operation === "documents-only") ShipAndDebit._renderEditUploadOnlyDocuments();
	},

	_runDocumentUploads: function () {
		var state = ShipAndDebit._docProgressState;
		if (!state || state.running) return;
		var entries = state.entries;
		if (!entries.some(function (entry) { return entry.status !== "done"; })) {
			state.running = false;
			ShipAndDebit._renderDocumentProgress();
			return;
		}
		state.running = true;
		entries.forEach(function (entry) {
			if (entry.status === "failed") entry.status = "pending";
		});
		var pending = entries.filter(function (entry) { return entry.status === "pending"; });
		if (!pending.length) {
			state.running = false;
			ShipAndDebit._renderDocumentProgress();
			return;
		}
		var batches = [];
		var batch = [];
		var batchBytes = 0;
		pending.forEach(function (entry) {
			if (batch.length && batchBytes + entry.file.size > ShipAndDebit.DOC_REQUEST_FILE_LIMIT_BYTES) {
				batches.push(batch);
				batch = [];
				batchBytes = 0;
			}
			batch.push(entry);
			batchBytes += entry.file.size;
		});
		if (batch.length) batches.push(batch);
		state.totalBatches = batches.length;
		state.currentBatch = 0;
		state.running = true;
		var sendBatch = function (batchIndex) {
			if (batchIndex >= batches.length) {
				state.running = false;
				ShipAndDebit._renderDocumentProgress();
				return;
			}
			var currentBatch = batches[batchIndex];
			state.currentBatch = batchIndex + 1;
			currentBatch.forEach(function (entry) { entry.status = "uploading"; });
			currentBatch.forEach(function (entry) {
				entry.uploadStartedAt = Date.now();
				entry.uploadFinishedAt = null;
			});
			ShipAndDebit._renderDocumentProgress();
			var context = ShipAndDebit._context();
			var form = new FormData();
			form.append("custCode", context.custCode);
			form.append("loginId", context.loginId);
			form.append("claimNumber", state.claimNumber);
			var batchFileNames = currentBatch.map(function (entry) { return entry.file.name; });
			var batchFileBytes = currentBatch.reduce(function (total, entry) {
				return total + entry.file.size;
			}, 0);
			currentBatch.forEach(function (entry) {
				form.append("files", entry.file, entry.file.name);
			});
			if (window.console && typeof console.info === "function") {
				console.info("Ship & Debit document batch sending", {
					claimNumber: state.claimNumber,
					batch: state.currentBatch,
					totalBatches: state.totalBatches,
					fileCount: currentBatch.length,
					fileBytes: batchFileBytes,
					files: batchFileNames
				});
			}
			ShipAndDebit._postMultipart("/documents", form, function () {
				var finishedAt = Date.now();
				if (window.console && typeof console.info === "function") {
					console.info("Ship & Debit document batch uploaded", {
						claimNumber: state.claimNumber,
						batch: state.currentBatch,
						fileCount: currentBatch.length,
						fileBytes: batchFileBytes
					});
				}
				currentBatch.forEach(function (entry) {
					entry.status = "done";
					entry.uploadFinishedAt = finishedAt;
				});
				sendBatch(batchIndex + 1);
			}, function (error) {
				if (window.console && typeof console.error === "function") {
					console.error("Ship & Debit document batch failed", {
						claimNumber: state.claimNumber,
						batch: state.currentBatch,
						fileCount: currentBatch.length,
						fileBytes: batchFileBytes,
						files: batchFileNames,
						error: error || "No error details returned by the server."
					});
				}
				var finishedAt = Date.now();
				currentBatch.forEach(function (entry) {
					entry.status = "failed";
					entry.uploadFinishedAt = finishedAt;
				});
				state.running = false;
				ShipAndDebit._renderDocumentProgress();
			});
		};
		sendBatch(0);
	},

	SaveEdit: function (confirmed) {
		if (ShipAndDebit._editSaveInProgress || ShipAndDebit._editUploadOnlyRunning) return false;
		var number = String(ShipAndDebit._openClaimNumber || "").trim();
		if (!number) return false;
		if (!ShipAndDebit._validateClaimComment("#sd_edit_comments")) return false;
		var previousEntries = ShipAndDebit._editDocumentQueue || [];
		var uploadEntries = previousEntries.filter(function (entry) { return entry.status !== "done"; });
		var uploadValidation = ShipAndDebit._validateDocumentFiles(uploadEntries.map(function (entry) {
			return entry.file;
		}));
		if (uploadValidation) {
			ShipAndDebit._showDocumentError("#sd_edit_document_error", uploadValidation);
			return false;
		}
		ShipAndDebit._showDocumentError("#sd_edit_document_error", "");
		var kept = ShipAndDebit._editRows || [];
		var removed = ShipAndDebit._editDeleted || [];
		if (!kept.length && !removed.length) {
			Common.showPageMsg(ShipAndDebit.ROOT, "This claim has no lines to update.", "warning");
			return false;
		}
		var total = Number(ShipAndDebit._$("#sd_e_total").val() || 0);
		if (kept.length && !total) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Total Claim Value is 0, Cannot Submit Claim", "warning");
			return false;
		}
		if (ShipAndDebit._editLateStatus !== "ready" && ShipAndDebit._editLateStatus !== "required") {
			if (ShipAndDebit._editLateStatus !== "loading") {
				ShipAndDebit._loadEditLateFlag(ShipAndDebit._editLookupToken);
			}
			Common.showPageMsg(ShipAndDebit.ROOT, "Late submission status is not ready. Please wait for the check to finish, then update again.", "warning");
			return false;
		}
		var lateRemarks = $.trim(ShipAndDebit._$("#sd_edit_late").val() || "");
		if (ShipAndDebit._editLateStatus === "required" && !lateRemarks) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Please share the reason for late submission", "warning");
			return false;
		}
		if (total > 0 && !confirmed) {
			if (ShipAndDebit._editConfirmingSubmit) return false;
			ShipAndDebit._editConfirmingSubmit = true;
			var confirmationText = "This is a debit note claim.\nClaim value: Rs. " + total.toFixed(2)
				+ "\nAre you sure to submit the claim?";
			var confirmationHtml = "This is a debit note claim.<br>Claim value: "
				+ "<strong class='sd-claim-confirm-amount'>Rs. " + total.toFixed(2) + "</strong>"
				+ "<br>Are you sure to submit the claim?";
			if (window.Swal && typeof Swal.fire === "function") {
				Swal.fire({
					title: "Confirm claim update",
					html: confirmationHtml,
					icon: "warning",
					showCancelButton: true,
					confirmButtonText: "OK",
					cancelButtonText: "Cancel",
					confirmButtonColor: "#3085d6",
					cancelButtonColor: "#6c757d",
					reverseButtons: true
				}).then(function (result) {
					ShipAndDebit._editConfirmingSubmit = false;
					if (result && result.isConfirmed) ShipAndDebit.SaveEdit(true);
				}, function () {
					ShipAndDebit._editConfirmingSubmit = false;
				});
				if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
			} else {
				ShipAndDebit._editConfirmingSubmit = false;
				if (window.confirm(confirmationText)) ShipAndDebit.SaveEdit(true);
			}
			return false;
		}
		var body = ShipAndDebit._context();
		body.comments = ShipAndDebit._$("#sd_edit_comments").val() || "";
		body.lateRemarks = lateRemarks;
		body.lines = kept.map(function (line) {
			return ShipAndDebit._editPayload(line, line.action === "I" ? "I" : "U");
		})
			.concat(removed.map(function (line) { return ShipAndDebit._editPayload(line, "D"); }));
		previousEntries.forEach(function (entry) {
			if (entry.status === "done" && entry.url) window.URL.revokeObjectURL(entry.url);
		});
		ShipAndDebit._editDocumentQueue = uploadEntries;
		ShipAndDebit._editSaveInProgress = true;
		ShipAndDebit._$("#sd_edit_update").prop("disabled", true);
		ShipAndDebit._$("#sd_edit_upload_only").prop("disabled", true);
		ShipAndDebit._post("/claims/" + encodeURIComponent(number), JSON.stringify(body), function (data) {
			var message = (data && data.message) || "Claim saved.";
			ShipAndDebit._sendFile(number, message);
		}, function (message) {
			ShipAndDebit._editSaveInProgress = false;
			ShipAndDebit._$("#sd_edit_update").prop("disabled", false);
			ShipAndDebit._$("#sd_edit_upload_only").prop("disabled", false);
			ShipAndDebit._renderEditDocuments();
			ShipAndDebit.HideMsg();
			ShipAndDebit._showRequestError("Claim could not be updated", message);
		});
		return false;
	},

	_sendFile: function (number, message, options) {
		options = options || {};
		var input = ShipAndDebit._el("#" + String(options.inputId || "sd_edit_file").replace(/^#/, ""));
		var afterClose = function (uploaded) {
			ShipAndDebit._editSaveInProgress = false;
			ShipAndDebit._$("#sd_edit_upload_only").prop("disabled", false);
			if (uploaded) {
				ShipAndDebit._clearEditDocumentQueue();
				if (input) input.value = "";
				ShipAndDebit._$("#sd_retry_edit_docs").addClass("d-none");
				Common.showPageMsg(ShipAndDebit.ROOT, message, "success");
				if (typeof options.after === "function") options.after("");
				else if (options.reloadEdit !== false) ShipAndDebit.OpenClaim(number);
				return;
			}
			ShipAndDebit._$("#sd_retry_edit_docs").removeClass("d-none");
			ShipAndDebit._$("#sd_edit_update").prop("disabled", false);
			ShipAndDebit._renderEditDocuments();
			Common.showPageMsg(ShipAndDebit.ROOT,
				"Claim " + number + " was updated, but one or more documents failed to upload. Retry the failed uploads.", "warning");
		};
		ShipAndDebit._startDocumentProgress(number, "updated", ShipAndDebit._editDocumentQueue, afterClose);
	},

	RetryEditDocuments: function () {
		var number = String(ShipAndDebit._openClaimNumber || "").trim();
		if (!number || !ShipAndDebit._editDocumentQueue.length) return false;
		ShipAndDebit._editSaveInProgress = true;
		ShipAndDebit._$("#sd_edit_update").prop("disabled", true);
		ShipAndDebit._$("#sd_edit_upload_only").prop("disabled", true);
		ShipAndDebit._startDocumentProgress(number, "updated", ShipAndDebit._editDocumentQueue, function (uploaded) {
			ShipAndDebit._editSaveInProgress = false;
			ShipAndDebit._$("#sd_edit_upload_only").prop("disabled", false);
			if (uploaded) {
				var input = ShipAndDebit._el("#sd_edit_file");
				if (input) input.value = "";
				ShipAndDebit._clearEditDocumentQueue();
				ShipAndDebit._$("#sd_retry_edit_docs").addClass("d-none");
				Common.showPageMsg(ShipAndDebit.ROOT, "Claim " + number + " and supporting documents were saved.", "success");
				ShipAndDebit.OpenClaim(number);
			} else {
				ShipAndDebit._$("#sd_edit_update").prop("disabled", false);
				ShipAndDebit._renderEditDocuments();
				Common.showPageMsg(ShipAndDebit.ROOT,
					"Some documents could not be uploaded for claim " + number + ". Retry the failed uploads.", "warning");
			}
		});
		return false;
	},

	OpenRate: function (number, endCustomer, mode) {
		number = String(number || "").trim();
		if (!number) return false;
		ShipAndDebit._rateNumber = number;
		ShipAndDebit._rateEnd = String(endCustomer || "").trim();
		ShipAndDebit._rateMode = mode === "A" ? "A" : "P";
		ShipAndDebit._get("/rate-contracts/detail?number=" + encodeURIComponent(number), function (rows) {
			ShipAndDebit._showRate(rows || []);
		});
		return false;
	},

	DownloadReport: function () {
		var context = ShipAndDebit._context();
		var from = ShipAndDebit._ymd("sd_from");
		var to = ShipAndDebit._ymd("sd_to");
		window.location.href = (window.$app_url || "") + ShipAndDebit._api + "/report/file?fromDate="
			+ encodeURIComponent(from)
			+ "&toDate=" + encodeURIComponent(to)
			+ "&custCode=" + encodeURIComponent(context.custCode)
			+ "&loginId=" + encodeURIComponent(context.loginId);
		return false;
	},

	AcceptRate: function () {
		if (!ShipAndDebit._$("#sd_rate_agree").prop("checked")) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Click the checkbox to proceed.", "warning");
			return false;
		}
		var body = ShipAndDebit._context();
		body.contractNumber = ShipAndDebit._rateNumber || "";
		body.endCustomer = ShipAndDebit._rateEnd || "";
		body.statusFlag = "A";
		ShipAndDebit._post("/rate-contracts/accept", JSON.stringify(body), function (data) {
			var modal = ShipAndDebit._el("#sd_rate_modal");
			var inst = modal && window.bootstrap && bootstrap.Modal.getInstance(modal);
			if (inst) inst.hide();
			Common.showPageMsg(ShipAndDebit.ROOT, (data && data.message) || "Accepted successfully.", "success");
			ShipAndDebit._ready.m_sd_pending = false;
			ShipAndDebit._ready.m_sd_accepted = false;
			ShipAndDebit._rates("m_sd_pending", "sd_pending_table", "sd_pending_tbody", "P");
		});
		return false;
	},

	DownloadRate: function () {
		if (!ShipAndDebit._rateNumber) return false;
		var context = ShipAndDebit._context();
		window.location.href = (window.$app_url || "") + ShipAndDebit._api + "/rate-contracts/file?number="
			+ encodeURIComponent(ShipAndDebit._rateNumber)
			+ "&custCode=" + encodeURIComponent(context.custCode)
			+ "&loginId=" + encodeURIComponent(context.loginId);
		return false;
	},

	Refresh: function (key) {
		if (key === "create" && window.ShipAndDebitCreate) {
			ShipAndDebitCreate._ready = false;
			ShipAndDebit._$("#sd_create_body").empty();
			ShipAndDebit._openCreate();
		} else if (key === "edit") {
			ShipAndDebit._claims("m_sd_edit", "sd_edit_table", "sd_edit_tbody", "P");
		} else if (key === "status") {
			ShipAndDebit.LoadStatus(true);
		} else if (key === "accepted") {
			ShipAndDebit._ready.m_sd_accepted = false;
			ShipAndDebit._rates("m_sd_accepted", "sd_accepted_table", "sd_accepted_tbody", "A");
		} else if (key === "pending") {
			ShipAndDebit._ready.m_sd_pending = false;
			ShipAndDebit._rates("m_sd_pending", "sd_pending_table", "sd_pending_tbody", "P");
		}
		return false;
	},

	_requiredText: function (missing) {
		if (!missing.length) return "";
		if (missing.length === 1) return missing[0].charAt(0).toUpperCase() + missing[0].slice(1) + " is required.";
		var last = missing.pop();
		var text = missing.join(", ") + " and " + last + " are required.";
		return text.charAt(0).toUpperCase() + text.slice(1);
	},

	_ymd: function (id) {
		var raw = $.trim($("#" + id).val() || "");
		var parts = raw.split("/");
		if (parts.length === 3 && parts[2].length === 4) return parts[2] + parts[1] + parts[0];
		return raw.replace(/-/g, "");
	},

	_claimMonthDateBounds: function (claimMonth, invoiceDate) {
		var month = String(claimMonth || "").replace(/\D/g, "");
		if (!/^\d{6}$/.test(month)) return null;
		var year = Number(month.substr(0, 4));
		var monthNumber = Number(month.substr(4, 2));
		if (monthNumber < 1 || monthNumber > 12) return null;
		var start = new Date(year, monthNumber - 1, 1);
		var end = new Date(year, monthNumber, 0);
		var today = new Date();
		today.setHours(0, 0, 0, 0);
		if (end > today) end = today;
		var invoice = String(invoiceDate || "").replace(/\D/g, "");
		if (/^\d{8}$/.test(invoice)) {
			var invoiceDay = new Date(Number(invoice.substr(0, 4)), Number(invoice.substr(4, 2)) - 1,
				Number(invoice.substr(6, 2)));
			if (invoiceDay > start) start = invoiceDay;
		}
		var toYmd = function (date) {
			return String(date.getFullYear()) + String(date.getMonth() + 1).padStart(2, "0")
				+ String(date.getDate()).padStart(2, "0");
		};
		return { startDate: start, endDate: end, startYmd: toYmd(start), endYmd: toYmd(end) };
	},

	_claimDistDateError: function (claimMonth, invoiceDate, distDate) {
		var month = String(claimMonth || "").replace(/\D/g, "");
		var invoice = String(invoiceDate || "").replace(/\D/g, "");
		var date = String(distDate || "").replace(/\D/g, "");
		var bounds = ShipAndDebit._claimMonthDateBounds(month, invoice);
		if (!bounds || !/^\d{8}$/.test(date)) return "Select a valid distributor invoice date.";
		if (date < bounds.startYmd) {
			return "Distributor invoice date must be within the claim month and on or after the 3M invoice date.";
		}
		if (date > bounds.endYmd) {
			return "Distributor invoice date must be within the claim month and cannot be later than today.";
		}
		return "";
	},

	_ensureDates: function (selector) {
		if (!window.jQuery || !$.fn.datepicker) return;
		$(selector || "#sd_from, #sd_to").each(function () {
			var $el = $(this);
			if ($el.data("datepicker")) return;
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				showOnFocus: false,
				format: "dd/mm/yyyy",
				orientation: "bottom auto"
			});
		});
	},

	_termsMsg: function (message) {
		var box = ShipAndDebit._el("#sd_terms_msg");
		if (!box) return;
		var text = String(message || "").trim();
		box.textContent = text;
		box.classList.toggle("d-none", !text);
		var home = ShipAndDebit._el("#sd_terms_home");
		if (home) home.classList.toggle("d-none", !text);
	},

	_showTerms: function () {
		var modal = ShipAndDebit._el("#sd_terms_modal");
		if (!modal) return;
		ShipAndDebit._termsMsg("");
		var body = modal.querySelector(".modal-body");
		$(body).load((window.$app_url || "") + "html_files/SHIPANDDEBIT/ship_debit_terms.html?r=" + Math.random(), function (_html, status) {
			if (status === "error") {
				body.innerHTML = "<p class='mb-0'>The terms could not be loaded. Open Contract Claim again.</p>";
			}
			$(modal).find("#sd_terms_check").on("change", function () {
				$(modal).find("#sd_terms_submit").prop("disabled", !this.checked);
			});
			if (!window.bootstrap) return;
			modal.addEventListener("shown.bs.modal", function () {
				var backs = document.querySelectorAll(".modal-backdrop");
				if (backs.length) backs[backs.length - 1].classList.add("sd-terms-backdrop");
			});
			bootstrap.Modal.getOrCreateInstance(modal).show();
		});
	},

	_loadScripts: function (done) {
		if (window.ShipAndDebitCreate) {
			done();
			return;
		}
		var script = document.createElement("script");
		script.src = (window.$app_url || "") + "custom_js/SHIPANDDEBIT/ship_and_debit_create.js?r=" + Date.now();
		script.onload = function () { done(); };
		script.onerror = function () {
			if (typeof hideLoader === "function") hideLoader();
			if (typeof showJsLoadError === "function") {
				showJsLoadError((window.$app_url || "") + "custom_js/SHIPANDDEBIT/ship_and_debit_create.js");
				return;
			}
			var box = ShipAndDebit._el("#inpc_page_msg");
			if (box) {
				box.className = "alert alert-danger mx-3";
				box.textContent = "Unable to load ship_and_debit_create.js. File not found.";
			}
		};
		document.body.appendChild(script);
	},

	_openCreate: function () {
		if (window.ShipAndDebitCreate) ShipAndDebitCreate.Load();
	},

	_loadEdit: function () {
		if (ShipAndDebit._ready.edit) {
			ShipAndDebit._openPendingClaim();
			return;
		}
		ShipAndDebit._$("#sd_edit_body").load((window.$app_url || "") + "html_files/SHIPANDDEBIT/edit_claim.html?r=" + Date.now(), function () {
			ShipAndDebit._ready.edit = true;
			if (ShipAndDebit._pendingOpen) ShipAndDebit._openPendingClaim();
			else ShipAndDebit._claims("m_sd_edit", "sd_edit_table", "sd_edit_tbody", "P");
		});
	},

	OpenStatusClaim: function (number) {
		number = String(number || "").trim();
		if (!number) return false;
		ShipAndDebit._get("/claims/" + encodeURIComponent(number), function (rows) {
			ShipAndDebit._showClaim(number, rows || []);
		});
		return false;
	},

	_showClaim: function (number, rows) {
		var lines = rows.map(function (row) { return ShipAndDebit._claimLine(row); });
		var first = lines[0] || {};
		var total = 0;
		lines.forEach(function (line) {
			total += Number(String(line.claimValue || "0").replace(/,/g, "")) || 0;
		});
		ShipAndDebit._$("#sd_claim_no").text(number);
		ShipAndDebit._popupCss();
		var html = "<div class='sd-rate-facts' style='display:grid;grid-template-columns:" + (window.innerWidth < 640 ? "1fr" : "1fr 1fr") + ";gap:.65rem;margin:0 0 .9rem'>"
			+ ShipAndDebit._fact("Division", first.division)
			+ ShipAndDebit._fact("End Customer", first.endCustomer)
			+ ShipAndDebit._fact("Claim Month", ShipAndDebit._claimMonth(first.claimMonth))
			+ ShipAndDebit._fact("Total Claim Value", total.toFixed(2));
		if (first.comments) html += ShipAndDebit._fact("Comment", first.comments);
		if (first.lateRemarks) html += ShipAndDebit._fact("Late Submission Remarks", first.lateRemarks);
		html += "</div>";
		html += "<div class='sd-rate-section' style='display:flex;align-items:center;gap:.45rem;margin:0 0 .45rem;padding:.45rem .7rem;border-radius:.55rem;background:linear-gradient(120deg,#4aa3e8,#7ec8f5);color:#0e3354;font-size:.92rem;font-weight:700'><i class='ri-stack-line' aria-hidden='true'></i> Stock details</div>"
			+ "<div class='table-responsive'><table class='table table-sm table-bordered sd-rate-table mb-0'><thead><tr>"
			+ ShipAndDebit._th("Product") + ShipAndDebit._th("Sku") + ShipAndDebit._th("3M invoice") + ShipAndDebit._th("Inv date")
			+ ShipAndDebit._th("Dist inv number") + ShipAndDebit._th("Dist inv date") + ShipAndDebit._th("UOM") + ShipAndDebit._th("Avail qty")
			+ ShipAndDebit._th("Sales person") + ShipAndDebit._th("Contract price") + ShipAndDebit._th("Dist qty") + ShipAndDebit._th("3M inv price")
			+ ShipAndDebit._th("VAT/CST/SGST/UGST") + ShipAndDebit._th("CGST") + ShipAndDebit._th("IGST")
			+ ShipAndDebit._th("Freight%") + ShipAndDebit._th("Discount%") + ShipAndDebit._th("Claim value") + ShipAndDebit._th("COFS order")
			+ "</tr></thead><tbody>";
		if (!lines.length) {
			html += "<tr><td colspan='19'>No claim lines were returned.</td></tr>";
		}
		lines.forEach(function (line) {
			html += "<tr>"
				+ "<td>" + ShipAndDebit._esc(line.description) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.sku) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.invoiceNumber) + "</td>"
				+ "<td>" + ShipAndDebit._esc(ShipAndDebit._date(line.invoiceDate)) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.distInvoiceNumber) + "</td>"
				+ "<td>" + ShipAndDebit._esc(ShipAndDebit._date(line.distInvoiceDate)) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.uom) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.availQty) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.salesPerson) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.rcPrice) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.distBillQty) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.distBillPrice) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.tax) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.cgst) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.igst) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.freight) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.discount) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.claimValue) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(line.cofsOrder) + "</td></tr>";
		});
		html += "</tbody></table></div>";
		html += "<div style='display:flex;flex-wrap:wrap;gap:.75rem;margin-top:.9rem;align-items:flex-start'>"
			+ ShipAndDebit._noteBox("Comment", first.comments)
			+ ShipAndDebit._noteBox("Late Submission Remarks", first.lateRemarks)
			+ ShipAndDebit._statusPanel(first)
			+ "</div>";
		ShipAndDebit._$("#sd_claim_body").html(html);
		var modal = ShipAndDebit._el("#sd_claim_modal");
		if (window.bootstrap && modal) {
			if (!modal.getAttribute("data-sd-bound")) {
				modal.setAttribute("data-sd-bound", "1");
				modal.addEventListener("shown.bs.modal", function () {
					var backs = document.querySelectorAll(".modal-backdrop");
					if (backs.length) backs[backs.length - 1].classList.add("sd-terms-backdrop");
				});
			}
			bootstrap.Modal.getOrCreateInstance(modal).show();
		}
	},

	_openPendingClaim: function () {
		var number = String(ShipAndDebit._pendingOpen || "").trim();
		if (!number || !ShipAndDebit._el("#sd_edit_detail")) return;
		ShipAndDebit._pendingOpen = "";
		ShipAndDebit.OpenClaim(number);
	},

	_claims: function (rootId, tableId, tbodyId, status) {
		ShipAndDebit._get("/claims?status=" + encodeURIComponent(status), function (rows) {
			var shown = rows || [];
			var columns = ShipAndDebit._claimColumns();
			if (rootId === "m_sd_edit") {
				ShipAndDebit._$("#sd_edit_detail").addClass("d-none");
				shown = shown.map(function (row) {
					var copy = ShipAndDebit._labelClaim(row);
					var number = ShipAndDebit._pick(copy, ["DCCLNO"]);
					copy.DCCLNO = "<a href='javascript:void(0)' onclick='return ShipAndDebit.OpenClaim("
						+ JSON.stringify(String(number)) + ")'><i class='ri-edit-line' aria-hidden='true' style='margin-right:.25rem'></i>"
						+ ShipAndDebit._esc(number) + "</a>";
					return copy;
				});
				columns = columns.map(function (col) {
					return col.field === "DCCLNO" ? { title: col.title, field: col.field, type: "html" } : col;
				});
			}
			ShipAndDebit._table(rootId, tableId, tbodyId, columns, shown);
		});
	},

	LoadStatus: function (force) {
		if (!force && ShipAndDebit._statusBuckets) {
			ShipAndDebit.ShowStatusBucket(ShipAndDebit._statusKey || "P");
			return;
		}
		ShipAndDebit._get("/claims?status=" + encodeURIComponent("P,W,C,R"), function (data) {
			ShipAndDebit._statusBuckets = data || {};
			ShipAndDebit.ShowStatusBucket(ShipAndDebit._statusKey || "P");
		});
	},

	ShowStatusBucket: function (key) {
		ShipAndDebit._statusKey = key;
		var buckets = ShipAndDebit._statusBuckets || {};
		var names = { P: "Submitted Claims", W: "Work in Process", C: "Closed Claims", R: "Rejected Claims" };
		var buttons = ShipAndDebit._$("#sd_status_buckets .sd-bucket").get();
		for (var i = 0; i < buttons.length; i++) {
			var code = buttons[i].getAttribute("data-sd-bucket");
			var rows = buckets[code] || [];
			buttons[i].textContent = names[code] + " (" + rows.length + ")";
			buttons[i].classList.toggle("btn-primary", code === key);
			buttons[i].classList.toggle("btn-outline-primary", code !== key);
		}
		var shown = (buckets[key] || []).map(function (row) {
			var copy = ShipAndDebit._labelClaim(row);
			var date = String(copy.DCRQDT || "");
			if (/^\d{8}$/.test(date)) copy.DCRQDT = date.substr(6, 2) + "-" + date.substr(4, 2) + "-" + date.substr(0, 4);
			var number = ShipAndDebit._pick(copy, ["DCCLNO"]);
			copy.DCCLNO = "<a href='javascript:void(0)' onclick='return ShipAndDebit.OpenStatusClaim("
				+ JSON.stringify(String(number)) + ")'>" + ShipAndDebit._esc(number) + "</a>";
			return copy;
		});
		var columns = ShipAndDebit._claimColumns().map(function (col) {
			return col.field === "DCCLNO" ? { title: col.title, field: col.field, type: "html" } : col;
		});
		ShipAndDebit._table("m_sd_status", "sd_status_table", "sd_status_tbody", columns, shown);
		return false;
	},

	_labelClaim: function (row) {
		var labels = ["DCCLNO", "DCNAME", "DCECNM", "DCRQNM", "DCRQDT", "DCBSGS", "DCDVMS", "DCCLVL", "DCCORD"];
		var keys = Object.keys(row || {});
		var copy = {};
		keys.forEach(function (name) { copy[name] = row[name]; });
		labels.forEach(function (label, index) {
			if (ShipAndDebit._pick(copy, [label]) || keys[index] == null) return;
			copy[label] = row[keys[index]];
		});
		var pending = ShipAndDebit._pick(row, ["STATUSLVL"]);
		if (pending) copy.STATUSLVL = pending;
		return copy;
	},

	_claimColumns: function () {
		return [
			{ title: "Claim No.", field: "DCCLNO" },
			{ title: "Distributor name", field: "DCNAME" },
			{ title: "End customer name", field: "DCECNM" },
			{ title: "Req By", field: "DCRQNM" },
			{ title: "Req Date", field: "DCRQDT" },
			{ title: "Pending With", field: "STATUSLVL" },
			{ title: "Total Claim Value(Rs)", field: "DCCLVL", "text-align": "right" }
		];
	},

	_rates: function (rootId, tableId, tbodyId, flag) {
		if (ShipAndDebit._ready[rootId]) return;
		ShipAndDebit._get("/rate-contracts?flag=" + encodeURIComponent(flag), function (rows) {
			var mode = flag === "A" ? "A" : "P";
			var shown = (rows || []).map(function (row) {
				var copy = {};
				Object.keys(row).forEach(function (name) { copy[name] = row[name]; });
				var number = ShipAndDebit._pick(row, ["DRRCNM"]);
				var end = ShipAndDebit._pick(row, ["DRECUS"]);
				copy.DRRCNM = "<a href='javascript:void(0)' onclick='return ShipAndDebit.OpenRate("
					+ JSON.stringify(String(number)) + "," + JSON.stringify(String(end)) + ","
					+ JSON.stringify(mode) + ")'>" + ShipAndDebit._esc(number) + "</a>";
				return copy;
			});
			if (mode === "P" && shown.length && !ShipAndDebit._pendingTold) {
				ShipAndDebit._pendingTold = true;
				Common.showPageMsg(ShipAndDebit.ROOT, "Please accept all pending rate contracts before creating claims.", "warning");
			}
			ShipAndDebit._ready[rootId] = true;
			ShipAndDebit._table(rootId, tableId, tbodyId, [
				{ title: "Rate contract Number", field: "DRRCNM", type: "html" },
				{ title: "End Customer Name", field: "DRECNM" }
			], shown);
		});
	},

	_showRate: function (rows) {
		ShipAndDebit._popupCss();
		var first = rows[0] || {};
		var number = ShipAndDebit._pick(first, ["RCREQN", "DRRCNM"]) || ShipAndDebit._rateNumber || "";
		var endCode = ShipAndDebit._pick(first, ["RCCUST", "DRECUS"]);
		if (endCode) ShipAndDebit._rateEnd = endCode;
		ShipAndDebit._$("#sd_rate_no").text(number);
		var html = "<div id='sd_rate_export'>"
			+ "<div class='sd-rate-facts' style='display:grid;grid-template-columns:" + (window.innerWidth < 640 ? "1fr" : "1fr 1fr") + ";gap:.65rem;margin:0 0 .9rem'>"
			+ ShipAndDebit._fact("Division", ShipAndDebit._pick(first, ["RCDIVC"]) + " - " + ShipAndDebit._pick(first, ["RCDIVD"]))
			+ ShipAndDebit._fact("End Customer Code/Description", endCode + " - " + ShipAndDebit._pick(first, ["RCCNME", "DRECNM"]))
			+ ShipAndDebit._fact("Rate Contract Start Date", ShipAndDebit._date(ShipAndDebit._pick(first, ["RCSDAT"])))
			+ ShipAndDebit._fact("Rate Contract End Date", ShipAndDebit._date(ShipAndDebit._pick(first, ["RCEDAT"])))
			+ "</div>"
			+ "<div class='sd-rate-section' style='display:flex;align-items:center;gap:.45rem;margin:0 0 .45rem;padding:.45rem .7rem;border-radius:.55rem;background:linear-gradient(120deg,#4aa3e8,#7ec8f5);color:#0e3354;font-size:.92rem;font-weight:700'><i class='ri-stack-line' aria-hidden='true'></i> Stock Code Details</div>"
			+ "<div class='table-responsive'><table class='table table-sm table-bordered sd-rate-table mb-0'><thead><tr>"
			+ "<th style='background:#eef6fc;color:#1d4f78'>Sl No</th><th style='background:#eef6fc;color:#1d4f78'>Product code / Description</th><th style='background:#eef6fc;color:#1d4f78'>UOM</th><th style='background:#eef6fc;color:#1d4f78'>Book Price</th><th style='background:#eef6fc;color:#1d4f78'>Rate Contract Price</th>"
			+ "</tr></thead><tbody>";
		rows.forEach(function (row, index) {
			html += "<tr><td>" + (index + 1) + "</td><td>" + ShipAndDebit._esc(ShipAndDebit._pick(row, ["RCPROD"]))
				+ " - " + ShipAndDebit._esc(ShipAndDebit._pick(row, ["RCDESC"])) + "</td>"
				+ "<td class='text-center'>" + ShipAndDebit._esc(ShipAndDebit._pick(row, ["RCSUOM"])) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(ShipAndDebit._pick(row, ["RCACTP"])) + "</td>"
				+ "<td class='text-end'>" + ShipAndDebit._esc(ShipAndDebit._pick(row, ["RCECPR"])) + "</td></tr>";
		});
		html += "</tbody></table></div></div>";
		ShipAndDebit._$("#sd_rate_body").html(rows.length ? html : "<p>No rate contract details were returned.</p>");
		var pending = ShipAndDebit._rateMode === "P";
		ShipAndDebit._$("#sd_rate_agree_wrap").toggleClass("d-none", !pending);
		ShipAndDebit._$("#sd_rate_submit").toggleClass("d-none", !pending);
		ShipAndDebit._$("#sd_rate_download").toggleClass("d-none", pending);
		ShipAndDebit._$("#sd_rate_agree").prop("checked", false);
		var modal = ShipAndDebit._el("#sd_rate_modal");
		if (window.bootstrap && modal) {
			if (!modal.getAttribute("data-sd-bound")) {
				modal.setAttribute("data-sd-bound", "1");
				modal.addEventListener("shown.bs.modal", function () {
					var backs = document.querySelectorAll(".modal-backdrop");
					if (backs.length) backs[backs.length - 1].classList.add("sd-terms-backdrop");
				});
			}
			bootstrap.Modal.getOrCreateInstance(modal).show();
		}
	},

	_th: function (label) {
		return "<th style='background:#eef6fc;color:#1d4f78'>" + ShipAndDebit._esc(label) + "</th>";
	},

	_noteBox: function (label, value) {
		return "<div style='flex:1 1 16rem;min-width:14rem'><div style='margin:0 0 .25rem;color:#5b7290;font-size:.72rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase'>"
			+ ShipAndDebit._esc(label) + "</div><textarea readonly rows='2' style='width:100%;resize:none;background:#e9ecef;border:1px solid #d7e0e8;border-radius:.35rem;padding:.4rem .55rem;color:#16324a'>"
			+ ShipAndDebit._esc(value) + "</textarea></div>";
	},

	_statusPanel: function (line) {
		line = line || {};
		var bsoName = String(line.bsoName || "").trim();
		var bsoTitle = bsoName ? bsoName + "'s Comments" : "BSG's Comments";
		var bsoCode = String(line.bsoStatus || "").trim() || "P";
		var html = "<div style='flex:1 1 16rem;min-width:16rem;border:1px solid #8aa4b8;border-radius:.45rem;overflow:hidden'>"
			+ "<div style='background:#4e6e8c;color:#fff;padding:.45rem .65rem;font-weight:700'>Status and comments</div>"
			+ "<div style='display:flex;justify-content:space-between;gap:.5rem;padding:.4rem .65rem;background:#eef3f6;font-weight:600'>"
			+ "<span>" + ShipAndDebit._esc(bsoTitle) + "</span></div>"
			+ "<div style='padding:.4rem .65rem;" + ShipAndDebit._statusStyle(bsoCode) + "'>"
			+ ShipAndDebit._esc(line.bsoComment) + "</div>";
		var dmComment = String(line.dmComment || "").trim();
		var dmStatus = String(line.dmStatus || "").trim();
		if (dmComment || dmStatus) {
			var dmName = String(line.dmName || "").trim();
			var dmTitle = dmName ? dmName + "'s Comments" : "DM's Comments";
			html += "<div style='padding:.4rem .65rem;background:#eef3f6;font-weight:600'>" + ShipAndDebit._esc(dmTitle) + "</div>"
				+ "<div style='padding:.4rem .65rem;" + ShipAndDebit._statusStyle(dmStatus || "P") + "'>"
				+ ShipAndDebit._esc(dmComment) + "</div>";
		}
		var overall = ShipAndDebit._overallStatus(line);
		html += "<div style='padding:.45rem .65rem;font-weight:700;" + ShipAndDebit._statusStyle(overall.code) + "'>"
			+ ShipAndDebit._esc(overall.label) + "</div></div>";
		return html;
	},

	_overallStatus: function (line) {
		var order = String(line.cofsOrder || "").trim();
		if (order && order !== "0") return { code: "A", label: "Closed" };
		var claim = String(line.claimStatus || "").trim().toUpperCase();
		if (claim === "A") return { code: "IP", label: "In progress" };
		if (claim === "R") return { code: "R", label: "Rejected" };
		return { code: "P", label: "Pending" };
	},

	_statusStyle: function (code) {
		var key = String(code || "P").trim().toUpperCase();
		if (key === "A") return "background:green;color:#fff";
		if (key === "IP") return "background:coral;color:#16324a";
		if (key === "R") return "background:red;color:#fff";
		return "background:yellow;color:#16324a";
	},

	_fact: function (label, value) {
		return "<div class='sd-rate-fact' style='padding:.65rem .75rem;border:1px solid #d7e8f6;border-radius:.7rem;background:#fff'><span style='display:block;margin:0 0 .2rem;color:#5b7290;font-size:.72rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase'>"
			+ ShipAndDebit._esc(label) + "</span><strong style='color:#16324a;font-size:.92rem;font-weight:650'>"
			+ ShipAndDebit._esc(value) + "</strong></div>";
	},

	_date: function (value) {
		var date = String(value || "");
		if (!/^\d{8}$/.test(date)) return date;
		return date.substr(6, 2) + "-" + date.substr(4, 2) + "-" + date.substr(0, 4);
	},

	_dateInput: function (value) {
		var date = String(value || "").replace(/\D/g, "");
		if (!/^\d{8}$/.test(date)) return "";
		return date.substr(6, 2) + "/" + date.substr(4, 2) + "/" + date.substr(0, 4);
	},

	_number: function (value) {
		var parsed = Number(String(value == null ? "" : value).replace(/,/g, "").trim());
		return isFinite(parsed) ? parsed : 0;
	},

	_claimLine: function (row) {
		var labeled = ShipAndDebit._labelDetail(row);
		var pick = function (names) { return ShipAndDebit._pick(labeled, names); };
		var line = {
			sku: pick(["SKUCOD"]),
			description: pick(["SKUDES"]),
			invoiceNumber: pick(["INVN"]),
			invoiceDate: pick(["INVD"]).replace(/\D/g, ""),
			uom: pick(["UOM"]),
			availQty: pick(["AVLQLT"]),
			salesPerson: pick(["SALPER"]),
			rcPrice: pick(["RCPRC"]),
			distInvoiceNumber: pick(["DINV"]),
			distInvoiceDate: pick(["DIND"]).replace(/\D/g, ""),
			distBillQty: pick(["DISBLQ"]),
			distBillPrice: pick(["DIBLPR"]),
			claimValue: pick(["CLMVL"]),
			taxRate: pick(["TAX"]),
			tax: pick(["VATCST"]),
			cgst: pick(["CGST"]),
			igst: pick(["IGST"]),
			freight: pick(["FRHT"]),
			discount: pick(["DSCUT"]),
			lineComments: pick(["LINCMD"]),
			claimNumber: pick(["CLNO#"]),
			division: pick(["DIVCOD"]).trim(),
			endCustomerCode: pick(["ECUST"]).trim(),
			endCustomer: (pick(["ECUST"]) + " - " + pick(["ECUSTNM"])).trim().replace(/^\s*-\s*|\s*-\s*$/g, ""),
			claimMonthRaw: pick(["CLMOT"]).replace(/\D/g, ""),
			claimMonth: pick(["CLMOT"]),
			comments: pick(["RQCMD"]),
			lateRemarks: pick(["DCGENC"]),
			bsoName: pick(["BSGNAM"]),
			bsoStatus: pick(["BSGSTS"]),
			bsoComment: pick(["BSGCMD"]),
			dmName: pick(["DVMGNM"]),
			dmStatus: pick(["DVMGST"]),
			dmComment: pick(["DVMGCM"]),
			cofsOrder: pick(["DCCORD"]),
			claimStatus: pick(["CLMSTS"])
		};
		line.originalInvoiceNumber = line.invoiceNumber;
		line.originalDistInvoice = line.distInvoiceNumber;
		line.originalDistDate = line.distInvoiceDate;
		line.originalQty = line.distBillQty;
		line.originalClaimValue = line.claimValue;
		line.action = "";
		return line;
	},

	_labelDetail: function (row) {
		var labels = ["CLNO#", "DIVCOD", "DIST", "DISTNM", "ECUST", "ECUSTNM", "CLMOT", "SKUCOD", "SKUDES",
			"INVN", "INVD", "UOM", "AVLQLT", "SALPER", "RCPRC", "DINV", "DIND", "DISBLQ", "DIBLPR", "CLMVL",
			"RQNAM", "RQEMAIL", "RQDAT", "RQCMD", "BSGNAM", "BSGDAT", "BSGSTS", "BSGCMD", "DVMGNM", "DVMSDT",
			"DVMGST", "DVMGCM", "DCCORD", "DCCRNO", "DCCRDT", "CLMSTS", "LINCMD", "TAX", "FRHT", "DSCUT",
			"VATCST", "IGST", "CGST", "extTaxPc"];
		var keys = Object.keys(row || {});
		var copy = {};
		keys.forEach(function (name) { copy[name] = row[name]; });
		labels.forEach(function (label, index) {
			if (ShipAndDebit._pick(copy, [label]) || keys[index] == null) return;
			copy[label] = row[keys[index]];
		});
		return copy;
	},

	_fillEditHeader: function () {
		var line = (ShipAndDebit._editRows || [])[0] || {};
		ShipAndDebit._$("#sd_e_claim").val(line.claimNumber || ShipAndDebit._openClaimNumber || "");
		ShipAndDebit._$("#sd_e_division").val(line.division || "");
		ShipAndDebit._$("#sd_e_customer").val(line.endCustomer || "");
		ShipAndDebit._$("#sd_e_month").val(ShipAndDebit._claimMonth(line.claimMonth));
		ShipAndDebit._$("#sd_edit_comments").val(line.comments || "");
		ShipAndDebit._$("#sd_edit_late").val(line.lateRemarks || "");
		ShipAndDebit._fillEditTotal();
	},

	_fillEditTotal: function () {
		var total = 0;
		(ShipAndDebit._editRows || []).forEach(function (line) {
			total += Number(String(line.claimValue || "0").replace(/,/g, "")) || 0;
		});
		ShipAndDebit._$("#sd_e_total").val(total.toFixed(2));
	},

	_claimMonth: function (value) {
		var raw = String(value || "").replace(/\D/g, "");
		if (raw.length === 6) return raw.substr(4, 2) + "/" + raw.substr(0, 4);
		return value || "";
	},

	_paintEditLines: function () {
		var html = "";
		(ShipAndDebit._editRows || []).forEach(function (line, index) {
			var editButton = line.action === "I" ? "" :
				"<button type='button' class='btn btn-link btn-sm p-0 me-2' onclick='return ShipAndDebit.EditLine(" + index + ");'><i class='ri-edit-line' aria-hidden='true'></i> Edit</button>";
			html += "<tr><td class='text-center'>" + (index + 1) + "</td><td>" + ShipAndDebit._esc(line.description) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.sku) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.invoiceNumber) + "</td>"
				+ "<td>" + ShipAndDebit._esc(ShipAndDebit._date(line.invoiceDate)) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.distInvoiceNumber) + "</td>"
				+ "<td>" + ShipAndDebit._esc(ShipAndDebit._date(line.distInvoiceDate)) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.uom) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.availQty) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.salesPerson) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.rcPrice) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.distBillQty) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.distBillPrice) + "</td>"
				+ "<td>" + ShipAndDebit._esc(line.claimValue) + "</td>"
				+ "<td class='text-nowrap'>" + editButton
				+ "<button type='button' class='btn btn-link btn-sm p-0 text-danger' onclick='return ShipAndDebit.DeleteLine(" + index + ");'><i class='ri-delete-bin-line' aria-hidden='true'></i> Delete</button></td></tr>";
		});
		ShipAndDebit._$("#sd_edit_line_body").html(html || "<tr><td colspan='15'>No lines were returned for this claim.</td></tr>");
	},

	_editPayload: function (line, action) {
		if (action === "I") {
			return {
				action: action,
				sku: line.sku,
				description: line.description,
				invoiceNumber: line.invoiceNumber,
				invoiceDate: line.invoiceDate,
				uom: line.uom,
				availQty: line.availQty,
				salesPerson: line.salesPerson,
				rcPrice: line.rcPrice,
				distInvoiceNumber: line.distInvoiceNumber,
				distInvoiceDate: line.distInvoiceDate,
				distBillQty: line.distBillQty,
				distBillPrice: line.distBillPrice,
				claimValue: line.claimValue,
				lineComments: line.lineComments
			};
		}
		return {
			action: action,
			sku: line.sku,
			invoiceNumber: line.invoiceNumber,
			invoiceDate: line.invoiceDate,
			oldDistInvoice: line.originalDistInvoice,
			oldDistDate: line.originalDistDate,
			qty: line.distBillQty,
			claimValue: line.claimValue,
			newDistInvoice: line.distInvoiceNumber,
			newDistDate: line.distInvoiceDate,
			lineComments: line.lineComments,
			rcPrice: line.rcPrice
		};
	},

	_editLines: function (rows) {
		ShipAndDebit._editRows = (rows || []).map(function (row) { return ShipAndDebit._claimLine(row); });
		ShipAndDebit._paintEditLines();
	},

	_cell: function (cls, value) {
		return "<td><input class='form-control form-control-sm " + cls + "' value='" + ShipAndDebit._esc(value) + "'></td>";
	},

	_files: function (claimNumber, onLoaded, onFailed) {
		var context = ShipAndDebit._context();
		var started = Date.now();
		var loadingHtml = "<div class='text-muted' role='status' aria-live='polite'>"
			+ "<span class='spinner-border spinner-border-sm me-2' aria-hidden='true'></span>"
			+ "Connecting to document storage and loading this claim's file list...</div>";
		ShipAndDebit._$("#sd_edit_files,#sd_edit_upload_existing").html(loadingHtml);
		var waitTimer = window.setInterval(function () {
			if (claimNumber !== ShipAndDebit._openClaimNumber) return;
			var seconds = Math.floor((Date.now() - started) / 1000);
			var waitMessage = seconds >= 10
				? "The document share is taking longer than expected (" + seconds + "s). Still loading the file list..."
				: "Connecting to document storage (" + seconds + "s elapsed)...";
			var waitingHtml = "<div class='text-warning' role='status' aria-live='polite'>"
				+ "<span class='spinner-border spinner-border-sm me-2' aria-hidden='true'></span>"
				+ waitMessage + "</div>";
			ShipAndDebit._$("#sd_edit_files,#sd_edit_upload_existing").html(waitingHtml);
		}, 5000);
		var failed = function (message) {
			window.clearInterval(waitTimer);
			ShipAndDebit._$("#sd_edit_files,#sd_edit_upload_existing").html(
				"<div class='text-danger' role='alert'>Stored documents could not be loaded. Close and reopen this window to try again.</div>");
			if (typeof onFailed === "function") onFailed(message);
		};
		ShipAndDebit._get("/documents/list?claimNumber=" + encodeURIComponent(claimNumber), function (names) {
			window.clearInterval(waitTimer);
			if (claimNumber !== ShipAndDebit._openClaimNumber) return;
			ShipAndDebit._editStoredDocuments = names || [];
			var html = "<div class='fw-semibold mb-1'>Existing documents</div>"
				+ "<div class='table-responsive'><table class='table table-sm table-bordered mb-0 sd-document-table sd-existing-document-table'>"
				+ "<thead><tr><th>Sl No</th><th>File</th><th>Status</th><th>Actions</th></tr></thead><tbody>";
			if (!ShipAndDebit._editStoredDocuments.length) {
				html += "<tr><td colspan='4' class='text-muted'>No documents stored for this claim.</td></tr>";
			} else {
				ShipAndDebit._editStoredDocuments.forEach(function (name, index) {
					html += "<tr><td class='text-center'>" + (index + 1) + "</td><td class='sd-file-name'>"
						+ ShipAndDebit._esc(name) + "</td><td>Existing</td><td>"
						+ "<a class='btn btn-sm btn-outline-primary' target='_blank' rel='noopener' title='View "
						+ ShipAndDebit._esc(name) + "' aria-label='View " + ShipAndDebit._esc(name) + "' href='"
						+ (window.$app_url || "") + ShipAndDebit._api + "/documents?name="
						+ encodeURIComponent(name) + "&claimNumber=" + encodeURIComponent(claimNumber)
						+ "&custCode=" + encodeURIComponent(context.custCode)
						+ "&loginId=" + encodeURIComponent(context.loginId) + "'><i class='ri-eye-line' aria-hidden='true'></i></a> "
						+ "<button type='button' class='btn btn-sm btn-outline-danger' data-sd-delete-existing='" + index
						+ "' title='Delete " + ShipAndDebit._esc(name) + "' aria-label='Delete " + ShipAndDebit._esc(name)
						+ "'><i class='ri-delete-bin-line' aria-hidden='true'></i></button></td></tr>";
				});
			}
			html += "</tbody></table></div>";
			ShipAndDebit._$("#sd_edit_files").html(html);
			ShipAndDebit._renderEditUploadOnlyExisting();
			if (typeof onLoaded === "function") onLoaded(ShipAndDebit._editStoredDocuments);
		}, failed, { silent: true });
	},

	_pick: function (row, names) {
		if (!row) return "";
		var found = "";
		Object.keys(row).forEach(function (key) {
			if (found) return;
			names.forEach(function (name) {
				if (name.toLowerCase() === String(key).toLowerCase()) found = row[key];
			});
		});
		return found == null ? "" : String(found);
	},

	_lookupColumn: function (row, names, index) {
		var value = ShipAndDebit._pick(row, names);
		if (value !== "") return value.trim();
		var keys = Object.keys(row || {});
		var positional = keys[index] == null ? "" : row[keys[index]];
		return positional == null ? "" : String(positional).trim();
	},

	_esc: function (value) {
		return String(value == null ? "" : value)
			.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
	},

	_table: function (rootId, tableId, tbodyId, columns, rows) {
		if (!ShipAndDebit._ready[tableId] && window.Common && Common.DataTable) {
			Common.DataTable.init({
				rootId: rootId, tableId: tableId, tbodyId: tbodyId,
				pageSizes: [15, 30, 45], pageSize: 15, filter_type: "full",
				stickyHeader: true, fillWidth: true, cellBorder: "full", maxHeight: "420px",
				emptyMessage: "No rows.", columns: columns, rows: []
			});
			ShipAndDebit._ready[tableId] = true;
		}
		if (window.Common && Common.DataTable) Common.DataTable.setData(rootId, rows);
		ShipAndDebit._placeRefresh(rootId);
	},

	_placeRefresh: function (rootId) {
		var keys = { m_sd_edit: "edit", m_sd_status: "status", m_sd_accepted: "accepted", m_sd_pending: "pending" };
		var key = keys[rootId];
		if (!key) return;
		var root = ShipAndDebit._el("#" + String(rootId || "").replace(/^#/, ""));
		if (!root) return;
		var bar = root.querySelector(".dt-toolbar");
		if (!bar || bar.querySelector(".sd-refresh")) return;
		var btn = document.createElement("button");
		btn.type = "button";
		btn.className = "btn btn-sm btn-outline-secondary sd-refresh";
		btn.innerHTML = '<i class="ri-refresh-line" aria-hidden="true"></i> Refresh';
		btn.onclick = function () { return ShipAndDebit.Refresh(key); };
		bar.appendChild(btn);
	},

	_columns: function (rows, fallback) {
		var first = rows && rows[0];
		if (!first) return fallback;
		var cols = [];
		Object.keys(first).forEach(function (key) {
			cols.push({ title: key, field: key });
		});
		return cols.length ? cols : fallback;
	},

	_fillSelect: function (selector, rows, names) {
		var $select = ShipAndDebit._$(selector);
		$select.empty().append("<option value=''>Select</option>");
		(rows || []).forEach(function (row) {
			var code = "";
			var label = "";
			Object.keys(row).forEach(function (key) {
				var wanted = names.some(function (name) { return name.toLowerCase() === key.toLowerCase(); });
				if (wanted && !code) code = String(row[key] || "");
			});
			if (!code) code = String(Object.values(row)[0] || "");
			label = Object.values(row).filter(function (v) { return v != null && String(v) !== ""; }).join(" - ");
			$select.append($("<option>").val(code).text(label || code));
		});
	},

	_lock: function (locked) {
		$("#m_ship_and_debit .sd-submit").prop("disabled", locked);
	},

	_context: function () {
		if (window.Common && Common.GetProcedureCustomerContext) {
			var context = Common.GetProcedureCustomerContext() || {};
			return { custCode: String(context.custCode || "").trim(), loginId: String(context.loginId || "").trim() };
		}
		return { custCode: "", loginId: "" };
	},

	_spin: function (show) {
		if (typeof showLoader !== "function" || typeof hideLoader !== "function") return;
		if (show) {
			ShipAndDebit._busy = (ShipAndDebit._busy || 0) + 1;
			showLoader("Please wait...", ShipAndDebit.ROOT);
			return;
		}
		ShipAndDebit._busy = Math.max(0, (ShipAndDebit._busy || 1) - 1);
		if (ShipAndDebit._busy === 0) hideLoader(ShipAndDebit.ROOT);
	},

	_get: function (path, ok, fail, options) {
		var showLoader = !(options && options.silent);
		if (showLoader) ShipAndDebit._spin(true);
		$.ajax({
			url: (window.$app_url || "") + ShipAndDebit._api + path,
			method: "GET", data: ShipAndDebit._context(), dataType: "json",
			xhrFields: { withCredentials: true },
			complete: function () { if (showLoader) ShipAndDebit._spin(false); },
			success: function (json) { ShipAndDebit._done(json, ok, fail); },
			error: function () {
				if (typeof fail === "function") fail();
				Common.showPageMsg(ShipAndDebit.ROOT, "The request could not be completed.", "danger");
			}
		});
	},

	_post: function (path, body, ok, fail) {
		var json = typeof body === "string";
		ShipAndDebit._spin(true);
		$.ajax({
			url: (window.$app_url || "") + ShipAndDebit._api + path,
			method: "POST", data: body, dataType: "json",
			contentType: json ? "application/json; charset=utf-8" : "application/x-www-form-urlencoded; charset=utf-8",
			xhrFields: { withCredentials: true },
			complete: function () { ShipAndDebit._spin(false); },
			success: function (jsonResponse) { ShipAndDebit._done(jsonResponse, ok, fail); },
			error: function () {
				ShipAndDebit._fail("The request could not be completed.");
				if (typeof fail === "function") fail("The request could not be completed.");
			}
		});
	},

	_postMultipart: function (path, form, ok, fail) {
		$.ajax({
			url: (window.$app_url || "") + ShipAndDebit._api + path,
			method: "POST", data: form, processData: false, contentType: false,
			dataType: "json", xhrFields: { withCredentials: true },
			success: function (json) { ShipAndDebit._done(json, ok, fail); },
			error: function (xhr) {
				if (window.console && typeof console.error === "function") {
					console.error("Ship & Debit document HTTP request error", {
						status: xhr ? xhr.status : 0,
						statusText: xhr ? xhr.statusText : "",
						response: xhr && xhr.responseJSON
							? xhr.responseJSON : (xhr && xhr.responseText ? String(xhr.responseText).slice(0, 500) : "")
					});
				}
				if (xhr && xhr.responseJSON) {
					ShipAndDebit._done(xhr.responseJSON, function () {}, fail);
					return;
				}
				var message = xhr && xhr.status
					? "Document request failed with HTTP " + xhr.status + " " + (xhr.statusText || "") + "."
					: "The document request could not be completed.";
				if (xhr && xhr.responseText) {
					message += " " + String(xhr.responseText).replace(/\s+/g, " ").slice(0, 500);
				}
				ShipAndDebit._fail(message);
				if (typeof fail === "function") fail(message);
			}
		});
	},

	_fail: function (message) {
		var text = message || "The request could not be completed.";
		var terms = ShipAndDebit._el("#sd_terms_modal");
		if (terms && terms.classList.contains("show")) ShipAndDebit._termsMsg(text);
		Common.showPageMsg(ShipAndDebit.ROOT, text, "danger");
	},

	_done: function (json, ok, fail) {
		if (window.inpcIsSessionExpiredPayload && window.inpcIsSessionExpiredPayload(json)) {
			window.inpcHandleSessionExpired(json && (json.message || json.data));
			if (typeof fail === "function") fail();
			return;
		}
		var code = json && (json.errorCode != null ? json.errorCode : json.error_code);
		if (!json || (code != null && Number(code) !== 0)) {
			var message = (json && json.message) || "The request could not be completed.";
			ShipAndDebit._fail(message);
			if (typeof fail === "function") fail(message);
			return;
		}
		ok(json.data);
	}
};
