/**
 * Create Claim. Loaded by ship_and_debit.js the first time that tab is opened.
 */
ShipAndDebitCreate = {
	_ready: false,
	_claimNumber: "",
	_lines: [],
	_editIndex: -1,
	_editProductOptionsHtml: "",
	_savingEdit: false,
	_confirmingSubmit: false,
	_documents: [],
	_invoiceTaxType: "",
	_extraTaxPercent: 0,
	_endCustomerChoices: null,
	_choicesLoading: false,
	_choicesWaiters: [],
	_loading: false,
	_lateStatus: "idle",
	_lateLookupToken: 0,
	_checkKey: "",
	_checkedKey: "",
	_checkWaiters: [],
	_settingDistDate: false,

	Load: function () {
		if (ShipAndDebitCreate._ready || ShipAndDebitCreate._loading) return;
		ShipAndDebitCreate._loading = true;
		ShipAndDebitCreate._ensureChoices(function () {
			ShipAndDebit._$("#sd_create_body").load((window.$app_url || "") + "html_files/SHIPANDDEBIT/create_claim.html?r=" + Date.now(), function () {
				ShipAndDebitCreate._loading = false;
				ShipAndDebitCreate._ready = true;
				ShipAndDebitCreate._initClaimMonthPicker();
				ShipAndDebitCreate._bindDocuments();
				ShipAndDebit._get("/divisions", function (rows) {
					ShipAndDebit._fillSelect("#sd_division", rows, ["DIVCODE", "DIVNAME"]);
					ShipAndDebit._$("#sd_division option:first").text("Choose your option");
				});
				ShipAndDebit._$("#sd_division").on("change", function () {
					ShipAndDebitCreate._touchEntry();
					ShipAndDebitCreate._destroyEndCustomerChoices();
					ShipAndDebit._get("/end-customers?division=" + encodeURIComponent(this.value || ""), function (rows) {
						ShipAndDebitCreate._fillEndCustomers(rows);
						ShipAndDebitCreate._bindEndCustomerChoices();
						ShipAndDebitCreate._touchEntry();
					});
				});
				ShipAndDebit._$("#sd_end_customer").on("change", function () { ShipAndDebitCreate._touchEntry(); });
				ShipAndDebit._$("#sd_product").off("change.sd").on("change.sd", function () { ShipAndDebitCreate.LoadInvoices(); ShipAndDebitCreate._touchLine(); });
				ShipAndDebit._$("#sd_invoice").off("change.sd").on("change.sd", function () { ShipAndDebitCreate.SelectInvoice(); ShipAndDebitCreate._touchLine(); });
				ShipAndDebit._$("#sd_dist_invoice").off("change.sd").on("change.sd", function () { ShipAndDebitCreate.CheckLine(); });
				ShipAndDebit._$("#sd_product, #sd_invoice, #sd_dist_invoice, #sd_dist_date, #sd_dist_qty").off("change.gap input.gap").on("change.gap input.gap", function () {
					ShipAndDebitCreate._touchLine();
				});
				ShipAndDebit._$("#sd_dist_qty").off("input.quantityOnly").on("input.quantityOnly", function () {
					ShipAndDebit._sanitizeQuantityInput(this);
				});
				ShipAndDebit._$("#sd_dist_qty").off("input.claimValue change.claimValue")
					.on("input.claimValue change.claimValue", ShipAndDebitCreate._calculateClaimValue);
			});
		});
	},

	_ensureChoices: function (done) {
		if (typeof window.Choices === "function") {
			ShipAndDebitCreate._ensureChoicesCss();
			done();
			return;
		}
		ShipAndDebitCreate._choicesWaiters.push(done);
		if (ShipAndDebitCreate._choicesLoading) return;
		ShipAndDebitCreate._choicesLoading = true;
		var script = document.createElement("script");
		script.src = (window.$app_url || "") + "nuiassets/libs/choices.js/public/assets/scripts/choices.min.js";
		script.onload = function () {
			ShipAndDebitCreate._choicesLoading = false;
			if (typeof window.Choices === "function") {
				ShipAndDebitCreate._ensureChoicesCss();
			} else {
				Common.showPageMsg(ShipAndDebit.ROOT, "Searchable End Customer control could not be initialized.", "warning");
			}
			var waiters = ShipAndDebitCreate._choicesWaiters.splice(0);
			waiters.forEach(function (callback) { callback(); });
		};
		script.onerror = function () {
			ShipAndDebitCreate._choicesLoading = false;
			Common.showPageMsg(ShipAndDebit.ROOT, "Unable to load the searchable End Customer control.", "warning");
			var waiters = ShipAndDebitCreate._choicesWaiters.splice(0);
			waiters.forEach(function (callback) { callback(); });
		};
		document.head.appendChild(script);
	},

	_ensureChoicesCss: function () {
		if (document.getElementById("sd_choices_css")) return;
		var link = document.createElement("link");
		link.id = "sd_choices_css";
		link.rel = "stylesheet";
		link.href = (window.$app_url || "") + "nuiassets/libs/choices.js/public/assets/styles/choices.min.css";
		link.onerror = function () {
			Common.showPageMsg(ShipAndDebit.ROOT, "Unable to load End Customer search styling.", "warning");
		};
		document.head.appendChild(link);
	},

	_destroyEndCustomerChoices: function () {
		if (!ShipAndDebitCreate._endCustomerChoices) return;
		ShipAndDebitCreate._endCustomerChoices.destroy();
		ShipAndDebitCreate._endCustomerChoices = null;
	},

	_bindEndCustomerChoices: function () {
		var select = ShipAndDebit._el("#sd_end_customer");
		if (!select || typeof window.Choices !== "function") return;
		ShipAndDebitCreate._destroyEndCustomerChoices();
		ShipAndDebitCreate._endCustomerChoices = new window.Choices(select, {
			searchEnabled: true,
			searchChoices: true,
			searchFields: ["label", "value"],
			searchFloor: 0,
			searchResultLimit: 100,
			searchPlaceholderValue: "Type to search end customers...",
			shouldSort: false,
			itemSelectText: "",
			position: "bottom",
			allowHTML: false
		});
		var updateTitle = function () {
			var selected = select.options[select.selectedIndex];
			var title = selected ? selected.text : "";
			select.title = title;
			var inner = select.parentNode && select.parentNode.querySelector(".choices__inner");
			if (inner) inner.title = title;
		};
		ShipAndDebit._$("#sd_end_customer").off("change.sdCustomerTitle")
			.on("change.sdCustomerTitle", updateTitle);
		updateTitle();
	},

	_fillEndCustomers: function (rows) {
		var $select = ShipAndDebit._$("#sd_end_customer").empty();
		$select.append($("<option></option>").val("").text("Choose your option"));
		(rows || []).forEach(function (row) {
			var code = "";
			var values = Object.keys(row || {}).map(function (key) {
				return ShipAndDebitCreate._decodeCustomerName(row[key]);
			}).filter(function (value) { return value !== ""; });
			Object.keys(row || {}).forEach(function (key) {
				if (key.toLowerCase() === "endusrcode") code = String(row[key] == null ? "" : row[key]);
			});
			if (!code) code = values[0] || "";
			var label = values.filter(function (value) { return value !== code; }).join(" - ");
			label = label ? code + " - " + label : code;
			$select.append($("<option></option>").val(code).text(label));
		});
	},

	_initClaimMonthPicker: function () {
		var $month = ShipAndDebit._$("#sd_claim_month");
		if (!$month.length || !window.jQuery || !$.fn.datepicker) return;
		$month.prop("readonly", true);
		if ($month.data("datepicker")) $month.datepicker("destroy");
		$month.datepicker({
			autoclose: true,
			forceParse: false,
			showOnFocus: false,
			format: "M-yyyy",
			startView: "months",
			minViewMode: "months",
			orientation: "bottom auto"
		});
		$month.off("changeDate.sdClaimMonth change.sdClaimMonth")
			.on("changeDate.sdClaimMonth change.sdClaimMonth", function () {
				ShipAndDebitCreate._touchEntry();
			});
		ShipAndDebit._$("#sd_claim_month_button").off("click.sdClaimMonth")
			.on("click.sdClaimMonth", function () {
				$month.datepicker("show");
			});
	},

	_decodeCustomerName: function (value) {
		var entities = { amp: "&", lt: "<", gt: ">", quot: "\"", apos: "'", "#39": "'" };
		return String(value == null ? "" : value).replace(
			/&(?:amp|lt|gt|quot|apos|#39|#\d+|#x[0-9a-f]+);/gi,
			function (entity) {
				var key = entity.slice(1, -1).toLowerCase();
				if (Object.prototype.hasOwnProperty.call(entities, key)) return entities[key];
				var codePoint = key.charAt(1) === "x"
					? parseInt(key.slice(2), 16) : parseInt(key.slice(1), 10);
				try {
					return codePoint > 0 && codePoint <= 0x10ffff
						? String.fromCodePoint(codePoint) : entity;
				} catch (error) {
					return entity;
				}
			});
	},

	_entryGap: function () {
		var missing = [];
		if (!ShipAndDebit._$("#sd_division").val()) missing.push("division");
		if (!ShipAndDebit._$("#sd_end_customer").val()) missing.push("end customer");
		if (!ShipAndDebit._$("#sd_claim_month").val()) missing.push("claim month");
		if (!missing.length) return "";
		if (missing.length === 1) return "Select " + missing[0] + ".";
		var last = missing.pop();
		return "Select " + missing.join(", ") + " and " + last + ".";
	},

	_touchEntry: function () {
		var $msg = ShipAndDebit._$("#inpc_page_msg");
		if (!$msg.length || $msg.hasClass("d-none") || ($msg.text() || "").indexOf("Select ") !== 0) return;
		var gap = ShipAndDebitCreate._entryGap();
		if (!gap) ShipAndDebit.HideMsg();
		else Common.showPageMsg(ShipAndDebit.ROOT, gap, "warning");
	},

	OpenEntry: function () {
		var gap = ShipAndDebitCreate._entryGap();
		if (gap) {
			Common.showPageMsg(ShipAndDebit.ROOT, gap, "warning");
			return false;
		}
		ShipAndDebit.HideMsg();
		ShipAndDebit._$(".sd-header").prop("disabled", true);
		ShipAndDebit._$("#sd_open_entry").prop("disabled", true);
		ShipAndDebit._$("#sd_entry").removeClass("d-none");
		ShipAndDebitCreate._dates();
		ShipAndDebitCreate._loadLookups();
		return false;
	},

	Reset: function () {
		ShipAndDebit.HideMsg();
		ShipAndDebitCreate._destroyEndCustomerChoices();
		ShipAndDebitCreate._clearDocuments();
		ShipAndDebitCreate._lines = [];
		ShipAndDebitCreate._claimNumber = "";
		ShipAndDebitCreate._editIndex = -1;
		ShipAndDebitCreate._editProductOptionsHtml = "";
		ShipAndDebitCreate._savingEdit = false;
		ShipAndDebitCreate._confirmingSubmit = false;
		ShipAndDebitCreate._loading = false;
		ShipAndDebitCreate._invoiceTaxType = "";
		ShipAndDebitCreate._extraTaxPercent = 0;
		ShipAndDebitCreate._late = "N";
		ShipAndDebitCreate._lateStatus = "idle";
		ShipAndDebitCreate._lateLookupToken++;
		ShipAndDebitCreate._cancelLineCheck(true);
		ShipAndDebitCreate._ready = false;
		ShipAndDebit._$("#sd_create_body").empty();
		ShipAndDebitCreate.Load();
		return false;
	},

	_bindDocuments: function () {
		ShipAndDebit._$("#sd_choose_files").off("click.sdDocs").on("click.sdDocs", function () {
			ShipAndDebit._$("#sd_file_picker").trigger("click");
		});
		ShipAndDebit._$("#sd_file_picker").off("change.sdDocs").on("change.sdDocs", function () {
			ShipAndDebitCreate._addDocuments(this.files);
			this.value = "";
		});
		ShipAndDebit._$("#sd_selected_files").off("click.sdDocs", "[data-sd-remove-file]")
			.on("click.sdDocs", "[data-sd-remove-file]", function () {
				ShipAndDebitCreate._removeDocument(Number(this.getAttribute("data-sd-remove-file")));
			});
		ShipAndDebit._$("#sd_selected_files").off("click.sdDocs", "[data-sd-view-file]")
			.on("click.sdDocs", "[data-sd-view-file]", function (event) {
				event.preventDefault();
				var selected = ShipAndDebitCreate._documents[Number(this.getAttribute("data-sd-view-file"))];
				if (selected) window.open(selected.url, "_blank", "noopener");
			});
		ShipAndDebit._$("#sd_retry_docs").off("click.sdDocs").on("click.sdDocs", function () {
			ShipAndDebitCreate.RetryDocuments();
		});
		ShipAndDebitCreate._renderDocuments();
	},

	_addDocuments: function (fileList) {
		var added = Array.prototype.slice.call(fileList || []);
		if (!added.length) return;
		var allowed = /\.(zip|7z|jpe?g|png|gif|pdf|tiff?|bmp|bpg|fax|img)$/i;
		for (var i = 0; i < added.length; i++) {
			var safeName = ShipAndDebit._safeDocumentFileName(added[i].name);
			if (!safeName) {
				ShipAndDebit._showDocumentError("#sd_document_error",
					"A selected document has an invalid filename. Rename it and try again.");
				return;
			}
			var nameKey = safeName.toLowerCase();
			if (!allowed.test(added[i].name)) {
				ShipAndDebit._showDocumentError("#sd_document_error", "Only images, PDF, ZIP, or 7Z documents are allowed.");
				return;
			}
			if (added[i].size <= 0) {
				ShipAndDebit._showDocumentError("#sd_document_error", "Selected documents cannot be empty.");
				return;
			}
			if (added[i].size > ShipAndDebit.DOC_REQUEST_FILE_LIMIT_BYTES) {
				ShipAndDebit._showDocumentError("#sd_document_error",
					"Each document must be 4.5 MB or smaller. Larger files cannot fit within the 5 MB request limit.");
				return;
			}
		}
		ShipAndDebit._showDocumentError("#sd_document_error", "");
		added.forEach(function (file) {
			ShipAndDebitCreate._documents.push({
				file: file,
				url: window.URL.createObjectURL(file)
			});
		});
		ShipAndDebitCreate._renderDocuments();
	},

	_removeDocument: function (index) {
		var selected = ShipAndDebitCreate._documents[index];
		if (!selected) return;
		window.URL.revokeObjectURL(selected.url);
		ShipAndDebitCreate._documents.splice(index, 1);
		ShipAndDebitCreate._renderDocuments();
		ShipAndDebit._showDocumentError("#sd_document_error", "");
	},

	_clearDocuments: function () {
		ShipAndDebitCreate._documents.forEach(function (item) {
			window.URL.revokeObjectURL(item.url);
		});
		ShipAndDebitCreate._documents = [];
		ShipAndDebitCreate._renderDocuments();
	},

	_renderDocuments: function () {
		var files = ShipAndDebitCreate._documents;
		var html = "";
		var totalBytes = files.reduce(function (total, item) {
			return total + (Number(item.file.size) || 0);
		}, 0);
		if (!files.length) {
			html = "<tr><td colspan='4' class='text-muted'>No documents selected.</td></tr>";
		}
		files.forEach(function (item, index) {
			html += "<tr><td class='text-center'>" + (index + 1) + "</td>"
				+ "<td class='sd-file-name'>" + ShipAndDebit._esc(item.file.name) + "</td>"
				+ "<td class='text-nowrap'>" + ShipAndDebitCreate._formatSize(item.file.size) + "</td><td class='text-nowrap'>"
				+ "<button type='button' class='btn btn-sm btn-outline-primary me-1' data-sd-view-file='"
				+ index + "' title='View " + ShipAndDebit._esc(item.file.name) + "' aria-label='View " + ShipAndDebit._esc(item.file.name)
				+ "'><i class='ri-eye-line' aria-hidden='true'></i></button>"
				+ "<button type='button' class='btn btn-sm btn-outline-danger' data-sd-remove-file='"
				+ index + "' title='Remove " + ShipAndDebit._esc(item.file.name) + "' aria-label='Remove " + ShipAndDebit._esc(item.file.name)
				+ "'><i class='ri-delete-bin-line' aria-hidden='true'></i></button></td></tr>";
		});
		ShipAndDebit._$("#sd_selected_files").html(html);
		ShipAndDebit._$("#sd_document_total").toggleClass("d-none", files.length <= 2)
			.text("Total size (" + files.length + " files): " + ShipAndDebitCreate._formatSize(totalBytes));
	},

	_formatSize: function (bytes) {
		return bytes < 1024 * 1024
			? Math.max(1, Math.round(bytes / 1024)) + " KB"
			: (bytes / (1024 * 1024)).toFixed(2) + " MB";
	},

	_uploadDocuments: function (claimNumber, done) {
		ShipAndDebit._startDocumentProgress(claimNumber, "created", ShipAndDebitCreate._documents, done);
	},

	RetryDocuments: function () {
		var claimNumber = ShipAndDebitCreate._claimNumber;
		if (!claimNumber || !ShipAndDebitCreate._documents.length) return false;
		ShipAndDebitCreate._uploadDocuments(claimNumber, function (uploaded) {
			if (uploaded) {
				ShipAndDebitCreate._clearDocuments();
				ShipAndDebit._$("#sd_retry_docs").addClass("d-none");
				ShipAndDebit._$("#sd_saved_claim").text("Claim " + claimNumber + " and supporting documents were saved.");
				Common.showPageMsg(ShipAndDebit.ROOT, "Supporting documents stored for claim " + claimNumber + ".", "success");
			} else {
				ShipAndDebit._$("#sd_retry_docs").removeClass("d-none");
				Common.showPageMsg(ShipAndDebit.ROOT, "Claim " + claimNumber
					+ " was saved, but some documents could not be uploaded. Retry the failed uploads.", "warning");
			}
		});
		return false;
	},

	_month: function () {
		var value = String(ShipAndDebit._$("#sd_claim_month").val() || "").trim();
		var monthYear = value.match(/^(\d{1,2})\/(\d{4})$/);
		if (monthYear) return monthYear[2] + monthYear[1].padStart(2, "0");
		var namedMonthYear = value.match(/^([A-Za-z]{3})-(\d{4})$/);
		if (namedMonthYear) {
			var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			var monthIndex = months.indexOf(namedMonthYear[1].slice(0, 1).toUpperCase()
				+ namedMonthYear[1].slice(1).toLowerCase());
			if (monthIndex >= 0) return namedMonthYear[2] + String(monthIndex + 1).padStart(2, "0");
		}
		var yearMonth = value.match(/^(\d{4})-(\d{2})$/);
		if (yearMonth) return yearMonth[1] + yearMonth[2];
		return "";
	},

	_col: function (row, names, index) {
		var named = ShipAndDebit._pick(row, names);
		if (named) return named;
		var keys = Object.keys(row || {});
		var value = keys[index] == null ? "" : row[keys[index]];
		return value == null ? "" : String(value).trim();
	},

	_today: function () {
		var now = new Date();
		var month = String(now.getMonth() + 1).padStart(2, "0");
		var day = String(now.getDate()).padStart(2, "0");
		return String(now.getFullYear()) + month + day;
	},

	_showDate: function (value) {
		var raw = String(value || "").replace(/\D/g, "");
		if (!/^\d{8}$/.test(raw)) return "";
		return raw.substr(6, 2) + "/" + raw.substr(4, 2) + "/" + raw.substr(0, 4);
	},

	_dates: function () {
		var $el = ShipAndDebit._$("#sd_dist_date");
		if (!window.jQuery || !$.fn.datepicker || !$el.length) return;
		$el.prop("readonly", true);
		var bounds = ShipAndDebit._claimMonthDateBounds(
			ShipAndDebitCreate._month(), ShipAndDebit._$("#sd_invoice_date").attr("data-ymd"));
		if ($el.data("datepicker")) {
			$el.datepicker("setStartDate", bounds ? bounds.startDate : false)
				.datepicker("setEndDate", bounds ? bounds.endDate : new Date());
		} else {
			$el.datepicker({
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true,
				forceParse: false,
				showOnFocus: false,
				format: "dd/mm/yyyy",
				startDate: bounds ? bounds.startDate : false,
				endDate: bounds ? bounds.endDate : new Date(),
				orientation: "bottom auto"
			});
		}
		$el.off("changeDate.sdCreate changeDate.sd").on("changeDate.sdCreate", function () {
			if (ShipAndDebitCreate._settingDistDate) return;
			ShipAndDebitCreate.CheckLine();
		});
	},

	_clearDistDate: function () {
		var $date = ShipAndDebit._$("#sd_dist_date");
		ShipAndDebitCreate._settingDistDate = true;
		$date.val("");
		if ($date.data("datepicker")) $date.datepicker("clearDates");
		ShipAndDebitCreate._settingDistDate = false;
	},

	ShowDistDate: function () {
		ShipAndDebitCreate._dates();
		var $el = ShipAndDebit._$("#sd_dist_date");
		if ($el.data("datepicker")) $el.datepicker("show");
		return false;
	},

	_loadLookups: function () {
		var division = ShipAndDebit._$("#sd_division").val() || "";
		var endCustomer = ShipAndDebit._$("#sd_end_customer").val() || "";
		ShipAndDebitCreate._loadLateFlag();
		ShipAndDebit._get("/skus?endCustomer=" + encodeURIComponent(endCustomer)
			+ "&division=" + encodeURIComponent(division), function (rows) {
			ShipAndDebitCreate._fillProducts(rows || []);
		});
	},

	_loadLateFlag: function () {
		var division = ShipAndDebit._$("#sd_division").val() || "";
		var month = ShipAndDebitCreate._month();
		var lookupToken = ++ShipAndDebitCreate._lateLookupToken;
		ShipAndDebitCreate._lateStatus = "loading";
		ShipAndDebitCreate._late = "";
		ShipAndDebit._$("#sd_late_wrap").addClass("d-none");
		ShipAndDebit._$("#sd_late").prop("required", false).attr("aria-required", "false");
		ShipAndDebit._get("/late-flag?division=" + encodeURIComponent(division)
			+ "&claimMonth=" + encodeURIComponent(month), function (rows) {
			if (lookupToken !== ShipAndDebitCreate._lateLookupToken) return;
			var row = rows && rows[0];
			var flag = row ? String(ShipAndDebitCreate._col(row, ["LSSTS"], 0)).trim().toUpperCase() : "";
			if (flag !== "Y" && flag !== "N") {
				ShipAndDebitCreate._lateStatus = "error";
				Common.showPageMsg(ShipAndDebit.ROOT, "Late submission status could not be verified. Please try again.", "danger");
				return;
			}
			ShipAndDebitCreate._late = flag;
			ShipAndDebitCreate._lateStatus = "ready";
			var required = flag === "Y";
			ShipAndDebit._$("#sd_late_wrap").toggleClass("d-none", !required);
			ShipAndDebit._$("#sd_late").prop("required", required).attr("aria-required", required ? "true" : "false");
		}, function () {
			if (lookupToken === ShipAndDebitCreate._lateLookupToken) ShipAndDebitCreate._lateStatus = "error";
		});
	},

	_fillProducts: function (rows) {
		var $select = ShipAndDebit._$("#sd_product").empty().append("<option value=''>Choose your option</option>");
		rows.forEach(function (row) {
			var code = ShipAndDebitCreate._col(row, ["SKUCODE"], 0);
			var name = ShipAndDebitCreate._col(row, ["SKUDES"], 1);
			if (!code) return;
			$select.append($("<option>").val(code).text((code + " - " + name).trim()));
		});
	},

	LoadInvoices: function () {
		var sku = ShipAndDebit._$("#sd_product").val() || "";
		ShipAndDebit._$("#sd_sku").val($.trim(sku));
		ShipAndDebitCreate._clearDerived();
		ShipAndDebit._$("#sd_invoice").empty().append("<option value=''>Choose your option</option>");
		if (!sku) return false;
		ShipAndDebit._get("/invoices?sku=" + encodeURIComponent(sku)
			+ "&claimMonth=" + encodeURIComponent(ShipAndDebitCreate._month()), function (rows) {
			if (!rows || !rows.length) {
				Common.showPageMsg(ShipAndDebit.ROOT, "No invoice number found for this SKU Code.", "warning");
				return;
			}
			var $select = ShipAndDebit._$("#sd_invoice").empty().append("<option value=''>Choose your option</option>");
			rows.forEach(function (row) {
				var number = ShipAndDebitCreate._col(row, ["INVOICENUM"], 0);
				var date = ShipAndDebitCreate._col(row, ["INVOICEDATE"], 1).replace(/\D/g, "");
				if (!number) return;
				$("<option>").val(number).attr("data-ymd", date).text(number).appendTo($select);
			});
		});
		return false;
	},

	SelectInvoice: function () {
		var option = ShipAndDebit._$("#sd_invoice option:selected");
		var raw = option.attr("data-ymd") || "";
		ShipAndDebit._$("#sd_invoice_date").val(ShipAndDebitCreate._showDate(raw)).attr("data-ymd", raw);
		ShipAndDebitCreate._invoiceTaxType = "";
		ShipAndDebitCreate._extraTaxPercent = 0;
		ShipAndDebit._$("#sd_dist_invoice,#sd_avail_qty,#sd_dist_qty,#sd_uom,#sd_sales,#sd_rc_price,#sd_inv_price,#sd_tax,#sd_cgst,#sd_igst,#sd_freight,#sd_discount").val("");
		ShipAndDebitCreate._clearDistDate();
		ShipAndDebitCreate._calculateClaimValue();
		ShipAndDebitCreate._dates();
		var claimMonth = ShipAndDebitCreate._month();
		if (/^\d{8}$/.test(raw) && claimMonth && raw.substr(0, 6) > claimMonth) {
			ShipAndDebit._$("#sd_invoice").val("");
			ShipAndDebit._$("#sd_invoice_date").val("").attr("data-ymd", "");
			Common.showPageMsg(ShipAndDebit.ROOT,
				"Selected 3M Invoice Date should be Lesser than the Dist Invoice Date. Please select different 3M Invoice.",
				"warning");
		}
		return false;
	},

	_cancelLineCheck: function (clearChecked) {
		var waiters = ShipAndDebitCreate._checkWaiters || [];
		ShipAndDebitCreate._checkKey = "";
		if (clearChecked) ShipAndDebitCreate._checkedKey = "";
		ShipAndDebitCreate._checkWaiters = [];
		waiters.forEach(function (done) {
			if (typeof done === "function") done(false);
		});
	},

	_clearDerived: function () {
		ShipAndDebitCreate._cancelLineCheck(true);
		ShipAndDebitCreate._invoiceTaxType = "";
		ShipAndDebitCreate._extraTaxPercent = 0;
		ShipAndDebit._$("#sd_invoice_date").val("").attr("data-ymd", "");
		ShipAndDebit._$("#sd_dist_invoice,#sd_avail_qty,#sd_dist_qty,#sd_uom,#sd_sales,#sd_rc_price,#sd_inv_price,#sd_tax,#sd_cgst,#sd_igst,#sd_freight,#sd_discount").val("");
		ShipAndDebitCreate._clearDistDate();
		ShipAndDebitCreate._calculateClaimValue();
	},

	CheckLine: function (done) {
		if (ShipAndDebitCreate._checkTimer) clearTimeout(ShipAndDebitCreate._checkTimer);
		ShipAndDebitCreate._checkTimer = setTimeout(function () {
			ShipAndDebitCreate._runCheckLine(done);
		}, 80);
		return false;
	},

	_finishCheck: function (key, success) {
		if (ShipAndDebitCreate._checkKey !== key) return;
		ShipAndDebitCreate._checkKey = "";
		ShipAndDebitCreate._checkedKey = success ? key : "";
		var waiters = ShipAndDebitCreate._checkWaiters || [];
		ShipAndDebitCreate._checkWaiters = [];
		waiters.forEach(function (done) {
			if (typeof done === "function") done(success);
		});
	},

	_runCheckLine: function (done) {
		var distDate = ShipAndDebit._ymd("sd_dist_date");
		if (!/^\d{8}$/.test(distDate)) {
			ShipAndDebitCreate._cancelLineCheck(false);
			if (typeof done === "function") done(false);
			return false;
		}
		if (distDate > ShipAndDebitCreate._today()) {
			ShipAndDebitCreate._cancelLineCheck(true);
			ShipAndDebitCreate._clearDistDate();
			Common.showPageMsg(ShipAndDebit.ROOT, "Distributor invoice date cannot be later than today.", "warning");
			if (typeof done === "function") done(false);
			return false;
		}
		var invoiceDate = ShipAndDebit._$("#sd_invoice_date").attr("data-ymd") || "";
		var dateError = ShipAndDebit._claimDistDateError(
			ShipAndDebitCreate._month(), invoiceDate, distDate);
		if (dateError) {
			ShipAndDebitCreate._cancelLineCheck(true);
			ShipAndDebitCreate._clearDistDate();
			Common.showPageMsg(ShipAndDebit.ROOT, dateError, "warning");
			if (typeof done === "function") done(false);
			return false;
		}
		if (/^\d{8}$/.test(invoiceDate) && distDate < invoiceDate) {
			ShipAndDebitCreate._cancelLineCheck(true);
			ShipAndDebitCreate._checkedKey = "";
			ShipAndDebitCreate._clearDistDate();
			Common.showPageMsg(ShipAndDebit.ROOT, "3M invoice date should be lesser than the distributor invoice date.", "warning");
			if (typeof done === "function") done(false);
			return false;
		}
		var sku = ShipAndDebit._$("#sd_sku").val() || "";
		var invoice = ShipAndDebit._$("#sd_invoice").val() || "";
		var distNumber = $.trim(ShipAndDebit._$("#sd_dist_invoice").val() || "");
		if (!sku || !invoice || !invoiceDate || !distNumber) {
			ShipAndDebitCreate._cancelLineCheck(false);
			if (typeof done === "function") done(false);
			return false;
		}
		var key = sku + "|" + invoice + "|" + invoiceDate + "|" + distNumber + "|" + distDate;
		if (ShipAndDebitCreate._checkedKey === key) {
			if (typeof done === "function") done(true);
			return true;
		}
		if (ShipAndDebitCreate._checkKey === key) {
			if (typeof done === "function") ShipAndDebitCreate._checkWaiters.push(done);
			return false;
		}
		if (ShipAndDebitCreate._checkKey) {
			ShipAndDebitCreate._cancelLineCheck(false);
		}
		ShipAndDebitCreate._checkKey = key;
		ShipAndDebitCreate._checkWaiters = typeof done === "function" ? [done] : [];
		var query = "/claim-check?sku=" + encodeURIComponent(sku)
			+ "&invoiceNumber=" + encodeURIComponent(invoice)
			+ "&invoiceDate=" + encodeURIComponent(invoiceDate)
			+ "&distInvoiceNumber=" + encodeURIComponent(distNumber)
			+ "&distInvoiceDate=" + encodeURIComponent(distDate);
		ShipAndDebit._get(query, function (checked) {
			if (ShipAndDebitCreate._checkKey !== key) return;
			var posDate = String((checked && checked.posInvDate) || "");
			if (posDate && distDate > posDate.replace(/\D/g, "")) {
				ShipAndDebitCreate._finishCheck(key, false);
				ShipAndDebitCreate._clearDistDate();
				Common.showPageMsg(ShipAndDebit.ROOT, "POS data is collected till " + posDate
					+ ". Claims can be submitted only till this period.", "warning");
				return;
			}
			if (checked && String(checked.claimStatus || "").trim().toUpperCase() === "Y") {
				ShipAndDebitCreate._finishCheck(key, false);
				ShipAndDebit._$("#sd_dist_invoice").val("");
				ShipAndDebitCreate._clearDistDate();
				Common.showPageMsg(ShipAndDebit.ROOT, "A claim is already raised for this stock code and invoice"
					+ (checked.claimNumber ? " (claim " + checked.claimNumber + ")." : "."), "warning");
				return;
			}
			ShipAndDebitCreate._fillDetails(sku, invoice, invoiceDate, distDate, function (loaded) {
				ShipAndDebitCreate._finishCheck(key, loaded !== false);
			}, key);
		}, function () {
			if (ShipAndDebitCreate._checkKey === key) ShipAndDebitCreate._finishCheck(key, false);
		});
		return false;
	},

	_fillDetails: function (sku, invoice, invoiceDate, distDate, done, requestKey) {
		ShipAndDebit._get("/invoice-details?endCustomer=" + encodeURIComponent(ShipAndDebit._$("#sd_end_customer").val() || "")
			+ "&sku=" + encodeURIComponent(sku)
			+ "&invoiceNumber=" + encodeURIComponent(invoice)
			+ "&invoiceDate=" + encodeURIComponent(invoiceDate)
			+ "&distInvoiceDate=" + encodeURIComponent(distDate), function (detail) {
			if (requestKey && ShipAndDebitCreate._checkKey !== requestKey) {
				if (typeof done === "function") done(false);
				return;
			}
			detail = detail || {};
			// TEMP: skip the zero RC-price block so Create Claim can be tested. Restore when asked.
			// if (Number(detail.RCPRICE) === 0) {
			// 	Common.showPageMsg(ShipAndDebit.ROOT, "Rate Contract price is not valid for this period.", "warning");
			// 	return;
			// }
			ShipAndDebit._$("#sd_uom").val(detail.UMO || "");
			ShipAndDebit._$("#sd_avail_qty").val(detail.AQTY || "");
			ShipAndDebit._$("#sd_sales").val(detail.SPERSON || "");
			ShipAndDebit._$("#sd_rc_price").val(detail.RCPRICE || "");
			ShipAndDebit._$("#sd_inv_price").val(detail.DISTPPRICE || "");
			ShipAndDebit._$("#sd_tax").val(detail.TAX || "");
			ShipAndDebit._$("#sd_freight").val(detail.FRIEGHT || "");
			ShipAndDebit._$("#sd_discount").val(detail.DISCOUNT || "");
			ShipAndDebit._$("#sd_cgst").val(detail.CGST || "");
			ShipAndDebit._$("#sd_igst").val(detail.IGST || "");
			ShipAndDebitCreate._invoiceTaxType = String(detail.VATCST || "").trim().toUpperCase();
			ShipAndDebitCreate._extraTaxPercent = ShipAndDebitCreate._number(detail.extTaxPc);
			ShipAndDebitCreate._calculateClaimValue();
			if (typeof done === "function") done();
		}, function () {
			if (typeof done === "function") done(false);
		});
	},

	_number: function (value) {
		var parsed = Number(String(value == null ? "" : value).replace(/,/g, "").trim());
		return isFinite(parsed) ? parsed : 0;
	},

	_calculateClaimValue: function () {
		var quantityText = $.trim(ShipAndDebit._$("#sd_dist_qty").val() || "");
		var claimValue = 0;
		if (quantityText && ShipAndDebit._$("#sd_rc_price").val() !== ""
				&& ShipAndDebit._$("#sd_inv_price").val() !== "") {
			var priceDifference = ShipAndDebitCreate._number(ShipAndDebit._$("#sd_rc_price").val())
				- ShipAndDebitCreate._number(ShipAndDebit._$("#sd_inv_price").val());
			var differenceAmount = ShipAndDebitCreate._number(quantityText) * priceDifference;
			var taxRate = ShipAndDebitCreate._number(ShipAndDebit._$("#sd_tax").val());
			var freight = differenceAmount * ShipAndDebitCreate._number(ShipAndDebit._$("#sd_freight").val()) / 100;
			var discount = differenceAmount * ShipAndDebitCreate._number(ShipAndDebit._$("#sd_discount").val()) / 100;
			var tax = differenceAmount * taxRate / 100;
			var extraTax = 0;
			var taxType = ShipAndDebitCreate._invoiceTaxType;

			if (taxType === "SGST" || taxType === "UGST" || taxType === "IGST") {
				tax = differenceAmount * (taxRate
					+ ShipAndDebitCreate._number(ShipAndDebit._$("#sd_cgst").val())
					+ ShipAndDebitCreate._number(ShipAndDebit._$("#sd_igst").val())) / 100;
				extraTax = (freight + discount) * ShipAndDebitCreate._extraTaxPercent / 100;
			} else if (taxType === "VAT") {
				tax = (differenceAmount + freight + discount) * taxRate / 100;
			} else if (taxType === "CST") {
				tax = (differenceAmount + discount) * taxRate / 100;
			}

			var vatCutoff = new Date(2017, 6, 25);
			if (new Date() > vatCutoff && (taxType === "VAT" || taxType === "CST")) {
				tax = 0;
				extraTax = 0;
			}
			claimValue = differenceAmount + tax + freight + discount + extraTax;
		}
		ShipAndDebit._$("#sd_claim_value").val(claimValue.toFixed(2));
	},

	_lineGap: function () {
		var missing = [];
		if (!(ShipAndDebit._$("#sd_sku").val() || "").trim()) missing.push("product");
		if (!(ShipAndDebit._$("#sd_invoice").val() || "").trim()) missing.push("invoice");
		if (!(ShipAndDebit._$("#sd_dist_invoice").val() || "").trim()) missing.push("distributor invoice number");
		if (!ShipAndDebit._ymd("sd_dist_date")) missing.push("distributor invoice date");
		if (!(ShipAndDebit._$("#sd_dist_qty").val() || "").trim()) missing.push("distributor qty");
		return ShipAndDebit._requiredText(missing);
	},

	_touchLine: function () {
		var $msg = ShipAndDebit._$("#inpc_page_msg");
		if (!$msg.length || $msg.hasClass("d-none")) return;
		var text = $msg.text() || "";
		if (text.indexOf("required.") < 0) return;
		if (text.indexOf("product") < 0 && text.indexOf("invoice") < 0 && text.indexOf("distributor") < 0) return;
		var gap = ShipAndDebitCreate._lineGap();
		if (!gap) ShipAndDebit.HideMsg();
		else Common.showPageMsg(ShipAndDebit.ROOT, gap, "warning");
	},

	AddLine: function () {
		if (ShipAndDebitCreate._editIndex >= 0) return ShipAndDebitCreate.SaveEdited();
		var sku = (ShipAndDebit._$("#sd_sku").val() || "").trim();
		var invoice = (ShipAndDebit._$("#sd_invoice").val() || "").trim();
		var distInvoice = (ShipAndDebit._$("#sd_dist_invoice").val() || "").trim();
		var distQty = (ShipAndDebit._$("#sd_dist_qty").val() || "").trim();
		var distDate = ShipAndDebit._ymd("sd_dist_date");
		var gap = ShipAndDebitCreate._lineGap();
		if (gap) {
			Common.showPageMsg(ShipAndDebit.ROOT, gap, "warning");
			return false;
		}
		if (ShipAndDebitCreate._lines.length >= 35) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Maximum 35 lines can be added per claim.", "warning");
			return false;
		}
		var availMsg = ShipAndDebitCreate._availMessage(sku, invoice, distQty, -1);
		if (availMsg) {
			Common.showPageMsg(ShipAndDebit.ROOT, availMsg, "warning");
			return false;
		}
		var duplicate = ShipAndDebitCreate._duplicateLineMessage(sku, invoice, distInvoice, distDate, -1);
		if (duplicate) {
			Common.showPageMsg(ShipAndDebit.ROOT, duplicate, "warning");
			return false;
		}
		ShipAndDebit.HideMsg();
		var product = ShipAndDebit._$("#sd_product option:selected").text() || "";
		ShipAndDebitCreate._lines.push({
			sku: sku,
			description: product === "Choose your option" ? "" : product,
			invoiceNumber: invoice,
			invoiceDate: ShipAndDebit._$("#sd_invoice_date").attr("data-ymd") || String(ShipAndDebit._$("#sd_invoice_date").val() || "").replace(/\D/g, ""),
			uom: ShipAndDebit._$("#sd_uom").val() || "",
			availQty: ShipAndDebit._$("#sd_avail_qty").val() || "",
			salesPerson: ShipAndDebit._$("#sd_sales").val() || "",
			rcPrice: ShipAndDebit._$("#sd_rc_price").val() || "",
			distInvoiceNumber: distInvoice,
			distInvoiceDate: distDate,
			distBillQty: distQty,
			distBillPrice: ShipAndDebit._$("#sd_inv_price").val() || "",
			claimValue: ShipAndDebit._$("#sd_claim_value").val() || "0.00",
			tax: ShipAndDebit._$("#sd_tax").val() || "",
			taxType: ShipAndDebitCreate._invoiceTaxType,
			extraTaxPercent: ShipAndDebitCreate._extraTaxPercent,
			cgst: ShipAndDebit._$("#sd_cgst").val() || "",
			igst: ShipAndDebit._$("#sd_igst").val() || "",
			freight: ShipAndDebit._$("#sd_freight").val() || "",
			discount: ShipAndDebit._$("#sd_discount").val() || "",
			lineComments: ""
		});
		ShipAndDebitCreate._paint();
		ShipAndDebitCreate._resetLineEntry();
		Common.showPageMsg(ShipAndDebit.ROOT, "SKU added to the list. Add another, or Submit to save all lines together.", "success");
		return false;
	},

	/** Dist Qty cannot pass Avail Qty for the same SKU and 3M invoice, matching the old validateAvailQty. */
	_availMessage: function (sku, invoice, distQty, excludeIndex) {
		var billed = Number(String(distQty).replace(/,/g, ""));
		var available = Number(String(ShipAndDebit._$("#sd_avail_qty").val() || "").replace(/,/g, ""));
		if (!available && available !== 0) return "";
		if (isNaN(billed) || isNaN(available)) return "";
		var used = 0;
		(ShipAndDebitCreate._lines || []).forEach(function (line, index) {
			if (index === excludeIndex) return;
			if (String(line.sku || "").trim() === sku && String(line.invoiceNumber || "").trim() === invoice) {
				used += Number(String(line.distBillQty || "0").replace(/,/g, "")) || 0;
			}
		});
		if (billed > available) {
			return "Stock Code: " + sku + ". Available Qty: " + available
				+ ". Total Billed Quantity: " + billed + ". Kindly Modify Distributor Billed Quantity.";
		}
		if (used === available) {
			return "Available qty for this invoice is exhausted. Try again with a different invoice.";
		}
		if (used + billed > available) {
			return "Stock Code: " + sku + ". Available Qty: " + available
				+ ". Total Billed Quantity: " + (used + billed) + ". Kindly Modify Distributor Billed Quantity.";
		}
		return "";
	},

	_duplicateLineMessage: function (sku, invoice, distInvoice, distDate, excludeIndex) {
		var duplicate = (ShipAndDebitCreate._lines || []).some(function (line, index) {
			if (index === excludeIndex) return false;
			return String(line.sku || "").trim() === sku
				&& String(line.invoiceNumber || "").trim() === invoice
				&& String(line.distInvoiceNumber || "").trim() === distInvoice
				&& String(line.distInvoiceDate || "").replace(/\D/g, "") === distDate;
		});
		return duplicate
			? "Duplicate combination of Stock Code, 3M Invoice Number, 3M Invoice Date, Distributor Invoice number, Distributor Invoice Date Not Allowed."
			: "";
	},

	EditLine: function (index) {
		if (ShipAndDebitCreate._savingEdit) return false;
		var line = (ShipAndDebitCreate._lines || [])[index];
		if (!line) return false;
		var $product = ShipAndDebit._$("#sd_product");
		var $invoice = ShipAndDebit._$("#sd_invoice");
		if (ShipAndDebitCreate._editIndex < 0) {
			ShipAndDebitCreate._editProductOptionsHtml = $product.html();
		}
		ShipAndDebitCreate._editIndex = index;
		$product.empty().append($("<option>").val(line.sku).text(line.description || line.sku))
			.val(line.sku).prop("disabled", true);
		ShipAndDebit._$("#sd_sku").val(line.sku);
		$invoice.empty().append($("<option>").val(line.invoiceNumber)
			.attr("data-ymd", line.invoiceDate).text(line.invoiceNumber))
			.val(line.invoiceNumber).prop("disabled", true);
		ShipAndDebit._$("#sd_invoice_date").val(ShipAndDebitCreate._showDate(line.invoiceDate))
			.attr("data-ymd", line.invoiceDate);
		ShipAndDebit._$("#sd_dist_invoice").val(line.distInvoiceNumber);
		ShipAndDebit._$("#sd_dist_date").val(ShipAndDebitCreate._showDate(line.distInvoiceDate));
		ShipAndDebitCreate._dates();
		var $date = ShipAndDebit._$("#sd_dist_date");
		if ($date.data("datepicker")) {
			var invoiceDate = String(line.invoiceDate || "");
			var startDate = /^\d{8}$/.test(invoiceDate)
				? new Date(Number(invoiceDate.substr(0, 4)), Number(invoiceDate.substr(4, 2)) - 1, Number(invoiceDate.substr(6, 2)))
				: false;
			ShipAndDebitCreate._settingDistDate = true;
			$date.datepicker("setStartDate", startDate).datepicker("update", $date.val());
			ShipAndDebitCreate._settingDistDate = false;
		}
		ShipAndDebit._$("#sd_avail_qty").val(line.availQty);
		ShipAndDebit._$("#sd_dist_qty").val(line.distBillQty);
		ShipAndDebit._$("#sd_uom").val(line.uom);
		ShipAndDebit._$("#sd_sales").val(line.salesPerson);
		ShipAndDebit._$("#sd_rc_price").val(line.rcPrice);
		ShipAndDebit._$("#sd_inv_price").val(line.distBillPrice);
		ShipAndDebit._$("#sd_tax").val(line.tax);
		ShipAndDebit._$("#sd_cgst").val(line.cgst);
		ShipAndDebit._$("#sd_igst").val(line.igst);
		ShipAndDebit._$("#sd_freight").val(line.freight);
		ShipAndDebit._$("#sd_discount").val(line.discount);
		ShipAndDebitCreate._invoiceTaxType = line.taxType || "";
		ShipAndDebitCreate._extraTaxPercent = ShipAndDebitCreate._number(line.extraTaxPercent);
		ShipAndDebit._$("#sd_claim_value").val(line.claimValue || "0.00");
		ShipAndDebit._$("#sd_add_line").html("<i class='ri-save-line' aria-hidden='true'></i> Save");
		ShipAndDebit._$("#sd_dist_qty").trigger("input");
		ShipAndDebit.HideMsg();
		return false;
	},

	SaveEdited: function () {
		if (ShipAndDebitCreate._savingEdit) return false;
		var index = ShipAndDebitCreate._editIndex;
		var line = (ShipAndDebitCreate._lines || [])[index];
		if (!line) return false;
		var gap = ShipAndDebitCreate._lineGap();
		if (gap) {
			Common.showPageMsg(ShipAndDebit.ROOT, gap, "warning");
			return false;
		}
		var sku = String(ShipAndDebit._$("#sd_sku").val() || "").trim();
		var invoice = String(ShipAndDebit._$("#sd_invoice").val() || "").trim();
		var invoiceDate = String(ShipAndDebit._$("#sd_invoice_date").attr("data-ymd") || "").replace(/\D/g, "");
		var distInvoice = $.trim(ShipAndDebit._$("#sd_dist_invoice").val() || "");
		var distDate = ShipAndDebit._ymd("sd_dist_date");
		var qtyText = $.trim(ShipAndDebit._$("#sd_dist_qty").val() || "");
		var qty = Number(qtyText);
		if (!/^\d+(?:\.\d{1,2})?$/.test(qtyText) || !isFinite(qty) || qty <= 0) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Enter a valid quantity with no more than 2 decimal places.", "warning");
			return false;
		}
		if (!/^\d{8}$/.test(invoiceDate) || !/^\d{8}$/.test(distDate)
			|| distDate < invoiceDate || distDate > ShipAndDebitCreate._today()) {
			Common.showPageMsg(ShipAndDebit.ROOT,
				"Distributor invoice date must be on or after the 3M invoice date and cannot be later than today.", "warning");
			return false;
		}
		var availableMessage = ShipAndDebitCreate._availMessage(sku, invoice, qtyText, index);
		if (availableMessage) {
			Common.showPageMsg(ShipAndDebit.ROOT, availableMessage, "warning");
			return false;
		}
		var duplicate = ShipAndDebitCreate._duplicateLineMessage(sku, invoice, distInvoice, distDate, index);
		if (duplicate) {
			Common.showPageMsg(ShipAndDebit.ROOT, duplicate, "warning");
			return false;
		}
		ShipAndDebitCreate._savingEdit = true;
		ShipAndDebit._$("#sd_add_line,#sd_dist_invoice,#sd_dist_date,#sd_dist_qty").prop("disabled", true);
		ShipAndDebitCreate.CheckLine(function (validated) {
			ShipAndDebitCreate._savingEdit = false;
			ShipAndDebit._$("#sd_add_line").prop("disabled", false);
			ShipAndDebit._$("#sd_dist_invoice,#sd_dist_date,#sd_dist_qty").prop("disabled", false);
			if (!validated || ShipAndDebitCreate._editIndex !== index) return;
			line.distInvoiceNumber = distInvoice;
			line.distInvoiceDate = distDate;
			line.distBillQty = qtyText;
			line.uom = ShipAndDebit._$("#sd_uom").val() || line.uom;
			line.availQty = ShipAndDebit._$("#sd_avail_qty").val() || line.availQty;
			line.salesPerson = ShipAndDebit._$("#sd_sales").val() || line.salesPerson;
			line.rcPrice = ShipAndDebit._$("#sd_rc_price").val() || line.rcPrice;
			line.distBillPrice = ShipAndDebit._$("#sd_inv_price").val() || line.distBillPrice;
			line.claimValue = ShipAndDebit._$("#sd_claim_value").val() || "0.00";
			line.tax = ShipAndDebit._$("#sd_tax").val() || "";
			line.taxType = ShipAndDebitCreate._invoiceTaxType || "";
			line.extraTaxPercent = ShipAndDebitCreate._extraTaxPercent;
			line.cgst = ShipAndDebit._$("#sd_cgst").val() || "";
			line.igst = ShipAndDebit._$("#sd_igst").val() || "";
			line.freight = ShipAndDebit._$("#sd_freight").val() || "";
			line.discount = ShipAndDebit._$("#sd_discount").val() || "";
			ShipAndDebitCreate._paint();
			ShipAndDebitCreate._resetLineEntry();
			Common.showPageMsg(ShipAndDebit.ROOT, "SKU details updated.", "success");
		});
		return false;
	},

	_resetLineEntry: function () {
		var $product = ShipAndDebit._$("#sd_product");
		var $invoice = ShipAndDebit._$("#sd_invoice");
		if (ShipAndDebitCreate._editProductOptionsHtml) {
			$product.html(ShipAndDebitCreate._editProductOptionsHtml);
		}
		$product.prop("disabled", false).prop("selectedIndex", 0);
		$invoice.empty().append("<option value=''>Choose your option</option>").prop("disabled", false);
		ShipAndDebit._$("#sd_sku,#sd_invoice_date,#sd_dist_invoice,#sd_dist_date,#sd_avail_qty,#sd_dist_qty,#sd_uom,#sd_sales,#sd_rc_price,#sd_inv_price,#sd_tax,#sd_cgst,#sd_igst,#sd_freight,#sd_discount").val("");
		if (ShipAndDebit._$("#sd_dist_date").data("datepicker")) {
			ShipAndDebit._$("#sd_dist_date").datepicker("setStartDate", false).datepicker("clearDates");
		}
		ShipAndDebit._$("#sd_invoice_date").attr("data-ymd", "");
		ShipAndDebitCreate._editIndex = -1;
		ShipAndDebitCreate._editProductOptionsHtml = "";
		ShipAndDebitCreate._invoiceTaxType = "";
		ShipAndDebitCreate._extraTaxPercent = 0;
		ShipAndDebitCreate._calculateClaimValue();
		ShipAndDebit._$("#sd_add_line").html("<i class='ri-add-line' aria-hidden='true'></i> Add").prop("disabled", false);
	},

	RemoveLine: function (index) {
		if (ShipAndDebitCreate._savingEdit) return false;
		var remove = function () {
			if (ShipAndDebitCreate._editIndex === index) {
				ShipAndDebitCreate._resetLineEntry();
			} else if (ShipAndDebitCreate._editIndex > index) {
				ShipAndDebitCreate._editIndex--;
			}
			ShipAndDebitCreate._lines.splice(index, 1);
			ShipAndDebitCreate._paint();
		};
		if (window.Swal && typeof Swal.fire === "function") {
			Swal.fire({
				title: "Delete this line?",
				text: "The line is removed from the list when you click OK.",
				icon: "warning",
				showCancelButton: true,
				confirmButtonText: "OK",
				cancelButtonText: "Cancel",
				confirmButtonColor: "#d33",
				cancelButtonColor: "#94a3b8",
				reverseButtons: true,
				focusCancel: true
			}).then(function (result) {
				if (result && result.isConfirmed) remove();
			});
			if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
		} else if (window.confirm("Delete this line?")) {
			remove();
		}
		return false;
	},

	_paint: function () {
		var rows = ShipAndDebitCreate._lines;
		var total = 0;
		var html = "";
		rows.forEach(function (line, index) {
			total += Number(line.claimValue) || 0;
			html += "<tr>"
				+ ShipAndDebitCreate._td(line.description)
				+ ShipAndDebitCreate._td(line.sku)
				+ ShipAndDebitCreate._td(line.invoiceNumber)
				+ ShipAndDebitCreate._td(line.invoiceDate)
				+ ShipAndDebitCreate._td(line.distInvoiceNumber)
				+ ShipAndDebitCreate._td(line.distInvoiceDate)
				+ ShipAndDebitCreate._td(line.uom)
				+ ShipAndDebitCreate._td(line.availQty)
				+ ShipAndDebitCreate._td(line.salesPerson)
				+ ShipAndDebitCreate._td(line.rcPrice)
				+ ShipAndDebitCreate._td(line.distBillQty)
				+ ShipAndDebitCreate._td(line.distBillPrice)
				+ ShipAndDebitCreate._td(line.tax)
				+ ShipAndDebitCreate._td(line.cgst)
				+ ShipAndDebitCreate._td(line.igst)
				+ ShipAndDebitCreate._td(line.freight)
				+ ShipAndDebitCreate._td(line.discount)
				+ ShipAndDebitCreate._td(line.claimValue)
				+ "<td class='text-nowrap'><button type='button' class='btn btn-link btn-sm p-0 me-2' onclick='return ShipAndDebitCreate.EditLine(" + index + ");'><i class='ri-edit-line' aria-hidden='true'></i> Edit</button>"
				+ "<button type='button' class='btn btn-link btn-sm p-0 text-danger' onclick='return ShipAndDebitCreate.RemoveLine(" + index + ");'><i class='ri-delete-bin-line' aria-hidden='true'></i> Delete</button></td>"
				+ "</tr>";
		});
		ShipAndDebit._$("#sd_lines_body").html(html);
		ShipAndDebit._$("#sd_lines_wrap").toggleClass("d-none", !rows.length);
		ShipAndDebit._$("#sd_total").val(total.toFixed(2));
	},

	_td: function (value) {
		return "<td>" + ShipAndDebit._esc(value) + "</td>";
	},

	Save: function (confirmed) {
		if (!ShipAndDebit._validateClaimComment("#sd_comments")) return false;
		if (ShipAndDebitCreate._lateStatus !== "ready") {
			if (ShipAndDebitCreate._lateStatus !== "loading") ShipAndDebitCreate._loadLateFlag();
			Common.showPageMsg(ShipAndDebit.ROOT, "Late submission status is not ready. Please wait for the check to finish, then submit again.", "warning");
			return false;
		}
		if (!ShipAndDebitCreate._lines.length) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Add at least one stock line before submit.", "warning");
			return false;
		}
		var total = Number(ShipAndDebit._$("#sd_total").val() || 0);
		if (!total) {
			Common.showPageMsg(ShipAndDebit.ROOT, "Total Claim Value is 0, Cannot Submit Claim", "warning");
			return false;
		}
		var lateRemarks = $.trim(ShipAndDebit._$("#sd_late").val() || "");
		if (ShipAndDebitCreate._late === "Y" && !lateRemarks) {
			ShipAndDebit._$("#sd_late_wrap").removeClass("d-none");
			Common.showPageMsg(ShipAndDebit.ROOT, "Please share the reason for late submission", "warning");
			return false;
		}
		if (!confirmed) {
			if (ShipAndDebitCreate._confirmingSubmit) return false;
			ShipAndDebitCreate._confirmingSubmit = true;
			var confirmationText = "This is a debit note claim.\nClaim value: Rs. " + total.toFixed(2)
				+ "\nAre you sure to submit the claim?";
			var confirmationHtml = "This is a debit note claim.<br>Claim value: "
				+ "<strong class='sd-claim-confirm-amount'>Rs. " + total.toFixed(2) + "</strong>"
				+ "<br>Are you sure to submit the claim?";
			if (window.Swal && typeof Swal.fire === "function") {
				Swal.fire({
					title: "Confirm claim submission",
					html: confirmationHtml,
					icon: "warning",
					showCancelButton: true,
					confirmButtonText: "OK",
					cancelButtonText: "Cancel",
					confirmButtonColor: "#3085d6",
					cancelButtonColor: "#6c757d",
					reverseButtons: true
				}).then(function (result) {
					ShipAndDebitCreate._confirmingSubmit = false;
					if (result && result.isConfirmed) ShipAndDebitCreate.Save(true);
				}, function () {
					ShipAndDebitCreate._confirmingSubmit = false;
				});
				if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
			} else {
				ShipAndDebitCreate._confirmingSubmit = false;
				if (window.confirm(confirmationText)) ShipAndDebitCreate.Save(true);
			}
			return false;
		}
		var body = ShipAndDebit._context();
		body.endCustomer = ShipAndDebit._$("#sd_end_customer").val() || "";
		body.division = ShipAndDebit._$("#sd_division").val() || "";
		body.claimMonth = ShipAndDebitCreate._month();
		body.comments = ShipAndDebit._$("#sd_comments").val() || "";
		body.lateRemarks = lateRemarks;
		body.lines = ShipAndDebitCreate._lines.map(function (line) {
			return {
				sku: line.sku,
				description: line.description,
				invoiceNumber: line.invoiceNumber,
				invoiceDate: line.invoiceDate,
				uom: line.uom,
				availQty: line.availQty,
				salesPerson: line.salesPerson,
				rcPrice: line.rcPrice,
				distInvoiceNumber: line.distInvoiceNumber,
				distInvoiceDate: line.distInvoiceDate,
				distBillQty: line.distBillQty,
				distBillPrice: line.distBillPrice,
				claimValue: line.claimValue,
				lineComments: line.lineComments
			};
		});
		var submit = function (data) {
			ShipAndDebitCreate._claimNumber = (data && data.claimNumber) || "";
			if (!ShipAndDebitCreate._claimNumber) {
				ShipAndDebit._$("#sd_submit_claim").prop("disabled", false);
				Common.showPageMsg(ShipAndDebit.ROOT, "The claim was saved, but the server did not return its claim number.", "danger");
				return;
			}
			var msg = (data && data.message) || "Claim saved.";
			if (data && data.posDealerExists === "No") {
				msg += " Register with the 3M POS program to shorten the claim cycle. Write to 3mindiapossupport@mmm.com.";
			}
			ShipAndDebit._$("#sd_submit_claim").prop("disabled", true);
			ShipAndDebit._$("#sd_doc_progress_title").text("Your claim was created successfully");
			ShipAndDebit._startDocumentProgress(ShipAndDebitCreate._claimNumber, "created",
				ShipAndDebitCreate._documents, function (uploaded) {
					if (uploaded) {
						ShipAndDebitCreate._clearDocuments();
						ShipAndDebit._$("#sd_retry_docs").addClass("d-none");
						ShipAndDebit._$("#sd_saved_claim").text(msg);
						Common.showPageMsg(ShipAndDebit.ROOT, msg, "success");
					} else {
						ShipAndDebit._$("#sd_retry_docs").removeClass("d-none");
						ShipAndDebit._$("#sd_saved_claim").text(msg + " Some documents still need to be uploaded.");
						Common.showPageMsg(ShipAndDebit.ROOT,
							"Claim " + ShipAndDebitCreate._claimNumber + " was saved, but some documents could not be uploaded. Retry the failed uploads.", "warning");
					}
				});
		};
		ShipAndDebit._$("#sd_submit_claim").prop("disabled", true);
		ShipAndDebit._post("/claims", JSON.stringify(body), submit, function (message) {
			ShipAndDebit._$("#sd_submit_claim").prop("disabled", false);
			ShipAndDebit.HideMsg();
			ShipAndDebit._showRequestError("Claim could not be saved", message);
		});
		return false;
	}
};
