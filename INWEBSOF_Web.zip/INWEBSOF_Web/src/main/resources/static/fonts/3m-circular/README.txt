Place official 3M Circular Web Fonts from Brand Central here (Book/Bold/Medium .woff or .woff2).
Download: Brand Central → Extra Components → 3M Circular Web Fonts (.woff)
