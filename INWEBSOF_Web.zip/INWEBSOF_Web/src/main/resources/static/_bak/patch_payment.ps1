
$ErrorActionPreference = "Stop"
$js = "C:\Users\DELL\eclipse-workspace\INPCV2\src\main\resources\static\custom_js\customer_payment.js"
$html = "C:\Users\DELL\eclipse-workspace\INPCV2\src\main\resources\static\html_files\INPC\customer_payment.html"
$bak = "C:\Users\DELL\eclipse-workspace\INPCV2\src\main\resources\static\_bak"
New-Item -ItemType Directory -Force -Path $bak | Out-Null
Copy-Item $js (Join-Path $bak ("customer_payment-" + (Get-Date -Format "yyyyMMddHHmmss") + ".js")) -Force
Copy-Item $html (Join-Path $bak ("customer_payment-" + (Get-Date -Format "yyyyMMddHHmmss") + ".html")) -Force

$utf8 = New-Object System.Text.UTF8Encoding $false
$t = [IO.File]::ReadAllText($js, $utf8)

# Fix root selector
$oldRoot = 'var $root = $("#m_customer_payment");'
$newRoot = "var rootId = CustomerPayment.LOADER_TARGET || `"m_customer_payment`";`r`n`t`tvar `$root = `$(`"#`" + rootId);"
if ($t.Contains($oldRoot)) { $t = $t.Replace($oldRoot, $newRoot); "ROOT_OK" } else { "ROOT_MISS" }

# Fix rupee: replace common mojibake sequences with INR prefix if needed
$rupee = [char]0x20B9
if ($t -match 'toLocaleString') {
  # replace broken prefix before toLocaleString concatenation
  $t = [regex]::Replace($t, 'return\s+"[^"]*"\s*\+\s*num\.toLocaleString', ('return "' + $rupee + '" + num.toLocaleString'))
  $t = [regex]::Replace($t, 'return\s+"[^"]*"\s*\+\s*num\.toFixed', ('return "' + $rupee + '" + num.toFixed'))
  "RUPEE_OK"
}

[IO.File]::WriteAllText($js, $t, $utf8)

$h = [IO.File]::ReadAllText($html, $utf8)
$pairs = @(
  @('#00B0F0', '#4f46e5'),
  @('#0090c8', '#4338ca'),
  @('#0077a8', '#3730a3'),
  @('#0099d6', '#4f46e5'),
  @('#7dd3f0', '#a5b4fc'),
  @('rgba(0,176,240,', 'rgba(79,70,229,'),
  @('#0369a1', '#3730a3'),
  @('#0c4a6e', '#312e81'),
  @('#f0f9ff', '#eef2ff'),
  @('#e0f4fc', '#e0e7ff'),
  @('#bae6fd', '#c7d2fe')
)
foreach ($p in $pairs) { $h = $h.Replace($p[0], $p[1]) }
[IO.File]::WriteAllText($html, $h, $utf8)
"THEME_OK"
# verify
if ($h.Contains('#4f46e5')) { "HAS_INDIGO" } else { "NO_INDIGO" }
if ($h.Contains('#00B0F0')) { "STILL_CYAN" } else { "CYAN_GONE" }
