/* This file is created by Framework System */

			var table_grid_ia_menu_options = jQuery('#table_grid_ia_menu_options').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_menu_options',
			datatype: 'json',
				colNames:['Menu Group','Menu Sub Group','Module Name','Display Name','File Name','Mobile File Name','Field Position','Generate Html','Generate Grid','Active','Sequence','Custom Links','View Type','Load Type','Grid Height'],
			colModel:[{name:'ref_menu_group_code',index:'ref_menu_group_code' ,  align:'left',  width:120.00}, 
{name:'ref_menu_subgroup_code',index:'ref_menu_subgroup_code' ,  align:'left',  width:152.00}, 
{name:'module_name',index:'module_name' ,  align:'left',  width:128.00}, 
{name:'display_name',index:'display_name' ,  align:'left',  width:136.00}, 
{name:'file_name',index:'file_name' ,  align:'left',  width:112.00}, 
{name:'mobile_file_name',index:'mobile_file_name' ,  align:'left',  width:168.00}, 
{name:'field_position',index:'field_position' ,  align:'left',  width:152.00}, 
{name:'generate_html',index:'generate_html' ,  align:'left',  width:144.00}, 
{name:'generate_grid',index:'generate_grid' ,  align:'left',  width:144.00}, 
{name:'active',index:'active' ,  align:'left',  width:100.00}, 
{name:'sequence',index:'sequence' ,  align:'left',  width:104.00}, 
{name:'custom_links',index:'custom_links' ,  align:'left',  width:136.00}, 
{name:'view_type',index:'view_type' ,  align:'left',  width:112.00}, 
{name:'load_type',index:'load_type' ,  align:'left',  width:112.00}, 
{name:'grid_height',index:'grid_height' ,  align:'left',  width:128.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_menu_options'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_menu_options');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_menu_options'
			}
			).navGrid('#sub_grid_div_ia_menu_options',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_menu_options',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_menu_options[0].toggleToolbar() } }) ;	


			 table_grid_ia_menu_options.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_menu_options);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_menu_options); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_menu_options[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
