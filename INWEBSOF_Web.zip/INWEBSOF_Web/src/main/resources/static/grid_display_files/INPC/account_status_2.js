/* This file is created by Framework System */

			var table_grid_account_status_2 = jQuery('#table_grid_account_status_2').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=account_status_2',
			datatype: 'json',
				colNames:['Document Name','Sequence','Mandatory','Active'],
			colModel:[{name:'document_name',index:'document_name' ,  align:'left',  width:85.00}, 
{name:'sequence',index:'sequence' ,  align:'left',  width:85.00}, 
{name:'mandatory',index:'mandatory' ,  align:'left',  width:85.00}, 
{name:'active',index:'active' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_account_status_2'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'account_status_2');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=account_status_2'
			}
			).navGrid('#sub_grid_div_account_status_2',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_account_status_2',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_account_status_2[0].toggleToolbar() } }) ;	


			 table_grid_account_status_2.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_account_status_2);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_account_status_2); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_account_status_2[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
