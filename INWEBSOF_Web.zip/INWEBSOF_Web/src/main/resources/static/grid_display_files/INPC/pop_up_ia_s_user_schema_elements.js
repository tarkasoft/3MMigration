
			var pg_ia_s_user_schema_elements = jQuery('#table_grid1').jqGrid(
			{
			url:$host_url+"display_grid/viewUserSchemaSrefDataDetails?pop_up_table_name="+pop_up_table_name+"&calling_table_name="+calling_table_name+"&clicked_id_system_name="+clicked_id_system_name,
			datatype: 'json',
				colNames:['User Schema Code','Name','System Name','Data Type','Sequence'],
			colModel:[{name:'ref_s_user_schema_code',index:'ref_s_user_schema_code' ,  align:'left',  width:85.00} , 
{name:'name',index:'name' ,  align:'left',  width:85.00} , 
{name:'system_name',index:'system_name' ,  align:'left',  width:85.00} , 
{name:'data_type',index:'data_type' ,  align:'left',  width:85.00} , 
{name:'sequence',index:'sequence' ,  align:'right',   width:85.00}],
			rowNum:50, 
	rowList:[50,100,200,500], 
	pager: jQuery('#sub_grid_div1'), 
	sortname: 'id', 
	height:'250',
		width:'600',
	viewrecords: true, 
	sortorder: 'desc', 
	multiselect: false, 
 
	cellsubmit: 'clientArray', 
	cellEdit: true,
	 forceFit : true, 
			 
		
	loadComplete:function() 
	{
		$('.ui-jqgrid-htable').css('border-collapse','separate');
	},
	ondblClickRow: function(rowid)
	{
	},
			}).navGrid('#sub_grid_div1',{edit:false,add:false,del:false,search:false},{},{},{},{multipleSearch:false})
			.navButtonAdd('#sub_grid_div1',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){ pg_ia_s_user_schema_elements[0].toggleToolbar() } }) ;	


			 pg_ia_s_user_schema_elements.filterToolbar(); 
			pg_ia_s_user_schema_elements[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid1').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );
	$('#ref_display_popup_title').html('Schema Elements');

			  
			