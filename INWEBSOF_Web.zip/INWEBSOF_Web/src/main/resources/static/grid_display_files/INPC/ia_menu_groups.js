/* This file is created by Framework System */

			var table_grid_ia_menu_groups = jQuery('#table_grid_ia_menu_groups').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_menu_groups',
			datatype: 'json',
				colNames:['App Type','Menu Name','direct_file_name','Menu Type','Active','Sequence'],
			colModel:[{name:'app_type',index:'app_type' ,  align:'left',  width:85.00}, 
{name:'menu_name',index:'menu_name' ,  align:'left',  width:85.00}, 
{name:'direct_file_name',index:'direct_file_name' ,  align:'left',  width:85.00}, 
{name:'menu_type',index:'menu_type' ,  align:'left',  width:85.00}, 
{name:'active',index:'active' ,  align:'left',  width:85.00}, 
{name:'sequence',index:'sequence' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_menu_groups'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_menu_groups');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_menu_groups'
			}
			).navGrid('#sub_grid_div_ia_menu_groups',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_menu_groups',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_menu_groups[0].toggleToolbar() } }) ;	


			 table_grid_ia_menu_groups.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_menu_groups);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_menu_groups); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_menu_groups[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
