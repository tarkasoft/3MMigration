var pg_sb_customer_master =  jQuery('#table_grid1').jqGrid 
({
	url:$host_url+"display_grid/viewUserSchemaSrefDataDetails?pop_up_table_name="+pop_up_table_name+"&calling_table_name="+calling_table_name+"&clicked_id_system_name="+clicked_id_system_name+"&all_data_obj="+all_data_obj,
	datatype: 'json', 
	colNames:['Code','Name','Address','GSTN Number','PAN Number','IA Number','State'],
	colModel:[{name:'code',index:'code' ,  align:'left',  width:85.00} , 
			{name:'name',index:'name' ,  align:'left',  width:85.00},
			{name:'registered_address',index:'registered_address' ,  align:'left',  width:85.00},
			{name:'gstn_number',index:'gstn_number' ,  align:'left',  width:85.00},
			{name:'pan_number',index:'pan_number' ,  align:'left',  width:85.00},
			{name:'ia_no',index:'ia_no' ,  align:'left',  width:85.00},
			{name:'state',index:'state' ,  align:'left',  width:85.00}],
	rowNum:50, 
	rowList:[50,100,200,500], 
	pager: jQuery('#sub_grid_div1'), 
	sortname: 'id', 
	height:'250',
		width:'600',
	viewrecords: true, 
	sortorder: 'desc', 
	multiselect: false, 
 
	cellsubmit: 'clientArray', 
	cellEdit: true,
	 forceFit : true, 
			 
		
	loadComplete:function() 
	{
		$('.ui-jqgrid-htable').css('border-collapse','separate');
	},
	ondblClickRow: function(rowid)
	{
	},
})
.navGrid('#sub_grid_div1',{edit:false,add:false,del:false,search:false},{},{},{},{multipleSearch:false})
.navButtonAdd('#sub_grid_div1',{caption:'Search', buttonicon :'ui-icon-search', onClickButton:function(){pg_sb_customer_master[0].toggleToolbar() } }) ; 

pg_sb_customer_master.filterToolbar(); 
pg_sb_customer_master[0].toggleToolbar();
$('.ui-search-toolbar').bind('keydown',function(evt)
{
	var kC  = (evt.which) ? evt.which : evt.keyCode;
	if(kC==40)
		jQuery('#table_grid1').editCell(1,1,false);
	if(kC==39) 
		$('#'+evt.target.id).focusNextInputField(); 
	if(kC==37) 
		$('#'+evt.target.id).focusPreviousInputField(); 
});
$('#ref_display_popup_title').html('Vendor Master');