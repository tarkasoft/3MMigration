/* This file is created by Framework System */

			var table_grid_welcome_msg_module = jQuery('#table_grid_welcome_msg_module').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=welcome_msg_module',
			datatype: 'json',
				colNames:['From Date','To Date','Active','User Type','title','ACK Required'],
			colModel:[{name:'from_date',index:'from_date' ,  align:'left',  width:85.00}, 
{name:'to_date',index:'to_date' ,  align:'left',  width:85.00}, 
{name:'active',index:'active' ,  align:'left',  width:85.00}, 
{name:'w_user_type',index:'w_user_type' ,  align:'left',  width:85.00}, 
{name:'title',index:'title' ,  align:'left',  width:85.00}, 
{name:'ack_required',index:'ack_required' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_welcome_msg_module'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'welcome_msg_module');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=welcome_msg_module'
			}
			).navGrid('#sub_grid_div_welcome_msg_module',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_welcome_msg_module',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_welcome_msg_module[0].toggleToolbar() } }) ;	


			 table_grid_welcome_msg_module.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_welcome_msg_module);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_welcome_msg_module); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_welcome_msg_module[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
