
			var table_grid_sb_approval_matrix = jQuery('#table_grid_sb_approval_matrix').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=sb_approval_matrix',
			datatype: 'json',
			colNames:['Approver From','Deviation','Approver Role','Approver','Sequence','UI Status'],
			colModel:[{name:'approver_from',index:'approver_from' ,  align:'left',  width:85.00} , 
						{name:'deviation',index:'deviation' ,  align:'left',  width:85.00},
						{name:'approver_role',index:'approver_role' ,  align:'left',  width:85.00},
						{name:'approver',index:'approver' ,  align:'left',  width:85.00},
						{name:'sequence',index:'sequence' ,  align:'left',  width:85.00},
						{name:'ui_status',index:'ui_status' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_sb_approval_matrix'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'sb_approval_matrix');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=sb_approval_matrix'
			}
			).navGrid('#sub_grid_div_sb_approval_matrix',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_sb_approval_matrix',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_sb_approval_matrix[0].toggleToolbar() } }) ;	


			 table_grid_sb_approval_matrix.filterToolbar();
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_sb_approval_matrix);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_sb_approval_matrix); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
 
			// table_grid_sb_approval_matrix[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
			