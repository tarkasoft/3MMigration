/* This file is created by Framework System */
var pg_ia_announcement =  jQuery('#table_grid1').jqGrid 
({
	url:$host_url+"display_grid/viewUserSchemaSrefDataDetails?pop_up_table_name="+pop_up_table_name+"&calling_table_name="+calling_table_name+"&clicked_id_system_name="+clicked_id_system_name,
	datatype: 'json', 
	colNames:[
	 'User Type',
	 'Title',
	 'Description',
	 'Sequence',
	 'From Date',
	 'To Date'],	
	colModel:[
	 {name:'a_user_type',index:'a_user_type', align:'left',  width:'85'},
	 {name:'title',index:'title', align:'left',  width:'85'},
	 {name:'description',index:'description', align:'left',  width:'85'},
	 {name:'sequence',index:'sequence', align:'left',  width:'85'},
	 {name:'from_date',index:'from_date', align:'left',  width:'85'},
	 {name:'to_date',index:'to_date', align:'left',  width:'85'}],	
		rowNum:50, 
	rowList:[50,100,200,500], 
	pager: jQuery('#sub_grid_div1'), 
	sortname: 'id', 
	height:'250',
		width:'600',
	viewrecords: true, 
	sortorder: 'desc', 
	multiselect: false, 
 
	cellsubmit: 'clientArray', 
	cellEdit: true,
	 forceFit : true, 
			 
		
	loadComplete:function() 
	{
		$('.ui-jqgrid-htable').css('border-collapse','separate');
	},
	ondblClickRow: function(rowid)
	{
	},
})
.navGrid('#sub_grid_div1',{edit:false,add:false,del:false,search:false},{},{},{},{multipleSearch:false})
.navButtonAdd('#sub_grid_div1',{caption:'Search', buttonicon :'ui-icon-search', onClickButton:function(){pg_ia_announcement[0].toggleToolbar() } }) ; 

pg_ia_announcement.filterToolbar(); 
// pg_ia_announcement[0].toggleToolbar();
$('.ui-search-toolbar').bind('keydown',function(evt)
{
	var kC  = (evt.which) ? evt.which : evt.keyCode;
	if(kC==40)
		jQuery('#table_grid1').editCell(1,1,false);
	if(kC==39) 
		$('#'+evt.target.id).focusNextInputField(); 
	if(kC==37) 
		$('#'+evt.target.id).focusPreviousInputField(); 
});
$('#ref_display_popup_title').html('Announcement');
