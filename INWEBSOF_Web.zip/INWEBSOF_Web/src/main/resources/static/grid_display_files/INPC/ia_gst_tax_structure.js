/* This file is created by Framework System */

			var table_grid_ia_gst_tax_structure = jQuery('#table_grid_ia_gst_tax_structure').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_gst_tax_structure',
			datatype: 'json',
				colNames:['CGST Rate','SGST Rate','IGST Rate','CESS Rate'],
			colModel:[{name:'cgst',index:'cgst' ,  align:'left',  width:85.00}, 
{name:'sgst',index:'sgst' ,  align:'left',  width:85.00}, 
{name:'igst',index:'igst' ,  align:'left',  width:85.00}, 
{name:'cess',index:'cess' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_gst_tax_structure'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_gst_tax_structure');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_gst_tax_structure'
			}
			).navGrid('#sub_grid_div_ia_gst_tax_structure',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_gst_tax_structure',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_gst_tax_structure[0].toggleToolbar() } }) ;	


			 table_grid_ia_gst_tax_structure.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_gst_tax_structure);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_gst_tax_structure); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_gst_tax_structure[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
