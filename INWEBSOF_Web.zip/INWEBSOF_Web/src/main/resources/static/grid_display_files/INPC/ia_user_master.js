/* This file is created by Framework System */

			var table_grid_ia_user_master = jQuery('#table_grid_ia_user_master').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_user_master',
			datatype: 'json',
				colNames:['ENL Id','User Type','Name','Customer Code','Email','Customer Name','Active'],
			colModel:[{name:'enl_id',index:'enl_id' ,  align:'left',  width:85.00}, 
{name:'u_user_type',index:'u_user_type' ,  align:'left',  width:85.00}, 
{name:'name',index:'name' ,  align:'left',  width:85.00}, 
{name:'cust_code',index:'cust_code' ,  align:'left',  width:85.00}, 
{name:'email',index:'email' ,  align:'left',  width:85.00}, 
{name:'cust_name',index:'cust_name' ,  align:'left',  width:85.00}, 
{name:'active',index:'active' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_user_master'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_user_master');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_user_master'
			}
			).navGrid('#sub_grid_div_ia_user_master',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_user_master',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_user_master[0].toggleToolbar() } }) ;	


			 table_grid_ia_user_master.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_user_master);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_user_master); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_user_master[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
