/* This file is created by Framework System */

			var table_grid_contact_us_data = jQuery('#table_grid_contact_us_data').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=contact_us_data',
			datatype: 'json',
				colNames:['Div No','Division','DivShortName','Customer Service Contact','Email','Mobile','Credit Services Contact','Email'],
			colModel:[{name:'div_no',index:'div_no' ,  align:'left',  width:85.00}, 
{name:'division',index:'division' ,  align:'left',  width:85.00}, 
{name:'div_short_name',index:'div_short_name' ,  align:'left',  width:85.00}, 
{name:'customer_service_contact',index:'customer_service_contact' ,  align:'left',  width:85.00}, 
{name:'email',index:'email' ,  align:'left',  width:85.00}, 
{name:'mobile',index:'mobile' ,  align:'left',  width:85.00}, 
{name:'credit_services_contact',index:'credit_services_contact' ,  align:'left',  width:85.00}, 
{name:'email1',index:'email1' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_contact_us_data'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'contact_us_data');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=contact_us_data'
			}
			).navGrid('#sub_grid_div_contact_us_data',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_contact_us_data',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_contact_us_data[0].toggleToolbar() } }) ;	


			 table_grid_contact_us_data.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_contact_us_data);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_contact_us_data); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_contact_us_data[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
