
			var table_grid_sb_sku_mapping = jQuery('#table_grid_sb_sku_mapping').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=sb_sku_mapping',
			datatype: 'json',
				colNames:['Customer SKU','Supply SKU','Apply SKU','SKU Desc','SKU UOM','Customer SKU Price'],
			colModel:[  {name:'customer_sku',index:'customer_sku',  align:'left',  width:85.00} , 
						{name:'supply_sku',index:'supply_sku',  align:'left',  width:85.00} , 
						{name:'apply_sku',index:'apply_sku',  align:'left',  width:85.00} , 
						{name:'sku_desc',index:'sku_desc' ,  align:'left',  width:85.00} , 
						{name:'uom',index:'uom' ,  align:'left',  width:85.00},
						{name:'customer_price',index:'customer_price' ,  align:'left',  width:85.00},
						],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_sb_sku_mapping'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'sb_sku_mapping');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=sb_sku_mapping'
			}
			).navGrid('#sub_grid_div_sb_sku_mapping',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_sb_sku_mapping',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_sb_sku_mapping[0].toggleToolbar() } }) ;	


			 table_grid_sb_sku_mapping.filterToolbar();
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_sb_sku_mapping);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_sb_sku_mapping); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
 
			// table_grid_sb_sku_mapping[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
			