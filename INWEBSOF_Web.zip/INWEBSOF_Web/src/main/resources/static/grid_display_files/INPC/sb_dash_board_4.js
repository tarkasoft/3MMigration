/* This file is created by Framework System */

			var table_grid_sb_dash_board_4 = jQuery('#table_grid_sb_dash_board_4').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=sb_dash_board_4',
			datatype: 'json',
				colNames:['Customer SKU','Supply SKU','Apply SKU','SKU description','UOM','Customer Price'],
			colModel:[{name:'customer_sku',index:'customer_sku' ,  align:'left',  width:85.00}, 
{name:'supply_sku',index:'supply_sku' ,  align:'left',  width:85.00}, 
{name:'apply_sku',index:'apply_sku' ,  align:'left',  width:85.00}, 
{name:'sku_desc',index:'sku_desc' ,  align:'left',  width:85.00}, 
{name:'uom',index:'uom' ,  align:'left',  width:85.00}, 
{name:'customer_price',index:'customer_price' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_sb_dash_board_4'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'sb_dash_board_4');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=sb_dash_board_4'
			}
			).navGrid('#sub_grid_div_sb_dash_board_4',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_sb_dash_board_4',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_sb_dash_board_4[0].toggleToolbar() } }) ;	


			 table_grid_sb_dash_board_4.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_sb_dash_board_4);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_sb_dash_board_4); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_sb_dash_board_4[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
