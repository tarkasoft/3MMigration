/* This file is created by Framework System */

			var table_grid_ia_s_user_schema_elements = jQuery('#table_grid_ia_s_user_schema_elements').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_s_user_schema_elements',
			datatype: 'json',
				colNames:['User Schema Code','Name','System Name','Data Type','Sequence','Ref User Schema Group Code','Ref Module Code'],
			colModel:[{name:'ref_s_user_schema_code',index:'ref_s_user_schema_code' ,  align:'left',  width:168.00}, 
{name:'name',index:'name' ,  align:'left',  width:100.00}, 
{name:'system_name',index:'system_name' ,  align:'left',  width:128.00}, 
{name:'data_type',index:'data_type' ,  align:'left',  width:112.00}, 
{name:'sequence',index:'sequence' ,  align:'left',  width:104.00}, 
{name:'ref_s_user_schema_group_code',index:'ref_s_user_schema_group_code' ,  align:'left',  width:248.00}, 
{name:'ref_module_code',index:'ref_module_code' ,  align:'left',  width:160.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_s_user_schema_elements'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_s_user_schema_elements');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_s_user_schema_elements'
			}
			).navGrid('#sub_grid_div_ia_s_user_schema_elements',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_s_user_schema_elements',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_s_user_schema_elements[0].toggleToolbar() } }) ;	


			 table_grid_ia_s_user_schema_elements.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_s_user_schema_elements);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_s_user_schema_elements); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_s_user_schema_elements[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
