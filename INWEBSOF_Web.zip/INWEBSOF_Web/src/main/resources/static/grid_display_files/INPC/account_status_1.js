/* This file is created by Framework System */

			var table_grid_account_status_1 = jQuery('#table_grid_account_status_1').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=account_status_1',
			datatype: 'json',
				colNames:['Vendor Code','Vendor Name','Address','State','Parser Status','Zone','Location','GST No','PAN No.','Contact Number','Parser File'],
			colModel:[{name:'vendor_code',index:'vendor_code' ,  align:'left',  width:85.00}, 
{name:'vendor_name',index:'vendor_name' ,  align:'left',  width:85.00}, 
{name:'address',index:'address' ,  align:'left',  width:85.00}, 
{name:'state',index:'state' ,  align:'left',  width:85.00}, 
{name:'parser_status',index:'parser_status' ,  align:'left',  width:85.00}, 
{name:'zone',index:'zone' ,  align:'left',  width:85.00}, 
{name:'location',index:'location' ,  align:'left',  width:85.00}, 
{name:'gstn_number',index:'gstn_number' ,  align:'left',  width:85.00}, 
{name:'pan_number',index:'pan_number' ,  align:'left',  width:85.00}, 
{name:'contact_number',index:'contact_number' ,  align:'left',  width:85.00}, 
{name:'parser_file',index:'parser_file' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_account_status_1'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'account_status_1');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=account_status_1'
			}
			).navGrid('#sub_grid_div_account_status_1',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_account_status_1',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_account_status_1[0].toggleToolbar() } }) ;	


			 table_grid_account_status_1.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_account_status_1);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_account_status_1); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_account_status_1[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
