/* This file is created by Framework System */

			var table_grid_ia_s_user_schema_group = jQuery('#table_grid_ia_s_user_schema_group').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_s_user_schema_group',
			datatype: 'json',
				colNames:['User Schema Code','Name','system Group Table Name','Group Id','Width','Field Type','Sequence'],
			colModel:[{name:'ref_s_user_schema_code',index:'ref_s_user_schema_code' ,  align:'left',  width:85.00}, 
{name:'name',index:'name' ,  align:'left',  width:85.00}, 
{name:'system_group_table_name',index:'system_group_table_name' ,  align:'left',  width:85.00}, 
{name:'group_id',index:'group_id' ,  align:'left',  width:85.00}, 
{name:'width',index:'width' ,  align:'left',  width:85.00}, 
{name:'field_type',index:'field_type' ,  align:'left',  width:85.00}, 
{name:'sequence',index:'sequence' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_s_user_schema_group'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_s_user_schema_group');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_s_user_schema_group'
			}
			).navGrid('#sub_grid_div_ia_s_user_schema_group',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_s_user_schema_group',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_s_user_schema_group[0].toggleToolbar() } }) ;	


			 table_grid_ia_s_user_schema_group.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_s_user_schema_group);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_s_user_schema_group); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_s_user_schema_group[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
