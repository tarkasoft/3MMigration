/* This file is created by Framework System */

			var table_grid_ia_customer_types = jQuery('#table_grid_ia_customer_types').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_customer_types',
			datatype: 'json',
				colNames:['Customer Type Code','Description 1','Description 2'],
			colModel:[{name:'customer_type_code',index:'customer_type_code' ,  align:'left',  width:85.00}, 
{name:'description1',index:'description1' ,  align:'left',  width:85.00}, 
{name:'description2',index:'description2' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_customer_types'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_customer_types');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_customer_types'
			}
			).navGrid('#sub_grid_div_ia_customer_types',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_customer_types',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_customer_types[0].toggleToolbar() } }) ;	


			 table_grid_ia_customer_types.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_customer_types);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_customer_types); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_customer_types[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
