/* This file is created by Framework System */

			var table_grid_3m_information = jQuery('#table_grid_3m_information').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=3m_information',
			datatype: 'json',
				colNames:['Customer','Code','Name','Registered Address','GSTN Number','PAN Number','IA No.','State'],
			colModel:[{name:'customer',index:'customer' ,  align:'left',  width:85.00}, 
{name:'code',index:'code' ,  align:'left',  width:85.00}, 
{name:'name',index:'name' ,  align:'left',  width:85.00}, 
{name:'registered_address',index:'registered_address' ,  align:'left',  width:85.00}, 
{name:'gstn_number',index:'gstn_number' ,  align:'left',  width:85.00}, 
{name:'pan_number',index:'pan_number' ,  align:'left',  width:85.00}, 
{name:'ia_no',index:'ia_no' ,  align:'left',  width:85.00}, 
{name:'state',index:'state' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_3m_information'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'3m_information');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=3m_information'
			}
			).navGrid('#sub_grid_div_3m_information',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_3m_information',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_3m_information[0].toggleToolbar() } }) ;	


			 table_grid_3m_information.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_3m_information);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_3m_information); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_3m_information[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
