
			var pg_ia_customer_types = jQuery('#table_grid1').jqGrid(
			{
			url:$host_url+"display_grid/viewUserSchemaSrefDataDetails?pop_up_table_name="+pop_up_table_name+"&calling_table_name="+calling_table_name+"&clicked_id_system_name="+clicked_id_system_name,
			datatype: 'json',
				colNames:['Customer Type Code','Description 1','Description 2'],
			colModel:[{name:'customer_type_code',index:'customer_type_code' ,  align:'left',  width:.00} , 
{name:'description1',index:'description1' ,  align:'left',  width:.00} , 
{name:'description2',index:'description2' ,  align:'left',  width:.00}],
				rowNum:50, 
	rowList:[50,100,200,500], 
	pager: jQuery('#sub_grid_div1'), 
	sortname: 'id', 
	height:'250',
		width:'600',
	viewrecords: true, 
	sortorder: 'desc', 
	multiselect: false, 
 
	cellsubmit: 'clientArray', 
	cellEdit: true,
	 forceFit : true, 
			 
		
	loadComplete:function() 
	{
		$('.ui-jqgrid-htable').css('border-collapse','separate');
	},
	ondblClickRow: function(rowid)
	{
	},
			}).navGrid('#sub_grid_div1',{edit:false,add:false,del:false,search:false},{},{},{},{multipleSearch:false})
			.navButtonAdd('#sub_grid_div1',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){ pg_ia_customer_types[0].toggleToolbar() } }) ;	


			 pg_ia_customer_types.filterToolbar(); 
			// pg_ia_customer_types[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid1').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );
	$('#ref_display_popup_title').html('Customer Type');

			  
			