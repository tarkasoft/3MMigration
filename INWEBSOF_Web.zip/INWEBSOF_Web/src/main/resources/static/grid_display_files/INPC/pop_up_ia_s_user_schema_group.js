
			var pg_ia_s_user_schema_group = jQuery('#table_grid1').jqGrid(
			{
			url:$host_url+"display_grid/viewUserSchemaSrefDataDetails?pop_up_table_name="+pop_up_table_name+"&calling_table_name="+calling_table_name+"&clicked_id_system_name="+clicked_id_system_name,
			datatype: 'json',
				colNames:['User Schema Code','Name','system Group Table Name','Group Id','Width','Field Type','Sequence'],
			colModel:[{name:'ref_s_user_schema_code',index:'ref_s_user_schema_code' ,  align:'left',  width:85.00} , 
{name:'name',index:'name' ,  align:'left',  width:85.00} , 
{name:'system_group_table_name',index:'system_group_table_name' ,  align:'left',  width:85.00} , 
{name:'group_id',index:'group_id' ,  align:'left',  width:85.00} , 
{name:'width',index:'width' ,  align:'left',  width:85.00} , 
{name:'field_type',index:'field_type' ,  align:'left',  width:85.00} , 
{name:'sequence',index:'sequence' ,  align:'right',   width:85.00}],
				rowNum:50, 
	rowList:[50,100,200,500], 
	pager: jQuery('#sub_grid_div1'), 
	sortname: 'id', 
	height:'250',
		width:'600',
	viewrecords: true, 
	sortorder: 'desc', 
	multiselect: false, 
 
	cellsubmit: 'clientArray', 
	cellEdit: true,
	 forceFit : true, 
			 
		
	loadComplete:function() 
	{
		$('.ui-jqgrid-htable').css('border-collapse','separate');
	},
	ondblClickRow: function(rowid)
	{
	},
		 
			
			}).navGrid('#sub_grid_div1',{edit:false,add:false,del:false,search:false},{},{},{},{multipleSearch:false})
			.navButtonAdd('#sub_grid_div1',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){ pg_ia_s_user_schema_group[0].toggleToolbar() } }) ;	


			 pg_ia_s_user_schema_group.filterToolbar(); 
			pg_ia_s_user_schema_group[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid1').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );
	$('#ref_display_popup_title').html('Schema Group');

			  
			