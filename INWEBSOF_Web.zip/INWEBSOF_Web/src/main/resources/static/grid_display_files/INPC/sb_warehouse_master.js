
			var table_grid_sb_warehouse_master = jQuery('#table_grid_sb_warehouse_master').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=sb_warehouse_master',
			datatype: 'json',
				colNames:['Code',' Name','Address'],
			colModel:[{name:'code',index:'code' ,  align:'left',  width:.00} , 
						{name:'name',index:'name' ,  align:'left',  width:.00} , 
						{name:'address',index:'address' ,  align:'left',  width:.00} ],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_sb_warehouse_master'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'sb_warehouse_master');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=sb_warehouse_master'
			}
			).navGrid('#sub_grid_div_sb_warehouse_master',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_sb_warehouse_master',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_sb_warehouse_master[0].toggleToolbar() } }) ;	


			 table_grid_sb_warehouse_master.filterToolbar();
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_sb_warehouse_master);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_sb_warehouse_master); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
 
			// table_grid_sb_warehouse_master[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
			