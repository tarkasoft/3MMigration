/* This file is created by Framework System */

			var table_grid_ia_announcement = jQuery('#table_grid_ia_announcement').jqGrid(
			{
			url:$host_url+'display_grid/viewUserSchemaModuleDetails?table_name=ia_announcement',
			datatype: 'json',
				colNames:['User Type','Title','Sequence','From Date','To Date','Description'],
			colModel:[{name:'a_user_type',index:'a_user_type' ,  align:'left',  width:85.00}, 
{name:'title',index:'title' ,  align:'left',  width:85.00}, 
{name:'sequence',index:'sequence' ,  align:'left',  width:85.00}, 
{name:'from_date',index:'from_date' ,  align:'left',  width:85.00}, 
{name:'to_date',index:'to_date' ,  align:'left',  width:85.00}, 
{name:'description',index:'description' ,  align:'left',  width:85.00}],
			rowNum:50,
			rowList:[50,100,200,500],
		 
			pager: jQuery('#sub_grid_div_ia_announcement'),
			sortname: 'id',
			height:'250',autowidth:true, 
			viewrecords: true,
			sortorder: 'desc',
			multiselect: false,
			autowidth: true,
			cellsubmit: 'clientArray',
			cellEdit: true,
			loadComplete:function() {
                $('.ui-jqgrid-htable').css('border-collapse','separate');
                if (window.Common && Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(jQuery(this)); }
                               },
			ondblClickRow: function(rowid)
				{
				all_obj.EditRecords(rowid,'ia_announcement');
				return;
				},
			shrinkToFit: true,
			editurl:$host_url+'display_grid/deleteUserSchemaModuleDetails.demo?table_name=ia_announcement'
			}
			).navGrid('#sub_grid_div_ia_announcement',{edit:false,add:false,del:true,search:false},{},{},{},{multipleSearch:true})
			.navButtonAdd('#sub_grid_div_ia_announcement',{caption:'Search',
			buttonicon :'ui-icon-pin-s', onClickButton:function(){table_grid_ia_announcement[0].toggleToolbar() } }) ;	


			 table_grid_ia_announcement.filterToolbar(); 
			if (window.Common && Common.EnableJqGridMobileHScroll) {
				Common.EnableJqGridMobileHScroll(table_grid_ia_announcement);
				if (Common.inpcElementsGridNoSqueeze) { Common.inpcElementsGridNoSqueeze(table_grid_ia_announcement); }
				if (Common.BindJqGridMobileHScroll) { Common.BindJqGridMobileHScroll(); }
			}
			// table_grid_ia_announcement[0].toggleToolbar();

			  
			   $('.ui-search-toolbar').bind('keydown',function(evt)
				{
					var kC  = (evt.which) ? evt.which : evt.keyCode;
					if(kC==40)
					jQuery('#table_grid').editCell(1,1,false);
					if(kC==39)
					 $('#'+evt.target.id).focusNextInputField();
					 if(kC==37)
					 $('#'+evt.target.id).focusPreviousInputField();
				} );


			  
