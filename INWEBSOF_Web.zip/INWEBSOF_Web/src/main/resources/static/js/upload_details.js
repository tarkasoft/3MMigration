//Uploading Details
var up_module_name="";

function BackFromUploadDownload()
{
	try {
		var name = up_module_name;
		if (!name || !all_obj || !all_obj[name]) {
			alert("Previous module not found");
			return;
		}
		var ao = all_obj[name];
		var module_id = ao["g_str_module_id"] || schema_id || 0;
		var module_name = ao["g_str_module_name"] || name;
		var display_name = name;
		try {
			if (ao["header_details"]) {
				display_name = ao["header_details"]["display_name"]
					|| ao["header_details"]["module_display_name"]
					|| ao["header_details"]["g_str_display_name"]
					|| module_name;
			} else {
				display_name = module_name;
			}
		} catch (eD) {
			display_name = module_name;
		}
		if (typeof window.getModulesDetailsNew === "function") {
			window.getModulesDetailsNew(name, module_name, module_id, "New", display_name, 0);
			return;
		}
		if (typeof window.LoadHtmlFiles === "function") {
			window.LoadHtmlFiles(name, module_name, display_name, module_id);
			return;
		}
		alert("Unable to return to module screen");
	} catch (e) {
		console.error(e);
		alert("Back error: " + (e && e.message ? e.message : e));
	}
}

function EnableDownlLoadUploadModules(system_module_name)
{
	try {
		if (!all_obj || !all_obj[system_module_name]) {
			alert("Module not loaded: " + system_module_name);
			return;
		}
		schema_id = all_obj[system_module_name]['g_str_module_id'];
		up_module_name = system_module_name;

		// Prefer the module's own panel / Include Tabs pane — never steal #home_dashboard when tabs are on.
		div_id = "#section-bar-" + schema_id;
		if ($(div_id).length === 0) {
			var $mod = $("#m_" + system_module_name);
			if ($mod.length && $mod.closest("[id^=section-bar-]").length) {
				div_id = "#" + $mod.closest("[id^=section-bar-]").attr("id");
			} else if ($mod.length) {
				var $tabPane = $mod.closest(".inpc-tab-pane");
				if ($tabPane.length && $tabPane.attr("id")) {
					div_id = "#" + $tabPane.attr("id");
				} else {
					div_id = "#m_" + system_module_name;
				}
			} else if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $ap = InpcTabs.$activePane();
				if ($ap && $ap.length && $ap.attr("id")) {
					div_id = "#" + $ap.attr("id");
				}
			}
			if ($(div_id).length === 0 && $("#home_dashboard").length && !(window.InpcTabs && InpcTabs.flagOn && InpcTabs.flagOn())) {
				// Classic single-panel mode only
				div_id = "#home_dashboard";
			} else if ($(div_id).length === 0 && $("#page_main_div").length) {
				div_id = "#page_main_div";
			}
		}
		if ($(div_id).length === 0) {
			alert("Download target panel not found");
			return;
		}

		var appType = (typeof $g_app_tye !== "undefined" && $g_app_tye) ? $g_app_tye : (window.$g_app_tye || "INPC");
		$path = "html_files/" + appType + "/upload_details.html?r=" + Math.random();
		$(div_id).load($path, function(response, status, xhr)
		{
			if (status === "error") {
				alert("Failed to load upload page: " + xhr.status + " " + xhr.statusText);
				return;
			}
			$(div_id + " #module_download_format").off("click").on("click", function() {
				get_header(schema_id, system_module_name);
			});
			$(div_id + " #module_upload_data").off("click").on("click", function() {
				uploadModuleDetailsIntoDB(schema_id, system_module_name);
			});
			$(div_id + " #module_download_data").off("click").on("click", function() {
				downloadModuleData(schema_id, system_module_name);
			});
			$(div_id + " #is_display_add_remove_row").off("click").on("click", function() {
				DisplayAddRemoveRow();
			});
			$(div_id + " #module_upload_back, " + div_id + " #module_upload_back_top").off("click").on("click", function(e) {
				e.preventDefault();
				BackFromUploadDownload();
			});

		});
	} catch (e) {
		console.error(e);
		alert("Download error: " + (e && e.message ? e.message : e));
	}
}

function DisplayAddRemoveRow()
{
	if(document.getElementById('is_display_add_remove_row').checked  == true)
	{
		$("#download_filters_fields").show();
	}
	else if(document.getElementById('is_display_add_remove_row').checked  == false)
	{
		$("#download_filters_fields").hide();
	}
	
	$op='';
	if( (all_obj[up_module_name]['g_user_schema_details_array']['data']['1'].length)>0)
	 {
  	    document.getElementById('download_field_id_1').options.length=0;		
		$op = new Option('Select One', '');
		//$op.id='0';
		document.getElementById('download_field_id_1').options.add($op);
		
		$.each(all_obj[up_module_name]['g_user_schema_details_array']['data']['1'], function(k,v)
		{
			$op = new Option(v['name'], v['system_name']);
			//$op.id=v['system_name'];//specifying the id  for options
			document.getElementById('download_field_id_1').options.add($op);
		});
	}
	
	// to delete the rows mannually
	var tbl = document.getElementById('download_details_table');
	var lastRow_full_length = tbl.rows.length;

	for($i=0;$i<lastRow_full_length;$i++)
	{
		var lastRow = tbl.rows.length;
		if (lastRow > 2) tbl.deleteRow(lastRow - 1);
	}	
	GetDownloadFilterDataDetails();  
 	
}

function addDownloadFiltersRow()
{
	var tbl = document.getElementById('download_details_table'); 
	var lastRow = tbl.rows.length; 
	var iteration = lastRow;
	var counter=iteration-1;

	// creates a new row
	var row = tbl.insertRow(lastRow);

	//Field
	var cellLeft = row.insertCell(0);
	cellLeft.id=iteration+"1";
	var sel = document.createElement('select');
	sel.id = 'download_field_id_' + iteration;
	sel.className  = 'form-control  input-sm';
	sel.setAttribute("onchange","createTextBoxBasedDataType('"+iteration+"')");  
	
	sel.options[0] = new Option('Select One', '');
	
	i=1;
	$.each(all_obj[up_module_name]['g_user_schema_details_array']['data']['1'], function(k,v)
	{   
		sel.options[i] = new Option(v['name'], v['system_name']); 
		i++;
	});  
	cellLeft.appendChild(sel);

	document.getElementById('download_field_id_' + iteration).style.width="85%"; 

	// Operator
	var cellRightSel = row.insertCell(1);
	cellRightSel.id=iteration+"2";
	var sel = document.createElement('select');
	sel.id = 'oper_' + iteration;
	sel.className  = 'form-control  input-sm';
	sel.options[0] = new Option('Select One' , ''); 
	sel.options[1] = new Option('=' , '='); 
	sel.options[2] = new Option('<=' , '<=');
	sel.options[3] = new Option('>=' , '>=');
	sel.options[4] = new Option('like' , 'like');
	 
	cellRightSel.appendChild(sel); 
	document.getElementById('oper_' + iteration).style.width="85%"; 
	

	// TExt Box  
	var cellRightSel = row.insertCell(2);
	cellRightSel.id=iteration+"3";
	var el = document.createElement('input');
	el.type='text';
	el.id='txtbox_'+ iteration;;
	el.className  = 'form-control  input-sm';
	cellRightSel.appendChild(el);  
	document.getElementById('txtbox_' + iteration).style.width="95%"; 

	var cellRightSel = row.insertCell(3);
	cellRightSel.id=iteration+"4";
	var sel = document.createElement('select');
	sel.id = 'and_or_' + iteration;
	sel.className  = 'form-control  input-sm';
	sel.options[0] = new Option('Select One', '');
	sel.options[1] = new Option('And', 'And');
	sel.options[2] = new Option('Or', 'Or');
	cellRightSel.appendChild(sel); 	
	document.getElementById('and_or_' + iteration).style.width="85%"; 
	return;   
}

function removeDownloadFiltersRow()
{
	// grab the element again!
	var tbl = document.getElementById('download_details_table');
	// grab the length!
	var lastRow = tbl.rows.length;
	// delete the last row if there is more than one row!
	if (lastRow > 2) tbl.deleteRow(lastRow - 1);
}

function createTextBoxBasedDataType(id)
{
	feild=$('#download_field_id_'+id).val();
	 
	data_type=all_obj[up_module_name]['g_system_names_full_arr'][feild]['Type'];
	
	if(data_type=='Number')
	{
		//$('#txtbox_'+id).attr("onkeypress", "return acceptNumbersOnlyForModule(event)") ;
		$('#'+id+'3').html("<input type='text' class='form-control  input-sm' id='txtbox_"+id+"' onkeypress='return acceptNumbersOnlyForModule(event)' style='width:95%;'>");
	}
	else if(data_type=='Month')
	{
		month_element="<div data-date-format='M' data-date-viewmode='years' class='input-icon right' style='width: 95%;'>";
		month_element+="<i class='fa fa-calendar-o' onclick=\"CallTarkaMonthPicker('txtbox_"+id+"')\" style='cursor:pointer; color:#333333;'></i>";
		month_element+="<input class='form-control input-sm' readonly id='txtbox_"+id+"' type='text'> </div>";
		$('#'+id+'3').html(month_element);
	}
	else if(data_type=='Date')
	{
		date_element="<div class='input-icon right' data-date-format='dd/mm/yyyy' data-date-viewmode='years' style='width: 95%;'>";
		date_element+="<i class='fa fa-calendar' onclick=\"CallTarkaDatePickerUpload('txtbox_"+id+"')\"  style='cursor:pointer; color:#333333;'></i>";
		date_element+="<input type='text' class='form-control date date-picker input-sm' placeholder='dd/mm/yyyy'   id='txtbox_"+id+"'> </div> ";
		$('#'+id+'3').html(date_element);
	}
	else if(data_type=='Reference Data')
	{
		$.each(all_obj[up_module_name]['g_user_schema_details_array']['data']['1'], function(k,v)
		{
			if(feild==v['system_name'])
			{
				ref_table_name=v['ref_module_table_name'];
				
				ref_element="<div class='input-icon right' style='width: 95%;'>";
				ref_element+="<input  class='form-control input-sm'   id='txtbox_"+id+"'   type='hidden'  value='0' />";
				ref_element+="<i style='width: 50px; margin-top: 1px; margin-bottom-1px; margin-right: 1px; height: 22px;' >";	
				ref_element+="<span class='fa fa-search' title='Search in SKU Master' onclick=\"POPUP.OpenFWPopup('"+ref_table_name+"','upload_download_filter' ,'txtbox_"+id+"');\"  style='background: #EEEEEE; color:#333333; height: 22px; margin: 0; width: 24px; float:right; padding:4px; cursor:pointer;'></span>";
				ref_element+="</i> <input class='form-control input-sm' on_exit='0' id='txt_ref_schema_txtbox_"+id+"' onblur=\"all_obj.ClearReferenceData('upload_download_filter','txtbox_"+id+"')\" type='text' style=' ' value=''>";
				ref_element+="</div>";
				$('#'+id+'3').html(ref_element);
				POPUP.AssignJqueryAutoCompleteNew(ref_table_name, 'upload_download_filter', 'txtbox_'+id);
			}
		});
	}
	else 
	{
		$('#'+id+'3').html("<input type='text' class='form-control  input-sm' id='txtbox_"+id+"' style='width:95%;'>");
	}
	 
	 
}

function CallTarkaDatePickerUpload(id)
{	 
		 
	$("#"+id).datepicker({ 
		autoclose: true,
		format: 'dd/mm/yyyy',
		dateFormat: 'dd/mm/yy',
		todayBtn: true
	}); 
	$("#"+id).datepicker('show');
		 
}

function GetDownloadFilterDataDetails()
{
	html="";
	
	html=" <table align='center'width='40%' border='0' cellspacing='1' cellpadding='1'>";
	html+="<tr><td>";

	html+="<table  align='center' width='46%' border='0' cellpadding='' cellspacing=''>";
	html+="<tr><td>Check All <input type='checkbox' checked id='is_filter_data_check_all' onclick='CheckAllFilterData()'/></td></tr>";
	html+="<tr>";
	html+="<td style='width:30px;'>";		
	html+="<div  style='overflow-y:scroll;overflow-y:auto;width:245px;height:227px;border:1px solid #cccccc;'>";
	$.each(all_obj[up_module_name]['g_user_schema_details_array']['data']['1'], function(k,v)
	{
		html+="<input type='checkbox' checked  id='"+v['system_name']+"' name='"+v['system_name']+"' /><label for='"+v['system_name']+"'>"+v['name']+"</label><br />";
	}); 
	html+="</div></td>";
	html+="</tr></table>";
	html+="</td> </tr></table>";	
	document.getElementById('download_filter_data_div').innerHTML=html;
	$("#download_filter_data_div").show();
}
 
function CheckAllFilterData()
{
    if(document.getElementById("is_filter_data_check_all").checked==true)
	{
		$.each(all_obj[up_module_name]['g_user_schema_details_array']['data']['1'], function(k,v)
		{
			$(':checkbox[id='+v['system_name']+']').prop('checked', true);
		});
	}
	else
	{
		$.each(all_obj[up_module_name]['g_user_schema_details_array']['data']['1'], function(k,v)
		{
			 $(':checkbox[id='+v['system_name']+']').prop('checked', false);
		});
	}
}
function get_header(schema_id,system_module_table_name)
{ 
	setTimeout(function(){ window.location.href=$host_url+"system/DownloadExcelFormatForUpload?schema_id="+schema_id+"&system_module_table_name="+system_module_table_name,500});
}

function downloadModuleData(schema_id,system_module_table_name)
{ 

	myJSONfiltersText="";
	var is_filter=0;
	var selected_db_fields_arr=Array();
	if($("#is_display_add_remove_row").length>0)
	{
		if(document.getElementById("is_display_add_remove_row").checked)
		{
			tbl = document.getElementById('download_details_table');
			var ctr=(tbl.rows.length)-1;
			var filter_cond="";
			$download_details= new Object();
			$k=0;
			for($i=1;$i<=ctr;$i++)
			{
				
				feild=$("#download_field_id_"+$i).val();
				val=$("#txtbox_"+$i).val(); 
				data_type=all_obj[up_module_name]['g_system_names_full_arr'][feild]['Type'];
		 
				if(data_type=='Month')
				{
					val= getYearMonthDBValue(val);
				}
				else if(data_type=='Date')
				{
					 val=date_format(val)
				}
				
				if(empty(feild)) 
					continue;
				
				$download_details[$k]= new Object();
				$download_details[$k]['db_filed']=feild;
				$download_details[$k]['oper']=$("#oper_"+$i).val();
				$download_details[$k]['val']=encodeURIComponent(val);
				$download_details[$k]['cond']=$("#and_or_"+$i).val();	
				$k++;		   
			}
		 
			$.each(all_obj[up_module_name]['g_user_schema_details_array']['data']['1'],function (ak,av)
			{
				id=av['system_name']; 
				system_name=id;
				if($(':checkbox[id='+id+']').is(':checked'))
					selected_db_fields_arr.push(system_name);
			});
			is_filter=1;
			var myJSONfiltersText = (JSON.stringify($download_details)); 
		}
	}
	setTimeout(function(){  window.location.href=$host_url+"system/DownloadExcelFormatFullData?schema_id="+schema_id+"&system_module_table_name="+system_module_table_name+"&filter_cond="+myJSONfiltersText+"&selected_db_fields_arr="+selected_db_fields_arr+"&is_filter="+is_filter,500});

   
}

function uploadModuleDetailsIntoDB(schema_id,system_module_name)
{ 
	  
		var ext=$("#module_details_uploaded_file").val().split(".").pop();
		module_details_uploaded_file=
		ext=ext.toLowerCase();
		if(ext!="xlsx")
		{
			alert(" Please select a .xlsx file");
			return false;
		}
		$('#update_result').html('');
		// var oMyForm = new FormData();
		// oMyForm.append("file", document.getElementById("module_details_uploaded_file").files[0]);
		// oMyForm.append("schema_id", schema_id);
		// oMyForm.append("system_module_table_name", system_module_name);
		 
	 
		document.getElementById('form_module_details_upload').action=$host_url+'system/UploadModuleDetailsIntoDB?schema_id='+schema_id+'&system_module_table_name='+system_module_name;
		document.getElementById('form_module_details_upload').submit();
		
		
		 // App.blockUI({boxed:true,message:"Please wait, Uploading"});
	 
		// $.ajax({
			// url: $host_url+'system/UploadModuleDetailsIntoDB',
			// data: oMyForm,
			// dataType: 'text',
			// processData: false,
			// contentType: false,
			// type: 'POST',
			 // error:AjaxErrorMessage,	
			// success: function(data){
				// App.unblockUI();
			// $('#result').html(data+ " uploaded by FormData!");
			  // $('#update_result').html(data);
			  
		// }
	  // });
}
  
