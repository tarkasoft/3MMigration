/**
 * INPC shared loader overlay (local Bootstrap spinner-border — no CDN / no loader.svg).
 *
 * Usage:
 *   showLoader();
 *   showLoader('Loading...');
 *   showLoader('Please wait', 'm_customer_payment');
 *   hideLoader(); / hideLoader('m_customer_payment');
 *
 * Overlay covers the target; the spinner card is portaled to document.body and
 * pinned at 50% of the viewport (top/left), so tall pages cannot pull it down.
 */
(function (window, document) {
  "use strict";

  var MAIN_SEL = ".main-content.app-content, .main-content, .app-content";
  var OVERLAY_CLASS = "inpc-loader-overlay";
  var PANEL_CLASS = "inpc-loader-inner";
  var DEFAULT_TEXT = "Please wait\u2026";

  function resolveTarget(divId) {
    if (divId) {
      var byId = document.getElementById(String(divId).replace(/^#/, ""));
      if (byId) return byId;
      try {
        var q = document.querySelector(String(divId));
        if (q) return q;
      } catch (e) { /* ignore invalid selector */ }
      return null;
    }
    return document.querySelector(MAIN_SEL) || document.body;
  }

  function overlayIdFor(divId) {
    if (!divId) return "inpc-loader-main";
    return "inpc-loader-" + String(divId).replace(/^#/, "").replace(/[^a-zA-Z0-9_-]/g, "_");
  }

  function panelIdFor(overlayId) {
    return overlayId + "-panel";
  }

  function ensureRelative(el) {
    if (el === document.body) return;
    var cs = window.getComputedStyle(el);
    if (cs.position === "static") {
      if (!el.getAttribute("data-inpc-loader-pos")) {
        el.setAttribute("data-inpc-loader-pos", "static");
      }
      el.style.position = "relative";
    }
  }

  function restorePosition(el) {
    if (!el || el === document.body) return;
    if (el.getAttribute("data-inpc-loader-pos") === "static") {
      el.style.position = "";
      el.removeAttribute("data-inpc-loader-pos");
    }
  }

  function buildOverlay(id) {
    var el = document.createElement("div");
    el.id = id;
    el.className = OVERLAY_CLASS;
    el.setAttribute("aria-hidden", "true");
    return el;
  }

  function buildPanel(id, text) {
    var el = document.createElement("div");
    el.id = id;
    el.className = PANEL_CLASS;
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");
    el.setAttribute("aria-busy", "true");
    el.innerHTML =
      '<div class="spinner-border text-danger inpc-loader-spinner" role="status" aria-hidden="true"></div>' +
      '<div class="inpc-loader-text"></div>';
    el.querySelector(".inpc-loader-text").textContent = text || DEFAULT_TEXT;
    return el;
  }

  function showLoader(text, divId) {
    var target = resolveTarget(divId);
    if (!target) return null;
    ensureRelative(target);
    var oid = overlayIdFor(divId);
    var pid = panelIdFor(oid);
    var msg = text == null || text === "" ? DEFAULT_TEXT : String(text);

    var existing = document.getElementById(oid);
    var panel = document.getElementById(pid);
    if (existing && panel) {
      var t = panel.querySelector(".inpc-loader-text");
      if (t) t.textContent = msg;
      existing.style.display = "block";
      panel.style.display = "flex";
      panel.setAttribute("aria-busy", "true");
      return existing;
    }

    // Clean partial state
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);

    var overlay = buildOverlay(oid);
    panel = buildPanel(pid, msg);
    target.appendChild(overlay);
    document.body.appendChild(panel);
    return overlay;
  }

  function hideLoader(divId) {
    var oid = overlayIdFor(divId);
    var pid = panelIdFor(oid);
    var existing = document.getElementById(oid);
    var panel = document.getElementById(pid);
    var parent = existing && existing.parentNode;
    if (existing && parent) parent.removeChild(existing);
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
    if (parent && parent.querySelectorAll && !parent.querySelector("." + OVERLAY_CLASS)) {
      restorePosition(parent);
    }
  }

  window.showLoader = showLoader;
  window.hideLoader = hideLoader;
  window.InpcLoader = {
    show: showLoader,
    hide: hideLoader,
  };
})(window, document);
