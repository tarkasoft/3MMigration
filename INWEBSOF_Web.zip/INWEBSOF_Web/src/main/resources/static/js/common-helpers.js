/**
 * Common helpers extracted from sunstar_dev MainPage.js / index.js
 * plus lightweight datepicker init for INPCV2 modules.
 */
var $host_url = $host_url || "";

function getCookie(c_name) {
  if (document.cookie.length > 0) {
    var c_start = document.cookie.indexOf(c_name + "=");
    if (c_start != -1) {
      c_start = c_start + c_name.length + 1;
      var c_end = document.cookie.indexOf(";", c_start);
      if (c_end == -1) c_end = document.cookie.length;
      return decodeURIComponent(document.cookie.substring(c_start, c_end));
    }
  }
  return "";
}

function setCookie(name, value, expiresDays, options) {
  if (!name) return;
  options = options || {};
  var cookieStr = name + "=" + encodeURIComponent(String(value));
  if (typeof expiresDays === "number" && expiresDays >= 0) {
    var d = new Date();
    d.setTime(d.getTime() + expiresDays * 24 * 60 * 60 * 1000);
    cookieStr += "; Expires=" + d.toUTCString();
  }
  cookieStr += "; Path=" + (options.path || "/");
  if (options.sameSite) cookieStr += "; SameSite=" + options.sameSite;
  if (options.secure) cookieStr += "; Secure";
  document.cookie = cookieStr;
}

function empty(mixed_var) {
  var key;
  if (
    mixed_var === "" ||
    mixed_var === 0 ||
    mixed_var === "null" ||
    mixed_var === "0" ||
    mixed_var === null ||
    mixed_var === false ||
    typeof mixed_var === "undefined"
  ) {
    return true;
  }
  if (typeof mixed_var == "object") {
    for (key in mixed_var) {
      return false;
    }
    return true;
  }
  return false;
}

function ShowAlertMsg(error) {
  if (window.Swal && typeof Swal.fire === "function") {
    Swal.fire({
      title: "Alert",
      html: error,
      icon: "warning",
      confirmButtonColor: "#DD6B55",
    });
    $(".swal2-container").css("z-index", "22222229999");
  } else {
    alert(String(error));
  }
}

function ShowSuccessMsg(msg) {
  if (window.Swal && typeof Swal.fire === "function") {
    Swal.fire({
      title: "Success",
      html: msg,
      icon: "success",
    });
    $(".swal2-container").css("z-index", "22222229999");
  } else {
    alert(String(msg));
  }
}

/** True when value is empty / placeholder date (00/00/0000) — treat as no date. */
function inpcIsEmptyDateValue(v) {
  v = String(v == null ? "" : v).trim();
  if (!v) return true;
  if (v === "00/00/0000" || v === "00-00-0000") return true;
  return /^0+[\/\-]0+[\/\-]0+$/.test(v);
}

/**
 * Bootstrap Datepicker defaults (Framework: dd/mm/yyyy).
 * Clears 00/00/0000 on show/focus so the calendar opens on today
 * (same as CallTarkaDatePickerNew icon click) instead of "November 0".
 */
function initDatePickers(root) {
  if (!window.jQuery || !$.fn.datepicker) return;
  var $root = root ? $(root) : $(document);
  $root.find(".datepicker, .date-picker, input[data-datepicker='true']").each(function () {
    var $el = $(this);
    var fmt = $el.attr("data-date-format") || $el.data("date-format") || "dd/mm/yyyy";
    if (String(fmt).indexOf("-") >= 0 && String(fmt).toLowerCase().indexOf("dd") === 0) {
      /* Prefer Framework slashes when attribute was dd-mm-yyyy */
      if (!$el.attr("data-date-format") || $el.attr("data-date-format") === "dd-mm-yyyy") {
        fmt = "dd/mm/yyyy";
      }
    }
    function clearPlaceholder() {
      if (inpcIsEmptyDateValue($el.val())) {
        $el.val("");
      }
    }
    if ($el.data("datepicker")) {
      /* Already bound — still attach clear-on-show once */
      if (!$el.data("inpcEmptyDateBound")) {
        $el.data("inpcEmptyDateBound", true);
        $el.on("show.inpcEmptyDate focus.inpcEmptyDate", function (event) {
          var dp = $el.data("datepicker");
          if (event.type === "focus" && dp && dp.picker && dp.picker.is(":visible")) return;
          clearPlaceholder();
          try {
            if (dp && inpcIsEmptyDateValue($el.val()) && (!dp.picker || !dp.picker.is(":visible"))) {
              dp.viewDate = new Date();
              if (typeof dp.fill === "function") dp.fill();
            }
          } catch (eFill) { /* ignore */ }
        });
      }
      return;
    }
    clearPlaceholder();
    $el.datepicker({
      autoclose: true,
      todayBtn: "linked",
      todayHighlight: true,
      forceParse: false,
      format: fmt,
      orientation: "bottom auto",
      defaultViewDate: new Date()
    });
    $el.data("inpcEmptyDateBound", true);
    $el.on("show.inpcEmptyDate focus.inpcEmptyDate", function (event) {
      var dp = $el.data("datepicker");
      if (event.type === "focus" && dp && dp.picker && dp.picker.is(":visible")) return;
      clearPlaceholder();
      try {
        if (dp && inpcIsEmptyDateValue($el.val()) && (!dp.picker || !dp.picker.is(":visible"))) {
          dp.viewDate = new Date();
          if (typeof dp.fill === "function") dp.fill();
          $el.datepicker("update");
        }
      } catch (eFill2) { /* ignore */ }
      $(".datepicker").css("z-index", 3000);
    });
  });
}

function initDateTimePickers(root) {
  if (!window.jQuery || !$.fn.datetimepicker) return;
  var $root = root ? $(root) : $(document);
  $root.find(".datetimepicker, input[data-datetimepicker='true']").each(function () {
    var $el = $(this);
    if ($el.data("datetimepicker")) return;
    $el.datetimepicker({
      autoclose: true,
      todayBtn: true,
      format: $el.data("date-format") || "dd-mm-yyyy hh:ii",
    });
  });
}

function initFlatpickrs(root) {
  if (!window.flatpickr) return;
  var scope = root || document;
  scope.querySelectorAll(".flatpickr, input[data-flatpickr='true']").forEach(function (el) {
    if (el._flatpickr) return;
    flatpickr(el, {
      dateFormat: el.getAttribute("data-date-format") || "d-m-Y",
      allowInput: true,
    });
  });
}

function initCommonWidgets(root) {
  initDatePickers(root);
  initDateTimePickers(root);
  initFlatpickrs(root);
}

$(function () {
  initCommonWidgets(document);
});