/**
 * INPC module tabs (optional).
 * Flag: window.INPC_INCLUDE_TABS = true|false  (also portal.extras.include-tabs).
 * Revert: set INPC_INCLUDE_TABS / include-tabs to false → single #home_dashboard (current behavior).
 * Mobile (width): always single page even when flag is true.
 * Max tabs including Home: 6.
 */
(function (window, $) {
  "use strict";

  var MAX_TABS = 6;
  var HOME_KEY = "home";

  function flagOn() {
    var v = window.INPC_INCLUDE_TABS;
    if (v === true || v === 1) return true;
    if (v == null) return false;
    var s = String(v).trim().toLowerCase();
    return s === "true" || s === "yes" || s === "1" || s === "y";
  }

  function tabIconsOn() {
    try {
      var v = window.INPC_TAB_ICONS;
      if (v === true || v === 1 || v === "1" || String(v).toLowerCase() === "true" || String(v).toLowerCase() === "yes") return true;
    } catch (e) { /* ignore */ }
    return false;
  }

  function resolveTabIcon(key, t) {
    t = t || {};
    if (key === HOME_KEY) {
      return { icon: "ri-home-4-line", color: t.iconColor || "#0b5fff" };
    }
    var icon = t.icon || "";
    var color = t.iconColor || "";
    try {
      var map = window.INPC_MENU_ICONS || {};
      var hit = map[key] || map[String(key).replace(/\.html$/i, "")];
      if (hit) {
        if (!icon) icon = hit.icon || "";
        if (!color) color = hit.color || "";
      }
    } catch (eR) { /* ignore */ }
    return { icon: icon || "ri-file-list-line", color: color || "" };
  }


  function normalizeTabStyle(v) {
    var n = parseInt(v, 10);
    if (!isFinite(n) || n < 1 || n > 6) n = 1;
    return String(n);
  }

  function currentTabStyle() {
    var v = window.INPC_TAB_STYLE;
    try {
      var ls = window.localStorage && localStorage.getItem("inpc_tab_style");
      if (ls != null && String(ls).trim() !== "") v = ls;
    } catch (eLs) { /* ignore */ }
    return normalizeTabStyle(v != null ? v : 1);
  }


  /** Show Module Tab Styles in Theme Switcher when Include Tabs is on (or INPC_TAB_STYLE is set). */
  function syncSwitcherTabStyles() {
    var $wrap = $("#inpc_switcher_tab_styles_wrap");
    if (!$wrap.length) return;
    var show = false;
    try {
      if (flagOn()) show = true;
      else if (window.INPC_TAB_STYLE != null && String(window.INPC_TAB_STYLE).trim() !== "") show = true;
    } catch (eS) { /* ignore */ }
    if (show) {
      $wrap.removeClass("d-none").attr("aria-hidden", "false");
      var cur = currentTabStyle();
      $wrap.find('input[name="inpc-tab-styles"]').prop("checked", false);
      var $r = $wrap.find("#inpc_tab_style_" + cur);
      if ($r.length) $r.prop("checked", true);
      else $wrap.find("#inpc_tab_style_1").prop("checked", true);
    } else {
      $wrap.addClass("d-none").attr("aria-hidden", "true");
    }
  }

  function bindSwitcherTabStyles() {
    if (window.__inpcSwitcherTabStylesBound) return;
    window.__inpcSwitcherTabStylesBound = true;
    $(document).on("change.inpcTabStyle", 'input[name="inpc-tab-styles"]', function () {
      var v = $(this).val();
      applyTabStyle(v);
      if (enabled()) renderBar();
    });
  }

  /** Apply visual theme only — does not change open/close/load behavior. */
  function applyTabStyle(style) {
    var s = normalizeTabStyle(style != null ? style : currentTabStyle());
    window.INPC_TAB_STYLE = s;
    try {
      if (window.localStorage) localStorage.setItem("inpc_tab_style", s);
    } catch (ePersist) { /* ignore */ }
    try {
      document.documentElement.setAttribute("data-inpc-tab-style", s);
      var bar = document.getElementById("inpc_module_tab_bar");
      if (bar) bar.setAttribute("data-inpc-tab-style", s);
      var host = document.getElementById("inpc_tab_host");
      if (host) host.setAttribute("data-inpc-tab-style", s);
      var pw = document.getElementById("page-wrapper");
      if (pw) pw.setAttribute("data-inpc-tab-style", s);
    } catch (eA) { /* ignore */ }
  }


  function isMobile() {
    try {
      if (typeof window.inpcIsMobileWidth === "function") return !!window.inpcIsMobileWidth();
      if (window.Common && typeof Common.IsMobile === "function") return !!Common.IsMobile();
    } catch (e) { /* ignore */ }
    var w = window.innerWidth || document.documentElement.clientWidth || 0;
    return w <= 767;
  }

  function enabled() {
    return flagOn() && !isMobile();
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/"/g, "&quot;");
  }

  var state = {
    /** @type {Record<string,{title:string,$pane:JQuery,closable:boolean}>} */
    tabs: {},
    order: [],
    active: HOME_KEY
  };

  function $host() {
    var $h = $("#inpc_tab_host");
    if ($h.length) return $h;
    var $pw = $("#page-wrapper");
    if (!$pw.length) $pw = $("body");
    if (!$("#home_dashboard").length) {
      $pw.append('<div id="home_dashboard"></div>');
    }
    var $hd = $("#home_dashboard");
    if (!$hd.parent().is("#inpc_tab_host")) {
      $hd.wrap('<div id="inpc_tab_host" class="inpc-tab-host"></div>');
    }
    return $("#inpc_tab_host");
  }

  function ensureChrome() {
    $host();
    if (!$("#inpc_module_tab_bar").length) {
      $("#inpc_tab_host").before(
        '<ul id="inpc_module_tab_bar" class="nav nav-tabs inpc-module-tabs mb-2" role="tablist" style="display:none"></ul>'
      );
    }
    var $hd = $("#home_dashboard");
    $hd.addClass("inpc-tab-pane").attr("data-tab-key", HOME_KEY);
    if (!state.tabs[HOME_KEY]) {
      state.tabs[HOME_KEY] = { title: "Home", $pane: $hd, closable: false };
      state.order = [HOME_KEY].concat(state.order.filter(function (k) { return k !== HOME_KEY; }));
    } else {
      state.tabs[HOME_KEY].$pane = $hd;
    }
  }

  function renderBar() {
    var $bar = $("#inpc_module_tab_bar");
    if (!$bar.length) return;
    if (!enabled()) {
      $bar.hide().empty();
      $(".inpc-tab-pane").not("#home_dashboard").remove();
      $("#home_dashboard").show().removeClass("d-none");
      state.tabs = {};
      state.order = [];
      state.active = HOME_KEY;
      ensureChrome();
      return;
    }
    applyTabStyle(currentTabStyle());
    $bar.show().empty();
    state.order.forEach(function (key) {
      var t = state.tabs[key];
      if (!t) return;
      var active = key === state.active ? " active" : "";
      var closeBtn = t.closable
        ? '<button type="button" class="inpc-tab-close" data-tab-key="' +
          esc(key) +
          '" aria-label="Close" title="Close"></button>'
        : "";
      var iconHtml = "";
      if (tabIconsOn()) {
        var ic = resolveTabIcon(key, t);
        var st = ic.color ? ' style="color:' + esc(ic.color) + '"' : "";
        iconHtml = '<i class="inpc-tab-mod-icon ' + esc(ic.icon) + '" aria-hidden="true"' + st + "></i>";
      } else if (key === HOME_KEY) {
        iconHtml = '<span class="inpc-tab-home-icon" aria-hidden="true"></span>';
      }
      $bar.append(
        '<li class="nav-item" role="presentation">' +
          '<button type="button" class="nav-link' +
          active +
          ' inpc-tab-link" data-tab-key="' +
          esc(key) +
          '" role="tab">' +
          iconHtml +
          '<span class="inpc-tab-label">' +
          esc(t.title || key) +
          "</span>" +
          closeBtn +
          "</button></li>"
      );
    });
  }

  function activate(key) {
    ensureChrome();
    if (!state.tabs[key]) key = HOME_KEY;
    state.active = key;
    Object.keys(state.tabs).forEach(function (k) {
      var t = state.tabs[k];
      if (!t || !t.$pane || !t.$pane.length) return;
      if (k === key) t.$pane.show().removeClass("d-none");
      else t.$pane.hide().addClass("d-none");
    });
    $("#content_title").text((state.tabs[key] && state.tabs[key].title) || key);
    renderBar();
    try {
      window.__inpcActiveTabKey = key;
      window.__inpcActiveContentId = key === HOME_KEY ? "home_dashboard" : paneId(key);
    } catch (e) { /* ignore */ }
  }

  function paneId(key) {
    return "inpc_tab_pane_" + String(key).replace(/[^a-zA-Z0-9_-]/g, "_");
  }

  function tabCount() {
    return state.order.filter(function (k) { return !!state.tabs[k]; }).length;
  }

  /**
   * Open or focus a tab, then run loader(into $pane).
   * opts: { key, title, reload?:boolean }
   * loader: function($pane, finish) — call finish() when load done (optional).
   * Returns false if blocked (max tabs).
   */
  function open(opts, loader) {
    opts = opts || {};
    var key = String(opts.key || HOME_KEY).trim() || HOME_KEY;
    var title = opts.title || key;
    var isHome = key === HOME_KEY || opts.isHome === true;

    // Single-page mode (flag off or mobile): classic #home_dashboard — no tab chrome
    if (!enabled()) {
      var $bar = $("#inpc_module_tab_bar");
      if ($bar.length) $bar.hide().empty();
      $(".inpc-tab-pane").not("#home_dashboard").remove();
      var $hd = $("#home_dashboard").show().removeClass("d-none");
      state.tabs = {};
      state.order = [];
      state.active = HOME_KEY;
      $("#content_title").text(title);
      if (typeof loader === "function") loader($hd, function () {});
      return true;
    }

    ensureChrome();

    if (state.tabs[key]) {
      state.tabs[key].title = title || state.tabs[key].title;
      if (opts.icon) state.tabs[key].icon = opts.icon;
      if (opts.iconColor) state.tabs[key].iconColor = opts.iconColor;
      /* refresh pane ref in case DOM was wrapped */
      if (key === HOME_KEY) {
        state.tabs[key].$pane = $("#home_dashboard");
      } else {
        var $existing = $("#" + paneId(key));
        if ($existing.length) state.tabs[key].$pane = $existing;
      }
      activate(key);
      /* Menu navigation always passes loader — refresh pane. Tab-strip click uses activate() only. */
      if (typeof loader === "function") {
        loader(state.tabs[key].$pane, function () {});
      }
      return true;
    }

    if (tabCount() >= MAX_TABS) {
      var msg = "Maximum of " + MAX_TABS + " tabs can be open.";
      if (typeof ShowAlertMsg === "function") ShowAlertMsg(msg, "warning");
      else alert(msg);
      return false;
    }

    var $pane;
    if (isHome) {
      $pane = $("#home_dashboard");
      key = HOME_KEY;
    } else {
      var id = paneId(key);
      $pane = $("#" + id);
      if (!$pane.length) {
        $pane = $('<div class="inpc-tab-pane" style="display:none"></div>')
          .attr("id", id)
          .attr("data-tab-key", key);
        $host().append($pane);
      }
    }

    state.tabs[key] = {
      title: title,
      $pane: $pane,
      closable: !isHome && key !== HOME_KEY,
      icon: opts.icon || "",
      iconColor: opts.iconColor || ""
    };
    if (state.order.indexOf(key) < 0) state.order.push(key);
    activate(key);
    if (typeof loader === "function") {
      loader($pane, function () {});
    }
    return true;
  }


  function confirmCloseTab(key, title) {
    var msg = "Do you want to close" + (title ? ' "' + title + '"' : "") + "?";
    function doClose(ok) {
      if (ok) closeTab(key);
    }
    if (window.Swal && typeof Swal.fire === "function") {
      Swal.fire({
        title: "Close tab?",
        text: msg,
        icon: "question",
        showCancelButton: true,
        confirmButtonText: "Yes, close",
        cancelButtonText: "Cancel",
        confirmButtonColor: "#0b5fff",
        cancelButtonColor: "#94a3b8",
        reverseButtons: true,
        focusCancel: true
      }).then(function (result) {
        doClose(!!(result && (result.isConfirmed || result.value === true)));
      });
      try {
        if (window.jQuery) $(".swal2-container").css("z-index", "22222229999");
      } catch (eZ) { /* ignore */ }
    } else if (window.bootbox && typeof bootbox.confirm === "function") {
      bootbox.confirm(msg, doClose);
    } else {
      doClose(window.confirm(msg));
    }
  }

  function closeTab(key) {
    if (!key || key === HOME_KEY) return;
    var t = state.tabs[key];
    if (!t) return;
    if (t.$pane && t.$pane.attr("id") !== "home_dashboard") {
      t.$pane.remove();
    } else if (t.$pane) {
      t.$pane.empty();
    }
    delete state.tabs[key];
    state.order = state.order.filter(function (k) { return k !== key; });
    if (state.active === key) {
      var next = state.order[state.order.length - 1] || HOME_KEY;
      activate(next);
    } else {
      renderBar();
    }
  }

  function bindOnce() {
    if (window.__inpcTabsBound) return;
    window.__inpcTabsBound = true;
    $(document).on("click", "#inpc_module_tab_bar .inpc-tab-link", function (e) {
      if ($(e.target).closest(".inpc-tab-close").length) return;
      var key = $(this).attr("data-tab-key");
      if (!key) return;
      activate(key);
      var t = state.tabs[key];
      var $p = t && t.$pane;
      var empty = !$p || !$p.length || !String($p.html() || "").replace(/\s+/g, "");
      if (key === HOME_KEY && empty && typeof window.LoadHtmlFiles === "function") {
        try {
          var homeMod = (typeof window.inpcHomeModuleForUserType === "function")
            ? window.inpcHomeModuleForUserType(window.inpcGetLoginUserType && window.inpcGetLoginUserType())
            : "home_customer";
          window.LoadHtmlFiles(homeMod, "Home", "Home", "0");
        } catch (eH) { /* ignore */ }
      }
    });
    $(document).on("click", "#inpc_module_tab_bar .inpc-tab-close", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var key = $(this).attr("data-tab-key");
      if (!key || key === HOME_KEY) return;
      var title = (state.tabs[key] && state.tabs[key].title) || key;
      confirmCloseTab(key, title);
    });
    $(window).on("resize.inpcTabs", function () {
      // Crossing mobile breakpoint: hide bar / force single look
      if (!flagOn()) return;
      if (isMobile()) {
        $("#inpc_module_tab_bar").hide();
        // keep panes in DOM but show only active
        activate(state.active || HOME_KEY);
      } else {
        renderBar();
        activate(state.active || HOME_KEY);
      }
    });
  }

  /** Active content element id for loaders (home_dashboard or inpc_tab_pane_*). */
  function activeContentId() {
    if (!enabled()) return "home_dashboard";
    var key = state.active || HOME_KEY;
    return key === HOME_KEY ? "home_dashboard" : paneId(key);
  }

  function $activePane() {
    if (!enabled()) return $("#home_dashboard");
    var t = state.tabs[state.active];
    return t && t.$pane && t.$pane.length ? t.$pane : $("#home_dashboard");
  }

  window.InpcTabs = {
    MAX: MAX_TABS,
    HOME_KEY: HOME_KEY,
    enabled: enabled,
    flagOn: flagOn,
    open: open,
    activate: activate,
    close: closeTab,
    closeConfirm: confirmCloseTab,
    ensureChrome: ensureChrome,
    renderBar: renderBar,
    bindOnce: bindOnce,
    activeContentId: activeContentId,
    $activePane: $activePane,
    tabCount: tabCount,
    setFlag: function (v) {
      window.INPC_INCLUDE_TABS = v;
      if (!enabled()) {
        renderBar();
      } else {
        ensureChrome();
        renderBar();
        activate(state.active || HOME_KEY);
      }
      try { syncSwitcherTabStyles(); } catch (eSf) { /* ignore */ }
    },
    setTabIcons: function (v) {
      window.INPC_TAB_ICONS = v;
      if (enabled()) renderBar();
    },
    tabIconsOn: tabIconsOn,
    setTabStyle: function (style) {
      applyTabStyle(style);
      if (enabled()) renderBar();
    },
    getTabStyle: function () {
      return currentTabStyle();
    },
    syncSwitcherTabStyles: syncSwitcherTabStyles,
    bindSwitcherTabStyles: bindSwitcherTabStyles
  };

  $(function () {
    bindOnce();
    bindSwitcherTabStyles();
    applyTabStyle(currentTabStyle());
    if (enabled()) {
      ensureChrome();
      renderBar();
      activate(HOME_KEY);
    }
  });
})(window, window.jQuery);
