// Loading Main Menu
function isNull(o) {
  return o === null;
}
function date_format($str) {
  if (trim($str) == "" || $str == "undefined" || $str == "''" || empty($str)) {
    $date = "0000-00-00";
    return $date;
  } else {
    var indx = $str.indexOf("/");
    if (indx == -1) return $str;
    else {
      $date = $str.split("/");
      return $date[2] + "-" + $date[1] + "-" + $date[0];
    }
  }
}
/** dd/mm/yyyy on screen -> yyyymmdd for the API. Empty returns 00000000. */
function DateFormatYYYYMMDD($str) {
  if (trim($str) == "" || $str == "undefined" || $str == "''" || empty($str)) {
    return "00000000";
  }
  var indx = $str.indexOf("/");
  if (indx == -1) return $str;
  var $date = $str.split("/");
  if ($date.length < 3) return $str;
  return $date[2] + $date[1] + $date[0];
}
function date_format_time(str) {
  var date = "0000-00-00 00:00:00";
  if (!empty(trim(str))) {
    var indx = str.indexOf(" ");
    if (indx == -1) return date;
    else {
      var split_arr = str.split(" ");
      var date_arr = split_arr[0].split("/");
      date = date_arr[2] + "-" + date_arr[1] + "-" + date_arr[0] + " " + split_arr[1];
    }
  }
  return date;
}

function ui_date_format($str) {
  if (trim($str) == "" || $str == "undefined" || $str == "null") $date = "00/00/0000";
  else $date = $str.split("-");

  if ($date.length == 3) $date = $date[2] + "/" + $date[1] + "/" + $date[0];
  else $date = "00/00/0000";
  return $date;
}

function trim($str) {
  return jQuery.trim($str);
}
/* Hide full-page preloader once UI is ready */
(function hidePagePreloader() {
  function done() {
    var el = document.getElementById("page_preloader");
    if (!el || el.classList.contains("is-done")) return;
    el.classList.add("is-done");
    el.setAttribute("aria-busy", "false");
    setTimeout(function () {
      if (el && el.parentNode) el.parentNode.removeChild(el);
    }, 400);
  }
  var minMs = 450;
  var started = Date.now();
  function finish() {
    var wait = Math.max(0, minMs - (Date.now() - started));
    setTimeout(done, wait);
  }
  if (document.readyState === "complete") {
    finish();
  } else {
    window.addEventListener("load", finish);
    // Safety: never leave overlay stuck
    setTimeout(done, 8000);
  }
})();

/* file_name (no .html) -> menu js_path; filled while building side menu */

/* Session expiry (errorCode -9): local -> login.html; IMEXT -> reload for credential prompt.
 * Flag from GET api/info (imextEnabled), same source as HealthInfoController. */
(function inpcSessionExpirySupport() {
  window.$imextEnabled = window.$imextEnabled === true;
  window.__inpcSessionExpiredHandling = false;

  window.inpcIsImextEnabled = function () {
    return window.$imextEnabled === true;
  };

  window.inpcIsSessionExpiredPayload = function (json) {
    if (!json || typeof json !== "object") return false;
    var c = json.errorCode != null ? json.errorCode : json.error_code;
    return c === -9 || c === "-9";
  };

  /** Common handler for unauthenticated / session-expired API responses. */
  window.inpcHandleSessionExpired = function (/* optMsg */) {
    if (window.__inpcSessionExpiredHandling) return;
    window.__inpcSessionExpiredHandling = true;
    try {
      if (typeof window.inpcClearUserCookies === "function") {
        window.inpcClearUserCookies();
      }
    } catch (eClear) { /* ignore */ }
    if (window.inpcIsImextEnabled()) {
      try {
        (window.top || window).location.reload();
      } catch (eRel) {
        window.location.reload();
      }
    } else {
      window.location.href = "login.html";
    }
  };

  /* Legacy MainPageNew.js CallLogout() on error_code -9 */
  window.CallLogout = window.CallLogout || function () {
    window.inpcHandleSessionExpired();
  };

  function inpcRememberImextFlag(json) {
    if (json && json.errorCode === 0 && json.data && typeof json.data.imextEnabled !== "undefined") {
      window.$imextEnabled = !!json.data.imextEnabled;
    }
  }

  function inpcWireAjaxSessionGuard() {
    if (typeof window.jQuery === "undefined") return;
    var $ = window.jQuery;
    /* Shared response handler: HTTP 200 JSON body with errorCode -9 */
    $(document).off("ajaxSuccess.inpcSession").on("ajaxSuccess.inpcSession", function (_evt, xhr) {
      if (window.__inpcSessionExpiredHandling) return;
      var json = xhr && xhr.responseJSON;
      if (!json && xhr && xhr.responseText) {
        var t = String(xhr.responseText).trim();
        if (!t || (t.charAt(0) !== "{" && t.charAt(0) !== "[")) return;
        try { json = JSON.parse(t); } catch (eParse) { return; }
      }
      if (window.inpcIsSessionExpiredPayload(json)) {
        window.inpcHandleSessionExpired(json.message || json.data);
      }
    });
    /* ajaxSetup dataFilter: catch HTTP 200 JSON bodies with errorCode -9 (before success callbacks). */
    $.ajaxSetup({
      dataFilter: function (data, type) {
        if (type === "json" && data && typeof data === "string" && !window.__inpcSessionExpiredHandling) {
          var t = data.trim();
          if (t.charAt(0) === "{" || t.charAt(0) === "[") {
            try {
              var json = JSON.parse(t);
              if (window.inpcIsSessionExpiredPayload(json)) {
                setTimeout(function () {
                  window.inpcHandleSessionExpired(json.message || json.data);
                }, 0);
              }
            } catch (eDf) { /* ignore parse errors */ }
          }
        }
        return data;
      }
    });
  }

  function inpcLoadImextFlag() {
    if (typeof window.jQuery === "undefined") return;
    window.jQuery.ajax({
      url: "api/info",
      method: "GET",
      dataType: "json",
      xhrFields: { withCredentials: true }
    }).done(inpcRememberImextFlag).fail(function () { /* leave default false */ });
  }

  if (typeof window.jQuery !== "undefined") {
    inpcWireAjaxSessionGuard();
    window.jQuery(inpcLoadImextFlag);
  } else {
    window.addEventListener("load", function () {
      inpcWireAjaxSessionGuard();
      inpcLoadImextFlag();
    });
  }
})();

window.$inpc_menu_js_by_file = window.$inpc_menu_js_by_file || {};
window.$inpc_menu_mobile_by_file = window.$inpc_menu_mobile_by_file || {};

/** PHP-style in_array -- same global as insba WebContent/js/main_page.js (shared for load_js_files / modules). */
function in_array(needle, haystack, argStrict) {
     
    var key = '', strict = !!argStrict;

    if (strict) {
        for (key in haystack) {
            if (haystack[key] === needle) {
                return true;
            }
        }
    } else {
        for (key in haystack) {
            if (haystack[key] == needle) {
                return true;
            }
        }
    }

    return false;
}
/**
 * INPCV2 MainPage -- menus + theme switcher (Sunstar-style).
 * Menus: GET api/auth/menus -- #side-menu, then jQuery expand/collapse (like dropMenu).
 * Module open: insba-style getModulesDetailsNew -- html_files/{app_type}/{file_name}.html
 */
(function ($) {
  "use strict";

  // Same global used by legacy insba system.js / MainPageNew.js
  window.$g_app_tye = window.$g_app_tye || "INPC";

  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function loadSwitcher() {
    return fetch("html_files/INPC/switcher.html?v=202609290941", { credentials: "same-origin" })
      .then(function (r) {
        if (!r.ok) throw new Error("switcher " + r.status);
        return r.text();
      })
      .then(function (html) {
        $("#switcher").html(html);
        try {
          if (window.InpcTabs) {
            if (InpcTabs.bindSwitcherTabStyles) InpcTabs.bindSwitcherTabStyles();
            if (InpcTabs.syncSwitcherTabStyles) InpcTabs.syncSwitcherTabStyles();
          }
        } catch (eTabSw) { /* ignore */ }
        var s = document.createElement("script");
        s.src = "nuiassets/js/custom-switcher.min.js?v=202609290850";
        document.body.appendChild(s);
        // Theme script changes layout attributes; reset stale menu state after each mode change.
        $(document).off("change.inpcLayout", "#switcher-horizontal, #switcher-vertical, #switcher-dropdown-menu, #switcher-mega-menu")
          .on("change.inpcLayout", "#switcher-horizontal, #switcher-vertical, #switcher-dropdown-menu, #switcher-mega-menu", function () {
            setTimeout(function () {
              $("#side-menu li.has-sub").removeClass("open");
              $("#side-menu ul.slide-menu").each(function () {
                clearSlideMenuInlineStyles(this);
                this.classList.remove("active");
                this.style.setProperty("display", "none", "important");
              });
              bindMenuClicks();
            }, 100);
          });
      })
      .catch(function (err) {
        console.warn("Theme switcher not loaded:", err);
      });
  }


  function navStyle() {
    return ($("html").attr("data-nav-style") || "").toLowerCase();
  }

  function isHoverNavStyle() {
    var ns = navStyle();
    return ns === "menu-hover" || ns === "icon-hover";
  }


  /** Strip accordion/flyout inline styles (vertical sets position:static !important). */
  function clearSlideMenuInlineStyles(el) {
    if (!el || !el.style) return;
    [
      "display", "position", "inset", "inset-inline-start", "inset-inline-end",
      "inset-block-start", "inset-block-end", "left", "right", "top", "bottom",
      "width", "min-width", "max-width", "height", "max-height", "box-shadow",
      "border-radius", "transform", "z-index", "margin", "float", "visibility",
      "opacity", "overflow", "pointer-events"
    ].forEach(function (p) { el.style.removeProperty(p); });
  }
  window.inpcClearSlideMenuInlineStyles = clearSlideMenuInlineStyles;


  /** Close every open branch and clear inline display so theme hover CSS can work. */
  function collapseAllMenus(clearInline) {
    $("#side-menu li.has-sub").removeClass("open");
    $("#side-menu a.side-menu__item").removeClass("active");
    var $menus = $("#side-menu ul.slide-menu");
    $menus.removeClass("active");
    if (clearInline || isHoverNavStyle() || $("html").attr("data-nav-layout") === "horizontal") {
      $menus.each(function () { clearSlideMenuInlineStyles(this); });
    } else {
      $menus.each(function () {
        clearSlideMenuInlineStyles(this);
        this.style.setProperty("display", "none", "important");
      });
    }
  }

  /** Keep Double Menu second rail open for the active top-level section (e.g. Masters). */
  function pinDoubleMenuForActiveLeaf() {
    var html = document.documentElement;
    if ((html.getAttribute("data-vertical-style") || "").toLowerCase() !== "doublemenu") return;
    var $active = $("#side-menu a.side-menu__item.active").filter(function () {
      return !$(this).parent().hasClass("has-sub");
    }).first();
    if (!$active.length) return;
    var $top = $active.closest("#side-menu > li.has-sub");
    if (!$top.length) return;
    $("#side-menu .slide-menu").removeClass("double-menu-active");
    var $pane = $top.children("ul.slide-menu").first();
    if (!$pane.length) return;
    $pane.addClass("double-menu-active");
    $pane.each(function () { this.style.removeProperty("display"); });
    // Keep Masters (etc.) marked open so the icon rail stays visible after mouse-out.
    $("#side-menu > li.has-sub").removeClass("open");
    $top.addClass("open");
    $top.children("a.side-menu__item").addClass("active");
    html.setAttribute("data-toggled", "double-menu-open");
  }

  /** Phone drawer: same close as the hamburger (data-toggled=close + overlay off). */
  function closeMobileDrawer() {
    var html = document.documentElement;
    var mobile = typeof window.inpcIsMobileNav === "function"
      ? window.inpcIsMobileNav()
      : (window.matchMedia ? window.matchMedia("(max-width: 991.98px)").matches : window.innerWidth < 992);
    if (!mobile && html.getAttribute("data-inpc-mobile-nav") !== "1") return false;
    html.setAttribute("data-toggled", "close");
    var overlay = document.getElementById("responsive-overlay");
    if (overlay) overlay.classList.remove("active");
    return true;
  }
  window.inpcCloseMobileDrawer = closeMobileDrawer;

  function closeFlyoutAfterLeaf() {
    var html = document.documentElement;
    var ns = (html.getAttribute("data-nav-style") || "").toLowerCase();
    var vs = (html.getAttribute("data-vertical-style") || "").toLowerCase();
    var layout = (html.getAttribute("data-nav-layout") || "").toLowerCase();

    // Mobile overlay stays open unless data-toggled becomes "close". Desktop flyout logic below would set "open".
    if (closeMobileDrawer()) return;

    // Double Menu: do NOT close the Masters sub-icon rail after opening a child page.
    if (vs === "doublemenu") {
      pinDoubleMenuForActiveLeaf();
      return;
    }

    collapseAllMenus(true);
    // Horizontal Menu Hover/Click: never enter *-closed (theme shrinks bar / hides labels via leftover overlay).
    if (layout === "horizontal" && (ns === "menu-hover" || ns === "menu-click")) {
      html.setAttribute("data-toggled", "open");
      html.removeAttribute("data-vertical-style");
      return;
    }
    // Hover/click flyouts can collapse after navigation; overlay accordion stays as-is.
    if (ns === "menu-click") html.setAttribute("data-toggled", "menu-click-closed");
    else if (ns === "icon-click") html.setAttribute("data-toggled", "icon-click-closed");
    else if (ns === "menu-hover") html.setAttribute("data-toggled", "menu-hover-closed");
    else if (ns === "icon-hover") html.setAttribute("data-toggled", "icon-hover-closed");
  }


  var __inpcNavStyleTimer = null;
  function onNavStyleChanged() {
    if (__inpcNavStyleTimer) clearTimeout(__inpcNavStyleTimer);
    __inpcNavStyleTimer = setTimeout(function () {
      // Mobile forceVertical re-asserts html attrs; those mutations must NOT wipe open accordion parents.
      if (window.__inpcSuppressMenuCollapse) return;
      var html = document.documentElement;
      var mobile = typeof window.inpcIsMobileNav === "function" && window.inpcIsMobileNav();
      if (mobile && html.getAttribute("data-inpc-mobile-nav") === "1") {
        bindMenuClicks();
        return;
      }
      collapseAllMenus(true);
      bindMenuClicks();
      inpcNormalizeMenuHoverLabels();
    }, 30);
  }
  function isHorizontalDropdown() {
    var $html = $("html");
    return $html.attr("data-nav-layout") === "horizontal" &&
      $html.attr("data-horizontal-submenu") !== "mega";
  }

  /**
   * Sunstar-style menu toggle.
   * Vertical: jQuery slide.
   * Horizontal Dropdown: add/remove .open and let NUI CSS position the submenu.
   */
  function closeMenuBranch($li) {
    $li.removeClass("open");
    $li.children("a.side-menu__item").removeClass("active");
    $li.find("li.has-sub").removeClass("open");
    $li.find("a.side-menu__item").removeClass("active");
    $li.find("ul.slide-menu").each(function () {
      this.classList.remove("active");
      if ($("html").attr("data-nav-layout") === "horizontal") {
        clearSlideMenuInlineStyles(this);
        this.style.setProperty("display", "none", "important");
      } else {
        this.style.setProperty("display", "none", "important");
      }
    });
  }

  /**
   * Accordion menus: opening one closes every sibling branch
   * (fixes horizontal dropdowns stuck with display:block).
   */
  function dropMenu(elt) {
    if (dropMenu.__inpcBusy) return;
    dropMenu.__inpcBusy = true;
    setTimeout(function () { dropMenu.__inpcBusy = false; }, 0);
    var $li = $(elt).parent("li");
    var $submenu = $li.children("ul.slide-menu");
    var opening = !$li.hasClass("open");

    // Close all sibling menus (MASTERS / TRANSACTION / SYSTEM, or nested peers)
    $li.siblings("li.has-sub").each(function () {
      closeMenuBranch($(this));
    });

    // Top-level safety: if this is a root item, close any other open roots
    if ($li.parent().is("#side-menu")) {
      $("#side-menu > li.has-sub").not($li).each(function () {
        closeMenuBranch($(this));
      });
    }

    if (isHorizontalDropdown() || $("html").attr("data-nav-layout") === "horizontal") {
      if (opening) {
        $li.addClass("open");
        $(elt).addClass("active");
        var isMega = $("html").attr("data-nav-layout") === "horizontal" &&
          $("html").attr("data-horizontal-submenu") === "mega";
        // Drop leftover vertical accordion inline position:static so theme flyout can overlay.
        $submenu.each(function () {
          clearSlideMenuInlineStyles(this);
          // Mega columns need flex row; block stacks sections down the left.
          this.style.setProperty("display", isMega ? "flex" : "block", "important");
          this.classList.add("active");
          if (isMega) {
            // Nested column menus must stay visible (closeMenuBranch may have set display:none).
            $(this).find("ul.slide-menu").each(function () {
              clearSlideMenuInlineStyles(this);
              this.style.setProperty("display", "flex", "important");
              this.style.setProperty("position", "static", "important");
            });
            if (window.inpcApplyMegaPanelLayout) {
              window.inpcApplyMegaPanelLayout($li[0], this);
            }
          }
        });
      } else {
        closeMenuBranch($li);
      }
      return;
    }

    if (!opening) {
      $li.removeClass("open");
      $(elt).removeClass("active");
      $submenu.stop(true, true).slideUp(200);
      $li.find("li.has-sub").removeClass("open");
      $li.find("ul.slide-menu").css("display", "none");
    } else {
      $li.addClass("open");
      $(elt).addClass("active");
      $li.siblings(".has-sub").children("ul.slide-menu").stop(true, true).slideUp(200);
      $submenu.stop(true, true);
      var vs = ($("html").attr("data-vertical-style") || "").toLowerCase();
      var ns = ($("html").attr("data-nav-style") || "").toLowerCase();
      // Icon/doublemenu keep theme flyouts; overlay/menu-click/menu-hover expand in-flow.
      var keepFlyout = vs === "doublemenu" || ns === "icon-hover" || ns === "icon-click";
      var layout = ($("html").attr("data-nav-layout") || "").toLowerCase();
      $submenu.each(function () {
        this.style.setProperty("display", "block", "important");
        this.style.setProperty("visibility", "visible", "important");
        this.style.setProperty("height", "auto", "important");
        this.style.setProperty("opacity", "1", "important");
        // Accordion inflow ONLY on vertical -- never leave position:static on horizontal.
        if (!keepFlyout && layout === "vertical") {
          this.style.setProperty("position", "static", "important");
          this.style.setProperty("inset-inline-start", "auto", "important");
          this.style.setProperty("inset-block-start", "auto", "important");
          this.style.setProperty("left", "auto", "important");
          this.style.setProperty("top", "auto", "important");
          this.style.setProperty("width", "100%", "important");
          this.style.setProperty("box-shadow", "none", "important");
          this.classList.remove("active");
        }
      });
      // .active on slide-menu is a horizontal flyout hook -- do not apply for vertical accordion.
    }
  }

  function bindMenuClicks() {
    // Capture-phase exclusive toggle for accordion parents so theme defaultmenu
    // slideToggle cannot open-then-close on the same click (Masters flash).
    if (!window.__inpcHasSubCapture) {
      window.__inpcHasSubCapture = true;
      document.addEventListener(
        "click",
        function (e) {
          var t = e.target;
          if (!t || !t.closest) return;
          var a = t.closest("#side-menu li.has-sub > a.side-menu__item");
          if (!a) return;
          e.preventDefault();
          e.stopPropagation();
          if (typeof e.stopImmediatePropagation === "function") e.stopImmediatePropagation();
          $("#side-menu li.slide:not(.has-sub) > a.side-menu__item").removeClass("active");
          dropMenu(a);
        },
        true
      );
    }

    // Parent folders: handled only in capture phase above (avoids open-then-close double toggle).
    $(document).off("click.inpcMenu", "#side-menu li.has-sub > a.side-menu__item");

    // Leaf items
    $(document).off("click.inpcLeaf", "#side-menu li.slide:not(.has-sub) > a.side-menu__item");
    $(document).on("click.inpcLeaf", "#side-menu li.slide:not(.has-sub) > a.side-menu__item", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var loadType = String(this.getAttribute("data-load-type") || "").toLowerCase();
      var oc = (this.getAttribute("onclick") || "").trim();
      // DeskMobile: always open via onMenuClick (viewport width + data-mobile-file-name)
      if (loadType === "deskmobile" && typeof window.onMenuClick === "function") {
        $("#side-menu a.side-menu__item").removeClass("active");
        $(this).addClass("active");
        window.onMenuClick(this);
      } else if (!oc && typeof window.onMenuClick === "function") {
        window.onMenuClick(this);
      } else {
        // Insba-style: native onclick opens the module; this handler only keeps active UI.
        $("#side-menu a.side-menu__item").removeClass("active");
        $(this).addClass("active");
      }
      // Always collapse sticky flyouts after a leaf is chosen.
      closeFlyoutAfterLeaf();
      // Theme scripts can re-open the drawer in the same turn; close again after that.
      setTimeout(closeMobileDrawer, 0);
      setTimeout(closeMobileDrawer, 80);
      setTimeout(pinDoubleMenuForActiveLeaf, 0);
      setTimeout(pinDoubleMenuForActiveLeaf, 200);
      setTimeout(closeMobileDrawer, 260);
    });

    // Close dropdowns when clicking outside the menu (hover + horizontal).
    $(document).off("click.inpcOutside").on("click.inpcOutside", function (e) {
      if (!$(e.target).closest("#side-menu, .app-sidebar").length) {
        if (isHoverNavStyle() || isHorizontalDropdown()) {
          collapseAllMenus(true);
        }
      }
    });
  }

  /** Escape for single-quoted JS literal inside HTML onclick="...". */
  function jsQuote(v) {
    return String(v == null ? "" : v)
      .replace(/\\/g, "\\\\")
      .replace(/'/g, "\\'")
      .replace(/\r/g, "")
      .replace(/\n/g, " ");
  }

  function buildMenuOnclick(opts) {
    var fileName = sanitizeModuleFileName(opts.file_name || "").replace(/\.html$/i, "");
    var moduleName = opts.module_name || fileName || "";
    var displayName = opts.display_name || moduleName || fileName || "";
    var internalCode = opts.internal_code != null ? String(opts.internal_code) : "0";
    var loadType = String(opts.load_type || "Internal").trim();
    var menuType = String(opts.menu_type || "").toLowerCase();
    var menuTag = String(opts.menu_tag || "").trim();
    var lt = loadType.toLowerCase();

    if (lt === "comingsoon" || menuTag.toLowerCase() === "comingsoon") {
      return "";
    }
    if (
      menuType === "direct" ||
      lt === "internal" ||
      lt === "new" ||
      menuTag.toLowerCase() === "new" ||
      lt === ""
    ) {
      return (
        "LoadHtmlFiles('" +
        jsQuote(fileName) +
        "','" +
        jsQuote(moduleName) +
        "','" +
        jsQuote(displayName) +
        "','" +
        jsQuote(internalCode) +
        "')"
      );
    }
    if (lt === "deskmobile") {
      /* open via onMenuClick — uses data-mobile-file-name + viewport width */
      return "";
    }
    if (lt === "framework" || lt === "fw") {
      return (
        "getModulesDetailsNew('" +
        jsQuote(fileName) +
        "','" +
        jsQuote(moduleName) +
        "','" +
        jsQuote(internalCode) +
        "','New','" +
        jsQuote(displayName) +
        "',0)"
      );
    }
    if (lt === "application" && opts.onclick) {
      return String(opts.onclick);
    }
    if (fileName) {
      return (
        "LoadHtmlFiles('" +
        jsQuote(fileName) +
        "','" +
        jsQuote(moduleName) +
        "','" +
        jsQuote(displayName) +
        "','" +
        jsQuote(internalCode) +
        "')"
      );
    }
    return "";
  }

  function buildSideMenuHtml(menus) {
    var tree = {};
    var directMenus = [];
    /* INPC_DIRECT_MENUS: Menu Type Direct -- top-level leaf like Home */
    (menus || []).forEach(function (m) {
      /* Map file_name -> menu icon for module tabs when INPC_TAB_ICONS is on (Direct + folder). */
      try {
        if (!window.INPC_MENU_ICONS) window.INPC_MENU_ICONS = {};
        var fKey = String(m.file_name || m.system_module_table_name || "").replace(/\.html$/i, "").trim();
        if (fKey) {
          window.INPC_MENU_ICONS[fKey] = {
            icon: m.icons || "ri-file-list-line",
            color: m.icons_color || ""
          };
        }
      } catch (eIconMap) { /* ignore */ }

      var menuType = String(m.menu_type || "").toLowerCase();
      if (menuType === "direct") {
        var dseq = Number(m.sequence);
        // No sequence from API yet -- place Direct after folder groups (Contact Us last).
        if (!isFinite(dseq)) dseq = 100000;
        m._seq = dseq;
        directMenus.push(m);
        return;
      }
      var g = m.menu_name || "Other";
      var s = m.sub_menu_name || "Others";
      var seq = Number(m.sequence);
      if (!isFinite(seq)) seq = 9999;
      if (!tree[g]) tree[g] = { items: {}, group_icons: m.group_icons || "", group_icons_color: m.group_icons_color || "", sequence: seq };
      if (seq < tree[g].sequence) tree[g].sequence = seq;
      if (m.group_icons) tree[g].group_icons = m.group_icons;
      if (m.group_icons_color) tree[g].group_icons_color = m.group_icons_color;

      if (!tree[g].items[s]) tree[g].items[s] = [];
      tree[g].items[s].push(m);
    });

    function iconClass(raw, fallback) {
      var ic = String(raw || "").trim();
      if (!ic) return fallback;
      // Already Remix / full class list
      if (/\bri-/.test(ic) || /\bfa\b/.test(ic) || ic.indexOf(" ") >= 0) return ic;
      // Bare remix name without ri-
      if (ic.indexOf("ri-") !== 0 && /^[a-z0-9-]+$/i.test(ic)) {
        // legacy FA short names already migrated in DB to ri-*; keep fallback-safe
        return ic.indexOf("-") >= 0 ? ("ri-" + ic.replace(/^ri-/, "")) : fallback;
      }
      return ic;
    }

    function iconHtml(raw, fallback, color) {
      var cls = iconClass(raw, fallback);
      var style = "";
      if (color) {
        style = ' style="color:' + String(color).replace(/"/g, "") + '"';
      }
      return "<i class='" + cls + " side-menu__icon me-1 fs-16'" + style + "></i>";
    }

    var homeMod = window.inpcHomeModuleForUserType(window.inpcGetLoginUserType());
    var html =
      "<li class='slide'>" +
      "  <a href='javascript:void(0);' class='side-menu__item'" +
      "     id='home' a_c_system_name='home' data-file-name='" + homeMod + ".html'" +
      "     data-module-name='Home' data-internal-code='0' data-display-name='Home' data-load-type='Internal'" +
      "     onclick=\"LoadHtmlFiles('" + homeMod + "','Home','Home','0')\">" +
      "    <i class='ri-home-4-line side-menu__icon me-1 fs-16' style='color:#0b5fff'></i>" +
      "    <span class='side-menu__label'>Home</span>" +
      "  </a>" +
      "</li>";

    // Home already rendered. Merge Direct + folder groups by sequence (Contact Us last).
    var topLevel = [];
    directMenus.forEach(function (m) {
      topLevel.push({ kind: "direct", sequence: m._seq, menu: m });
    });
    Object.keys(tree).forEach(function (menuName) {
      topLevel.push({
        kind: "group",
        sequence: tree[menuName].sequence,
        name: menuName,
        meta: tree[menuName]
      });
    });
    topLevel.sort(function (a, b) {
      if (a.sequence !== b.sequence) return a.sequence - b.sequence;
      var an = a.kind === "direct" ? String(a.menu.menu_name || "") : String(a.name || "");
      var bn = b.kind === "direct" ? String(b.menu.menu_name || "") : String(b.name || "");
      return an.localeCompare(bn);
    });

    topLevel.forEach(function (entry) {
      if (entry.kind === "direct") {
        (function (m) {
      var fileName = String(m.direct_file_name || m.file_name || "").replace(/\.html$/i, "");
      var label = m.display_name || m.menu_name || fileName || "Direct";
      var ic = m.group_icons || m.icons || "ri-customer-service-2-line";
      var icolor = m.group_icons_color || m.icons_color || "#0b5fff";
      html +=
        "<li class='slide'>" +
        "  <a href='javascript:void(0);' class='side-menu__item'" +
        "     id='" + escapeHtml(fileName) + "'" +
        "     a_c_system_name='" + escapeHtml(fileName) + "'" +
        "     data-file-name='" + escapeHtml(fileName) + "'" +
        "     data-module-name='" + escapeHtml(fileName) + "'" +
        "     data-internal-code='" + escapeHtml(m.internal_code || "0") + "'" +
        "     data-display-name='" + escapeHtml(label) + "'" +
        "     data-menu-type='Direct'" +
        "     data-load-type='Internal'" +
        "     onclick=\"" + buildMenuOnclick({
          file_name: fileName,
          module_name: fileName,
          display_name: label,
          internal_code: m.internal_code || "0",
          load_type: "Internal",
          menu_type: "Direct"
        }) + "\">" +
        iconHtml(ic, "ri-customer-service-2-line", icolor) +
        "     <span class='side-menu__label'>" + escapeHtml(label) + "</span>" +
        "  </a>" +
        "</li>";
        })(entry.menu);
        return;
      }
      (function (menuName) {
        var gMeta = entry.meta;
      /* gMeta from entry */
      html +=
        "<li class='slide has-sub'>" +
        "  <a href='javascript:void(0);' class='side-menu__item'>" +
        iconHtml(gMeta.group_icons, "ri-folder-2-line", gMeta.group_icons_color) +
        "    <span class='side-menu__label'>" + escapeHtml(menuName) + "</span>" +
        "    <i class='ri-arrow-right-s-line side-menu__angle'></i>" +
        "  </a>" +
        "  <ul class='slide-menu child1' >" +
        "    <li class='slide side-menu__label1'><a href='javascript:void(0)'>" +
        escapeHtml(menuName) +
        "</a></li>";

      Object.keys(gMeta.items).forEach(function (subName) {
        var items = gMeta.items[subName];
        var isOthers = subName === "Others";

        if (!isOthers) {
          html +=
            "<li class='slide has-sub'>" +
            "  <a href='javascript:void(0);' class='side-menu__item'>" +
            "    <span class='side-menu__label'>" + escapeHtml(subName) + "</span>" +
            "    <i class='ri-arrow-right-s-line side-menu__angle'></i>" +
            "  </a>" +
            "  <ul class='slide-menu child2' >";
        }

        items.forEach(function (m) {
          var label = m.display_name || m.module_name || m.file_name || "(menu)";
          var fileName = m.file_name || "";
          var moduleName = m.module_name || fileName || "";
          var internalCode = m.internal_code || "";
          var displayName = m.display_name || label;
          var jsPath = String(m.js_path || "").trim();
          var mobileFileName = String(m.mobile_file_name || m.MOBILE_FILE_NAME || "").trim();
          var fileKey = String(fileName || "").replace(/\.html$/i, "");
          var mobileKey = String(mobileFileName || "").replace(/\.html$/i, "");
          if (fileKey && jsPath) {
            window.$inpc_menu_js_by_file[fileKey] = jsPath;
          }
          if (mobileKey && jsPath) {
            window.$inpc_menu_js_by_file[mobileKey] = jsPath;
          }
          if (fileKey && mobileKey) {
            window.$inpc_menu_mobile_by_file[fileKey] = mobileKey;
          }
          html +=
            "<li class='slide'>" +
            "  <a href='javascript:void(0);' class='side-menu__item'" +
            "     id='" + escapeHtml(fileName) + "'" +
            "     a_c_system_name='" + escapeHtml(fileName || moduleName) + "'" +
            "     data-file-name='" + escapeHtml(fileName) + "'" +
            "     data-mobile-file-name='" + escapeHtml(mobileFileName) + "'" +
            "     data-module-name='" + escapeHtml(moduleName) + "'" +
            "     data-internal-code='" + escapeHtml(internalCode) + "'" +
            "     data-display-name='" + escapeHtml(displayName) + "'" +
            "     data-js-path='" + escapeHtml(jsPath) + "'" +
            "     data-onclick='" + escapeHtml(m.onclick || "") + "'" +
            "     data-load-type='" + escapeHtml(m.load_type || "Internal") + "'" +
            "     onclick=\"" + buildMenuOnclick({
              file_name: fileName,
              mobile_file_name: mobileFileName,
              module_name: moduleName,
              display_name: displayName,
              internal_code: internalCode,
              load_type: m.load_type || "Internal",
              menu_tag: m.menu_tag || "",
              onclick: m.onclick || ""
            }) + "\"" +
            "     main_menu_name='" + escapeHtml(m.menu_name || "") + "'" +
            "     sub_menu_name='" + escapeHtml(m.sub_menu_name || "") + "'>" +
            iconHtml(m.icons, "ri-file-list-line", m.icons_color) +
            "     <span class='side-menu__label'>" + escapeHtml(label) + "</span>" +
            "  </a>" +
            "</li>";
        });

        if (!isOthers) {
          html += "</ul></li>";
        }
      });

      html += "</ul></li>";
      })(entry.name);
    });


    if (!Object.keys(tree).length && !directMenus.length) {
      html =
        "<li class='slide'><a class='side-menu__item' href='javascript:void(0);'>" +
        "<span class='side-menu__label'>No menus for this user</span></a></li>";
    }
    return html;
  }


  /** Resolve module HTML path like insba MainPageNew.js */
  
    function normalizeLoadType(v) {
    return String(v || "Internal").trim().toLowerCase();
  }

  /** Internal = plain HTML into content pane; FrameWork = HTML then FW module init */
  function isPlainHtmlLoadType(loadType) {
    var t = normalizeLoadType(loadType);
    // Insba SystemSetup: Internal and NEW both use LoadHtmlFiles
    return t === "internal" || t === "direct" || t === "new" || t === "";
  }

  function isFrameworkLoadType(loadType) {
    return normalizeLoadType(loadType) === "framework";
  }


  /**
   * Normalize ia_menu_options.file_name to a safe relative path under html_files/.
   * Folder-qualified names resolve directly under html_files/ (e.g. CUST_SERVICE/foo).
   * Bare names still resolve to html_files/{app}/{name}.html. Rejects ".." traversal.
   */
  function sanitizeModuleFileName(systemModuleName) {
    var raw = String(systemModuleName == null ? "" : systemModuleName).trim();
    if (!raw) return "";
    raw = raw.split("?")[0].split("#")[0];
    raw = raw.replace(/\\/g, "/").replace(/^\.\//, "").replace(/^\/+/, "").trim();
    if (!raw) return "";
    var parts = raw.split("/");
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      var seg = String(parts[i] || "").trim();
      if (!seg || seg === ".") continue;
      if (seg === "..") return ""; // path traversal not allowed
      out.push(seg);
    }
    return out.join("/");
  }

  function moduleHtmlPath(systemModuleName) {
    var raw = sanitizeModuleFileName(systemModuleName);
    if (!raw) return "";
    var app = window.$g_app_tye || "INPC";
    var rel;
    if (/^html_files\//i.test(raw)) {
      rel = raw.replace(/\.html$/i, "") + ".html";
    } else {
      var name = raw.replace(/\.html$/i, "");
      if (name.indexOf("/") >= 0) {
        // Folder-qualified names map directly beneath static/html_files.
        rel = "html_files/" + name + ".html";
      } else {
        rel = "html_files/" + app + "/" + name + ".html";
      }
    }
    return rel + "?r=" + Math.random();
  }
  window.inpcSanitizeModuleFileName = sanitizeModuleFileName;
  window.inpcModuleHtmlPath = moduleHtmlPath;

  /** Resolve menu js_path for a file_name (no .html). */
  function resolveMenuJsPath(fileName, explicit) {
    var fromArg = String(explicit || "").trim();
    if (fromArg) return fromArg;
    var key = String(fileName || "").replace(/\.html$/i, "").trim();
    if (!key) return "";
    var map = window.$inpc_menu_js_by_file || {};
    return String(map[key] || "").trim();
  }

  /**
   * Once-only menu JS loader via includeJsFilesMannually + $loaded_js_files_arr.
   * Semicolon-separated paths supported. Calls done after all scripts are ready.
   */
  function loadMenuJsThen(jsPath, done) {
    var cb = typeof done === "function" ? done : function () {};
    var raw = String(jsPath || "").trim();
    if (!raw) {
      cb();
      return;
    }
    var parts = raw.split(/;+/).map(function (p) { return $.trim(p); }).filter(Boolean);
    var i = 0;
    function next() {
      if (i >= parts.length) {
        cb();
        return;
      }
      var p = parts[i++];
      if (typeof includeJsFilesMannually === "function") {
        includeJsFilesMannually(p, next);
      } else {
        // Fallback: still avoid duplicate script tags via $loaded_js_files_arr when present
        if (typeof $loaded_js_files_arr !== "undefined" && typeof in_array === "function" && in_array(p, $loaded_js_files_arr)) {
          next();
          return;
        }
        var s = document.createElement("script");
        s.type = "text/javascript";
        s.onload = next;
        s.onerror = function () {
          if (typeof showJsLoadError === "function") showJsLoadError(p);
        };
        s.src = p;
        document.getElementsByTagName("head")[0].appendChild(s);
        if (typeof $loaded_js_files_arr !== "undefined") {
          $loaded_js_files_arr.push(p);
        }
      }
    }
    next();
  }

  /** Old MainPage.js pattern: $("#home_dashboard").load(path). JS Path loads first (once-only). */
  function loadPage(path, title, jsPath, tabKey) {
    path = $.trim(path || "");
    var key = $.trim(tabKey || "");
    if (!key) {
      /* derive from path stem when possible */
      var stem = path.replace(/\\/g, "/").split("?")[0].split("/").pop() || "";
      stem = stem.replace(/\.html$/i, "");
      key = stem || "home";
    }
    /* Only real Home tab uses key "home" (explicit tabKey or configured home file). */
    if (tabKey === "home" || key === "home") {
      key = (window.InpcTabs && InpcTabs.HOME_KEY) || "home";
    } else if (typeof window.inpcHomeModuleForUserType === "function") {
      try {
        var homeFile = String(window.inpcHomeModuleForUserType(window.inpcGetLoginUserType && window.inpcGetLoginUserType()) || "")
          .replace(/\.html$/i, "");
        if (homeFile && key === homeFile) key = (window.InpcTabs && InpcTabs.HOME_KEY) || "home";
      } catch (_eHomeKey) { /* ignore */ }
    }

    if (!path) {
      $("#content_title").text(title || "Module");
      var $emptyHost = window.InpcTabs ? InpcTabs.$activePane() : $("#home_dashboard");
      $emptyHost.html(
        "<div class='alert alert-warning mb-0'>No file_name configured for this menu.</div>"
      );
      return;
    }

    // Keep module loads inside this application; reject external/script URLs and traversal.
    if (/^(?:https?:)?\/\//i.test(path) || /^javascript:/i.test(path)) {
      $("#content_title").text(title || "Module");
      (window.InpcTabs ? InpcTabs.$activePane() : $("#home_dashboard")).html(
        "<div class='alert alert-danger mb-0'>External module path is not allowed.</div>"
      );
      return;
    }

    path = path.replace(/\\/g, "/").replace(/^\.\//, "").replace(/^\//, "");
    if (/(^|\/)\.\.(\/|$)/.test(path.split("?")[0])) {
      $("#content_title").text(title || "Module");
      (window.InpcTabs ? InpcTabs.$activePane() : $("#home_dashboard")).html(
        "<div class='alert alert-danger mb-0'>Invalid module path.</div>"
      );
      return;
    }

    function runLoad($pane) {
      var hostId = ($pane && $pane.attr("id")) || "home_dashboard";
      try {
        if (typeof showLoader === "function") showLoader("Loading " + (title || "page") + "...", hostId);
      } catch (_eShow) { /* ignore */ }

      function doHtmlLoad() {
        $pane.load(path, function (_response, status, xhr) {
          try {
            if (typeof hideLoader === "function") hideLoader(hostId);
          } catch (_eHide) { /* ignore */ }
          if (status === "error") {
            $pane.html(
              "<div class='alert alert-danger mb-0'>Unable to load <code>" +
                escapeHtml(path) +
                "</code> (HTTP " +
                xhr.status +
                ").</div>"
            );
          } else if (typeof initCommonWidgets === "function") {
            initCommonWidgets($pane[0] || document.getElementById(hostId));
          }
        });
      }
      loadMenuJsThen(jsPath, doHtmlLoad);
    }

    if (window.InpcTabs && typeof InpcTabs.open === "function") {
      var ok = InpcTabs.open(
        (function () {
          var o = { key: key, title: title || key, isHome: key === "home" };
          try {
            var ic = (window.INPC_MENU_ICONS && window.INPC_MENU_ICONS[key]) || null;
            if (ic) { o.icon = ic.icon; o.iconColor = ic.color; }
          } catch (eIc) { /* ignore */ }
          return o;
        })(),
        function ($pane) {
          $pane.empty();
          runLoad($pane);
        }
      );
      if (!ok) return;
    } else {
      $("#content_title").text(title || "Home");
      $("#home_dashboard").empty();
      runLoad($("#home_dashboard"));
    }
  }


  /**
   * Legacy insba opener (MainPageNew.js).
   * INPCV2 uses a single content pane (#home_dashboard) instead of CBPFWTabs.
   * After HTML load, CallGetModuleDetailsNew (MainPageNew.js) inits Save + grid via schema API.
   */


  /**
   * Insba main_page.js: LoadHtmlFiles(file_name, module_name, display_name, module_id).
   * Internal / Direct / NEW menus call this. INPCV2 loads into #home_dashboard (no CBPFWTabs).
   */

  /**
   * DeskMobile: pick desktop vs mobile HTML at click time (shared js_path).
   * Falls back to desktop file_name when mobile file is empty.
   */
  /** True when viewport width is mobile-sized (same rule as Common.IsMobile). */
  function inpcIsMobileWidth() {
    var w = window.innerWidth || document.documentElement.clientWidth || 0;
    var max = 767;
    if (typeof Common !== "undefined" && Common.MOBILE_MAX_WIDTH != null) {
      var m = Number(Common.MOBILE_MAX_WIDTH);
      if (isFinite(m) && m > 0) max = m;
    }
    return w <= max;
  }

  /**
   * DeskMobile open from a menu <a> — reads data-file-name / data-mobile-file-name
   * and picks HTML by viewport width (not user-agent).
   */
  window.inpcOpenDeskMobile = function (el) {
    var $a = el && el.nodeType ? $(el) : $(el);
    if (!$a.length && typeof el === "string") $a = $(el);
    var desk = sanitizeModuleFileName($a.attr("data-file-name") || $a.attr("id") || "").replace(/\.html$/i, "");
    var mob = sanitizeModuleFileName($a.attr("data-mobile-file-name") || "").replace(/\.html$/i, "");
    if (!mob && desk && window.$inpc_menu_mobile_by_file) {
      mob = sanitizeModuleFileName(window.$inpc_menu_mobile_by_file[desk] || "").replace(/\.html$/i, "");
    }
    var moduleName = $a.attr("data-module-name") || desk;
    var displayName =
      $a.attr("data-display-name") ||
      $.trim($a.find(".side-menu__label").text() || $a.text()) ||
      desk;
    var internalCode = $a.attr("data-internal-code") || "0";
    var jsPath = $a.attr("data-js-path") || "";
    return window.LoadHtmlFilesForDevice(desk, mob, moduleName, displayName, internalCode, jsPath);
  };

  /**
   * DeskMobile: pick desktop vs mobile HTML by viewport width.
   * Falls back to desktop file_name when mobile file is empty.
   */
  window.LoadHtmlFilesForDevice = function (desktop_file, mobile_file, module_name, display_name, module_id, js_path) {
    var desk = sanitizeModuleFileName(desktop_file || "").replace(/\.html$/i, "");
    var mob = sanitizeModuleFileName(mobile_file || "").replace(/\.html$/i, "");
    if (!mob && desk && window.$inpc_menu_mobile_by_file) {
      mob = sanitizeModuleFileName(window.$inpc_menu_mobile_by_file[desk] || "").replace(/\.html$/i, "");
    }
    var useMobile = inpcIsMobileWidth();
    var file = useMobile && mob ? mob : desk;
    if (!file) file = desk || mob;
    return window.LoadHtmlFiles(file, module_name, display_name, module_id, js_path);
  };
  window.LoadHtmlFiles = function (file_name, module_name, display_name, module_id, js_path) {
    var file = sanitizeModuleFileName(file_name).replace(/\.html$/i, "");
    var title = display_name || module_name || file || "Module";
    if (!file) {
      $("#content_title").text(title);
      $("#home_dashboard").html(
        "<div class='alert alert-warning mb-0'>No file_name configured for this menu.</div>"
      );
      return;
    }
    var jsPath = resolveMenuJsPath(file, js_path);
    var tabKey = file;
    try {
      var homeFile = (typeof window.inpcHomeModuleForUserType === "function")
        ? String(window.inpcHomeModuleForUserType(window.inpcGetLoginUserType && window.inpcGetLoginUserType()) || "").replace(/\.html$/i, "")
        : "";
      if (file === homeFile || file === "home") tabKey = "home";
    } catch (_eTk) { /* ignore */ }
    loadPage(moduleHtmlPath(file), title, jsPath, tabKey);
    if (typeof window.CallAfterManualFiles === "function") {
      try { window.CallAfterManualFiles(file, title); } catch (_e) { /* optional */ }
    }
  };

  /** Clear inpc_loader (and leftover App.blockUI if any). */
  function inpcClearModuleLoader(hostId) {
    try {
      var hid = hostId || (window.InpcTabs && InpcTabs.activeContentId ? InpcTabs.activeContentId() : "home_dashboard");
      if (typeof hideLoader === "function") hideLoader(hid);
    } catch (_e) { /* ignore */ }
    try {
      if (typeof hideLoader === "function") hideLoader();
    } catch (_e2) { /* ignore */ }
    try {
      if (typeof App !== "undefined" && typeof App.unblockUI === "function") App.unblockUI();
    } catch (_e3) { /* ignore */ }
  }

  /** Show INPC loader for FrameWork module open (schema AJAX follows HTML load). */
  function inpcShowModuleLoader(msg, hostId) {
    try {
      var hid = hostId || (window.InpcTabs && InpcTabs.activeContentId ? InpcTabs.activeContentId() : "home_dashboard");
      if (typeof showLoader === "function") {
        showLoader(msg || "Please wait...", hid);
      }
    } catch (_e) { /* ignore */ }
  }

  /**
   * FrameWork opener: load html_files HTML into #home_dashboard, then
   * CallGetModuleDetailsNew (schema/API). Must NOT use Internal LoadHtmlFiles path.
   * Empty js_path is OK (loadMenuJsThen no-ops). Customer Payment Internal+js_path
   * still goes through LoadHtmlFiles only.
   */
  window.getModulesDetailsNew = function (
    system_module_name,
    module_name,
    module_id,
    is_module_for_new_or_edit,
    display_module_name,
    geditinternalcode,
    callback_func
  ) {
    var title = display_module_name || module_name || system_module_name || "Module";
    if (!system_module_name) {
      $("#content_title").text(title);
      (window.InpcTabs ? InpcTabs.$activePane() : $("#home_dashboard")).html(
        "<div class='alert alert-warning mb-0'>No file_name (system module) for this menu.</div>"
      );
      inpcClearModuleLoader();
      return;
    }

    var safeName = sanitizeModuleFileName(system_module_name).replace(/\.html$/i, "");
    if (!safeName) {
      $("#content_title").text(title);
      (window.InpcTabs ? InpcTabs.$activePane() : $("#home_dashboard")).html(
        "<div class='alert alert-danger mb-0'>Invalid file_name (system module) path.</div>"
      );
      inpcClearModuleLoader();
      return;
    }
    var path = moduleHtmlPath(safeName);
    var fwJsPath = resolveMenuJsPath(safeName);

    function afterLoad($pane) {
      var hostId = ($pane && $pane.attr("id")) || "home_dashboard";
      inpcShowModuleLoader("Loading " + title + "...", hostId);
      loadMenuJsThen(fwJsPath, function () {
        $pane.load(path, function (_response, status, xhr) {
          if (status === "error") {
            inpcClearModuleLoader(hostId);
            $pane.html(
              "<div class='alert alert-danger mb-0'>Unable to load <code>" +
                escapeHtml(path) +
                "</code> (HTTP " +
                xhr.status +
                "). Expected under <code>html_files/" +
                escapeHtml(window.$g_app_tye || "") +
                "/</code>.</div>"
            );
            return;
          }
          if (typeof initCommonWidgets === "function") {
            initCommonWidgets($pane[0] || document.getElementById(hostId));
          }
          if (typeof window.CallGetModuleDetailsNew === "function") {
            try {
              window.CallGetModuleDetailsNew(
                system_module_name,
                is_module_for_new_or_edit || "New",
                module_name,
                module_id,
                geditinternalcode || 0,
                "FW",
                function () {
                  inpcClearModuleLoader(hostId);
                  if (typeof callback_func === "function") callback_func();
                }
              );
            } catch (err) {
              inpcClearModuleLoader(hostId);
              throw err;
            }
          } else {
            inpcClearModuleLoader(hostId);
            if (typeof callback_func === "function") callback_func();
          }
        });
      });
    }

    if (window.InpcTabs && typeof InpcTabs.open === "function") {
      var ok = InpcTabs.open((function () {
        var o = { key: safeName, title: title };
        try {
          var ic = (window.INPC_MENU_ICONS && window.INPC_MENU_ICONS[safeName]) || null;
          if (ic) { o.icon = ic.icon; o.iconColor = ic.color; }
        } catch (eIc2) { /* ignore */ }
        return o;
      })(), function ($pane) {
        $pane.empty();
        afterLoad($pane);
      });
      if (!ok) {
        inpcClearModuleLoader();
        return;
      }
    } else {
      $("#content_title").text(title);
      $("#home_dashboard").empty();
      afterLoad($("#home_dashboard"));
    }
  };




/** Safe decodeURIComponent for cust names (cookies may be encoded; never throw). */
  function inpcSafeDecodeURIComponent(s) {
    if (s == null || s === "") return "";
    s = String(s);
    try {
      return decodeURIComponent(s.replace(/\+/g, " "));
    } catch (e) {
      return s;
    }
  }

  /**
   * Customer name / related header title contrast from data-header-styles.
   * Light (or transparent+light theme) → dark text; dark/color/gradient → white.
   */
  function inpcRefreshHeaderTitleColor() {
    try {
      var html = document.documentElement;
      var hs = String(html.getAttribute("data-header-styles") || "light").toLowerCase();
      var tm = String(html.getAttribute("data-theme-mode") || "light").toLowerCase();
      var lightHeader =
        hs === "light" || (hs === "transparent" && tm !== "dark");
      var color = lightHeader ? "#1e293b" : "#ffffff";
      var el = document.getElementById("customer_name_display");
      if (el) {
        el.style.setProperty("color", color, "important");
      }
    } catch (eColor) { /* ignore */ }
  }

  function inpcSetCustomerNameDisplay(name) {
    var decoded = inpcSafeDecodeURIComponent(name);
    if (decoded) {
      $("#customer_name_display").text(decoded);
    }
    inpcRefreshHeaderTitleColor();
    return decoded;
  }


  /** Cookie helpers — prefer shared js/inpc-portal-cookies.js when loaded first. */
  function inpcSetCookie(name, value, days) {
    if (window.__inpcPortalCookiesReady && typeof window.inpcSetCookie === "function" && window.inpcSetCookie !== inpcSetCookie) {
      return window.inpcSetCookie(name, value, days);
    }
    try {
      var maxAge = (days == null ? 30 : days) * 86400;
      document.cookie =
        encodeURIComponent(name) +
        "=" +
        encodeURIComponent(value == null ? "" : String(value)) +
        ";path=/;max-age=" +
        maxAge +
        ";SameSite=Lax";
    } catch (e) { /* ignore */ }
  }

  function inpcClearCookie(name) {
    if (window.__inpcPortalCookiesReady && typeof window.inpcClearCookie === "function" && window.inpcClearCookie !== inpcClearCookie) {
      return window.inpcClearCookie(name);
    }
    try {
      var enc = encodeURIComponent(name);
      var paths = ["/", "/inwebsof", "/inwebsof/", "/INPCV2", "/INPCV2/"];
      try {
        if (window.$app_url) {
          var app = String(window.$app_url);
          paths.push(app);
          paths.push(app.replace(/\/$/, "") || "/");
        }
      } catch (eP) { /* ignore */ }
      for (var i = 0; i < paths.length; i++) {
        document.cookie = enc + "=;path=" + paths[i] + ";max-age=0;SameSite=Lax";
      }
    } catch (e) { /* ignore */ }
  }

  function inpcIsCustomerOverridden() {
    try {
      if (typeof getCookie === "function") {
        return String(getCookie("fw_customer_overridden") || "").trim().toLowerCase() === "yes";
      }
    } catch (eOv) { /* ignore */ }
    return false;
  }


  window.inpcNormalizeUserType = function (t) {
    t = String(t == null ? "" : t).trim();
    if (!t || t.toLowerCase() === "null") return "Customer";
    if (/^customser\s*service$/i.test(t)) return "Customer Service";
    return t;
  };

  function inpcMaybeReloadHomeForUserType() {
    try {
      var want = window.inpcHomeModuleForUserType(window.inpcGetLoginUserType());
      var $home = $("#home");
      var cur = "";
      if ($home.length) {
        cur = String($home.attr("data-file-name") || "").replace(/\.html$/i, "");
      }
      if (cur && want && cur !== want) {
        $home.attr("data-file-name", want + ".html");
        if (typeof loadPage === "function") {
          loadPage(moduleHtmlPath(want), "Home");
        }
      }
    } catch (eRel) { /* ignore */ }
  }
  window.inpcMaybeReloadHomeForUserType = inpcMaybeReloadHomeForUserType;

  window.inpcHomeModuleForUserType = function (t) {
    t = window.inpcNormalizeUserType(t);
    var map = {
      Admin: "home_admin",
      Customer: "home_customer",
      Distributor: "home_distributor",
      "Customer Service": "home_customer_service"
    };
    return map[t] || "home_customer";
  };

  window.inpcGetLoginUserType = function () {
    try {
      if (typeof getCookie === "function") {
        var c = getCookie("fw_login_user_type");
        if (c) return window.inpcNormalizeUserType(c);
      }
    } catch (e) { /* ignore */ }
    try {
      if (window.$inpc_login_user_type) return window.inpcNormalizeUserType(window.$inpc_login_user_type);
    } catch (e2) { /* ignore */ }
    return "Customer";
  };

  function inpcStoreUserCookiesFromMenus(d) {
    if (!d) return;
    /* Always refresh home / visibility cookies from server */
    inpcSetCookie("fw_cust_name", inpcSafeDecodeURIComponent(d.cust_name || ""));
    inpcSetCookie("fw_cust_code", inpcSafeDecodeURIComponent(d.cust_code || ""));
    inpcSetCookie("fw_see_other_cust_data", d.see_other_cust_data || "");
    inpcSetCookie("fw_login_user_type", window.inpcNormalizeUserType(d.loginUserType || ""));
    try { window.$inpc_login_user_type = window.inpcNormalizeUserType(d.loginUserType || ""); } catch (eUt) {}
    /*
     * When user has overridden customer (fw_customer_overridden=Yes), do NOT
     * overwrite fw_override_cust_code / fw_override_cust_name from menus d.cust_*.
     * see_other_cust_data is still stored above for Change Customer menu visibility.
     */
    if (!inpcIsCustomerOverridden()) {
      inpcSetCookie("fw_override_cust_name", inpcSafeDecodeURIComponent(d.cust_name || ""));
      inpcSetCookie("fw_override_cust_code", inpcSafeDecodeURIComponent(d.cust_code || ""));
      inpcSetCookie("fw_override_loginId", d.loginId || "");
    }
    if (d.loginId) {
      inpcSetCookie("fw_loginId", d.loginId);
    }
    if (typeof ChangeCustomer !== "undefined" && ChangeCustomer.ApplyVisibility) {
      ChangeCustomer.ApplyVisibility(d.see_other_cust_data);
    }
    inpcMaybeReloadHomeForUserType();
  }

  function inpcClearUserCookies() {
    if (window.__inpcPortalCookiesReady && typeof window.inpcClearUserCookies === "function" && window.inpcClearUserCookies !== inpcClearUserCookies) {
      return window.inpcClearUserCookies();
    }
    inpcClearCookie("fw_cust_name");
    inpcClearCookie("fw_cust_code");
    inpcClearCookie("fw_loginId");
    inpcClearCookie("fw_override_cust_name");
    inpcClearCookie("fw_override_cust_code");
    inpcClearCookie("fw_override_loginId");
    inpcClearCookie("fw_customer_overridden");
    inpcClearCookie("fw_see_other_cust_data");
    inpcClearCookie("fw_login_user_type");
    inpcClearCookie("cust_name");
    inpcClearCookie("cust_code");
    inpcClearCookie("loginId");
    try {
      var raw = String(document.cookie || "");
      var parts = raw.split(";");
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i].trim();
        if (!p) continue;
        var eq = p.indexOf("=");
        var n = eq >= 0 ? p.substring(0, eq) : p;
        try { n = decodeURIComponent(n); } catch (eN) { /* keep */ }
        if (/^fw_/i.test(n)) inpcClearCookie(n);
      }
    } catch (eSweep) { /* ignore */ }
  }

  /* Expose cookie helpers for ChangeCustomer / other global chrome scripts.
   * Prefer shared js/inpc-portal-cookies.js when already loaded; do not clobber. */
  if (!window.__inpcPortalCookiesReady) {
    window.inpcSetCookie = inpcSetCookie;
  }
  window.inpcSafeDecodeURIComponent = inpcSafeDecodeURIComponent;
  window.inpcRefreshHeaderTitleColor = inpcRefreshHeaderTitleColor;
  window.inpcSetCustomerNameDisplay = inpcSetCustomerNameDisplay;

  /* $host_url / host_url / $app_url are globals from fw-globals.js (loaded by MainPage.html). Never redefine per feature page. */
  if (!window.$host_url) {
    console.warn("MainPage: window.$host_url missing -- ensure fw-globals.js loads before MainPage.js");
  }
  window.host_url = window.host_url || window.$host_url;
  if (!window.$app_url && window.$host_url) {
    window.$app_url = String(window.$host_url).replace(/titpl\/?$/, "");
  }
  if (!window.__inpcPortalCookiesReady) {
    window.inpcClearCookie = inpcClearCookie;
    window.inpcClearUserCookies = inpcClearUserCookies;
  } else {
    /* Keep local names callable; window already has shared clear helpers */
    window.inpcClearUserCookies = window.inpcClearUserCookies || inpcClearUserCookies;
  }
  if (typeof window.inpcClearAllDocumentCookies !== "function") {
    window.inpcClearAllDocumentCookies = function () {
      inpcClearUserCookies();
      try {
        var raw = String(document.cookie || "");
        var parts = raw.split(";");
        for (var i = 0; i < parts.length; i++) {
          var p = parts[i].trim();
          if (!p) continue;
          var eq = p.indexOf("=");
          var n = eq >= 0 ? p.substring(0, eq) : p;
          try { n = decodeURIComponent(n); } catch (eN) {}
          if (n) inpcClearCookie(n);
        }
      } catch (eAll) { /* ignore */ }
    };
  }

  /* Keep #customer_name_display contrast in sync when Switcher changes header theme */
  try {
    inpcRefreshHeaderTitleColor();
    var hdrColorObs = new MutationObserver(function () {
      inpcRefreshHeaderTitleColor();
    });
    hdrColorObs.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["data-header-styles", "data-theme-mode"]
    });
  } catch (eHdrColor) { /* ignore */ }


  window.inpcNormalizeShowWelcome = function (v) {
    return /^yes$/i.test(String(v == null ? "" : v).trim()) ? "Yes" : "No";
  };

  /**
   * Blocking welcome modal when menus returns welcome_msg (html_body).
   * Match is server-side: welcome_msg_module from_date/to_date + w_user_type.
   * Base modal stays on MainPage. OK only; no Esc / no backdrop click.
   */
  function inpcBindWelcomeLock(el) {
    if (!el || el.getAttribute("data-ack-bound") === "Yes") return;
    el.setAttribute("data-ack-bound", "Yes");
    el.addEventListener("hide.bs.modal", function (event) {
      if (el.getAttribute("data-ack-lock") === "Yes") event.preventDefault();
    });
  }

  function inpcWelcomeAckRequired(d) {
    return /^yes$/i.test(String(d && d.ack_required != null ? d.ack_required : "").trim());
  }

  function inpcWelcomeAlreadyAcked(d) {
    return /^yes$/i.test(String(d && d.already_acknowledged != null ? d.already_acknowledged : "").trim());
  }

  function inpcWelcomeAckLabel(d) {
    var msg = d && d.ack_message != null ? String(d.ack_message).trim() : "";
    if (!msg || msg.toLowerCase() === "null") return "I acknowledge";
    return msg;
  }

  function inpcPrepareWelcomeAck(required, label, alreadyAcked, ackOn) {
    var $row = $("#inpc_welcome_ack_row");
    if (!$row.length) {
      $("#inpc_welcome_modal .modal-footer").prepend(
        '<div class="form-check me-auto mb-0" id="inpc_welcome_ack_row">' +
          '<input class="form-check-input" type="checkbox" id="inpc_welcome_ack_check">' +
          '<label class="form-check-label" for="inpc_welcome_ack_check">I acknowledge</label>' +
        "</div>"
      );
      $row = $("#inpc_welcome_ack_row");
    }
    var $note = $("#inpc_welcome_ack_done");
    if (!$note.length) {
      $("#inpc_welcome_modal .modal-footer").prepend(
        '<div class="me-auto mb-0 small text-muted d-none" id="inpc_welcome_ack_done"></div>'
      );
      $note = $("#inpc_welcome_ack_done");
    }
    $row.find("label").text(label || "I acknowledge");
    $("#inpc_welcome_ack_check").prop("checked", false);
    var $btn = $("#inpc_welcome_ok_btn");
    if (alreadyAcked) {
      $row.addClass("d-none");
      var when = ackOn ? String(ackOn).trim() : "";
      $note.text(when && when.toLowerCase() !== "null"
        ? "You have acknowledged on " + when + "."
        : "You have acknowledged.").removeClass("d-none");
      $btn.text("OK").prop("disabled", false);
      return;
    }
    $note.addClass("d-none").text("");
    $row.toggleClass("d-none", !required);
    $btn.text(required ? "Submit" : "OK").prop("disabled", !!required);
    $("#inpc_welcome_ack_check").off("change.inpcWelcome").on("change.inpcWelcome", function () {
      $btn.prop("disabled", required && !this.checked);
    });
  }

  function inpcMaybeShowWelcome(d) {
    try {
      if (window.__inpcWelcomeShownThisPage) return;
      var html = d && d.welcome_msg != null ? String(d.welcome_msg).trim() : "";
      if (!html || html.toLowerCase() === "null") return;
      var el = document.getElementById("inpc_welcome_modal");
      if (!el || typeof bootstrap === "undefined" || !bootstrap.Modal) return;
      window.__inpcWelcomeShownThisPage = true;
      var title = d && d.welcome_title != null ? String(d.welcome_title).trim() : "";
      if (!title || title.toLowerCase() === "null") title = "Welcome";
      var alreadyAcked = inpcWelcomeAlreadyAcked(d);
      var ackRequired = inpcWelcomeAckRequired(d) && !alreadyAcked;
      var ackOn = d && d.acknowledged_on != null ? String(d.acknowledged_on).trim() : "";
      $("#inpc_welcome_modal_title").text(title);
      $("#inpc_welcome_modal_body").html(html);
      inpcBindWelcomeLock(el);
      inpcPrepareWelcomeAck(ackRequired, inpcWelcomeAckLabel(d), alreadyAcked, ackOn);
      el.setAttribute("data-ack-lock", ackRequired ? "Yes" : "No");
      var modal = bootstrap.Modal.getOrCreateInstance(el, { backdrop: "static", keyboard: false });
      $("#inpc_welcome_ok_btn")
        .off("click.inpcWelcome")
        .on("click.inpcWelcome", function () {
          if (!ackRequired) {
            el.setAttribute("data-ack-lock", "No");
            try { modal.hide(); } catch (eHide) { /* ignore */ }
            return;
          }
          if (!$("#inpc_welcome_ack_check").prop("checked")) return;
          var welcomeId = d && d.welcome_internal_code != null ? String(d.welcome_internal_code) : "";
          var $btn = $(this);
          $btn.prop("disabled", true);
          if (!window.Common || !Common.AcknowledgeWelcome) {
            $btn.prop("disabled", false);
            return;
          }
          Common.AcknowledgeWelcome(welcomeId, function () {
            el.setAttribute("data-ack-lock", "No");
            try { modal.hide(); } catch (eHide) { /* ignore */ }
          }, function (message) {
            $btn.prop("disabled", false);
            if (typeof ShowAlertMsg === "function") ShowAlertMsg(message);
          });
        });
      try { modal.show(); } catch (eShow) { /* ignore */ }
    } catch (eWelcome) { /* ignore */ }
  }

  function loadMenus() {
    return $.ajax({
      url: "api/auth/menus",
      method: "GET",
      dataType: "json",
      xhrFields: { withCredentials: true },
    })
      .done(function (json) {
        if (!json || json.errorCode !== 0) {
          $("#side-menu").html(
            "<li class='slide'><a class='side-menu__item' href='login.html'>" +
              "<span class='side-menu__label'>" +
              escapeHtml((json && json.message) || "Please login") +
              "</span></a></li>"
          );
    inpcFixSubmenuColors();
          setTimeout(function () {
            if (typeof window.inpcIsSessionExpiredPayload === "function" && window.inpcIsSessionExpiredPayload(json)) {
              window.inpcHandleSessionExpired(json && json.message);
            } else if (!json || json.errorCode === -1) {
              /* non-session failure: still send local users to login */
              window.location.href = "login.html";
            }
          }, 800);
          return;
        }
        var d = json.data || {};
        inpcStoreUserCookiesFromMenus(d);
        $("#login_user_name_display").text(d.loginId || "");
        $("#fw_real_name").text(d.loginUserName || "");
        var userType = window.inpcNormalizeUserType(d.loginUserType || "");
        var showCustomerCode = /^(customer|vendor)$/i.test(userType);
        var customerCode = inpcSafeDecodeURIComponent(d.cust_code || "");
        $("#profile_customer_code").text(customerCode);
        $("#profile_customer_code_item").toggleClass("d-none", !showCustomerCode || !customerCode);
        /* Prefer override cookies when fw_customer_overridden=Yes; else menus cust_name (decoded) */
        if (typeof ChangeCustomer !== "undefined" && ChangeCustomer.RefreshHeaderDisplay) {
          ChangeCustomer.RefreshHeaderDisplay(inpcSafeDecodeURIComponent(d.cust_name || d.customerName || "R.K Traders"));
        } else if (inpcIsCustomerOverridden() && typeof getCookie === "function") {
          var ovName = inpcSafeDecodeURIComponent(getCookie("fw_override_cust_name") || getCookie("fw_override_cust_code") || "");
          inpcSetCustomerNameDisplay(ovName || d.cust_name || d.customerName || "R.K Traders");
        } else {
          inpcSetCustomerNameDisplay(d.cust_name || d.customerName || "R.K Traders");
        }
        if (d.appType) {
          window.$g_app_tye = d.appType;
        }
        /* portal.extras.include-tabs → window.INPC_INCLUDE_TABS (false = classic single page) */
        try {
          var ex = d.extras || {};
          if (ex["include-tabs"] != null || ex.include_tabs != null || ex.includeTabs != null) {
            var raw = ex["include-tabs"] != null ? ex["include-tabs"] : (ex.include_tabs != null ? ex.include_tabs : ex.includeTabs);
            window.INPC_INCLUDE_TABS = raw;
            if (window.InpcTabs && InpcTabs.setFlag) InpcTabs.setFlag(raw);
            if (window.InpcTabs && InpcTabs.syncSwitcherTabStyles) InpcTabs.syncSwitcherTabStyles();
          }
          if (ex["tab-style"] != null || ex.tab_style != null || ex.tabStyle != null) {
            var ts = ex["tab-style"] != null ? ex["tab-style"] : (ex.tab_style != null ? ex.tab_style : ex.tabStyle);
            window.INPC_TAB_STYLE = ts;
            if (window.InpcTabs && InpcTabs.setTabStyle) InpcTabs.setTabStyle(ts);
          }
          if (ex["tab-icons"] != null || ex.tab_icons != null || ex.tabIcons != null) {
            var ti = ex["tab-icons"] != null ? ex["tab-icons"] : (ex.tab_icons != null ? ex.tab_icons : ex.tabIcons);
            window.INPC_TAB_ICONS = ti;
            if (window.InpcTabs && InpcTabs.setTabIcons) InpcTabs.setTabIcons(ti);
          }
        } catch (_eTabs) { /* ignore */ }

        $("#side-menu").html(buildSideMenuHtml(d.menus || []));
        try {
          if (window.InpcTabs && InpcTabs.setTabIcons) InpcTabs.setTabIcons(window.INPC_TAB_ICONS);
        } catch (_eRefreshIcons) { /* ignore */ }
    inpcFixSubmenuColors();
        bindMenuClicks();
        $("#side-menu a.side-menu__item[a_c_system_name='home']").addClass("active");
        if (typeof inpcNormalizeMenuHoverLabels === "function") inpcNormalizeMenuHoverLabels();
        inpcMaybeShowWelcome(d);
        if (typeof Common !== "undefined" && Common.FillAnnouncementsData) {
          Common.FillAnnouncementsData();
        }
        // Do not force data-toggled -- hamburger must control open/close.
        // defaultmenu.min.js is loaded once by MainPage.html; custom delegated clicks handle AJAX menus.
      })
      .fail(function (xhr) {
        $("#side-menu").html(
          "<li class='slide'><a class='side-menu__item' href='login.html'>" +
            "<span class='side-menu__label'>Menu load failed (" +
            xhr.status +
            ")</span></a></li>"
        );
    inpcFixSubmenuColors();
      });
  }

  /**
   * Leaf click -- same call shape as insba menu onclick:
   * getModulesDetailsNew(file_name, module_name, internal_code, 'New', display_name, 0)
   */
  window.onMenuClick = function (el) {
    var $a = $(el);
    var fileName = sanitizeModuleFileName($a.attr("data-file-name") || $a.attr("id") || "").replace(/\.html$/i, "");
    var moduleName = $a.attr("data-module-name") || fileName;
    var internalCode = $a.attr("data-internal-code") || "0";
    var displayName =
      $a.attr("data-display-name") ||
      $.trim($a.find(".side-menu__label").text() || $a.text());
    var menuType = String($a.attr("data-menu-type") || "").toLowerCase();
    var loadType = $a.attr("data-load-type") || "Internal";
    var jsPath = $a.attr("data-js-path") || "";
    var mobileFileName = sanitizeModuleFileName($a.attr("data-mobile-file-name") || "").replace(/\.html$/i, "");

    $("#side-menu a.side-menu__item").removeClass("active");
    $a.addClass("active");

    // DeskMobile -- pick desktop vs mobile HTML at click time
    if (normalizeLoadType(loadType) === "deskmobile") {
      if (!fileName && !mobileFileName) {
        $("#content_title").text(displayName || "Module");
        $("#home_dashboard").html(
          "<div class='alert alert-warning mb-0'>No file_name / mobile_file_name configured for this menu.</div>"
        );
        return;
      }
      return window.inpcOpenDeskMobile($a[0] || $a);
      return;
    }

    // Direct menu group OR Load Type = Internal -- only load HTML from html_files/{app}/file_name.html
    if (menuType === "direct" || isPlainHtmlLoadType(loadType)) {
      if (!fileName) {
        $("#content_title").text(displayName || "Module");
        $("#home_dashboard").html(
          "<div class='alert alert-warning mb-0'>No file_name configured for this menu.</div>"
        );
        return;
      }
      window.LoadHtmlFiles(fileName, moduleName, displayName || fileName, internalCode, jsPath);
      return;
    }

    // Load Type = FrameWork -- legacy FW open path
    if (isFrameworkLoadType(loadType)) {
      window.getModulesDetailsNew(
        fileName,
        moduleName,
        internalCode,
        "New",
        displayName,
        0
      );
      return;
    }

    // Other load types (Application / External / COMINGSOON / NEW): still try HTML if file present
    var lt = normalizeLoadType(loadType);
    if (lt === "comingsoon") {
      $("#content_title").text(displayName || "Coming soon");
      $("#home_dashboard").html(
        "<div class='alert alert-info mb-0'>This module is marked Coming Soon.</div>"
      );
      return;
    }
    if (lt === "external" && fileName && /^(https?:)?\/\//i.test(fileName)) {
      window.open(fileName, "_blank");
      return;
    }
    if (fileName) {
      window.LoadHtmlFiles(fileName, moduleName, displayName || fileName, internalCode, jsPath);
      return;
    }
    $("#content_title").text(displayName || "Module");
    $("#home_dashboard").html(
      "<div class='alert alert-warning mb-0'>Unsupported load_type: " +
        $("<div/>").text(loadType).html() +
        "</div>"
    );
  };


  /** INPC: after refresh/theme restore, Menu Hover must not stay in overlay icon-only mode. */
  function inpcNormalizeMenuHoverLabels() {
    var html = document.documentElement;
    if (typeof window.inpcIsMobileNav === "function" && window.inpcIsMobileNav()) {
      if (typeof window.inpcForceMobileVertical === "function") window.inpcForceMobileVertical();
      return;
    }
    var ns = (html.getAttribute("data-nav-style") || "").toLowerCase();
    var layout = (html.getAttribute("data-nav-layout") || "").toLowerCase();
    var tog = (html.getAttribute("data-toggled") || "").toLowerCase();
    if (ns !== "menu-hover" && ns !== "menu-click") return;
    // Nav styles own the chrome -- drop leftover Default/Icon Overlay attrs.
    html.removeAttribute("data-vertical-style");
    if (tog === "icon-overlay-close" || tog === "icon-text-close" || tog === "close-menu-close") {
      html.setAttribute("data-toggled", "open");
    }
    if (layout === "horizontal" && (tog === "menu-hover-closed" || tog === "menu-click-closed")) {
      html.setAttribute("data-toggled", "open");
    }
  }
  window.inpcNormalizeMenuHoverLabels = inpcNormalizeMenuHoverLabels;
  window.dropMenu = dropMenu;

  /* INPC_CLEAR_ON_INDEX: clear portal cookies when navigating MainPage -> index/login/context root.
   * Browser Back is covered by clear-on-arrival in index.html / login.html (inpc-portal-cookies.js). */
  (function inpcWireClearOnLeaveToIndex() {
    function clearForIndexNav() {
      try {
        if (typeof window.inpcClearAllDocumentCookies === "function") {
          window.inpcClearAllDocumentCookies();
        } else {
          inpcClearUserCookies();
        }
      } catch (eClr) { /* ignore */ }
    }
    function isIndexTarget(href) {
      if (typeof window.inpcIsIndexOrLoginTarget === "function") {
        return window.inpcIsIndexOrLoginTarget(href);
      }
      var s = String(href || "").toLowerCase();
      return s.indexOf("index.html") >= 0 || s.indexOf("login.html") >= 0;
    }
    document.addEventListener(
      "click",
      function (ev) {
        var t = ev.target;
        while (t && t !== document && (!t.tagName || t.tagName !== "A")) {
          t = t.parentNode;
        }
        if (!t || t.tagName !== "A") return;
        var href = t.getAttribute("href");
        if (isIndexTarget(href)) clearForIndexNav();
      },
      true
    );
  })();

  window.logout = function () {
    try {
      if (typeof window.inpcClearAllDocumentCookies === "function") {
        window.inpcClearAllDocumentCookies();
      } else {
        inpcClearUserCookies();
      }
    } catch (eLogoutClr) {
      inpcClearUserCookies();
    }
    $.ajax({
      url: "api/auth/logout",
      method: "POST",
      xhrFields: { withCredentials: true },
    }).always(function () {
      window.location.href = "login.html";
    });
  };

    window.loadMasters = function () {
    loadSwitcher();
    /* Menus first so portal.extras.include-tabs is applied before Home opens. */
    var menusPromise = loadMenus();
    function openHome() {
      loadPage(moduleHtmlPath(window.inpcHomeModuleForUserType(window.inpcGetLoginUserType())), "Home", null, "home");
    }
    if (menusPromise && typeof menusPromise.always === "function") {
      menusPromise.always(openHome);
    } else {
      openHome();
    }
  };

$(function () {
    bindMenuClicks();
    loadMasters();
    inpcNormalizeMenuHoverLabels();
    setTimeout(inpcNormalizeMenuHoverLabels, 350);
    setTimeout(inpcNormalizeMenuHoverLabels, 1200);

    // When Switcher changes Menu Click <-> Menu Hover (or vertical style), reset menu DOM.
    try {
      var htmlEl = document.documentElement;
      var obs = new MutationObserver(function (mutations) {
        for (var i = 0; i < mutations.length; i++) {
          var a = mutations[i].attributeName || "";
          if (a === "data-nav-style" || a === "data-vertical-style" || a === "data-nav-layout") {
            onNavStyleChanged();
            break;
          }
        }
      });
      obs.observe(htmlEl, { attributes: true, attributeFilter: ["data-nav-style", "data-vertical-style", "data-nav-layout"] });
    } catch (err) { /* ignore */ }

    $(document).on("click.inpcNavStyle", "#switcher-menu-hover, #switcher-menu-click, #switcher-icon-hover, #switcher-icon-click", function () {
      setTimeout(onNavStyleChanged, 50);
    });
  });
})(jQuery);


/* Keep flyout labels readable if theme switcher sets menu-styles=dark */
function inpcFixSubmenuColors() {
  try {
    var styleId = "inpc-submenu-color-fix";
    if (!document.getElementById(styleId)) {
      var s = document.createElement("style");
      s.id = styleId;
      s.textContent =
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu .side-menu__label," +
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu .side-menu__item," +
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu .side-menu__angle," +
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu li.side-menu__label1 a," +
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu .side-menu__label1," +
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu .side-menu__label1 a" +
        "{color:#1e293b !important;-webkit-text-fill-color:#1e293b !important;opacity:1 !important;visibility:visible !important;}" +
        "html[data-theme-mode='dark'][data-nav-layout='horizontal'] .app-sidebar .slide-menu," +
        "html[data-theme-mode='dark'][data-nav-layout='horizontal'] .app-sidebar ul.slide-menu.child1," +
        "html[data-theme-mode='dark'][data-nav-layout='horizontal'] .app-sidebar ul.slide-menu.child2," +
        "html[data-theme-mode='dark'][data-nav-layout='horizontal'] .app-sidebar ul.slide-menu.child3" +
        "{background:#2c2b31 !important;background-color:#2c2b31 !important;background-image:none !important;color:rgba(255,255,255,.88) !important;border:1px solid rgba(255,255,255,.12) !important;}" +
        "html[data-theme-mode='dark'][data-nav-layout='vertical'] .app-sidebar .slide-menu," +
        "html[data-theme-mode='dark'][data-nav-layout='vertical'] .app-sidebar ul.slide-menu.child1," +
        "html[data-theme-mode='dark'][data-nav-layout='vertical'] .app-sidebar ul.slide-menu.child2," +
        "html[data-theme-mode='dark'][data-nav-layout='vertical'] .app-sidebar ul.slide-menu.child3" +
        "{background:transparent !important;background-color:transparent !important;background-image:none !important;border:0 !important;box-shadow:none !important;color:rgba(255,255,255,.88) !important;}" +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__label," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__item," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__angle," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__icon," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu li.side-menu__label1 a" +
        "{color:rgba(255,255,255,.72) !important;-webkit-text-fill-color:rgba(255,255,255,.72) !important;opacity:1 !important;visibility:visible !important;}" +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__item:hover," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__item:hover .side-menu__label," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__item:hover .side-menu__icon," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__item.active," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__item.active .side-menu__label," +
        "html[data-theme-mode='dark'] .app-sidebar .slide-menu .side-menu__item.active .side-menu__icon" +
        "{color:#93c5fd !important;-webkit-text-fill-color:#93c5fd !important;background-color:rgba(255,255,255,.08) !important;}" +
        "html[data-nav-style='icon-hover'][data-toggled='icon-hover-closed'] .app-sidebar .slide-menu .side-menu__label," +
        "html[data-nav-style='icon-click'][data-toggled='icon-click-closed'] .app-sidebar .slide-menu .side-menu__label," +
        "html[data-nav-style='menu-click'][data-toggled='menu-click-closed'] .app-sidebar .slide-menu .side-menu__label," +
        "html[data-nav-style='menu-hover'][data-toggled='menu-hover-closed'] .app-sidebar .slide-menu .side-menu__label," +
        "html[data-vertical-style='doublemenu'] .app-sidebar .slide-menu .side-menu__label" +
        "{display:inline !important;font-size:.8125rem !important;font-weight:500 !important;}" +
        "html[data-vertical-style='doublemenu'] .app-sidebar .slide-menu .side-menu__angle," +
        "html[data-nav-style='icon-hover'][data-toggled='icon-hover-closed'] .app-sidebar .slide-menu .side-menu__angle" +
        "{display:block !important;}" +
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu .side-menu__item:hover .side-menu__label," +
        "html:not([data-theme-mode='dark']) .app-sidebar .slide-menu .side-menu__item.active .side-menu__label" +
        "{color:#0b5fff !important;-webkit-text-fill-color:#0b5fff !important;}";
      document.head.appendChild(s);
    }
  } catch (e) {}
}


/* Mega panel layout: multi sections = side-by-side full width; single = fixed under parent. */
window.inpcApplyMegaPanelLayout = function (slide, childMenu) {
  try {
    if (!slide || !childMenu) return;
    var html = document.documentElement;
    if ((html.getAttribute("data-nav-layout") || "") !== "horizontal") return;
    if ((html.getAttribute("data-horizontal-submenu") || "") !== "mega") return;

    var hasSubCount = 0;
    var leafCount = 0;
    Array.prototype.forEach.call(childMenu.children, function (el) {
      if (!el.classList || !el.classList.contains("slide") || el.classList.contains("side-menu__label1")) return;
      if (el.classList.contains("has-sub")) hasSubCount += 1;
      else leafCount += 1;
    });

    var single = hasSubCount === 0 || (hasSubCount === 1 && leafCount === 0);
    slide.classList.toggle("mega-compact-parent", single);
    childMenu.classList.toggle("mega-single-column", single);
    childMenu.classList.remove("mega-single-column-end");

    if (single) {
      var anchor = slide.querySelector(":scope > .side-menu__item") || slide;
      var rect = anchor.getBoundingClientRect();
      var minWidth = Math.max(rect.width, 224);
      var left = rect.left;
      var top = rect.bottom;
      if (left + minWidth > window.innerWidth - 8) {
        left = Math.max(8, window.innerWidth - minWidth - 8);
        childMenu.classList.add("mega-single-column-end");
      }
      childMenu.style.setProperty("position", "fixed", "important");
      childMenu.style.setProperty("top", top + "px", "important");
      childMenu.style.setProperty("left", left + "px", "important");
      childMenu.style.setProperty("right", "auto", "important");
      childMenu.style.setProperty("width", "max-content", "important");
      childMenu.style.setProperty("min-width", minWidth + "px", "important");
      childMenu.style.setProperty("max-width", "22rem", "important");
      childMenu.style.setProperty("flex-direction", "column", "important");
      childMenu.style.setProperty("flex-wrap", "nowrap", "important");
    } else {
      childMenu.style.removeProperty("left");
      childMenu.style.removeProperty("right");
      childMenu.style.removeProperty("top");
      childMenu.style.removeProperty("width");
      childMenu.style.removeProperty("min-width");
      childMenu.style.removeProperty("max-width");
      childMenu.style.setProperty("position", "fixed", "important");
      childMenu.style.setProperty("left", "0", "important");
      childMenu.style.setProperty("right", "0", "important");
      childMenu.style.setProperty("top", "calc(5rem + 3px)", "important");
      childMenu.style.setProperty("width", "100%", "important");
      childMenu.style.setProperty("min-width", "100%", "important");
      childMenu.style.setProperty("max-width", "100%", "important");
      childMenu.style.setProperty("display", "flex", "important");
      childMenu.style.setProperty("flex-direction", "row", "important");
      childMenu.style.setProperty("flex-wrap", "nowrap", "important");
      childMenu.style.setProperty("align-items", "flex-start", "important");
    }
  } catch (e) { /* ignore */ }
};

/* Account Status tabs - must live here because jQuery .load() may strip fragment scripts. */
window.asActivateTab = function (btn) {
  try {
    var _sy = window.scrollY || window.pageYOffset || 0;
    var root = (btn && btn.closest) ? btn.closest("#account_status") : document.getElementById("account_status");
    if (!root) return false;
    var key = btn.getAttribute("data-as-tab");
    if (!key) return false;
    var tabs = root.querySelectorAll("#asTabs .nav-link");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.remove("active");
      tabs[i].setAttribute("aria-selected", "false");
    }
    btn.classList.add("active");
    btn.setAttribute("aria-selected", "true");
    var panels = root.querySelectorAll(".as-panel");
    for (var p = 0; p < panels.length; p++) {
      panels[p].classList.remove("active");
    }
    var panel = root.querySelector("#as_panel_" + key);
    if (panel) panel.classList.add("active");
    try { window.scrollTo(0, _sy); } catch (_e) {}
  } catch (err) { /* ignore */ }
  return false;
};

/* Account Status option 1/2 tabs - same reason: fragment scripts are stripped by jQuery .html()/.load(). */
window.as1ActivateTab = function (btn) {
  try {
    var root = (btn && btn.closest) ? btn.closest("#account_status_1") : document.getElementById("account_status_1");
    if (!root) return false;
    var key = btn.getAttribute("data-as1-tab");
    if (!key) return false;
    var tabs = root.querySelectorAll("#as1Tabs .nav-link");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.remove("active");
      tabs[i].setAttribute("aria-selected", "false");
    }
    btn.classList.add("active");
    btn.setAttribute("aria-selected", "true");
    var panels = root.querySelectorAll(".as1-panel");
    for (var p = 0; p < panels.length; p++) panels[p].classList.remove("active");
    var panel = root.querySelector("#as1_panel_" + key);
    if (panel) panel.classList.add("active");
  } catch (err) { /* ignore */ }
  return false;
};

window.as2ActivateTab = function (btn) {
  try {
    var root = (btn && btn.closest) ? btn.closest("#account_status_2") : document.getElementById("account_status_2");
    if (!root) return false;
    var key = btn.getAttribute("data-as2-tab");
    if (!key) return false;
    var tabs = root.querySelectorAll("#as2Tabs [data-as2-tab]");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.remove("active");
      tabs[i].setAttribute("aria-selected", "false");
    }
    btn.classList.add("active");
    btn.setAttribute("aria-selected", "true");
    var panels = root.querySelectorAll(".as2-panel");
    for (var p = 0; p < panels.length; p++) panels[p].classList.remove("active");
    var panel = root.querySelector("#as2_panel_" + key);
    if (panel) panel.classList.add("active");
  } catch (err) { /* ignore */ }
  return false;
};

window.AccountStatus1 = window.AccountStatus1 || {
  getPaidInvoices: function () { return false; },
  getPaymentHistory: function () { return false; }
};
window.AccountStatus2 = window.AccountStatus2 || {
  onAction: function () { return false; }
};

/* 3M Information tabs - live here because jQuery .load() may strip fragment scripts. */
window.i3ActivateTab = function (btn) {
  try {
    var root = (btn && btn.closest) ? btn.closest("#info_3m") : document.getElementById("info_3m");
    if (!root) return false;
    var key = btn.getAttribute("data-i3-tab");
    if (!key) return false;
    var tabs = root.querySelectorAll("#i3Tabs .i3-tab");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.remove("active");
      tabs[i].setAttribute("aria-selected", "false");
    }
    btn.classList.add("active");
    btn.setAttribute("aria-selected", "true");
    var panels = root.querySelectorAll(".i3-panel");
    for (var p = 0; p < panels.length; p++) panels[p].classList.remove("active");
    var panel = root.querySelector("#i3_panel_" + key);
    if (panel) panel.classList.add("active");
  } catch (err) { /* ignore */ }
  return false;
};

/* Reliable vertical sidebar hamburger: own open/collapse so theme absolute-overlay modes cannot cover the page. */
(function () {
  function sidebarGutter(html) {
    var vs = (html.getAttribute("data-vertical-style") || "overlay").toLowerCase();
    var tog = (html.getAttribute("data-toggled") || "").toLowerCase();
    // Icon Overlay closed: slim icon rail (~5rem) -- match theme closed width
    if (vs === "overlay" && tog === "icon-overlay-close") return "5rem";
    if (vs === "doublemenu") {
      if (tog === "double-menu-close") return "5rem";
      return "17rem";
    }
    if (vs === "icontext") return "9rem";
    if (vs === "detached") return "15rem";
    return "15rem";
  }

  function applySidebarLayout(html) {
    var collapsed = html.getAttribute("data-inpc-sidebar") === "collapsed";
    var gutter = sidebarGutter(html);
    var next = collapsed ? "0px" : gutter;
    // Only update CSS var -- never re-set data-inpc-sidebar here.
    // setAttribute (even same value) retriggers gutObs and freezes the UI.
    if (html.style.getPropertyValue("--inpc-sidebar-gutter") !== next) {
      html.style.setProperty("--inpc-sidebar-gutter", next);
    }
  }

  function toggleVerticalSidebar(e) {
    var btn = e.target && e.target.closest ? e.target.closest(".sidemenu-toggle") : null;
    if (!btn) return;
    var html = document.documentElement;
    var mobile = typeof window.inpcIsMobileNav === "function"
      ? window.inpcIsMobileNav()
      : (window.matchMedia ? window.matchMedia("(max-width: 991.98px)").matches : window.innerWidth < 992);
    // Mobile must always behave as vertical overlay (open/close), even if Switcher left horizontal attrs.
    if (mobile) {
      if (typeof window.inpcForceMobileVertical === "function") window.inpcForceMobileVertical();
      e.preventDefault();
      e.stopPropagation();
      if (typeof e.stopImmediatePropagation === "function") e.stopImmediatePropagation();
      if ((html.getAttribute("data-toggled") || "").toLowerCase() === "close") {
        html.setAttribute("data-toggled", "open");
        var ov = document.getElementById("responsive-overlay");
        if (!ov) {
          ov = document.createElement("div");
          ov.id = "responsive-overlay";
          document.body.appendChild(ov);
          ov.addEventListener("click", function () {
            ov.classList.remove("active");
            html.setAttribute("data-toggled", "close");
          });
        }
        setTimeout(function () { ov.classList.add("active"); }, 30);
      } else {
        html.setAttribute("data-toggled", "close");
        var ov2 = document.getElementById("responsive-overlay");
        if (ov2) ov2.classList.remove("active");
      }
      return;
    }
    if ((html.getAttribute("data-nav-layout") || "") !== "vertical") return;
    e.preventDefault();
    e.stopPropagation();
    if (typeof e.stopImmediatePropagation === "function") e.stopImmediatePropagation();

    if (html.getAttribute("data-inpc-sidebar") === "collapsed") {
      html.removeAttribute("data-inpc-sidebar");
    } else {
      html.setAttribute("data-inpc-sidebar", "collapsed");
    }
    applySidebarLayout(html);
    try { window.dispatchEvent(new Event("resize")); } catch (err) {}
  }

  // Keep gutter correct when Switcher changes sidemenu layout
  function syncGutterFromSwitcher() {
    applySidebarLayout(document.documentElement);
  }

  window.inpcBindVerticalSidebarToggle = function () {
    document.removeEventListener("click", toggleVerticalSidebar, true);
    document.addEventListener("click", toggleVerticalSidebar, true);
    syncGutterFromSwitcher();
  };
  window.inpcSyncSidebarGutter = syncGutterFromSwitcher;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", window.inpcBindVerticalSidebarToggle);
  } else {
    window.inpcBindVerticalSidebarToggle();
  }

  // Re-sync after switcher clicks (Default / Icon Overlay / nav styles / etc.)
  document.addEventListener(
    "click",
    function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      if (t.closest("#switcher-default-menu, #switcher-icontext-menu, #switcher-icon-overlay, #switcher-double-menu, #switcher-detached, #switcher-closed-menu, #switcher-menu-click, #switcher-menu-hover, #switcher-icon-click, #switcher-icon-hover")) {
        setTimeout(syncGutterFromSwitcher, 30);
        setTimeout(syncGutterFromSwitcher, 200);
      }
    },
    false
  );

  // Keep gutter in sync when theme flips data-toggled (e.g. Icon Overlay closed rail)
  try {
    var htmlEl = document.documentElement;
    var gutSyncing = false;
    var gutObs = new MutationObserver(function () {
      if (gutSyncing || window.__inpcSuppressMenuCollapse) return;
      gutSyncing = true;
      try {
        syncGutterFromSwitcher();
      } finally {
        gutSyncing = false;
      }
    });
    gutObs.observe(htmlEl, {
      attributes: true,
      attributeFilter: ["data-toggled", "data-vertical-style", "data-inpc-sidebar"]
    });
  } catch (eObs) { /* ignore */ }
})();

window.i3ApplyRailState = function (layout, state) {
  if (!layout) return;
  var wrap = layout.querySelector(".i3-rail-wrap");
  layout.classList.remove("is-rail-hidden", "is-rail-collapsed");
  if (state === "collapsed") {
    layout.classList.add("is-rail-collapsed");
    layout.style.gridTemplateColumns = "2.75rem minmax(0,1fr)";
    layout.style.gap = "";
    if (wrap) {
      wrap.style.display = "";
      wrap.style.width = "";
      wrap.style.minWidth = "";
    }
  } else if (state === "hidden") {
    layout.classList.add("is-rail-hidden");
    layout.style.gridTemplateColumns = "minmax(0,1fr)";
    layout.style.gap = "0";
    if (wrap) {
      wrap.style.display = "none";
      wrap.style.width = "0";
      wrap.style.minWidth = "0";
    }
  } else {
    layout.style.gridTemplateColumns = "";
    layout.style.gap = "";
    if (wrap) {
      wrap.style.display = "";
      wrap.style.width = "";
      wrap.style.minWidth = "";
    }
  }
};
window.i3ToggleRail = function (forceShow, evt) {
  try {
    if (evt && evt.stopPropagation) evt.stopPropagation();
    var layout = document.getElementById("i3_layout");
    if (!layout) return false;
    if (forceShow === true || forceShow === 2) {
      window.i3ApplyRailState(layout, "expanded");
      return false;
    }
    if (layout.classList.contains("is-rail-hidden")) {
      window.i3ApplyRailState(layout, "expanded");
    } else if (layout.classList.contains("is-rail-collapsed")) {
      window.i3ApplyRailState(layout, "hidden");
    } else {
      window.i3ApplyRailState(layout, "collapsed");
    }
  } catch (e) {}
  return false;
};



/* Guard theme hover helpers -- a missing child <ul> must not throw and freeze the UI. */
(function () {
  function safeWrap(name) {
    try {
      var fn = window[name];
      if (typeof fn !== "function" || fn.__inpcSafe) return;
      var wrapped = function (event) {
        try {
          var el = event && event.currentTarget;
          if (!el || !el.querySelector || !el.querySelector("ul")) return;
          return fn.apply(this, arguments);
        } catch (err) {
          console.warn(name + " skipped:", err);
        }
      };
      wrapped.__inpcSafe = true;
      window[name] = wrapped;
    } catch (e) { /* ignore */ }
  }
  function apply() {
    safeWrap("HoverToggleInnerMenuFn");
    safeWrap("HoverToggleInnerMenuRemoveForceFn");
    safeWrap("HoverToggleInnerMenu");
    safeWrap("HoverToggleInnerMenuRemoveForce");
  }
  apply();
  setTimeout(apply, 500);
  setTimeout(apply, 2000);
})();

/* INPC_STRIP_DETACHED_CLOSED_ICONTEXT_DOUBLE: removed Switcher options -- migrate old choice to Default Menu */
(function () {
  function clearBadVerticalLs() {
    try {
      var vsLs = (localStorage.getItem("zynixverticalstyles") || "").toLowerCase();
      if (vsLs === "icontext" || vsLs === "doublemenu" || vsLs === "detached" ||
          vsLs === "closed" || vsLs === "closemenu") {
        localStorage.removeItem("zynixverticalstyles");
      }
      var raw = localStorage.getItem("zynixlayout") || localStorage.getItem("ynexlayout") || "";
      if (raw && (raw.indexOf("detached") >= 0 || raw.indexOf("closed") >= 0 ||
          raw.indexOf("icontext") >= 0 || raw.indexOf("doublemenu") >= 0)) {
        localStorage.removeItem("zynixlayout");
        localStorage.removeItem("ynexlayout");
      }
    } catch (e2) {}
  }
  function migrateToDefaultMenu(html) {
    // Default Menu uses fullwidth (not overlay icon-rail)
    html.setAttribute("data-vertical-style", "fullwidth");
    html.setAttribute("data-nav-layout", "vertical");
    var tog = (html.getAttribute("data-toggled") || "").toLowerCase();
    if (tog.indexOf("detached") >= 0 || tog.indexOf("close-menu") >= 0 ||
        tog === "close" || tog === "icon-text-close" || tog === "double-menu-close" ||
        tog === "double-menu-open" || tog === "icon-overlay-close") {
      html.setAttribute("data-toggled", "open");
    }
    clearBadVerticalLs();
    var def = document.getElementById("switcher-default-menu");
    if (def) def.checked = true;
    var it = document.getElementById("switcher-icontext-menu");
    if (it) it.checked = false;
    var dm = document.getElementById("switcher-double-menu");
    if (dm) dm.checked = false;
    var ov = document.getElementById("switcher-icon-overlay");
    if (ov) ov.checked = false;
    try {
      if (typeof window.inpcSyncSidebarGutter === "function") window.inpcSyncSidebarGutter();
    } catch (e3) {}
  }
  function run() {
    try {
      var html = document.documentElement;
      var vs = (html.getAttribute("data-vertical-style") || "").toLowerCase();
      var vsLs = "";
      try { vsLs = (localStorage.getItem("zynixverticalstyles") || "").toLowerCase(); } catch (e4) {}
      if (vs === "detached" || vs === "closed" || vs === "closemenu" ||
          vs === "icontext" || vs === "doublemenu" ||
          vsLs === "icontext" || vsLs === "doublemenu" ||
          vsLs === "detached" || vsLs === "closed" || vsLs === "closemenu") {
        migrateToDefaultMenu(html);
      }
    } catch (e) {}
  }
  run();
  // Theme restore may re-apply after DOMContentLoaded -- re-check shortly
  setTimeout(run, 50);
  setTimeout(run, 400);
  setTimeout(run, 1200);
})();

/* INPC_MOBILE_NAV_SYNC: <992px always vertical overlay; >=992 restore LS theme (no permanent overwrite). */
(function () {
  var mq = null;
  try { mq = window.matchMedia("(max-width: 991.98px)"); } catch (e) { mq = null; }

  function applyViewportNav() {
    if (typeof window.inpcApplyNavForViewport === "function") {
      window.inpcApplyNavForViewport();
    } else if (typeof window.inpcIsMobileNav === "function" && window.inpcIsMobileNav()) {
      if (typeof window.inpcForceMobileVertical === "function") window.inpcForceMobileVertical();
    }
    try {
      if (typeof window.inpcSyncSidebarGutter === "function") window.inpcSyncSidebarGutter();
    } catch (e2) {}
    try {
      if (typeof window.inpcNormalizeMenuHoverLabels === "function") window.inpcNormalizeMenuHoverLabels();
    } catch (e3) {}
  }

  function onMqChange() {
    applyViewportNav();
    // Reset open accordion flyouts when flipping layouts
    try {
      var menus = document.querySelectorAll("#side-menu ul.slide-menu");
      for (var i = 0; i < menus.length; i++) {
        if (typeof window.inpcClearSlideMenuInlineStyles === "function") {
          window.inpcClearSlideMenuInlineStyles(menus[i]);
        } else {
          menus[i].style.removeProperty("display");
          menus[i].style.removeProperty("position");
        }
        menus[i].classList.remove("active");
      }
      var opens = document.querySelectorAll("#side-menu li.has-sub.open");
      for (var j = 0; j < opens.length; j++) opens[j].classList.remove("open");
    } catch (e4) {}
  }

  if (mq) {
    if (typeof mq.addEventListener === "function") mq.addEventListener("change", onMqChange);
    else if (typeof mq.addListener === "function") mq.addListener(onMqChange);
  } else {
    var lastMobile = null;
    window.addEventListener("resize", function () {
      var now = window.innerWidth < 992;
      if (lastMobile === null || lastMobile !== now) {
        lastMobile = now;
        onMqChange();
      }
    });
  }

  // Re-force after Switcher / theme-db mutates html attrs while still on mobile.
  try {
    var htmlEl = document.documentElement;
    var reforceTimer = null;
    var obs = new MutationObserver(function () {
      var mobile = typeof window.inpcIsMobileNav === "function"
        ? window.inpcIsMobileNav()
        : (window.matchMedia ? window.matchMedia("(max-width: 991.98px)").matches : window.innerWidth < 992);
      if (!mobile) return;
      var layout = (htmlEl.getAttribute("data-nav-layout") || "").toLowerCase();
      var ns = (htmlEl.getAttribute("data-nav-style") || "").toLowerCase();
      var vs = (htmlEl.getAttribute("data-vertical-style") || "").toLowerCase();
      var forced = htmlEl.getAttribute("data-inpc-mobile-nav") === "1";
      if (layout === "horizontal" || ns || vs !== "overlay" || !forced) {
        if (reforceTimer) clearTimeout(reforceTimer);
        reforceTimer = setTimeout(function () {
          if (typeof window.inpcForceMobileVertical === "function") window.inpcForceMobileVertical();
        }, 0);
      }
    });
    obs.observe(htmlEl, {
      attributes: true,
      attributeFilter: ["data-nav-layout", "data-nav-style", "data-vertical-style", "data-horizontal-submenu"]
    });
  } catch (e5) {}

  function boot() {
    applyViewportNav();
    setTimeout(applyViewportNav, 400);
    setTimeout(applyViewportNav, 1400);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();

/* Contact Us design option 1 — static card filter (HTML fragment scripts may not run after jQuery load). */
window.cu1FilterContacts = function (input) {
  try {
    var root = document.getElementById("m_contact_us_1");
    if (!root) return false;
    var q = String((input && input.value) || "").trim().toLowerCase();
    var cards = root.querySelectorAll(".cu1-card");
    var shown = 0;
    for (var i = 0; i < cards.length; i++) {
      var hay = (cards[i].getAttribute("data-q") || "").toLowerCase();
      var ok = !q || hay.indexOf(q) >= 0;
      if (ok) {
        cards[i].classList.remove("is-hidden");
        shown++;
      } else {
        cards[i].classList.add("is-hidden");
      }
    }
    var empty = document.getElementById("cu1_empty");
    var count = document.getElementById("cu1_count");
    if (empty) empty.style.display = shown ? "none" : "block";
    if (count) count.textContent = "Showing " + shown + " contact" + (shown === 1 ? "" : "s");
  } catch (e) { /* ignore */ }
  return false;
};

/* Contact Us design option 3 — static teal directory filter. */
window.cu3FilterContacts = function (input) {
  try {
    var root = document.getElementById("m_contact_us_3");
    if (!root) return false;
    var q = String((input && input.value) || "").trim().toLowerCase();
    var rows = root.querySelectorAll(".cu3-row");
    var shown = 0;
    for (var i = 0; i < rows.length; i++) {
      var hay = (rows[i].getAttribute("data-q") || "").toLowerCase();
      var ok = !q || hay.indexOf(q) >= 0;
      if (ok) {
        rows[i].classList.remove("is-hidden");
        shown++;
      } else {
        rows[i].classList.add("is-hidden");
      }
    }
    var empty = document.getElementById("cu3_empty");
    var count = document.getElementById("cu3_count");
    if (empty) empty.style.display = shown ? "none" : "block";
    if (count) count.textContent = "Showing " + shown + " contact" + (shown === 1 ? "" : "s");
  } catch (e) { /* ignore */ }
  return false;
};

/* Date / Month pickers (from sunstar MainPage.js CallTarkaDatePickerWithDivId) — needs bootstrap-datepicker + formatdate.js on MainPage */
function CallTarkaDatePicker(system_name) {
  if (typeof system_name === "undefined") {
    $(".date-picker").datepicker({ autoclose: true, format: "dd/mm/yyyy", todayBtn: true });
  } else {
    $("#" + system_name).datepicker({ autoclose: true, format: "dd/mm/yyyy", todayBtn: true });
    $("#" + system_name).datepicker("show");
  }
}
function CallTarkaDatePickerWithDivId(system_module_name, system_name) {
  if (typeof system_name === "undefined") {
    $(".date-picker").datepicker({
      autoclose: true,
      format: "dd/mm/yyyy",
      todayBtn: "linked",
      todayHighlight: true,
      forceParse: false,
      defaultViewDate: new Date()
    });
  } else {
    var $el = $("#m_" + system_module_name + " #" + system_name);
    if ($el.prop("readonly") || $el.prop("disabled")) return;
    var v = ($el.val() || "").trim();
    if (!v || v === "00/00/0000" || v === "00-00-0000" || /^0+[\/\-]0+[\/\-]0+$/.test(v)) {
      $el.val("");
    }
    if ($el.data("datepicker")) {
      $el.datepicker("destroy");
    }
    $el.datepicker({
      autoclose: true,
      format: "dd/mm/yyyy",
      todayBtn: "linked",
      todayHighlight: true,
      forceParse: false,
      defaultViewDate: new Date()
    }).on("show", function () {
      $(".datepicker").css("z-index", 3000);
    });
    $el.datepicker("show");
    $(".datepicker").css("z-index", 3000);
    $(".prev, .next").css("cursor", "pointer");
  }
}

/* Clicking a .date-picker input with 00/00/0000 used to open "November 0". Clear placeholder like icon path. */
(function inpcBindDatePickerEmptyClear() {
  if (window.__inpcDateEmptyClearBound || !window.jQuery) return;
  window.__inpcDateEmptyClearBound = true;
  function isEmptyDate(v) {
    v = String(v == null ? "" : v).trim();
    return !v || v === "00/00/0000" || v === "00-00-0000" || /^0+[\/\-]0+[\/\-]0+$/.test(v);
  }
  $(document).on("focus.inpcDateEmpty", "input.date-picker, input.datepicker", function () {
    var $el = $(this);
    if ($el.prop("readonly") || $el.prop("disabled")) return;
    var dp = $el.data("datepicker");
    if (dp && dp.picker && dp.picker.is(":visible")) return;
    if (!isEmptyDate($el.val())) return;
    var raw = String($el.val() == null ? "" : $el.val()).trim();
    if (!raw) return;
    $el.val("");
    if (!$el.data("datepicker") || !$.fn.datepicker) return;
    try {
      $el.datepicker("destroy");
    } catch (eD) { /* ignore */ }
    $el.datepicker({
      autoclose: true,
      format: $el.attr("data-date-format") || "dd/mm/yyyy",
      todayBtn: "linked",
      todayHighlight: true,
      forceParse: false,
      defaultViewDate: new Date()
    }).on("show", function () {
      $(".datepicker").css("z-index", 3000);
    });
  });
})();
function CallTarkaMonthPicker(system_module_name, system_name) {
  var $el = $("#m_" + system_module_name + " #" + system_name);
  if (!$el.length) $el = $("#" + system_name);
  if ($el.prop("readonly") || $el.prop("disabled")) return;
  $el.datepicker({
    autoclose: true,
    format: "mm/yyyy",
    minViewMode: 1,
    startView: 1,
    todayBtn: true
  }).on("show", function () {
    $(".datepicker").css("z-index", 3000);
  });
  $el.datepicker("show");
  $(".datepicker").css("z-index", 3000);
}