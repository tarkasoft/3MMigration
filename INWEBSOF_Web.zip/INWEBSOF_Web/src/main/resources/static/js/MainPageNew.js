var AllModules=function()
{
	 
	this.ClearfieldsNew=function(system_module_name)
	{ 
		if(all_obj[system_module_name]['load_type']=='FW')
			getModulesDetailsNew(system_module_name,all_obj[system_module_name]['g_str_module_name'],all_obj[system_module_name]['g_str_module_id'],'Clear',all_obj[system_module_name]['g_display_module_name'],0);
		else
		{
			var jt_db=getCookie("jt_db");
			var path="html_modules/modules/"+jt_db+"/module_"+all_obj[system_module_name]['g_str_module_id']+".html";	
			var popup_content_div_id="popup_content_"+all_obj[system_module_name]['g_str_module_id']
			$('#'+popup_content_div_id).load(path,function() 
			{
				CallGetModuleDetailsNew(system_module_name,'Clear',all_obj[system_module_name]['g_str_module_name'],all_obj[system_module_name]['g_str_module_id'],0,'PopUp');
			});
		}
	},
	this.EditRecords=function(row_id,system_module_name)
	{ 
		all_obj[system_module_name].geditinternalcode=row_id;
		if(all_obj[system_module_name]['header_details']['view_type']=='EntryScreen')
		{
			this.GetSchemaModuleDetailsForUpdateNew(system_module_name);
		}
		else		
		{
			getModulesDetailsNew(system_module_name,all_obj[system_module_name].g_str_module_name,all_obj[system_module_name].g_str_module_id,'Edit',all_obj[system_module_name].g_display_module_name,row_id);
		}
	}, 
	this.close = function (system_module_name,internal_code) 
	{
		if(all_obj.hasOwnProperty(system_module_name))
		{
			if(all_obj[system_module_name]['geditinternalcode'] > 0)
			{
				swal({
						title: 'You are in edit mode, Are you sure to close..?',
						type: 'warning',
						showCancelButton: true,
						confirmButtonColor: '#3085d6',
						cancelButtonColor: '#d33',
						confirmButtonText: 'Yes'
				}).then(function(result)  {  
						if (result.value===true)
						{ 
							all_obj.CloseFromCall(system_module_name,internal_code);
						}
					}); 
			}
			else
			{
				this.CloseFromCall(system_module_name,internal_code);
			}
		}
		else
		{
			this.CloseFromCall(system_module_name,internal_code);
		}
	},
	
	this.CloseModulePanel=function(system_module_name)
	{
		try {
			var name = String(system_module_name || "");
			if (!name) return;

			// Include Tabs: close the corresponding tab (same confirm as tab X)
			if (window.InpcTabs && typeof InpcTabs.flagOn === "function" && InpcTabs.flagOn()) {
				var key = name;
				var $mod = $("#m_" + name);
				if ($mod.length) {
					var $pane = $mod.closest(".inpc-tab-pane");
					if ($pane.length && $pane.attr("data-tab-key")) {
						key = $pane.attr("data-tab-key");
					}
				}
				if (key === (InpcTabs.HOME_KEY || "home")) {
					// Never close Home via module Close — just activate it
					if (typeof InpcTabs.activate === "function") InpcTabs.activate(key);
					return;
				}
				var title = (all_obj[name] && all_obj[name]["header_details"] && all_obj[name]["header_details"]["display_name"])
					? all_obj[name]["header_details"]["display_name"]
					: name;
				if (typeof InpcTabs.closeConfirm === "function") {
					InpcTabs.closeConfirm(key, title);
				} else if (typeof InpcTabs.close === "function") {
					InpcTabs.close(key);
				}
				return;
			}

			// Single page (no tabs): go to Home
			var homeMod = "home";
			try {
				if (typeof window.inpcHomeModuleForUserType === "function") {
					homeMod = String(window.inpcHomeModuleForUserType(window.inpcGetLoginUserType && window.inpcGetLoginUserType()) || "home").replace(/\.html$/i, "");
				}
			} catch (eH) { homeMod = "home"; }
			if (typeof window.LoadHtmlFiles === "function") {
				window.LoadHtmlFiles(homeMod, "Home", "Home", "0");
			} else if ($("#home_dashboard").length) {
				$("#content_title").text("Home");
				$("#home_dashboard").html("");
				if (typeof loadPage === "function") {
					loadPage("html_files/" + ((window.$g_app_tye || $g_app_tye || "INPC")) + "/" + homeMod + ".html", "Home", null, "home");
				}
			}
		} catch (e) {
			console.error(e);
			alert("Close error: " + (e && e.message ? e.message : e));
		}
	},
	this.CloseFromCall=function(system_module_name,internal_code)
	{
		if(all_obj.hasOwnProperty(system_module_name))
		{
			if(all_obj[system_module_name]['load_type']== 'FW')
			{
				setTimeout(function(){
						$("#menu_tabs li.tab-current").prev().trigger("click");
						$('#section-bar-'+internal_code).remove();
						$('#menu_tabs #li_'+internal_code).remove();
					}, 100);
			}
			else
			{
				var div_id="popup_module_dialog_"+internal_code;
				$('#'+div_id).dialog("close");
				$("#popup_module_dialog_"+internal_code).html("");
			}
		}
		else
		{
			setTimeout(function(){
						$("#menu_tabs li.tab-current").prev().trigger("click");
						$('#section-bar-'+internal_code).remove();
						$('#menu_tabs #li_'+internal_code).remove();
					}, 100);
		}
	},
	this.DisplayUserSchemaModuleDetailsNew=function(system_module_table_name)
	{
		var load_id = "#page_main_div";
		var load_type=all_obj[system_module_table_name]['load_type'];
		all_obj[system_module_table_name]['geditinternalcode']=0;
		if(load_type=='PopUp')
		{
			load_id="#popup_module_dialog_"+all_obj[system_module_table_name]['g_str_module_id']+" #popup_content_"+all_obj[system_module_table_name]['g_str_module_id'];
			
		}
		// console.log(load_id);
	 
		var main="<table  id='table_grid_"+system_module_table_name+"' class='scroll'  system_module_table_name='"+system_module_table_name+"' ></table> <div id='sub_grid_div_"+system_module_table_name+"'   class='scroll' style='text-align:center;'></div>";
			$(load_id).html("<div class='col-md-12 no-padding' id='m_"+system_module_table_name+"' style='margin-top:10px;'>"+main+"</div>");
		
		var th = document.getElementsByTagName('head')[0];
		var s = document.createElement('script');
		var jt_db=getCookie("jt_db");
		s.setAttribute('type','text/javascript');
			var path="grid_display_files/"+$g_app_tye+"/"+system_module_table_name+".js";
 //alert(path);
		s.setAttribute('src',path);
		th.appendChild(s); 
		 
	},
	this.AssignMenuEvents=function(system_module_name)
	{
		var header_details=all_obj[system_module_name]['header_details'];
		   custom_links=header_details['custom_links']; 
		  action_html="";
		if(header_details['include_save']=='1')
		  action_html+=" <a href='javascript:void(0)' onclick=javascript:all_obj.saveModuleDetails('"+system_module_name+"'); class='btn btn-sm btn-success d-inline-flex align-items-center gap-1 px-3'><i class='ri-save-line'></i> Save</a> ";
		if(header_details['include_clear']=='1')
			action_html+=" <a href='javascript:void(0)' onclick=javascript:all_obj.ClearfieldsNew('"+system_module_name+"'); class='btn btn-sm btn-danger d-inline-flex align-items-center gap-1 px-3'><i class='ri-close-circle-line'></i> Clear</a>";
		if(header_details['include_close']=='1' || header_details['include_close']==1 || String(header_details['include_close'])==='1')
			action_html+=" <a href='javascript:void(0)' onclick=javascript:all_obj.CloseModulePanel('"+system_module_name+"'); class='btn btn-sm btn-secondary d-inline-flex align-items-center gap-1 px-3'><i class='ri-logout-box-r-line'></i> Close</a>";
		if(header_details['include_download']=='1')
			action_html+=" <a href='javascript:void(0)' onclick=javascript:EnableDownlLoadUploadModules('"+system_module_name+"'); class='btn btn-sm btn-warning d-inline-flex align-items-center gap-1 px-3'><i class='ri-download-2-line'></i> Download</a>";
		if(header_details['include_generate']=='1')
			action_html+=" <a href='javascript:void(0)' onclick=javascript:GenerateReports('"+system_module_name+"'); class='btn btn-sm btn-primary d-inline-flex align-items-center gap-1 px-3'><i class='ri-bar-chart-2-line'></i> Generate</a>";
		if(header_details['include_view']=='1' &&  header_details['view_type']=='FullGrid')
			action_html+=" <a href='javascript:void(0)' onclick=javascript:all_obj.DisplayUserSchemaModuleDetailsNew('"+system_module_name+"'); class='btn btn-sm btn-info d-inline-flex align-items-center gap-1 px-3'><i class='ri-eye-line'></i> View</a>";
		if(!empty(custom_links))
			action_html+=this.RenderCustomLinks(custom_links);
		$("#page_main_actions_div").show();
		$("#m_"+system_module_name+" #page_main_actions_div").html(action_html);
	},
	/**
	 * ia_menu_options.custom_links → action buttons.
	 * Format: Label~function();  several links separated by |
	 * Optional third part is a Bootstrap color: Preview~PreviewWelcomeMessage();~info
	 * A value that already contains HTML (a tag, and no ~) is inserted as stored.
	 */
	this.RenderCustomLinks=function(custom_links)
	{
		var raw = custom_links == null ? "" : String(custom_links).trim();
		if (!raw || raw.toLowerCase() === "null") return "";
		if (raw.indexOf("<") >= 0 && raw.indexOf("~") < 0) return " " + raw + " ";
		var parts = raw.split("|");
		var colors = ["info", "warning", "primary", "success", "danger"];
		var allowed = { info: 1, warning: 1, primary: 1, success: 1, danger: 1, secondary: 1, dark: 1 };
		var html = "";
		for (var i = 0; i < parts.length; i++) {
			var piece = (parts[i] || "").trim();
			if (!piece) continue;
			var bits = piece.split("~");
			var name = (bits[0] || "").trim();
			var fun = bits.length > 1 ? (bits[1] || "").trim() : "";
			var color = bits.length > 2 ? (bits[2] || "").trim().toLowerCase() : "";
			if (!name) continue;
			if (!fun) {
				html += " " + $("<div>").text(name).html() + " ";
				continue;
			}
			if (!allowed[color]) color = colors[i % colors.length];
			var safeName = $("<div>").text(name).html();
			var safeFun = fun.replace(/\\/g, "\\\\").replace(/"/g, "&quot;");
			var icon = /preview/i.test(name) ? "ri-eye-line" : "ri-links-line";
			html += " <a href='javascript:void(0)' onclick=\"javascript:" + safeFun + "\" class='btn btn-sm btn-" + color
				+ " d-inline-flex align-items-center gap-1 px-3'><i class='" + icon + "'></i> " + safeName + "</a> ";
		}
		return html;
	},
	this.GetGroupDetailsForGroup=function (system_module_name,group_name)
	{
		var all_multi_groups=all_obj[system_module_name]['all_multi_groups'];
	
		for( j=0; j<  all_multi_groups.length; j++)
		{
			if(group_name==all_multi_groups[j]['group_name'])
			return  all_multi_groups[j];
		}
	},
	this.CallTarkaDatePickerWithDivId = function (system_module_name, system_name) {
		return this.CallTarkaDatePickerNew(system_module_name, system_name);
	},
	this.CallTarkaDatePickerNew = function (system_module_name,system_name)
	{
		var $el = $("#m_"+system_module_name+" #"+system_name);
		if ($el.prop('readonly') || $el.prop('disabled')) {
			return;
		}
		/* 00/00/0000 parses as ~1900 — treat as empty and open on today */
		var v = ($el.val() || "").trim();
		if (!v || v === "00/00/0000" || v === "00-00-0000" || /^0+[\/\-]0+[\/\-]0+$/.test(v)) {
			$el.val("");
		}
		if ($el.data("datepicker")) {
			$el.datepicker("destroy");
		}
		$el.datepicker({
			autoclose: true,
			format: "dd/mm/yyyy",
			todayBtn: "linked",
			todayHighlight: true,
			forceParse: false,
			defaultViewDate: new Date()
		}).on("show", function () {
			$(".datepicker").css("z-index", 3000);
		});
		$el.datepicker("show");
		$(".datepicker").css("z-index", 3000);
		$(".prev, .next").css("cursor", "pointer");
	},
	
	this.ClearReferenceData=function (system_module_name,system_name) {
		
		var div_id = "#page_main_div #m_"+system_module_name;
		var val = $(div_id+" #"+system_name).val();
		var txt_ref_val = trim($(div_id+" #txt_ref_schema_"+system_name).val());
		if(val==0 && !empty(txt_ref_val))
		{
			$(div_id+" #txt_ref_schema_"+system_name).val("");
			setTimeout(function(){
				$(div_id+" #txt_ref_schema_"+system_name).focus();
			}, 100);
			return false;
		}
	},
	
	this.validateFormFields=function(system_module_name)
	{
		// alert("Coming to validation");
		var save_obj=this[system_module_name];
		var div_id="m_"+system_module_name;
		save_second_level=save_obj.g_user_schema_details_array.data[1];
		var system_module_table_name=save_second_level[0].system_module_table_name;
	
		for($i = 0; $i < save_second_level.length; $i++)
		{
			var data_type=save_second_level[$i].Type;
			var optional=save_second_level[$i].optional;
			var system_name=save_second_level[$i].system_name;
			// alert(system_name);
			var element_name=save_second_level[$i].name;
			var is_ref_module_code_lov=save_second_level[$i].is_ref_module_code_lov;
			var p_cell_val=parseFloat(trim($("#"+div_id+" #"+save_second_level[$i].system_name).val()));
			var div_sytem_name=$("#"+div_id+" #"+save_second_level[$i].system_name);
			var cell_val= (trim($("#"+div_id+" #"+save_second_level[$i].system_name).val()));
			 // console.log(("#"+div_id+" #"+save_second_level[$i].system_name)+"---cell value---"+cell_val+"--data type---"+data_type);
			if(data_type=="Number"   && optional=='0' && (empty(cell_val) || cell_val==0))
			{
				ShowAlertMsg(element_name+" is mandatory", "warning");
				setTimeout(function(){div_sytem_name.focus(); ;},2000);	
				return false;
			}
			else if(data_type=="Text"  && optional=='0'  && empty(cell_val))
			{					 
				ShowAlertMsg(element_name+" is mandatory", "warning") ;  
				setTimeout(function(){div_sytem_name.focus(); ;},2000);	
				return false;
			}	
			else if(data_type=="List Of Values"  && optional=='0' && empty(cell_val))
			{					 
				ShowAlertMsg(element_name+" is mandatory", "warning")  ;
				setTimeout(function(){div_sytem_name.focus(); ;},2000);									
				return false;
			}
			else if(data_type=="Reference Data"  && optional=='0'  && empty(cell_val) )//&& is_ref_module_code_lov=1
			{
				ShowAlertMsg(element_name+" is mandatory", "warning");
				setTimeout(function(){div_sytem_name.focus(); ;},2000);									
				return false;
			}
			else if(data_type=="Date")
			{
				if(optional=='0' && (cell_val=="00/00/0000" || empty(cell_val)))
				{
					ShowAlertMsg(element_name+" is mandatory", "warning") 
					return false;
				}
				if(!empty(cell_val)   && !isDate(cell_val,'d/M/y'))
				{
					ShowAlertMsg( element_name+" is mandatory", "warning");
					setTimeout(function(){div_sytem_name.focus(); ;},2000);	
					div_sytem_name.focus();
					return false;
				}
			}
			else if(data_type=="Attachment" && typeof window.FileReader !== 'function' )
			{
				ShowAlertMsg(element_name+" is mandatory", "warning") ;  
				return false;
			}
			else if(data_type=="Attachment" && optional=='0' && empty(cell_val) )
			{
				ShowAlertMsg(element_name+" is mandatory", "warning")  
				return false;
			}
			
		}
		
		return true;
	},
	this.ReadAttachment=function (system_module_name,system_name)
	{
	
		var load_id = "#m_"+system_module_name+" #"+system_name;
		var input =$(load_id).fileinput()[0];
		var attachment_obj =new Object();;
		if (input.files[0])
		{
			var file_name = $(load_id).fileinput()[0].files[0].name;
				
			var file = input.files[0];
			var fr = new FileReader();
			fr.readAsDataURL(file);
			var result;
			fr.onload = function () {
				result = fr.result;
			
				$(load_id).attr("data-file-src",result);
				$(load_id).attr("data-file-name",file_name);
				$(load_id).attr("data-att-state","New");
				$(load_id+"_attch_del").show();
				$(load_id+"_attch_name").attr('href',"");
				$(load_id+"_attch_name").html("");
			};
		}
	},
	this.RemoveAttachment=function(system_module_name,system_name)
	{
		var load_id = "#m_"+system_module_name+" #"+system_name;
		$(load_id).val("");
		$(load_id).attr("data-file-src","");
		$(load_id).attr("data-file-name","");
		$(load_id).attr("data-att-state","Delete");
		$(load_id+"_attch_name").attr('href',"");
		$(load_id+"_attch_name").html("");
		$(load_id+"_attch_del").hide();
		
	},
	this.saveModuleDetails=function(system_module_name)
	{
		// alert(system_module_name);
		// try
		// {
			var save_obj=this[system_module_name];
		 
			var div_id="m_"+system_module_name;
			save_second_level=save_obj.g_user_schema_details_array.data[1];
			var system_module_table_name=save_obj.g_system_module_table_name;
			//alert('validateFormFields'+system_module_name)
			 if(!this.validateFormFields(system_module_name)) return;
					// alert('aaaa___validateFormFields'+system_module_name)
						$auto_increment_value='';
						 
						var save_schema_details_arr = new Object();
						var header_data_type_arr = new Object();
						 
					var image_obj = new Object();
					var attachments_obj = new Object();
					// console.log(save_second_level);
					for($k = 0; $k < save_second_level.length; $k++)
					  {
						 
						var field_id=save_second_level[$k].system_name;
						 header_data_type_arr[field_id]=save_second_level[$k].Type;
						var field_id_val='';

						 
							var system_name= save_second_level[$k].system_name;
							var cell_val= (trim($("#"+div_id+" #"+save_second_level[$k].system_name).val()));
							
							var int_code=save_second_level[$k].internal_code;;
						
						  if(save_second_level[$k].Type=='Date' && !empty(cell_val))
							{
							 
							field_id_val=date_format(cell_val);
							 
							}
							 
							else if(save_second_level[$k].Type=='DateTime' && cell_val=='')
							{
							field_id_val="00/00/0000 00:00";
							}
							else if(save_second_level[$k].Type=='Month' && cell_val!='')
							{
							field_id_val=getYearMonthDBValue(cell_val);
							}
							else if(save_second_level[$k].Type=='Month' && cell_val=='')
							{
							field_id_val="000000"
						 
							}
							else if(save_second_level[$k].Type=='Image')
							{
								var image_val=encodeURIComponent($("#"+system_name+" .fileinput-preview.fileinput-exists.thumbnail >img").attr('src'));
								var image_class = $("#"+system_name+" .fileinput").attr('class')
								image_obj[system_name]= new Object();
								image_obj[system_name]['data']= image_val;
								image_obj[system_name]['class']= image_class;
								image_obj[system_name]['file_name']= $("#"+system_name+" :file").val();
								continue;
							}
							else if(save_second_level[$k].Type=='Attachment')
							{	
							
								attachments_obj[system_name] = new Object();
								var file_content = encodeURIComponent($("#m_"+system_module_name+" #"+system_name).attr('data-file-src'));
								var file_name = encodeURIComponent($("#m_"+system_module_name+" #"+system_name).attr('data-file-name'));
								var attach_state = $("#m_"+system_module_name+" #"+system_name).attr('data-att-state');
								attachments_obj[system_name]['file_name']=file_name;
								attachments_obj[system_name]['file_content']=file_content;
								attachments_obj[system_name]['attach_state']=attach_state;
								continue;
							} 
							else if (save_second_level[$k].Type=='Reference Data' && save_second_level[$k].is_ref_module_code_lov=='0')
							{
							var txt_ref_val=trim($("#"+div_id+" #"+'txt_ref_schema_'+save_second_level[$k].system_name).val());
								if(empty(txt_ref_val))
									{
									 
									field_id_val="0"
									 
									}
									else 
									{
										field_id_val=cell_val;
										field_id_val=empty(field_id_val)?0:field_id_val;
										
									}
							}
							else if(save_second_level[$k].Type=='Checkbox')
							{
								var field_id_val=0;
									var checkbox_val=  $("#"+div_id+" #"+save_second_level[$k].system_name).is(':checked');
								if(checkbox_val)
									field_id_val=1;
								 
							}
							else 
							{
							field_id_val=cell_val;
							}
							 
							 
							save_schema_details_arr[field_id]=encodeURIComponent(field_id_val);
						 
						
					}
					// alert('jjjjjjj--------validateFormFields'+system_module_name)
			var fw_save_obj=new Object();			
			var image_data = image_obj;
			var attachment_data = attachments_obj;
		 
			 
			var group_details_arr=this.GetGroupDetailsForSave(save_obj.g_multi_group,system_module_name);
		 
			  fw_save_obj.internal_code=save_obj['geditinternalcode'];
			var before_save_insert_id=save_obj['geditinternalcode'];
			  fw_save_obj.ref_s_user_schema_code=save_obj['g_str_module_id'];
			  fw_save_obj.system_module_table_name=encodeURIComponent(system_module_table_name);
			   var FW_login_Id = "";
			  var login_user_html = $("#login_user_name").html();
			  if (login_user_html == null || login_user_html === "") {
			  	login_user_html = $("#login_user_name_display").text();
			  }
			  if (login_user_html == null) login_user_html = "";
			  FW_login_Id = $.trim(String(login_user_html).split("-")[0]);
				 fw_save_obj.FW_login_Id=FW_login_Id;
			fw_save_obj.save_schema_details_arr=save_schema_details_arr;
			fw_save_obj.header_data_type_arr=header_data_type_arr;
			// alert('nnn--------validateFormFields'+system_module_name)
			/*  
			 alert('jjjjjjj--------validateFormFields'+system_module_name)
			fw_save_obj.image_data=image_data;
			fw_save_obj.attachment_data=attachment_data; */
			 if(typeof(OverRideFraworkSaveObj)=="function")
			 {
				fw_save_obj=OverRideFraworkSaveObj(fw_save_obj,system_module_table_name);
				 
			 }	 
			 
			 	// alert('OverRideFraworkSaveObj'+system_module_name)
			fw_save_obj.group_details_arr= ((group_details_arr));			 
			var save_flag=true;
			var s_module_pre_save=save_obj.s_module_pre_save
			 if(!empty(s_module_pre_save))
			 {
				 save_flag=eval(s_module_pre_save);
			 }
			 var pre_val_flag=true;
			pre_val_flag=PreSaveModuleValidation(system_module_table_name);
			var msave=all_obj[system_module_name]['msave'];
			var  upload_form = new FormData();
			upload_form.append("fw_save_obj", JSON.stringify(fw_save_obj));
			
			if(save_flag==true && msave=='Yes' && pre_val_flag==true)
			 {
				all_obj[system_module_name]['msave']='No';
				
				// alert('AddUserSchemaGeneralDetailsNew'+system_module_name)
				App.blockUI({boxed:true,message:"Saving "});
				$.ajax
				({
					   type: "POST",
					   url: $host_url+"system/AddUserSchemaGeneralDetailsNew",
					   dataType: "json",
					  	data:upload_form,
						processData: false,
						contentType: false,
					   error:AjaxErrorMessage,		      
					   success:  function saveUserSchemaGeneralDetailsResponce($responce)
								{
									 //try
										{
											App.unblockUI();
											all_obj[system_module_name]['msave']='Yes';
											// $responce = eval('(' + $responce + ')');
											if($responce.error_code=='-9')
											{
												
												ShowAlertMsg($responce.data);
												CallLogout();
											return false;
											}
											// var system_module_name=$responce.data.system_module_name;

											if ($responce.error_code == 2) 
											{
											ShowAlertMsg($responce.data)
											 
											return false;
											}
											if($responce.error_code == 0)
											{
												var save_last_id = ($responce.data && $responce.data.last_id != null) ? String($responce.data.last_id) : "0";
												var save_msg = ($responce.data && $responce.data.msg != null) ? String($responce.data.msg) : "";
												if(save_last_id === "0" || save_last_id === "" || /exception|failed|invalid object/i.test(save_msg))
												{
													ShowAlertMsg(save_msg || "Save failed");
												}
												else
												{
													all_obj[system_module_name]['geditinternalcode']=$responce.data.last_id;
													var flag=PostSaveModuleDetails($responce,$responce.data.last_id,system_module_table_name,before_save_insert_id);
													var flag="";
													if(system_module_name!="tk_po_receipt" && system_module_name!="ew_convertor"
													 && system_module_name!="ew_applicator"&& system_module_name!="tsd_product_master")
													{
														ShowSuccessMsg(save_msg || "Saved successfully");
														{
															all_obj.ClearfieldsNew(system_module_name);
														}
													}
												}
											}

											if($responce.error_code == -1)
											{
											ShowAlertMsg($responce.data.msg);
										 
											}
										}	
										/* catch(err)
										{
											txt= err.message;
											
											bootbox.alert(txt+"<br> in saveModuleDetails");
										}  */
								}	
						   
				  });
			 }
		/* } //try close
		catch(err)
		{
			txt= err.message;
			App.unblockUI();
			bootbox.alert(txt+"<br> in saveModuleDetails");
		}  */
	},
	this.AssignRefModuleDefaultValues = function(system_module_table_name)
	{
		if(!empty(all_obj[system_module_table_name]['g_user_schema_details_array']['data']['ref_data_default_val']) && all_obj[system_module_table_name]['g_is_module_for_new_or_edit']=="Add")
		{
			var rdf_obj=all_obj[system_module_table_name]['g_user_schema_details_array']['data']['ref_data_default_val'];
			 
	 
			jQuery.each(rdf_obj, function(k, v) {
				var system_name=k;
				var rfd_default_val=v['default_val'];
				var rfd_int_code=v['int_code'];
				if(all_obj[system_module_table_name]['load_type']=='FW') 
				{
					  var div_id="#m_"+system_module_table_name;
					
				}else if(all_obj[system_module_table_name]['load_type']=='PopUp') 
				{
					var module_id=all_obj[system_module_table_name]['g_str_module_id'];
					var div_id="#popup_module_dialog_"+module_id+" #m_"+system_module_table_name;
				}
				 
				if($(div_id+" #"+system_name).attr('type')=='hidden')
					{
						$(div_id+" #txt_ref_schema_"+system_name).val(rfd_default_val);
						$(div_id+" #"+system_name).val(rfd_int_code);
					}
					else
					{
						 
						$(div_id+" #"+system_name).val(rfd_int_code);									 
					}
				
			});							
		}
	},
	this.GetPrevNextModuleDetails = function(system_module_name,type,internal_code)
	{
		if(internal_code==0 || empty(internal_code))
		{
			ShowAlertMsg("No "+type+" Record to view");
			return false;
		}
		else
		{
			all_obj[system_module_name]['geditinternalcode']=internal_code;
			all_obj.GetSchemaModuleDetailsForUpdateNew(system_module_name);
		}
	},
	
	this.GetSchemaModuleDetailsForUpdateNew=function (system_module_name)
	{
		
		var save_obj=all_obj[system_module_name];
		var display_module_name=save_obj['g_display_module_name'];
 
				// App.blockUI({boxed:true,message:"Getting "+display_module_name+" Data"});
				App.blockUI({
                
                boxed: true,
                message: "Getting "+display_module_name+" Data"
            });
				
				
			$.ajax({
				type: "POST",
				 // async: false,
				url: $host_url+"system/GetSchemaModuleDetailsForUpdateNew",
				error:AjaxErrorMessage,
				data:"internal_code="+save_obj.geditinternalcode+"&table_name="+save_obj.g_system_module_table_name+"&schema_id="+save_obj.g_str_module_id,
				error:function (xhr, ajaxOptions, thrownError){
					 App.unblockUI();
					 swal("Error", thrownError+xhr.responseText, "warning");
						// bootbox.alert(thrownError+xhr.responseText);
					 
				},
				success: function populateSchemaModuleDetalisForUpdate(responce)
						{
							  try
								{ 
									App.unblockUI();
									   
									 responce = eval('(' + responce + ')');
									
									if(responce.error_code=='-9')
									{
									ShowAlertMsg(responce.data);CallLogout();
									return false;
									}
									 else if(responce.error_code == -1)
									{
										 ShowAlertMsg(responce.data.msg);
								 
									}
									if(responce.error_code == 0)
									{
										all_obj.AssginDataAfterEdit(system_module_name,responce,save_obj.geditinternalcode);
									}

									
								  }	
								catch(err)
								{
									txt= err.message;
									App.unblockUI();
									bootbox.alert(txt+"<br> in GetSchemaModuleDetailsForUpdateNew");
								}  
						}
						
				});
	}
	this.AssginDataAfterEdit=function(system_module_name,responce,internal_code)
	{
			var save_obj=all_obj[system_module_name];
			var div_id="m_"+system_module_name;
			var previous_int_code=responce.data['previous_int_code'];
			var next_int_code=responce.data['next_int_code'];
			saved_ref_display_arr=responce.data['saved_ref_display_arr'];
			var details=responce.data['details'][0];
			$.each(save_obj.g_system_names_full_arr,function(k,v)
			{
				
				var system_name=k;
				var data_type=v['Type'];
				var is_ref_module_code_lov=v['is_ref_module_code_lov'];
				if(data_type=="Reference Data" && is_ref_module_code_lov=="0")
				{
						var txt_schema_id="txt_ref_schema_"+system_name;
					$("#"+div_id+" #txt_ref_schema_"+system_name).val(details[txt_schema_id]);
					$("#"+div_id+" #"+system_name).val(details[system_name]);
				}if(data_type=="Reference Data" && is_ref_module_code_lov=="1")
				{
					ref_val=details[system_name];
					if(empty(ref_val))
						ref_val=0;
					$("#"+div_id+" #"+system_name).val(ref_val);
				}
				else if(data_type=='Image')
				{
					var image_path = details[system_name];
					if(!empty(image_path))
					{
						var image_tag= "<img src='"+image_path+"'></img>";
						$("#"+system_name+" .fileinput-preview.fileinput-exists.thumbnail").html(image_tag);
						$("#"+system_name+" .fileinput").removeClass('fileinput-new');
						$("#"+system_name+" .fileinput").addClass('fileinput-exists');
						
					}
				}
				else if(data_type=='Attachment')
				{
					var attachment_path = details[system_name];
					if(!empty(attachment_path))
					{
						$("#"+div_id+" #"+system_name+"_attch_name").attr('href',attachment_path);
						var file_name = attachment_path.split('/').pop();
						$("#"+div_id+" #"+system_name+"_attch_name").html(file_name);
						$("#"+div_id+" #"+system_name+"_attch_del").show();
						
					}
				}
				else if(data_type=='Ref Display')
				{
					 $("#"+div_id+" #"+system_name).val(saved_ref_display_arr[system_name]);
				} 
				else if(data_type=='Checkbox')
				{
					if(details[system_name]=='1')
					 $("#"+div_id+" #"+system_name).attr("checked",true);
					else
						 $("#"+div_id+" #"+system_name).attr("checked",false);
				}
				else  if(data_type=='Month')
				{
					$("#"+div_id+" #"+system_name).val(getYearMonthUIValue(details[system_name]));
				}
				else  if(data_type=='Date')
				{
					date_val=details[system_name];
					if(date_val=="01/01/1900")
						date_val="";
					$("#"+div_id+" #"+system_name).val( date_val);
				}
				else
				{
					$("#"+div_id+" #"+system_name).val(details[system_name]);
				}
			});
			
			 	 var grp_details=responce.data['grp_details'];
			 
			 if(!empty(grp_details))
			 FWMultiGrid.AssignGroupDetailsAfterEdit(system_module_name,grp_details);
			else
			{
			this.ClearGroupDetailsBeforeAssign(system_module_name);
			}
			 if (typeof AfterEditModule === "function") { AfterEditModule(system_module_name,internal_code,details); }
			 
		 
	},
	this.ClearGroupDetailsBeforeAssign = function(system_module_name)
	{
	
		multi_group_arr=all_obj[system_module_name]['g_multi_group'];
		if(!empty(multi_group_arr))
		{
			$.each(multi_group_arr,function(k,v){
				
				$("#m_"+system_module_name+" table#"+k+" tbody tr").remove();
				
				FWMultiGrid.FormGridEditFields(system_module_name,k,0,'Add');
			});
		}
	},	
	this.GetGroupDetailsForSave = function(g_multi_group,system_module_name)
	{
		if(empty(g_multi_group))
			return;
		var group_save_obj= new Object;
		var div_id="m_"+system_module_name;
		$.each(g_multi_group, function (k,v) {
			var group_name=v.table_name;
			var is_child_exists=v.is_child_exists;
			var group_id=v.group_id;
			var is_grid_edit_inline=v.is_grid_edit_inline;
			var is_grid_edit=v.is_grid_edit;
			var parent_group=v.parent_group;
			if(parent_group>0) return;
			var child_group_arr=v.child_group_arr;
			var elements=v.elements;
			var grp_system_name_full_arr=v.grp_system_name_full_arr;
			var table_id="#"+div_id+" #"+group_name+" tbody tr";
			group_save_obj[group_name]=new Object;
			if(is_grid_edit=="1" && is_grid_edit_inline=="1")
			{
			var jqgrid_data=$('#table_group_grid_'+group_id).jqGrid('getGridParam','data');
			// group_save_obj[group_name]=jqgrid_data; return;
			var element_keys=Object.keys(grp_system_name_full_arr);
			// console.log(element_keys);
				var grid_obj=new Object();
				k=0;
				 $.each($(jqgrid_data), function (gk,gv) {
					 grid_obj[k]=new Object();
					 for(m=0;m<element_keys.length;m++)
					 {
						grid_obj[k][element_keys[m]]=gv[element_keys[m]];
					 }
					 k++;
				 });
				 // console.log(grid_obj);
			group_save_obj[group_name]=grid_obj; return;
			
			}
			var i=0;
			//####HANDLE TAX
				 var t_tax_structure_doc_table = all_obj[system_module_name].t_tax_structure_doc_table;
				 var t_tax_structure_exists = all_obj[system_module_name].t_tax_structure_exists;
				 var t_tax_structure_item_tax_table = all_obj[system_module_name].t_tax_structure_item_tax_table;
					var tax_structure_type = all_obj[system_module_name].g_multi_group[group_name].tax_structure_type;
					var is_item_tax_data_exists = all_obj[system_module_name].g_multi_group[group_name].grp_system_name_full_arr.hasOwnProperty('item_tax_data');
					if(t_tax_structure_exists=='Yes' && t_tax_structure_doc_table==group_name)// for doc tax structure we are taking values differently
					{
						var tax_obj=Tax.GetDocTaxStructureDataForSave(system_module_name);
						group_save_obj[group_name]=tax_obj;
						return;
					}	
			// console.log(table_id);			
			$.each($(table_id), function (rk,rv) {
			
				
				var tr_id=rv['id'];
				
				var row_type = $(table_id+"#"+tr_id+" #actions #row_cancel").attr('data-row-type');
				// input_field_length=$(table_id+"#"+tr_id+" input:visible, "+table_id+"#"+tr_id+" select:visible").length;
				 // console.log(row_type);	
				if(row_type!='New' && row_type!='Edit' && parent_group==0)
				{
				
					group_save_obj[group_name][i]=new Object;
					$.each(elements, function (ek,ev) {
						
						var meta_data=ev['meta_data'];
						if(meta_data=="User") return;
						var data_type=ev['Type'];
						var db_field=ev['db_field'];
						var is_ref_module_code_lov=ev['is_ref_module_code_lov'];
						var tr_row_data=$(table_id+"#"+tr_id);
						// console.log(tr_row_data);
						
						if((data_type=='Reference Data') && (is_ref_module_code_lov==0))
						{
							// group_save_obj[group_name][i][db_field]=$(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id).val();
								 group_save_obj[group_name][i][db_field]=tr_row_data.find("#"+db_field+"_"+tr_id).val();
						}
						/* else if(data_type=='Date')
						{
							group_save_obj[group_name][i][db_field]=date_format($(table_id+"#"+tr_id+"  #"+db_field+"_"+tr_id+" p").html());
						} */
						else if(data_type=='Image')
						{
							var img_obj= new Object();
							var image_data = $(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p img").attr('src');
							var image_type = $(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p img").attr('data-image-type');
							var image_name = $(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p img").attr('data-image-name');
						
							img_obj['image_data']=encodeURIComponent(image_data);
							img_obj['image_type']=encodeURIComponent(image_type);
							img_obj['image_name']=encodeURIComponent(image_name);
							group_save_obj[group_name][i][db_field]=img_obj;
						}
						else if(data_type=='Attachment')
						{
							var att_obj= new Object();
							var att_data = $(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p").attr('data-file-src');
							var data_att_state = $(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p").attr('data-att-state');
							var file_name = $(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p").attr('data-file-name');
						
							att_obj['image_data']=encodeURIComponent(att_data);
							att_obj['image_type']=encodeURIComponent(data_att_state);
							att_obj['image_name']=encodeURIComponent(file_name);
							group_save_obj[group_name][i][db_field]=att_obj;
						}
						else if(data_type=='Checkbox')
						{
							var check_val=0;
							var checkbox_val=$(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p :input[type='checkbox']").is(':checked');
							if(checkbox_val)
								check_val=1;
							group_save_obj[group_name][i][db_field]=check_val;
						}
						else
						{
							group_save_obj[group_name][i][db_field]=encodeURIComponent(tr_row_data.find("#"+db_field+"_"+tr_id+" p").html());
							// group_save_obj[group_name][i][db_field]=encodeURIComponent($(table_id+"#"+tr_id+" #"+db_field+"_"+tr_id+" p").html());
						}
							
						});
						
						group_save_obj[group_name][i]['group_int_code']=$(table_id+"#"+tr_id+" #group_int_code_"+tr_id).val();
				 
						group_save_obj[group_name][i]['row_sequence']=$(table_id+"#"+tr_id+" #seq_"+tr_id+" p").html();;
						if(is_child_exists=="1")
						{
							
								var t_obj= decodeURIComponent($(table_id+"#"+tr_id+" #third_level_obj_"+tr_id).html());;
								t_obj= JSON.parse(t_obj);
								
								
								if(t_tax_structure_exists=='Yes' && tax_structure_type=='Item' && is_item_tax_data_exists==true)
								{
									var item_tax_obj = new Object();
									item_tax_obj[t_tax_structure_item_tax_table]=JSON.parse(decodeURIComponent($(table_id+"#"+tr_id+" #item_tax_data_"+tr_id+" p").html()))
									if(!empty(t_obj))
									{
										if(!empty(item_tax_obj))
										{
										var third_level_obj=t_obj;// merging 3rd level Group with item Comercial Group
										var t_obj=new Object();
										$.extend( t_obj, third_level_obj, item_tax_obj);
										}
									}
									else// if only one group in third level exists
									{
										t_obj=item_tax_obj;
									}
								}
					
					
									group_save_obj[group_name][i]['child_groups']=t_obj;
								 
						}
						
						
					 
					
					i++;
					 
				}
				
			})
		});
		return group_save_obj;
	}
	
	 
	  //closing of save Module validation	
}//closing of mail class
var Module = function ()
{
	 
	this.geditinternalcode='0';
 
	this.g_system_module_table_name='';
 
	this.g_user_schema_details_array='';
	this.g_is_module_for_new_or_edit='';
	this.html_id_arr=new Object();
 
	this.g_system_names_full_arr=new Object();
	this.html_id_criteria_arr='';
	this.all_multi_groups='';
	this.all_non_multi_groups='';
	

	this.main_menu_name="";
	this.sub_menu_name="";
	this.g_display_module_name="";
		
	this.g_str_module_name="";
	this.load_type="";
	this.g_str_module_id="";
	
	this.g_module_parent_menu="";
	
	this.g_multi_group="";
	this.s_module_onload="";
	this.s_module_pre_save="";
	this.s_module_after_edit="";
	
	 
	this.t_item_tax_data="";//to store Item Level Object On change of tax structure
	this.t_tax_structure_exists="";// to check wheather this module has tax structure exists on not
	this.t_tax_structure_item_table="";// po_items_group_table_name
	this.t_tax_structure_item_tax_table="";// po_items_tax_structure_group_table_name
	this.t_tax_structure_doc_table="";// po_doc_tax_group_table_name
	this.upload_type="";// po_doc_tax_group_table_name
	this.header_details="";// po_doc_tax_group_table_name
	this.AssignDisplayModuleName=function()
	{
		 if(!empty(this.main_menu_name))
		{
			$("#span_main_menu").html(this.main_menu_name);
			$("#bc_main_menu_list").show();
		}
		if(!empty(this.sub_menu_name))
		{
			$("#span_sub_main_menu").html(this.sub_menu_name);
			$("#bc_sub_menu_list").show();
		}
		
		if(!empty(this.g_display_module_name))
		{
			$("#display_module_name").html(this.g_display_module_name);
			$("#bc_display_module_name").show();
		}
		 
		$("#breadcrum_right").html("<h4 style='margin:0;padding:0;color:#F87B21;font-weight:bold;'>"+this.g_display_module_name+"<h4>").show();
	},
	this.HandleEntryScreenGrid=function()
	{ 
		if(this.header_details['view_type']=='EntryScreen' && (this.header_details['include_view']=='1' || this.header_details['include_save']=='1'))
		{
			this.loadGridScreen("EntryScreen","grid_"+this.g_system_module_table_name,this.g_system_module_table_name)
		}
	},
	this.loadGridScreen=function(load_type,div_id,grid_file_name)
	{
		if(load_type=="EntryScreen")
		{
		var main="<table  id='table_grid_"+grid_file_name+"' class='scroll' ></table> <div id='sub_grid_div_"+grid_file_name+"'   class='scroll' style='text-align:center;'></div>";
		$("#"+div_id).html(main);
		var th = document.getElementsByTagName('head')[0];
		var s = document.createElement('script');
		s.setAttribute('type','text/javascript');
		var path="grid_display_files/"+$g_app_tye+"/"+grid_file_name+".js";
		 
		s.setAttribute('src',path);
		th.appendChild(s); 
		$('#grid_'+grid_file_name).append("<span style='line-height:30px;color:#405399;'>Please double click on row to edit</span>");
		}
	}
    this.InitModule=function()
	{
		if(this.g_is_module_for_new_or_edit=="Add")
		{
			this.geditinternalcode=0;
		}
		var html_save="";
				
		if(this.load_type=="FW")
		{
				 // $("#module_menu_links").html(links_data);
				// $("#page_main_tab_div").parent().after(footer_link);
		}
			 
			all_obj.AssignRefModuleDefaultValues(this.g_system_module_table_name);
			all_obj.AssignMenuEvents(this.g_system_module_table_name);
			
				 var js_path=this.header_details['js_path'];
				  
				  if(!empty(js_path))
				 {
					
					 js_path_arr=js_path.split(";");
					for(i=0;i<js_path_arr.length;i++)
					{
						 
						includeJsFilesMannually(js_path_arr[i], function(){
					});
					}
				 }
		 
				 this.s_module_onload=this.g_user_schema_details_array.data[1][0].s_module_onload;
				this.s_module_pre_save=this.g_user_schema_details_array.data[1][0].s_module_pre_save;
				 this.s_module_after_edit=this.g_user_schema_details_array.data[1][0].s_module_after_edit;
				var is_ref_module_code_lov_cnt=0;			 	
	 							 
			for($a=0;$a<this.g_user_schema_details_array.data[1].length;$a++)
			{
				
				$obj=this.g_user_schema_details_array.data[1];
				var  data_type=$obj[$a]['Type'];
				this.g_system_names_full_arr[$obj[$a]['system_name']]=new Object();
				this.html_id_arr[$obj[$a]['system_name']]=$obj[$a]['system_name'];
				this.g_system_names_full_arr[$obj[$a]['system_name']]['Type']=$obj[$a]['Type'];
				this.g_system_names_full_arr[$obj[$a]['system_name']]['optional']=$obj[$a]['optional'];
				this.g_system_names_full_arr[$obj[$a]['system_name']]['is_ref_module_code_lov']=$obj[$a]['is_ref_module_code_lov'];
				this.g_system_names_full_arr[$obj[$a]['system_name']]['on_exit']=$obj[$a]['on_exit'];
				var is_ref_module_code_lov=$obj[$a]['is_ref_module_code_lov'];
				if(is_ref_module_code_lov==1)
					is_ref_module_code_lov_cnt++;
				var system_name=$obj[$a]['system_name'];
					if(data_type=="Number")
					{
						 
					}	
					if(data_type=="Date")
					{
					var date_default_val_obj=(this.g_user_schema_details_array.data['date_fields_default_values']);
						// $("#m_"+this.g_system_module_table_name+" #"+system_name).mask({mask: "##/##/####"}) ; 
						// $("#m_"+this.g_system_module_table_name+" #"+system_name).val(date_default_val_obj[system_name]);
					}
					else if(data_type=="DateTime")
					{
						var date_default_val_obj=(this.g_user_schema_details_array.data['date_fields_default_values']);
						// $("#m_"+this.g_system_module_table_name+" #"+system_name).mask({mask: "##/##/#### ##:##:##"}) ;  
						// $("#m_"+this.g_system_module_table_name+" #"+system_name).val(date_default_val_obj[system_name]);
					}
										
					if(data_type=="Multi Search")
					{
						POPUP.AssignJqueryMultiSelectAutoComplete($obj[$a]['ref_module_table_name'],this.g_system_module_table_name,$obj[$a]['system_name']);
					}
					else if(data_type=="Reference Data" && is_ref_module_code_lov==0)
					{
						var ref_data_obj=new Object();
						ref_data_obj['ref_module_code_ref_field']=$obj[$a]['ref_module_code_ref_field'];
						var pop_up_ref_obj=new Object();
						if(ref_data_obj['ref_module_code_ref_field']>0)
						{
							pop_up_ref_obj['ref_module_code_ref_field_db_field']=$obj[$a]['ref_module_code_ref_field_db_field'];
							pop_up_ref_obj['ref_module_code_ref_field_on']=$obj[$a]['ref_module_code_ref_field_on'];
							pop_up_ref_obj['ref_module_code_ref_field_const']=$obj[$a]['ref_module_code_ref_field_const'];
							this.g_system_names_full_arr[$obj[$a]['system_name']]['pop_up_ref_obj']=pop_up_ref_obj;
						}
						ref_data_obj['ref_module_code_ref_field_db_field']=$obj[$a]['ref_module_code_ref_field_db_field'];
						ref_data_obj['ref_module_code_ref_field_on']=$obj[$a]['ref_module_code_ref_field_on'];
						ref_data_obj['ref_module_code_ref_field_const']=$obj[$a]['ref_module_code_ref_field_const'];
					 
							POPUP.AssignJqueryAutoCompleteNew($obj[$a]['ref_module_table_name'],this.g_system_module_table_name,$obj[$a]['system_name'],ref_data_obj,$obj[$a]['ref_module_code']);
					}
					 						
			}
			if(is_ref_module_code_lov_cnt>0)
 	  		  AssignRefModuleLovValues(this.g_str_module_id,this.g_system_module_table_name);

			FWMultiGrid.FormFWMultiGroupGrid(this.g_system_module_table_name);
		
			this.InitMultiGroupModule();			
			// OnloadModule();
			eval(this.s_module_onload);
			
				this.AssignDisplayModuleName();
				this.HandleEntryScreenGrid();
			// App.init();
			 

		if(this.g_is_module_for_new_or_edit=="Edit")
		{
			all_obj.GetSchemaModuleDetailsForUpdateNew(this.g_system_module_table_name);
		}			
	},//close of init 
	this.InitMultiGroupModule=function()
	{
		var multi_group_arr=this.g_user_schema_details_array.data['multi_group'];
								if(!empty(multi_group_arr))
								{
									jQuery.each(multi_group_arr, function(k, v)  
									{ 
										var ele_obj=v['elements'];
										var is_grid_edit_inline=v['is_grid_edit_inline'];
										var group_id=v['group_id'];
										
											if(!empty(ele_obj))
											{
												jQuery.each(ele_obj, function(kk, vv)  
												{
													var data_type=(vv['Type']);
													var system_name=(vv['system_name']);
													var ref_module_code=(vv['ref_module_code']);
													if(data_type=="Number")
													{
													
														/* $("#"+system_name).live('focus', function () {
														$(this).select();  
														});
														 $("#"+system_name).live('mouseup', function () {
														$(this).select();  
														}); */
													}
													var is_ref_module_code_lov=(vv['is_ref_module_code_lov']);
													if(data_type=="Multi Search")
													{
														AssignJqueryMultiSelectAutoComplete(system_name,ref_module_code);
													}
													else if(data_type=="Reference Data" && is_ref_module_code_lov==0)
													{
														var ref_data_obj=new Object();
														ref_data_obj['ref_module_code_ref_field']="";
														ref_data_obj['ref_module_code_ref_field_db_field']="";
														ref_data_obj['ref_module_code_ref_field_on']="";
														ref_data_obj['ref_module_code_ref_field_const']="";
														//AssignJqueryAutoComplete(system_name,ref_module_code,ref_data_obj);
													}
												});
											}	
									});
								}
							
	  }//close of InitMultiGroupModule
};
//getModulesDetailsNew('Brand Master',42,'Add','Brand Master','New')
all_obj=new AllModules();
// INPCV2: MainPage.js installs window.getModulesDetailsNew for #home_dashboard.
// A function declaration would hoist-overwrite that before we can save it - use assignment.
(function () {
	var inpcGetModulesDetailsNew = window.getModulesDetailsNew;
	window.getModulesDetailsNew = function (system_module_name, module_name, module_id, is_module_for_new_or_edit, display_module_name, geditinternalcode, callback_func) {
		// Prefer INPC single-pane FrameWork opener (schema/API via CallGetModuleDetailsNew).
		if (typeof inpcGetModulesDetailsNew === "function" && document.getElementById("home_dashboard")) {
			return inpcGetModulesDetailsNew(
				system_module_name,
				module_name,
				module_id,
				is_module_for_new_or_edit,
				display_module_name,
				geditinternalcode,
				callback_func
			);
		}

		if (typeof showLoader === "function") showLoader("Please wait...");
		else if (typeof App !== "undefined" && typeof App.blockUI === "function") App.blockUI();

		if ($("#m_" + system_module_name).length > 0) {
			div_id = "section-bar-" + module_id;
			$path = (typeof window.inpcModuleHtmlPath === "function")
				? window.inpcModuleHtmlPath(system_module_name)
				: ("html_files/" + ($g_app_tye || "INPC") + "/" + String(system_module_name || "").replace(/\\/g, "/").replace(/^\/+/, "").replace(/\.html$/i, "") + ".html?r=" + Math.random());
			$("#" + div_id).load($path, function (response, status, xhr) {
				if (status == "error") {
					var msg = "Sorry but there was an error: ";
					alert(msg + xhr.status + " " + xhr.statusText + " Please close browser and login once again");
					App.unblockUI();
					if (typeof hideLoader === "function") hideLoader();
					return;
				}
				CallGetModuleDetailsNew(system_module_name, is_module_for_new_or_edit, module_name, module_id, geditinternalcode, "FW", callback_func);
			});
			$("#li_" + module_id).trigger("click");
			return;
		}
		tabs_cnt = $("#menu_tabs li:visible").length;

		if (tabs_cnt < 6) {
			$("#menu_tabs li").removeClass("tab-current");
			var tabs = "";
			var section_bar = "";

			tabs = "<li id='li_" + module_id + "'><a href='#section-bar-" + module_id + "' class='fa fa-dashboard'> &nbsp;<span></span></a></li>";
			section_bar += "<section id='section-bar-" + module_id + "' style='padding: 0px 5px 5px;'></section>";

			$("#menu_tabs").append(tabs);
			$("#section_bars").append(section_bar);

			(function () {
				[].slice.call(document.querySelectorAll(".sttabs")).forEach(function (el) {
					new CBPFWTabs(el);
				});
			})();
			var elems = Array.prototype.slice.call(document.querySelectorAll(".js-switch"));
			$(".js-switch").each(function () {
				new Switchery($(this)[0], $(this).data());
			});
			$("section[id^='section-bar-']").removeClass("content-current");
			$("#li_" + module_id).trigger("click");

			setTimeout(function () {
				div_id = "section-bar-" + module_id;

				$path = (typeof window.inpcModuleHtmlPath === "function")
				? window.inpcModuleHtmlPath(system_module_name)
				: ("html_files/" + ($g_app_tye || "INPC") + "/" + String(system_module_name || "").replace(/\\/g, "/").replace(/^\/+/, "").replace(/\.html$/i, "") + ".html?r=" + Math.random());
				$("#li_" + module_id).html(
					"<a href='#section-bar-" +
						module_id +
						"' class='fa fa-dashboard' style='border-radius:5px'> &nbsp;<span>" +
						display_module_name +
						"</span></a><div><button type='button' class='clsbtn' onclick='javascript:all_obj.close(&quot;" +
						system_module_name +
						"&quot;,&quot;" +
						module_id +
						"&quot;);'>&times;</button></div>"
				);
				$("#m_" + system_module_name).remove();
				$(".contents").show();
				$("#" + div_id).show();
				$("#page_main_home_div").hide();
				$("#main_body").show();
				$("#" + div_id).load($path, function (response, status, xhr) {
					if (status == "error") {
						var msg = "Sorry but there was an error: ";
						alert(msg + xhr.status + " " + xhr.statusText + " Please close browser and login once again");
						App.unblockUI();
						if (typeof hideLoader === "function") hideLoader();
						return;
					}

					HandleSectionBarMinheight();
					CallGetModuleDetailsNew(system_module_name, is_module_for_new_or_edit, module_name, module_id, geditinternalcode, "FW", callback_func);
				});
			}, 500);
		} else {
			ShowAlertMsg("You have opened maximum menus");
			App.unblockUI();
			if (typeof hideLoader === "function") hideLoader();
		}
	};
})();
 function getModulesDetailsNewForPopup(system_module_name,module_name,display_module_name,module_id,callback_func)
 { 
	var dialog_color_arr = new Array("#00A0B1", "#643EBF", "#BF1E4B", "#FF981D", "#00A600", "#FF0097");  
	var jt_db=getCookie("jt_db");
	var path="html_modules/modules/"+jt_db+"/module_"+module_id+".html";
 	
	 var div_id="popup_module_dialog_"+module_id;	
	 var popup_content_div_id="popup_content_"+module_id;
	var dialog_state = $("#"+div_id).dialogExtend("state");
	var is_dialog_open = $("#"+div_id).dialog('isOpen');
	var dialog_count = $(".ui-dialog[aria-describedby*='popup_module_dialog_']:visible").length;
	
	if(is_dialog_open  &&  dialog_state == 'minimized' )
	{
		$("#"+div_id).dialogExtend("restore");
	}
	else if(is_dialog_open  && (dialog_state == 'maximized' || dialog_state == 'normal') )
	{
		$("#"+div_id).dialog("open");
	}
	else
	{
		if(dialog_count==6)
		{
			ShowAlertMsg("Maximum Popup Windows Opened, Please Close Any One To Open New.");
			return false;
		}
		{
			$('#'+div_id).dialog("close")
			$('#'+div_id).remove();
		 
			var dialog_bred_crum="<div  style='margin-left: 0px;'>";
				dialog_bred_crum+="<div class='col-md-12 page-content' style='padding:0; min-height:0;' id='popup_bc'>";
				dialog_bred_crum+="<ul class='page-breadcrumb breadcrumb' style='margin-bottom: 0;'>";
				dialog_bred_crum+="				<li class='btn-group' id='module_menu_action' style='right:0;'>";
				dialog_bred_crum+="					<button type='button' class='btn blue dropdown-toggle' data-toggle='dropdown' data-hover='dropdown' data-delay='1000' data-close-others='true'>";
				dialog_bred_crum+="					<span>";
				dialog_bred_crum+="						Actions";
				dialog_bred_crum+="					</span>";
				dialog_bred_crum+="					<i class='fa fa-angle-down'></i>";
				dialog_bred_crum+="					</button>";
				dialog_bred_crum+="					<ul class='dropdown-menu pull-right' id='module_menu_links' role='menu'></ul>";
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="				<li>";
				dialog_bred_crum+="				<i class='fa fa-home'></i>";
				dialog_bred_crum+="				<a href='#' onclick='home('home_dashboard');'>";
				dialog_bred_crum+="					Home";
				dialog_bred_crum+="				</a>";
				dialog_bred_crum+="				<i class='fa fa-angle-right'></i>";
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="			<li>";
				dialog_bred_crum+="				<a href='#' id='span_parent_menu'> Dashboard</a>";
				dialog_bred_crum+="				<i class='fa fa-angle-right' id='span_parent_menu_right'></i>";
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="			<li style='display:none;'>";
				dialog_bred_crum+="				<a href='#' id='span_main_menu'></a>";
				dialog_bred_crum+="				<i class='fa fa-angle-right'></i>";
				dialog_bred_crum+="			</li>	";
				dialog_bred_crum+="			<li>";
				dialog_bred_crum+="				<a href='#' id='display_module_name' onclick='javascript:Clearfields();'></a>	";					
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="			</ul>";
				dialog_bred_crum+="</div>";
				dialog_bred_crum+="</div>";
				  
			  $("#page-content").append("<div id='"+div_id+"' title='' style='padding-left:0;'><div id='popup_breadcrumb '  class='col-md-12'>"+dialog_bred_crum+"</div><div id='"+popup_content_div_id+"'></div> </div>");
			
				var dialog_height = screen.height-200;
					IncludeFrameWorkSupportFiles(); 
				  $('#'+div_id).dialog({"title" : display_module_name,
				"width" : "99%",
				"height" : dialog_height, position: [5,50],
				resizable:true,
				draggable:true 

				}).dialogExtend({
				"closable" : true,
				"maximizable" : true,
				"collapsable" : false,
				"minimizable" :true,
				"minimizeLocation" :"left",
				"dblclick" : "collapse",
				"titlebar" : false,
				"maximize" : function(evt,ui) 
				   {$(this).parent().css("top","50px"); },
				"close" : function(evt,ui) 
				   {ShowAlertMsg("asd");},

				icons:{"close":"ui-icon-close"}
				});
				
				
				
				$('#'+popup_content_div_id).load(path,function() 
				{
				 
						CallGetModuleDetailsNew(system_module_name,'Add',module_name,module_id,0,'PopUp', function () {
								if (empty(callback_func))
									return;
								else
									eval(callback_func);
							});
				});
				
				$(".ui-dialog-titlebar-close").css("cursor" ,"pointer").css("padding" ,"0").css("height" ,"18px");
				$("#"+div_id).siblings('.ui-widget-header').css("background",dialog_color_arr[dialog_count]).css("border" ,"none");
				$(".ui-widget-header .ui-dialog-title").css("color","#ffffff");
				$(".ui-dialog").css("z-index","10000").css('box-shadow','1px 1px 5px 0px rgba(0,0,0,0.75)');
				$(".ui-dialog-titlebar").css('padding','1px 10px');
		}
	}
 }
 // to open Direclty from Other Module in Popup, same as above except Passing in Edit Mode
 function getModulesDetailsNewForPopupForEdit(system_module_name,module_name,display_module_name,module_id,geditinternalcode,callback_func)
 { 
	var dialog_color_arr = new Array("#00A0B1", "#643EBF", "#BF1E4B", "#FF981D", "#00A600", "#FF0097");  
	var jt_db=getCookie("jt_db");
	var path="html_modules/modules/"+jt_db+"/module_"+module_id+".html";
 	
	 var div_id="popup_module_dialog_"+module_id;	
	 var popup_content_div_id="popup_content_"+module_id;
	var dialog_state = $("#"+div_id).dialogExtend("state");
	var is_dialog_open = $("#"+div_id).dialog('isOpen');
	var dialog_count = $(".ui-dialog[aria-describedby*='popup_module_dialog_']:visible").length;
	
	if(is_dialog_open  &&  dialog_state == 'minimized' )
	{
		$("#"+div_id).dialogExtend("restore");
	}
	else if(is_dialog_open  && (dialog_state == 'maximized' || dialog_state == 'normal') )
	{
		$("#"+div_id).dialog("open");
	}
	else
	{
		if(dialog_count==6)
		{
			ShowAlertMsg("Maximum Popup Windows Opened, Please Close Any One To Open New.");
			return false;
		}
		{
			$('#'+div_id).dialog("close")
			$('#'+div_id).remove();
		 
			var dialog_bred_crum="<div  style='margin-left: 0px;'>";
				dialog_bred_crum+="<div class='col-md-12 page-content' style='padding:0; min-height:0;' id='popup_bc'>";
				dialog_bred_crum+="<ul class='page-breadcrumb breadcrumb' style='margin-bottom: 0;'>";
				dialog_bred_crum+="				<li class='btn-group' id='module_menu_action' style='right:0;'>";
				dialog_bred_crum+="					<button type='button' class='btn blue dropdown-toggle' data-toggle='dropdown' data-hover='dropdown' data-delay='1000' data-close-others='true'>";
				dialog_bred_crum+="					<span>";
				dialog_bred_crum+="						Actions";
				dialog_bred_crum+="					</span>";
				dialog_bred_crum+="					<i class='fa fa-angle-down'></i>";
				dialog_bred_crum+="					</button>";
				dialog_bred_crum+="					<ul class='dropdown-menu pull-right' id='module_menu_links' role='menu'></ul>";
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="				<li>";
				dialog_bred_crum+="				<i class='fa fa-home'></i>";
				dialog_bred_crum+="				<a href='#' onclick='home('home_dashboard');'>";
				dialog_bred_crum+="					Home";
				dialog_bred_crum+="				</a>";
				dialog_bred_crum+="				<i class='fa fa-angle-right'></i>";
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="			<li>";
				dialog_bred_crum+="				<a href='#' id='span_parent_menu'> Dashboard</a>";
				dialog_bred_crum+="				<i class='fa fa-angle-right' id='span_parent_menu_right'></i>";
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="			<li style='display:none;'>";
				dialog_bred_crum+="				<a href='#' id='span_main_menu'></a>";
				dialog_bred_crum+="				<i class='fa fa-angle-right'></i>";
				dialog_bred_crum+="			</li>	";
				dialog_bred_crum+="			<li>";
				dialog_bred_crum+="				<a href='#' id='display_module_name' onclick='javascript:Clearfields();'></a>	";					
				dialog_bred_crum+="			</li>";
				dialog_bred_crum+="			</ul>";
				dialog_bred_crum+="</div>";
				dialog_bred_crum+="</div>";
				  
			  $("#page-content").append("<div id='"+div_id+"' title='' style='padding-left:0;'><div id='popup_breadcrumb '  class='col-md-12'>"+dialog_bred_crum+"</div><div id='"+popup_content_div_id+"'></div> </div>");
			
				var dialog_height = screen.height-200;
					IncludeFrameWorkSupportFiles(); 
				  $('#'+div_id).dialog({"title" : display_module_name,
				"width" : "99%",
				"height" : dialog_height, position: [5,50],
				resizable:true,
				draggable:true 

				}).dialogExtend({
				"closable" : true,
				"maximizable" : true,
				"collapsable" : false,
				"minimizable" :true,
				"minimizeLocation" :"left",
				"dblclick" : "collapse",
				"titlebar" : false,
				"maximize" : function(evt,ui) 
				   {$(this).parent().css("top","50px"); },
				"close" : function(evt,ui) 
				   {ShowAlertMsg("asd");},

				icons:{"close":"ui-icon-close"}
				});
				
				
				
				$('#'+popup_content_div_id).load(path,function() 
				{
					 
						CallGetModuleDetailsNew(system_module_name,'Edit',module_name,module_id,geditinternalcode,'PopUp', function () {
								if (empty(callback_func))
									return;
								else
									eval(callback_func);
							});
				});
				
				$(".ui-dialog-titlebar-close").css("cursor" ,"pointer").css("padding" ,"0").css("height" ,"18px");
				$("#"+div_id).siblings('.ui-widget-header').css("background",dialog_color_arr[dialog_count]).css("border" ,"none");
				$(".ui-widget-header .ui-dialog-title").css("color","#ffffff");
				$(".ui-dialog").css("z-index","10000").css('box-shadow','1px 1px 5px 0px rgba(0,0,0,0.75)');
				$(".ui-dialog-titlebar").css('padding','1px 10px');
		}
	}
 }	
 
function CallGetModuleDetailsNew(system_module_name,is_module_for_new_or_edit,module_name,module_id,geditinternalcode,load_type,callback)
{
	// console.log(system_module_name);
	HandleSectionBarMinheight();
	
	 if(ajax_req) ajax_req.abort();
	 ajax_req=$.ajax({
			 type: "POST",
			   // async:false,
			   error:AjaxErrorMessage,
				url: $host_url+"system/getGeneralUserSchemaDetails",      
				//ADDED TO ACCOMPLISH THE USER RIGHTS ON NOV-7-2008 is_module_for_new_or_edit
				data:"&module_id="+module_id,
				error:function (xhr, ajaxOptions, thrownError){
					 App.unblockUI();
					 if (typeof hideLoader === "function") hideLoader();
					  swal("Error",thrownError+xhr.responseText, "warning");
						 
					 
				},

			   success: function GeneralUserSchemaDetailsResponse($responce)
						{
							 //try  
							{
								App.unblockUI();
								if (typeof hideLoader === "function") hideLoader();

								$responce = eval('(' + $responce + ')');  
								if($responce.error_code=='-9')
								{
									ShowAlertMsg($responce.data);CallLogout();
									return false;
								}
								var m_obj = new Module();
								 
									 m_obj.geditinternalcode=geditinternalcode;
							 
								m_obj.g_is_module_for_new_or_edit=is_module_for_new_or_edit;
							
								m_obj.load_type=load_type;
								m_obj.g_str_module_name=module_name;
								m_obj.g_str_module_id=module_id;
							
								m_obj.g_user_schema_details_array=$responce;
								// m_obj.html_id_arr=$responce.data['html_id_arr'];
								m_obj.g_system_module_table_name=system_module_name
							 
						 
								m_obj.all_multi_groups=$responce.data['all_multi_groups'];
								m_obj.all_non_multi_groups=$responce.data['all_non_multi_groups'];	
								
								m_obj.g_display_module_name=$responce.data['header_details'][0]['display_name'];
								m_obj.main_menu_name=$responce.data['header_details'][0]['menu_name'];
								m_obj.sub_menu_name=$responce.data['header_details'][0]['sub_menu_name'];
								
								
								m_obj.g_multi_group=$responce.data['multi_group'];
							 
								m_obj.upload_type=$responce.data['upload_type'];
								m_obj.header_details=$responce.data['header_details'][0];
							 
	
	
								if(!empty($responce.data['multi_group']))
								{
									$.each($responce.data['multi_group'], function (gk,gv) { 		
			
									var group_table_name=gv.table_name;
									var group_name=gv.group_name;
									var parent_group=gv.parent_group;

									var grp_ele_arr=gv.elements;
									var grp_system_name_full_arr=new Object();
									if(!empty(grp_ele_arr))
									{
										 $.each(grp_ele_arr, function (ek,ev) {			
											var data_type=ev.Type;
											var db_field=ev.db_field;
											var system_name=ev.system_name;
											grp_system_name_full_arr[system_name]=new Object();
											grp_system_name_full_arr[system_name]['data_type']=data_type;
											});
											 
											m_obj.g_multi_group[group_table_name]['grp_system_name_full_arr']=grp_system_name_full_arr;
									}		
										});
								}	
								
								
								$("#m_"+m_obj.g_system_module_table_name+"  :input:visible:first").focus(); 
								all_obj[m_obj.g_system_module_table_name]=m_obj;
								all_obj[m_obj.g_system_module_table_name]['msave']="Yes";
							
								m_obj.InitModule();
								if (callback && typeof(callback) === "function")
									callback();

							}
						 /*   catch(err)
							{
								txt= err.message;
								App.unblockUI();
								bootbox.alert(txt+"<br>"+$responce+" in CallGetModuleDetailsNew");
							}   */	
						}
			 });
	
}
function AssignRefModuleLovValues(schema_id,system_module_table_name)
{
	 ajax_req=$.ajax({
		
		type: "POST",
		async:false,
		url: $host_url+"auto_complete/AssignRefModuleLovValues",   
		dataType: "json",	    
		error:AjaxErrorMessage,
		data:"schema_id="+schema_id+"&system_module_table_name="+system_module_table_name,
		success: function AssignRefModuleLovValuesResponse(responce)
		{
			if(responce.error_code=='-9')
			{
			  ShowAlertMsg($responce.data);
			  return false;
			}
			if(!isNull(responce.data))
			{
				var data_set=responce.data;
				$.each(data_set,function(k,v)
				{
					var system_name=k;
					if(!empty(v))
					{
						var str=" <option value=''>Select</option>";
						$.each(v,function(kk,vv)
						{
							 str+=" <option value='"+vv['internal_code']+"'>"+vv['value']+"</option>";
						});
						$("#m_"+system_module_table_name+" #"+system_name).html(str);
					}
				});
			}
		} 
	});
	
}