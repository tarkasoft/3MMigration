/* INPCV2: map legacy ShowErrorMsg to ShowAlertMsg when missing */
if (typeof ShowErrorMsg !== 'function') {
	function ShowErrorMsg(msg) {
		if (typeof ShowAlertMsg === 'function') { ShowAlertMsg(msg); }
		else { alert(String(msg)); }
	}
}
ac_ajax=null;
 
function split(val) {
	return val.split(/;\s*/);
}
function extractLast( term ) {
	return split(term).pop();
}


POPUP={
	 
		OpenFWPopup : function (p_pop_up_table_name,p_calling_table_name,system_name,ref_module_display_name)
		{
			 read_only_att=$("#m_"+p_calling_table_name+" #txt_ref_schema_"+system_name).attr("readonly");//.toLowerCase();
			 if(read_only_att =='readonly') return;
			try
			{
				clicked_id_system_name=system_name;
			calling_table_name=p_calling_table_name;
			pop_up_table_name=p_pop_up_table_name;
		 
			var file_name="pop_up_"+p_pop_up_table_name+".js";
			search_ref_module_db_field="";
			search_ref_module_value="";
			ref_data_obj="";
			 
			 
			 /* $("#ref_display_popup").popup({
			 escape: "true" ,
			  opacity: 0.6,
			  transition: "all 0.3s",  autozindex: true 
			});
	   */
			all_data_obj=this.GetAllDataObjects(p_calling_table_name);
															  
			
			
			var main="<table id='table_grid1' class='scroll'   ondblclick= POPUP.PopUpOnDBClickEvent('"+p_pop_up_table_name+"','"+p_calling_table_name+"','"+system_name+"'); ></table> <div id='sub_grid_div1' class='scroll' style='text-align:center;'></div>";
			 
				$('#ref_display_popup_title').html(' ');
			 
		 // $("#ref_display_popup_data").html(main+" <div><span id='open_popup_value'></span><div>");
		  // $('#ref_display_popup').popup('show');
		    // $('#info_point_popup_title').html('Customer Details');
			
			
			
			// $("#fw_ref_pop_up_modal .modal-dialog").css("width","");
              var fwModalEl = document.getElementById('fw_ref_pop_up_modal');
              if (fwModalEl && window.bootstrap && bootstrap.Modal) {
                bootstrap.Modal.getOrCreateInstance(fwModalEl).show();
              } else if (window.jQuery && typeof jQuery(fwModalEl).modal === 'function') {
                jQuery("#fw_ref_pop_up_modal").modal('show');
              }
              var __fwTitle = (ref_module_display_name != null && String(ref_module_display_name).trim() !== "")
                ? String(ref_module_display_name).trim()
                : String(p_pop_up_table_name || "Lookup");
              $('#cir_pop_up_title').html("<span style='color:#008299;font-weight:bold'></span>");
              $('#cir_pop_up_title span').text(__fwTitle);
              $("#fw_ref_pop_up_modal .modal-dialog").css({"max-width":"760px","width":"92vw","margin":"1.25rem auto"});
              $("#fw_ref_pop_up_modal .modal-body").css({"padding-left":"0.75rem","padding-right":"0.75rem"});
              


	
        

		$("#fw_ref_pop_up_modal #fw_ref_pop_up_body").html(main+" <div><span id='open_popup_value'></span><div>");
		
		
			var th = document.getElementsByTagName('head')[0];
			var s = document.createElement('script');
			s.setAttribute('type','text/javascript');
			 
			var path="grid_display_files/"+$g_app_tye+"/"+file_name;
			 
			s.setAttribute('src',path);
			th.appendChild(s);

		$("#fw_ref_pop_up_modal #fw_ref_pop_up_body").append("<span style='float:left;line-height:30px;color:#405399;'>Please double click on row to select</span>");
			setTimeout(function () {
				try {
					var $g = jQuery("#table_grid1");
					if ($g.length && $g[0] && $g[0].grid) {
						var bw = Math.floor(($("#fw_ref_pop_up_modal #fw_ref_pop_up_body").width() || $(window).width() * 0.9) - 8);
						if (bw > 200) { $g.jqGrid("setGridWidth", bw, true); }
					}
				} catch (eW) { /* ignore */ }
			}, 250);
	
			}
			catch(err)
				{
					txt= err.message;
					// $.unblockUI();
					  ShowErrorMsg(txt);
				}				
		},
		
		AssignJqueryMultiSelectAutoComplete  : function (pop_up_table_name,calling_table_name,system_name)
		 {
			 
				if($("#m_"+calling_table_name+" #"+system_name).length>0)
				{
				 
				
					$myinput=$("#m_"+calling_table_name+" #"+system_name)
						// don't navigate away from the field on tab when selecting an item
						.bind( "keydown", function( event ) {
							if ( event.keyCode === $.ui.keyCode.TAB &&
									$( this ).data( "autocomplete" ).menu.active ) {
								event.preventDefault();
							}
						})
						.autocomplete({
							source: function( request, response ) {
						 
								 $.ajax({
											type: "POST",									
											url: $host_url+"getAutoCompleteMultiSearchFromFrameWork",   
											data:"value="+extractLast(request.term)+"&system_name="+system_name+"&pop_up_table_name="+pop_up_table_name+"&calling_table_name="+calling_table_name,
											success:  function GetDashboardDetailsSuccess(v_response)
											{
											  v_response = eval('(' +  v_response + ')');
											 response(v_response.data);	
												$('ul.ui-autocomplete li a').css("color",'#403849');	
											} 
									});
								
							
							},
							open: function(event, ui) {
							var new_width=eval(parseFloat($("#"+system_name).width())+32);
							 var new_top=$("#"+system_name).offset()['top']+30;				 
						  jQuery(".ui-autocomplete").css("top", new_top);
							$(this).autocomplete("widget").css({
								"width": new_width,
								"min-heigh": 210,
								"height": 210 ,
								"z-index": 120000 ,
								"overflow": 'auto' 
							});
							},
							search: function() {
								// custom minLength
								var term = extractLast( this.value );
								 
								/* if ( term.length < 2 ) {
									return false;
								} */
							},
							focus: function() {
								// prevent value inserted on focus
								return false;
							},
							select: function( event, ui ) {
							 
								var terms = split( this.value );

								 					
									// remove the current input
									terms.pop();
									// add the selected item
									terms.push( ui.item.details_val );
									// add placeholder to get the comma-and-space at the end
									terms.push( "" );
									this.value = terms.join( ";" );
									return false;
								 
							}
					});
			 
				}	
			 },
		
		
		
		AsignPopUpDetailsValues:function(col_model_arr,id)
		{
			var a_data=jQuery("#table_grid1").getRowData(id);
			var pop_up_data=" <table border=0>";
			jQuery.each(a_data, function(ak, av) {	
			pop_up_data+="<tr><td><b>"+col_model_arr[ak]+"</b></td><td>:</td><td>"+av+"</td></tr>";
			});
			pop_up_data+="</table>";		
			$("#open_popup_value").html("");		 
			$("#open_popup_value").html(pop_up_data);	
			return true;	
		},
		PopUpOnDBClickEvent:function(pop_up_table_name,calling_table_name,system_name)
		{
			
			var id=jQuery("#table_grid1").getGridParam('selrow'); 
			if(id > 0) 
			{ 
		
			if(pop_up_table_name=='ia_user_master' && calling_table_name=='dd_create_new_request')
			{
				var enl_id=jQuery('#table_grid1').getRowData(id)['enl_id'];
				var name=jQuery('#table_grid1').getRowData(id)['name'];
				$("#show_employee_table #mmm_name").val(name);
				$("#show_employee_table #txt_ref_schema_mmm_code").val(enl_id);
			}
			else if(pop_up_table_name=='dd_vendor_master' && calling_table_name=='dd_create_new_request')
			{
				var vendor_code=jQuery('#table_grid1').getRowData(id)['vendor_code'];
				var vendor_name=jQuery('#table_grid1').getRowData(id)['vendor_name'];
				
				$("#vendor_details_table #txt_ref_schema_v_vendor_code").val(vendor_code);
				$("#vendor_details_table #v_vendor_name").val(vendor_name);
			}
			else if(pop_up_table_name=='sb_customer_master' && calling_table_name=='change_customer')
			{
				var __ccRow=jQuery('#table_grid1').getRowData(id);
				var __ccCode=__ccRow['code']||'';
				var __ccName=__ccRow['name']||'';
				$("#m_change_customer #ref_customer").val(id);
				$("#m_change_customer #txt_ref_schema_ref_customer").val(__ccCode+(__ccName?(' - '+__ccName):''));
				if(typeof ChangeCustomer!=='undefined'){
					ChangeCustomer._pendingCode=__ccCode;
					ChangeCustomer._pendingName=__ccName;
					ChangeCustomer._pendingInternal=id;
				}
			}
			else 
			{		
				this.GetModuleKeyDataForElement(pop_up_table_name,calling_table_name,system_name,id);
			}
			    var __fwHideEl = document.getElementById('fw_ref_pop_up_modal');
			    if (__fwHideEl && window.bootstrap && bootstrap.Modal) {
			    	var __inst = bootstrap.Modal.getInstance(__fwHideEl) || bootstrap.Modal.getOrCreateInstance(__fwHideEl);
			    	__inst.hide();
			    } else if (window.jQuery) {
			    	jQuery("#fw_ref_pop_up_modal").modal('hide');
			    } 
			} 
			else
			{ 
				alert("Please select row"); return;
			}
		},
		GetModuleKeyDataForElement:function(pop_up_table_name,calling_table_name,system_name,internal_code)
		{
			
		 
			$.ajax({
				   type: "POST",
					async:false,
				   url: $host_url+"auto_complete/GetModuleKeyDataForElement",
				   error:AjaxErrorMessage,
				   data: "pop_up_table_name="+pop_up_table_name+"&calling_table_name="+calling_table_name+"&system_name="+system_name+"&internal_code="+internal_code,
				   success: function GetModuleKeyDataForElementResponce( responce)
					{ 
						try
						{
							responce = eval('(' +  responce + ')');
							if( responce.error_code=='-9')
							{
								alert($responce.data);
								return false;
							}
							else if( responce.error_code=='0')
							{
								 
								$("#m_"+calling_table_name+" #txt_ref_schema_"+system_name).val(responce.data['0']['name']);
								$("#m_"+calling_table_name+" #"+system_name).val(responce.data['0']['internal_code']);
								var on_exit_event=$("#m_"+calling_table_name+" #txt_ref_schema_"+system_name).attr("on_exit");
								if(on_exit_event!='')
								{
								eval(on_exit_event);
								}
								 
							}
						}
						 catch(err)
						{
							txt= err.message;
							$.unblockUI();
							bootbox.alert(txt+"<br>"+responce);
						}	
					}
				});
		},
		GetAllDataObjects:function(calling_table_name)
		{
				var all_data_obj_ac=new Object();
				
				if(typeof(all_obj[calling_table_name])!='undefined')
				{
					var html_id_arr=all_obj[calling_table_name]['html_id_arr'];
					
					jQuery.each(html_id_arr,function (ak,av){
					all_data_obj_ac[ak]=new Object();
					all_data_obj_ac[ak]=$("#m_"+calling_table_name+" #"+ak).val();
					});	
					all_data_obj_ac = encodeURIComponent(JSON.stringify(all_data_obj_ac)); 
				}
			return 	all_data_obj_ac;					 
			
		},
		
		/** Ensure a ChangeCustomer-style spinner exists beside a ref autocomplete input. */
		EnsureAcSpinner:function(txt_selector, parent_sel, spinner_id)
		{
			var eid = String(spinner_id == null ? "" : spinner_id).replace(/^#/, "");
			if (!eid) return;
			var $parent = parent_sel ? $(parent_sel) : $(document);
			if ($parent.find("#" + eid).length) return;
			var $txt = $(txt_selector);
			if (!$txt.length) return;
			var html = '<span id="'+eid+'" class="inpc-ac-spinner" role="status" aria-hidden="true" hidden>'
				+ '<span class="spinner-border spinner-border-sm text-primary" aria-hidden="true"></span>'
				+ '</span>';
			var $grp = $txt.closest(".input-group");
			if ($grp.length) {
				if ($grp.css("position") === "static") {
					$grp.css("position", "relative");
				}
				$txt.addClass("pe-4");
				$grp.append(html);
			} else {
				if (!$txt.parent().hasClass("inpc-ac-field-wrap")) {
					$txt.wrap('<span class="inpc-ac-field-wrap position-relative d-block"></span>');
				}
				$txt.addClass("pe-4");
				$txt.after(html);
			}
		},
		AssignJqueryAutoCompleteNew:function(pop_up_table_name,calling_table_name,system_name,ref_data_obj)
		{
			 
				if($("#m_"+calling_table_name+" #"+system_name).length>0)
				{
				var search_ref_module_db_field=0;

				var ref_search_value=0;
				var txt_system_name=("#m_"+calling_table_name+" #txt_ref_schema_"+system_name);
				$(txt_system_name).unbind();
			 
				 $myinput=$(txt_system_name)
					// don't navigate away from the field on tab when selecting an item
					.bind( "keydown", function( event ) {
					
						if ( event.keyCode === $.ui.keyCode.TAB &&
								$( this ).data( "uiAutocomplete" ).menu.active ) {
							event.preventDefault();
						}
						if(event.keyCode==8)
						{
							$("#m_"+calling_table_name+" #"+system_name).val(0);
						}else if(event.keyCode==112)
						{
							$("#m_"+calling_table_name+" #pop_up_"+system_name+" img").trigger("click");
						}
					})
					.autocomplete({
						source: function( request, response ) {
					 
						
						if(!empty(ref_data_obj))
							{
								 
								var ref_mofule_code_active_field=ref_data_obj['ref_mofule_code_active_field'];
								if(ref_data_obj['ref_module_code_ref_field']!='0')
								{
									 search_ref_module_db_field=ref_data_obj['ref_module_code_ref_field_db_field'];
									if(ref_data_obj['ref_module_code_ref_field_on']!=0)
									{


									 ref_search_value= $("#m_"+calling_table_name+" #"+ref_data_obj['ref_module_code_ref_field_on']).val();							}

									else
									{
									 ref_search_value=ref_data_obj['ref_module_code_ref_field_const'];
									}
								}
							}
						 all_data_obj=POPUP.GetAllDataObjects(calling_table_name);
					  var lstr_query_string='';
					   lstr_query_string+='value='+encodeURIComponent(request.term);
						lstr_query_string+="&system_name="+system_name;
					   lstr_query_string+="&pop_up_table_name="+pop_up_table_name;
				 
					   lstr_query_string+="&calling_table_name="+calling_table_name;
					 
						// lstr_query_string+="&ref_search_value="+ref_search_value+"&search_ref_module_db_field="+search_ref_module_db_field+"&ref_mofule_code_active_field="+ref_mofule_code_active_field;
					   // lstr_query_string+="&all_data_obj="+all_data_obj;
						$("#m_"+calling_table_name+" #"+system_name).val(0);
						 var ac_parent = "#m_"+calling_table_name;
						 var ac_spinner_id = system_name + "_ac_spinner";
						 try {
						 	if (typeof POPUP.EnsureAcSpinner === "function") {
						 		POPUP.EnsureAcSpinner(txt_system_name, ac_parent, ac_spinner_id);
						 	}
						 } catch (eAcEns) { /* ignore */ }
						 if(ac_ajax) ac_ajax.abort();
						 ac_ajax=$.ajax({
						 	 dataType: "json",
						 	type : 'Get',
						 	  url: $host_url+"auto_complete/getAutoCompleteFromFrameWorkNew",  
						 	  data: lstr_query_string,
						 	  beforeSend: function () {
						 		try {
						 			if (window.Common && Common.ShowAcSpinner) {
						 				Common.ShowAcSpinner(ac_parent, ac_spinner_id);
						 			}
						 		} catch (eAcShow) { /* ignore */ }
						 	  },
						 	  complete: function () {
						 		try {
						 			if (window.Common && Common.HideAcSpinner) {
						 				Common.HideAcSpinner(ac_parent, ac_spinner_id);
						 			}
						 		} catch (eAcHide) { /* ignore */ }
						 		$(txt_system_name).removeClass('ui-autocomplete-loading');
						 	  },
						 	  error: function(data) {
						 	    $(txt_system_name).removeClass('ui-autocomplete-loading'); 
						 		},
						 	  success: function getAutoCompleteFromFrameWorkNewResponce(v_response)
						 		{
						 				 
						 				   $(txt_system_name).removeClass('ui-autocomplete-loading'); 
						 				 response(v_response.data);	
						 					$('ul.ui-autocomplete li a').css("color",'#403849');	
						 		} 
						 		});
							
						
						},
						open: function(event, ui) {
							var $menu = $(this).autocomplete("widget");
							$menu.addClass("inpc-ac-scroll");
							$menu.css({ maxHeight: "280px", overflowY: "auto", overflowX: "hidden" });
						},
						search: function() {
							 
							// custom minLength
							var term = extractLast( this.value );
							 
							 /*  if ( term.length < 2 ) {
								return false;
							}   */
						},
						focus: function() {
							// prevent value inserted on focus
							return false;
						},
						select: function( event, ui ) {
							this.value = this.value;
							POPUP.GetModuleKeyDataForElement(pop_up_table_name,calling_table_name,system_name,ui.item.internal_code)
							//autoCompleteSelectText(txt_system_name,system_name,this.id,ui.item.internal_code ,module_id);
							return false;
						},
						 minLength: 1,max:10,
						scroll:true
				});
			  }
			 	
		},
		AssignJqueryAutoFill:function(calling_table_name,system_name)
		 {
			 
				var txt_system_name=("#m_"+calling_table_name+" #"+system_name);
			 
			$myinput=$(txt_system_name).bind( "keydown", function( event ) {
				 
			}).autocomplete({
				source: function( request, response ) {
				 
				var lstr_query_string='';
				lstr_query_string+='value='+request.term ;
				lstr_query_string+='&system_name='+system_name ;
				lstr_query_string+='&calling_table_name='+calling_table_name ;
				 
			  
				$.ajaxq ("ajaxQueue",{
	                  type: "POST",
		              async:false,
		              url: $host_url+"GetJqueryAutoCompleteAutoFill",  
	                  data: lstr_query_string,
	                  success: function GetJqueryAutoCompleteAutoFillResponce(v_response)
						{
							 v_response = eval('(' +  v_response + ')');
							 response(v_response.data);	
							$('ul.ui-autocomplete li a').css("color",'#403849');	
						} 
						});
					
				
				},
				 open: function(event, ui) {
						 var new_width=eval(parseFloat($(txt_system_name).width())+22);
						 var new_top=$(txt_system_name).offset()['top']+25;	
						 
						if(all_obj[calling_table_name]['load_type']=='PopUp')
						{
							var module_id = all_obj[calling_table_name]['g_str_module_id'];
							var pop_top_height = $("#popup_module_dialog_"+module_id).parent().offset().top;
							new_top = new_top-pop_top_height;
						}
						
					  jQuery(".ui-autocomplete").css("top", new_top);
						$(this).autocomplete("widget").css({
							"width": new_width,
							"min-heigh": 210,
							"height": 210 ,
							"z-index": 120000 ,
							"overflow": 'auto' 

						});
						},
				search: function() {
					 
					var term = extractLast( this.value );
				},
				focus: function() {
					// prevent value inserted on focus
					return false;
				},
				select: function( event, ui ) {
				 	$(txt_system_name).val(ui.item.value);
					return false;
				}
		});
		 
		}
}


