/* App.blockUI / unblockUI — soft overlay + spinner (uses InpcLoader when present) */
(function (window, $) {
  "use strict";
  var overlayId = "fw-blockui-overlay";
  var usingInpc = false;

  function ensureOverlay() {
    var el = document.getElementById(overlayId);
    if (!el) {
      el = document.createElement("div");
      el.id = overlayId;
      el.className = "fw-blockui-overlay";
      el.setAttribute("role", "status");
      el.setAttribute("aria-live", "polite");
      el.innerHTML =
        '<div class="fw-blockui-inner">' +
        '<div class="spinner-border text-danger fw-blockui-spinner" role="status" aria-hidden="true"></div>' +
        '<div class="fw-blockui-text">Please wait...</div>' +
        "</div>";
      document.body.appendChild(el);
    }
    return el;
  }

  window.App = window.App || {};
  window.App.blockUI = function (opts) {
    var msg = (opts && opts.message) || "Please wait...";
    if (typeof showLoader === "function") {
      usingInpc = true;
      showLoader(msg);
      return;
    }
    usingInpc = false;
    var el = ensureOverlay();
    var text = el.querySelector(".fw-blockui-text");
    if (text) text.textContent = msg;
    el.style.display = "flex";
  };
  window.App.unblockUI = function () {
    if (usingInpc && typeof hideLoader === "function") {
      hideLoader();
      hideLoader("home_dashboard");
      usingInpc = false;
      return;
    }
    var el = document.getElementById(overlayId);
    if (el) el.style.display = "none";
    usingInpc = false;
  };
})(window, window.jQuery);
