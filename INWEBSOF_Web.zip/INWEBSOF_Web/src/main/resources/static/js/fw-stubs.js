/* Stubs required by MainPageNew.js / ServiceBilling FW */
var ajax_req;
function AjaxErrorMessage(xhr, status, err) {
  var msg = "Ajax error";
  try {
    if (err) msg += ": " + err;
    if (status) msg += " [" + status + "]";
    if (xhr && xhr.status) msg += " HTTP " + xhr.status;
  } catch (e) {}
  console.error(msg, xhr);
  try {
    alert(msg);
  } catch (e2) {}
}
function HandleSectionBarMinheight() {}
function PreSaveModuleValidation() {
  return true;
}
function PostSaveModuleDetails() {
  return true;
}
if (typeof window.trim !== "function") {
  window.trim = function (s) {
    return s == null ? "" : String(s).trim();
  };
}
if (typeof window.bootbox === "undefined") {
  window.bootbox = {
    alert: function (msg, cb) {
      try {
        alert(typeof msg === "string" ? msg.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "") : msg);
      } catch (e) {}
      if (typeof cb === "function") cb();
    },
    confirm: function (msg, cb) {
      var ok = false;
      try {
        ok = confirm(typeof msg === "string" ? msg.replace(/<[^>]+>/g, "") : msg);
      } catch (e) {}
      if (typeof cb === "function") cb(ok);
    }
  };
}

/* SweetAlert1-compatible shim over SweetAlert2 */
window.swal = function (title, text, icon) {
  if (window.Swal && typeof Swal.fire === "function") {
    var opts = { confirmButtonColor: "#DD6B55" };
    if (typeof title === "object" && title !== null) {
      opts = Object.assign({}, title);
      if (opts.type && !opts.icon) opts.icon = opts.type;
    } else {
      opts.title = title || "";
      opts.html = text || "";
      opts.icon = icon || "info";
    }
    return Swal.fire(opts);
  }
  alert((typeof title === "string" ? title + "\n" : "") + (text || ""));
};

/* Called after grid edit fills the form (MainPageNew.GetSchemaModuleDetailsForUpdateNew). */
function AfterEditModule(system_module_table_name, internal_code, details) {
  // Module-specific hooks live in load_js_files.js; default no-op is safe.
}
function OnloadModule() {}