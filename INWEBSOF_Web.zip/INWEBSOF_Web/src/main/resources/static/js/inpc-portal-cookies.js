/**
 * INPCV2 portal cookie helpers (auth / change-customer / session display).
 * Loaded by index.html, login.html, and MainPage.html (before MainPage.js).
 * Safe to load more than once — functions are idempotent on window.
 */
(function (w) {
  "use strict";
  if (w.__inpcPortalCookiesReady) return;
  w.__inpcPortalCookiesReady = true;

  function inpcCookiePaths() {
    var paths = ["/", "/inwebsof", "/inwebsof/", "/INPCV2", "/INPCV2/"];
    try {
      var app = String(w.$app_url || "").trim();
      if (app) {
        if (app.charAt(app.length - 1) === "/") {
          paths.push(app);
          paths.push(app.replace(/\/$/, "") || "/");
        } else {
          paths.push(app);
          paths.push(app + "/");
        }
      }
      var p = String((w.location && w.location.pathname) || "");
      var i = p.indexOf("/", 1);
      if (i > 0) {
        var ctx = p.substring(0, i);
        paths.push(ctx);
        paths.push(ctx + "/");
      }
    } catch (ePaths) { /* ignore */ }
    var out = [];
    var seen = {};
    for (var i = 0; i < paths.length; i++) {
      var x = paths[i];
      if (!x || seen[x]) continue;
      seen[x] = true;
      out.push(x);
    }
    return out;
  }

  function inpcClearCookie(name) {
    if (!name) return;
    try {
      var enc = encodeURIComponent(name);
      var paths = inpcCookiePaths();
      for (var i = 0; i < paths.length; i++) {
        w.document.cookie =
          enc + "=;path=" + paths[i] + ";max-age=0;SameSite=Lax";
        w.document.cookie =
          enc + "=;path=" + paths[i] + ";expires=Thu, 01 Jan 1970 00:00:00 GMT;SameSite=Lax";
      }
    } catch (e) { /* ignore */ }
  }

  function inpcSetCookie(name, value, days) {
    try {
      var maxAge = (days == null ? 30 : days) * 86400;
      w.document.cookie =
        encodeURIComponent(name) +
        "=" +
        encodeURIComponent(value == null ? "" : String(value)) +
        ";path=/;max-age=" +
        maxAge +
        ";SameSite=Lax";
    } catch (e) { /* ignore */ }
  }


  /**
   * Read a cookie by name (matches encodeURIComponent names from inpcSetCookie).
   * Prefer this over ad-hoc document.cookie parsing.
   */
  function inpcGetCookie(name) {
    if (!name) return "";
    try {
      var raw = String(w.document.cookie || "");
      if (!raw) return "";
      var want = String(name);
      var wantEnc = encodeURIComponent(want);
      var parts = raw.split(";");
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i].trim();
        if (!p) continue;
        var eq = p.indexOf("=");
        if (eq < 0) continue;
        var n = p.substring(0, eq);
        var v = p.substring(eq + 1);
        if (n === wantEnc || n === want) {
          try {
            return decodeURIComponent(v);
          } catch (eDec) {
            return v;
          }
        }
        try {
          if (decodeURIComponent(n) === want) {
            try {
              return decodeURIComponent(v);
            } catch (eDec2) {
              return v;
            }
          }
        } catch (eName) { /* ignore */ }
      }
    } catch (e) { /* ignore */ }
    return "";
  }
  /** Known portal / auth display cookies (aligned with logout). */
  var INPC_KNOWN_PORTAL_COOKIES = [
    "fw_cust_name",
    "fw_cust_code",
    "fw_loginId",
    "fw_override_cust_name",
    "fw_override_cust_code",
    "fw_override_loginId",
    "fw_customer_overridden",
    "fw_see_other_cust_data",
    /* legacy bare names (pre-fw_ prefix) */
    "cust_name",
    "cust_code",
    "loginId"
  ];

  function inpcListDocumentCookieNames() {
    var names = [];
    try {
      var raw = String(w.document.cookie || "");
      if (!raw) return names;
      var parts = raw.split(";");
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i].trim();
        if (!p) continue;
        var eq = p.indexOf("=");
        var n = eq >= 0 ? p.substring(0, eq) : p;
        try {
          n = decodeURIComponent(n);
        } catch (eDec) { /* keep raw */ }
        if (n) names.push(n);
      }
    } catch (eList) { /* ignore */ }
    return names;
  }

  /**
   * Clear portal session/display cookies (same set logout uses), plus any fw_* still present.
   */
  function inpcClearUserCookies() {
    var i;
    for (i = 0; i < INPC_KNOWN_PORTAL_COOKIES.length; i++) {
      inpcClearCookie(INPC_KNOWN_PORTAL_COOKIES[i]);
    }
    var names = inpcListDocumentCookieNames();
    for (i = 0; i < names.length; i++) {
      if (/^fw_/i.test(names[i])) {
        inpcClearCookie(names[i]);
      }
    }
  }

  /**
   * Safe clear of all non-HttpOnly cookies visible on the app path
   * (document.cookie only sees cookies for the current path/domain).
   * Expires each name for / and /INPCV2 (and $app_url).
   */
  function inpcClearAllDocumentCookies() {
    inpcClearUserCookies();
    var names = inpcListDocumentCookieNames();
    for (var i = 0; i < names.length; i++) {
      inpcClearCookie(names[i]);
    }
  }

  /** True if URL targets index / login / context root (leave MainPage → home). */
  function inpcIsIndexOrLoginTarget(href) {
    if (!href || href === "#" || href.indexOf("javascript:") === 0) return false;
    try {
      var u = new URL(href, w.location.href);
      if (u.origin !== w.location.origin) return false;
      var path = String(u.pathname || "");
      var low = path.toLowerCase();
      if (/\/(index|login|login1)\.html$/i.test(low)) return true;
      /* context root: /inwebsof or /inwebsof/ (no further file) */
      var app = String(w.$app_url || "/inwebsof/");
      var appNorm = app.replace(/\/+$/, "") || "";
      var pathNorm = path.replace(/\/+$/, "") || "";
      if (appNorm && (pathNorm === appNorm || low === "/" || pathNorm === "")) {
        /* bare context root often serves index */
        if (!/\.[a-z0-9]+$/i.test(pathNorm.split("/").pop() || "")) {
          return pathNorm === appNorm || path === "/" || path === app;
        }
      }
      if (pathNorm === appNorm) return true;
    } catch (eUrl) {
      var s = String(href).toLowerCase();
      if (s.indexOf("index.html") >= 0 || s.indexOf("login.html") >= 0) return true;
    }
    return false;
  }

  /** Run clear when arriving at index/login (covers browser Back + direct open). */
  function inpcClearCookiesOnIndexOrLoginArrival() {
    try {
      var path = String((w.location && w.location.pathname) || "").toLowerCase();
      if (
        /\/(index|login|login1)\.html$/i.test(path) ||
        /\/inpcv2\/?$/i.test(path) ||
        path === "/"
      ) {
        inpcClearAllDocumentCookies();
      }
    } catch (eArr) {
      try {
        inpcClearAllDocumentCookies();
      } catch (e2) { /* ignore */ }
    }
  }

  w.inpcCookiePaths = inpcCookiePaths;
  w.inpcGetCookie = inpcGetCookie;
  w.inpcSetCookie = inpcSetCookie;
  w.inpcClearCookie = inpcClearCookie;
  w.inpcClearUserCookies = inpcClearUserCookies;
  w.inpcClearAllDocumentCookies = inpcClearAllDocumentCookies;
  w.inpcIsIndexOrLoginTarget = inpcIsIndexOrLoginTarget;
  w.inpcClearCookiesOnIndexOrLoginArrival = inpcClearCookiesOnIndexOrLoginArrival;
})(window);
