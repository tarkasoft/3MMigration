/* Framework multi-grid pre/post hooks — keep methods even when unused */
var ModuleGridPreSaveValidation = {
  PreMultiSaveGridRow: function (system_module_name, group_table_name, edid_row_id, grid_row_obj) {
    return true;
  },
  PostMultiSaveGridRow: function (system_module_name, group_table_name, edid_row_id, grid_row_obj, fw_edit_mode) {
    return true;
  },
  MultiGridAfterAddRowEvent: function (system_module_name, group_table_name, last_saved_row_id) {
    return true;
  },
  PreMultiDeleteGridRow: function (system_module_name, group_table_name) {
    return true;
  },
  PostMultiDeleteGridRow: function (system_module_name, group_table_name) {
    return true;
  },
  GetSystemRowEditableFields: function (system_module_name, group_table_name) {
    return "";
  },
  PreThirdLevelGridRow: function (system_module_name, group_table_name, row_id) {
    return true;
  },
  GetGroupAdditionalButtons: function (system_module_name, group_table_name, row_id) {
    return "";
  }
};