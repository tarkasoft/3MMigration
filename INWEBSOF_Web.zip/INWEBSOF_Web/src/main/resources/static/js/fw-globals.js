/**
 * App root from the address bar. Do NOT redefine in page/feature scripts.
 * Local and IP: /inwebsof/MainPage.html -> /inwebsof/
 * Domain mapped at the site root: /MainPage.html -> /
 */
window.inpcAppRoot = function () {
  var path = String((window.location && window.location.pathname) || "/");
  var parts = path.split("/");
  if (parts.length >= 3 && parts[1] && parts[1].indexOf(".") < 0) {
    return "/" + parts[1] + "/";
  }
  return "/";
};
/** Global titpl base URL — set once for the portal. */
window.$host_url = window.inpcAppRoot() + "titpl/";
/** Alias used by some legacy scripts */
window.host_url = window.$host_url;
/** App context root (Spring /api/auth/*, static pages). Derived once from $host_url. */
window.$app_url = window.$host_url.replace(/titpl\/?$/, "");
window.$g_app_tye = window.$g_app_tye || "INPC";

/**
 * Global AS400 data switch.
 * false = call AS400 procedures; true = request local dummy/sample data.
 */
window.as400_dummy_data_required = false;

/** Module tabs: true = Home + up to 6 panes; false = classic single #home_dashboard (revert). Mobile always single. */
window.INPC_INCLUDE_TABS = window.INPC_INCLUDE_TABS != null ? window.INPC_INCLUDE_TABS : true;

/** Tab strip theme when Include Tabs is on: 1|2|3|4|5|6 (see css/inpc_tabs.css). */
window.INPC_TAB_STYLE = window.INPC_TAB_STYLE != null ? window.INPC_TAB_STYLE : 4;

/** Show icons before tab labels when Include Tabs is on (portal.extras.tab-icons). */
window.INPC_TAB_ICONS = window.INPC_TAB_ICONS != null ? window.INPC_TAB_ICONS : false;
/** file_name -> { icon, color } filled from menus JSON */
if (!window.INPC_MENU_ICONS) window.INPC_MENU_ICONS = {};
