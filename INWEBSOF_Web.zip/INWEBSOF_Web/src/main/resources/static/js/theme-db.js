/**
 * INPCV2 — load/save Switcher theme from ia_user_master.theme_json (titpl APIs).
 * Cookie "theme_css" is the fast client restore source; sessionStorage + DB stay in sync.
 */
(function (window, $) {
  "use strict";
  if (!$) return;

  var THEME_COOKIE = "theme_css";
  var THEME_SS_KEY = "inpc_theme_json";
  var COOKIE_DAYS = 30;

  function hostTitpl() {
    if (typeof window.$host_url === "string" && window.$host_url) return window.$host_url;
    if (typeof window.inpcAppRoot === "function") return window.inpcAppRoot() + "titpl/";
    var p = String(window.location.pathname || "/");
    var parts = p.split("/");
    if (parts.length >= 3 && parts[1] && parts[1].indexOf(".") < 0) return "/" + parts[1] + "/titpl/";
    return "/titpl/";
  }

  function looksLikeThemeJson(s) {
    return typeof s === "string" && s.trim().charAt(0) === "{";
  }

  /** Read theme_css cookie; works with common-helpers (decoded) or raw document.cookie. */
  function readThemeCookie() {
    try {
      if (typeof window.getCookie === "function") {
        var v = window.getCookie(THEME_COOKIE);
        if (v == null || v === "") return "";
        v = String(v);
        if (looksLikeThemeJson(v)) return v.trim();
        try {
          var d = decodeURIComponent(v);
          if (looksLikeThemeJson(d)) return d.trim();
        } catch (e0) {}
        return v.trim();
      }
    } catch (e1) {}
    try {
      var parts = ("; " + document.cookie).split("; " + THEME_COOKIE + "=");
      if (parts.length < 2) return "";
      var raw = parts.pop().split(";").shift();
      if (!raw) return "";
      try {
        var dec = decodeURIComponent(raw);
        return looksLikeThemeJson(dec) ? dec.trim() : raw;
      } catch (e2) {
        return raw;
      }
    } catch (e3) {}
    return "";
  }

  function writeThemeCookie(themeJson) {
    if (!looksLikeThemeJson(themeJson)) return;
    try {
      if (typeof window.setCookie === "function") {
        // common-helpers setCookie encodes the value
        window.setCookie(THEME_COOKIE, themeJson, COOKIE_DAYS, { path: "/", sameSite: "Lax" });
      } else {
        document.cookie =
          THEME_COOKIE +
          "=" +
          encodeURIComponent(themeJson) +
          ";path=/;max-age=" +
          86400 * COOKIE_DAYS +
          ";SameSite=Lax";
      }
    } catch (e) {}
  }

  function writeThemeSession(themeJson) {
    if (!looksLikeThemeJson(themeJson)) return;
    try {
      sessionStorage.setItem(THEME_SS_KEY, themeJson);
    } catch (e) {}
  }

  function applyFromJson(themeJson) {
    if (!looksLikeThemeJson(themeJson) || themeJson.trim() === "{}") {
      return false;
    }
    try {
      var settings = JSON.parse(themeJson);
      if (typeof window.applyThemeSettings === "function") {
        window.applyThemeSettings(settings);
      } else {
        if (settings.banner_theme && typeof window.inpcApplyBannerTheme === "function") {
          window.inpcApplyBannerTheme(settings.banner_theme);
        }
        if (settings.primary_rgb) {
          // Before custom-switcher loads: at least apply primary (and light attrs) pre-paint-ish
          try {
            var html = document.documentElement;
            html.style.setProperty("--primary-rgb", settings.primary_rgb);
            try {
              localStorage.setItem("primaryRGB", settings.primary_rgb);
            } catch (eLs) {}
            if (settings.body_bg_rgb) html.style.setProperty("--body-bg-rgb", settings.body_bg_rgb);
            if (settings.body_light_rgb) html.style.setProperty("--body-bg-rgb2", settings.body_light_rgb);
            if (settings.theme_mode) html.setAttribute("data-theme-mode", settings.theme_mode);
            if (settings.menu_styles) html.setAttribute("data-menu-styles", settings.menu_styles);
            if (settings.header_styles) html.setAttribute("data-header-styles", settings.header_styles);
          } catch (eEarly) {}
        }
      }
      if (typeof window.updateLocalStorageFromSettings === "function") {
        window.updateLocalStorageFromSettings(settings);
      }
      writeThemeCookie(themeJson);
      writeThemeSession(themeJson);
      setTimeout(function () {
        if (typeof window.checkOptions === "function") window.checkOptions();
        if (typeof window.restoreMegaMenuFromStorage === "function") window.restoreMegaMenuFromStorage();
      }, 120);
      return true;
    } catch (e) {
      console.warn("INPC theme apply failed:", e);
      return false;
    }
  }

  window.inpcWriteThemeCookie = writeThemeCookie;
  window.inpcReadThemeCookie = readThemeCookie;

  window.inpcLoadThemeFromDb = function () {
    // 1) Cookie first (user-facing persist for refresh)
    var cookieTheme = readThemeCookie();
    if (cookieTheme && applyFromJson(cookieTheme)) {
      return;
    }

    // 2) sessionStorage (same-tab after login)
    try {
      var cached = sessionStorage.getItem(THEME_SS_KEY);
      if (cached && applyFromJson(cached)) return;
    } catch (e0) {}

    // 3) DB
    $.ajax({
      type: "GET",
      url: hostTitpl() + "getThemejson",
      dataType: "json",
      success: function (res) {
        var payload = res && (res.data || res);
        var theme = payload && (payload.theme_json || payload.themeJson || "");
        if (theme) {
          applyFromJson(theme);
        } else if (typeof window.loadUserThemeSettings === "function") {
          window.loadUserThemeSettings();
        }
      },
      error: function () {
        if (typeof window.loadUserThemeSettings === "function") {
          window.loadUserThemeSettings();
        }
      },
    });
  };

  window.inpcStoreThemeFromLogin = function (loginData) {
    if (!loginData) return;
    var theme = loginData.theme_json || loginData.themeJson || "";
    if (theme) {
      applyFromJson(theme);
    }
  };

  $(function () {
    if (document.body && document.body.id === "inpc-login-page") return;
    setTimeout(function () {
      window.inpcLoadThemeFromDb();
    }, 300);
  });
})(window, window.jQuery);
