/** Fallback only if MainPage.js not loaded yet; prefer shared in_array from MainPage.js (insba-compatible). */
if (typeof in_array !== "function") {
	window.in_array = function (needle, haystack, argStrict) {
		var key = "", strict = !!argStrict;
		if (strict) {
			for (key in haystack) {
				if (haystack[key] === needle) {
					return true;
				}
			}
		} else {
			for (key in haystack) {
				if (haystack[key] == needle) {
					return true;
				}
			}
		}
		return false;
	};
}
var $loaded_js_files_arr = new Array(); 
function includeJsFilesMannuallyOld(js_path)
{
   
	if(js_path!="" && !in_array(js_path,$loaded_js_files_arr))
	{
	 
	  $loaded_js_files_arr.push(js_path);
	/*   var oHead = document.getElementsByTagName('head')[0];
        var oScript = document.createElement('script');
        oScript.type = 'text/javascript';
        oScript.charset = 'utf-8';
        oScript.src = js_path;
        oHead.appendChild(oScript);  */
	  
	  $(document.createElement('script')).attr('src',js_path).attr('type', 'text/javascript').appendTo('head');
	}
} 

function showJsLoadError(jsPath) {
	try {
		if (typeof hideLoader === "function") {
			hideLoader();
			var hid = "home_dashboard";
			try {
				if (window.InpcTabs && typeof InpcTabs.activeContentId === "function") {
					hid = InpcTabs.activeContentId() || hid;
				}
			} catch (_eHid) { /* ignore */ }
			hideLoader(hid);
		}
	} catch (_eHide) { /* ignore */ }
	var safe = String(jsPath || "").replace(/[&<>"']/g, function (c) {
		return { "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c];
	});
	var html = "<div class='alert alert-danger mb-0'>Unable to load <code>" + safe + "</code>. File not found.</div>";
	var pane = null;
	try {
		if (window.InpcTabs && typeof InpcTabs.$activePane === "function") pane = InpcTabs.$activePane();
	} catch (_ePane) { /* ignore */ }
	if (pane && pane.length) pane.html(html);
	else if (window.jQuery) jQuery("#home_dashboard").html(html);
}
function includeJsFilesMannually(js_path, callback){
	o_js_path=js_path; App.unblockUI();
	if(js_path!="" && !in_array(o_js_path,$loaded_js_files_arr))
	{
		var finished = false;
		js_path=js_path+"?r="+Math.random();
	 
		var script = document.createElement("script")
		script.type = "text/javascript";
		function ok() {
			if (finished) return;
			finished = true;
			$loaded_js_files_arr.push(o_js_path);
			callback();
		}
		function fail() {
			if (finished) return;
			finished = true;
			showJsLoadError(o_js_path);
		}

		if (script.readyState){  //IE
			script.onreadystatechange = function(){
				if (script.readyState == "loaded" ||
						script.readyState == "complete"){
					script.onreadystatechange = null;
					ok();
				}
			};
		} else {  //Others
			script.onload = function(){
				ok();
			};
		}
		script.onerror = fail;

		script.src = js_path;
		document.getElementsByTagName("head")[0].appendChild(script);
	}
	else
	{
		callback();
	}
}

function includeJsFilesMannuallyOverride(js_path, callback){

	if(js_path!="" )
	{
		var script = document.createElement("script")
		script.type = "text/javascript";

		if (script.readyState){  //IE
			script.onreadystatechange = function(){
				if (script.readyState == "loaded" ||
						script.readyState == "complete"){
					script.onreadystatechange = null;
					callback();
				}
			};
		} else {  //Others
			script.onload = function(){
				callback();
			};
		}

		script.src = js_path;
		document.getElementsByTagName("head")[0].appendChild(script);
		$loaded_js_files_arr.push(js_path);
	}
	else
	{
		callback();
	}
}
function PreSaveModuleValidation(system_module_table_name)
{
	var flag=true;
	 
	return flag;
}
function PostSaveModuleDetails(responce,last_insert_id,system_module_table_name,before_save_insert_id)
{
	
	
	if(system_module_table_name=="tk_po_receipt")
	{
			$('#po_attachment').attr("po_attach_int_code",last_insert_id);
			
		if(!empty($("input[id*='po_attachment']").val()))
		{
			POReceipt.UploadPOReceiptDocument(last_insert_id);
		}
		else
		{
			
			all_obj.tk_po_receipt.geditinternalcode=0;
			
			 bootbox.alert(responce.data.msg);
			  all_obj.ClearfieldsNew('tk_po_receipt');
		}
	}
	
	if(system_module_table_name=="ew_convertor")
	{
		 
		if(before_save_insert_id=="0")
		{
			 UpdateAutoGenerataionNumberForModule('ew_convertor','CONV');
		}			
		if(!empty($("input[id*='agreement_copy']").val()))
		{
			EWConvertorMaster.UploadConvertorDocument(last_insert_id);
		}
		else
		{
			
			all_obj.ew_convertor.geditinternalcode=0;
			 bootbox.alert(responce.data.msg);
			  all_obj.ClearfieldsNew('ew_convertor');
		}
	}
	if(system_module_table_name=="ew_applicator")
	{
		 
		if(before_save_insert_id=="0")
		{
			 UpdateAutoGenerataionNumberForModule('ew_applicator','APPL');
		}	
		if(!empty($("input[id*='app_agreement_copy']").val()))
		{
			EWApplicatorMaster.UploadApplicatorDocument(last_insert_id);
		}
		else
		{
			
			all_obj.ew_applicator.geditinternalcode=0;
			 bootbox.alert(responce.data.msg);
			  all_obj.ClearfieldsNew('ew_applicator');
		}
	}
	if(system_module_table_name=="ew_conv_customer")
	{
		 
		if(before_save_insert_id=="0")
		{
			 UpdateAutoGenerataionNumberForModule('ew_conv_customer','CUST');
		}	
	}
	if(system_module_table_name=="tsd_product_master")
	{
		 
		TSDPM.SaveProductMasterDynTableDetails(last_insert_id,'prod_dyn_table');
		 	
	}
}
function AfterEditModule(system_module_table_name,internal_code,details)
{
	if(system_module_table_name=="tk_po_receipt")
	{
		POReceipt.GetPoReceiptForSelectedID();	
	}
	 
	if(system_module_table_name=="ew_convertor")
	{
		$("#m_ew_convertor #btn_cov_dist_mapping").show();	
		EWConvertorMaster.ShowConvUploadedDocumentAfterEdit()
	}
	if(system_module_table_name=="ew_applicator")
	{
	 
		EWApplicatorMaster.ShowApplicatorUploadedDocumentAfterEdit()
	}
	 
	if(system_module_table_name=="ew_distributor")
	{
		$("#m_ew_distributor #btn_dist_conv_mapping").show();	
	}
	
	if(system_module_table_name=="tsd_product_master")
	{
		 
		TSDPM.GetSavedProductMasterDynTableDetails(internal_code,'prod_dyn_table');
		 	
	}
	if(system_module_table_name=="cc_ecom_customers")
	{
		 
		EnableEcmCustomerCSRDiv()
		 	
	}
	 
	
	
}