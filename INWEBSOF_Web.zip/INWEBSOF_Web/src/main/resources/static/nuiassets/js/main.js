(function () {
  "use strict";

  // ========== DEFINE FALLBACK FUNCTIONS ==========
  // Define fallback if clearNavDropdown doesn't exist
  if (typeof clearNavDropdown === "undefined") {
    window.clearNavDropdown = function () {
      console.log("clearNavDropdown fallback called");
      try {
        document.querySelectorAll(".slide-menu").forEach(function (el) {
          if (el.style.display !== "none") {
            el.style.display = "none";
          }
        });
        document.querySelectorAll(".slide.has-sub.open").forEach(function (el) {
          el.classList.remove("open");
        });
      } catch (e) {
        // Silently fail
      }
    };
  }

  // Define fallback if checkHoriMenu doesn't exist
  if (typeof checkHoriMenu === "undefined") {
    window.checkHoriMenu = function () {
      console.log("checkHoriMenu fallback called");
      try {
        var menuNav = document.querySelector(".main-menu");
        var mainContainer = document.querySelector(".main-sidebar");
        if (menuNav && mainContainer) {
          var slideRight = document.querySelector(".slide-right");
          if (menuNav.scrollWidth > mainContainer.offsetWidth) {
            if (slideRight) slideRight.classList.remove("d-none");
          } else {
            if (slideRight) slideRight.classList.add("d-none");
          }
        }
      } catch (e) {
        // Silently fail
      }
    };
  }
  // ========== END FALLBACK FUNCTIONS ==========

  if (localStorage.getItem("zynixdarktheme")) {
    document.querySelector("html").setAttribute("data-theme-mode", "dark");
    document.querySelector("html").setAttribute("data-menu-styles", "dark");
    document
      .querySelector("html")
      .setAttribute("data-header-styles", "transparent");
  }
  if (localStorage.zynixrtl) {
    let html = document.querySelector("html");
    html.setAttribute("dir", "rtl");
    document
      .querySelector("#style")
      ?.setAttribute(
        "href",
        "../assets/libs/bootstrap/css/bootstrap.rtl.min.css",
      );
  }
  if (localStorage.zynixlayout) {
    let html = document.querySelector("html");
    html.setAttribute("data-nav-layout", "horizontal");
    document.querySelector("html").setAttribute("data-menu-styles", "light");
  }
  if (localStorage.getItem("zynixlayout") == "horizontal") {
    document
      .querySelector("html")
      .setAttribute("data-nav-layout", "horizontal");
  }
  if (localStorage.loaderEnable == "true") {
    document.querySelector("html").setAttribute("loader", "enable");
  } else {
    if (!document.querySelector("html").getAttribute("loader")) {
      document.querySelector("html").setAttribute("loader", "disable");
    }
  }

  function localStorageBackup() {
    // if there is a value stored, update color picker and background color
    // Used to retrive the data from local storage
    if (localStorage.primaryRGB) {
      if (document.querySelector(".theme-container-primary")) {
        document.querySelector(".theme-container-primary").value =
          localStorage.primaryRGB;
      }
      document
        .querySelector("html")
        .style.setProperty("--primary-rgb", localStorage.primaryRGB);
    }
    if (localStorage.bodyBgRGB && localStorage.bodylightRGB) {
      if (document.querySelector(".theme-container-background")) {
        document.querySelector(".theme-container-background").value =
          localStorage.bodyBgRGB;
      }
      document
        .querySelector("html")
        .style.setProperty("--body-bg-rgb", localStorage.bodyBgRGB);
      document
        .querySelector("html")
        .style.setProperty("--body-bg-rgb2", localStorage.bodylightRGB);
      document
        .querySelector("html")
        .style.setProperty("--light-rgb", localStorage.bodylightRGB);
      document
        .querySelector("html")
        .style.setProperty(
          "--form-control-bg",
          `rgb(${localStorage.bodylightRGB})`,
        );
      document
        .querySelector("html")
        .style.setProperty("--gray-3", `rgb(${localStorage.bodylightRGB})`);
      document
        .querySelector("html")
        .style.setProperty("--input-border", "rgba(255,255,255,0.1)");
      let html = document.querySelector("html");
      html.setAttribute("data-theme-mode", "dark");
      html.setAttribute("data-menu-styles", "dark");
      html.setAttribute("data-header-styles", "dark");
    }
    if (localStorage.zynixdarktheme) {
      let html = document.querySelector("html");
      html.setAttribute("data-theme-mode", "dark");
    }
    if (localStorage.zynixlayout) {
      let html = document.querySelector("html");
      let layoutValue = localStorage.getItem("zynixlayout");
      html.setAttribute("data-nav-layout", "horizontal");
      setTimeout(() => {
        // Now safe to call - fallback exists
        clearNavDropdown();
      }, 1000);
      html.setAttribute("data-nav-style", "menu-click");
      setTimeout(() => {
        // Now safe to call - fallback exists
        checkHoriMenu();
      }, 5000);
    }
    if (localStorage.zynixverticalstyles) {
      let html = document.querySelector("html");
      let verticalStyles = localStorage.getItem("zynixverticalstyles");

      if (verticalStyles == "fullwidth") {
        html.setAttribute("data-vertical-style", "fullwidth");
        localStorage.removeItem("zynixnavstyles");
      }
      if (verticalStyles == "closed") {
        html.setAttribute("data-vertical-style", "closed");
        localStorage.removeItem("zynixnavstyles");
      }
      if (verticalStyles == "icontext") {
        html.setAttribute("data-vertical-style", "icontext");
        localStorage.removeItem("zynixnavstyles");
      }
      if (verticalStyles == "overlay") {
        html.setAttribute("data-vertical-style", "overlay");
        localStorage.removeItem("zynixnavstyles");
      }
      if (verticalStyles == "detached") {
        html.setAttribute("data-vertical-style", "detached");
        localStorage.removeItem("zynixnavstyles");
      }
      if (verticalStyles == "doublemenu") {
        html.setAttribute("data-vertical-style", "doublemenu");
        localStorage.removeItem("zynixnavstyles");
        setTimeout(() => {
          const menuSlideItem = document.querySelectorAll(
            ".main-menu > li > .side-menu__item",
          );

          // Create the tooltip element
          const tooltip = document.createElement("div");
          tooltip.className = "custome-tooltip";
          // Set the CSS properties of the tooltip element
          tooltip.style.setProperty("position", "fixed");
          tooltip.style.setProperty("display", "none");
          tooltip.style.setProperty("padding", "0.5rem");
          tooltip.style.setProperty("font-weight", "500");
          tooltip.style.setProperty("font-size", "0.75rem");
          tooltip.style.setProperty("background-color", "rgb(15, 23 ,42)");
          tooltip.style.setProperty("color", "rgb(255, 255 ,255)");
          tooltip.style.setProperty("margin-inline-start", "48px");
          tooltip.style.setProperty("border-radius", "0.25rem");
          tooltip.style.setProperty("z-index", "99");

          menuSlideItem.forEach((e) => {
            // Add an event listener to the menu slide item to show the tooltip
            e.addEventListener("mouseenter", () => {
              if (localStorage.zynixverticalstyles == "doublemenu") {
                tooltip.style.setProperty("display", "block");
                tooltip.textContent =
                  e.querySelector(".side-menu__label").textContent;
                if (
                  document
                    .querySelector("html")
                    .getAttribute("data-vertical-style") == "doublemenu"
                ) {
                  e.appendChild(tooltip);
                }
              }
            });

            // Add an event listener to hide the tooltip
            e.addEventListener("mouseleave", () => {
              tooltip.style.setProperty("display", "none");
              tooltip.textContent =
                e.querySelector(".side-menu__label").textContent;
            });
          });
        }, 1000);
      }
    }
    if (localStorage.zynixnavstyles) {
      let html = document.querySelector("html");
      let navStyles = localStorage.getItem("zynixnavstyles");
      if (navStyles == "menu-click") {
        html.setAttribute("data-nav-style", "menu-click");
        localStorage.removeItem("zynixverticalstyles");
        html.removeAttribute("data-vertical-style");
        // INPC: clear overlay icon-only toggled after Menu Click restore
        if ((html.getAttribute("data-toggled") || "") === "icon-overlay-close") {
          html.setAttribute("data-toggled", "open");
        }
      }
      if (navStyles == "menu-hover") {
        html.setAttribute("data-nav-style", "menu-hover");
        localStorage.removeItem("zynixverticalstyles");
        html.removeAttribute("data-vertical-style");
        // INPC: Menu Hover must show icons+labels; clear overlay icon-only toggled
        if ((html.getAttribute("data-toggled") || "") === "icon-overlay-close" ||
            (html.getAttribute("data-nav-layout") === "horizontal" &&
              html.getAttribute("data-toggled") === "menu-hover-closed")) {
          html.setAttribute("data-toggled", "open");
        }
      }
      if (navStyles == "icon-click") {
        html.setAttribute("data-nav-style", "icon-click");
        localStorage.removeItem("zynixverticalstyles");
        html.removeAttribute("data-vertical-style");
      }
      if (navStyles == "icon-hover") {
        html.setAttribute("data-nav-style", "icon-hover");
        localStorage.removeItem("zynixverticalstyles");
        html.removeAttribute("data-vertical-style");
      }
    }
    if (localStorage.zynixclassic) {
      let html = document.querySelector("html");
      html.setAttribute("data-page-style", "classic");
    }
    if (localStorage.zynixmodern) {
      let html = document.querySelector("html");
      html.setAttribute("data-page-style", "modern");
    }
    if (localStorage.zynixboxed) {
      let html = document.querySelector("html");
      html.setAttribute("data-width", "boxed");
    }
    if (localStorage.zynixfullwidth) {
      let html = document.querySelector("html");
      html.setAttribute("data-width", "fullwidth");
    }
    if (localStorage.zynixheaderfixed) {
      let html = document.querySelector("html");
      html.setAttribute("data-header-position", "fixed");
    }
    if (localStorage.zynixheaderscrollable) {
      let html = document.querySelector("html");
      html.setAttribute("data-header-position", "scrollable");
    }
    if (localStorage.zynixmenufixed) {
      let html = document.querySelector("html");
      html.setAttribute("data-menu-position", "fixed");
    }
    if (localStorage.zynixmenuscrollable) {
      let html = document.querySelector("html");
      html.setAttribute("data-menu-position", "scrollable");
    }
    if (localStorage.zynixMenu) {
      let html = document.querySelector("html");
      let menuValue = localStorage.getItem("zynixMenu");
      switch (menuValue) {
        case "light":
          html.setAttribute("data-menu-styles", "light");
          break;
        case "dark":
          html.setAttribute("data-menu-styles", "dark");
          break;
        case "color":
          html.setAttribute("data-menu-styles", "color");
          break;
        case "gradient":
          html.setAttribute("data-menu-styles", "gradient");
          break;
        case "transparent":
          html.setAttribute("data-menu-styles", "transparent");
          break;
        default:
          break;
      }
    }
    if (localStorage.zynixHeader) {
      let html = document.querySelector("html");
      let headerValue = localStorage.getItem("zynixHeader");
      html.setAttribute("data-header-styles", headerValue);
    }
    if (localStorage.bgimg) {
      let html = document.querySelector("html");
      let value = localStorage.getItem("bgimg");
      html.setAttribute("data-bg-img", value);
    }
  }
  localStorageBackup();
})();
