package com.mmm.tsd;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.event.PdfDocumentEvent;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.properties.AreaBreakType;

/**
 * Manual smoke check for warranty letterhead margins (no DB).
 * Run from IDE after compile; writes target/tsd-warranty-layout-smoke.pdf
 */
public final class TsdWarrantyPdfLayoutSmoke {
	private TsdWarrantyPdfLayoutSmoke() {
	}

	public static void main(String[] args) throws Exception {
		byte[] logo = TsdWarrantyPdfBuilder.class.getClassLoader()
				.getResourceAsStream("tsd/images/3m.png")
				.readAllBytes();

		Path out = Path.of("target", "tsd-warranty-layout-smoke.pdf");
		Files.createDirectories(out.getParent());

		try (PdfWriter writer = new PdfWriter(Files.newOutputStream(out));
				PdfDocument pdf = new PdfDocument(writer);
				Document document = new Document(pdf, PageSize.A4, false)) {

			Method applyMargins = TsdWarrantyPdfBuilder.class.getDeclaredMethod("applyMargins", Document.class);
			applyMargins.setAccessible(true);
			applyMargins.invoke(null, document);

			Class<?> headerCls = Class.forName("com.mmm.tsd.TsdWarrantyPdfBuilder$HeaderHandler");
			var headerCtor = headerCls.getDeclaredConstructor(byte[].class, String.class);
			headerCtor.setAccessible(true);
			Object header = headerCtor.newInstance(logo, "05/02/2026");
			pdf.addEventHandler(PdfDocumentEvent.END_PAGE,
					(com.itextpdf.kernel.pdf.event.AbstractPdfDocumentEventHandler) header);

			Method addAddress = TsdWarrantyPdfBuilder.class.getDeclaredMethod("addAddressBlock",
					Document.class, String[].class);
			addAddress.setAccessible(true);
			addAddress.invoke(null, document, new String[] {
					"3M India Limited",
					"5th Floor Marksquare, 61 St Marks Road",
					"Bangalore – 560001, India",
					"Tel: +91 80 22231414",
					"www.3m.com/in"
			});

			Method normalize = TsdWarrantyPdfBuilder.class.getDeclaredMethod("normalizeHtml", String.class);
			normalize.setAccessible(true);
			Method addHtml = TsdWarrantyPdfBuilder.class.getDeclaredMethod("addHtml", Document.class, String.class);
			addHtml.setAccessible(true);
			String page1 = (String) normalize.invoke(null,
					"<div style='padding-top:-35px'><p><b>Date :</b> 05/02/2026</p>"
							+ "<p><b>Warranty No :</b> 260200281-4000</p>"
							+ "<center><u><b>WARRANTY CERTIFICATE</b></u></center>"
							+ "<p><b>Client Name :</b> NATIONAL HIGHWAY AUTHORITY OF INDIA</p>"
							+ "<p><b>Address :</b> PIU - INDORE-INDORE</p></div>");
			addHtml.invoke(null, document, page1);

			document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
			applyMargins.invoke(null, document);
			addAddress.invoke(null, document, new String[] {
					"3M India Limited",
					"5th Floor Marksquare, 61 St Marks Road",
					"Bangalore – 560001, India",
					"Tel: +91 80 22231414",
					"www.3m.com/in"
			});
			String page2 = (String) normalize.invoke(null,
					"<p>1. The sign is ineffective for its intended purpose when viewed from a moving vehicle "
							+ "under normal night driving conditions by a driver with a normal vision,</p>"
							+ "<table border='1' width='700'>"
							+ "<tr><th>Observation Angle</th><th>Entrance Angle</th><th>White</th>"
							+ "<th>Yellow</th><th>Green</th><th>Red</th><th>Blue</th><th>Brown</th></tr>"
							+ "<tr><td>0.1</td><td>-4</td><td>830</td><td>620</td><td>83</td><td>125</td><td>37</td><td>12</td></tr>"
							+ "</table>");
			addHtml.invoke(null, document, page2);
		}

		System.out.println("Wrote " + out.toAbsolutePath() + " pages check: open PDF — no logo/date overlap, Brown visible.");
	}
}
