package com.mmm.titpl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SqlDebugFormatterTest {
	@Test
	void rendersSqlServerBindValuesAsLiterals() {
		assertEquals("select * from customer where id = 12 and name = N'O''Brien'",
				SqlDebugFormatter.render("select * from customer where id = ? and name = ?",
						12, "O'Brien"));
	}

	@Test
	void doesNotReplaceQuestionMarksInsideSqlTextOrComments() {
		assertEquals("select '?' as marker where id = 7 -- ?\n",
				SqlDebugFormatter.render("select '?' as marker where id = ? -- ?\n", 7));
	}

	@Test
	void rendersNullAndReportsParameterCountMismatch() {
		assertEquals("select NULL, ? /* SQL bind count mismatch: 2 placeholders, 1 values */",
				SqlDebugFormatter.render("select ?, ?", (Object) null));
	}
}
