# Close Eclipse FIRST (File -> Exit). Cursor may stay open.
# Renames disk folders + Eclipse Project Explorer metadata INPCV2 -> INWEBSOF_Web
$ErrorActionPreference = "Stop"

$ws = "C:\Users\A6GWBZZ\eclipse-workspace"
$innerSrc = Join-Path $ws "INPCV2\INPCV2"
$innerMid = Join-Path $ws "INPCV2\INWEBSOF_Web"
$parentSrc = Join-Path $ws "INPCV2"
$parentDst = Join-Path $ws "INWEBSOF_Web"
$finalProj = Join-Path $parentDst "INWEBSOF_Web"
$metaRoot = Join-Path $ws ".metadata\.plugins\org.eclipse.core.resources\.projects"
$metaOld = Join-Path $metaRoot "INPCV2"
$metaNew = Join-Path $metaRoot "INWEBSOF_Web"
$jbossOld = "C:\Users\A6GWBZZ\jboss-eap-8.1.0-dev\jboss-eap-8.1\standalone\deployments\INPCV2.war"
$jbossNew = "C:\Users\A6GWBZZ\jboss-eap-8.1.0-dev\jboss-eap-8.1\standalone\deployments\INWEBSOF_Web.war"
$deployDir = Split-Path $jbossNew -Parent
$copyJunk = Join-Path $parentSrc "_INWEBSOF_Web_copy"

if (Get-Process -Name "eclipse" -ErrorAction SilentlyContinue) {
  throw "Eclipse is still running. File -> Exit Eclipse, then run this script again."
}

if (Test-Path "$finalProj\.project") {
  Write-Host "Project folder already at $finalProj"
} else {
  if (-not (Test-Path $innerSrc) -and -not (Test-Path $innerMid)) {
    throw "Cannot find project under $parentSrc"
  }
  if (Test-Path $copyJunk) {
    Remove-Item -LiteralPath $copyJunk -Recurse -Force
    Write-Host "Removed leftover _INWEBSOF_Web_copy"
  }
  if (Test-Path $innerSrc) {
    Rename-Item -LiteralPath $innerSrc -NewName "INWEBSOF_Web"
    Write-Host "Renamed project folder -> INWEBSOF_Web"
  }
  if (-not (Test-Path $parentDst)) {
    Rename-Item -LiteralPath $parentSrc -NewName "INWEBSOF_Web"
    Write-Host "Renamed parent folder -> INWEBSOF_Web"
  } elseif (Test-Path $innerMid) {
    New-Item -ItemType Directory -Force -Path $parentDst | Out-Null
    Move-Item -LiteralPath $innerMid -Destination $finalProj -Force
    Write-Host "Moved project into $finalProj"
  }
}

# Rewrite Eclipse .location binary URI + rename metadata project key
if (Test-Path $metaOld) {
  $loc = Join-Path $metaOld ".location"
  if (Test-Path $loc) {
    $bytes = [System.IO.File]::ReadAllBytes($loc)
    $oldUri = "URI//file:/C:/Users/A6GWBZZ/eclipse-workspace/INPCV2/INPCV2"
    $newUri = "URI//file:/C:/Users/A6GWBZZ/eclipse-workspace/INWEBSOF_Web/INWEBSOF_Web"
    $old = [System.Text.Encoding]::ASCII.GetBytes($oldUri)
    $new = [System.Text.Encoding]::ASCII.GetBytes($newUri)
    # find old URI
    $idx = -1
    for ($i = 0; $i -le $bytes.Length - $old.Length; $i++) {
      $ok = $true
      for ($j = 0; $j -lt $old.Length; $j++) {
        if ($bytes[$i + $j] -ne $old[$j]) { $ok = $false; break }
      }
      if ($ok) { $idx = $i; break }
    }
    if ($idx -lt 0) { throw "Could not find old URI in Eclipse .location" }
    # length byte is usually immediately before 'U' of URI (idx-1)
    $lenPos = $idx - 1
    if ($bytes[$lenPos] -ne $old.Length) {
      Write-Host "Warn: length byte $($bytes[$lenPos]) != $($old.Length); writing $($new.Length) at $lenPos"
    }
    $out = New-Object System.Collections.Generic.List[byte]
    for ($i = 0; $i -lt $lenPos; $i++) { [void]$out.Add($bytes[$i]) }
    [void]$out.Add([byte]$new.Length)
    foreach ($b in $new) { [void]$out.Add($b) }
    for ($i = $idx + $old.Length; $i -lt $bytes.Length; $i++) { [void]$out.Add($bytes[$i]) }
    [System.IO.File]::WriteAllBytes($loc, $out.ToArray())
    Write-Host "Updated Eclipse .location path"
  }
  if (Test-Path $metaNew) {
    Remove-Item -LiteralPath $metaNew -Recurse -Force
  }
  Rename-Item -LiteralPath $metaOld -NewName "INWEBSOF_Web"
  Write-Host "Renamed Eclipse metadata project INPCV2 -> INWEBSOF_Web"
} elseif (Test-Path $metaNew) {
  Write-Host "Eclipse metadata already INWEBSOF_Web"
} else {
  Write-Host "No Eclipse metadata for INPCV2 (import project after opening Eclipse)"
}

# Ensure .project name
$projFile = Join-Path $finalProj ".project"
if (Test-Path $projFile) {
  (Get-Content $projFile -Raw) -replace '<name>INPCV2</name>','<name>INWEBSOF_Web</name>' | Set-Content $projFile -NoNewline
}

# JBoss exploded WAR
if ((Test-Path $jbossOld) -and -not (Test-Path $jbossNew)) {
  Rename-Item -LiteralPath $jbossOld -NewName "INWEBSOF_Web.war"
  Get-ChildItem $deployDir -Filter "INPCV2.war.*" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
  New-Item -ItemType File -Path (Join-Path $deployDir "INWEBSOF_Web.war.dodeploy") -Force | Out-Null
  Write-Host "Renamed JBoss WAR -> INWEBSOF_Web.war"
}

Write-Host ""
Write-Host "DONE. Open Eclipse — Project Explorer should show INWEBSOF_Web"
Write-Host "URLs: http://localhost:8080/inwebsof/login.html"
Write-Host "      http://localhost:8090/inwebsof/login.html"
Write-Host "If project missing: File -> Import -> Existing Maven Projects -> $finalProj"
