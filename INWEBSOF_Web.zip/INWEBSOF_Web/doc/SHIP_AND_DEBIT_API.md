# Ship and Debit API Reference and Request Audit

This document covers the client-facing Ship and Debit API rooted at
`/api/customer/ship-and-debit`. The browser calls are implemented in
`src/main/resources/static/custom_js/SHIPANDDEBIT/ship_and_debit.js` and
`ship_and_debit_create.js`. Java handlers are in `ShipAndDebit.java` and
`ShipAndDebitDocUpload.java`; IBM i calls are made by `ShipAndDebitSql.java`
and `SaveClaim.java`.

## Runtime request audit

`ShipAndDebitApiAuditFilter` and `ShipAndDebitApiAuditInterceptor` record each
mapped API request and completion in the application log. The interceptor is
registered in `WebMvcConfig` for `/api/customer/ship-and-debit/**`. A record
includes the HTTP method and path, Java handler, query/form parameter values,
JSON request field names, content type/length, HTTP status, elapsed time, and
exception class when a handler throws.

Example:

```text
Ship and Debit API method=GET path=/INPCV2/api/customer/ship-and-debit/end-customers
handler=ShipAndDebit#endCustomers params={custCode=[5558], division=[41], loginId=[[REDACTED]]}
bodyFields=[] contentType=null contentLength=-1 status=200 durationMs=42 error=-
```

Values for login IDs, passwords, tokens, secrets, email, comments, and remarks
are redacted. JSON request values and response bodies are not logged; JSON field
names are logged instead. This avoids copying claim details, comments, or other
business data into application logs. File contents are never logged. IBM i
procedure calls have their own `AS400 procedure call [datasource=...]` log
entries. Runtime records go to the application logger/stdout and are subject to
the application's normal log retention and access controls; they are not
written to a separate audit database.

## Common request context and response

The browser sends `custCode` and `loginId` as query parameters for GET requests,
form parameters for `/terms`, and JSON fields for JSON POSTs. The server
resolves these against the current logged-in session using
`UserSessionSupport.resolveProcedureCustomerContext`; the browser values are
not an independent authorization source. Endpoints that need an accepted
terms state use the session status established by `/open` or `/terms`.

JSON endpoints use the `ResponseDataGeneric` envelope:

```json
{
  "errorCode": 0,
  "status": "success",
  "message": "success",
  "data": []
}
```

An error uses the same envelope with `status: "failure"`, an error message,
and `data: null`. A successful row-list endpoint places procedure result rows
in `data`; property names and row counts depend on the IBM i procedure.
Claim save/update errors are shown in a styled dialog. AS/400 bind failures
include the affected claim field and SQLSTATE when available; raw driver
messages, SQL text, and submitted values stay in server logs.

## Endpoint inventory

Every path below is relative to `/api/customer/ship-and-debit`.
`custCode` and `loginId` are optional context values unless noted; the server
resolves the effective values from the active session.

| Method and path | Request parameters | Java handler | IBM i / other operation | Successful output |
|---|---|---|---|---|
| `GET /open` | Optional `custCode`, `loginId` | `ShipAndDebit.open` | `SFLASH.PMS330S(CCM, loginId, OUT role, OUT email, OUT name, OUT DISTRTERMS)`; POS `dbo.Dealer` count for customer | Envelope with `data` containing `custCode`, `loginId`, `accepted`, `role`, `name`, `email`, `posDealerExists` |
| `POST /terms` | Optional `custCode`, `loginId` (form) | `ShipAndDebit.acceptTerms` | `SFLASH.PMS351S(CCM, loginId, OUT status)`; if status is not `Y`, the implementation rechecks with `PMS330S` | `data: {"accepted": true}` on success |
| `GET /claims?status=...` | Required `status`; optional context | `ShipAndDebit.claims` | `SFLASH.PMS324S(INPC, loginId, role, one status)` once per comma-separated status | `data` is a row list for one status, or an object keyed by status for multiple statuses |
| `GET /claims/{claimNumber}` | Path `claimNumber`; optional context | `ShipAndDebit.claim` | `SFLASH.PMS325S(CCM, claimNumber, loginId)` | `data` is the claim line list |
| `POST /claims` | JSON claim body below; or multipart fields `claim` (JSON) and repeated `files` attachments | `ShipAndDebit.create` (JSON) or `ShipAndDebit.createWithDocuments` (multipart) | `PMS328S(CCM, loginId, 'C', OUT claim number)` once, then `PMS334S` once per line; for multipart, stores attachments to encrypted SMB 3.1.1 under the new claim folder; POS `dbo.Dealer` count | `data` includes `claimNumber`, confirmation `message`, `posDealerExists`; multipart also includes `documentsStored` and `documentFiles` |
| `POST /claims/{claimNumber}` | Path `claimNumber`; JSON body below | `ShipAndDebit.update` | `PMS360S` for existing lines whose action is `U` or `D`; `PMS334S` for each new line whose action is `I`. For an insert, `SaveClaim` reads the existing claim header with `PMS325S` and uses its end customer, division, and claim month. All line writes share one transaction. | `data` includes `claimNumber` and confirmation `message` |
| `GET /divisions` | Optional context | `ShipAndDebit.divisions` | `SFLASH.PMS362S(CCM, loginId, customerCode)` | `data` is the division list |
| `GET /end-customers?division=...` | Required `division`; optional context | `ShipAndDebit.endCustomers` | `SFLASH.PMS349S('ESOF', '', customerCode, division)` | `data` is the end-customer list |
| `GET /skus?endCustomer=...&division=...` | Required `endCustomer`, `division`; optional context | `ShipAndDebit.skus` | `SFLASH.PMS350S(CCM, loginId, customerCode, endCustomer, division)` | `data` is the SKU list |
| `GET /invoices?sku=...&claimMonth=...` | Required `sku`, `claimMonth`; optional context | `ShipAndDebit.invoices` | `SFLASH.PMS333S(CCM, loginId, customerCode, sku, claimMonth)` | `data` is the invoice list |
| `GET /late-flag?division=...&claimMonth=...` | Required `division`, `claimMonth`; optional context | `ShipAndDebit.lateFlag` | `SFLASH.PMS387S(division, claimMonth)` | `data` is the late-claim result |
| `GET /claim-check?...` | Required `sku`, `invoiceNumber`, `invoiceDate`, `distInvoiceNumber`, `distInvoiceDate`; optional context | `ShipAndDebit.claimCheck` | `SFLASH.PMS355S(CCM, loginId, sku, invoiceNumber, invoiceDate, distInvoiceNumber, distInvoiceDate, OUT claim status, OUT claim number)`; POS max distributor invoice date query | `data` contains `claimStatus`, `claimNumber`, `posInvDate` |
| `GET /invoice-details?...` | Required `endCustomer`, `sku`, `invoiceNumber`, `invoiceDate`, `distInvoiceDate`; optional context | `ShipAndDebit.invoiceDetails` | `SFLASH.PMS337S` (8 input parameters followed by 13 output parameters) | `data` contains invoice/claim calculation fields such as `UMO`, `AQTY`, `SPERSON`, `RCPRICE`, `TAX`, `FREIGHT`, `DISCOUNT`, `IGST`, `CGST` |
| `GET /rate-contracts?flag=...` | Required `flag`; optional context | `ShipAndDebit.rateContracts` | `SFLASH.PMS261S(CCM, loginId, flag, customerCode, '')` | `data` is the rate-contract list |
| `GET /rate-contracts/detail?number=...` | Required `number`; optional context | `ShipAndDebit.rateContract` | `SFLASH.PMS332S(CCM, contractNumber)` | `data` is the contract detail list |
| `GET /rate-contracts/file?number=...` | Required `number`; optional context | `ShipAndDebit.rateContractFile` | `SFLASH.PMS332S(CCM, contractNumber)`; Java writes an Excel workbook | Binary `.xlsx` download (`ApprovedRC<number>.xlsx`) |
| `POST /rate-contracts/accept` | JSON `contractNumber`, `endCustomer`, optional `statusFlag` (defaults to `A`), optional context fields | `ShipAndDebit.acceptRate` | `SFLASH.PMS262S(CCM, loginId, endCustomer, contractNumber, statusFlag)` | `data: {"message": "Rate contract accepted."}` |
| `GET /report?fromDate=...&toDate=...` | Required `fromDate`, `toDate`; optional context | `ShipAndDebit.report` | `SFLASH.PMS396S(fromDate, toDate, session internal user code, customerCode)` | `data` is the report row list |
| `GET /report/file?fromDate=...&toDate=...` | Required `fromDate`, `toDate`; optional context | `ShipAndDebit.reportFile` | `SFLASH.PMS396S(fromDate, toDate, session internal user code, customerCode)`; Java writes an Excel workbook | Binary `claim-report.xlsx` download |
| `GET /documents/list?claimNumber=...` | Required `claimNumber`; optional context | `ShipAndDebitDocUpload.list` | `PMS325S` verifies the claim for the active login; `BPCSLCLIN.CMW010S(CCM, loginId, '')` resolves the configured share, then SMB listing | `data` is the array of stored file names in that claim folder |
| `POST /documents` | Multipart `claimNumber`, one or more repeated `files` (legacy single `file` also accepted); optional `custCode`, `loginId` | `ShipAndDebitDocUpload.upload` | `PMS325S` verifies claim access; `BPCSLCLIN.CMW010S` then encrypted SMB 3.1.1 write into the claim folder | On success `data` has `files` and `message`; max combined upload is 5 MB |
| `GET /documents?claimNumber=...&name=...` | Required `claimNumber`, `name`; optional context | `ShipAndDebitDocUpload.download` | `PMS325S` verifies claim access; `BPCSLCLIN.CMW010S` then claim-scoped SMB read | Binary file download |

### Claim JSON request bodies

Create claim (`POST /claims`) accepts the following JSON body when no files are
selected. When files are attached, send this JSON in the multipart `claim` field
and send each selected document as a repeated multipart `files` field:

```json
{
  "custCode": "5558",
  "loginId": "USERID",
  "endCustomer": "12345",
  "division": "41",
  "claimMonth": "202610",
  "comments": "",
  "lateRemarks": "",
  "lines": [
    {
      "sku": "SKU001",
      "description": "Example product",
      "invoiceNumber": "INV001",
      "invoiceDate": "20261001",
      "uom": "EA",
      "availQty": "10",
      "salesPerson": "Example",
      "rcPrice": "12.50",
      "distInvoiceNumber": "DINV001",
      "distInvoiceDate": "20261002",
      "distBillQty": "2",
      "distBillPrice": "12.50",
      "claimValue": "1.25",
      "lineComments": ""
    }
  ]
}
```

Update claim (`POST /claims/{claimNumber}`) accepts `custCode`, `loginId`,
`comments`, `lateRemarks`, and a `lines` array. Existing lines provide
`action` (`U` update or `D` delete), `sku`, `invoiceNumber`, `invoiceDate`,
`oldDistInvoice`, `oldDistDate`, `qty`, `claimValue`, `newDistInvoice`,
`newDistDate`, `lineComments`, and `rcPrice`. A new Edit Claim line uses
`action: "I"` and provides the `PMS334S` line fields: `sku`, `description`,
`invoiceNumber`, `invoiceDate`, `uom`, `availQty`, `salesPerson`, `rcPrice`,
`distInvoiceNumber`, `distInvoiceDate`, `distBillQty`, `distBillPrice`,
`claimValue`, and `lineComments`. The `PMS334S` `SKUDESC` argument is limited
to 30 characters; when the UI description starts with the SKU plus `" - "`,
the server removes that display-only prefix before binding the description.
This shared insert path applies to both Create Claim and Update Claim line inserts.
The server verifies the claim with
`PMS325S` and takes its customer, division, and claim month from that result;
clients cannot choose a different header for the new line.

Sample create success (claim number and dealer status are generated at runtime):

```json
{
  "errorCode": 0,
  "status": "success",
  "message": "success",
  "data": {
    "claimNumber": "generated-claim-number",
    "message": "Claim generated-claim-number was submitted.",
    "posDealerExists": "Yes",
    "documentsStored": true,
    "documentFiles": ["invoice.pdf", "photo.jpg"]
  }
}
```

Create Claim's Supporting Documents popup allows the user to select multiple
legacy-supported image/PDF/archive files, review each selected filename, open
it for viewing, or remove it before submitting. The combined size is limited to
5 MB. If the claim is saved but SMB storage fails, the API still returns the
created claim number with `documentsStored: false` and `documentMessage`; the
UI exposes a retry action that calls `POST /documents` without resubmitting the
claim. The document-list and download endpoints are enabled and scoped to the
claim-number subfolder.

## Java file and procedure parameter reference

| Java file / method | Procedure | Parameters in call order |
|---|---|---|
| `ShipAndDebitSql.terms` | `PMS330S` | `appCode`, `loginId`, OUT `ROLE`, OUT `EMAIL`, OUT `NAME`, OUT `DISTRTERMS` |
| `ShipAndDebitSql.acceptTerms` | `PMS351S` | `appCode`, `loginId`, OUT `STATUS` |
| `ShipAndDebitSql.claims`, `claimsByStatus` | `PMS324S` | `claimListAppCode` (`INPC` by default), `loginId`, `role`, `status` |
| `ShipAndDebitSql.claim` | `PMS325S` | `appCode`, `claimNumber`, `loginId` |
| `SaveClaim.claimNumber` | `PMS328S` | `appCode`, `loginId`, `'C'`, OUT `RNUM` |
| `SaveClaim.insertLine` | `PMS334S` | Create Claim: `appCode`, `loginId`, `claimNumber`, `endCustomer`, `division`, `sku`, `description`, `invoiceNumber`, `invoiceDate`, `uom`, `availQty`, `salesPerson`, `rcPrice`, `distInvoiceNumber`, `distInvoiceDate`, `distBillQty`, `distBillPrice`, `claimValue`, `claimMonth`, `comments`, `lineComments`, `lateRemarks`; Edit Claim uses the existing claim's header and the same line arguments |
| `SaveClaim.updateLine` | `PMS360S` | `appCode`, `loginId`, `action`, `claimNumber`, `sku`, `invoiceNumber`, `invoiceDate`, `oldDistInvoice`, `oldDistDate`, `qty`, `claimValue`, `comments`, `newDistInvoice`, `newDistDate`, `lineComments`, `rcPrice`, `lateRemarks` |
| `ShipAndDebitSql.divisions` | `PMS362S` | `appCode`, `loginId`, `customerCode` |
| `ShipAndDebitSql.endCustomers` | `PMS349S` | `'ESOF'`, `''`, `customerCode`, `division` |
| `ShipAndDebitSql.skus` | `PMS350S` | `appCode`, `loginId`, `customerCode`, `endCustomer`, `division` |
| `ShipAndDebitSql.invoices` | `PMS333S` | `appCode`, `loginId`, `customerCode`, `sku`, `claimMonth` |
| `ShipAndDebitSql.lateFlag` | `PMS387S` | `division`, numeric `claimMonth` |
| `ShipAndDebitSql.claimCheck` | `PMS355S` | `appCode`, `loginId`, `sku`, `invoiceNumber`, `invoiceDate`, `distInvoiceNumber`, `distInvoiceDate`, OUT `CLAIMStatus`, OUT `CLAIMNUMBER` |
| `ShipAndDebitSql.invoiceDetails` | `PMS337S` | `appCode`, `loginId`, `endCustomer`, `sku`, `invoiceNumber`, `invoiceDate`, `distInvoiceDate`, `'0'`, then 13 OUT values |
| `ShipAndDebitSql.rateContracts` | `PMS261S` | `appCode`, `loginId`, `flag`, `customerCode`, `''` |
| `ShipAndDebitSql.rateContract` | `PMS332S` | `appCode`, `contractNumber` |
| `ShipAndDebitSql.acceptRateContract` | `PMS262S` | `appCode`, `loginId`, `endCustomer`, `contractNumber`, `statusFlag` |
| `ShipAndDebitSql.report` | `PMS396S` | `fromDate`, `toDate`, session internal user code, `customerCode` |
| `ShipAndDebitSql.shareRows` | `CMW010S` | `appCode`, `loginId`, `''`; used to resolve the CLAIMDOC share for document operations |

Application procedure calls use `inpc.ship-and-debit.app-code` (`CCM` by
default), except claim lists, which use
`inpc.ship-and-debit.claim-list-app-code` (`INPC` by default). All Ship and
Debit AS/400 procedure logs include the configured pool name from
`inpc.ship-and-debit.as400`.
