# Role Rights and User-Role Excel

The Role Rights page manages two separate mappings:

- **Role permissions**: `ia_role_rights` maps a role (`ref_role_code`) to menu modules (`ref_menu_code`).
- **User assignments**: `ia_user_master_roles_group` maps a user (`ref_s_ref_data_code` → `ia_user_master.internal_code`) to a role (`ref_role_code` → `ia_roles.internal_code`).

Changing a user's assignments does not change the role's module permissions, and deleting an assignment never deletes the role itself.

## Source files

| Purpose | Path |
|---|---|
| Role Rights page and Excel popup | `src/main/resources/static/html_files/INPC/ia_role_rights.html` |
| Page behavior, Tom Select remote user search, preview/apply calls | `src/main/resources/static/custom_js/role_rights.js` |
| Role LOV, user autocomplete LOV, menu-group autocomplete LOV, role-rights APIs | `src/main/java/com/mmm/system/RoleRights.java` |
| Excel downloads and user-role workbook validation/application | `src/main/java/com/mmm/system/RoleRightsUploadDownload.java` |
| Locally vendored Tom Select JS | `src/main/resources/static/nuiassets/libs/tom-select/js/tom-select.complete.min.js` |
| Locally vendored Tom Select CSS | `src/main/resources/static/nuiassets/libs/tom-select/css/tom-select.default.min.css` |
| Tom Select license | `src/main/resources/static/nuiassets/libs/tom-select/LICENSE` |

Tom Select is loaded from the application's local `nuiassets` path; the page does not depend on a CDN.

## User-role popup

The **Upload User Roles** popup shows available role names and offers:

- **Download Blank Format**: downloads `user_role_upload_format.xlsx`, with a `User Role Upload` sheet and columns `ENL ID`, `Role Name`, `Action`. The example row (`YOUR_ENL_ID`, `YOUR_ROLE_NAME`, `I`) must be replaced or removed before upload.
- **Download Existing User Roles**: downloads the current assignments with `ENL ID`, `cust_code`, `Customer Name`, `Name`, `Role Name`, `Last Login Time`, `Status`, and `Action`. Customer details, user name, last login, and status (`ia_user_master.active`) are for reference; upload validation reads `ENL ID`, `Role Name`, and `Action` by header and ignores the extra columns. Action cells are blank. The selected role and users both filter the workbook; with no filters, all user-role assignments are exported.
- **Choose Excel to Upload**: validates the workbook, shows errors in the popup or a preview of the proposed additions/removals, then asks for confirmation before applying.

The main Role Name selector uses the locally bundled Choices.js single-select with in-dropdown search; its Bootstrap-like sizing and option heights are styled globally in `css/mainpage-overrides.css`. The user assignment filter remains a locally bundled Tom Select multi-select.

### Multiple-user selection

The user filter is a searchable Tom Select multi-select. Selected tags use a light-gray background. Searching starts at two characters and the LOV returns up to 25 matching users by ENL ID or name. The role selector shows assignments for that role; selecting users without a role shows every role mapped to those users. Both filters can be combined. The user-role view uses `Common.DataTable` from `tarka_common_datatable.js`, providing search, sorting, pagination, and a frozen header within its scroll area. Selected ENL IDs and the role code are sent to the export endpoint by POST. A single export is limited to 500 selected users; the UI and server both enforce that limit. An empty user selection means no user filter.

## Workbook actions and validation

| Action cell | Effect |
|---|---|
| Blank or `I` (case-insensitive) | Add the user-role mapping if it does not already exist; otherwise leave it unchanged |
| `D` (case-insensitive) | Delete only that user's mapping to that role; if it is not assigned, leave it unchanged |

Rows not included in the workbook are unchanged. Deleting a row from the downloaded spreadsheet does **not** remove its assignment; use `D`.

Upload validation requires `ENL ID`, `Role Name`, and `Action` columns (header case and extra whitespace are normalized). The upload accepts the `User Role Upload` or `User Master` sheet, or falls back to the first sheet. It rejects empty/invalid workbooks, unknown ENL IDs or role names, invalid actions, duplicate user-role pairs, and files with more than 5,000 non-empty assignment rows. Any validation error prevents all changes. Applying a valid upload revalidates the workbook and applies its rows in one transaction.

## Endpoints

Base paths are relative to the application's `$host_url`.

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `titpl/role_rights/GetRoleNamesLov` | Load roles used by the Role Name selector and popup role table |
| `GET` | `titpl/role_rights/GetUsersForRoleDownloadLov?term=...` | Search users by ENL ID or name; returns up to 25 matches |
| `GET` | `titpl/role_rights_upload_dowload/getUserRoleAssignments` | Load assignments filtered by optional `role_code` and/or comma-separated `enl_ids` |
| `GET` | `titpl/role_rights/GetMenuGroupNamesLov?app_type=...&term=...` | Search menu groups for the Role Rights filter |
| `GET` | `titpl/role_rights/GetModuleNamesforSelectedRoles` | Get module permissions for an application and role |
| `GET` | `titpl/role_rights/SaveRoleDetails` | Save role-to-module permission mappings |
| `GET` | `titpl/role_rights_upload_dowload/userRoleRightsDownlaod` | Download the existing multi-sheet role-rights/user-role workbook |
| `GET` | `titpl/role_rights_upload_dowload/downloadUserRoleUploadFormat` | Download the blank user-role upload format |
| `GET` or `POST` | `titpl/role_rights_upload_dowload/downloadExistingUserRoles` | Download all mappings, or mappings filtered by comma-separated `enl_ids` and/or `role_code` |
| `POST` | `titpl/role_rights_upload_dowload/uploadUserRoles` | Validate an uploaded workbook and return row operations/errors without applying changes |
| `POST` | `titpl/role_rights_upload_dowload/applyUserRoles` | Revalidate and transactionally apply a valid workbook |
