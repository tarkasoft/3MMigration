# Authentication package (`com.mmm.authentication`)

## Common ENL_ID path

Once ENL_ID is known (from `login.html` or Microsoft IMEXT response), call:

- **Service:** `AuthService.bootstrapSessionByEnlId(request, enlId)`
- **HTTP:** `POST /INPCV2/api/auth/bootstrap-by-enl-id` with form field `enlId`

Both establish the same HTTP session attributes (`loginId`, roles, `cust_name`, `cust_code`, `see_other_cust_data`, `inpc_hh`, `inpc_mm`, …). Login reads the first row of `dbo.inpc_configuration` and stores `inpc_hh` and `inpc_mm`. Blank or missing values are 0. Each program replaces SQL `getdate()` with `dateadd(MINUTE, inpc_mm, dateadd(HOUR, inpc_hh, getdate()))` using those session numbers. A successful bootstrap also sets `ia_user_master.last_login_date` the same way. Opening menus does not change that column.

## API shapes

### `POST /api/auth/login` (validate only)
Success `data`: `{ loginId, redirect, theme_json? }` - no menus/roles dump.

### `GET /api/auth/menus` (and `/me` user map)
Success `data` includes: `loginId`, `loginUserName`, `loginUserType`, `roles`, **`cust_name`**, **`cust_code`**, **`see_other_cust_data`**, `customerName` (portal), `portal`, `menus`, `theme_json`, `appType`, **`welcome_title`**, **`welcome_msg`**, `show_welcome`.

`loginUserType` is `ia_user_type.user_type_name` for `ia_user_master.u_user_type` (that column stores `ia_user_type.internal_code`). Blank still becomes Customer.

Welcome popup rules, acknowledgement, `active`, and the 1 Oct 2026 Customer notice are in [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md). `show_welcome` is `Yes` only when `welcome_msg` is non-empty.

### Client cookies (set after menus load via `inpcSetCookie`)
| Cookie | Source / notes |
|--------|----------------|
| `fw_cust_name` / `fw_cust_code` | Home customer from menus |
| `fw_see_other_cust_data` | Permission for Change Customer menu |
| `fw_override_cust_name` / `fw_override_cust_code` | Synced from home unless `fw_customer_overridden=Yes` |
| `fw_customer_overridden` | Set by Change Customer Update flow |
| `fw_loginId` | Login id |

Cleared on logout and when arriving at `index.html` / `login.html` (incl. browser Back from MainPage) via `inpcClearUserCookies` / `inpcClearAllDocumentCookies` in `js/inpc-portal-cookies.js` (also clears any remaining `fw_*` and document cookies on `/` or `/INPCV2`). Prefer `fw_*` names; do not rely on bare `cust_name` / `cust_code` cookie names for new work.

## Verify
1. Restart Tomcat / republish INPCV2 (Java moved packages).
2. Open `/INPCV2/login.html` → sign in with ENL_ID.
3. On MainPage, DevTools → Application → Cookies: expect `fw_cust_name`, `fw_cust_code`, `fw_loginId`, `fw_see_other_cust_data`.
4. Network → `api/auth/menus` JSON includes those fields (plus `see_other_cust_data`).

## Global URLs (`$host_url` / `$app_url`)

Set **once** in `static/js/fw-globals.js`, loaded by `MainPage.html` before `MainPage.js` / feature scripts.

| Global | Meaning |
|--------|---------|
| `window.$host_url` (alias `host_url`) | Titpl/framework base, e.g. `/INPCV2/titpl/` - use for `auto_complete/*`, FW save, etc. |
| `window.$app_url` | App context root, e.g. `/INPCV2/` - use for Spring `api/auth/*`, `api/portal/*` |

**Do not** redefine `var host = ...` inside page/feature scripts (`change_customer.js`, module JS, etc.). Use the globals.

`MainPage.js` only asserts the globals exist; it does not invent a second host.

## Change Customer Code

Full detail: **[CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md)**.

Summary:

- Session + menus/me: `see_other_cust_data`; cookie `fw_see_other_cust_data`; Settings/profile item **Change Customer Code** when value is `Yes`.
- UI: `custom_js/change_customer.js` on MainPage (after `MainPage.js`); modal Update sets override cookies via **`inpcSetCookie` only**.
- Production autocomplete: `GET /api/portal/change-customer/autocomplete?value=` (`com.mmm.portal_common.ChangeCustomer`) - response rows are **`code` / `name` / `value` only** (no `internal_code`).
- Test-only siblings: `autocomplete-without-map`, `autocomplete-without-map-no-scalars` (same shape).
- While overridden, menus refresh must not wipe `fw_override_cust_*`; header shows override vs home per `fw_customer_overridden`.

## Session expiry errorCode **-9**

Unauthenticated / session-expired API responses use **`errorCode: -9`** (not `-1`) with message typically `Please login once again` (HTTP **200** JSON body).

| Layer | Behaviour |
|-------|-----------|
| `SessionLoginInterceptor` | When `security.session-check.enabled=true`, emits `-9` for gated `/api/**`. |
| Controllers | `AuthController` (`/me`, `/menus`, customers autocomplete), `ChangeCustomer`, `ThemeController.requireLoginId` use `UserSessionSupport.SESSION_EXPIRED_ERROR_CODE` (`-9`). |
| Client | `MainPage.js`: **`inpcHandleSessionExpired`**. Detects IMEXT via `GET api/info` → `data.imextEnabled` (`window.$imextEnabled`). **Local** (IMEXT off): redirect `login.html`. **IMEXT on**: `location.reload()` / `top.location.reload()` so IMEXT can re-prompt. Wired via jQuery `ajaxSetup.dataFilter` + `ajaxSuccess` (and `CallLogout` alias for legacy `MainPageNew.js`). |

Keep `security.session-check.enabled` as today; only the error code / client handling change.

## Global session check (`security.session-check.enabled`)

Optional HandlerInterceptor (`SessionLoginInterceptor`) registered from `WebMvcConfig` when the flag is **true**.

| Flag | Behaviour |
|------|-----------|
| `false` (default) | Interceptor **not** registered - behaviour unchanged; controllers keep their own `UserSessionSupport.isLoggedIn` checks. |
| `true` | All `/api/**` require a logged-in session (`UserSessionSupport.isLoggedIn`). Failures return JSON `SetError(-9,"failure","Please login once again")`, HTTP **200**, and do not enter the controller. |

**Excluded** (remain reachable without session): `/api/auth/login`, `/api/auth/bootstrap-by-enl-id`, `/api/auth/logout`, `/api/info`, `/api/test/**`, `/api/cir/**`, `/api/csd/**`. Actuator stays outside `/api/**`.

**Not excluded:** `/api/portal/**`, `/api/auth/me`, `/api/auth/menus` (and other auth APIs that need a user).

Flip the flag in `application.yml`, then **Eclipse republish / Tomcat restart** so the interceptor registration picks up the change.

## IMEXT / IAMExt (Azure AD B2C)

Profile: `spring.profiles.active=imext` loads `application-imext.yml`. Flag: `security.imext.enabled=true`.

### Flow
1. Browser opens `/INPCV2/api/auth/imext/start` (or Spring `/oauth2/authorization/iamext`).
2. Redirect to B2C authorize (`B2C_1A_3MA`).
3. Azure returns to `/login/oauth2/code/iamext` (must match Azure app registration).
4. `ImextOAuth2LoginSuccessHandler` reads claim `upin` → ENL_ID → `AuthService.bootstrapSessionByEnlId`.
5. Redirect `/api/auth/imext/response` → `MainPage.html`.

### Config
See `application-imext.yml` (client id/secret/scopes/provider URIs). Prod redirect in legacy app:
`https://inpc.3m.com/inpc/login/oauth2/code/iamext`. Local WAR uses context `/INPCV2` and port 8090 on EAP.

### Local smoke
1. Ensure Azure redirect URI includes your local callback.
2. Restart with profile `imext`.
3. Hit `http://localhost:8090/INPCV2/api/auth/imext/start`.
4. After B2C login, you should land on MainPage with session cookies.
