# Rebate Programs Migration

## Purpose and status

This document tracks the migration of the legacy Rebate Program List page to
the INPCV2 `INFOAPPS` datasource. The requested scope is all three tabs,
including claim submissions, invoice/GST and supporting-document handling,
notifications, and Excel export.

**Multi-tab DOM (2026-10-04):** shell root is `#m_rebate_programs` (`RebateProgram.ROOT`).
Client get/set uses `RebateProgram._$home()` / `RebateProgram._$popup()` /
`RebateProgram._$("#…")` / `_el`. Program / claim / discrepancy / terms modals
live under `#m_rebate_programs_popup` (`RebateProgram.POPUP_ROOT`). On show, that
host (not each modal alone) is moved to `document.body` so fixed positioning
survives desktop↔mobile layout switches; orphan modals are re-parented into the
popup host. `Load` / `OpenClaim` call `_scrubOrphanPopups()` so duplicate popup
hosts left on `document.body` after a menu reload are removed (keeps the latest).
Claim form reads/writes go through `_claimContent$()` (live
`#rebate_claim_modal` → `#rebate_claim_content`) so totals and fields are not
taken from a stale duplicate id. Module CSS is scoped with
`:is(#m_rebate_programs,#m_rebate_programs_popup,#rebate_*_modal)`. The HTML
fragment force-reloads `custom_js/REBATE/rebate_programs.js?v=…` via
`includeJsFilesMannuallyOverride`. Same rule as
[JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md).

The current INPCV2 `INFOAPPS` datasource is configured for the `dINFOPOINT`
database. Read-only SQL Server metadata queries have now confirmed the
presence of the rebate tables described below. This verifies object metadata
only; it does not validate business data, joins, permissions for every
operation, or whether this is the intended production/write environment.

## Source code reviewed

| Area | Legacy source |
| --- | --- |
| Rebate Program List HTML | `..\..\inpc\inpc\src\main\webapp\resources\rebateprograms\html\RebateProgList.html` |
| Page JavaScript | `..\..\inpc\inpc\src\main\webapp\resources\rebateprograms\js\rebate.js` |
| Claim/invoice JavaScript | `..\..\inpc\inpc\src\main\webapp\resources\rebateprograms\js\upload_cust_inv.js` |
| Main page controller and SQL | `..\..\inpc\inpc\src\main\java\com\mmm\rebatenew\RebateProgram.java` |
| Claim/invoice controller and SQL | `..\..\inpc\inpc\src\main\java\com\mmm\rebatenew\UploadCustInvoice.java` |
| Excel report controller and SQL | `..\..\inpc\inpc\src\main\java\com\mmm\rebatenew\GenerateExcelReport.java` |
| Shared rebate queries/mail data | `..\..\inpc\inpc\src\main\java\com\mmm\rebatenew\RebateCommon.java` |
| Mail delivery | `..\..\inpc\inpc\src\main\java\com\mmm\rebatenew\SendRebateMail.java` |
| Rebate attachment transfer | `..\..\inpc\inpc\src\main\java\com\mmm\rebatenew\RebateDocFtpUpload.java` |

The legacy HTML page dynamically loads `rebate.js`, `upload_cust_inv.js`, and
Bootbox. The migrated INPCV2 page uses one Rebate module JavaScript file.

## Page behavior and request flow

The page has three tabs: **Program Enrollment**, **YTD Achievement**, and
**My Claims**. Initial page setup calls `GetRebateLoginCustomer`; the server
uses the legacy login session's customer code and looks up the customer's
`reb_customer_master.internal_code`. The page then uses that internal code in
subsequent requests.

| Page action | Legacy endpoint | Observed behavior |
| --- | --- | --- |
| Resolve logged-in customer | `GET /rebate_program/GetRebateLoginCustomer` | Returns customer code and rebate customer internal code. |
| Load enrollment list | `GET /rebate_program/GetNewEnrollProgram` | Lists approved customer-program mappings, enrollment state, program period/target, and cutoff state. |
| Enroll | `GET /rebate_program/UpdateProgramDetails` | Updates the mapping as accepted by the customer and sends an enrollment email. The page then reloads the list. |
| View program / YTD details | `GET /rebate_program/GetProGramDataForPopUp` | Returns program and customer mapping details, plus interim YTD achievements/payout. |
| Download program document | `GET /rebate_program/GetProgramDocPath`, then download helper | Looks up the document path/name and downloads through the rebate file-transfer helper. |
| Load YTD tab | `GET /rebate_program/GetYTDData` | Returns achievement, target values, provisional payout, cutoff status, and discrepancy-report state. |
| Read discrepancy response | `GET /rebate_program/GetErrorResolvedRemarks` | Returns BSO remarks for a discrepancy-history record. |
| Report discrepancy | `GET /rebate_program/ReportErrorForDescripiancySubmit` | Creates a pending YTD or invoice discrepancy record and sends customer/BSO email. The UI limits initial reporting to a seven-day window. |
| Load claims | `GET /rebate_program/GetClaimDetails` | Returns approved incentive claims and their claim status, credit-note number, achievement, and error state. |
| Load invoice claim form | `GET /rebate_upload_cust_inv/GetPendingActionsData` | Loads a payout case, invoice/GST evidence, required documents, customer data, and supporting details. |
| Upload/delete/submit claim | `/rebate_upload_cust_inv/*` | Uploads invoice and GST files and program documents, deletes a screen document, then submits or resubmits the claim. |
| Export claims report | `GET /rebate_excel_report/GeneateRebateExcelReport` | Downloads an Excel report filtered by optional approval dates. |

The claim tab has a multi-step workflow: a claim can be opened, invoice and
GST-proof documents can be uploaded, supporting program documents can be
managed, and the final submission records invoice/verification details and
changes the claim status. Rework submissions use a separate status path. This
workflow is included in the selected full **My Claims** migration scope.

## Legacy data and business rules observed

The `RebateProgList.html` page's main controller is
`com.mmm.rebatenew.RebateProgram`. Its associated claim/upload workflow is in
`com.mmm.rebatenew.UploadCustInvoice`. This migration analysis is limited to
those `com.mmm.rebatenew` page and backend sources and their direct
dependencies.

Read-only metadata inspection on the configured INFOAPPS SQL Server verified
the following objects as `dbo` user tables in `dINFOPOINT`:

- `reb_customer_master`, `reb_program`, `reb_division`,
  `reb_prg_cust_mapping`
- `reb_cust_ytd_interim`, `reb_cust_incentive`, `reb_cust_ytd`,
  `reb_report_err_history`
- `reb_program_udoc_group`, `reb_program_document_group`,
  `reb_prg_cust_mapping_docs`, `reb_document_type`
- `reb_cust_invoice`, `gst_state_codes`, `reb_user_master`,
  `reb_rebate_setup`
- `SO_ItemMaster`, `SO_CustomerMaster`

Selected observed schema details important to the migration:

| Object | Verified columns / types |
| --- | --- |
| `reb_customer_master` | `internal_code int NOT NULL`, `cust_code varchar(50)`, `status varchar(10)` |
| `reb_program` | `internal_code int NOT NULL`, `division varchar(50)`, `program_name varchar(500)`, `program_no varchar(50)`, `target_type varchar(50)`, `start_date` / `end_date` / `cut_off_date date`, `is_deleted varchar(5)` |
| `reb_prg_cust_mapping` | `ref_cust_code varchar(50)`, `ref_prg_code varchar(50)`, `approval_status varchar(25)`, `target int`, acceptance type/by `varchar(50)` and acceptance date `datetime` |
| `reb_cust_ytd_interim` | customer/program refs are `int`; `ytd_achievement bigint` |
| `reb_cust_ytd` | `ref_cust_code varchar(50)`, `ref_prg_code int`, `payout_bso_case_no bigint` |
| `reb_cust_incentive` | customer/program refs are `int`; `claim_status varchar(50)`, `claim_bso_case_no bigint` |
| `reb_cust_invoice` | customer/program refs are `int`; `state_code varchar(50)`; `uploaded_by` / `created_by` / `modified_by` are `int` (customer `internal_code`, not login id) |
| `reb_report_err_history` | `error_type varchar(50)`, `error_status varchar(20)` |

The customer/program reference columns do not have one consistent SQL type
across these tables: for example, `reb_prg_cust_mapping.ref_cust_code` is
`varchar(50)` while `reb_cust_ytd_interim.ref_cust_code` is `int`, and
`reb_cust_ytd.ref_cust_code` is `varchar(50)`. Preserve the actual column
types in parameter binding and verify joins/conversions against representative
records before enabling customer-scoped reads or writes in the target runtime. `reb_program`
does not expose `approval_status`; the legacy enrollment filter reads that
field from `reb_prg_cust_mapping`.

The main rebate controller executes direct SQL against these verified
rebate-domain tables:

- `reb_customer_master`: customer code, rebate customer ID, contact and tax
  information.
- `reb_program`, `reb_division`: program metadata, dates, targets, division,
  approvers, and email settings.
- `reb_prg_cust_mapping`: program/customer association, approval, target, and
  customer enrollment acceptance.
- `reb_cust_ytd_interim`: interim achievement and provisional payout.
- `reb_cust_incentive`: final claim/payout and claim status.
- `reb_cust_ytd`: payout breakdown by state and SKU.
- `reb_report_err_history`: customer discrepancy reports and BSO resolution.
- `reb_program_udoc_group`, `reb_program_document_group`,
  `reb_prg_cust_mapping_docs`, `reb_document_type`: program and claim
  supporting documents.
- `reb_cust_invoice`, `gst_state_codes`: invoice data, state tax details, and
  invoice/GST document metadata.
- `reb_user_master`, `reb_rebate_setup`, and `SO_ItemMaster`: approver/contact,
  rebate setup, and SKU/HSN support data.

Observed rules include:

- The enrollment list is filtered to `approval_status='Approved'`. A customer
  can enroll only before its cutoff date; an existing acceptance is displayed
  as enrolled.
- Program targets are displayed as INR values or units according to
  `target_type`. The detail popup also displays dates, target descriptions,
  BSO remarks, and downloadable program documents.
- YTD values and provisional payout come from interim records. Discrepancy
  reports are tracked separately as `YTD` or `Invoice`, with `Pending` and
  `Resolved` states and BSO remarks.
- Claim rows are based on approved incentive records and their linked customer
  program acceptance. UI status text includes special handling for
  `Submitted`, `Sent for Rework`, and `Credit Note Generated`.
- Invoice submission records the customer invoice/tax data, checks submitted
  declarations, updates the claim and invoice statuses, and sends notification
  email. Claim documents are transferred to a configured remote share; SQL
  metadata and the file transfer therefore form a multi-system operation.

The page's SQL is SQL Server flavored (`ISNULL`, `GETDATE`, `DATEDIFF`,
`CONVERT`). The claim workflow and export have additional table joins and
status/date behavior that need to be preserved deliberately, not inferred from
the enrollment list alone.

## INPCV2 integration pattern and target boundary

INPCV2 already defines `HibernateFactoryRegistry.INFOAPPS` and uses the named
factory for other modules. The intended patterns are:

- Keep the migrated page in the existing INPCV2 static HTML/JavaScript
  structure, with one HTML file and one page JavaScript file where practical;
  use standard semantic HTML and maintainable JavaScript consistent with the
  COA module.
- Put server-side functionality in the `com.mmm.rebate` package and follow
  the existing COA Java conventions for Spring APIs, validation, response
  handling, logging, and separation of responsibilities.
- Read with `NativeQuerySupport.executeQuery(registry,
  HibernateFactoryRegistry.INFOAPPS, sql, parameters)`.
- Bind all request values; do not concatenate customer IDs, remarks, dates, or
  other client-provided values into SQL.
- Perform related writes in an INFOAPPS session transaction using the
  session-scoped `NativeQuerySupport` update helper; roll back on failure.
- Resolve the customer's allowed context from the authenticated portal
  session (including the existing authorized customer-override rules). Do not
  trust a browser-supplied rebate customer internal code as authorization.
- Use `Common.GetProcedureCustomerContext()` on the page and validate/resolve
  that context again on the server, following COA's authorized customer
  override behavior.

The configured INPCV2 INFOAPPS datasource is connected to `dINFOPOINT`, and
the rebate tables above were confirmed there. The legacy `rebatenew` code
accesses a separately injected SQL Server datasource. Metadata presence does not
confirm that the configured account has all required read/write permissions,
that records and foreign-key relationships are complete, or that the
configured database is the intended target for rebate writes. Confirm those
details before enabling mutations. No customer/program business rows were
read during this schema check.

## Initial implementation

The INPCV2 implementation is in place:

- `src/main/resources/static/html_files/REBATE/rebate_programs.html`
- `src/main/resources/static/custom_js/REBATE/rebate_programs.js`
- `src/main/java/com/mmm/rebate/RebatePrograms.java`
- `src/main/java/com/mmm/rebate/RebateProgramSql.java`
- `src/main/java/com/mmm/rebate/RebateDocUpload.java`
- `src/main/java/com/mmm/rebate/RebateMail.java`
- `src/main/java/com/mmm/rebate/RebateExcel.java`

### Current implementation and presentation

The page is served through the existing static HTML/JavaScript module loader:

- `src/main/resources/static/html_files/REBATE/rebate_programs.html`
- `src/main/resources/static/custom_js/REBATE/rebate_programs.js`

The Java implementation uses `com.mmm.rebate` and the INFOAPPS datasource.
`RebatePrograms` owns the customer-facing API and claim/document workflows;
`RebateProgramSql` contains parameterized SQL Server queries and transaction
helpers; `RebateDocUpload` handles SMB transfer using the share returned by
the AS/400 `CMW010S` procedure; `RebateMail`
handles notifications; and the claims workbook has its own `RebateExcel`
controller. Trim and SQL dates use `com.mmm.titpl.CommonFunctions`
(`import static` `text` / `sqlDate`), same as TSD — invoice and export
approval dates normalize to `yyyy-MM-dd` before INFOAPPS writes/filters.

The three page tabs are Program Enrollment, YTD Achievement, and My Claims.
Enrollment and claims use `Common.DataTable` for search, sorting, client-side
pagination, and page-size choices (50, 100, 150, 200). The YTD table has its
own row rendering. Loading states use the shared `showLoader` / `hideLoader`
API from `js/inpc_loader.js` (same as TSD/CIR), not a Rebate-only spinner.
The page shell uses the same rounded white surface as CIR
home in light mode. Its title and supporting text are vertically centered on
one header row, and the title, tabs, and tab panels share the same horizontal
edges. Dark mode keeps that shell transparent. Tab/card headings reuse the
theme-aware `inpc-page-banner` treatment. Rebate-scoped dark-mode rules follow
`html[data-theme-mode="dark"]` and cover tables, toolbars, badges, controls,
and modals without changing shared theme files. Modals use Bootstrap 5 markup
and `bootstrap.Modal` APIs.

The program-details response and popup include program number, name,
description, type, division, period, target, cutoff date, BSO remarks, and a
program-document download action when a document is available. Claim details
are presented as summary cards, invoice and supporting-document sections,
approval remarks, and an editable declaration when the claim is eligible.
Each service invoice is one `.rebate-claim-inv` card: read-only facts
(state / 3M GST / HSN / description + claim amt) above a single editable
entry table (GST type, cust inv no/date/amt, Inv/GST browse, Upload).
Multiple invoices stack as separate cards (typically up to 3–4); save and
per-row upload still treat one `.rebate-claim-inv` as one invoice.

**Claim modal chrome**

| Surface | Width / style |
| --- | --- |
| Claim (`#rebate_claim_modal`) | **85%** viewport (`#rebate_claim_modal .modal-dialog` / `.rebate-claim-dialog`; full-width on ≤767px) |
| Terms & Conditions (`#rebate_claim_terms_modal`) | **80%** viewport; teal gradient header + white title; z-index above claim (1095) |
| Discrepancy / program | Bootstrap `modal-lg` (unchanged) |

On mobile (≤767px) the entry table stacks as labeled fields (`data-label` +
CSS). Module `<style id="rebate-programs-css">` is moved to `document.head`
on Load; `_ensureCssInHead` **replaces** any older copy so tab reloads pick up
CSS changes. Field captions use `.rebate-k` / `.rebate-v` (not generic
`.label`, which clashes with portal CSS).

**Invoice card facts / browse / total**

- Read-only facts row: State | 3M GST No | HSN/SAC | Description on **one**
  line (Description beside HSN/SAC; four-column grid, not `fact-wide`).
- Browse File sits in a 31px `.rebate-file-control` row aligned with the GST /
  inv inputs; file name + smaller View/Delete icons stack in `.rebate-file-meta`
  below.
- **Total Claim Amount (Incl. GST)** sums `inv_value` across cards into
  `data-total-incl` on `#rebate_claim_total_amt`. Editable mode refreshes from
  `.rebate-invoice-value` inputs; **read-only does not re-run input sum** (avoids
  stale totals like a previous claim’s amount after tab/modal reuse). Refresh
  is scoped via `_claimContent$()` to the live `#rebate_claim_modal`.

**Per-row invoice upload:** after Inv/GST upload succeeds, show a success
alert only — do **not** close the claim modal and do **not** call
`OpenClaim` to rebuild the form. Mark `data-has-invoice` / `data-has-gst` and
the browse control as uploaded in place (`_afterInvoiceUpload` /
`_markBrowseUploaded`). If the invoice copy is already on the claim (path or
display name / `data-uploaded`) and the user changes GST type / inv no / date /
amt without browsing a new file, **Upload** calls
`POST /api/customer/rebate/claim/invoice-details` (field upsert only via
`RebateProgramSql.updateInvoiceDetails`). Final claim **Submit** still
requires Inv+GST paths on server, closes the modal, and refreshes My Claims;
**Save for Later** closes and refreshes (draft persist).

**My Claims grid columns** (left → right): Claim No, Program No, View,
Program Name, Division, Program Period, Final Payout (INR), Claim Status,
Credit Note No, **Program Target**, **Final Achievement** (Target /
Achievement at the end; money columns `textAlign: "right"`). Final Payout,
Program Target (non-Quantity), and Final Achievement use `_money` →
`INR` + `en-IN` grouping (e.g. `INR 1,90,000.00`).

Claim status mapping for non-Rebate programs is performed in SQL, matching
the legacy rule: `Credit Note Processing` and
`Submitted for Credit Note process` are displayed as
`GSTR-2A Confirmation Awaited`.

### Claims Excel export (designed and implemented)

My Claims toolbar: optional **From Date** / **To Date** (both blank or both
set; framework `dd/mm/yyyy` pickers) + **Export to Excel**
(`RebateProgram.ExportClaims` → `window.location` download with
`custCode` / `loginId`).

`RebateExcel.java` is a separate Spring controller, mapped under
`/api/customer/rebate`; the export route is
`GET /api/customer/rebate/claims/export`. The route validates the
authenticated/overridden customer context and optional approval-date range
(`d_approved_date` on `reb_cust_incentive`) before calling
`RebateProgramSql.claimsExport`. Output filename: `rebate_claims.xlsx`.

The export follows the legacy `GenerateExcelReport.WriteExcelData`
16-column layout, at one row per claim/state/invoice join:

| # | Excel header | Data mapping |
| --- | --- | --- |
| 1 | Claim No | `reb_cust_incentive.claim_no` |
| 2 | Program No | `reb_program.program_no` |
| 3 | Program Name | `reb_program.program_name` |
| 4 | Division | `reb_division.div_name` |
| 5 | Program Period | Program start and end dates |
| 6 | Program Target | Customer-program mapping target |
| 7 | Final Achievement | Summed interim YTD achievement |
| 8 | Final Payout | State-level `reb_cust_ytd.incentive_amt` |
| 9 | Claim Status | Legacy non-Rebate status mapping |
| 10 | Credit Note No | `reb_cust_incentive.credit_note_no` |
| 11 | State Code | `reb_cust_ytd.state_code` |
| 12 | 3M GST No | `gst_state_codes.gst_no` |
| 13 | Claim Value | Final payout, as in the legacy export |
| 14 | Invoice No | `reb_cust_invoice.cust_inv_no` |
| 15 | Invoice Date | `reb_cust_invoice.cust_inv_date` |
| 16 | Invoice Value | `reb_cust_invoice.inv_value` |

The workbook header is bold Arial 10, centered vertically and horizontally,
with an ivory-like pale yellow fill, thin borders, and auto-sized columns.
The XLSX uses real numeric cell values for target, achievement, payout, claim
value, and invoice value. SQL parameters are bound rather than interpolated.
The legacy export writes the GST number and state code under the opposite
headers; the migrated export maps each value to its correctly named column.

Changes under `src/main/resources/static` are also copied into the current
deployment output trees when explicitly synchronized:
`target/classes/static` and `target/INPCV2/WEB-INF/classes/static`. Java
changes require the normal application redeploy/restart; copying static
assets alone does not deploy Java controllers or SQL changes.

### Claim document upload and update

The claim-document upload/update flow is implemented in
`RebatePrograms.java` and `RebateProgramSql.java`, with SMB transport in
`RebateDocUpload.java`:

- `POST /api/customer/rebate/claim/upload` stores invoice or GST evidence in
  the CMW010S-provided `REBATE` attachment location and updates `reb_cust_invoice` fields
  `u_invoice_doc_name` / `u_invoice_doc_path` or
  `u_invoice_gst_doc_name` / `u_invoice_gst_doc_path` (also upserts tax/inv
  fields via shared `upsertInvoiceDetails`).
- `POST /api/customer/rebate/claim/invoice-details` updates GST type, invoice
  number/date/value when Inv evidence is already on the claim (no new file).
- `POST /api/customer/rebate/claim/program-document` stores a supporting
  program document and updates `reb_prg_cust_mapping_docs.doc_name` and
  `doc_path` for its customer, program, document type, and claim case.
- Re-uploading a supporting document replaces its mapping row in one INFOAPPS
  transaction. `DELETE /api/customer/rebate/claim/program-document/{documentCode}`
  removes that customer's matching document mapping.
  `DELETE /api/customer/rebate/claim/evidence/{program}/{claimCase}/{stateCode}/{kind}`
  clears invoice or GST evidence paths on `reb_cust_invoice` for an editable claim.
  The claim popup shows View / Delete (same pattern as CIR/TSD) after Browse or
  after a successful upload.
- File names are generated server-side, original display names are sanitized,
  uploads are limited to 20 MB and supported document/image extensions, and
  SMB is restricted to encrypted SMB 3.1.1. Share location and credentials
  are retrieved for each upload/download from
  `BPCSLCLIN.CMW010S('REBATE', '', 'ATTACHMENT')` through the AS400 datasource.
  The returned `NWPATH`, `NWLID`, and `NWPWD` values are used for the SMB
  connection; credentials are never logged. The remote folder comes from the
  procedure path, with `REBATE` retained as the fallback when no folder is
  included in that path.

The page exposes Program Enrollment, YTD Achievement, and My Claims. The API
uses authenticated portal customer context, parameterized INFOAPPS queries,
transactional claim updates, the CMW010S-provided Rebate SMB share over
encrypted SMB 3.1.1 for evidence files, and the existing SMTP host conventions
for enrollment, discrepancy, and claim notifications. The claims export is
generated as an Excel workbook.

No INFOAPPS records were changed and no SMB upload/download or email was
triggered while implementing. A menu/module record still needs its `html_path`
and `js_path` configured to these static assets; no menu configuration was
written as part of this code change. The build verifies Java compilation, but
database permissions, actual column constraints, SMTP delivery, and SMB access
must be validated in the target runtime before enabling customer use.

## Remaining verification before production

1. Verify exact constraints and column nullability for all write paths against
   the target INFOAPPS schema, and verify the connected database account has
   the required permissions.
2. Verify customer identity mapping for customer and authorized-override
   accounts, including users without a `reb_customer_master` record.
3. Confirm `CMW010S('REBATE', '', 'ATTACHMENT')` returns a valid SMB path and
   credentials, and verify the returned folder has appropriate write
   permissions.
4. Confirm SMTP reachability, approver addresses, mail recipients, and
   notification templates.
5. Exercise cutoff and seven-day reporting boundaries, claim submission and
   rework statuses, and file upload/download in a non-production test setup.

## Legacy risks to avoid carrying forward

- Several legacy queries concatenate request values directly into SQL.
- The browser sends the rebate customer internal code on later requests;
  authorization must be enforced server-side from the authenticated session.
- The JavaScript builds table HTML from database response values without
  consistent escaping.
- The legacy claim workflow can persist some SQL changes before remote file
  transfer or notification succeeds; failure handling and retry/idempotency
  must be designed for multi-step effects.

## Current INPCV2 status

The Rebate Programs page and API are implemented in the current INPCV2 source
tree. The implementation uses the existing INFOAPPS datasource and does not
add a database schema object. The claims Excel download is implemented
separately in `RebateExcel.java`; no new project, repository, or datasource
was introduced.

Java compilation has passed after wiring Rebate/ShipAndDebit/COA onto
`CommonFunctions` (`text` / `sqlDate`) like TSD. The export query, customer
override rules, INFOAPPS permissions and live record-level behavior, SMB
transfer, and SMTP delivery still require verification in the target runtime.
No claim that those external integrations were live-tested is implied by the
successful compilation.

### Resume next session (paused 2026-10-04 ~17:35 IST)

Session closed after claim UX + total fix + docs. Start from this file.

**Done this session**

- Shared `com.mmm.titpl.CommonFunctions` on Rebate / ShipAndDebit / COA (TSD-style
  `import static`); ShipAndDebit AS400 dates stay `yyyyMMdd`.
- Claim modal host `#m_rebate_programs_popup` + `:is(...)` CSS; `_ensureCssInHead`
  replaces stale head CSS; `_scrubOrphanPopups` on Load/OpenClaim.
- Invoice cards: Description beside HSN/SAC; Browse aligned to inputs; smaller
  View/Delete; claim modal **85%**; terms **80%** + teal header.
- Row Upload stays open; existing files → `POST /claim/invoice-details`.
- Read-only **Total Claim Amount**: baked `data-total-incl` + `_claimContent$()`;
  do not refresh from orphan inputs (fixed sticky `INR 1,52,819.00` across claims).
- My Claims: Target + Achievement at end; Final Payout / Target / Achievement via
  `_money` (`INR` + `en-IN`).
- Claims Excel export designed (`RebateExcel` + toolbar) — see section above.
- Eclipse: m2e skips Maven `dodeploy`; Ant builder once after m2e
  ([AutoDeploy-JBoss.md](./AutoDeploy-JBoss.md)).
- Loader: shared `showLoader` / `hideLoader`.

**When reconnecting**

1. Reopen Rebate menu (`rebate_programs.js?v=…`); sync static to
   `target/classes` / EAP `WEB-INF/classes/static` if needed.
2. Smoke: open several different read-only claims → each Total matches that
   claim’s Cust Inv Amt; editable Upload / invoice-details; Export Excel;
   Save for Later / Submit.
3. Optional (only if asked): Save for Later keep-open; live SMB/SMTP;
   `ia_menu_options` if missing.
