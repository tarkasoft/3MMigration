# Framework Tools

UI: `html_files/INPC/frame_work_file.html` (Framework Tools module).

Helpers live in `custom_js/common.js`. Java classes are one class each under `com.mmm.system` (CreateHtmlFiles style).

## Buttons / APIs

| Tool | JS | Endpoint | Java |
|------|-----|----------|------|
| Create HTML | `Common.CreateHtmlFiles()` | `system/createHtmlFiles` | `CreateHtmlFiles` |
| Create Grid | `Common.CreateGridFiles()` | `system/createGridFiles` | `CreateGridFiles` |
| Create Popup | `Common.CreatePopup()` / `CreatePopupFiles()` | `system/createPopupFiles` | `CreatePopupFiles` |
| Sync Module Layout | `Common.SyncModuleLayout()` | `system/syncModuleLayout` | `SyncModuleLayout` |
| Create Meta Columns | (existing) | (existing) | `CreateModuleMetaColumns` |

`$host_url` already ends with `titpl/`, so clients call `$host_url + "system/…"`.

Full HTML/grid generator details: [HTML_CREATION.md](./HTML_CREATION.md).

Module tables and element columns: [CREATE_TABLES_AND_ELEMENTS.md](./CREATE_TABLES_AND_ELEMENTS.md).

---

## Create Popup (`CreatePopupFiles`)

Same module set as Create Grid (`generate_grid = Yes`). Elements included when **`include_in_popup = 1`**.

| Item | Detail |
|------|--------|
| Output | `grid_display_files/INPC/pop_up_{file_name}.js` |
| Template | Same pattern as `pop_up_ia_menu_options.js` (`#table_grid1`, `viewUserSchemaSrefDataDetails`) |
| Dual-write | Project static + exploded WAR paths (same dual-write idea as grids) |

Also: Create Grid element query filters **`include_in_grid = 1`** when that column is used.

---

## Sync Module Layout (`SyncModuleLayout`)

Updates **one module** at a time from a form → SQL preview → Proceed.

### UI flow

1. Form modal `#inpc_sync_layout_form_modal` (file_name, field_position, grid_position, html/grid width, generate_html/grid).
2. **Preview UPDATEs** → dry_run → preview modal with `update_commands`.
3. Preview footer: **Go Back** (return to form) · **Close** · **Proceed — update DB**.

Modals live in [SHARED_MODALS.md](./SHARED_MODALS.md) (`inpc_modal_popup.html`). Loaded once on page ready; `SyncModuleLayout` does not lazy-load them.

### What gets written

| Table | Fields |
|-------|--------|
| `ia_menu_options` | `generate_html`, `generate_grid`, `field_position`, `grid_position`, `html_width`, `grid_width` |
| `ia_s_user_schema_elements` | `sequence`, `field_width`, `field_position`, `list_of_values` (from existing HTML when found) |

### Rules

| Rule | Value |
|------|--------|
| Scope | One `file_name` per run |
| `field_width` | TopBottom → `12`; LeftRight → `3` |
| LOV / order | Parsed from existing `html_files/INPC/{file}.html` when present |
| Preview | `dry_run=1` returns `update_commands` only; Proceed uses `dry_run=0` |

### Call

```js
Common.SyncModuleLayout();                    // empty form
Common.SyncModuleLayout({ file_name: "ia_roles", field_position: "TopBottom" });
```

---

## Generated file header

Create HTML / Grid / Popup each write this marker at the top of every generated file:

- HTML: `<!-- This file is created by Framework System -->`
- JS (grid / popup): `/* This file is created by Framework System */`


---

## FW reference popup (`POPUP.OpenFWPopup`)

```js
POPUP.OpenFWPopup(pop_up_table_name, calling_table_name, system_name, ref_module_display_name);
```

| Arg | Role |
|-----|------|
| 1 | Ref module `file_name` |
| 2 | Calling module `file_name` |
| 3 | Field `system_name` |
| 4 | Title (`display_name`). If null/empty, title = arg 1 |

CreateHtmlFiles passes arg 4 from the referenced module's `display_name`. Modal width uses ~96vw / `modal-xl`.
