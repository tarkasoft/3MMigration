# TSD E-Warranty — system map (files + APIs)

Living reference for INPCV2 TSD. **Update this file in the same pass** whenever you add/change HTML, JS, Java, or an API.

Discovery / phased plan: [TSD_MIGRATION.md](./TSD_MIGRATION.md)  
Warranty DB: [CSD_DATASOURCE.md](./CSD_DATASOURCE.md) (`csd` / `TSD` → `dINTWSYS`)

Last updated: **2026-10-04**

---

## Base JS template (plain jQuery)

**Global standard for all new modules:** [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md)  
**Reference implementation:** `custom_js/TSD/tsd.js`  
Cursor rule: `.cursor/rules/js-module-standard.mdc` (always on for new UI work).

```
Load            → get customer → bind tab clicks
loadContext     → $.ajax GET /context
showTab         → show / hide panels
.load()         → HTML fragment once (per tab)
loadRequests    → $.ajax GET /requests → Common.DataTable
```

**Multi-tab DOM scoping:** portal can open several module tabs with duplicate ids. All TSD HTML (shell, panels, converter/signboard modals, detail modal via requests fragment) lives under `#m_tsd_home`. Read/write via `Tsd._$home()` / `Tsd._$("#id")` and `TsdNewRequest._$` (same pattern as CIR) — never bare `$("#tsd_…").val()` / `document.getElementById("tsd_…")` for module fields.

| Step | Function (TSD) | What it does |
|------|----------------|--------------|
| 1 | `Tsd.Load` | Read portal customer context; bind tabs; call context then default tab |
| 2 | `Tsd.loadContext` | `$.ajax` → `GET /api/customer/tsd/context` with `custCode`, `loginId` |
| 3 | `Tsd.showTab` | Toggle `aria-selected` + `d-none` on panels |
| 4 | `Tsd.openRequestsTab` / `openNewTab` | `$panel.load(...)` **once** |
| 5 | `Tsd.initTable` + `Tsd.loadRequests` | DataTable init + `$.ajax` → `/requests` → `setData` |
| 6 | **Change Converter** | Top-right button on shell → modal → AC / Apply / Clear |

**Where to change converter:** button **Change Converter** next to the converter label on `tsd_home` (visible when role `INPC_TSD_CHANGE_CONVERTER`). Not inside the grid alert text.

Customer resolve (server): Change Converter session → portal Change Customer → direct login.

**Change Converter Apply:** pick is kept in `Tsd._converterPickedCode` + hidden `#tsd_converter_picked_code`; Apply/Clear use `mousedown` `preventDefault` so AC input blur does not swallow the first click.

**Dark + mobile:** shell, tab panels, Change Converter + Signboard Excel modals, My Requests, New Request (incl. edit banner / alerts / locked warranty radios), and detail popup (sections, product tabs, signboard tables, warranty cert card, tender/docs/history) all include `html[data-theme-mode="dark"]` and ≤767px layout (stacked headers, scrollable tabs, full-width actions, horizontal grid/table scroll). Same HTML for phone/desktop.

**New Request validation banner:** `#tsd_nr_message` matches Ship & Debit / Contract Claim style (`alert-warning`: pale yellow `#fff4cc`, text `#7a4e12`, orange left stripe) via CSS in `tsd_new_request.html`; `TsdNewRequest.showMsg` + `scrollToMsg`. Local banner (not `#inpc_page_msg`) so it stays under the edit banner.

**New Request UX (2026-10-03 evening):**
- Warranty type: card-style radios (still `name=tsd_nr_warr_type`).
- Client validation highlights the failing control (`.tsd-nr-err`); clears on change/input; scrolls field into view.
- Product Details: must fill at least one cell before Add row; at 10 rows show `#tsd_nr_signboard_note` (Note to Requester) instead of Swal.
- Actual + PQ exists Yes: Warranty No AC → select loads Approved PQ into form as **new** Actual (`editIntCode` stays 0).
- Buyer textarea id `#tsd_nr_buyer_name` (section remains `#tsd_nr_buyer_details` — do not duplicate ids).

---

## Quick map

| Layer | Path |
|-------|------|
| Menu entry | `ia_menu_options` **1569** · `file_name` = `TSD/tsd_home` · `js_path` = `custom_js/TSD/tsd.js` · icon `ri-file-shield-2-line` |
| Menu group | `ia_menu_groups` **118** Warranty System · icon `ri-shield-check-line` `#0d9488` |
| Shell HTML | `src/main/resources/static/html_files/TSD/tsd_home.html` |
| My Requests HTML | `src/main/resources/static/html_files/TSD/tsd_requests.html` |
| Detail popup HTML | `src/main/resources/static/html_files/TSD/tsd_detail_popup.html` |
| New Request HTML | `src/main/resources/static/html_files/TSD/tsd_new_request.html` |
| Client JS | `custom_js/TSD/tsd.js` (shell) + `custom_js/TSD/tsd_new_request.js` (form) |
| REST controller | `src/main/java/com/mmm/tsd/TsdRequests.java` |
| Context resolve | `src/main/java/com/mmm/tsd/TsdContextResolver.java` |
| SQL helper | `src/main/java/com/mmm/tsd/TsdRequestsSql.java` |
| Warranty PDF | `TsdWarrantyPdf` + `TsdWarrantyPdfBuilder` + `TsdWarrantyPdfSql` |
| API prefix | `/api/customer/tsd` |
| Hibernate factory | `HibernateFactoryRegistry.TSD` (= `CSD` / YAML key `csd`) |

---

## UI files

| File | Role | Loaded by |
|------|------|-----------|
| `html_files/TSD/tsd_home.html` | Module shell: title, converter label, tabs **My Requests** / **New Request** | Portal menu (`file_name`) |
| `html_files/TSD/tsd_requests.html` | My Requests DataTable host (+ detail modal) | `Tsd.openRequestsTab` → `Tsd._$("#tsd_my_requests_panel").load(...)` |
| `html_files/TSD/tsd_detail_popup.html` | Full Request Details modal (legacy layout) | `Tsd.openDetail` → load into `#tsd_detail_modal` |
| `html_files/TSD/tsd_new_request.html` | New Request form (PQ / Actual / PPC + product tabs). Dates: framework picker `dd/mm/yyyy` (Date of Sale, Actual Installation Date) | `Tsd.openNewTab` → `$("#tsd_new_request_panel").load(...)` |
| `custom_js/TSD/tsd.js` | Tabs, context, grid, Change Converter, detail popup, warranty PDF download, signboard Excel | Menu `js_path`; home script calls `Tsd.Load()` |
| `custom_js/TSD/tsd_new_request.js` | Form Load, lookups, type show/hide, product tabs, Draft/Submit, edit reload | `Tsd.ensureNewRequestJs` → `TsdNewRequest.Load()` |

### Tab → fragment

| Tab | Panel id | Fragment |
|-----|----------|----------|
| My Requests (default) | `#tsd_my_requests_panel` | `tsd_requests.html` |
| New Request | `#tsd_new_request_panel` | `tsd_new_request.html` |

### JS → API (who calls what)

| JS function | HTTP | Path | When |
|-------------|------|------|------|
| `Tsd.loadContext` | GET | `/api/customer/tsd/context` | On `Tsd.Load()` |
| `Tsd.loadRequests` | GET | `/api/customer/tsd/requests` | Open My Requests / Refresh |
| `TsdNewRequest.loadLookups` | GET | `/api/customer/tsd/new-request/lookups` | Open New Request (first load) |
| `TsdNewRequest.wireProductAutocomplete` | GET | `/api/customer/tsd/products/autocomplete` | Product name typeahead |
| `TsdNewRequest.wireWarrantyAutocomplete` | GET | `/api/customer/tsd/warranties/autocomplete` | Actual + PQ exists → Warranty No AC; select loads PQ via `GET /requests/{id}` |
| `TsdNewRequest.loadProductDynTables` | GET | `/api/customer/tsd/products/{id}/dyn-table` | Product Details grid after product select |
| `TsdNewRequest.save` | POST | `/api/customer/tsd/requests` | Draft / Submit (multipart header + products + docs) |
| `Tsd.openDetail` | GET | `/api/customer/tsd/requests/{id}` | My Requests → View |
| `Tsd.downloadWarrantyPdf` | GET | `/api/customer/tsd/requests/{id}/products/{productMasterId}/warranty-pdf` | Detail product tab (Approved) |
| Signboard Excel | GET/POST | `/api/customer/tsd/requests/{id}/products/{productRowId}/signboard/excel` | Detail product tab modal |
| Document download | GET | `/api/customer/tsd/requests/{id}/documents/{docRowId}/download` | Detail Documents tab |

Query params from UI: `custCode`, `loginId` via `Common.GetProcedureCustomerContext()` (Change Customer when active; else empty → server uses login).

---

## Java files

| Class | Package path | Responsibility |
|-------|--------------|----------------|
| `TsdRequests` | `com.mmm.tsd.TsdRequests` | `@RestController` — context, list, converter, lookups, product AC, docs/approvers, multipart save |
| `TsdContextResolver` | `com.mmm.tsd.TsdContextResolver` | Three-source working converter resolve |
| `TsdRequestsSql` | `com.mmm.tsd.TsdRequestsSql` | Bound SQL: distributor, requests, states, categories, product AC, matrix/docs LOVs |
| `SaveTsdRequest` | `com.mmm.tsd.SaveTsdRequest` | Draft/Submit one TX (header + products + history + approvers + doc metadata); Submit hooks `TsdMail` after commit |
| `TsdMail` | `com.mmm.tsd.TsdMail` | Submit → first-approver mail (legacy `SendTSDMail` / `SendApprovalMailsToFirstApprover`) + `tsd_mail_history` |
| `CommonFunctions` | `com.mmm.titpl.CommonFunctions` | Shared `text` / `sqlDate` / `longVal` / `intVal` / `capitalize` (static import) |
| `TsdDocUpload` | `com.mmm.tsd.TsdDocUpload` | SMB 3.1.1 store/read/remove + download APIs |
| `TsdWarrantyPdf` | `com.mmm.tsd.TsdWarrantyPdf` | On-demand warranty cert PDF (iText 9 + html2pdf) |
| `TsdWarrantyPdfBuilder` | `com.mmm.tsd.TsdWarrantyPdfBuilder` | Letterhead, tokens, html2pdf layout (generate-time only) |
| `TsdWarrantyPdfSql` | `com.mmm.tsd.TsdWarrantyPdfSql` | Header/product/template/signboard/static/DM SQL |
| `TsdSignboardExcel` | `com.mmm.tsd.TsdSignboardExcel` | POI download/upload into `tsd_new_request_signboard_table` |

**Submit mail (done):** After successful Submit/resubmit, `TsdMail` emails pending-with + approval-matrix recipients (CC = FYI), link = `tsd_url_setup.ew_backend_url`, log = `tsd_mail_history`. Draft does not mail. Approvals stay in the backend app — no approve/reject in the customer portal.

**Still pending:** none for converter portal mail; internal approval mutations remain in the backend app (not this portal).

**Draft/Rework edit (done):** Request Details popup shows **Edit Request** for status Draft|Rework → `Tsd.EditRequestData(id)` confirms, closes modal, opens **New Request** tab, reloads GET `/requests/{id}` into the form (`editIntCode`) for Draft/Submit update.

### Working converter (server — every TSD API)

| Order | Source | How |
|-------|--------|-----|
| 1 | **Change Converter** | Role `INPC_TSD_CHANGE_CONVERTER` + session `tsd_conv_*` |
| 2 | **Change Customer** | Portal override via `resolveProcedureCustomerContext` |
| 3 | **Direct login** | Session `cust_code` |

Candidate must exist in `tsd_distributor.code`. Module override does **not** change portal `fw_override_cust_*`.

---

## API catalog

Base URL: `{app_url}/api/customer/tsd/...`  
Response envelope: `ResponseDataGeneric` JSON (`errorCode` / `message` / `data`). Session expired → `errorCode = -9`.

### 1. Context — working converter

| | |
|--|--|
| **Method / path** | `GET /api/customer/tsd/context` |
| **Java** | `TsdRequests.context` |
| **SQL** | `TsdRequestsSql.distributor` → `tsd_distributor` where `code = ?` |
| **Called from** | `tsd.js` → `Tsd.loadContext` |

**Query params**

| Param | Required | Source | Notes |
|-------|----------|--------|--------|
| `custCode` | No* | Portal procedure customer / Change Customer | Server resolves via `UserSessionSupport.resolveProcedureCustomerContext` |
| `loginId` | No | Same | Optional; session login used if blank |

\*Effective converter code must resolve; blank customer → error.

**Success `data` (keys)**

| Key | Meaning |
|-----|---------|
| `custCode` / `convCode` | Working converter code (`tsd_distributor.code`) |
| `convName` | Distributor name |
| `convDisplay` | `code-name` |
| `loginId` | Resolved login |
| `overridden` | Portal Change Customer override flag |
| `inTsdMaster` | Always `true` on success (row found) |

**Errors (examples):** not logged in; not a customer account; no customer selected; code not in `tsd_distributor`.

---

### 2. My Requests — list grid

| | |
|--|--|
| **Method / path** | `GET /api/customer/tsd/requests` |
| **Java** | `TsdRequests.requests` |
| **SQL** | `TsdRequestsSql.requests` → `tsd_new_request` + `tsd_distributor`, `req_dist = ?`, `order by internal_code desc` |
| **Called from** | `tsd.js` → `Tsd.loadRequests` |

**Query params** — same as context: `custCode`, `loginId` (optional; server-resolved).

**Success `data` (keys)**

| Key | Meaning |
|-----|---------|
| `header_details` | Array of list rows (see below) |
| `convCode` / `convName` / `convDisplay` | Working converter echo |

**Each row in `header_details`**

| Field | UI column |
|-------|-----------|
| `dist_name` | Converter/Applicator (`code-name`) |
| `req_int_code` | Internal key (View button) |
| `req_id` | Request ID |
| `wrty_type` | Warranty Type |
| `wrr_status` | Status |

View opens **full Request Details** (`GET /requests/{id}` + `tsd_detail_popup.html`): products, warranty cert download, signboard Excel, Approver/Documents/History.

---

## Datasource

| Config | Value |
|--------|--------|
| YAML | `insba.datasources.csd` |
| Menu map | `TSD: csd` |
| Java constant | `HibernateFactoryRegistry.TSD` (alias of `CSD`) |
| Database | `dINTWSYS` |

Do **not** add a second YAML pool named `tsd`.

---

## Converter APIs (implemented)

| Method / path | Purpose | Java |
|---------------|---------|------|
| `GET .../converters/autocomplete?value=` | Limited AC (`tsd_distributor` + ASM map for login ENL) | `TsdRequests.converterAutocomplete` |
| `POST .../converter` body `{ "convCode": "…" }` | Set module override | `TsdRequests.setConverter` |
| `POST .../converter/clear` | Clear module override | `TsdRequests.clearConverter` |

## New Request APIs (implemented)

| Method / path | Purpose | Java |
|---------------|---------|------|
| `GET .../new-request/lookups` | Distributor address/flags, `tk_state`, `tsd_product_category` | `TsdRequests.newRequestLookups` |
| `GET .../products/autocomplete?phrase=&categoryId=` | Product name AC for selected type | `TsdRequests.productAutocomplete` |
| `GET .../warranties/autocomplete?phrase=` | Approved PQ Warranty No AC (legacy `GetWarrantyAutoComplete`); scoped to working converter | `TsdRequests.warrantyAutocomplete` |
| `GET .../products/{productId}/dyn-table` | Product Details columns + static master rows (legacy `GetSavedProductMasterDynTableDetails`) | `TsdRequests.productDynTable` |

`lookups` data keys: `distributor`, `states`, `productCategories` (+ working converter map).

### Draft / Submit — create or update

| | |
|--|--|
| **Method / path** | `POST /api/customer/tsd/requests` (`multipart/form-data`) |
| **Java** | `TsdRequests.saveRequest` → `SaveTsdRequest.save` + `TsdDocUpload.store` |
| **Body** | `payload` JSON `{ header, products, approvers }` + files `header~{docIntCode}~{shortCode}` |
| **TX** | One Hibernate TX: ticket → header → products → warranty codes → approvers/`pending_with` → SMB store callback → document rows → history |
| **New header id** | After INSERT, resolve by `req_id` (not `SCOPE_IDENTITY()` — separate JDBC statements lose identity) |
| **Dates** | UI `dd/mm/yyyy` → `CommonFunctions.sqlDate` → SQL `yyyy-MM-dd` or JDBC `NULL` (`date_of_sale`, `actual_date_of_instl`) |
| **Errors** | Always log stack in `TsdRequests.error` / `SaveTsdRequest` rollback |

### Actual Warranty — PQ Warranty No (legacy GetWarrantyAutoComplete)

| | |
|--|--|
| **Show** | Actual type + Does PQ Warranty Exists? = Yes → `#tsd_nr_warranty_no` |
| **AC** | `GET /api/customer/tsd/warranties/autocomplete?phrase=` — Approved PQ for working converter (`value`=req_id, `internal_code`) |
| **Select** | `GET /requests/{internal_code}` → `applyPqReference` fills customer/products; keeps **Actual** type; `editIntCode=0` (new request, not edit of PQ) |
| **JS** | `TsdNewRequest.wireWarrantyAutocomplete` / `loadPqReference` / `applyPqReference` |

### Request Details popup

| | |
|--|--|
| **Method / path** | `GET /api/customer/tsd/requests/{id}` |
| **Java** | `TsdRequests.requestDetail` |
| **UI** | `html_files/TSD/tsd_detail_popup.html` loaded into `#tsd_detail_modal` from My Requests View |
| **Data** | `header`, `products`, `approvers`, `documents`, `history` (scoped to working converter) |
| **Layout** | Matches legacy screenshot: red header line, PQ questionnaire + parties, product tabs, Approver/Documents/History (CIR-style body-active tabs) |
| **Docs download** | `GET /api/customer/tsd/requests/{id}/documents/{docRowId}/download` → `TsdDocUpload.read` |
| **File by path** | `GET /api/customer/tsd/requests/{id}/files/download?path=` → stored SMB path (signboard / legacy file) |
| **Signboard Excel** | `GET/POST .../requests/{id}/products/{productRowId}/signboard/excel` → `TsdSignboardExcel` |
| **Warranty PDF** | `GET .../requests/{id}/products/{productMasterId}/warranty-pdf` → `TsdWarrantyPdf` (`productMasterId` = `tsd_product_master.internal_code`) |
| **File transport** | **Encrypted SMB 3.1.1 only** in `TsdDocUpload` (`store` / `read` / `remove`). Share: `CMW010S('TSD',…,'ATTACHMENT')`. No JCIFS. |

Also: `GET .../new-request/documents`, `GET .../new-request/asm` (approver matrix + ASM refresh).

## Feature status

| Feature | Status |
|---------|--------|
| Shell + tabs + Change Converter | **done** |
| My Requests grid + Request Details popup | **done** |
| New Request (PQ/Actual/PPC) + Draft/Submit + edit Draft/Rework | **done** |
| Actual → Warranty No AC + load Approved PQ | **done** |
| Approvers / documents + SMB | **done** |
| Signboard Excel (detail popup) + product dyn-table rows | **done** |
| Warranty certificate PDF (on-demand) | **done** (accepted layout 2026-10-03) |
| New Request UX (type cards, field highlight, 10-row note) | **done** |
| Submit → approver mail (`TsdMail` / `tsd_mail_history`) | **done** |
| Internal approval mutations | **out of scope** (backend app via `ew_backend_url`) |

---

## Warranty certificate PDF (accepted)

Replaces legacy `TSDGenerateWarrantyPDF` / `TSDPQWarrantyPDF` / `TSDPPCWarrantyPDF` with **one** builder. Shared DB templates (`tsd_template` / `tsd_template_details.pdf_text`) — **never write layout fixes back to DB** (legacy still uses the same rows).

| | |
|--|--|
| **Method / path** | `GET /api/customer/tsd/requests/{id}/products/{productMasterId}/warranty-pdf` |
| **Java** | `TsdWarrantyPdf` → `TsdWarrantyPdfBuilder` + `TsdWarrantyPdfSql` |
| **UI** | Detail popup product tab → Download Warranty Certificate card |
| **Library** | iText 9 + html2pdf |
| **Assets** | `classpath:tsd/images/3m.png`, optional `classpath:tsd/images/signatures/{enl_id}.png` (or `.jpg`) |
| **Gate** | Request status **Approved**; working converter must match |

### Letterhead / margins

| Item | Behavior |
|------|----------|
| `Document.setMargins` | iText order **`(top, right, bottom, left)`** — use `70 / 25 / 33 / 25` (not left/right/top/bottom) |
| Every page (absolute, END_PAGE) | 3M logo + “Confidential” + ticket date (top-right) |
| Body flow | Company address from `tsd_url_setup.mmm_address` at start + after each explicit `ADD_PAGE` / `ADD_BEFORE_PAGE` |
| Watermark | “Transportation Safety Division” (diagonal) |

### Template processing (generate-time only)

1. Load template chunks by product PQ / Actual / PPC template id (`sequence` order).
2. Replace tokens → strip control tokens → `normalizeHtml` → skip blank chunks → `html2pdf`.
3. After a chunk: if `{RETRO_TABLE}` / `{SIGN_BOARD_TABLE}` present, append Java tables (static / signboard rows).
4. **Do not** update `pdf_text` in SQL Server.

### Tokens

| Token | Source |
|-------|--------|
| `{PROD_NAME}`, `{TICKET_NO}`, `{TICKET_DATE}` | Product / header |
| `{CUST_*}`, `{CONV_*}`, `{CONTR_*}`, `{WO_*}`, `{DIST_NAME}` | Header parties (addresses soft-wrapped) |
| `{BUYER_NAME}`, `{DATE_OF_SALE}`, `{W_YEARS}`, `{PPC_Qty}` | Header / product |
| `{DOCUMENT_HEADING_NAME}` | PQ / Actual / PPC heading text |
| `{SIGN_BOARD_TABLE_NAME}` | Product master label |
| `{RETRO_TABLE}`, `{SIGN_BOARD_TABLE}`, `{USAGE_CONFORMANCE_CERTIFICATE}` | Cleared; tables injected in Java when flagged |
| `{DIVISION_MANAGER}` | Request approver role DM / Division* → `ia_user_master.name` |
| `{Div_manager_sign}` | Optional image `tsd/images/signatures/{enl}.png` as data-URI `<img>`; empty if missing |
| `{Actual_installation_date}` | Product `actual_date_of_instl` (`dd/MM/yyyy`) |

Unresolved manager/date tokens are stripped so literals never appear in the PDF.

### Layout rules (accepted as-is)

| Rule | Behavior |
|------|----------|
| `<br>` / `</br>` | Normalized; consecutive breaks collapsed to **one** (keeps DM name / title / division tight like legacy) |
| Section gap | Extra break restored before **USAGE CONFORMANCE CERTIFICATE** only |
| Empty chunks | Skipped after token strip (avoids large gaps from empty `{USAGE_CONFORMANCE_CERTIFICATE}`) |
| Signatory columns | Setup may use `float:left` / `float:right` — **preserved in DB**; at generate time converted to a 2-col table for pdfHTML (left 3M+DM, right `M/S {CONV_NAME}`) |
| Signatory keep-together | Chunks containing AUTHORISED SIGNATORY kept together when possible |
| Tables | Oversized fixed widths forced to `width:100%` so last columns (e.g. Brown) fit A4 |

### Legacy vs INPCV2

| Legacy | INPCV2 |
|--------|--------|
| Three Java PDF classes + XMLWorker | Single `TsdWarrantyPdfBuilder` + html2pdf |
| Same `tsd_template_details` | Same — read-only |
| Margins `document.setMargins(25,25,60,33)` (iText 5 left/right/top/bottom) | Explicit top/right/bottom/left for iText 9 |

---

## Signboard Excel (done)

Flow: My Requests → **View** → product tab → **Upload Signboard Excel** modal (download + upload).

| Piece | INPCV2 |
|-------|--------|
| UI | Modal on shell (`#tsd_signboard_excel_modal` in `tsd_home.html`) |
| Java | `TsdSignboardExcel` (Apache POI) |
| API | `GET/POST .../requests/{id}/products/{productRowId}/signboard/excel` |
| Storage | `tsd_new_request_signboard_table` (`tr_data` `~`-joined) |

New Request form still supports up to **10** inline signboard rows; larger sets use Excel from the detail popup.

---

## Changelog (this doc)

| Date | Change |
|------|--------|
| 2026-10-03 | Initial map: shell, My Requests grid, `context` + `requests` APIs |
| 2026-10-03 | `tsd.js` rewritten as plain jQuery (`Load` → tabs → `$.ajax` / `.load`) |
| 2026-10-03 | Promoted TSD JS flow to **global** [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) + `.cursor/rules/js-module-standard.mdc` |
| 2026-10-03 | Change Converter button + modal on shell; converter AC / Apply / Clear APIs |
| 2026-10-03 | New Request form HTML/JS + lookups + product autocomplete APIs |
| 2026-10-03 | Draft/Submit save (`SaveTsdRequest`) — header + products + history; docs/approvers pending |
| 2026-10-03 | Explored Signboard Excel (My Requests → detail popup); build after Request Details + product column metadata |
| 2026-10-03 | Full Request Details popup (legacy layout) + `GET /requests/{id}` |
| 2026-10-03 | Fix New Request lookups: `isnull(sequence,'')` varchar→numeric on `tsd_product_category` |
| 2026-10-03 | Detail popup: CIR-style body-active tabs; document download via SMB (`GET .../documents/{id}/download`) |
| 2026-10-03 | SMB 3.1.1 file I/O folded into `TsdDocUpload` only (`TsdFileStore` removed) |
| 2026-10-03 | Product tab: Warranty Certificate link, Product Details signboard table, Upload Signboard Excel (POI) |
| 2026-10-03 | New Request approver/document matrix APIs + multipart save via `TsdDocUpload.store` |
| 2026-10-03 | Warranty certificate PDF generate (iText 9.7.1 + html2pdf); assets `classpath:tsd/images/` |
| 2026-10-03 | New Request dates use framework picker (`dd/mm/yyyy`); documented in JS_MODULE_STANDARD |
| 2026-10-03 | Product select → `GET /products/{id}/dyn-table` (legacy GetSavedProductMasterDynTableDetails); Product Details grid + row file + add/delete (max 10); save into `tsd_new_request_signboard_table` |
| 2026-10-03 | Draft/Rework **Edit Request** in detail popup → `Tsd.EditRequestData` opens New Request and reloads GET `/requests/{id}` for save (`editIntCode`) |
| 2026-10-03 | Warranty PDF aligned to legacy TSDPQWarrantyPDF: margins 25/25/60/33, absolute logo + Confidential/date, flow address after each page break, tight html2pdf density (~5 pages) |
| 2026-10-03 | Warranty PDF letterhead fix: `setMargins(top,right,bottom,left)` was called as left/right/top/bottom (top=25, bottom≈150 → overlap + page bloat). Restored top=60 logo band, flow address, A4 table width |
| 2026-10-03 | Change Converter: first Apply after AC pick works (mousedown preventDefault + in-memory picked code) |
| 2026-10-03 | Warranty PDF: collapse leftover `<br>` / empty blocks after token strip (clause gaps); `{DIVISION_MANAGER}` + `{Div_manager_sign}` from request DM approver (+ optional `tsd/images/signatures/{enl}.png`); keep signature block together |
| 2026-10-03 | Warranty PDF signatory: keep setup float L/R (convert to 2-col table for pdfHTML); preserve double `<br>` before next section; stop forcing `float:none` |
| 2026-10-03 | Warranty PDF: single `<br>` between DM name/title lines; `{Actual_installation_date}` from `actual_date_of_instl` (no DB template change) |
| 2026-10-03 | **Accepted current PDF layout** — no further break/DB changes; margins `70/25/33/25` (top/right/bottom/left); generate-time float→table; double break before USAGE only. Full Warranty PDF + Feature status sections; Signboard Excel marked done. Sync [TSD_MIGRATION.md](./TSD_MIGRATION.md) pending → done. |
| 2026-10-03 | Actual Warranty: Warranty No AC (`GET /warranties/autocomplete`) + select prefills from Approved PQ (`GET /requests/{id}`) as new request (not edit). |
| 2026-10-03 | New Request UX: warranty type cards; validation field highlight + clear on change; Product Details require value before Add row; Note to Requester on 10-row limit. |
| 2026-10-03 | Save fixes: header/product id by `req_id`/keys (not `SCOPE_IDENTITY`); `dd/mm/yyyy` → `sqlDate`; buyer field `#tsd_nr_buyer_name`; always log save exceptions. |
| 2026-10-03 | Shared helpers → `com.mmm.titpl.CommonFunctions` (`text`/`sqlDate`/…); TSD classes use `import static`. |
| 2026-10-03 | Submit mail: `TsdMail` (legacy SendTSDMail + SendApprovalMailsToFirstApprover); hooked after `SaveTsdRequest` commit; Draft skips; approvals remain in backend app. |
| 2026-10-03 | Dates: client always `dd/mm/yyyy`; GET detail uses `convert(...,103)` (not `isnull(datetime,'')` → 1900); save via `CommonFunctions.sqlDate` → `yyyy-MM-dd`. |
