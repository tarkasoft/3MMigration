# Know Your Customer (KYC) Migration

## Scope and status

This document compares the INPCV2 KYC screen with the legacy INPC
implementation and records the live `INFOAPPS` integration. The KYC API now
uses parameterized SQL through `NativeQuerySupport`; `dummy=true` remains
available for local sample testing and keeps saves in memory only.

## Source files reviewed

| Area | Current INPCV2 | Legacy INPC |
| --- | --- | --- |
| HTML | `src/main/resources/static/html_files/INPC/know_your_customer.html` | `..\..\inpc\inpc\src\main\webapp\resources\KYC\html\kyc.html` |
| JavaScript | `src/main/resources/static/custom_js/CUST_SERVICE/know_your_customer.js` | `..\..\inpc\inpc\src\main\webapp\resources\KYC\js\kyc.js` |
| Java/API | `src/main/java/com/mmm/customer/KnowYourCustomer.java` | `..\..\inpc\inpc\src\main\java\com\mmm\kyc\KYC.java` |
| Datasource/factory | `src/main/java/com/mmm/config/HibernateFactoryRegistry.java` and `src/main/resources/application.yml` | `..\..\inpc\inpc\src\main\resources\application.properties` and `root-context.xml` |

The legacy source path supplied in the request omitted `src/main/webapp`; the
checked-in HTML and JavaScript are under the paths shown above.

## Current INPCV2 behavior

- The HTML defines the KYC form and ship-to table. The page invokes
  `KnowYourCustomer.Load()` after the module fragment is loaded.
- The JavaScript reads the customer code/login from the portal session helpers,
  then calls `GET /api/customer/know-your-customer`. It submits the form as JSON
  to `POST` on the same endpoint.
- `KnowYourCustomer.get()` requires an authenticated session. Live requests
  read the customer/KYC header from `SO_CustomerMaster` and `Kyc_header`, then
  read `Kyc_group`; if no saved ship-to rows exist, the response is seeded from
  `ShipTo_Master`.
- Live `POST` requests upsert the header and submitted ship-to rows in one
  `INFOAPPS` transaction. All customer and form values are JDBC-bound.
- `dummy=true` uses the existing sample record and stores edits in an
  in-memory map for the current server run. It never writes to `INFOAPPS`.
- The authenticated session's selected customer context is resolved through
  `UserSessionSupport`; a request parameter alone cannot override a
  non-privileged user's customer code.
- The KYC JavaScript sends `Common.GetProcedureCustomerContext()` customer and
  login values on both load and update, matching Customer Payment. For a
  privileged selected-customer override, that selected `custCode` is sent;
  otherwise empty override values make the server use the authenticated
  session's customer and login.
- The response includes legacy KYC status and approval remarks. An `Approved`
  status hides the Update button, and approval remarks are shown in the page.

## Legacy behavior and data mapping

The legacy page makes separate requests to load login/customer details, KYC
header data, and ship-to rows. Its save request posts a `full_obj` form field
containing `kyc_header_obj` and `kyc_group_obj`.

| KYC field | Legacy source / column | Current JSON field |
| --- | --- | --- |
| Customer code | Login `Custcode`; `Kyc_header.cust_code` | `custCode` |
| Proprietor name | `Kyc_header.name_of_proprietor`, fallback `SO_CustomerMaster.CNME` | `proprietorName` |
| Business address | `Kyc_header.business_address`, fallback customer address (`CAD1`–`CAD3`, `CZIP`) | `businessAddress` |
| Billing address | `Kyc_header.billing_address`, same customer-address fallback | `billingAddress` |
| Legacy contact/email/code | `Kyc_header.contact_no` / `email_id` / `code`, with fallbacks from `CPHON` / `CMDATN` / `CMID` | Not represented in the current JSON/form |
| GST / PAN | `Kyc_header.gst_no` / `pan_no` | `gstNo` / `panNo` |
| Primary / alternate contact | `Kyc_header.primary_contact_no` / `alternate_contact_no` | `primaryContact` / `alternateContact` |
| Accounting / transaction email | `Kyc_header.email_id_accounting` / `email_id_transaction` | `emailAccounting` / `emailTransaction` |
| Remarks / drug license | `Kyc_header.remarks` / `drug_license_no` | `remarks` / `drugLicenseNo` |
| Approval state / remarks | `Kyc_header.ui_status` / `approved_remarks` | No current UI field |
| Ship-to code/address | `Kyc_group.shipto_code` / `shipto_address` | `rows[].shipToCode` / `shipToAddress` |
| Ship-to GST/phone/email/PAN | `Kyc_group.gst_no` / `phone_no` / `email_id` / `pan_no` | `rows[].gstNo` / `phoneNo` / `emailId` / `panNo` |
| Ship-to contact/remarks | `Kyc_group.contact_person` / `shipto_remarks` | `rows[].contactPerson` / `remarks` |

The legacy header read left-joins `Kyc_header` to `SO_CustomerMaster`, using the
customer-master values as defaults for a customer with no KYC header yet. The
legacy ship-to read returns existing `Kyc_group` rows when present; otherwise
it seeds the list from `ShipTo_Master` (`TSHIP`, address parts, phone, email,
and contact person). The legacy controller's KYC SQL runs through its
`dataSource_sosr_qa` SQL Server datasource; it is not using the current
INPCV2 AS400 session helper.

The legacy save inserts or updates `Kyc_header`, sets `ui_status` back to
`New`, and updates the timestamp on an existing header. It then inserts or
updates each submitted `Kyc_group` row by customer and ship-to code. It does
not delete persisted ship-to rows omitted from a later submission. After a
successful header write, non-empty ship-to data triggers customer and approver
email notifications. Recipient/configuration data is read from
`kyc_mail_ids`.

Legacy UI details to account for:

- `Approved` status hides the submit button and approval remarks are displayed.
  The current INPCV2 screen does not yet display either value.
- The legacy JavaScript assigns the header's `code` value to the alternate
  contact field when loading it. The database column is
  `alternate_contact_no`; confirm the intended value before preserving this
  apparent mapping defect.
- Legacy client validation requires proprietor, business and billing
  addresses, primary contact, GST, and PAN. INPCV2 currently enforces GST, PAN,
  and primary contact (plus validation of populated ship-to tax/phone values).
  Agree on the authoritative validation rules before switching persistence.

## INFOAPPS factory and environment alignment

`HibernateFactoryRegistry` defines `INFOAPPS = "infoapps"` and exposes
`getInfoappsSessionFactory()`. `NativeQuerySupport` already provides
parameterized native query/update methods that use
`registry.withSession(datasourceName, ...)`, close sessions, and wrap updates
in a transaction. Existing INPCV2 code uses these helpers with
`HibernateFactoryRegistry.INFOAPPS`.

The legacy KYC controller injects `dataSource_sosr_qa`; its datasource
configuration points to the QA SQL Server and the `dINFOPOINT` database. The
current `infoapps` entry in `application.yml` points to a different configured
SQL Server host with the same database name. Before enabling live KYC reads or
writes, verify the active profile/overrides and confirm that the chosen
`INFOAPPS` environment contains the required KYC tables, customer/ship-to
views, and mail configuration. Do not copy the local connection credentials
into code or documentation.

## Implemented migration behavior

1. Live reads use the configured `INFOAPPS` factory and parameterized
   `NativeQuerySupport.executeQuery` calls, following the COA SQL helper pattern.
   A query/database failure returns an error; it does not masquerade as sample
   data.
2. Live saves use the clearly named
   `NativeQuerySupport.executeUpdateInSession(Session, ...)` inside a single
   Hibernate transaction. The existing registry-level helper delegates to
   this session-scoped implementation, preserving its own transaction behavior
   for existing callers.
3. The explicit `dummy=true` path remains available for local testing. The
   frontend passes the existing `window.as400_dummy_data_required` flag on
   reads and saves; dummy saves are not persisted to SQL.
4. Header saves reset `ui_status` to `New`, preserving legacy behavior.
   Submitted ship-to rows are inserted or updated; omitted rows are not
   deleted. Newly added rows can be removed from the page before the overall
   Update is submitted; this does not delete existing saved database rows.
   Populated rows require unique ship-to codes.
5. Customer/approver email notifications from the legacy controller are not
   yet migrated. Before implementing them, verify recipients and delivery
   configuration, and send only after a successful database commit.
6. Confirm the active `INFOAPPS` endpoint/schema and the KYC table constraints
   in each deployment environment. The legacy source used a QA SQL Server
   datasource, while the current `INFOAPPS` entry can target another host.

## Acceptance checks for the later code change

- Verify no-header and existing-header reads against the active INFOAPPS schema.
- Verify customer-master ship-to fallback and saved ship-to precedence.
- Verify insert/update behavior and transaction rollback against a test
  database; no live INFOAPPS integration test has been run here.
- Verify status/approval behavior, email-notification requirements, and legacy
  validation rules with the business owner. Legacy notifications remain out of
  scope for this change.
- Verify `dummy=true` end to end: sample values load and edits remain in memory
  without database writes.
- Run the existing Java compile/test suite after implementation.
