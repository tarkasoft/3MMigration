﻿# Sidebar flyout / Double Menu labels

Theme CSS hides ALL `.side-menu__label` under `.app-sidebar` for Icon Hover and Double Menu.
That also hid names inside the flyout / second pane (only the section title like "Masters" remained).

**Fix:** `css/mainpage-overrides.css` + `inpcFixSubmenuColors()` in `js/MainPage.js` re-show labels inside `.slide-menu` and force dark text (`#1e293b`).
