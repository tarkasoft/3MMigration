# sb_dash_board_4 / Sales Performance tab

- File: `html_files/INPC/sb_dash_board_4.html` (sample ApexCharts data only)
- Wired as Home tab 5 in `html_files/INPC/home_Page.html` (`home_tab_4`, title Sales Performance)
- Light pastel UI; bar colors sky/indigo/teal/pink
