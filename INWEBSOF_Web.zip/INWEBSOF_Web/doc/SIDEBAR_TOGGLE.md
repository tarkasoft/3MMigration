﻿# Vertical sidebar hamburger

Hamburger (`.sidemenu-toggle`) must hide/show the vertical sidebar.

**Bugs fixed**
1. After Get Menus, `MainPage.js` forced `data-toggled="open"` which fought the user.
2. Theme `toggleSidemenu` skips setting `icon-overlay-close` when `localStorage.zynixlayout` is set — intermittent no-op.

**Fix:** capture-phase click handler `inpcBindVerticalSidebarToggle` always toggles the correct closed token for the current vertical / nav style.
