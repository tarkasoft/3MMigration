# Common.DataTable — client and server-side guide

`Common.DataTable` is the portal's shared table component. It builds the header,
filters, page-size selector, entry count, pagination, scrolling, sorting, borders,
alignment, and light/dark-mode styles. It supports two data modes:

- **Client-side (default):** load all rows once and process them in the browser.
- **Server-side (opt-in):** request one filtered/sorted MSSQL page at a time.

Server-side support extends the same component; it is not a copied second table.
Existing tables remain client-side unless they explicitly set `serverSide: true`.

## Source files

- JavaScript: `src/main/resources/static/custom_js/common.js`
- Styles: `src/main/resources/static/css/common_table.css`
- Java MSSQL helper: `src/main/java/com/mmm/titpl/CommonDataTable.java`
- Client-side example: `src/main/resources/static/custom_js/CUST_SERVICE/account_status.js`
- Server-side example: `src/main/resources/static/custom_js/contact_us.js`
- Server controller example: `src/main/java/com/mmm/customer/ContactUs.java`

`Common.DataTable.init()` loads `css/common_table.css` automatically.

## Shared messages and notifications

Use the portal's shared message helpers for module feedback; do not call the
browser's `alert()` directly:

- `ShowErrorMsg(message)` for validation, lookup, and request errors. This
  legacy-compatible helper delegates to `ShowAlertMsg()` when available.
- `ShowSuccessMsg(message)` for successful actions.

Both helpers are provided by `src/main/resources/static/js/common-helpers.js`
and display the portal's SweetAlert dialog. Example:

```javascript
if (!invoiceNo) {
  ShowErrorMsg("Please enter an invoice number.");
  return false;
}

// After the request succeeds:
ShowSuccessMsg("Your request was submitted successfully.");
```

Keep success and error messages tied to the corresponding completed action;
use the module's established inline error display for table or page-load errors
when that is its existing UX.

## Required HTML

The page only needs a root element, table, `<thead>`, and `<tbody>`:

```html
<div id="m_example">
  <div class="dt-table-wrap">
    <table class="dt-table" id="example_table">
      <thead></thead>
      <tbody id="example_tbody"></tbody>
    </table>
  </div>
</div>
```

The generated toolbar and footer are inserted inside the root element.

## Client-side initialization (default)

```javascript
Common.DataTable.init({
  rootId: "m_example",
  tableId: "example_table",
  tbodyId: "example_tbody",
  infoId: "m_example_info",
  pagerId: "m_example_pager",
  searchId: "m_example_search",
  pageSizeId: "m_example_page_size",
  pageSizes: [10, 25, 50, 100],
  pageSize: 10,
  filter_type: "minimal",
  stickyHeader: true,
  fillWidth: false,
  cellBorder: "row",
  maxHeight: "420px",
  emptyMessage: "No records found",
  columns: [
    { title: "Reference", field: "reference", sortable: true, width: 130 },
    { title: "Amount", field: "amount", textAlign: "right", minWidth: 100, maxWidth: 220 }
  ],
  rows: []
});
```

## Initialization options

| Option | Default | Description |
|---|---|---|
| `rootId` | required | Root element ID. A leading `#` is accepted. The instance is stored using this ID. |
| `tableId` | required for rendering | Table element ID. |
| `tbodyId` | required for rows | Table body element ID. |
| `infoId` | `{rootId}_info` | Entry-count element ID. Generated unless `info: false`. |
| `pagerId` | `{rootId}_pager` | Pager element ID. Generated unless `pager: false`. |
| `searchId` | `{rootId}_search` | Global-search input ID in `minimal` mode. Generated unless `search: false`. Ignored in `full` mode. |
| `pageSizeId` | `{rootId}_page_size` | Page-size selector ID. Generated unless `pageSizeControl: false`. |
| `pageSizes` | `[10, 25, 50, 100]` | Positive page-size choices. The selected `pageSize` is added if it is missing. |
| `pageSize` | `10` | Initial rows per page. |
| `filter_type` | `"minimal"` | `"minimal"` for one global search or `"full"` for one filter per searchable column. `filterType` is also accepted. |
| `stickyHeader` | `true` | Keeps headings visible while the table body scrolls. |
| `fillWidth` | `false` | When `true`, stretches the table to fill its container if the configured columns are narrower. Wider tables still scroll horizontally. |
| `cellBorder` | `"row"` | `"row"` for horizontal row separators or `"full"` for borders around every header/body cell. |
| `maxHeight` | `"min(60vh, 560px)"` | Scroll-panel height. Accepts a number, `px`, `vh`, `min(vh, px)`, or `max(vh, px)`. Minimum resolved height is 120px. |
| `emptyMessage` | `"No data found"` | Message rendered when no rows match. |
| `columns` | `[]` | Column definitions in display order. |
| `rows` | `[]` | Initial client-side row objects. |
| `serverSide` | `false` | Opt-in server paging/filtering/sorting. Existing client-side tables remain unchanged. |
| `loadData` | none | Function receiving a request object and returning a promise for `{ rows, totalRecords, page, pageSize }`. Required in server mode. |
| `searchDelay` | `300` | Server-mode filter debounce in milliseconds. |
| `sortField` | empty | Initial server/client sort field. |
| `sortDir` | `"asc"` | Initial sort direction: `"asc"` or `"desc"`. |
| `searchPlaceholder` | `"Search…"` | Placeholder for the global search in `minimal` mode. |
| `chrome` | `true` | Set `false` to prevent automatic toolbar/footer creation. |
| `search` | `true` | Set `false` to prevent global-search generation in `minimal` mode. |
| `pageSizeControl` | `true` | Set `false` to prevent page-size selector generation. |
| `info` | `true` | Set `false` to prevent entry-count generation. |
| `pager` | `true` | Set `false` to prevent pager generation. |

## Column options

```javascript
{
  title: "Invoice Amount",
  field: "invoiceAmount",
  sortable: true,
  searchable: true,
  type: "text",
  "text-align": "right",
  width: 150,
  minWidth: 90,
  maxWidth: 300
}
```

| Option | Default | Description |
|---|---|---|
| `title` | `field` | Header text and full-filter accessibility label. |
| `field` | empty | Property read from each row object. |
| `sortable` | `true` | Set `false` to disable sorting for this column. |
| `searchable` | `true` | Set `false` to exclude the column from searches and omit its full-mode filter input. |
| `type` | `"text"` | `"text"` escapes output, `"email"` creates a `mailto:` link, and `"html"` renders the value as HTML. |
| `text-align` | `"left"` | `"left"`, `"center"`, or `"right"`. `textAlign` and `align` are accepted aliases. |
| `width` | based on heading | Initial width in pixels. Accepts a positive number, numeric string, or `px` value. |
| `minWidth` | `70` | Smallest width allowed when initially sized or mouse-resized. |
| `maxWidth` | `600` | Largest width allowed when initially sized or mouse-resized. |

Only use `type: "html"` with trusted/generated markup because its value is intentionally not escaped.

## Column widths and mouse resizing

- If `width` is empty or omitted, the initial width is calculated from `title` (or `field` when there is no title).
- Automatic heading-based width is constrained to 90–220px.
- Every table using `Common.DataTable` receives this behavior automatically; module files do not need duplicate width settings.
- Set `fillWidth: true` when a table should retain the old full-container appearance. All current portal modules set this explicitly.
- Set `width` on a column only when its automatic width needs adjustment.
- Contact Us sets manual widths for every column, including 190px for both email columns.
- Move the mouse to the right edge of a column heading. The cursor changes to the column-resize cursor.
- Drag left to decrease the width or right to increase it.
- Dragging is limited by that column's `minWidth` and `maxWidth`.
- Resized widths remain active while filtering, sorting, paging, and replacing rows for that initialized table instance.
- Long cell content is shown with an ellipsis when it does not fit; drag the heading edge to reveal more.

## Filter modes

### Minimal

```javascript
filter_type: "minimal"
```

- This is the default.
- One search box checks every column where `searchable !== false`.
- Matching is case-insensitive and uses contains/substring matching.

### Full

```javascript
filter_type: "full"
```

- Adds one input below every searchable column heading.
- The global search box is not created.
- Matching is case-insensitive and uses contains/substring matching.
- Multiple populated column filters use AND logic: a row must match every populated filter.
- Filter values remain active during sorting, paging, and data refresh.
- Contact Us uses full filtering with its opt-in MSSQL server-side mode.

Show or hide the active filter UI:

```javascript
Common.DataTable.toggleFilters("m_example");
```

In `full` mode this toggles the column-filter row. In `minimal` mode it toggles the toolbar.

## Border modes

Horizontal row separators only:

```javascript
cellBorder: "row"
```

Full horizontal and vertical grid:

```javascript
cellBorder: "full"
```

The corresponding table classes are `dt-border-row` and `dt-border-full`. In full mode, the scroll wrapper supplies the outside perimeter and cells supply the internal grid, avoiding doubled outside borders. Account Status uses `cellBorder: "full"`.

## Loading or replacing rows

Initialize once, then provide AJAX results:

```javascript
Common.DataTable.setData("m_example", [
  { reference: "PAY-100", amount: "1,250.00" },
  { reference: "PAY-200", amount: "3,500.00" }
]);
```

`setData()` replaces the current rows, returns to page 1, reapplies active filtering/sorting, and refreshes the scroll panel.

### Complete client-side flow

```javascript
function loadExample() {
  Common.DataTable.init({
    rootId: "m_example",
    tableId: "example_table",
    tbodyId: "example_tbody",
    infoId: "m_example_info",
    pagerId: "m_example_pager",
    searchId: "m_example_search",
    pageSizeId: "m_example_page_size",
    pageSize: 10,
    filter_type: "minimal",
    columns: [
      { title: "Reference", field: "reference" },
      { title: "Amount", field: "amount", "text-align": "right" }
    ],
    rows: []
  });

  $.ajax({
    url: "api/example/list",
    dataType: "json"
  }).done(function (json) {
    Common.DataTable.setData("m_example", json.data.rows);
  });
}
```

Client-side behavior:

- The API is called once for a load or explicit refresh.
- `setData()` stores the complete result in the browser.
- Search, column filters, sorting, page-size changes, and pagination do not call the server.
- Use this mode for small or moderate result sets.
- `serverSide`, `loadData`, and the Java `CommonDataTable` helper are not required.

## MSSQL server-side mode

Server mode is opt-in. Tables without `serverSide: true` keep the original behavior:
load all rows once, then filter, sort, and page in the browser.

```javascript
Common.DataTable.init({
  rootId: "m_example",
  tableId: "example_table",
  tbodyId: "example_tbody",
  serverSide: true,
  searchDelay: 300,
  sortField: "reference",
  sortDir: "asc",
  loadData: function (request) {
    return $.ajax({
      url: "api/example/list",
      data: {
        page: request.page,
        pageSize: request.pageSize,
        sortField: request.sortField,
        sortDir: request.sortDir,
        globalFilter: request.globalFilter,
        columnFilters: JSON.stringify(request.columnFilters)
      }
    }).then(function (json) {
      return json.data;
    });
  },
  columns: [
    { title: "Reference", field: "reference" }
  ]
});

Common.DataTable.reload("m_example", true);
```

The `loadData` promise must resolve to:

```json
{
  "rows": [],
  "totalRecords": 250,
  "page": 1,
  "pageSize": 10
}
```

`loadData(request)` receives:

```json
{
  "page": 1,
  "pageSize": 10,
  "sortField": "reference",
  "sortDir": "asc",
  "globalFilter": "",
  "columnFilters": {
    "reference": "PAY"
  }
}
```

`loadData` must return a jQuery promise or jqXHR-compatible promise. A module can
transform its wrapped `ResponseDataGeneric` payload with `xhr.then(...)`. When the
derived promise should remain cancellable, expose the original request's abort:

```javascript
var xhr = $.ajax({ url: "api/example/list", data: requestData });
var promise = xhr.then(function (json) {
  return json.data;
});
promise.abort = function () {
  xhr.abort();
};
return promise;
```

This allows the shared component to cancel an obsolete request when the user
types another filter before the first response arrives.

In server mode:

- Search input is debounced.
- An active request is aborted when a newer request starts.
- Paging, page-size changes, sorting, and filters request a new server page.
- The browser renders the returned page without applying client-side filtering or sorting again.
- `Common.DataTable.reload(rootId, true)` reloads from page 1.
- `Common.DataTable.reload(rootId, false)` reloads the current page.

The MSSQL helper is `com.mmm.titpl.CommonDataTable`. A controller defines a
server-owned base query and an allowlisted mapping between browser fields and SQL
result aliases. The helper uses prepared parameters for filter values and
`ORDER BY ... OFFSET ? ROWS FETCH NEXT ? ROWS ONLY` for paging. SQL is never sent
by or accepted from the browser.

### Java controller and query definition

Each controller owns its SQL and allowed fields. The browser never sends SQL:

```java
private static final CommonDataTable.QuerySpec EXAMPLE_TABLE =
        CommonDataTable.QuerySpec.builder("""
                select
                    e.reference as reference,
                    e.amount as amount
                from example_data e
                """)
                .column("reference", "reference")
                .column("amount", "amount")
                .defaultSort("reference")
                .build();

CommonDataTable.Request tableRequest = new CommonDataTable.Request(
        page,
        pageSize,
        sortField,
        sortDir,
        globalFilter,
        CommonDataTable.parseColumnFilters(columnFiltersJson));

CommonDataTable.Page tablePage =
        CommonDataTable.query(systemSession(), EXAMPLE_TABLE, tableRequest);

result.SetSuccess("success", tablePage.toMap());
```

The query helper:

- Runs under the controller's existing Hibernate session and transaction.
- Executes a parameterized `COUNT_BIG(1)` query.
- Executes one MSSQL page with `OFFSET ? ROWS FETCH NEXT ? ROWS ONLY`.
- Binds global-filter, column-filter, offset, and page-size values.
- Allows sorting only through Java-defined field-to-result-alias mappings.
- Limits page size to 200 and filter text to 500 characters.
- Escapes MSSQL `LIKE` wildcard characters.
- Supports optional fixed base-query parameters through
  `QuerySpec.Builder.parameter(...)` or `.parameters(...)`.
- Provides `parseColumnFilters(String)` so every controller uses the same JSON
  object-to-map conversion.
- `QuerySpec.toString()` prints the base SQL, default sort, parameter count, and
  allowed columns. `ContactUs` prints `CONTACT_TABLE` once when Spring creates
  the controller.

The base SQL must expose stable aliases matching the registered result aliases.
Do not include an `ORDER BY` in the base SQL; the helper adds the allowlisted
order required by MSSQL pagination.

### Generated page SQL

For every request the helper builds one page query:

```sql
select grid_data.*
from (
    -- module base SQL
) grid_data
where ...
order by grid_data.[allowed_column] asc
offset 0 rows fetch next 10 rows only
```

`OFFSET ... ROWS FETCH NEXT ... ROWS ONLY` returns one page after the
`ORDER BY` has sorted the filtered rows:

- `OFFSET 0 ROWS` skips nothing, so page 1 starts at the first row.
- `FETCH NEXT 10 ROWS ONLY` returns the next 10 rows.
- Page 2 with page size 10 is `OFFSET 10 ROWS FETCH NEXT 10 ROWS ONLY`.

The formula is:

```text
offset = (page - 1) * pageSize
fetch  = pageSize
```

The executed statement uses `?` parameters. The server console prints a copy
with those values inlined so the query can be inspected or rerun manually:

```text
pageSql:
... order by grid_data.[div_no] asc
offset 0 rows fetch next 10 rows only
```

Filter values are printed as `N'...'`. Offset and page size are printed as numbers.
This print is for debugging; it is not the statement sent to SQL Server.

### ResponseDataGeneric integration

The normal API response remains wrapped:

```json
{
  "errorCode": 0,
  "status": "success",
  "message": "success",
  "data": {
    "rows": [],
    "totalRecords": 250,
    "totalPages": 25,
    "page": 1,
    "pageSize": 10
  }
}
```

The module's `loadData` function validates session/business errors and resolves
only the inner `data` page object for `Common.DataTable`.

### Server-side security rules

1. SQL must be defined in trusted Java code.
2. Never accept a SQL query, SQL column expression, or `ORDER BY` text from the browser.
3. Register every searchable/sortable browser field in `QuerySpec`.
4. Use base-query parameters for tenant, customer, permission, or other fixed values.
5. Perform session and authorization checks in the controller before calling the helper.
6. Keep module-specific transformations and permissions outside the generic helper.

## Public JavaScript API by mode

- `Common.DataTable.init(options)` — initializes either mode.
- `Common.DataTable.setData(rootId, rows)` — supplies the complete dataset in client mode.
- `Common.DataTable.reload(rootId, true)` — reloads a server table from page 1.
- `Common.DataTable.reload(rootId, false)` — reloads the current server page.
- `Common.DataTable.toggleFilters(rootId)` — toggles minimal or full filter UI in either mode.

Do not call `setData()` for normal server-side responses. Resolve the page object
from `loadData()` instead. Calling `reload()` on a client-side table intentionally
does nothing.

## Sorting and pagination

- Clicking a sortable heading switches between ascending and descending order.
- Numeric-looking values are compared numerically; other values are compared case-insensitively as text.
- Sorting returns to page 1.
- Previous and Next buttons are always generated when the pager is enabled.
- Up to eight numbered page buttons are currently displayed.

## Styling and responsive behavior

- Shared styles support light and dark themes.
- Wide tables scroll horizontally.
- The body scrolls vertically inside `maxHeight`.
- Headers and full-mode filter inputs remain sticky.
- Mobile styles reduce spacing and allow horizontal table scrolling.
- Right-aligned columns use tabular numerals.

Main CSS classes:

- `.dt-toolbar`, `.dt-pagesize`, `.dt-search`
- `.dt-table-wrap`, `.dt-sticky-wrap`, `.dt-table`
- `.dt-border-row`, `.dt-border-full`
- `.dt-column-filters`, `.dt-column-filter`
- `.dt-align-left`, `.dt-align-center`, `.dt-align-right`
- `.dt-foot`, `.dt-pager`

## Usage rules

1. Use a unique `rootId`, `tableId`, and `tbodyId` for every table.
2. Initialize a table after its HTML has been inserted into the page.
3. In client mode, keep AJAX calls in the module JavaScript and pass rows to `setData()`.
4. In server mode, return the documented page object from `loadData()`.
5. Do not build a second custom search, pager, or table header when shared DataTable functionality is sufficient.
6. Use `searchable: false` for action columns that should not have filters.
7. Use `cellBorder: "full"` when vertical column separators are required.
