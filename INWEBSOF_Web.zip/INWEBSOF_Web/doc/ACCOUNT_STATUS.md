﻿# Account Status (CUST_SERVICE)

Follow [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md). Reference implementation: `account_status.js`.

## Paths

- HTML: `html_files/CUST_SERVICE/account_status.html`
- JS: `custom_js/CUST_SERVICE/account_status.js`
- Java: one class per tab in `com.mmm.customer.account_status`
- Menu `file_name`: `CUST_SERVICE/account_status` (internal_code 543)
- Menu `js_path`: `custom_js/CUST_SERVICE/account_status.js`

The page script calls `AccountStatus.LoadAccountStatus()`. MainPage does not.

## Tabs

Account Summary loads when the page opens. Each other tab loads the first time it is clicked. Coming back does not call again. **Refresh** on that tab loads again. Paid Invoices and Payment History also reload from **Get Paid Invoices** / **Get Payment History**.

Loaded flags live on `#m_account_status` via jQuery `.data()`: `summaryLoaded`, `payments_dueLoaded`, `paid_invoicesLoaded`, `unappliedLoaded`, `payment_historyLoaded`, `instrument_returnLoaded`, `statementLoaded`. Console: `$("#m_account_status").data()`.

Customer line is `Common.GetCustCode()` and `Common.GetCustName()`.

## Dates

Paid Invoices and Payment History use the framework picker (`dd/mm/yyyy`). From Date defaults to the 1st of the month. To Date defaults to today. The request sends `yyyymmdd` through `DateFormatYYYYMMDD()`.

## APIs

All are GET. `loginId` is optional. Sample data for now; each class keeps an AS400 session for the later procedure.

- `/api/customer/account-status/summary`
- `/api/customer/account-status/payments-due`
- `/api/customer/account-status/paid-invoices?fromDate=&toDate=`
- `/api/customer/account-status/unapplied`
- `/api/customer/account-status/payment-history?fromDate=&toDate=`
- `/api/customer/account-status/instrument-return`
- `/api/customer/account-status/statement`

Grids use `Common.DataTable`. Account Summary is cards, not a grid.

Restart the server after Java changes.
