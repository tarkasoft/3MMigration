# sb_dash_board_5 / 6

Cloned from `sb_dash_board_4.html` with distinct themes:

| File | Theme | Home tab |
|------|--------|----------|
| `sb_dash_board_5.html` | Warm amber / peach | **6 Sales Pulse** |
| `sb_dash_board_6.html` | Cool emerald / mint | **7 Channel Sales** |

Wired on custom home shells: `home_customer.html`, `home_distributor.html`, `home_Page.html`.
