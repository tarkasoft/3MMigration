# TSD E-Warranty Migration

## Purpose and scope

This document records legacy **TSD E-Warranty** discovery and defines a
migration plan for INPCV2. It is a discovery / planning document — not proof
that the business workflow has already been migrated.

Legacy UI path (workspace checkout):

`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\webapp\resources\TSD\`

Legacy Java package:

`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\java\com\mmm\tsd\`

The user path `npc/resources/TSD/html/tsd_new_req_warranty.html` maps to that
`inpc/.../resources/TSD/` tree. A parallel copy may exist under `inpc_new`.

**Out of scope for this track:** the separate **Ewarranty** converter graphic
film module under `resources/Ewarranty/` (`com.mmm.ewarranty`, routes such as
`#/Ewarranty`). Treat that as a different migration unless product owners
explicitly merge the two.

## Current INPCV2 position

As of 3 Oct 2026:

- **Warranty DB wired:** `insba.datasources.csd` → `PRODSQL445A\SQL445A` /
  **`dINTWSYS`** (legacy `hibernate_tws.cfg.xml`). Shared by **CSD** smoke
  (`com.mmm.csd`) and **TSD** (`com.mmm.tsd`). See [CSD_DATASOURCE.md](./CSD_DATASOURCE.md).
- Registry: `HibernateFactoryRegistry.CSD` and alias **`TSD`** (same pool).
  Menu map: `CSD: csd`, `TSD: csd`.
- **Customer portal module largely complete** (shell, My Requests, New Request
  Draft/Submit + edit, Warranty No AC / PQ prefill, Signboard Excel, warranty
  PDF, dark/mobile + field validation UX). Living map:
  **[TSD_SYSTEM.md](./TSD_SYSTEM.md)**. Submit mail done (`TsdMail`); approvals stay in backend app.
- Portal menu: `file_name=TSD/tsd_home`, `js_path=custom_js/TSD/tsd.js`
  (Load Type Internal); menu option **1569**.

## Status — done vs pending

### Done

| Item | Location / notes |
|------|------------------|
| Warranty datasource `csd` → `dINTWSYS` | `application.yml`; shared CSD/TSD |
| `HibernateFactoryRegistry.TSD` alias | Same pool as `CSD` |
| Menu map `TSD: csd` | `insba.menu-datasources` |
| Module shell + tabs + dark/mobile | `html_files/TSD/tsd_home.html` — **My Requests** + **New Request** |
| My Requests list + Request Details popup | `tsd_requests.html` + `tsd_detail_popup.html` + `GET /requests/{id}` |
| Change Converter | Role `INPC_TSD_CHANGE_CONVERTER` + modal + limited AC + three-source resolve |
| New Request (PQ / Actual / PPC) | Form + lookups + product AC + dyn-table Product Details |
| Draft/Submit + edit Draft/Rework | `SaveTsdRequest` multipart + detail **Edit Request**; id via `req_id` lookup; dates via `CommonFunctions.sqlDate` |
| Actual Warranty No AC + PQ prefill | `GET /warranties/autocomplete` + load `GET /requests/{id}` as new Actual |
| Approvers / documents + SMB | Matrix APIs + `TsdDocUpload` (SMB 3.1.1 only) |
| Signboard Excel | Detail product tab → `TsdSignboardExcel` (POI `.xlsx`) |
| Warranty certificate PDF | `TsdWarrantyPdf` + builder/sql; **layout accepted 2026-10-03** (no DB template writes) |
| New Request UX polish | Type cards, field error highlight, 10-row Note to Requester |
| Shared Java helpers | `com.mmm.titpl.CommonFunctions` |
| Submit → approver mail | `TsdMail` after `SaveTsdRequest` commit; `tsd_mail_history`; link `ew_backend_url` |
| Client JS | `custom_js/TSD/tsd.js` + `tsd_new_request.js` |

### Pending / out of scope (portal)

| Priority | Item |
|----------|------|
| Approvals | Approve/reject stay in **backend app** (`ew_backend_url`) — not customer portal |

### MSSQL implementation pattern = CIR

TSD is SQL Server (`dINTWSYS`), same coding stack as CIR (`dINECIR`). **Port
Java the way CIR was done** — copy structure from `com.mmm.cir`, not legacy
`HybernetUtil` / string-concat SQL. Details also in
[CIR_MIGRATION.md](./CIR_MIGRATION.md) and
[Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md).

| Concern | CIR (reuse pattern) | TSD / CSD warranty |
|---------|---------------------|---------------------|
| Datasource | `application.yml` → `cir`; `HibernateFactoryRegistry.CIR` | **`csd`** pool → `dINTWSYS`; use `HibernateFactoryRegistry.TSD` (alias of `CSD`) |
| Package | Flat `com.mmm.cir` | Flat `com.mmm.tsd` (CSD smoke stays `com.mmm.csd`) |
| Controller | `@RestController` `/api/customer/cir` | `/api/customer/tsd` |
| SQL | `CirRequestsSql` + `NativeQuerySupport` bound `?` | `Tsd*Sql` same helpers, factory key **`TSD`** |
| Context | `UserSessionSupport` / procedure customer | Same + TSD three-source converter resolve |
| List UI | `Common.DataTable` | My Requests same |
| Save TX | `SaveCir` + coding standard | `SaveTsdRequest` + coding standard |
| Files | `CirFileStore` SMB 3.1.1 | `TsdDocUpload` SMB 3.1.1 (CMW010S TSD share) |
| Response | `ResponseDataGeneric` + Gson | Same |
| Timestamps | `UserSessionSupport.sessionDate()` | Same |

Do **not** add a second YAML datasource named `tsd`. Do **not** invent a
second MSSQL access style for TSD.

## Legacy asset inventory

### HTML (`resources/TSD/html/`)

| File | Role |
|------|------|
| `tsd_warranty.html` | Module shell: CSR converter override, tabs, JS bootstrap |
| `tsd_warranty_requests.html` | Warranty request list fragment |
| `tsd_new_req_warranty.html` | New / edit request form (large) |
| `tsd_warr_approval_popup.html` | Read-only detail / approval / history modal |
| `tsd_signboard_excel_upload_popup.html` | Signboard Excel upload popup |
| `tsd_customer.html` | Add-customer modal fragment |

### JavaScript (`resources/TSD/js/`)

| File | Role |
|------|------|
| `tsd_new_req_warranty.js` | `TsdReqWarranty` — onload, validation, Draft/Submit save, docs |
| `tsd_warr_req_popup.js` | `TSDReqPopup` — list popup, history, PDF / Excel entry |
| `tsd_common.js` | `TSDCommon` — session, LOV, autocompletes |
| `tsd_product_master.js` | `TSDPM` — dynamic signboard / static product tables |
| `bootbox/bootbox.min.js` | Local Bootbox (do not port; use portal libs) |

### CSS / images

Module CSS under `resources/TSD/css/`, images under `resources/TSD/images/`,
and a vendored Bootstrap 3 tree under `resources/TSD/bootstrap/`. **Do not**
copy Bootstrap 3 into INPCV2; use MainPage Bootstrap 5 + Remix icons.

### Java (`com.mmm.tsd`)

| Class | Role |
|-------|------|
| `TSDReqWarranty` | List, onload, document/approver LOV, save, new customer |
| `TSDCommon` | Login distributor context, autocompletes, history helpers |
| `TSDReqPopup` | Popup read model (header, products, docs, matrix, history) |
| `TSDFtpFileUpload` | Attachment upload/download (legacy JCIFS + CMW010S) |
| `TSDProductMaster` | Product dynamic table load/save helpers |
| `TSDSignboardExcelUpload` | Signboard Excel template + upload |
| `TSDGenerateWarrantyPDF`, `TSDPQWarrantyPDF`, `TSDPPCWarrantyPDF` | Certificate PDFs |
| `SendTSDMail` | Notification mail + `tsd_mail_history` |
| `HybernetUtil`, `JDBCAccessor` | Legacy session / JDBC helpers (do not port as-is) |

## Page flow

```
Portal menu / legacy #/TSD
  → tsd_warranty.html (shell)
       → GetDistLoggedInDetails (distributor / warranty flags)
       → Tab: Warranty Requests → tsd_warranty_requests.html
            → GetWarrantyRequestsByTSD → DataTable
            → row → TSDReqPopup / GetApprovalDetailsForPopup
                 → PDF / signboard Excel / Edit (Draft|Rework)
       → Tab: Request New Warranty → tsd_new_req_warranty.html
            → getOnloadData, GetDocumentList
            → SaveTSDNewRequest (Draft | Submit) multipart
```

Shell bootstrap (legacy): load `tsd_new_req_warranty.js`, then
`TsdReqWarranty.GetDistLoggedInDetails` → open **Warranty Requests** tab.
`CallProperModuleOnClick` clears and `.load()`s the list or new-request HTML.

## My Requests — list grid + detail popup

Legacy tab label **Warranty Requests** (INPCV2: treat as **My Requests**).
Screenshots (2026-10-03):

| UI | File |
|----|------|
| List grid | [tsd_my_requests_grid.png](./assets/tsd/tsd_my_requests_grid.png) |
| Request Details popup | [tsd_request_details_popup.png](./assets/tsd/tsd_request_details_popup.png) |

### List (`tsd_warranty_requests.html` / `#TSDWarrReqDataTable`)

- Load: `POST TSDReqWarranty/GetWarrantyRequestsByTSD` with working converter
  (`convIntCode` = resolved DistCode / cust_code).
- SQL: `tsd_new_request` joined to `tsd_distributor` on `req_dist = dist.code`,
  filtered `req_dist = ?`, order by `internal_code desc`.
- Columns:

| Column | Field |
|--------|--------|
| View | Radio → opens detail popup (`TSDReqPopup.ViewRequestData`) |
| Converter/Applicator | `code-name` (e.g. `18878-RKS Industries`) |
| Request ID | `req_id` (e.g. `261002055`) |
| Warranty Type | PQ Warranty / Actual Warranty / PPC… |
| Status | Draft, Pending with ASM/RSM, Approved, Rework, … |

- Legacy DataTable page length 50 + search. INPCV2: `Common.DataTable.init` /
  `setData` (CIR pattern). List always scoped to the **resolved working
  converter** (three-source context).

### Request Details popup (`tsd_warr_approval_popup.html`)

Opened from the View radio → `POST TSDReqPopup/GetApprovalDetailsForPopup`.
Read-only for most statuses; Draft/Rework may offer Edit.

**Header:** Request No, Warranty Type, Status (e.g. Pending with RSM).

**Left — questionnaire answers** (Converter/Applicator, agreement, sister
concern, SOP/MCS, Remarks, …).

**Right — parties**

- Converter (code-name, address, phone, email)
- Customer (name, address)
- Contractor (name, address)

**Middle — Product and Tender Details** (Product 1…N tabs): product type/name,
work order, warranty years, project, remarks, tender/ref.

**Bottom tabs**

| Tab | Content |
|-----|---------|
| Approver Details | Sl No, Role, Approver, Status, Remarks, Date |
| Documents | Uploaded files (download) |
| History | Status history |

INPCV2: one detail modal on the TSD shell; load fragment or render from JSON.
Do not put **Change Converter** inside this popup — converter change stays on
the module shell (role `INPC_TSD_CHANGE_CONVERTER`); the popup only **displays**
the request’s converter.

### Signboard Excel upload (>10 lines) — from My Requests

On **New Request**, the signboard grid allows at most **10 rows** inline.
If more lines are needed:

1. User **submits/saves** the request first (Draft or Submit).
2. Opens **My Requests** → View → Request Details popup.
3. Under **Product Information** (product tab), uses **Excel upload**
   (`OpenPopupforSignboardExcelUpload` → `#tsd_warr_details_signboard_pop_up`
   / `tsd_signboard_excel_upload_popup.html`).

Legacy copy on the new-request form:

- If signboard details exceed **10 lines**, submit the request, open the
  Warranty Requests popup, and upload the Excel under Product Information.
- Upload signboard **document files on the new-request form only**.
- Excel upload is **data only** — no document files through that screen.

| Action | Legacy API |
|--------|------------|
| Download template / existing rows | `GET TSDSignboardExcelUpload/DownloadSignboardExcelFormat?product_int_code=&header_int_code=` → `.xls` |
| Upload filled Excel | `POST TSDSignboardExcelUpload/UploadTSDSignboardExcelIntoDB` (multipart) |

- Target table: `tsd_new_request_signboard_table` (delete/replace rows for that
  product + request header, then insert `tr_data` / sequence).
- Client alert when adding past 10 rows on the form:
  *“You can upload only 10 records at a time. Please upload the Excel file
  under My Request tab.”* (`tsd_product_master.js`).

**INPCV2 (done):** `GET/POST /api/customer/tsd/requests/{id}/products/{productRowId}/signboard/excel`
via `TsdSignboardExcel` (Apache POI `.xlsx`, not jxl). One TX on upload
(delete then insert). 10-line form limit kept; Excel from Request Details
product tab (`#tsd_signboard_excel_modal`). Documents stay on the main form /
SMB path, not in Excel.
Details: [TSD_SYSTEM.md — Signboard Excel](./TSD_SYSTEM.md#signboard-excel-done).

## Converter context — three sources (INPCV2 design)

TSD always needs one **working converter code** plus warranty flags from
`tsd_distributor`.

### Identity: converter = portal customer code

For reference: the converter/applicator code is the same business key as
**`ia_user_master.cust_code`** (session / Change Customer / `Common.GetCustCode`).
Legacy login passes `Custcode` into TSD as `DistCode`; `tsd_distributor.code`
is that same code (e.g. `18878`). So:

| Layer | Column / field |
|-------|----------------|
| Portal user | `ia_user_master.cust_code` |
| TSD master | `tsd_distributor.code` (must exist for warranty flags) |
| TSD working context | that code (historically `$g_tsd_dist_code` / `req_dist`) |

Autocomplete for Change Converter can therefore search codes that exist in
**both** places, but **warranty setup** still requires a row in
`tsd_distributor` (PQ/Actual/PPC flags, address). A portal customer with no
`tsd_distributor` row is not a usable TSD converter.

INPCV2 will support **three** ways that code is chosen. They are separate
stores; only TSD APIs resolve them in a fixed order.

### A. The three sources

| # | Source | When | Scope | Store |
|---|--------|------|-------|--------|
| 1 | **Direct login** | User’s own `cust_code` is a TSD converter | Default | Session `cust_code` / home cookies `fw_cust_*` |
| 2 | **Global Change Customer** | User has `see_other_cust_data=Yes` and applied portal override | Whole portal (CIR, Account Status, …) | `fw_override_cust_*` + `fw_customer_overridden` — unchanged ([CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md)) |
| 3 | **Module Change Converter** | User has role **`INPC_TSD_CHANGE_CONVERTER`** and applied TSD picker | **TSD module only** | Session attrs + cookies e.g. `fw_tsd_conv_code` / `fw_tsd_conv_name` / `fw_tsd_conv_overridden` (names TBD; do **not** reuse `fw_override_cust_*`) |

Legacy used `RoleCode` DIST/ENDC vs `Failure_CSR`. INPCV2 **replaces** that
gate with role **`INPC_TSD_CHANGE_CONVERTER`** for showing the converter
picker.

**Module picker autocomplete (decision):** reuse the legacy limited list —
same behavior as production

[`TSDCommon/GetDistributorAutoComplete?system_name=tsd_ovrride_con_code&tsd_dist_enl_id={loginEnl}&phrase=`](https://inpc.3m.com/inpc/TSDCommon/GetDistributorAutoComplete?system_name=tsd_ovrride_con_code&tsd_dist_enl_id=A6GWBZZ&phrase=+)

That query returns only converters in `tsd_distributor` mapped to the logged-in
ENL via `tsd_distributor_asm_mapping` (not the full portal customer list).
Port as `GET /api/customer/tsd/converters/autocomplete` with the same filter.
Do **not** use Change Customer’s `ia_user_master` autocomplete for module
override — too many rows / wrong entitlement.

### B. UI rules

| Condition | UI |
|-----------|-----|
| Has role `INPC_TSD_CHANGE_CONVERTER` | Show **Change Converter** in TSD shell (modal UX like Change Customer; screenshot: [tsd_set_converter.png](./assets/tsd/tsd_set_converter.png)); AC = limited distributor list above |
| No that role | Hide picker; converter = resolved default only (login or portal override — see C) |
| Portal Change Customer | Unchanged in profile menu; does not open TSD picker |

After a successful TSD converter apply: reload Warranty Requests, clear any
in-progress New Request, refresh warranty-type radios from `warranty_obj`.

### C. Server resolve order (every TSD API)

Implement one helper, e.g. `TsdContextSql.resolveWorkingConverter(session)`:

```
1) If session has TSD module override
      AND user has role INPC_TSD_CHANGE_CONVERTER
      → use fw_tsd_conv_code / session TSD override

2) Else if portal customer is overridden (see_other + fw_customer_overridden)
      → candidate = portal override cust_code (same value as ia_user_master.cust_code / GetCustCode)
      → if candidate exists in tsd_distributor.code → use it
      → else → 400/clear message: that customer is not set up as a TSD converter
        (user with INPC_TSD_CHANGE_CONVERTER can then pick via module UI)

3) Else → candidate = login cust_code (ia_user_master.cust_code)
      → if exists in tsd_distributor.code → use it
      → else → “Converter is not set up” (or require Change Converter if role present)
```

Always load `warranty_obj` from `tsd_distributor` for the **resolved** code
(`d.code` = that customer/converter code).
Never trust a client-posted DistCode unless it matches this resolution (or is
the apply-converter endpoint, which checks role + master + optional ASM map).

**Why module override wins over portal:** a CSR may Change Customer for CIR
work, then open TSD and pick a different converter without breaking the
portal header. Leaving TSD clears or ignores module override; portal override
stays.

**Why portal override is still used when no module override:** support users
who already selected a customer that *is* a converter get a sensible TSD
default without a second pick.

### D. APIs (suggested)

| Endpoint | Purpose |
|----------|---------|
| `GET /api/customer/tsd/context` | Resolved converter + warranty flags + `canChangeConverter` (role) + `source` (`login` \| `portal` \| `tsd`) |
| `GET /api/customer/tsd/converters/autocomplete?value=` | Port of `GetDistributorAutoComplete` with `system_name=tsd_ovrride_con_code`: `tsd_distributor` + **ASM mapping for login ENL** (limited set) |
| `POST /api/customer/tsd/converter` | Set/clear module override — **requires** `INPC_TSD_CHANGE_CONVERTER`; validate code is in that allowed set |

Portal Change Customer APIs stay under `/api/portal/change-customer/*`.

### E. Client helpers

- Portal modules: keep `Common.GetCustCode()` (portal only).
- TSD JS: `Tsd.GetConverterCode()` / context from `/context` — **do not** call
  `GetCustCode` alone for DistCode; use TSD context so module override applies.
- Shell on load: call `/context`; if `canChangeConverter` and no valid
  converter yet → open/focus Change Converter; else show tabs.

### F. Legacy reference (still true for autocomplete SQL)

Prod autocomplete today:

`…/TSDCommon/GetDistributorAutoComplete?system_name=tsd_ovrride_con_code&tsd_dist_enl_id={enl}&phrase=`

Submit: `TsdReqWarranty.SetNewConvCodeManualy()` → `TSDCommon/SetNewConvCodeManualy`.
INPCV2 ports behavior under the role + three-source model above; drop
DIST/ENDC-only `Failure_CSR` as the sole gate.

## Warranty types and form summary

Warranty types shown from distributor flags (`GetWarrantyTypesForSelectedDist`
/ UI `FormWarrantyTyes`). Selecting a type **changes the New Request screen**.
Legacy screenshots (captured 2026-10-03) are saved under
`doc/assets/tsd/` for UI parity during migration:

| Type | Screenshot |
|------|------------|
| PQ Warranty | [tsd_pq_warranty.png](./assets/tsd/tsd_pq_warranty.png) |
| Actual Warranty | [tsd_actual_warranty.png](./assets/tsd/tsd_actual_warranty.png) |
| PPC for Retail Sale | [tsd_ppc_retail_sale.png](./assets/tsd/tsd_ppc_retail_sale.png) |

### 1) PQ Warranty

Shared **Customer Details** questionnaire (all mandatory radios):

- Are you a Converter / Applicator? → Converter | Applicator
- First time issuing a PQ warranty to you? → Yes | No
- Relationship with other existing 3M converters? → No Relationship | Sister Concern
- Sister companies issued PQ certificates by competition for this project? → Yes | No
- Valid converter/Applicator agreement signed by 3M and current? → Yes | No
- Any sister cos being certified by us? → Yes | No
- Signboards manufactured per 3M SOP using 3M MCS? → Yes | No

Then the **address grid** (Converter/Applicator row read-only from login):

| Row | Name | Address 1 | Address 2 | State |
|-----|------|-----------|-----------|-------|
| Converter/Applicator | prefilled (e.g. `18878-RKS INDUSTRIES`) | prefilled | prefilled | prefilled |
| Customer * | free text (note: appears on Warranty Document) | * | * | state LOV * |
| Contractor * | free text (note: appears on Warranty Document) | * | * | state LOV * |

**Remarks *** (textarea). Further sections (FYI emails, products, docs, approvers)
continue below the fold in the legacy form.

### 2) Actual Warranty

Same questionnaire + address grid + Remarks as PQ Warranty, **plus** under
Warranty Information:

- **Does PQ Warranty Exists?** → Yes | No  
  (When Yes, legacy also collects the related warranty number — keep that
  behavior when porting.)

Product tabs later add **actual installation date** (and related Actual-only
fields). Account overdue / due diligence prompts apply on Actual (and PPC).

### 3) PPC for Retail Sale — **different screen**

Does **not** show the PQ/Actual questionnaire or customer/contractor address
grid. Instead:

**Distributor Details**

- First time issuing a PPC Certificate to you? * → Yes | No
- Have you signed the agreement and is it current? * → Yes | No
- Distributor Name * — read-only from login (e.g. `18878-RKS Industries`)

**Buyer Details**

- Buyer Details * — textarea
- Date of Sale * — date picker

**Product And Tender Details** (same tab engine as PQ/Actual — see below)

- No. of Products * — dropdown (drives Product 1…N tabs)
- Per-product: Type, Name, WorkOrder/PO, Project, warranty years, Remarks,
  **PPC Qty**, **PPC UOM ***

INPCV2 must keep type-specific show/hide: PQ and Actual share one layout
family; PPC is a separate header layout with its own mandatory fields and
product columns.

### Product tabs — No. of Products (all three types)

Applies to **PQ Warranty**, **Actual Warranty**, and **PPC for Retail Sale**.
Screenshots (2026-10-03):

| Type | Product / tender screenshot |
|------|-----------------------------|
| PQ | [tsd_products_pq.png](./assets/tsd/tsd_products_pq.png) |
| Actual | [tsd_products_actual.png](./assets/tsd/tsd_products_actual.png) |
| PPC | [tsd_products_ppc.png](./assets/tsd/tsd_products_ppc.png) |

**Behavior (legacy `tsd_new_req_warranty.html` / `AssignTabsForProducts`):**

1. Section **Product And Tender Details**.
2. **No. of Products *** — `<select id="no_of_products">` options **1–10**
   (`onchange='AssignTabsForProducts()'`, `onfocus` stores `previous_val`).
3. Changing the count **rebuilds tabs** `Product 1` … `Product N` into
   `#products_ul` / `#tab_content_product`. Reducing N may prompt if data
   would be lost; cancel restores `previous_val`.
4. PQ also shows **Tender/Ref No. *** beside the product count (same strip).
5. On edit load, `no_of_products` is set from header and **disabled**.
6. Saved as `header_obj.no_of_products`; product loop `for i=1..N` builds
   `product_obj`.

**Per-product fields (shared core):**

| Field | PQ | Actual | PPC |
|-------|:--:|:------:|:---:|
| Product Type * | ✓ | ✓ | ✓ |
| Product Name * | ✓ | ✓ | ✓ |
| WorkOrder/PO Details * | ✓ | ✓ | ✓ |
| Project Name * | ✓ | ✓ | ✓ |
| No of warranty years * | ✓ | ✓ | ✓ |
| Remarks | ✓ | ✓ | ✓ |
| Actual Installation Date | — | ✓ | — |
| PPC Qty / PPC UOM | — | — | ✓ |

Below the active product panel (all types):

- **Note to Requester** — if signboard details exceed **10 lines**, submit
  then upload Excel from Warranty Requests popup Product Information; upload
  signboard **documents on the form only**; Excel is **data only** (no files).
- **Account Overdue Status *** — Overdue | Not Overdue (shown on Actual/PPC
  screens in captures; keep type rules from legacy JS when porting).
- **Approver And Document Details** — left: Approvers (ASM / RSM / NSM / DM…);
  right: Attachment Details (e.g. *3M Invoice Copy, Work Order / PO Details).
- Actions: **Cancel** | **Draft** | **Submit**.

Legacy oddity: option label `8` uses `value='9'` in HTML — fix to `value='8'`
in INPCV2.

### Approver And Document Details (DB-driven)

Screenshot: [tsd_approver_documents.png](./assets/tsd/tsd_approver_documents.png).

This footer block is **not hard-coded**. After warranty type (and customer
state for ASM LOV) is known, the UI calls legacy
`POST TSDReqWarranty/GetDocumentList` with
`editIntCode`, `warr_type`, `g_tsd_entity`, `g_tsd_dist_code`, `cust_state`.
Response drives both tables via `FormApprovalmatrix` + `FormDocumentTable`.

Also shown above the two tables (type rules from legacy validation):

- **Account Overdue Status *** — Overdue | Not Overdue  
  Submit blocks if empty; **Overdue** cannot raise a request.

| Side | UI | Source |
|------|-----|--------|
| Left | **Approvers Details** — Sl No, Approver Role, Approver Name | `tsd_approval_matrix` (+ LOVs) |
| Right | **Attachment Details** — Document Name, Choose File | `tsd_document_master` (+ saved files on edit) |

**Approvers (`approval_matrix_obj`)**

- Rows from `GetApprovalMatrixForSelectedEntity` → `tsd_approval_matrix`
  filtered by entity / warranty type (and edit context when reloading).
- Typical roles in UI: **ASM**, **RSM**, **NSM**, **DM** (also GM / ASMUpload
  etc. depending on matrix data).
- **ASM** and **DM** are dropdowns; other roles often display a fixed
  `enl_id-name` string.
- Supporting LOVs in the same API response:
  - `asm_obj` — PQ/Actual: ASM for **customer state**
    (`TSDCommon.GetASMListForState` / `tsd_asm_state_mapping`);  
    PPC: ASM for **distributor + state** (`GetASMListForSelectedDist`).
  - `rsm_nsm_obj` — RSM/NSM from distributor mapping (`GetRSMList`).
  - `approval_division_obj` — DM list for entity (`GetDivisionList` /
    `tsd_division_master` / group).
- Changing customer state can refresh ASM via `GetASMListForCustomrState`
  without rebuilding the whole document list.
- On save, UI builds `approver_obj[i]` with `sequence`, `approver_role`,
  `approver_id`, `approval_source`, `ui_status` → inserted into
  `tsd_new_request_approval_matrix`; header gets `pending_with*` / status.

**Documents (`query_docs_obj`)**

- From `tsd_document_master` where `warranty_type = <selected warr_type>`.
- Columns used: `doc_int_code`, `short_code`, `document_name`, `mandatory`,
  `sequence`; on edit, left join `tsd_new_request_documents` for
  `ftp_file_name` / `ftp_file_path`.
- UI marks mandatory names with `*` (example capture: **\*3M Invoice Copy**
  mandatory; **Work Order / PO Details** optional — exact set is **per
  warranty type in DB**, so always load from master, do not hard-code names).
- File inputs on Submit/Draft upload; total attachment size historically
  **&lt; 10 MB**; stored under request via `InsertIntoAttachmentItemDetails`
  + SMB share (INPCV2: SMB 3.1.1).

**Actions (same footer):** Cancel | Draft | Submit.

### Shared (footer continued)

**Signboard / static product tables:** dynamic signboard grid (optional
per-row file) and static retro metadata from product master (inside product
tabs / popup Excel path).

**Save:** `header_obj.save_type` = `Draft` or `Submit`. Payload is
`multipart/form-data` with JSON `full_obj` (`header_obj`, `approver_obj`,
`product_obj`, …) plus files keyed like `header~{docIntCode}~{shortCode}`,
`signboard~…`, and tender paths inside product JSON.

## Legacy API map → suggested INPCV2 APIs

Legacy controllers use `{context}/TSDReqWarranty/...` (no `/api/customer`
prefix). New APIs should follow CIR: `/api/customer/tsd/...`.

### `TSDCommon` → `/api/customer/tsd/...`

| Legacy | Purpose |
|--------|---------|
| `GET MakeSessionActive` | Session keepalive (portal already has session) |
| `GET GetDistLoggedInDetails` | Distributor / converter context + warranty flags |
| `GET SetNewConvCodeManualy` | CSR override converter (admin/CSR only) |
| `POST GetStateLOVData` | State LOV |
| Autocomplete GETs | Distributor, customer, converter, applicator, contractor, product, warranty |
| `POST GetASMListForSelectedState` | ASM for new-customer modal |

### `TSDReqWarranty` → `/api/customer/tsd/...`

| Legacy | Purpose |
|--------|---------|
| `GetWarrantyRequestsByTSD` | My Requests list |
| `getOnloadData` | Product types + edit payload |
| `GetDocumentList` | Required docs + approval matrix + ASM/RSM/DM LOV |
| `GetASMListForCustomrState` | ASM refresh by customer state |
| `SaveTSDNewRequest` | Create/update + files |
| `SaveTSDEditProductDetails` | Signboard-only edit from popup |
| `SaveNewCustomer` | Modal new customer |

### Other (legacy → INPCV2)

| Legacy | INPCV2 |
|--------|--------|
| `/TSDReqPopup` `GetApprovalDetailsForPopup` | `GET /api/customer/tsd/requests/{id}` |
| `/TSDFtpFileUpload` downloads | `GET .../documents/{id}/download` + `GET .../files/download` (`TsdDocUpload`) |
| `/TSDSignboardExcelUpload` | `GET/POST .../products/{productRowId}/signboard/excel` (**done**) |
| `/TSDGenerateWarrantyPDF` (+ PQ/PPC classes) | `GET .../products/{productMasterId}/warranty-pdf` (**done**) |
| `TSDProductMaster` dyn table | `GET .../products/{productId}/dyn-table` (**done**) |

## Database (MSSQL)

| Item | Value |
|------|--------|
| Legacy config | `inpc/.../resources/hibernate_tws.cfg.xml` |
| Server (active in repo) | `PRODSQL445A\SQL445A` |
| Database | **`dINTWSYS`** |
| Username (cfg) | `INSQLAPPADMIN_TW` |

Credentials stay in config / secrets managers — **do not** paste passwords into
docs or commit them into this markdown. Confirm network and application-user
permissions from the INPCV2 runtime before coding writes.

**INPCV2 (done):** use existing `insba.datasources.csd` → `dINTWSYS`;
`HibernateFactoryRegistry.TSD` aliases `CSD`; `menu-datasources: TSD: csd`.
Do **not** add a second YAML pool named `tsd`.

Secondary: AS/400 via existing `as400` pool for share resolution
`call BPCSLCLIN.CMW010S('TSD','A2ARVZZ','ATTACHMENT')` (legacy hard-coded
login in that call — replace with the approved application login pattern used
by CIR/COA).

### Core tables (from legacy SQL)

**Transaction**

- `tsd_new_request`
- `tsd_new_request_product_table`
- `tsd_new_request_approval_matrix`
- `tsd_new_request_documents`
- `tsd_new_request_history`
- `tsd_new_request_signboard_table`
- `tsd_new_request_static_table`
- `tsd_new_request_buyer_proc_details`
- `tsd_new_request_dist_proc_details`

**Master / config**

- `tsd_distributor`, `tsd_customer`, `tsd_product_master`, `tsd_product_category`
- `tsd_product_master_tr_group`
- `tsd_document_master`, `tsd_approval_matrix`
- `tsd_division_master`, `tsd_group_master`
- `tsd_asm_rsm_mapping`, `tsd_distributor_asm_mapping`, `tsd_asm_state_mapping`
- `tsd_ppc_product`
- `tsd_template`, `tsd_template_details`
- `tsd_code_generator`, `tsd_url_setup`
- `tsd_mail_history`

**Cross-module**

- `ia_user_master` (approver ENL / name / email)
- Occasional references to other schemas in legacy — verify before use

## Document storage

- Legacy upload: `TSDFtpFileUpload.UploadTSDDocuments` → CMW010S share row →
  **JCIFS `SmbFile`**.
- Paths stored relative, e.g.
  `{year}/{month}/{folder}/{requestId}_{rand}_header_{docId}.{ext}`
  (and `_signboard_`, `_tendor_` variants).
- Download: `GET TSDFtpFileUpload/DownloadTKFilesFromServer?...`.

**INPCV2 requirement:** all TSD file I/O server-side with encrypted **SMB 3.1.1**
(SMBJ), same standard as CIR / Rebate / COA. Do **not** copy JCIFS or expose
`smb:` paths to the browser.

**Implemented:** `TsdDocUpload` owns SMB I/O — `store` (upload) and `read` (download) use
`SmbConfig.withDialects(SMB_3_1_1).withEncryptData(true)`. Download API:
`GET .../documents/{id}/download`. New Request multipart upload must call
`TsdDocUpload.store` (same class); do not add a second file transport.

## Confirmed implementation decisions

- Add **new** TSD files only under INPCV2; do not edit the legacy `inpc` checkout
  for this migration.
- Flat package: `src/main/java/com/mmm/tsd/` (no `controller` / `dao` /
  `dto` subpackages).
- **Java save and multi-table writes** follow
  [Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md)
  (see next section).
- UI under `src/main/resources/static/html_files/TSD/` and
  `src/main/resources/static/custom_js/TSD/tsd.js` (merge legacy JS into one
  module script where practical).
- Resolve converter through the three-source context helper. Never trust
  browser-only `convIntCode` / `DistCode` for authorization.
- Parameterize SQL in `*Sql` helpers via `NativeQuerySupport` — no string-concat
  of user input.
- My Requests list uses `Common.DataTable.init` / `setData`.
- SQL timestamps: `UserSessionSupport.sessionDate()` where inserts/updates use
  “now”.
- **Warranty PDF done** (accepted 2026-10-03): single builder (`TsdWarrantyPdf` /
  `TsdWarrantyPdfBuilder` / `TsdWarrantyPdfSql`), iText 9 + html2pdf, shared
  `tsd_template_details.pdf_text` **read-only** (never write layout fixes to DB).
  Margins `setMargins(70, 25, 33, 25)` top/right/bottom/left; generate-time
  float→table for signatory; collapse `<br>`; double break before USAGE only.
  Full rules: [TSD_SYSTEM.md — Warranty certificate PDF](./TSD_SYSTEM.md#warranty-certificate-pdf-accepted).
- **Save identity:** after INSERT use `req_id` / product keys — do **not** rely on
  `SCOPE_IDENTITY()` across separate `NativeQuerySupport` JDBC statements.
- **Dates:** portal `dd/mm/yyyy` → `CommonFunctions.sqlDate` → `yyyy-MM-dd` or null.
- **IDs:** never duplicate HTML ids (Buyer: section `#tsd_nr_buyer_details`,
  textarea `#tsd_nr_buyer_name`).
- Submit mail done (`TsdMail`); approve/reject stay in the backend app.

## Java save and transactional coding

**Source of truth for how to write TSD Java (especially Draft/Submit):**  
[Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md).

Apply that standard for `SaveTsdRequest` / related writes the same way Ship and
Debit and other transactional modules do:

1. Read request fields into **local variables**; validate before DB changes.
2. **One** Hibernate transaction for header + products + approval matrix +
   document metadata + history (no partial commits).
3. Header INSERT → resolve **generated id** by `req_id` (or product keys) —
   not `MAX(id)` and not `SCOPE_IDENTITY()` across separate JDBC statements →
   child tables (`tsd_new_request_product_table`, `tsd_new_request_approval_matrix`,
   `tsd_new_request_documents`, signboard/static/buyer/dist detail tables,
   `tsd_new_request_history`).
4. Bound `?` parameters in SQL order; no DTO/parameter-builder wrappers that
   only shuffle values.
5. Meaningful methods (`validateRequest`, `insertHeader`, `insertProducts`,
   `insertApprovers`, `insertDocuments`, `insertHistory`) — not abstraction for
   its own sake.
6. File bytes via SMB **after** (or clearly coordinated with) the DB transaction
   per module practice; DB must not stay half-written if the logical save fails.
7. Preserve legacy business rules unless product asks to change them.

Legacy `SaveTSDNewRequest` is the behavior reference; the coding standard is
the **structure** reference for the INPCV2 port.

## Suggested INPCV2 layout

### Java

| Class | Responsibility |
|-------|----------------|
| `TsdContext` / `TsdContextSql` | Replace `GetDistLoggedInDetails`; warranty flags; three-source resolve |
| `TsdRequests` / `TsdRequestsSql` | List + popup read |
| `SaveTsdRequest` / `SaveTsdRequestSql` | Draft/Submit per coding standard (one TX) |
| `TsdLookups` | States, docs, matrix, limited converter autocomplete |
| `TsdDocUpload` | SMB 3.1.1 upload/download (single class) |
| `TsdSignboardExcel` | Excel template + import (**done**) |
| `TsdWarrantyPdf` / `TsdWarrantyPdfBuilder` / `TsdWarrantyPdfSql` | Certificate PDF (**done**, layout accepted) |
| `TsdMail` | Submit → first-approver mail + `tsd_mail_history` (**done**) |

### UI

| Asset | From |
|-------|------|
| `html_files/TSD/tsd_home.html` | `tsd_warranty.html` shell + Bootstrap 5 tabs |
| `html_files/TSD/tsd_requests.html` | list fragment |
| `html_files/TSD/tsd_new_request.html` | `tsd_new_req_warranty.html` |
| `html_files/TSD/tsd_detail_popup.html` | approval popup |
| `custom_js/TSD/tsd.js` | merged client logic |

Menu (enable when ready):

```sql
-- Adjust menu_id / parent to match your Customer Services TSD leaf
UPDATE ia_menu_options
SET file_name = 'TSD/tsd_home',
    js_path = 'custom_js/TSD/tsd.js'
WHERE /* menu name / id for TSD E-Warranty */;
```

Load Type: Internal.

### API prefix

`/api/customer/tsd/...` (Spring `@RestController`).

## Migration phases

1. **Datasource + smoke** — **done** (`csd`/`TSD` → `dINTWSYS`).
2. **Context + My Requests + Change Converter + detail popup** — **done**.
3. **New request lookups / matrix / product AC / dyn-table** — **done**.
4. **Save Draft/Submit** + SMB documents + Draft/Rework edit — **done**.
5. **Signboard Excel** from Request Details (>10 lines) — **done**.
6. **Warranty PDF download** — **done** (layout accepted 2026-10-03; no further
   break/DB changes).
7. **Mail** after Submit — **done** (`TsdMail`; Draft skips; backend link from
   `tsd_url_setup.ew_backend_url`).
8. **Internal approval mutations** — **out of scope** for customer portal
   (approvers act in the backend app).

## Security and migration risks

1. Legacy list/save trust client `convIntCode` / `DistCode` — must become
   server-resolved context.
2. Heavy string-concat SQL in legacy controllers — rewrite with bound params.
3. JCIFS + credentials in Hibernate cfg — move to Spring config; SMBJ only.
4. Client 10 MB limit — enforce again server-side.
5. CSR override (`SetNewConvCodeManualy`) needs role gating.
6. Confirm internal approval channel before implementing mutations.
7. Do not conflate with `com.mmm.ewarranty` / `resources/Ewarranty`.

## Distinction: TSD vs Ewarranty

| | **TSD (`#/TSD`)** | **Ewarranty** |
|--|-------------------|---------------|
| Audience | TSD converter / applicator / PPC dist | Converter / dist / end-customer graphic warranty |
| Java | `com.mmm.tsd.*` | `com.mmm.ewarranty.*` |
| Entry HTML | `tsd_warranty.html` | `ewarrantyconv.html`, etc. |
| DB (TSD) | `dINTWSYS` | Separate (verify if migrating later) |

## Related docs

- [TSD_SYSTEM.md](./TSD_SYSTEM.md) — **living file + API map** (paths, params, Java class per call) — keep in sync when coding
- [CIR_MIGRATION.md](./CIR_MIGRATION.md) — **MSSQL module pattern to copy** (package, APIs, Sql helpers, DataTable, SMB)
- [Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md) — **Java save / multi-table TX pattern**
- [SHIP_AND_DEBIT.md](./SHIP_AND_DEBIT.md) — another customer-module migration style
- [CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md) — portal Change Customer (global)
- [CURSOR_PROJECT_GUIDE.md](./CURSOR_PROJECT_GUIDE.md) — shell, datasources, SMB rule
- [getCustomer.md](./getCustomer.md) — how modules resolve customer context
- [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) — **global** plain-jQuery module JS standard (`tsd.js` is the reference)
- [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md) — tab load-once pattern for shells
