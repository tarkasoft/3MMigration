# Shared module banner theme

Use the shared banner on new module page fragments so page headers have one
consistent layout and can be recolored centrally.

## Shared CSS

The banner theme is defined in
`src/main/resources/static/css/mainpage-overrides.css`. `MainPage.html` loads
that stylesheet. Update its CSS custom properties to change banner colors,
sizing, and spacing for every module using the shared classes:

```css
:root {
  --inpc-banner-start: #12314b;
  --inpc-banner-end: #146b79;
  --inpc-banner-text: #ffffff;
  --inpc-banner-eyebrow: #bfe8e5;
  --inpc-banner-min-height: 52px;
  --inpc-banner-padding-block: 0.45rem;
  --inpc-banner-padding-inline: 1.5rem;
}
```

Dark-mode gradient colors are overridden in the adjacent
`html[data-theme-mode="dark"]` rule. Keep page-specific banner color values out
of module fragment styles.

## HTML pattern

Add the shared `inpc-page-banner` class to the module header. Put the section
label on the left, and the module title on the right. Optional actions, such as
Refresh, can be grouped with the title on the right:

```html
<div class="module-head inpc-page-banner">
  <span class="inpc-page-banner-eyebrow">Customer resources</span>
  <div class="d-flex flex-wrap align-items-center gap-3">
    <h1 class="inpc-page-banner-title">Module title</h1>
    <!-- Optional module action buttons -->
  </div>
</div>
```

Use the exact shared utility classes for label and title; retain module-specific
classes only when needed for unrelated layout or behavior. The theme includes
responsive sizing and supports the portal dark theme.

Current examples: Policies & Guidelines, Contact Us, and Certificate of
Analysis.
