# CSD Graphic E-Warranty — system map

Living file: update when APIs or paths change. Discovery plan: [EWARRANTY_MIGRATION.md](./EWARRANTY_MIGRATION.md).

**Not TSD.** Do not edit `com.mmm.tsd` / `html_files/TSD` / `custom_js/TSD`.

## Datasource

| Item | Value |
|------|--------|
| Pool | `HibernateFactoryRegistry.CSD` (alias `TSD`) |
| Database | `dINTWSYS` |
| Tables | `ew_*` only |

## Menu (portal)

| Persona | `file_name` | `js_path` |
|---------|-------------|-----------|
| Converter | `EWARRANTY/ew_conv_home` | `custom_js/EWARRANTY/ew_conv.js` |
| Distributor | `EWARRANTY/ew_dist_home` | `custom_js/EWARRANTY/ew_dist.js` |

Load Type: Internal. Home HTML calls `EwConv.Load()` / `EwDist.Load()`.

## Paths

| Kind | Path |
|------|------|
| Java | `src/main/java/com/mmm/ewarranty/` |
| HTML | `src/main/resources/static/html_files/EWARRANTY/` |
| JS | `src/main/resources/static/custom_js/EWARRANTY/` |

## Shells

| Home id | Entry JS | Tabs (phase 1) |
|---------|----------|----------------|
| `m_ew_conv_home` | `EwConv.Load` | Requests (filters + list); New Request |
| `m_ew_dist_home` | `EwDist.Load` | Requests (filters + list) |

## Customer context

JS: `Common.GetProcedureCustomerContext()` → `custCode` + `loginId` on every call.  
Java: `UserSessionSupport.resolveProcedureCustomerContext` → map to `ew_convertor` / `ew_distributor`. Never trust client DistCode / convIntCode.

## APIs

| Method | Path | Java | Notes |
|--------|------|------|--------|
| GET | `/api/customer/ewarranty/converter/context` | `EwConvertor` | Change Customer → converter |
| GET | `/api/customer/ewarranty/converter/requests` | `EwConvertor` | List by `en.converter` |
| GET | `/api/customer/ewarranty/converter/requests/{id}` | `EwConvertor` | View popup (`GetApprovalDetailsForPopup`) |
| GET | `/api/customer/ewarranty/distributor/context` | `EwDistributor` | Change Customer → distributor |
| GET | `/api/customer/ewarranty/distributor/requests` | `EwDistributor` | List by `en.distributor` |
| GET | `/api/customer/ewarranty/distributor/requests/{id}` | `EwDistributor` | View popup (`GetApprovalDetailsForPopup`) |
| GET | `/api/customer/ewarranty/new-request/onload` | `EwReqWarranty` | Lookups, templates, states, approvers |
| POST | `/api/customer/ewarranty/new-request/cascade` | `EwReqWarranty` | `ew_warranty_life` LOV (`LIFE_COLUMNS` whitelist; app col = `fin_prod_info_app`) |
| POST | `/api/customer/ewarranty/new-request/warranty-life` | `EwReqWarranty` | Years from `ew_warranty_life` |
| GET | `/api/customer/ewarranty/new-request/distributors` | `EwReqWarranty` | Converter–distributor mapping AC; select shows Address/City/Phone/Email beside field (legacy) |
| GET | `/api/customer/ewarranty/new-request/customers` | `EwReqWarranty` | Approved `ew_conv_customer` AC |
| GET | `/api/customer/ewarranty/new-request/applicators` | `EwReqWarranty` | Applicator AC; select shows Address/City/Phone/Email |
| GET | `/api/customer/ewarranty/new-request/segment-leaders` | `EwReqWarranty` | Segment Leader AC (`ew_lookup_master` + `ia_user_master`, by warranty template) |
| POST | `/api/customer/ewarranty/new-request/vinyl` | `EwReqWarranty` | Primary / secondary film AC |
| POST | `/api/customer/ewarranty/new-request` | `EwReqWarranty` / `SaveEwRequest` | One TX: number + header + vinyl + matrix |
| GET | `/api/customer/ewarranty/converter/requests/{id}/products/{prodRefCode}/warranty-pdf` | `EwWarrantyPdf` | Closed only — dispatches by exact `wrty_template` (PPF + 5 graphics families); photos from mount via `EwFileStore` |
| GET | `/api/customer/ewarranty/distributor/requests/{id}/products/{prodRefCode}/warranty-pdf` | `EwWarrantyPdf` | Same, distributor-owned |
| GET | `/api/customer/ewarranty/converter/requests/{id}/files/download` | `EwDocDownload` | Invoice / proof files (`fileName`, `filePath`) |
| GET | `/api/customer/ewarranty/distributor/requests/{id}/files/download` | `EwDocDownload` | Same, distributor-owned |
| GET | `/api/customer/ewarranty/autocomplete` | `CsdAutocomplete` | List filters: display `code-name`, query by **code** only |

Query params: `custCode`, `loginId` (optional).  
SQL helpers: `EwRequestsSql`, `EwReqWarrantySql`, `EwWarrantyPdfSql`. Context: `EwContext`. Files: `EwFileStore` — mount only (no SMB): `{inpc.ewarranty.mount-root}/EWARANTY/{picture_path}` (console prints `new_path....`).

## Files (as built)

| Kind | Files |
|------|--------|
| HTML | `ew_conv_home.html`, `ew_dist_home.html`, `ew_requests.html`, `ew_new_request.html`, `ew_req_products.html`, `ew_req_ppf.html`, `ew_dist_cust_graphics_invoice_details.html`, `ew_req_popup.html` |
| JS | `ew_conv.js`, `ew_dist.js`, `ew_common.js`, `ew_new_request.js`, `ew_req_popup.js`, `csd_autocomplete.js` |
| Java | `EwContext`, `EwConvertor`, `EwDistributor`, `EwReqWarranty`, `EwReqWarrantySql`, `SaveEwRequest`, `EwRequestsSql`, `CsdAutocomplete`, `EwDocDownload`, `EwFileStore`, `EwWarrantyPdf`, `EwWarrantyPdfPpf`, `EwWarrantyPdfGraphics`, `EwWarrantyPdfSql` |

Follow [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md): parent `m_ew_conv_home` / `m_ew_dist_home`; New Request root `m_ew_new_request`; `EwConv._$` / `EwNewRequest._$`; `showLoader` / `hideLoader`; framework date picker (`dd/mm/yyyy`, `EwCommon.initFilterDate` / `openFilterDate` / `openModuleDate` with `container:"body"`); Browse File pattern (`ew-nr-doc-browse`); never `<input type="date">`. Page errors: Ship-and-Debit style banner + `is-invalid` on fields.

## Converter New Request

Host: `ew_new_request.html` + `ew_new_request.js`.

**Template switch** = legacy `EWReqWarranty.ActionsOnChangeWarrantyTemplate`  
Lookup `Warranty Template` values (exact spelling):

| # | Template value | Host (billing always shown) | Install default | Dist + Dist→Conv invoice | No. of Graphic Elements | Print Service | Applicator/Store | Product tab(s) | Product body |
|---|----------------|----------------------------|-----------------|--------------------------|-------------------------|---------------|------------------|----------------|--------------|
| 1 | **MCS Warranty-Printed** | Dist + Segment Leader | Address | yes | 1–5 | show | hide | Graphic ElementN / SignageN | Full graphics (Primary + Sec + Overlam + Print + color) |
| 2 | **MCS Warranty-Colored & Signage** | same as MCS Printed | Address | yes | 1–5 | show | hide | Graphic ElementN / SignageN | same as MCS Printed |
| 3 | **Special Warranty - Graphics** | same as MCS Printed | Address | yes | 1–5 | show | hide | Graphic ElementN / SignageN | same as MCS Printed |
| 4 | **Building Window Film Warranty** | Dist + Segment Leader | Address | yes | 1–5 | show | hide | Graphic ElementN / SignageN | `HideForBuildingOrDiNoc`: hide graphic_conv / flexible-substrate / sec / overlam / print / color; show Edge Sealer; BWF film labels; **Application Substrate stays** |
| 5 | **Paint Protection Film** | `is-ppf` → Applicator + Segment Leader; hide Dist / invoice / print / multi-product | **Vehicle** (Address radio disabled) | no | forced 1 (hidden) | hide | show | Product 1 | `ew_req_ppf.html` |
| 6 | **DI-NOC Warranty** | Dist + Segment Leader | Address | yes | **hidden** (forced 1) | **hide** | hide | **Di-Noc Installation** | same product hide as BWF; DI-NOC film labels |

Fragments: `ew_req_products.html` (slots 1–5), `ew_req_ppf.html` (PPF Product 1), `ew_dist_cust_graphics_invoice_details.html` (non-PPF only).

Non-vehicle install field order (legacy `non_veh_inst_div`): Brand Owner Name → Address 1/2 → City → State → Postal → Branch/Site Name → Branch/Site ID. UI: labeled 4-col panel; Address vs Vehicle radios toggle `#ew_non_veh_inst_div` / `#ew_veh_inst_div` (`onInstTypeChange`).

### Product tabs — `AssignTabsForProducts`

Legacy: `#no_of_products` `onchange` → `EWReqWarranty.AssignTabsForProducts()`.

INPCV2: `EwNewRequest.assignTabsForProducts(askConfirm)`:

- `#ew_no_of_products` change → `assignTabsForProducts(true)` (Swal confirm: *All entered Product Details will be deleted. Do you want to change?*; cancel restores previous count).
- Template switch → `assignTabsForProducts(false)`.
- Shows tabs **Graphic ElementN / SignageN** for N = 1…`no_of_products` (max 5); activates slot 1; wires / resets cascade on visible panels.
- `captureNoOfProducts` stores `data-previous-val`.

Click tab → `activateSlot` (legacy `HandleProductsTabs`). Each product slot uses a distinct section/table header color (legacy `ew_req_product_N`): **1** rose `#E6D2D0` / `#C78C86`, **2** purple `#f0e6f5` / `#9c59bd`, **3** lime `#e5f5c1` / `#76A908`, **4** teal-grey `#e0ebeb` / `#94b8b8`, **5** pink `#ffcccc` / `#ff9999`. Active tab button matches.

### Graphics product body (legacy `ew_req_product_N.html` order)

Per slot in `ew_req_products.html`:

1. **Project Information** — Application, Graphic Conversion Method (hidden BWF/DI-NOC → `NA`), Type of exposure, Application substrate (**always** for graphics), Edge Sealer (BWF/DI-NOC only)
2. **Substrate Information** — Flexible substrate, lot, qty (hidden BWF/DI-NOC)
3. **Proof Of Installation** — Width, Height, Unit, Area (auto), Qty, Picture (Browse File), Remarks
4. **Primary Film / Vinyl** — multi-row table + Action
5. **Secondary Film / Vinyl** — multi-row (hidden BWF/DI-NOC); default `NA`
6. **Overlaminate Information** — overlam, lot, qty (hidden BWF/DI-NOC)
7. **Printing Information** — Print Platform, Printer Model, Ink (hidden BWF/DI-NOC)
8. **Warranty Life** (readonly) + **Recheck Warranty**

**Block chrome:** Title strip `.ew-ppf-block-title` (`border-bottom:0`) + either `.ew-ppf-table` cells (Substrate / POI / Vinyl / Overlam) or `.ew-ppf-block-body` (Project / Printing grids) so each section is a closed box. Product-panel borders use `--ew-slot-accent` (same per-tab colors as headers).

**Distributor to Converter Invoice** (above products, non-PPF): Invoice No / Date / Documents / + — same role as legacy `ew_dist_cust_graphics_invoice_details.html`.

### Cascade + AC UX (graphics)

- Chain on `ew_warranty_life` via `POST .../cascade` (`LIFE_COLUMNS` whitelist). Each step: disable target + `EwCommon.ensureAcLoader` spinner; on fail show `.ew-nr-ac-error` beside the field (same pattern as Dist/Customer AC).
- **Graphic Conversion Method:** first cascade step loads with `warranty_type` only (skip Application filter) so LOV includes legacy **`NA`** plus filtered values; ensure `NA` is present even if SQL omits it.
- **No. of products** confirm: SweetAlert2 (`Swal.fire`) — not `window.confirm`.
- **Distributor AC:** `ew_converter_distributor_mapping` has **no** `warranty_type` column — SQL filters by converter + phrase only.

### Film / vinyl multi-rows (legacy `AddVinylGroupRow`)

**+** does **not** require lot / unique / qty filled (INPCV2; legacy validates before add). Rows 2+ **copy first-row film name and disable it**. Max 5 lines (message if exceeded).

| Template | Film labels | Color | Unique lot | Secondary film | Cascade |
|----------|-------------|-------|------------|----------------|---------|
| Paint Protection Film | PPF Information | hide | show | n/a | no — vinyl AC + life |
| Building Window Film / DI-NOC | BWF / DI-NOC series labels | hide | hide | hide | yes |
| MCS / Special Graphics | Primary Film/Vinyl 1 | show | hide | show (copy+disable) | yes |

**Save mapping:** many vinyl rows may share the same `prod_sl_no` / `prod_ref_code` (product tab). PPF: all lines `prod_sl_no=1`, header `no_of_products=1`. Graphics: header `no_of_products` = tab count; vinyl list length may be greater.

### PPF layout (legacy `ew_req_ppf_product1.html`)

| Region | Behaviour |
|--------|-----------|
| Warranty Information | 6-col billing; Template |
| Parties | Applicator/Store AC + details; Segment Leader AC |
| Installation | Date; Vehicle mode; Type of Application = lookup **Vehicle Application Type** (`v_to_app`, not warranty-life filter) |
| Product 1 | Store Details \| Dist to Store Invoice; Proof Picture; PPF Information multi-row; Warranty life readonly |
| Save | Applicator + billing + segment leader required; distributor **not** required for PPF |

Install date: PPF ≤ 7 days, others ≤ 60. Draft → Draft; Submit → Pending With Distributor (graphics) or Pending With KAM/ASM (PPF).

### View / PDF / lists

View popup (`GET .../requests/{id}`): legacy `GetApprovalDetailsForPopup` payload. UI: `ew_req_popup.html` + `ew_req_popup.js`.  
Graphics POI columns: Width, Height, Unit, Area (`dimension`), Quantity(pcs), Picture, Remarks (`description`). PPF POI: Picture + Area of Application.  
Modal: wider (`max-width:1560px`); teal **Request Details** header (not white); dark mode + mobile full-bleed scroll.  
PDF: all 6 templates when Closed (`EwWarrantyPdf` → `EwWarrantyPdfPpf` or `EwWarrantyPdfGraphics`); assets `classpath:ewarranty/images/{Common,PPF,BWF,DiNOC,MCS,SpecialWarranty}/`; photos from mount.  
Lists: `csd_autocomplete.js` + `CsdAutocomplete`. Unmapped customer: bold red message.

Multi-tab: all fields under `m_ew_new_request` via `Module._$`. Autocomplete `appendTo` = active home. Grids: unique DataTable roots per persona.

## Status

| Item | Status |
|------|--------|
| Converter shell + request list | Done |
| Distributor shell + request list | Done |
| New Request — PPF | Done (layout, docs browse, multi-row, segment leader, save) |
| New Request — Graphics | Host + products + tabs + cascade/AC UX done; **save** header/vinyl/sec/substrate/overlam/POI/addnl invoice **metadata** done; **file upload to mount** (invoice docs / POI pictures) still pending |
| Detail popup + file download | View + download done; approve + dist-agree upload pending |
| PDF per product | Done — all 6 templates (PPF + BWF / DI-NOC / MCS Printed / MCS Colored & Signage / Special Graphics) when Closed |
| Claims / Manage Customers / End customer | Hidden |

## Changelog

| Date | Change |
|------|--------|
| 2026-10-06 | Converter + Distributor shells, lists, Change Customer |
| 2026-10-06 | New Request: template switch, cascade, save |
| 2026-10-06 | List filters AC; framework date picker |
| 2026-10-06 | PPF View popup + warranty PDF + Application Photographs |
| 2026-10-06 | `EwDocDownload`; mount-only `EwFileStore` (`inpc.ewarranty.mount-root`) |
| 2026-10-06 | PPF: Segment Leader AC; Vehicle Application Type; Browse File; SD-style errors; vinyl AC `fin_prod_info_app` |
| 2026-10-06 | PPF multi-row copy+disable; add without filling lot/qty |
| 2026-10-06 | Graphics: `ActionsOnChangeWarrantyTemplate` invoice load; `ew_req_product` section order; `assignTabsForProducts`; DI-NOC spelling; BWF/DI-NOC hide |
| 2026-10-06 | All 6 Warranty Template host matrix vs legacy; DI-NOC hides No. of products; Application Substrate stays for BWF/DI-NOC; install field order |
| 2026-10-06 | Per-product tab header colors (legacy ew_req_product_N) |
| 2026-10-06 | Graphics save: substrate / overlam / POI / sec vinyl / Dist→Converter invoice rows; PPF no longer requires Distributor |
| 2026-10-06 | Dist AC: drop nonexistent `mp.warranty_type`; show AC/DB errors beside autocomplete fields |
| 2026-10-06 | Cascade: per-field spinner + field-adjacent errors; GCM LOV without Application filter + ensure `NA`; product-count confirm → Swal |
| 2026-10-06 | Project / Printing: `.ew-ppf-block-body` closes border under title (slot accent); table sections unchanged |
| 2026-10-07 | Distributor select shows Address/City/Phone/Email beside field (`#ew_distributor_details`, same strip as Applicator) |
| 2026-10-07 | Installation Information: labeled 4-col panels; Address/Vehicle hide-show; matches Warranty Information style |
| 2026-10-07 | Detail popup: graphics POI columns (Area + Remarks); wider modal; teal Request Details header; dark/mobile polish |
| 2026-10-07 | Warranty PDF: BWF / DI-NOC / MCS Printed / MCS Colored & Signage / Special Graphics via `EwWarrantyPdfGraphics`; popup `canPdf = closed` for all templates |
