# CSD / TSD warranty datasource & smoke APIs

**Shared warranty DB** for both **CSD** (`com.mmm.csd` smoke) and **TSD**
(`com.mmm.tsd` E-Warranty). Legacy: `hibernate_tws.cfg.xml`.

| Item | Value |
|------|--------|
| YAML key | `insba.datasources.csd` |
| Registry | `HibernateFactoryRegistry.CSD` and alias `TSD` (same pool) |
| Server | `PRODSQL445A\SQL445A` |
| Database | **`dINTWSYS`** |
| Username | `INSQLAPPADMIN_TW` (password in `application.yml` only) |
| Menu map | `CSD: csd`, `TSD: csd` |

Do not add a second YAML pool for TSD. Production code under `com.mmm.tsd`
should call `NativeQuerySupport` with `HibernateFactoryRegistry.TSD` (or `CSD`).

## Smoke endpoints (`com.mmm.csd`)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/INPCV2/api/csd/ping` | Build SF, return identity hashes |
| GET | `/INPCV2/api/csd/users?limit=5` | Sample query (smoke; table may differ on warranty DB) |
| GET | `/INPCV2/api/csd/compare?limit=3` | System vs warranty pool in one call |

Same response envelope as CIR (`ResponseDataGeneric` JSON).

## Files

- `src/main/java/com/mmm/csd/CsdHybernetUtil.java`
- `src/main/java/com/mmm/csd/CsdUserService.java`
- `src/main/java/com/mmm/csd/CsdSmokeController.java`
- `HibernateFactoryRegistry` — `CSD` / `TSD` alias + `getCsdSessionFactory()` /
  `getTsdSessionFactory()`

## After deploy

Restart EAP/Tomcat, then hit `/INPCV2/api/csd/ping`. Confirm host/database
reflect `dINTWSYS`. TSD module discovery: [TSD_MIGRATION.md](./TSD_MIGRATION.md).
