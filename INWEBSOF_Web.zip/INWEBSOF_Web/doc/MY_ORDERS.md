# My Orders (CUST_SERVICE)

Follow [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md). Reference implementation: `my_orders.js`.

## Paths

- HTML: `html_files/CUST_SERVICE/my_orders.html`
- JS: `custom_js/CUST_SERVICE/my_orders.js`
- Java: `com.mmm.customer.MyOrders` (one file, sample data for now)

The page script calls `MyOrders.LoadMyOrders()`. MainPage does not.

## Tabs

Open Orders loads when the page opens. Invoice & Shipped loads the first time that tab is opened. Switching back does not call again. **Refresh** on a tab loads that tab again. **GetOrders** reloads Invoice & Shipped with the current dates and stock.

Loaded flags live on `#m_my_orders` via jQuery `.data()`: `openLoaded`, `invLoaded`. Console: `$("#m_my_orders").data()`.

## Dates

Invoice & Shipped uses the framework picker (`dd/mm/yyyy`). From Date defaults to the 1st of the month. To Date defaults to today. The API receives `yyyy-mm-dd`.

## APIs

- `GET /api/customer/my-orders/open?custCode=&loginId=`
- `GET /api/customer/my-orders/invoiced?custCode=&loginId=&fromDate=&toDate=&stock=`

`custCode` / `loginId` come from `Common.GetCustCode()` / `Common.GetLoginId()`. `loginId` may be omitted.

Both grids use `Common.DataTable`.
