# Dependency & VAPT notes

**Java:** 21  
**Spring Boot parent:** `3.5.16` (compatible with **Eclipse Tomcat 10.1** / Servlet 6.0)  
**Previous broken attempt:** `4.1.1` — requires **Tomcat 11** / Servlet 6.1

## Why not Boot 4.1.1 yet?

Your Eclipse server is `Tomcat v10.1`. Spring Boot 4 needs Servlet **6.1** (Tomcat **11**). Deploying Boot 4 on Tomcat 10.1 causes startup failures (and Boot 4 also moved autoconfigure packages).

**When you add a Tomcat 11 runtime in Eclipse**, bump parent to `4.1.1` and update excludes in `Inpcv2Application` (Boot 4 package names).

## `Failed to instantiate WebApplicationInitializer` / Unresolved compilation

Eclipse ECJ can deploy a **broken stub** `.class` that throws `java.lang.Error: Unresolved compilation problems` at Tomcat start — even when source and `WEB-INF/lib` jars are fine.

Fix that worked (2026-09-17):

1. Keep Boot **3.5.16** for Tomcat 10.1.
2. `Inpcv2Application` uses `@SpringBootApplication(excludeName = { ... })` (string names, no type imports).
3. Compile with **JDK 21** (not PATH Java 8). The `JAVA_HOME` line below is from an older Eclipse install; use this machine's JDK 21 if that folder is missing:

```powershell
$env:JAVA_HOME = "C:\Users\DELL\.p2\pool\plugins\org.eclipse.justj.openjdk.hotspot.jre.full.win32.x86_64_21.0.7.v20250502-0916\jre"
$env:Path = "$env:JAVA_HOME\bin;" + $env:Path
& "$env:USERPROFILE\.m2\wrapper\apache-maven-3.9.6\bin\mvn.cmd" -f C:\Users\A6GWBZZ\eclipse-workspace\INPCV2\INPCV2\pom.xml clean compile -DskipTests
```

4. Restart the Tomcat 10.1 server in Eclipse (Clean module work directory if it still loads an old stub).

Do **not** use the system `java` 1.8 on PATH for Maven — text blocks (`"""`) fail with fake “unclosed string literal” errors.

## VAPT fixes kept on 3.5.16

| Item | Status |
|------|--------|
| `com.github.cliftonlabs:json-simple:2.3.1` | Replaces EOL `json-simple:1.1.1` + junit CVE noise |
| `mssql-jdbc` `12.10.1.jre11` | Pinned |
| OWASP dependency-check-maven | `mvn -DskipTests org.owasp:dependency-check-maven:check` (use JDK 21) |

## After POM / Java change

1. Eclipse → right-click project → **Maven → Update Project** (Force Update).
2. Prefer **Maven compile with JDK 21** over relying on Eclipse incremental build after a Boot parent bump.
3. Restart Tomcat 10.1 / republish INPCV2.