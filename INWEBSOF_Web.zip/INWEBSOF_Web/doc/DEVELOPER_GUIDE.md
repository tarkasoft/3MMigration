# INPCV2 developer guide — native queries, mapping, datasources

Base reference for any developer working on INPCV2 data access.

**New module UI JS:** use the plain-jQuery standard — [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) (`Load` → context → tabs → `.load` once → DataTable). Reference: `custom_js/TSD/tsd.js`.

---

## 1. Big picture (flow)

```
Browser / Controller / Service
        |
        v
HibernateFactoryRegistry   (named SessionFactories: system, cir, csd/TSD, as400, infoapps, pos…)
        |
        +-- withSession(name, work)     // open → work → always close
        |         or
        +-- openSession() + finally close()   // traditional
        |
        v
NativeQuerySupport
        |
        +-- executeQuery(...)   // preferred Map mapping, no scalars
        +-- executeUpdate(...)  // parameterized writes + transaction
        +-- executeProcedure(...) / executeProcedureWithOutputs(...)
        +-- listAsMaps(...)     // Hibernate native + named binds + scalars
        |
        +-- CommonDataTable    // shared server-side table paging
        |
        v
List<Map<String, Object>>   // one Map per row (column → value)
```

**Project-wide query rule:** all feature database access must use the existing
shared query helpers (`NativeQuerySupport`, or `CommonDataTable` for its
server-side paging use case). Choose the helper matching the operation, bind
runtime values, and select the datasource through `HibernateFactoryRegistry`.
Do not add feature-local `Statement`/`PreparedStatement`, direct
`createNativeQuery`, or ad-hoc connection/session execution. If a feature needs
query behavior the shared helpers do not provide, add a reusable method to the
shared helper and document it here rather than duplicating query plumbing in a
feature.

**Project-wide document file rule:** any document **upload** or **download**
that uses a network file share must go through **SMBJ with encrypted SMB 3.1.1**
(`SMB2Dialect.SMB_3_1_1`, `withEncryptData(true)`). Resolve share location and
credentials on the server only. Do not introduce JCIFS, SMB1/SMB2-only
dialects, or browser-visible `smb:` paths/credentials. Current implementations:
`CirFileStore`, `RebateDocUpload`, `ShipAndDebitDocUpload`, `CoaSql`,
`PoliciesGuidelines`. See [CURSOR_PROJECT_GUIDE.md](./CURSOR_PROJECT_GUIDE.md)
section 14.

**Lifecycle rules**

| Object | Lifetime | Who closes it |
|--------|----------|----------------|
| `HibernateFactoryRegistry` | App (Spring singleton) | Spring |
| `SessionFactory` | App | Spring (`system`) or registry `@PreDestroy` (lazy DBs) |
| Hikari connection pool | App | Same as above |
| `Session` | **One request / one call** | You (`withSession` or `finally`) |
| Query result `List`/`Map` | Request locals | GC after response |

Do **not** store `Session` on a field or `static`. Do **not** close `SessionFactory` per request.

---

## 2. Key classes

| Class | Package | Role |
|-------|---------|------|
| `InpcDatasourceProperties` | `com.mmm.config` | Reads `insba.datasources.*` from `application.yml` |
| `SystemHibernateConfig` | `com.mmm.config` | Spring TX + primary `system` SessionFactory |
| `HibernateFactoryRegistry` | `com.mmm.config` | Named factories + `withSession` |
| `NativeQuerySupport` | `com.mmm.titpl` | Shared parameterized SQL and procedure helpers |
| `CommonDataTable` | `com.mmm.titpl` | Shared server-side table paging |
| `NativeQueryMappingTest` | `com.mmm.titpl` | Browser demos under `/api/test/**` |

Constants (datasource names):

- `HibernateFactoryRegistry.SYSTEM` → `"system"`
- `HibernateFactoryRegistry.CIR` → `"cir"`
- `HibernateFactoryRegistry.AS400` → `"as400"`

---

## 3. How to write a query

### Preferred: full SQL → Map rows (`executeQuery`)

No `addScalar`. JDBC `ResultSet` + metadata → every selected column is in the Map.

```java
String sql = """
        select top 5 u.enl_id as enlId, u.name as name
        from ia_user_master u
        order by u.enl_id
        """;

// One-liner: registry opens/closes session
List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
        registry, HibernateFactoryRegistry.SYSTEM, sql);

// Or when you already use withSession
List<Map<String, Object>> rows = registry.withSession(
        HibernateFactoryRegistry.SYSTEM,
        session -> NativeQuerySupport.executeQuery(session, sql));
```

**When to use:** day-to-day list/report style reads, “give me the full result set as maps”.

**Security:** the three-argument `executeQuery` has **no bind parameters**. For user or runtime values, use the parameterized `executeQuery` overload or `listAsMaps` with named params. Never concatenate untrusted values into SQL.

### Parameterized SELECT and updates

Use the parameterized helpers for SQL containing runtime values. They keep the
standard column-label-to-map result shape while binding values through JDBC:

```java
List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
        registry, HibernateFactoryRegistry.INFOAPPS,
        "select name from users where customer_code = ?", customerCode);

int affected = NativeQuerySupport.executeUpdate(
        registry, HibernateFactoryRegistry.INFOAPPS,
        "update users set active = ? where customer_code = ?", active, customerCode);
```

`executeUpdate` owns the transaction, commits on success, rolls back on failure,
and returns the affected row count. Do not inline runtime values into SQL.

### Optional: Hibernate native + scalars (`listAsMaps`)

Use when you need **named binds** (`:enlId`) or **forced types**.

```java
String sql = """
        select u.enl_id as enlId, u.name as name
        from ia_user_master u
        where u.enl_id = :enlId
        """;

Map<String, Object> params = new LinkedHashMap<>();
params.put("enlId", enlId);

Map<String, BasicTypeReference<?>> scalars = new LinkedHashMap<>();
scalars.put("enlId", StandardBasicTypes.LONG);
scalars.put("name", StandardBasicTypes.STRING);

List<Map<String, Object>> rows = registry.withSession(
        HibernateFactoryRegistry.SYSTEM,
        session -> NativeQuerySupport.listAsMaps(session, sql, params, scalars));
```

**Scalars are required** for `listAsMaps`: Hibernate returns `Object[]` without column names; scalar keys become Map keys.

### Traditional: open / close yourself

Same as legacy style — always close in `finally`.

```java
Session session = null;
try {
    session = registry.getSessionFactory(HibernateFactoryRegistry.SYSTEM).openSession();
    List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(session, sql);
    // use rows
} finally {
    if (session != null && session.isOpen()) {
        session.close();
    }
}
```

Prefer `withSession` for new code; traditional is fine for learning / parity with old modules.

### Manual mapping (no `executeQuery`)

`createNativeQuery` + `addScalar` + loop into `LinkedHashMap` — see `/api/test/mapping` in `NativeQueryMappingTest`.

---

## 4. Mapping — what you get

`executeQuery` builds:

```text
[
  { "enlId": 1, "name": "Ada", "active": "Y", "email": "a@x.com" },
  { "enlId": 2, "name": "Bob", ... }
]
```

- Keys = SQL column **label** (alias), else column name  
- Values = JDBC `getObject` (may be `Long`, `String`, `BigDecimal`, …)  
- Empty SQL result → empty list (not `null`)

Read a cell:

```java
Object name = rows.get(0).get("name");
Number id = (Number) rows.get(0).get("enlId");
```

---

## 5. How to add a new DB connection

### Step A — `application.yml`

Under `insba.datasources`, add a named block:

```yaml
insba:
  datasources:
    sql2:                                    # <-- new name
      url: jdbc:sqlserver://HOST;instanceName=SQLEXPRESS;databaseName=SOME_DB;encrypt=true;trustServerCertificate=true
      username: sa
      password: secret
      driver-class-name: com.microsoft.sqlserver.jdbc.SQLServerDriver
      dialect: org.hibernate.dialect.SQLServerDialect
      lazy: true                             # build SessionFactory on first use
      max-pool-size: 15
      min-idle: 0
  menu-datasources:
    MyModule: sql2                           # optional: menu key → datasource name
```

Notes:

- `system` is special: Spring TX + eager primary factory (`SystemHibernateConfig`).
- Other DBs are usually `lazy: true` and opened via `withSession`.
- Pool size ≈ concurrent DB work, **not** total logged-in users.

### Step B — (optional) constant in `HibernateFactoryRegistry`

```java
public static final String SQL2 = "sql2";
```

### Step C — use it

```java
List<Map<String, Object>> rows = NativeQuerySupport.executeQuery(
        registry, "sql2", sql);
// or HibernateFactoryRegistry.SQL2 if you added the constant
```

No new Spring `@Bean` is required for a lazy named datasource — the registry builds Hikari + SessionFactory on first `getSessionFactory(name)` / `withSession`.

### Step D — AS400 / other drivers

Set `driver-class-name`, `dialect`, and JDBC URL for that platform. Ensure the JDBC driver JAR is on the classpath (`pom.xml`).

---

## 6. system vs other datasources

| | `system` | `cir` / `sql*` / `as400` |
|--|----------|---------------------------|
| Config | `SystemHibernateConfig` | Lazy via registry |
| Transactions | `@Transactional` + `getCurrentSession()` OK | Prefer `withSession` / open+close |
| Typical use | Auth, core app DB | Module / secondary DBs |

You can still use `withSession(SYSTEM, …)` / `executeQuery` on system for simple native Map queries (as in `/api/test/system`).

---

## 7. Recommended cookbook (copy/paste)

### Service listing rows

```java
@Service
public class ExampleUserQueryService {

    private final HibernateFactoryRegistry registry;

    public ExampleUserQueryService(HibernateFactoryRegistry registry) {
        this.registry = registry;
    }

    public List<Map<String, Object>> listUsers(int limit) {
        int n = Math.max(1, Math.min(limit, 50));
        String sql = """
                select top %d u.enl_id as enlId, u.name as name
                from ia_user_master u
                order by u.enl_id
                """.formatted(n);
        return NativeQuerySupport.executeQuery(
                registry, HibernateFactoryRegistry.SYSTEM, sql);
    }
}
```

### Hit two DBs in one call

```java
List<Map<String, Object>> systemRows = NativeQuerySupport.executeQuery(
        registry, HibernateFactoryRegistry.SYSTEM, sql);
List<Map<String, Object>> cirRows = NativeQuerySupport.executeQuery(
        registry, HibernateFactoryRegistry.CIR, sql);
```

Each call opens and closes its own session — no leak if you use `executeQuery(registry, …)` or `withSession`.

### Controller returning JSON to the browser

Follow `NativeQueryMappingTest`: `@RestController` + `ResponseDataGeneric` + `Gson` (or return a Map/DTO with Spring MVC JSON). Controllers are Spring singletons — inject `HibernateFactoryRegistry`; do **not** make it `static`.

---

## 8. Memory / leak checklist

- [x] Prefer `withSession` or `executeQuery(registry, name, sql)`  
- [x] Traditional path: `openSession` + `finally { session.close(); }`  
- [ ] Never keep `Session` in a field / static  
- [ ] Never close `SessionFactory` in request code  
- [ ] Don’t put unbounded query results in a static cache  

Factories and pools living for the whole app is **expected**, not a leak.

---

## 9. Where to look in the repo

```
src/main/resources/application.yml          # datasource URLs / pools
src/main/java/com/mmm/config/
  InpcDatasourceProperties.java
  SystemHibernateConfig.java
  HibernateFactoryRegistry.java
  AppBootstrapConfig.java
src/main/java/com/mmm/titpl/
  NativeQuerySupport.java                   # executeQuery / listAsMaps
  NativeQueryMappingTest.java               # /api/test demos
src/main/java/com/mmm/cir/CirUserService.java
doc/DEVELOPER_GUIDE.md                      # this file
```

---

## 10. Quick decision guide

| Goal | Use |
|------|-----|
| SELECT without binds → `List<Map>` | `NativeQuerySupport.executeQuery` |
| Parameterized SELECT → `List<Map>` | `NativeQuerySupport.executeQuery(registry, datasource, sql, values...)` |
| Parameterized INSERT/UPDATE/DELETE | `NativeQuerySupport.executeUpdate` |
| Stored procedure | `NativeQuerySupport.executeProcedure` / `executeProcedureWithOutputs` |
| Server-side DataTable paging | `CommonDataTable` |
| Named params / typed scalars | `listAsMaps` + scalars |
| Learn open/close | Traditional `openSession` + `finally` |
| New database | `application.yml` entry + `executeQuery(registry, "name", sql)` |
| Same URL many times | Keep Spring singleton injection (no static registry) |

When unsure, start with **`executeQuery` + named datasource**. Add scalars only when binds/types force you to.

---

## `$host_url` / `$app_url` are global

Defined in `fw-globals.js` (via `MainPage.html`). Feature JS must use `$host_url` / `$app_url` — do not invent per-page host fallbacks.

Portal Change Customer APIs and cookie rules: see `doc/CHANGE_CUSTOMER.md` (`com.mmm.portal_common.ChangeCustomer`). Prefer `NativeQuerySupport.listAsMaps` (production autocomplete) over the test-only embedded-LIKE variants.
