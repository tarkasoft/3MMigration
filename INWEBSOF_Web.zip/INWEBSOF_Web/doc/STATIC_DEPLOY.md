# Static file deploy note (Eclipse WTP)

INPCV2 is published to:
`...\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps\INPCV2\`

Static HTML under `src/main/resources/static` is copied to:
- `WEB-INF/classes/static/...` (Spring Boot classpath)
- and should also exist under webapp root `html_files/...` when that folder is present

**Pitfall:** If `html_files/` exists at the webapp root, Tomcat's default servlet may handle `/html_files/**` and return **404** for files that exist only on the classpath. After adding a new HTML module, sync it to **both**:
1. `target/classes/static/html_files/INPC/` (and `CUST_SERVICE/` when that module changed)
2. `wtpwebapps/INPCV2/html_files/INPC/` (or republish the server from Eclipse)

`sb_tab.html` path: `/INPCV2/html_files/INPC/sb_tab.html`