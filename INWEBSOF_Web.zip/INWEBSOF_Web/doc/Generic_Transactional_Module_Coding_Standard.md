# Generic Transactional Module Coding Standard

## Purpose

For every transactional module, especially modules that INSERT or UPDATE multiple related tables, follow a simple, explicit, consistent, and maintainable transaction pattern.

The same approach should be followed across all modules unless the existing application architecture requires otherwise.

---

## 1. Read and Prepare Input

- Read request/input values into clearly named local variables.
- Validate required fields and business rules before performing database changes.
- Perform required database lookups, calculations, and validations before saving data.
- Keep variable names meaningful and easy to trace.

Avoid unnecessary wrapper objects, records, DTOs, parameter-builder methods, or intermediate `Object[]` structures when they only move existing values from one place to another without adding meaningful business logic.

---

## 2. Use One Clear Database Transaction

For a logical operation involving multiple related tables, use one database transaction.

The preferred flow is:

```text
Begin Transaction
    |
    +-- Main/Header INSERT or UPDATE
    |
    +-- Get generated ID if required
    |
    +-- Detail INSERT/UPDATE
    |
    +-- Related table INSERT/UPDATE
    |
    +-- History/Audit INSERT
    |
    +-- Commit
```

If any database operation fails:

```text
Rollback Transaction
```

No partial data should remain in the database.

---

## 3. Keep SQL Parameters Explicit

When using parameterized SQL with `?`, pass the corresponding variables directly and in the same order as the SQL parameters.

Preferred:

```java
executeUpdate(session, sql,
    customerCode,
    invoiceNo,
    invoiceDate,
    totalAmount,
    remarks
);
```

Avoid unnecessary methods such as:

```java
createParameters()
insertParameters()
buildParameters()
```

when they only create and return an `Object[]` containing existing variables.

The code should make it easy to trace:

```text
Java variable
    |
    v
SQL parameter (?)
    |
    v
Database column
```

The order of parameters must always match the order of the `?` placeholders in the SQL.

---

## 4. Header/Parent -> Generated ID -> Details Pattern

When a transaction contains a parent/header record and child/detail records:

```text
INSERT/UPDATE Header
        |
        v
Get generated Header ID
        |
        v
INSERT/UPDATE Detail records using Header ID
        |
        v
INSERT History/Audit using Header ID
```

Do not use `MAX(id)` to obtain the newly inserted ID.

Use the database-supported identity/generated-key mechanism appropriate for the existing database implementation.

---

## 5. Keep Transaction Boundaries Obvious

The transaction should be easy to identify in the code.

Preferred structure:

```java
Transaction transaction = session.beginTransaction();

try {

    // Main INSERT / UPDATE

    // Get generated ID if required

    // Detail INSERT / UPDATE

    // Related table INSERT / UPDATE

    // History / Audit INSERT

    transaction.commit();

} catch (RuntimeException ex) {

    rollback(transaction);
    throw ex;
}
```

Do not unnecessarily distribute one logical transaction across multiple independent transactions.

---

## 6. Preserve Existing Business Logic

When modifying or creating a module:

- Do not change existing business rules unless explicitly requested.
- Do not change existing calculations unless explicitly requested.
- Do not change existing SQL behavior unnecessarily.
- Preserve existing validation.
- Preserve existing database relationships.
- Preserve existing transaction and rollback behavior.
- Preserve existing error handling.
- Do not remove required database lookups or validations.

The purpose of this standard is to improve clarity and maintainability, not to change functional behavior.

---

## 7. Use Methods for Meaningful Operations

Methods are encouraged when they represent a meaningful operation, for example:

```java
validateRequest()
getInvoiceDetails()
calculateTax()
calculateTotal()
insertHeader()
updateHeader()
insertDetails()
insertHistory()
getGeneratedId()
```

Avoid methods whose only purpose is to move existing variables into another container without adding meaningful logic.

---

## 8. Keep the Code Easy to Trace and Debug

A developer should be able to follow a transaction from beginning to end without jumping through unnecessary abstraction layers.

Preferred:

```text
Input
  |
  v
Local Variables
  |
  v
Validation / Business Calculations
  |
  v
Begin Transaction
  |
  v
Header INSERT / UPDATE
  |
  v
Generated ID
  |
  v
Detail INSERT / UPDATE
  |
  v
History / Audit
  |
  v
Commit
```

Avoid unnecessarily complex flows such as:

```text
Input
  |
  v
Prepare Object
  |
  v
DTO
  |
  v
Wrapper
  |
  v
Parameter Builder
  |
  v
Object Array
  |
  v
SQL
```

unless the additional abstraction is genuinely required by the application architecture.

---

## 9. Multiple Tables

The same transaction pattern applies whether the operation involves two tables or many tables.

For example:

```text
BEGIN TRANSACTION
    |
    +-- Customer/Header
    |
    +-- Item/Detail
    |
    +-- Tax
    |
    +-- Payment
    |
    +-- Inventory
    |
    +-- Document
    |
    +-- History/Audit
    |
COMMIT
```

If any operation fails:

```text
ROLLBACK
```

The entire logical operation should be rolled back.

---

## 10. Do Not Over-Abstract

Before introducing a new:

- `record`
- DTO
- wrapper class
- parameter object
- parameter-builder method
- `Object[]` builder
- additional abstraction layer

first check whether the same functionality can be implemented more clearly using existing local variables and direct method parameters.

Abstraction should be introduced only when it provides a clear and meaningful benefit.

---

## 11. Consistency Across Modules

Follow this coding standard consistently for all modules.

Do not use a simple and explicit transaction pattern in one module and introduce unnecessary abstraction-heavy patterns in another module without a clear reason.

When creating a new module or modifying an existing module, first look at the existing transaction pattern and maintain the same overall approach.

---

## Overall Rule

Prefer:

**Simple -> Explicit -> Traceable -> Maintainable**

The code should make it easy for another developer to answer:

1. Where did this value come from?
2. Which SQL parameter receives this value?
3. Which database column receives this parameter?
4. Which table is being changed?
5. Which generated ID links the related records?
6. What happens if one operation fails?
7. Where is the transaction committed or rolled back?

The implementation should answer these questions directly from the code without requiring unnecessary navigation through multiple abstraction layers.

- Avoid unnecessary wrappers/records/DTOs/parameter builders/Object[] if they only move values.
- Do not create a private static final class, record, DTO, or wrapper merely to carry values between methods or package SQL parameters.
- If a method needs to return many values, prefer straightforward local variables and meaningful existing methods before introducing a new data-holder class.
- A small data class/record is acceptable only when it represents meaningful business data or a meaningful calculated result, not merely SQL parameter packaging.


## Data Holder / Wrapper Rule

Do not introduce classes such as:

```java
private static final class ValidatedRequest
```

just to transport validated values or SQL parameters between methods.

For example, avoid creating a wrapper whose only purpose is to collect values and later pass them into an INSERT or UPDATE.

Prefer:
- Local variables when practical.
- Direct method parameters when the parameter count remains reasonable.
- Meaningful helper methods for validation/calculation.
- Explicit SQL parameters in the same order as the SQL `?` placeholders.

A data holder is appropriate when it represents meaningful business data or a meaningful calculated result. For example, a `CalculatedLine` object can be retained when it represents the calculated result of one transaction line.

**Rule:** Do not replace one unnecessary wrapper with another. Keep the implementation straightforward and traceable.
