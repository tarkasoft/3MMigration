# Customer Issue Resolution (CIR) Migration

## Purpose and scope

This document records the previously completed legacy CIR discovery and
defines a migration plan for the current INPCV2 application. The prior
discovery referenced the legacy asset folder at:

`inpc/src/main/webapp/resources/CIR/`

and the directly connected legacy controllers under
`inpc/src/main/java/com/mmm/cir/`. CIR also calls shared controllers outside
that package; those dependencies are listed below. This is a migration
discovery document, not evidence that the CIR business workflow has already
been migrated.

The legacy CIR folder contains:

- HTML: `cir_home.html`, `cir_new_request.html`, `cir_requests.html`,
  `cir_my_approval_popup.html`
- JavaScript: `cir_new_request.js`, `cir_requests_view.js`
- CSS: Bootstrap 3 copies, `style-metronic.css`, `star-rating.css`
- Images: loading indicators
- `cir_new_request.js.bak` and a bundled Bootbox copy

The active page loads request and review fragments dynamically. Bootstrap,
jQuery, jQuery UI autocomplete, datepicker, Bootbox, and other portal globals
are implicit dependencies. The new implementation should use the libraries
and shared components already loaded by INPCV2 rather than copying the legacy
vendor assets.

## Current INPCV2 position

As of 3 Oct 2026 the customer CIR path includes Dashboard, New Request, My
Requests, save, and document upload/download (`SaveCir`, `CirDocUpload`,
`CirFileStore`, `CirDashboard` / `CirDashboardSql`, `CirRequests` /
`CirRequestsSql`). All share file I/O uses encrypted SMB 3.1.1. The smoke
classes below stay untouched. SQL timestamps use
`UserSessionSupport.sessionDate()`. Continuation notes are in
[CURSOR_PROJECT_GUIDE.md](./CURSOR_PROJECT_GUIDE.md) section 17.

**Multi-tab DOM (2026-10-04):** shell root is `#m_cir_home`. Client get/set uses
`Cir._$home()` / `Cir._$("#…")` (and `cir_dashboard.js` via `Cir._$`) so duplicate
ids across portal tabs do not collide. Detail modal lives under `#m_cir_requests`
(loaded into the home panel). Same rule as [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md).

INPCV2 has a named `cir` datasource in `HibernateFactoryRegistry` and the
following CIR-related smoke classes, which are not the production module:

- `src/main/java/com/mmm/cir/CirHybernetUtil.java`
- `src/main/java/com/mmm/cir/CirSmokeController.java`
- `src/main/java/com/mmm/cir/CirUserService.java`

Those three files are still datasource/smoke-test scaffolding. Keep them
untouched. Approval routing mutations and email are not finished. Retire or
access-restrict the smoke endpoints separately before production release.

The legacy application obtains its primary CIR SQL Server session factory
from `hibernate_cir.cfg.xml` and has a separate AS/400 factory/configuration
for invoice operations. INPCV2's named `cir` datasource is configured for
`PRODSQL438A\SQL438A`, database `dINECIR`; credentials are intentionally not
recorded here. Connectivity and catalog read access were verified from this
workspace on 2026-09-30. Confirm application-user permissions for the required
read/write operations before production use. The `as400` datasource remains a
separate integration for invoice operations.

The legacy CIR Java and UI package is available in the adjacent checkout at
`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\...`. The CIR source and
request-list SQL described below were inspected there. The live database
metadata in this document was queried directly from `dINECIR`.

## Confirmed implementation decisions

- Add new CIR files only; do not edit or repurpose the existing dummy-check
  files listed above.
- Keep Java classes directly under `src/main/java/com/mmm/cir/`, following
  the flat Rebate package pattern. Do not add `controller`, `dto`, or `dao`
  subpackages.
- Keep the UI to one or two HTML files under
  `src/main/resources/static/html_files/CIR/` and one JavaScript file,
  `src/main/resources/static/custom_js/CIR/cir.js`.
- Follow the Rebate Java customer/query pattern. Resolve the selected
  customer through `UserSessionSupport.resolveProcedureCustomerContext(...)`
  and the authenticated portal session. A requested customer override is
  effective only when the session permits it and supplies both customer and
  login values; never trust browser-supplied customer identifiers alone.
- Build **My Requests** on the shared `Common.DataTable.init` /
  `Common.DataTable.setData` API used by Rebate, rather than introducing a
  separate table implementation. The current shared API name is
  `Common.DataTable.init` (there is no `Common.InitTable` helper in the
  inspected static code).
- Handle **all** CIR document upload/download server-side over encrypted
  **SMB 3.1.1** (`CirFileStore` + SMBJ): required documents
  (`POST/GET .../documents/...`) and additional attachments
  (`POST/GET .../attachments/...`). Do not use JCIFS, SMB1/SMB2-only dialects,
  or browser-visible share paths. Resolve CIR's own approved share
  (CIRATTCH via `CMW010S`); do not assume the Rebate folder/share is CIR's
  storage location.
- The first implementation increment is the read-only customer-context and
  **My Requests** flow against the CIR datasource. It is implemented in
  `CirRequests` / `CirRequestsSql` and the `CIR/cir.js` +
  `CIR/cir_home.html` assets. It uses the verified `dINECIR` schema and legacy
  list behavior, but replaces the client-trusted customer parameter with
  server-resolved customer context and a bound SQL parameter.
- The CIR home shell uses a rounded white surface in light mode. Its shorter
  title banner and supporting text are vertically centered on one header row,
  with the title, tabs, and request panel aligned to shared horizontal edges.
  Form-level error alerts have a 2px horizontal inset. The shell retains the
  existing transparent/dark-theme treatment when dark mode is active.
- The New Request form's Customer Details, Invoice Details, and Complaint
  Details cards use matching section icons and a pale-blue header strip in
  light mode, with coordinated slate-blue headers in dark mode.
- The Load Invoice and Submit actions include invoice-load and send icons.
  Submit saves the request in one database transaction and shows the result.
  Attachment rows load from `cc_document_type` for the selected complaint
  type and cause (legacy `GetDocumentData`), including mandatory markers
  where `is_mandatory = 'Document'`. Documents are uploaded after save, one
  file per request, with each file and the selected total limited to 5 MB.
  Upload stores `ref_doc_code` as the document type id. Required and additional
  document upload/download are handled by `CirDocUpload` + `CirFileStore`.
  Files go to the CIRATTCH share over encrypted **SMB 3.1.1** only (default
  `inpc.cir.file-transport=smb`). Setting `file-transport` to `mount` and
  `inpc.cir.mount-root` to a folder writes the same relative path on a
  mounted drive instead (dev fallback only; production document I/O stays on
  SMB3).
- CIR loading states use the shared `showLoader(message, targetId)` /
  `hideLoader(targetId)` API from `js/inpc_loader.js`, following the
  Customer Payment module. This applies to New Request setup/lookups, My
  Requests, invoice-line loading, and request-detail loading. Invoice
  autocomplete retains its existing compact inline spinner; local CIR-only
  page overlays have been removed.
- The My Requests detail modal has a lightly tinted header to distinguish it
  from the page navigation, and its title is labeled **CIR Request** with the
  request number.
- The My Requests header includes a refresh icon. Clicking it reloads the
  current customer's request list through the existing `/requests` API, shows
  the shared CIR data loader while loading, and disables/animates the icon
  until the request completes.
- **New Request: Load Invoice (implemented, simplified).**
  Load Invoice checks the same required values as legacy `GetCustComplaintInvoice`
  before the request: customer, invoice number, group, division, customer
  reason and cause, credit/debit, material return, CIR type, and invoice date.
  The first missing value is shown in an alert and the request is not sent.
  `GET /api/customer/cir/new-request/invoice-items`
  (`CirRequests.invoiceItems`) loads billed invoice lines for the selected
  customer/invoice so the user can enter return quantities on the
  **New Request** form. It mirrors legacy's `CIRRequest.GetCustComplaintInvoice`
  flow:
  - `CirRequestsSql.missingLotDetails` — bound-parameter port of legacy
    `CheckLotDetailsCount`. If any lot-controlled SKU on the invoice is
    missing a lot record, the endpoint blocks (throws with a formatted SKU
    list), matching legacy's blocking behavior.
  - `CirRequestsSql.invoiceLineItems` — bound-parameter port of legacy
    `GetInvoicedetailsForNormalMode` only. Returns billed qty/rate/value, tax
    split (sgst/cgst/igst + rates), lot_controlled flag, and nine-month tax
    flag, with already-claimed quantities excluded from `balance_qty` unless
    the existing request is Rejected or Rectification Entry Passed. The
    previous-claims subquery groups by invoice/customer/item/line; it does
    not read `amount_type` from `cc_customer_complaints_items_group` because
    that column is not present in the verified item-group schema. This avoids
    SQL Server error 207 ("Invalid column name 'amount_type'") during invoice
    loading.
  - `CirRequestsSql.invoiceFreightDetails` / `distinctTaxRates` — supporting
    lookups.
  - **Legacy complaint selection parity:** only **Customer Reason** is shown
    as a lookup. Its `category` and `sub_categoty` values select the hidden
    complaint type and cause records, as in legacy `CallReasonAndSubCodes()`;
    cause metadata continues to drive stock, credit/debit, material-return,
    amount-type, and tax behavior.
  - **CIR Type:** Normal / Flat Amount radios follow the selected cause's
    `amount_type` (or `c_amount_type_for_non_mat_return` when Material Return
    is No). The allowed option remains clickable even when the cause permits
    only one type; when both are allowed, Normal is the default and the user
    may select Flat. Selecting Flat triggers the same invoice-table refresh
    behavior as the legacy radio: Normal-only inputs are reset/disabled, Flat
    Amount becomes editable for selected lines, and its column is shown.
    Returning to Normal restores the invoice tax rates and Normal-mode inputs.
  - Complaint Details follow the legacy order: Customer Reason, Stock
    Category when the reason category is `STOCK`, Credit/Debit, Material
    Return, CIR Type, Sent Samples, and Sent Docket No. Sent Samples is shown
    only when the complaint type code is `PRDQUA`. Choosing Yes shows Sent
    Docket No; any other reason hides both fields and clears them.
  - **Invoice columns:** the table follows the legacy ordering: item details,
    billed quantity/balance/price/value/tax components/tax/total, then actual
    return quantity, GRN quantity when applicable, Difference Price, Actual
    Value, applicable tax components, Tax Amount, optional Flat Amount, and
    Claim Amount. For the current non-adjustment request, GRN is hidden.
    Tax component columns are shown for the invoice's tax type (CGST/SGST for
    SCGST, IGST for IGST); Flat Amount is dynamically added/removed and the
    grouped headings/claim total row adjust to the visible column count. The
    SQL supplies explicit billed tax rates keyed to the invoice tax names;
    actual return tax percentages default from those rates and display with
    percent signs.
  - `CIR/cir.js` (`_bindLoadInvoiceButton`, `_loadInvoiceLines`,
    `_renderInvoiceLines`, `_toggleInvoiceLine`, `_validateInvoiceLineInput`,
    `_recalculateLine`) renders the returned lines into the invoice-line table.
    Each line has a selection checkbox, and the header checkbox selects every
    claimable line. For an invoice-cancellation reason, select-all locks the
    row checkboxes the way the legacy screen does. Unchecked lines have
    disabled entry fields and no calculated values. Selecting a line enables
    Actual Return Qty and Difference Price. Actual tax percent fields stay
    disabled unless the cause edit type is Tax. Flat mode
    disables those Normal-mode inputs and enables Flat Amount. Selecting a
    line in Normal mode copies balance quantity into Actual Return Qty and the
    billed price into Difference Price, then calculates Actual Value, tax, and
    Claim Amount. Flat mode leaves quantity and price at zero.
    A line with no remaining balance shows **Claimed** and has no selection checkbox.
    The grid keeps both header rows visible while the lines scroll. Number
    columns and entry fields are right-aligned, and the three group titles are
    centered.
    Quantity cannot exceed balance quantity;
    Difference Price cannot exceed billed price. In Normal mode,
    `Actual Value = actual_qty * difference_price` and
    `Tax Amount = Actual Value * (CGST% + SGST% + IGST%) / 100`, suppressed by
    the selected cause's tax flag for the chosen material-return radio.
    Flat-mode Claim Amount uses the entered Flat Amount. The selected-line
    total is reflected in both the table's Claim Total row and the form total.
  - **Explicitly out of scope / simplified — needs sign-off before further
    work depends on it (see risk item 6 below):**
    - **Edit-mode invoice loading is not implemented.** Legacy's
      `GetInvoicedetailsForEditMode` / `GetHeaderDetailsEdit` were not
      ported; INPCV2 has no "edit an existing CIR request" flow yet.
    - **Freight proration is not implemented.** Legacy's own
      `GetFrieghtDetails` SQL already returns hardcoded `0` placeholders for
      the real freight math — the actual proration logic lives entirely in
      legacy's client-side `cir_new_request.js` (~4468 lines) and was judged
      too large to port at this stage. `invoiceFreightDetails` exposes only
      `div_code`, `description`, `perc` as informational reference data;
      freight is **not** added into the Claim Amount total.
    - The tax-suppression rule above is a simplified reading of the cause
      metadata flags; legacy has additional branching (amount type, line
      calc type, 9-month tax exception) not yet replicated.
    - **Recommendation:** obtain golden legacy output for a representative
      set of invoices/causes (normal, flat-amount, tax-exempt,
      9-month-exception, lot-controlled) and compare against this
      implementation's Claim Amount before enabling request submission.

## Legacy user flows

### 1. New request

`cir_home.html` presents **New Request** and **Requests** tabs. New Request
loads the form and its JavaScript, then loads customer, reason, document,
invoice, and approval data.

The request form contains these functional areas:

1. **Request category and customer**
   - CIR main type: Invoice Cancellation, Undelivered Shipment, or Others.
   - Customer, customer type, contact name, phone, and email.
   - Requester/user selection appears in role-specific or legacy paths.
2. **Invoice context**
   - Invoice number and invoice date.
   - Group, division, warehouse, and customer region.
   - Invoice lookup and invoice-copy download.
3. **Complaint classification**
   - Customer reason, reason code, cause/adjustment code, SAP category,
     stock category, and usage example.
   - Some fields appear conditionally based on the reason, role, and request
     type; classification drives document requirements and approval routing.
4. **Request decisions**
   - Credit or Debit.
   - Material Return Yes/No.
   - Normal or Flat Amount for applicable return flows.
   - Sample sent and sample docket number for product-quality cases.
   - Rebook LR number/date and CFR number for applicable scenarios.
   - Out-of-policy flag and justification where required.
5. **Line items and calculations**
   - Invoice/billed quantity, unit price/value, tax rates/amounts, and invoice
     total.
   - Actual return/refund quantity and values, warehouse-entered quantities,
     claim amount, tax, and optional flat amount.
   - Item checkboxes select the claimed lines. Client JavaScript recalculates
     item values, tax, freight, and total CIR claim amount.
6. **Freight**
   - Freight type/description, GST applicability, base value, freight/tax
     percentages, tax amount, flat amount, and calculated freight value.
7. **Documents, approvers, and remarks**
   - Reason/category-driven required documents; total required document size
     is limited by the UI to 5 MB.
   - Approval matrix preview based on organizational context and claim
     amount.
   - Required complaint description (maximum 500 characters) and optional
     file uploads.

The request JavaScript serializes `header_obj`, `line_items`, `approver_obj`,
and `frieght_obj` into a `full_obj` multipart field and appends uploaded
documents. Submission is sent to `SaveNewRequestData`. The UI performs
required-field, item-selection, already-claimed, and attachment-size checks,
but all such checks must be repeated and trusted only on the server after
migration.

### 2. Requests list and detail review

The Requests tab initially shows customer requests in a DataTable configured
for 50 rows per page. The visible columns are View, Request ID, Request Date,
Invoice No, Invoice Date, Reason, Total Amount, and Status. A row opens a
large detail modal.

The detail response is assembled from separate header, invoice-line, lot,
approver, history, document, clarification, freight, transport, and customer
queries. The modal provides these sections (some are conditionally hidden):

- Request/customer/invoice summary, current stage, pending approver, and
  total amount (also written in words).
- Invoice line items with billed and customer actual return/refund
  quantities, prices, values, taxes, and claim amounts.
- Lot details and warehouse-approved quantities.
- Required documents and additional uploaded documents.
- Approval matrix/history, clarification questions and answers, and credit
  note details.
- Transport/reverse-pickup information when applicable.
- Invoice copy and document downloads.
- Edit/resubmit action when the request has been reassigned to the customer.

The list status is derived from request fields: customer reassignment is
presented as Rework, rejected and closed UI states are shown explicitly, and
other rows appear as In Progress. The detail response also uses the approval
stage, pending role/user, rework remarks, credit note, and workflow history.
The migrated status model must be established from the authoritative
database/workflow rules; do not rely on the legacy display-only CASE alone.

### 3. Approval, care-cell, and clarification paths

The request stores an approval matrix with approver roles, sequence,
assignment, status, remarks, and modification dates. The legacy UI can
reassign a request to a customer and the customer can edit/resubmit it.
Client JavaScript also contains care-cell quantity update, approve-quantity,
reject, and send-back-to-warehouse flows.

The inspected `com.mmm.cir` Java package exposes matrix construction and
clarification APIs, but the care-cell URLs referenced by `cir_new_request.js`
(`CIRCareCellQtyAdjustment/*`) did not resolve to a matching controller in
the inspected legacy CIR package. Their actual controller ownership and
whether those functions are still live must be confirmed before deciding
whether they belong in this migration.

Clarification operations create a question against a CIR request and accept
an answer against a question record. The popup displays raised/answered
dates, actors, question, and answer. Clarification actions and permissions
must be enforced using the authenticated user and current workflow stage,
not client-supplied IDs or user codes.

## Legacy endpoint inventory

The legacy annotations commonly use generic `@RequestMapping` without an
explicit HTTP method. This inventory records route names; preserve the
business operations, not the inconsistent verb contracts.

| Controller / route | Purpose |
| --- | --- |
| `cir_request/GetCIROnloaddata` | Load customer, reason/cause, stock category, closed days, requester warehouse, and optional edit-mode request data. |
| `cir_request/GetCustomerAutoComplete` | Search customer/master data. |
| `cir_request/GetInvoiceAutoComplete` | Search invoices for customer and warehouse context. |
| `cir_request/GetCustComplaintInvoice` | Load invoice lines, prior claims, tax and item data for the request form. |
| `cir_request/GetDocumentData` | Resolve required documents from reason/cause and edit context. |
| `CIRCommon/GetFullApprovalMatrix` | Build the approval chain from group, division, warehouse, reason, amount, out-of-policy status, stock category, and region. |
| `CIRCommon/GetUserAutoComplete`, `GetAddrForUser` | User lookup and user address lookup. |
| `CIRCommon/GetItemAutoComplete` | Item lookup. |
| `CIRCommon/SendForClarification`, `SendAnsForClarification` | Create clarification question and answer records. |
| `save_new_cir/SaveNewRequestData` | Multipart request create/edit/rework submission, line items, approval routing, documents, and notifications. |
| `CIRMyApproval/GetCIRRequests` | Load customer request list/status. |
| `CIRMyApproval/GetApprovalDetailsForPopup` | Load request details and related invoice, lot, approval, history, document, clarification, freight, transport, and customer data. |
| `cir_add_attch/SaveUpladedDocuments` | Upload additional request attachments. |
| `cir_add_attch/GetAdditionalData` | List additional attachments and metadata. |
| `cir_add_attch/DeleteProgramDocDetailsFromScreen` | Delete an additional-attachment record. |
| `titpl/cir_doc_upload/DownloadCIRFilesFromServer` | Download a CIR attachment from the configured file share. |
| `DownloadCustomerInvoiceFromAS400/DownloadCIRInvoiceCopy` | Retrieve the invoice copy from AS/400. |
| `CIRCareCellQtyAdjustment/*` (referenced by JavaScript) | Quantity adjustment/approval/rejection/send-back actions; controller ownership is unresolved in the inspected source. |

The legacy popup also calls common portal utilities and dynamically loads
HTML fragments. Capture actual network requests in a representative runtime
before decommissioning it; the route inventory above was checked against the
legacy controller sources and their matching JavaScript calls.

## Data and integrations

### Verified dINECIR schema

The following is a metadata-only snapshot collected from SQL Server catalog
views (`sys.tables`, `sys.columns`, `sys.types`, `sys.indexes`, and foreign-key
catalogs); no application rows were queried or changed. The database contains
70 non-system tables whose names start with `cc_` or `cir_`. The complete
name inventory is:

```text
cc_accounting_division, cc_accounting_division_cust_type_group,
cc_accounting_division_region_group, cc_accounting_group,
cc_accounting_group_stock_category_group, cc_approval_matrix,
cc_approval_matrix_approvers_group, cc_approval_matrix_approvers_group_bkp,
cc_cause_codes, cc_code_generator, cc_complaint_category,
cc_complaint_category_group_user_group, cc_complaint_category_wh_user_group,
cc_complaint_item_lot_group, cc_complaint_log, cc_complaint_report_summary,
cc_complaint_type, cc_customer_complaints, cc_customer_complaints_add_atch,
cc_customer_complaints_approval_matrix, cc_customer_complaints_approve_history,
cc_customer_complaints_as400, cc_customer_complaints_clarifications,
cc_customer_complaints_dc_eway_atch, cc_customer_complaints_deleted,
cc_customer_complaints_doc_group, cc_customer_complaints_frieght_group,
cc_customer_complaints_fyi_group, cc_customer_complaints_history,
cc_customer_complaints_items_group, cc_customer_complaints_items_group_t,
cc_customer_complaints_t, cc_customer_reason, cc_document_type,
cc_ecom_customers, cc_employee_master, cc_employee_master_division_group,
cc_employee_master_warehouse_group, cc_failure_codes, cc_frieght_div_codes,
cc_group_email_ids, cc_inv_approvers, cc_inv_can_unique_inv_no,
cc_inv_cancel_history, cc_inv_complaint_report_summary, cc_mail_history,
cc_rdm_reversal_nsm, cc_region_master, cc_rejection_reason_master,
cc_reminder_email_log, cc_setup, cc_stage_master,
cc_stock_reversal_category, cc_tax_rates, cc_warehouse_master, cc_weekly_mail,
cir_complaint_item_lot_group, cir_deligation, cir_excel_requests,
cir_infopoint_data, cir_lr_details, cir_mail_history, cir_oem_excel_data,
cir_oem_excel_data_temp, cir_oem_excel_documents,
cir_post_business_approval_flow, cir_proc_run_history, cir_provision_table,
cir_setup, cir_verifier_addr_master
```

There are no declared foreign-key constraints involving the inspected
`cc_customer_complaints*` and complaint-lot tables. Joins such as
`ref_s_ref_data_code` to a header `internal_code` are therefore application
conventions, not database-enforced relationships; verify each join and
ownership predicate against legacy SQL. The main header has 158 current
columns, `internal_code` is its identity primary key, and `ticket_number` has
a unique index. The header's column ordinal 128 is absent in the current
catalog, so use the live column names rather than assuming a contiguous
ordinal sequence.

The workflow table column names observed in the live catalog are recorded
below. These lists are complete for the named tables; names preserve legacy
spelling, including `frieght`, `fright`, `cretaed_enl_id`, and
`trans_cliam_number`.

| Table | Columns |
| --- | --- |
| `cc_customer_complaints` (158) | `internal_code`, `invoice_no`, `invoice_date`, `created_by`, `created_date`, `modified_by`, `modified_date`, `failure_code`, `cause_code`, `complaint_type`, `category`, `ticket_number`, `div_code`, `wh_code`, `assign_to`, `stage`, `cust_remarks`, `frieght_perc`, `claim_amt`, `total_amt`, `frieght_amount`, `reassign_to_cust`, `date`, `customer`, `claiming_fri_amt`, `freight_tot_amount`, `ship_to_code`, `closed_date`, `credit_note_no`, `credit_note_date`, `ecare_no`, `ecare_date`, `comp_age`, `approver_id`, `approved_date`, `is_pushed_to_ecare`, `customer_email`, `validator_id`, `validated_date`, `complaint_status`, `complaint_closed_date`, `group_code`, `reassign_count`, `sales_rep`, `recommendation_action`, `lr_number`, `lr_date`, `lr_name`, `cust_name`, `cust_phNo`, `sales_rep_name`, `cust_type`, `fright_type`, `fright_tax_perc`, `fright_perc`, `h_material_return`, `h_return_type`, `cn_mail_sent`, `cn_mail_sent_date`, `cc_f_tax1_perc`, `cc_f_tax2_perc`, `cc_f_tax1_name`, `cc_f_tax2_name`, `validator2_remarks`, `validator1_remarks`, `reassign_to_cust_date`, `reassign_mail_sent_quartz`, `type`, `inv_wh_approver`, `inv_appr_status`, `inv_appr_remarks`, `inv_approved_by`, `inv_credit_remarks`, `is_manually_updated`, `cretaed_enl_id`, `inv_appr_date`, `first_location`, `inv_ui_status`, `inv_order_no`, `request_type`, `rejected_date`, `ui_status`, `pending_with`, `approval_sequence`, `pending_with_role`, `cc_inv_cust_reason`, `out_of_policy`, `reason_category_code`, `credit_debit`, `material_return`, `requester`, `created_enl_id`, `oop_justification`, `approver_role_sequence`, `clarification_pending_with`, `amount_type`, `tax_type`, `docket_date`, `docket_no`, `original_total_amt`, `grn_no`, `grn_date`, `company`, `as400_error`, `rework_sent_by`, `rework_sent_date`, `rejected_by`, `rejected_role`, `rework_sent_by_role`, `carecell_wh_qty_approved`, `qty_price_edit_type`, `rebook_lr_no`, `rebook_lr_date`, `request_src`, `clrif_submitted_date`, `resubmitted_date`, `transporter_name`, `pickup_date`, `slip_number`, `sent_sample`, `trans_cliam_number`, `sample_docket_no`, `cir_main_type`, `category_code`, `customer_contact_name`, `sent_credit_mail`, `sent_credit_date`, `rework_remarks`, `material_laying_at`, `ship_to_state`, `ship_to_pin`, `rec_remarks`, `rec_credit_debit_no`, `rec_credit_debit_date`, `rectified_by`, `rectified_date`, `inv_sales_type`, `w_wo_invoice`, `as400_order_type`, `cir_entity`, `wh_docket_status`, `cfr_number`, `debit_no`, `debit_date`, `einstein_category`, `fyi`, `update_material_return_to_no`, `tax_type_for_return_type`, `rma_msg`, `disposal_file_name`, `disposal_file_path`, `dm_file_path`, `dm_file_name`, `disposal_file_remarks`, `dm_file_remarks`, `material_disposed_at`, `grn_status`, `aoem_ref_Code` |
| `cc_customer_complaints_items_group` (58) | `internal_code`, `ref_s_ref_data_code`, `row_sequence`, `item_code`, `item_desc`, `return_material`, `return_type`, `bill_qty`, `bill_rate`, `bill_val`, `tax_rate1`, `tax_rate2`, `tax_rate3`, `tax1_val`, `tax2_val`, `tax3_val`, `bill_tax_val`, `item_val`, `act_qty`, `act_rate`, `act_val`, `act_tax_val`, `act_item_val`, `claim_amt`, `remarks`, `created_by`, `created_date`, `modified_by`, `modified_date`, `item_frieght_amt`, `lot_no`, `line_no`, `tax_name1`, `tax_name2`, `tax_name3`, `is_lot_available`, `item_lot_location`, `order_no`, `order_type`, `balance_qty`, `line_level_status`, `act_tax_rate1`, `act_tax_rate2`, `act_tax_rate3`, `act_flat_amt`, `wh_entered_qty`, `original_qty`, `original_claim_amt`, `as400_push`, `mismatch_type`, `alternative_item`, `alternative_lot`, `nine_mth_tax_applicable`, `wh_excess_qty`, `grn_no`, `grn_date`, `mto_mts`, `sku_hsn` |
| `cc_customer_complaints_frieght_group` (18) | `internal_code`, `ref_s_ref_data_code`, `row_sequence`, `type`, `frieght_desc`, `gst_applicable`, `item_base_value`, `frieght_perc`, `item_tax_perx`, `total_frieght_amount`, `frieght_flat_amount`, `frieght_div`, `created_by`, `created_date`, `modified_by`, `modified_date`, `item_tax_amount`, `f_line_no` |
| `cc_customer_complaints_doc_group` (14) | `internal_code`, `ref_s_ref_data_code`, `row_sequence`, `ref_doc_code`, `u_doc_name`, `u_doc_path`, `created_by`, `created_date`, `modified_by`, `modified_date`, `re_upload_required`, `mmm_u_doc_name`, `mmm_u_doc_path`, `cust_doc_remarks` |
| `cc_customer_complaints_approval_matrix` (14) | `internal_code`, `ref_s_ref_data_code`, `approval_type`, `approver_role`, `approver`, `sequence`, `a_ui_status`, `created_by`, `modified_by`, `created_date`, `modified_date`, `updated_by`, `approval_remarks`, `approval_status` |
| `cc_customer_complaints_approve_history` (62) | `internal_code`, `ref_s_ref_data_code`, `approver1_enl`, `approver1_status`, `approver1_remarks`, `approver1_date`, `approver2_enl`, `approver2_status`, `approver2_remarks`, `approver2_date`, `approver3_enl`, `approver3_status`, `approver3_remarks`, `approver3_date`, `approver4_enl`, `approver4_status`, `approver4_remarks`, `approver4_date`, `approver5_enl`, `approver5_status`, `approver5_remarks`, `approver5_date`, `approver6_enl`, `approver6_status`, `approver6_remarks`, `approver6_date`, `approver15_enl`, `approver15_status`, `approver15_remarks`, `approver15_date`, `approver16_enl`, `approver16_status`, `approver16_remarks`, `approver16_date`, `approver17_enl`, `approver17_status`, `approver17_remarks`, `approver17_date`, `approver18_enl`, `approver18_status`, `approver18_remarks`, `approver18_date`, `approver19_enl`, `approver19_status`, `approver19_remarks`, `approver19_date`, `approver20_enl`, `approver20_status`, `approver20_remarks`, `approver20_date`, `approver1_5_enl`, `approver1_5_status`, `approver1_5_remarks`, `approver1_5_date`, `approver2_5_enl`, `approver2_5_status`, `approver2_5_remarks`, `approver2_5_date`, `approver7_enl`, `approver7_status`, `approver7_remarks`, `approver7_date` |
| `cc_customer_complaints_history` (12) | `internal_code`, `ref_s_ref_data_code`, `updated_by`, `approver_status`, `approver_remarks`, `created_by`, `created_date`, `modified_by`, `modified_date`, `updated_date`, `approver_type`, `approver_role_status` |
| `cc_customer_complaints_clarifications` (11) | `internal_code`, `ref_s_ref_data_code`, `row_sequence`, `user_id`, `question`, `clarification_raised_by`, `type`, `request_date`, `answered_by`, `answered_date`, `answer` |
| `cc_customer_complaints_add_atch` (8) | `internal_code`, `ref_s_ref_data_code`, `file_name`, `file_path`, `remarks`, `created_by_enl_id`, `created_date`, `attached_file` |
| `cc_customer_complaints_fyi_group` (4) | `internal_code`, `ref_s_ref_data_code`, `enl_id`, `name` |
| `cc_customer_complaints_as400` (22) | `internal_code`, `ticket_no`, `customer`, `inv_prefix`, `inv_no`, `invoice_date`, `item_line_no`, `rejected_qty`, `item_code`, `lot_no`, `rejected_lot_qty`, `cause_code`, `lot_location`, `total_line_cnt`, `credit_debit`, `act_flat_amt`, `created_date`, `as400_status`, `proc_call`, `user_4`, `user_5`, `proc_status` |
| `cc_complaint_item_lot_group` (10) | `internal_code`, `header_int_code`, `item_int_code`, `lot_no`, `lot_wh_code`, `lot_location`, `lot_qty`, `lot_act_aty`, `sel_location`, `balance_qty` |
| `cir_complaint_item_lot_group` (10) | `internal_code`, `header_int_code`, `item_int_code`, `line_no`, `lot_no`, `lot_wh_code`, `lot_location`, `lot_qty`, `lot_act_aty`, `sel_location` |

Important catalog types include `cc_customer_complaints.internal_code int NOT
NULL`, `ticket_number varchar(50) NULL`, `customer varchar(50) NULL`,
`created_enl_id varchar(10) NULL`, `requester varchar(50) NULL`,
`invoice_no varchar(50) NULL`, `invoice_date date NULL`, `created_date
datetime NULL`, `ui_status varchar(50) NULL`, `complaint_status varchar(100)
NULL`, `claim_amt decimal(15,2) NULL`, and `total_amt decimal(15,2) NULL`.
These names suggest candidate list fields, but customer ownership and status
display rules must be taken from legacy query semantics, not guessed from
column names.

### CIR transactional tables

The legacy flow and verified database schema identify these principal tables:

- `cc_customer_complaints` — request header, customer/invoice context,
  request type, amount, state, assignments, status, and request metadata.
- `cc_customer_complaints_items_group` — selected invoice lines, billed and
  actual return/refund values, quantities, tax, and claim amounts.
- `cc_customer_complaints_frieght_group` — freight/tax calculations.
- `cc_customer_complaints_doc_group` — required document metadata/files.
- `cc_customer_complaints_approval_matrix` — approval routing and state.
- `cc_customer_complaints_approve_history` and
  `cc_customer_complaints_history` — approval/audit history.
- `cc_customer_complaints_clarifications` — questions and answers.
- `cc_customer_complaints_add_atch` — additional attachments and remarks.
- `cc_customer_complaints_as400` — AS/400 request/item push and processing
  status.
- `cc_customer_complaints_fyi_group` — FYI recipients.
- `cc_customer_complaints_dc_eway_atch` — delivery-challan/e-way attachments.
- `cc_complaint_item_lot_group` and `cir_complaint_item_lot_group` — both
  exist; each stores lot-level/warehouse data with slightly different
  columns. Establish which one each legacy path uses before querying.
- `cc_customer_complaints_deleted`, `cc_customer_complaints_t`, and
  `cc_customer_complaints_items_group_t` — archive/temporary-shaped tables;
  do not treat these as the active request tables without confirming legacy
  usage.

The database also has supporting complaint/audit/report tables including
`cc_complaint_log`, `cc_complaint_report_summary`,
`cc_inv_complaint_report_summary`, `cc_mail_history`, `cir_mail_history`,
`cc_reminder_email_log`, `cc_weekly_mail`, `cir_lr_details`,
`cir_excel_requests`, `cir_infopoint_data`, `cir_oem_excel_data`,
`cir_oem_excel_data_temp`, `cir_oem_excel_documents`,
`cir_proc_run_history`, and `cir_provision_table`. Verify each table's
purpose and retention before use.

### Configuration and lookup tables

Observed lookup/configuration dependencies include:

`cc_customer_reason`, `cc_complaint_type`, `cc_complaint_category`,
`cc_document_type`, `cc_stock_reversal_category`, `cc_tax_rates`,
`cc_approval_matrix`, `cc_approval_matrix_approvers_group`,
`cir_post_business_approval_flow`, `cir_setup`, `cir_verifier_addr_master`,
`cir_deligation`, `ia_user_master`, `ia_user_master_roles_group`,
`ia_roles`, `cc_accounting_division`, `cc_accounting_group`,
`cc_accounting_division_cust_type_group`,
`cc_accounting_division_region_group`, `cc_warehouse_master`,
`inv_warehouse_approval_matrix`,
`inv_warehouse_approval_matrix_warehouse_requester_group`,
`cc_rdm_reversal_nsm`, and `cc_region_master`.

The live schema confirms `cc_customer_reason`, `cc_cause_codes`,
`cc_complaint_type`, `cc_complaint_category`, `cc_document_type`,
`cc_stock_reversal_category`, `cc_tax_rates`, `cc_approval_matrix`,
`cc_approval_matrix_approvers_group`, `cc_accounting_division`,
`cc_accounting_division_cust_type_group`,
`cc_accounting_division_region_group`, `cc_accounting_group`,
`cc_accounting_group_stock_category_group`, `cc_employee_master`,
`cc_employee_master_division_group`,
`cc_employee_master_warehouse_group`, `cc_warehouse_master`,
`cc_region_master`, `cc_stage_master`, `cir_post_business_approval_flow`,
`cir_setup`, `cir_verifier_addr_master`, and `cir_deligation`. Their names
and existence are verified; lookup values and business semantics were not
read as part of the metadata-only check.

Selected live lookup/configuration column signatures are:

| Table | Selected catalog columns (`name type [nullability]`) |
| --- | --- |
| `cc_customer_reason` | `internal_code int NOT NULL`, `code varchar(50) NULL`, `name varchar(500) NULL`, `active varchar(50) NULL`, `sap_sub_code int NULL`, `sequence int NULL`, `sap_main_code int NULL` |
| `cc_complaint_type` | `internal_code int NOT NULL`, `type varchar(50) NULL`, `ticket_type varchar(20) NULL`, `active varchar(50) NULL`, `role_type varchar(50) NULL`, `sequence int NULL`, `code varchar(20) NULL`, `data_for varchar(10) NULL`, `oop_days int NULL`, `inpc_oop_days int NULL` |
| `cc_complaint_category` | `internal_code int NOT NULL`, `category varchar(100) NULL`, `type int NULL`, `reason_code varchar(50) NULL`, `ln_cause_code varchar(50) NULL`, `active varchar(50) NULL`, `sap_category varchar(100) NULL`, `app_type varchar(50) NULL`, `c_amount_type varchar(10) NULL`, `return_material varchar(10) NULL`, `c_credit_debit varchar(10) NULL`, `usage_example varchar(700) NULL`, `return_type varchar(100) NULL`, `data_for varchar(10) NULL` |
| `cc_document_type` | `internal_code int NOT NULL`, `document_type varchar(500) NULL`, `sequence varchar(50) NULL`, `is_mandatory varchar(20) NULL`, `category_type int NULL`, `document_for varchar(10) NULL`, `extension varchar(100) NULL`, `doc_ticket_type varchar(20) NULL`, `active varchar(10) NULL` |
| `cc_approval_matrix` | `internal_code int NOT NULL`, `category int NULL`, `app_type varchar(50) NULL` |
| `cc_approval_matrix_approvers_group` | `internal_code int NOT NULL`, `from_slab decimal(15,2) NULL`, `to_slab decimal(15,2) NULL`, `approver int NULL`, `approver_role varchar(40) NULL`, `policy_type varchar(50) NULL`, `sequence varchar(10) NULL`, `a_ui_status varchar(40) NULL`, `is_mandatory varchar(10) NULL` |
| `cc_accounting_division` / `cc_accounting_group` | Division: `internal_code int NOT NULL`, `code varchar(50) NULL`, `name varchar(50) NULL`, `div_active varchar(10) NULL`, `cc_group int NULL`. Group: `internal_code int NOT NULL`, `code varchar(10) NULL`, `name varchar(50) NULL`, `grp_active varchar(10) NULL`, `active varchar(50) NULL`. |
| `cc_warehouse_master` / `cc_region_master` | Warehouse: `internal_code int NOT NULL`, `code varchar(50) NULL`, `name varchar(50) NULL`, `region int NULL`. Region: `internal_code int NOT NULL`, `code varchar(50) NULL`, `name varchar(100) NULL`. |
| `cc_stock_reversal_category` / `cc_tax_rates` | Stock category: `internal_code int NOT NULL`, `stock_category varchar(300) NULL`. Tax: `tax_code varchar(50) NULL`, `tax_rate decimal(18,4) NULL`. |
| `cc_stage_master` | `internal_code int NOT NULL`, `code varchar(100) NULL`, `sequence int NULL` |
| `cir_post_business_approval_flow` | `internal_code int NOT NULL`, `return_material varchar(10) NULL`, `sequence int NULL`, `ui_status varchar(200) NULL`, `approver_role varchar(50) NULL` |
| `cir_setup` | `internal_code int NOT NULL`, `oop_days int NULL`, `cir_closed_days varchar(30) NULL`, `inpc_cir_closed_days varchar(30) NULL`, `curr_rate decimal(5,2) NULL`, `inpc_oop_days int NULL` |

### CIR views and request-list evidence

Catalog inspection also found `dbo.cir_header_view` and
`dbo.cir_open_care_view`. The header view exposes these 26 fields:

`Status`, `Country`, `case_reason`, `subject`, `ReferenceNumber`,
`AccountNumber`, `AccountName`, `ContactName`, `CustomerComplaintDate`,
`Description`, `DateTimeOpened`, `DateTimeClosed`, `LastModifiedDate`,
`BusinessGroup`, `SalesDistrict`, `Requestor`, `Owner`, `origin`,
`MonetaryValueofIssue`, `ComplaintReason`, `ComplaintConclusion`,
`AdjustmentReasonCode`, `created_date`, `AdjustmentReasonSAPCode`,
`Selling_District_Name`, `Selling_District_ID`.

Its definition reads `cc_customer_complaints`, joins
`SO_CustomerMaster` on `SO_CustomerMaster.CCUST =
cc_customer_complaints.customer`, and also joins complaint type/category,
group/division, and portal user masters. It filters selected SAP reason codes
and excludes `cir_entity='SAMCO'`; it contains no current-customer predicate.
The `AccountNumber` output is the string form of `SO_CustomerMaster.CCUST`.
Thus the account mapping is grounded in the live view, but a customer-facing
query still must add a server-authorized customer filter.

`dbo.cir_open_care_view` exposes `comp`, `CurrentReviewer`, `Division`,
`CareNo`, `CustNo`, `CustomerName`, `CareDate`, `CareAmount`, `CareStatus`,
`Country`, `case_reason`, `ReasonCode`, `causeCode`, and `COFSNumber`. It
depends on the complaint header, customer master, complaint type/category,
and portal user master; it appears care/reviewer-oriented and is not
established as the customer **My Requests** source.

The legacy `CIRMyApproval/GetCIRRequests` implementation was inspected at
`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\java\com\mmm\cir\CIRMyApproval.java`.
It queries the complaint tables directly and does not call
`cir_header_view`. The live header view remains useful evidence for the
account join/display mapping, but its output and filters differ from this
customer request list.

The legacy **My Requests** query:

- starts from `cc_customer_complaints` and left-joins
  `cc_complaint_type` on `complaint_type`, `cc_customer_reason` on
  `cc_inv_cust_reason`, `cc_complaint_category` on `category`, and
  `ia_user_master` on `pending_with` and `requester`;
- inner-joins `SO_CustomerMaster` on
  `SO_CustomerMaster.CCUST = cc_customer_complaints.customer`;
- filters `cc.customer = <cust_int_code>` and
  `request_src = 'Customer'`, then sorts by `ticket_number DESC`;
- selects the aliases `credit_note_no`, `credit_note_date`, `customer`,
  `invoice_no`, `invoice_date`, `internal_code`, `complaint_type`,
  `reason_short_code`, `category`, `sap_reason`, `sap_category`,
  `pending_with`, `cir_date`, `cir_no`, `total_amt`, `ui_status`, and
  `customer_reason` (as well as the request/ticket number);
- displays the request/ticket number, request date, invoice number, invoice
  date, reason, total amount, and status in the customer grid. The legacy
  DataTable page length is 50. Status is `Rework` when
  `reassign_to_cust='Yes'`, otherwise `Rejected` or `Closed` for those
  `ui_status` values, else `In Progress`.

The legacy UI posts `$g_cust_code` as `cust_int_code`; the controller
concatenates it into SQL without checking the authenticated session. The
migrated API instead uses
`UserSessionSupport.resolveProcedureCustomerContext(...)` (including
permission-gated override handling), resolves the CIR account key through the
CIR datasource's `SO_CustomerMaster.CCUST` lookup, and binds it to the CIR query. A
missing or ambiguous master match is rejected. Never accept a
browser-supplied `cust_int_code` as authorization.

The legacy `GetApprovalDetailsForPopup` accepts `internal_code` and
`FW_login_Id`, but its header SQL filters only by `cc.internal_code`; it does
not constrain the selected request to the current customer in that query. The
new detail API must authorize the request against the resolved customer or
the authenticated reviewer's permitted role/workflow state.

INPCV2 CIR home (`cir_home.html` + `cir.js`) has three tabs, defaulting to
**Dashboard**:

1. **Dashboard** — `cir_dashboard.html` / `cir_dashboard.js` / `CirDashboard` /
   `CirDashboardSql`. Year select (current + previous, default current),
   refresh icon (reloads data), New Request shortcut. Summary cards, needs
   attention list, ApexCharts status-mix donut (hover/click), recent requests,
   and Total claimed (selected year; excludes `Rejected` / `Cancelled`).
   Opening the Dashboard tab again does not re-fetch until Refresh or year
   change. Clicking the CIR menu clears any stuck CIR loaders.
2. **New Request** — `cir_new_request.html` with customer/invoice/complaint
   layout, invoice lines, and required-document upload after save.
3. **My Requests** — `cir_requests.html` list/detail on demand.

INPCV2's customer-facing API currently provides:

- `GET /api/customer/cir/context` to return the resolved CIR customer context.
- `GET /api/customer/cir/dashboard?year=` for dashboard summary/action/recent
  data filtered by `year(created_date)` (current or previous year only).
- `GET /api/customer/cir/new-request/lookups` for customer and request-form
  lookup data.
- `GET /api/customer/cir/new-request/invoices` for eligible invoice
  autocomplete suggestions.
- `GET /api/customer/cir/new-request/required-documents` for reason/cause
  document catalog rows (`document`, `document_type_id`, `is_mandatory`,
  extension, and prior upload path/name when editing).
- `GET /api/customer/cir/requests` for the customer's request list.
- `GET /api/customer/cir/requests/{requestId}` for an owned request's details.
- `POST /api/customer/cir/requests/{requestId}/documents` to upload one required
  document (multipart, after save) onto the CIRATTCH share via SMB 3.1.1.
- `GET /api/customer/cir/requests/{requestId}/documents/{documentId}/download`
  to download an owned request's required document via SMB 3.1.1.
- `POST /api/customer/cir/requests/{requestId}/attachments` to upload one
  additional document (multipart: `file`, optional `fileName`/`remarks`) onto
  the same share via SMB 3.1.1; the row is stored in
  `cc_customer_complaints_add_atch`.
- `GET /api/customer/cir/requests/{requestId}/attachments/{attachmentId}/download`
  to download an owned request's additional attachment via SMB 3.1.1.
- `POST /api/customer/cir/requests/{requestId}/clarifications/{clarificationId}/answer`
  to answer an outstanding customer clarification.

`CirRequests` uses the same
`UserSessionSupport.resolveProcedureCustomerContext(...)` and customer-role
guard as Rebate; `CirRequestsSql` executes the CIR query through
`NativeQuerySupport` with a bound customer parameter. It returns the legacy
`data.header_details` shape and only the fields needed by the customer grid.
The new `CIR/cir_home.html` and `CIR/cir.js` follow Rebate's shared
`Common.DataTable` API, 50-row default, status badges, and light/dark theme
styling. The grid's View action calls
`GET /api/customer/cir/requests/{requestId}`, which verifies the request
belongs to the resolved customer before loading its header, invoice lines,
lots, freight, approval rows, history, document metadata, additional
attachments, and clarifications. The detail view groups this information into Invoice Details, Lot Details,
Documents, and Credit Details tabs (legacy column layouts):

- **Invoice Details** — grouped Item / 3M Billed / Customer Actual columns
  (SI No., SKU No./Desc, Billed Qty, Price per Unit, CGST/SGST, Tax Amount,
  Total Inv. Amount, Actual Return Qty, Difference Price, Actual Value,
  Actual CGST/SGST, Claim Amount). Freight table when present.
- **Lot Details** — legacy columns: Sl.No, Item/LOT Mismatch, Item No.,
  Description, Line No., Invoice Billed Qty, Returned Qty, WH. Approved Qty,
  LOT No., LOT Wh., LOT Location, Overridden Loc., Billed Loc. Qty, Returned
  Qty. Lots are read from `cir_complaint_item_lot_group` with fallback to
  `cc_complaint_item_lot_group`.
- **Documents** — Required Documents table; Additional Documents table
  (Sl No, File Name, Remarks, Uploaded By, Uploaded Date, Download); Upload
  Additional Documents form (File Name, Attachment, Remarks, Upload). Upload
  and download use `CirFileStore` / SMB 3.1.1. Display/download names keep the
  original file extension via `CirFileStore.nameWithExtension` when the typed
  name has none. Download errors show inside the detail modal (not the My
  Requests banner); the spinner is always cleared, including when the CIR menu
  is reopened.
- **Credit Details** — amount/credit-note cards and clarifications. When
  `credit_note_no` is non-blank, **Approvals** and **History** are not
  rendered at all.

Popup detail tables use distinct tinted header backgrounds per section.
`CirFileStore` revalidates ownership before retrieving bytes from the CIR
share. File paths are never returned to the browser. The detail modal header
matches legacy fields (requester, customer/type, contact, material return,
invoice/date, reason, group/division, warehouse, credit/debit, complaint
details, total CIR amount in words).
Customers can answer an unanswered legacy `Request` clarification from the
detail modal. The POST rechecks session/customer/request ownership, only
updates an unanswered clarification for that request, clears the pending
clarification marker only when no other customer clarification remains, and
inserts an audit-history record in the same transaction. Neither this change
nor the read paths create or alter database schema.
CIR query diagnostics log SQL with bind parameters rendered as SQL Server
literals. These INFO logs can contain customer identifiers and clarification
answers; use them only in a controlled development environment.
The menu entry still needs HTML asset `CIR/cir_home` and
`custom_js/CIR/cir.js` (dashboard JS is loaded from the home shell). Approval
routing mutations, clarification-question creation, and email notifications
remain unfinished.

### ERP/AS/400 sources and external effects

The request flow reads customer, invoice, item, warehouse, shipment/lot,
group/division, and tax information from legacy ERP/AS/400-associated data
sources or views, including names such as `SO_CustomerMaster`,
`SO_ItemMaster`, `SO_Sales`, `SO_WarehouseMaster`, `SO_GrpdivX`, `EIL`,
`ZCC`, and `TransportLogFile`. The exact live ownership and availability of
each object must be confirmed with the database owners.

Customer resolution must follow the Rebate pattern without conflating
datasources: `UserSessionSupport.resolveProcedureCustomerContext(...)`
provides the authenticated session customer and permission-gated override.
`RebateProgramSql.customer(...)` looks up `reb_customer_master` on
`HibernateFactoryRegistry.INFOAPPS`; CIR request/workflow SQL runs on the
`cir` datasource in `dINECIR`. The legacy CIR module resolves its customer
from `SO_CustomerMaster` on the CIR database connection. `CirRequestsSql`
now does the same, using a parameterized `CCUST` lookup on the CIR datasource
before list/detail queries. The earlier INFOAPPS lookup returned no customer
for the selected account in the user's screenshot and has been removed. The
catalog does not define a foreign key for that association.

Other external effects include:

- CIR evidence and additional files transferred through SMB to a configured
  share, organized by year/month/ticket.
- Invoice PDF/copy retrieval from AS/400.
- Request, approval, clarification, and upload-failure email notifications;
  `cir_mail_history` records mail history.
- Approval assignment influenced by user roles, delegation, group/division,
  warehouse, region, request category, total amount, and policy status.

The inspected legacy `CIRDocFTPUploadINPC` obtains its share configuration
through the CIR attachment configuration routine, then uses the older JCIFS
SMB file APIs. Its attachment layout includes year/month/ticket directories.
Do not carry forward the legacy SMB client, credentials, or browser-visible
paths. **Project rule:** every CIR (and INPCV2 module) document upload/download
uses encrypted **SMB 3.1.1** through SMBJ 0.15.0
(`SMB2Dialect.SMB_3_1_1`, `withEncryptData(true)`), matching
`RebateDocUpload` / `ShipAndDebitDocUpload` / `CoaSql` /
`PoliciesGuidelines`. `CirFileStore` owns CIR storage on CIRATTCH.
Upload/download operations must validate file metadata, resolve paths from
server-side CIR records/configuration, authorize the request and document
against the resolved customer/session context, and return file content rather
than a share path. Do not reuse Rebate's `REBATE/` remote directory for CIR.

The legacy invoice-download implementation contains credentials embedded in
source. Do not reuse them. Before migration, revoke/rotate any exposed
credentials, remove them from source and artifacts, and use managed secrets
for the target integrations.

## Migration architecture for INPCV2

### Static UI

Create the module in the existing INPCV2 static structure:

- `src/main/resources/static/html_files/CIR/cir_home.html`
- Optional second page/fragment:
  `src/main/resources/static/html_files/CIR/cir_requests.html`
- `src/main/resources/static/custom_js/CIR/cir.js`

Reuse the existing application shell/module loader, `Common.DataTable`,
shared date picker, shared notification/modal patterns, and Bootstrap 5.
Keep styles scoped under the CIR module root. Do not copy Bootstrap 3,
Metronic styles, Bootbox, or duplicate vendor libraries. Render database
values as text or escaped values; do not concatenate untrusted values into
HTML or inline event handlers.

Suggested page structure:

- **New Request**: customer/invoice header, classification, selected line
  items, calculated amount/freight, document checklist/uploads, and
  submission summary.
- **My Requests**: searchable/paged customer request grid with status,
  request date, invoice, reason, amount, and a detail action.
- **Dashboard**: year-filtered summary, ApexCharts status mix, action items,
  recent requests; Total claimed excludes Rejected/Cancelled.
- **Request Details**: legacy-aligned Invoice / Lot / Documents / Credit
  tabs; Approvals/History hidden when a credit note is issued; additional
  document upload/download over SMB 3.1.1.
- Role-gated reviewer/care-cell operations should be separate actions/states,
  not inferred from hidden DOM controls.

### API and data access

Implement new APIs in flat `com.mmm.cir` classes with Spring constructor
injection and explicit HTTP verbs, following `RebatePrograms` /
`RebateProgramSql` separation without adding subpackages. Use the CIR
datasource and the existing `NativeQuerySupport`/`registry.withSession`
patterns. Use parameterized SQL for all client- or session-derived values.
Never close the registry-owned shared `SessionFactory` from request code.

Resolve identity and roles from the authenticated portal session on every
request. Resolve customer context/override using the established Rebate
`UserSessionSupport` pattern. A request ID, user ID, customer code, approval
sequence, role, status, amount, or file path supplied by the browser is not
authorization. Add object-level authorization for each request and state
transition. Separate read-only ERP/AS/400 calls from CIR transactional
mutations.

Suggested API capability groups (final route names may follow INPCV2
conventions):

- Lookup/context: customer context, customer/invoice autocomplete,
  invoice details, reason/cause/document options, eligible items/taxes.
- Requests: create, update/resubmit, list, and get details.
- Approval routing: calculate/preview matrix server-side; never persist an
  unvalidated browser-built approval chain.
- Workflow actions: approve, reject, send back/rework, care-cell quantity
  update, clarification question/answer, and close/complete.
- Files: upload/list/delete/download CIR attachments and invoice evidence
  with ownership checks.
- Integration: invoice copy retrieval through the named AS400 datasource.

Persist the request header and its item, freight, document metadata,
approval-chain, and initial-history records in a single CIR database
transaction where possible. Coordinate SMB transfer and email as explicit
external side effects with durable state, error reporting, and safe retry
behavior; do not report a successful submission if required persistence
failed. Record each workflow transition with actor, timestamp, prior/new
state, and remarks.

### Data integrity and workflow contract

Before coding the mutation APIs, establish a state-transition matrix covering
at least draft/create, submitted, pending approver, approved, rejected,
rework/reassigned to customer, resubmitted, care-cell/warehouse stages,
clarification pending/answered, closed, and credit-note issued. The exact
status names and transition ordering must be reconciled against configured
approval matrices and current business-owner rules.

Move monetary/tax calculations and policy validation to a shared
server-authoritative calculation service. Define precision, rounding,
negative/credit/debit behavior, inclusive/exclusive tax rules, flat amount
allocation, freight calculation, and duplicate-claim prevention before
porting the legacy JavaScript calculations. Return line-level validation
errors that the UI can associate with the corresponding item.

## Migration risks and decisions to resolve

1. **Legacy SQL construction:** numerous query/update statements concatenate
   request data into SQL. Replace all with bound parameters and allowlisted
   identifiers; do not port the query strings as-is.
2. **Identity and authorization:** legacy requests pass user/customer codes
   and request IDs from JavaScript; the review script contains a fixed user
   identifier. Use server session identity and role-based object-level
   authorization.
3. **Multi-database joins:** some queries combine CIR, ERP/AS400, and portal
   masters. Determine which data is local, which is remote, supported query
   paths, and consistency/freshness requirements. Do not assume cross-DB
   joins will work through INPCV2 datasource separation.
4. **Shared table ownership:** another legacy package,
   `com.mmm.customercomplaints`, also reads/writes `cc_customer_complaints`
   and related tables and exposes similar functionality. Establish whether it
   is a separate customer-complaint product, a second CIR implementation, or
   a shared service before migrating mutations; avoid incompatible parallel
   writers.
5. **Approval correctness:** matrix rules are numerous and configuration
   driven. Reconcile all role/amount/region/group/warehouse/reason variants
   with business owners and sample existing workflows.
6. **Calculation correctness:** taxes, material return, flat amounts,
   freight, out-of-policy requests, and partial/previous claims create
   financial risk. Obtain golden test cases from legacy outputs and compare
   server-side results before launch. **Status:** the Load Invoice feature
   (see "New Request: Load Invoice" above) currently implements a simplified
   MVP calculation only — no freight proration, no edit-mode support, and a
   simplified tax-suppression rule. Do not enable request submission until
   golden test cases are compared.
7. **Files:** validate required-file rules, size limits, extensions,
   malware scanning, storage naming, retention, download authorization,
   SMB availability, and failure/retry behavior. Do not trust client-provided
   paths or names.
8. **AS/400 invoice data:** validate invoice lookup, date conversion,
   customer association, and document retrieval for representative cases.
9. **Email and audit:** validate recipients/templates and ensure durable
   audit history remains authoritative if email is delayed or fails.
10. **Legacy runtime assumptions:** old Bootstrap/jQuery globals, synchronous
    AJAX, direct DOM globals, old DataTables APIs, and dynamically loaded
    script order should not be carried into the new module.

## Recommended migration phases

1. **Discovery and sign-off**
   - Confirm CIR and AS/400 datasource/database ownership and read/write
     permissions.
   - Inventory schema, keys, nullability, triggers, stored procedures, views,
     and all shared-table writers.
   - Capture representative current cases, including each request type,
     material-return mode, tax type, amount mode, approval chain, rework,
     warehouse/care-cell, clarification, lots, and attachments.
   - Confirm the authority for approval rules, status transitions,
     calculations, retention, and notification behavior.
2. **Read-only foundation**
   - Add context-safe lookup, invoice/item preview, customer request list,
     and detail APIs using the CIR registry datasource.
   - Compare read-only results against legacy for approved, pending,
     rejected, rework, closed, and credit-note cases.
3. **New-request form and calculations**
   - Port request categories and conditional form behavior.
   - Implement and golden-test server-side line/tax/freight calculations and
     duplicate-claim rules.
4. **Transactional submit and documents**
   - Implement create/edit/resubmit with transactional header/lines/approval/
     history persistence.
   - Add secure upload/list/download and durable handling of SMB/email
     failures.
5. **Review and workflow actions**
   - Implement request detail, approvals, rejection/rework, care-cell/
     warehouse updates, clarifications, audit history, and credit-note/
     transport sections behind server-enforced role/state checks.
6. **Parallel validation and rollout**
   - Run legacy/new read-only comparisons and business UAT.
   - Test permissions, CSRF/session behavior, malicious IDs/files, concurrency,
     duplicate submits, external-service outages, and retry/idempotency.
   - Roll out by approved user group with monitoring and a rollback plan;
     disable the legacy writer only after data and workflow reconciliation.

## Acceptance criteria

- Every migrated user action has a documented API, required role, allowed
  state, validation rule, and audit event.
- Request header, lines, freight, approval routing, documents, and history
  match approved legacy golden cases, including total/tax rounding.
- A user cannot read, mutate, attach to, or download another user's
  unauthorized CIR request by changing request/customer/role IDs.
- Untrusted data is not inserted into SQL or HTML; uploads are validated and
  downloads require ownership checks.
- Every workflow transition is atomic within CIR persistence and safe under
  retries; external SMB/email outcomes are visible and recoverable.
- Invoice/item/customer lookups and invoice-copy downloads work using
  approved named datasources without embedded credentials.
- Search, pagination, modal/detail behavior, and responsive layout work in
  Bootstrap 5 and both portal themes.
- Legacy and new reports/details reconcile for a representative signed-off
  sample set.

## Legacy source paths and files consulted

The paths below are from the adjacent legacy checkout at
`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\`; no legacy files were
modified. `CIRMyApproval.java`, `CIRDocFTPUploadINPC.java`,
`CIRAdditionalAttchments.java`, `cir_requests_view.js`, and `cir_requests.html`
were consulted for the request-list and attachment findings above. The other
paths are part of the identified legacy CIR package and may require inspection
as implementation proceeds.

Legacy UI:

- `inpc/src/main/webapp/resources/CIR/html/cir_home.html`
- `inpc/src/main/webapp/resources/CIR/html/cir_new_request.html`
- `inpc/src/main/webapp/resources/CIR/html/cir_requests.html`
- `inpc/src/main/webapp/resources/CIR/html/cir_my_approval_popup.html`
- `inpc/src/main/webapp/resources/CIR/js/cir_new_request.js`
- `inpc/src/main/webapp/resources/CIR/js/cir_requests_view.js`

Legacy Java:

- `inpc/src/main/java/com/mmm/cir/CIRRequest.java`
- `inpc/src/main/java/com/mmm/cir/SaveNewCIRRequest.java`
- `inpc/src/main/java/com/mmm/cir/CIRMyApproval.java`
- `inpc/src/main/java/com/mmm/cir/CIRCommon.java`
- `inpc/src/main/java/com/mmm/cir/CIRAdditionalAttchments.java`
- `inpc/src/main/java/com/mmm/cir/CIRDocFTPUploadINPC.java`
- `inpc/src/main/java/com/mmm/cir/DownloadCustomerInvoiceFromAS400.java`
- `inpc/src/main/java/com/mmm/cir/SendCIRMail.java`
- `inpc/src/main/java/com/mmm/cir/HybernetUtil.java`

INPCV2 files inspected as the existing smoke-test scaffold (left unchanged):

- `src/main/java/com/mmm/config/HibernateFactoryRegistry.java`
- `src/main/java/com/mmm/cir/CirHybernetUtil.java`
- `src/main/java/com/mmm/cir/CirSmokeController.java`
- `src/main/java/com/mmm/cir/CirUserService.java`
