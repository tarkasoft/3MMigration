# Auto-deploy to JBoss (exploded WAR)

When Java sources change, compiled classes are copied to:

`C:\Users\A6GWBZZ\jboss-eap-8.1.0-dev\jboss-eap-8.1\standalone\deployments\INPCV2.war\WEB-INF\classes`

and `INPCV2.war.dodeploy` is touched so EAP redeploys.

## Eclipse

1. **Project → Build Automatically** must be ON.
2. Builder **deploy-to-jboss** runs **after** the Maven (m2e) builder (see Project → Properties → Builders).
3. Save a `.java` file / refresh → classes sync + **one** redeploy.

Inside Eclipse, Maven `process-classes` **does not** touch `dodeploy` (`m2e` profile sets `inpc.jboss.deploy.skip=true`). Only the Ant builder deploys, so a refresh no longer redeploys twice.

To pause: Project → Properties → Builders → uncheck **deploy-to-jboss**.

Manual Ant: right-click `deploy-to-jboss.xml` → Run As → Ant Build.

## Maven (CLI)

`mvn compile` / `package` still runs the copy on `process-classes` (property `inpc.jboss.war` in `pom.xml`). That path is for command-line builds only.

## Note

Redeploy drops HTTP sessions (users may need to log in again). Static HTML/JS/CSS are not copied by this builder — only `target/classes`.
