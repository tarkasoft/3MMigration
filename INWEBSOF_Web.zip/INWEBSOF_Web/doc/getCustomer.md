# getCustomer

How a module passes the customer from the page and how Java returns the customer code. Rebate Programs, CIR Requests, Account Status, and Ship and Debit use this. The Change Customer screen itself is [CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md).

## Pass customer

Each request that needs a customer sends two optional fields, `custCode` and `loginId`.

The page reads them with `Common.GetProcedureCustomerContext()` in `custom_js/common.js` and puts that object on the query string or in the JSON body.

| Cookies | What is sent |
|---------|----------------|
| `fw_see_other_cust_data` is Yes and `fw_customer_overridden` is Yes | `fw_override_cust_code` and `fw_override_loginId` |
| Any other case | `custCode` and `loginId` are both empty |

Empty means the logged-in session. Call this on every request, including page load. `Common.GetCustCode()` and `Common.GetCustName()` are for labels on the page. The request uses `GetProcedureCustomerContext`, which is empty unless Change Customer is active.

```javascript
_procedureContext: function () {
    if (Common.GetProcedureCustomerContext) {
        var context = Common.GetProcedureCustomerContext() || {};
        return {
            custCode: String(context.custCode || "").trim(),
            loginId: String(context.loginId || "").trim()
        };
    }
    return { custCode: "", loginId: "" };
}
```

Rebate does this on load, calls `GET /api/customer/rebate/context?custCode=&loginId=`, and then keeps the `custCode` and `loginId` that the server returns.

## getCustomer

The API takes both parameters as optional. Java reads the customer with `UserSessionSupport.resolveProcedureCustomerContext`. The session attributes are `cust_code` and `loginId`.

```java
@GetMapping("/context")
public String context(HttpServletRequest request,
        @RequestParam(value = "custCode", required = false) String custCode,
        @RequestParam(value = "loginId", required = false) String loginId) {
    HttpSession session = request.getSession(false);
    if (!UserSessionSupport.isLoggedIn(session)) {
        throw new IllegalStateException(UserSessionSupport.SESSION_EXPIRED_MESSAGE);
    }
    UserSessionSupport.ProcedureCustomerContext context =
            UserSessionSupport.resolveProcedureCustomerContext(session, custCode, loginId);
    String customerCode = context.custCode();
    String loginIdForCall = context.loginId();
}
```

The override pair is kept when all three are true:

1. The session is logged in and `see_other_cust_data` is Yes (`canChangeCustomer`).
2. The passed `custCode` is not blank.
3. The passed `loginId` is not blank.

Otherwise `customerCode` is the session customer and `loginIdForCall` is the session login. `context.overridden()` is true only when the override pair was kept.

Use `customerCode` as a bound parameter. The next step depends on the module:

| Module | After getCustomer |
|--------|-------------------|
| Rebate Programs | `reb_customer_master` on `infoapps` where `cust_code = ?`, then `internal_code` |
| CIR Requests | `SO_CustomerMaster.CCUST` on `cir`, then that row's `cust_code` |
| Account Status, My Orders, Payments | `loginIdForCall` on the procedure; some calls also take `customerCode` |
| Ship and Debit | `customerCode` is the distributor code for `SFLASH` and for POS (`dbo.Dealer`, `dis_max_inv_date`) |

A customer picked inside the screen, such as the Ship and Debit end customer, is a separate field. It is not this `customerCode`.
