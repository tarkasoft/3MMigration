# Account Status — Legacy (`inpc`) to Current (`INPCV2`) Migration

Tracking document for replacing the dummy Account Status backends with real AS400
stored-procedure calls.

- **Legacy source**: `C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main`
- **Target source**: `C:\Users\A6GWBZZ\eclipse-workspace\INPCV2\INPCV2\src\main`

---

## 1. Ground rules

1. **No new files.** Each tab already has exactly one Java class, and the whole
   screen shares one JS file and one HTML file. Work happens inside the existing
   method bodies.
2. **Follow the `MyOrders` pattern**, not the legacy DAO/DAOImpl/DTO layering.
   One `@RestController` per tab, `NativeQuerySupport.executeProcedure(...)`
   called directly, rows assembled into `List<Map<String,Object>>`.
3. **Every endpoint keeps a `dummy` flag**, exactly like
   `/api/customer/my-orders/open?dummy=true`. Dummy rows stay in the file so the
   screen is demoable when AS400 is unreachable.
4. **No credentials in source.** The legacy code has a plaintext FTP user and
   password; use `@Value` properties instead.
5. **One tab at a time**, verified against real AS400 data before starting the
   next.

---

## 2. Current state

The UI is already complete. `account_status.html` has all seven tabs and
`account_status.js` wires all seven to real endpoints through
`Common.DataTable`. Only the Java layer was fake — the classes returned
`dummyRows()` / `dummySummary()` and reported `"source":"dummy"`.

So this is not a port. It is a per-file swap of one private method.

### 2.1 Migration status

| # | Tab | Java file | Status | Verified |
|---|---|---|---|---|
| 1 | Paid Invoices | `PaidInvoices.java` | ✅ **Done** | Live AS400, 37 rows, columns matched to legacy |
| 2 | Payment History | `PaymentHistory.java` | ✅ **Done** | Live AS400, 37 rows; positional mapping fix applied |
| 3 | Unapplied Amount | `UnappliedAmount.java` | ⬜ Not started | — |
| 4 | Instrument Return | `InstrumentReturn.java` | ⬜ Not started | — |
| 5 | Account Summary | `AccountSummary.java` | ⬜ Not started | — |
| 6 | Payments Due | `PaymentsDue.java` | ⬜ Not started | — |
| 7 | Statement of Accounts | `StatementOfAccounts.java` | ⬜ Not started | — |

Done = real procedure call, dummy flag, legacy-matched column mapping,
`javac` clean. Tabs 3-7 still return dummy rows only.

---

## 3. Procedure map

| # | Java file | Procedure | Parameters | Status |
|---|---|---|---|---|
| 1 | `PaidInvoices.java` | `BPCSLCLIN.COS009S` | APPCODE, LOGINID, FROMDATE, TODATE | ✅ Done |
| 2 | `UnappliedAmount.java` | `BPCSLCLIN.COS024S` | APPCODE, LOGINID, CUSTCOD | ⬜ Pending |
| 3 | `InstrumentReturn.java` | `BPCSLCLIN.COS016S` | APPCODE, LOGINID, DISTCOD | ⬜ Pending |
| 4 | `PaymentHistory.java` | `BPCSLCLIN.COS010S` | APPCODE, LOGINID, FROMDATE, TODATE | ✅ Done |
| 5 | `AccountSummary.java` | `BPCSLCLIN.COS001S` + `COS002S` | APPCODE, LOGINID (+ output params) | ⬜ Pending |
| 6 | `PaymentsDue.java` | `BPCSLCLIN.COS014S` | APPCODE, LOGINID, DISTCOD, DEBTDTE | ⬜ Pending |
| 7 | `StatementOfAccounts.java` | `BPCSLCLIN.COS011S` + FTP | APPCODE, LOGINID, FROMDATE, TODATE, out SOAFILENAME | ⬜ Pending |

`COS001S` and `COS002S` return **output parameters only**, so they need
`executeProcedureWithOutputs(...)`, not `executeProcedure(...)`.

---

## 4. Open issues to settle

### 4.1 APPCODE — confirmed as `INPC`
Legacy used `"INPC"` for account status and a separate `APPCODEMYPAY` property
for payments. The current project uses `"MYORD"` in `MyOrders` and `CRSAPP` in
`InvCrDrDownload`.

`PaidInvoices` and `PaymentHistory` use the property
`inpc.account-status.app-code` with a default of `INPC`. Override in
`application.properties` if AS400 expects a different value. A wrong app code
typically returns an empty result set rather than an error.

**Update:** `INPC` is confirmed working — `COS009S` returned live rows for
Paid Invoices with it. Reuse the same property for every remaining tab.

### 4.2 Three procedures ignore `custCode`

`COS001S`, `COS002S` and `COS003S` accept only APPCODE and LOGINID — the customer
is implied by the login on the AS400 side. The current project passes `custCode`
explicitly via `UserSessionSupport.resolveProcedureCustomerContext(...)` to
support CSR impersonation. Those screens will therefore not honour a
CSR-selected customer. Needs a business decision.

### 4.3 Legacy features with no home in the new UI

- **Unpaid Invoices** (`COS003S`) — a full legacy screen; there is no tab for it
  in `account_status.html`.
- **Payments Due remarks editing** (`COS013S` update + `COS021S` email lookup) —
  legacy allowed inline editing of customer remarks, 5–250 characters, editable
  only when the debit date was more than seven days away. `PaymentsDue.java`
  emits no remark keys, so it is read-only by construction.

Both are out of scope for the first pass.

### 4.4 Helper duplication

Each tab needs `sqlLiteral`, `text`, `value`, `zeroIfBlank`, `parseDate` and
`displayDate`. `MyOrders` and `InvCrDrDownload` already duplicate these, and
`PaidInvoices` + `PaymentHistory` now make **four** copies. Repeating them five
more times is a lot of copy-paste; they could instead be added as `public static`
helpers on the existing `com.mmm.titpl.NativeQuerySupport`, which adds no new
file.

Still deferred to keep each tab self-contained during verification, but this is
worth doing once all seven tabs are live and their mappings are confirmed —
at that point the extraction is a mechanical, low-risk change. Note that
`parseDate` has already drifted: `PaymentHistory` accepts `dd-MM-yyyy` because
COS010S edits its dates that way, `PaidInvoices` does not. Any extraction must
take the superset.

---

## 5. Tab 1 — Paid Invoices

### 5.1 Endpoint

```
GET /api/customer/account-status/paid-invoices
      ?custCode=&loginId=&fromDate=&toDate=&dummy=
```

`fromDate` / `toDate` accept `yyyymmdd`, `dd/MM/yyyy` or `yyyy-MM-dd`.
When both are blank the range defaults to **first day of last month → today**,
which is the legacy default.

### 5.2 Procedure call

```java
NativeQuerySupport.executeProcedure(
        hibernateRegistry,
        HibernateFactoryRegistry.AS400,
        "{call BPCSLCLIN.COS009S(?,?,?,?)}",
        appCode, loginId, fromNumeric, toNumeric);
```

`fromNumeric` / `toNumeric` are `BigDecimal` values in `yyyyMMdd` form. The
legacy DAO declared these parameters as **decimal**, not character, so they must
not be passed as strings.

### 5.3 Validation

Ported from the legacy datepicker rules:

| Rule | Message |
|---|---|
| From must be on or before To | `From Date cannot be after To Date` |
| Range must not exceed 6 months | `Date range cannot exceed 6 months` |
| To must not be in the future | `To Date cannot be in the future` |

### 5.4 Column mapping

Legacy `COS009S` returns: `CSINVN`, `CSINVDT`, `CSCUSPO`, `CSTERM`, `CSTOT`,
`CSPAID`, `CSBAL`, `CSDUEDT`, `CSCLODT`, `CSODUE`.

The new grid in `account_status.js:156-167` expects different columns, so the
mapping is not one-to-one:

| JSON key (new UI) | Grid label | AS400 source | Confidence |
|---|---|---|---|
| `invoiceNo` | Invoice Number | `CSINVN` | Confirmed |
| `invoiceDate` | Invoice Date | `CSINVDT` | Confirmed |
| `poNo` | PO Number | `CSCUSPO` | Confirmed |
| `invoiceAmount` | Invoice Amount | `CSTOT` | Confirmed |
| `paymentRef` | Payment Reference | `CSCKNO` | Confirmed |
| `amount` | Amount (Rs) | `CSCKA` | Confirmed |
| `creditNoteAdj` | Credit Note Adjusted | `CSCRNO` (text) | Confirmed |
| `creditNoteAmount` | Amount (Rs) | `CSCRA` | Confirmed |
| `closedDate` | Closed Date | `CSCLODT` | Confirmed |
| `daysToPay` | Days To Pay | computed `CSCLODT - CSINVDT` | Confirmed |

Source of truth: the legacy grid definition in
`inpc/src/main/webapp/resources/myaccsts/js/myaccsts.js` lines 279-383
(`columnDefs` for the Paid Invoices grid), plus `calculatedaystopay()` at
line 484 which is literally `daysBetween(CSINVDT, CSCLODT)`.

Two corrections were made after the first pass returned the right row count
but wrong figures:

1. `CSPAID` / `CSODUE` were **wrong**. Those labels come from
   `UnpaidInvoices.jsp`, a different screen. The legacy Paid Invoices grid
   explicitly comments `CSPAID` out (myaccsts.js:327-332) and binds
   `CSCKNO` (cheque number) and `CSCKA` (cheque amount) instead.
2. There is no computed *Net Amount*. The legacy grid shows a second
   *Amount (Rs)* column bound to `CSCRA`, the credit-note amount. The
   `subtract(...)` fallback was removed.

`creditNoteAdj` is rendered as text, not a number: the legacy column uses
`cellClass: "center-align"` and its `cellFilter: 'number'` is commented out,
and it displays blank when there is no credit note. So it must **not** go
through `zeroIfBlank`, or every row shows a spurious `0`.

Positional fallback was removed from `value(...)`. COS009S returns more
columns than the grid consumes, so a missed name silently resolved to
whatever sat at that ordinal — that is what put the invoice amount into
*Payment Reference* and a grand total into *Amount (Rs)*. Name-only lookup
fails visibly (blank) instead of plausibly (wrong number).

`CSBAL` and `CSDUEDT` are returned by the procedure but have no column in the
new grid. They are intentionally dropped — the legacy grid comments `CSDUEDT`
out (myaccsts.js:360-367).

`CSTERM` is read but not displayed. COS009S appends a summary row carrying
`CSTERM = 'Total'`; the legacy grid keeps that row and blanks its Invoice
Number, Invoice Date, PO Number and Closed Date cells so only the totals show
(myaccsts.js:285, 292, 299, 373). `loadAs400Rows(...)` reproduces this and also
blanks Days To Pay, which is meaningless without an invoice date. The row is
tagged `totalRow: true` in the JSON so the grid can style it later if wanted.

### 5.5 How to verify the mapping

The implementation logs the raw AS400 column names of the first returned row:

```
COS009S returned N row(s). Raw columns of first row: [...]
```

Fields are resolved **by name only** — there is deliberately no positional
fallback. A wrong or missing name therefore renders an empty cell rather than
silently borrowing an unrelated figure from that ordinal. If a cell is blank,
read the log line above and correct the alias in `loadAs400Rows(...)`.

### 5.6 Files changed for this tab

1. `C:\Users\A6GWBZZ\eclipse-workspace\INPCV2\INPCV2\src\main\java\com\mmm\customer\account_status\PaidInvoices.java`
2. `C:\Users\A6GWBZZ\eclipse-workspace\INPCV2\INPCV2\src\main\resources\static\custom_js\CUST_SERVICE\account_status.js`
   — column titles and `money` list realigned to the legacy grid.
3. `C:\Users\A6GWBZZ\eclipse-workspace\INPCV2\INPCV2\src\main\resources\static\html_files\CUST_SERVICE\account_status.html`
   — filter hint now carries the legacy "current and previous month" note.

---

## 5A. Login-id contract fix in `account_status.js`

`PaidInvoices` now resolves its customer through
`UserSessionSupport.resolveProcedureCustomerContext(...)`, the same as
`MyOrders` and `InvCrDrDownload`. That method only honours a client-supplied
customer when **both** `custCode` and `loginId` are present and the session is
allowed to view other customers; otherwise it falls back to the session pair.

`account_status.js` was sending the wrong pair:

```javascript
var custCode = String(Common.GetCustCode() || "").trim();
var loginId  = String(Common.GetLoginId()  || "").trim();
```

- `Common.GetCustCode()` returns the **override** customer code when an override
  is active (cookie `fw_override_cust_code`).
- `Common.GetLoginId()` always returns `fw_loginId`, which is the **signed-in
  user's own** login, never `fw_override_loginId`.

So for a CSR viewing another customer, the request carried customer A's code
together with the CSR's own login id. Because `canChangeCustomer` is true and
both values are non-empty, Java accepted that mismatched pair and passed it
straight to AS400. The procedures key off `LOGINID`, so the screen would show
the wrong rows, or none, while appearing to be on customer A. Silent, not an
error.

`my_orders.js` avoids this with `Common.GetProcedureCustomerContext()`, which
returns either a **matched** override pair or `{ custCode: "", loginId: "" }` so
that Java falls back to the session. `account_status.js` now uses the identical
helper, added as `AccountStatus._procedureContext()` and consumed in `_load`.

Because `_load` is shared by all seven tabs, this one change covers the whole
screen.

`Common.GetCustCode()` is still used as the *presence guard* in
`LoadAccountStatus` and `_load` — that matches `my_orders.js` and is correct,
since the guard only asks "is a customer selected at all".

### 5A.1 Dummy flag

`account_status.js` had no dummy switch. It now carries the same one as
`my_orders.js`:

```javascript
AccountStatus.USE_DUMMY_DATA = false
```

It is sent as `dummy` on every tab request. `PaidInvoices` and `PaymentHistory`
read it today; the remaining five controllers ignore the unknown parameter
harmlessly, and will pick it up as each one is migrated.

This flag matters now: before the migration every tab returned dummy data
unconditionally, so defaulting `dummy=false` is what switches a migrated tab
over to live AS400 data. Flip `USE_DUMMY_DATA` to `true` to demo the screens
without AS400.

### Related, not changed

`customer_payment.js` and `know_your_customer.js` still use the
`GetCustCode()` + `GetLoginId()` pattern. Their Java counterparts do **not** call
`resolveProcedureCustomerContext`, so they are not affected today. If those
controllers are ever migrated to that helper, their JS must be updated at the
same time.

---

## 5B. Tab 2 — Payment History

### 5B.1 Endpoint

```
GET /api/customer/account-status/payment-history
      ?custCode=&loginId=&fromDate=&toDate=&dummy=
```

Same contract as Paid Invoices: session-checked, customer resolved through
`UserSessionSupport.resolveProcedureCustomerContext(...)`, dates accepted as
`yyyymmdd`, `dd/MM/yyyy`, `dd-MM-yyyy` or `yyyy-MM-dd`, defaulting to first day
of last month → today when both are blank.

### 5B.2 Procedure call

```
{call BPCSLCLIN.COS010S(?,?,?,?)}
```

`APPCODE` varchar, `LOGINID` varchar, `FROMDATE` decimal, `TODATE` decimal —
**identical in shape to COS009S**, confirmed from the legacy
`MyAccStsImpl.paymenthistoryList(...)` (MyAccStsImpl.java:130-151). The dates are
decimal `yyyyMMdd`, so they are passed as `BigDecimal`, not strings.

Note the legacy JS sent `yyyy-MM-dd` over HTTP and converted to decimal in the
Java layer; the new endpoint accepts either and converts once.

### 5B.3 Column mapping

Source of truth: the legacy `paymentHistory.columnDefs` in
`inpc/src/main/webapp/resources/myaccsts/js/myaccsts.js` lines 716-770, **plus**
the `keyChange` + `statickeys` call at lines 874-884.

**This procedure is mapped by position, not by name.** COS010S builds several
columns from expressions — `REPLACE(PHPAYE,'/','-')`, `IFNULL(OHOBNO,' ')` and
the `SUBSTR(DIGITS(OHOBD8),...)` date — and DB2 returns expression columns
**unnamed**. The legacy UI handled this by renaming the whole result set
positionally through `keyChange(data, [...statickeys])`; the display names in
`columnDefs` are therefore labels that legacy *assigned*, not names the procedure
*returned*.

Documented result-set order (myaccsts.js:775-785):

| Pos | Legacy alias | Physical source | New JSON key | Grid title |
|---|---|---|---|---|
| 1 | `PHCKNO` | `PHCKNO` | `paymentRef` | Payment Reference |
| 2 | `PHDESC` | `PHDESC` | *dropped* | — |
| 3 | `RECVDT` | `REPLACE(PHPAYE,'/','-')` | `receivedDate` | Received Date |
| 4 | `RECVAMT` | `PHPAYA` | `receivedAmount` | Received Amount (Rs) |
| 5 | `APPLAMT` | `PHCAAP` | `appliedAmount` | Applied Amount (Rs) |
| 6 | `UNAPPLAMT` | `PHUNAA` | `unappliedAmount` | Unapplied Amount (Rs) |
| 7 | `CLSDDT` | `REPLACE(PHCLSE,'/','-')` | *dropped* | — |
| 8 | `OBLIGATEID` | `IFNULL(OHOBNO,' ')` | `invoiceNo` | Invoice Number |
| 9 | `OBLIGATEDT` | `SUBSTR(DIGITS(OHOBD8),…)` | `invoiceDate` | Invoice Date |

`valueAt(row, ordinal, names…)` tries the names first and falls back to the
ordinal, but **only when the row has all nine columns**. If the procedure shape
ever changes, cells go blank instead of silently showing a neighbouring value.

The existing JS already used exactly the seven surviving keys in this order, so
**no JS or HTML change was needed for this tab** — the grid titles already match
the legacy `displayName` values.

Dropped deliberately, matching legacy — both are commented out in the legacy
grid: `PHDESC` (Description, myaccsts.js:720-723) and `CLSDDT` (Closed Date,
myaccsts.js:765-768).

There is **no totals row** in this grid — unlike Paid Invoices, the legacy
Payment History `columnDefs` contain no `CSTERM == 'Total'` cell templates, so
no summary-row handling is needed.

Positions 3 and 9 arrive pre-formatted as `dd-MM-yyyy` (the procedure does the
editing), which is why `parseDate` here accepts that pattern.

> **Lesson, now seen twice.** Paid Invoices broke because of a *blind* positional
> fallback with no anchor. Payment History broke because of *name-only* lookup
> against a procedure that does not name its columns. Neither rule is universally
> right — per tab, check whether the legacy JS calls `keyChange`. If it does, the
> contract is positional and must be anchored to a verified column count.

### 5B.4 Files changed for this tab

1. `C:\Users\A6GWBZZ\eclipse-workspace\INPCV2\INPCV2\src\main\java\com\mmm\customer\account_status\PaymentHistory.java`

No JS or HTML change — the grid config already matched the legacy definition.

---

## 6. Testing checklist per tab

- [ ] **Before coding:** read the legacy `columnDefs` *and* check whether that
      tab's request function calls `keyChange(...)`. Only Payment History does
      (myaccsts.js:877) — the other five are name-based, so name-only lookup is
      correct for them.
- [ ] `?dummy=true` still renders the sample rows
- [ ] `?dummy=false` returns `"source":"as400"`
- [ ] Raw column names logged and mapping confirmed
- [ ] **Every column compared against the legacy screen side by side** — a right
      row count proves nothing about the mapping
- [ ] Date validation messages appear correctly
- [ ] Blank numeric cells show `0`, not empty
- [ ] Dates render as `dd-MM-yyyy`
- [ ] With a CSR override active, the rows belong to the selected customer
