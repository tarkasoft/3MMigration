# CreateTablesAndElements

Class: `com.mmm.system.CreateTablesAndElements`.

Runs only when framework save writes `ia_menu_options` or `ia_s_user_schema_elements`, and only when that module’s `load_type` is `FrameWork`. Other load types and other modules do not create or change tables. Group rows (`is_multiple_group = 1`) and group tables are ignored.

Save entry: `POST titpl/system/AddUserSchemaGeneralDetailsNew` → `DynamicModuleDetails.AddUserSchemaGeneralDetailsNew`.

Delete entry: `titpl/display_grid/deleteUserSchemaModuleDetails.demo`. The column or table is dropped **before** the row delete, and only when `load_type` is FrameWork. Deleting an element drops `system_name` on the module table. Deleting a menu option drops the table named by `file_name`. Group rows are skipped. Catalog tables (`ia_menu_options`, `ia_s_user_schema_elements`, `ia_user_master`, and the other framework tables) are never dropped. If another element still uses the same `system_name`, the column is left in place. A failed drop rolls the delete back.

## Order

1. `PreSaveData(session, savedTable, internalCode)` reads the current row **before** insert or update. On a new row (`internal_code` is `0`) the snapshot is empty.
2. The framework save writes the row.
3. `FWValidation.PostSaveModuleDetails` runs only for the two tables above and calls `apply` with the new row id and that snapshot.
4. `apply` reads the row just saved and compares it to the snapshot.

The snapshot is held in the save method until `PostSave` returns. It is not stored in the browser session.

| Saved table | `PreSaveData` keeps |
|---|---|
| `ia_menu_options` | `file_name` |
| `ia_s_user_schema_elements` | `system_name`, `data_type` |

## Menu option → table

`file_name` is the table name in `dbo`.

Created when missing:

- `internal_code` int identity, primary key `PK_{file_name}`
- `created_by` int, `created_date` datetime, `modified_by` int, `modified_date` datetime

| Before | After | Action |
|---|---|---|
| No previous name, or the same name | `file_name` | Create the table if it is missing |
| Old table missing | New `file_name` | Create the new table |
| Name changed, old table exists, new name is free | New `file_name` | `sp_rename` the table. Rows stay |
| Name changed, new name is already a table | | Save fails. The menu row is rolled back |

A name that is not a plain identifier (`letters, digits, underscore`, must start with a letter) is skipped. Examples that are skipped: `CUST_SERVICE/account_status`.

## Element → column

Parent table is `ia_menu_options.file_name` for `ref_s_user_schema_code`. The column name is `system_name`. If that table is missing, the header table is created first, then the column is added.

`is_multiple_group = 1` returns without adding or renaming anything.

These names are never added as columns: `internal_code`, `created_by`, `created_date`, `modified_by`, `modified_date`.

| Before | After | Action |
|---|---|---|
| New element | Column missing | `ALTER TABLE ADD` |
| `system_name` changed, old column exists, new name is free | | `sp_rename` the column |
| `system_name` changed, new column already exists | | Save fails |
| Data type changed | Column exists | `ALTER COLUMN` to the new type, still nullable |
| Name and type both changed | | Rename, then alter the type |
| Nothing changed | | Do nothing |

A type change fails when values already in the column cannot convert. That save rolls back, so the element row and the column stay as they were.

## Data type → SQL type

All new and altered columns are nullable.

| Element `data_type` | Column |
|---|---|
| Text, and any other type not listed | `varchar(200)` |
| List Of Values | `varchar(100)` |
| Large Text, TextArea, Text Area | `varchar(max)` |
| Number | `decimal(18,4)` |
| Checkbox | `int` |
| Date | `date` |
| DateTime | `datetime` |
| Reference Data | `int` (the other row’s `internal_code`) |

There is no length column on elements. Older tables may use different widths. A re-save that does not change the data type does not alter those existing columns.

## Restart

Java change. Restart Tomcat or EAP before saving a menu option or an element.
