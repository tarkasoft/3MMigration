# CSD Graphic E-Warranty Migration

## Purpose and scope

This document records legacy **CSD graphic E-Warranty** (Converter / Distributor / End Customer) discovery and the INPCV2 target. It is a discovery / planning document — not proof that the module is already in the portal.

**This is not TSD.** TSD is a separate, already-migrated module (`resources/TSD`, `com.mmm.tsd`). Do **not** edit TSD Java, HTML, JS, or TSD docs while building E-Warranty. Refer to TSD only as a **coding pattern**.

Living API map: **[EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md)** (keep updated when coding).

Legacy UI:

`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\webapp\resources\Ewarranty\`

Legacy Java:

`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\java\com\mmm\ewarranty\`

PDF builders:

`C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc\src\main\java\com\mmm\csdwarrantydocumnts\`

Portal routes (legacy): `EWCONV` → Converter (`ewarrantyconv.html`), `EWDIST` → Distributor (`ewarrantydist.html`), end customer → `WarrantyEndCust.html`.

## Do not touch TSD

| Allowed | Forbidden |
|---------|-----------|
| Read `custom_js/TSD/tsd.js`, `com.mmm.tsd`, [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md), [TSD_MIGRATION.md](./TSD_MIGRATION.md) as **reference** | Change any file under `html_files/TSD`, `custom_js/TSD`, `com.mmm.tsd` |
| Same DB **pool** as TSD (`csd` / `dINTWSYS`) | Mix TSD SQL (`tsd_*`) into EW controllers |
| Copy **patterns** (Load/showTab, `NativeQuerySupport`, `TsdDocUpload` SMB shape) into **new** `com.mmm.ewarranty` | Reuse `TsdDocUpload`, `TsdContextResolver`, TSD session keys, `/api/customer/tsd` |

## TSD vs E-Warranty

| | **TSD** | **CSD graphic E-Warranty (this doc)** |
|--|---------|----------------------------------------|
| Legacy UI | `resources/TSD` | `resources/Ewarranty` |
| Java | `com.mmm.tsd` | `com.mmm.ewarranty` + `com.mmm.csdwarrantydocumnts` |
| INPCV2 today | Largely complete | Converter + Distributor in portal (see [EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md)); End customer / claims pending |
| Tables | `tsd_*` | `ew_*` |
| DB pool | `HibernateFactoryRegistry.CSD` / alias `TSD` → **`dINTWSYS`** | **Same pool**, different tables |
| Approvals | Backend app (portal does not approve) | **In-portal popup** (legacy EW style) |
| PDF | One TSD certificate builder | **Six family builders**, **one PDF per product** |

## Current INPCV2 position

- Warranty DB: `insba.datasources.csd` → **`dINTWSYS`**. Registry: `HibernateFactoryRegistry.CSD` (alias `TSD`). See [CSD_DATASOURCE.md](./CSD_DATASOURCE.md).
- `com.mmm.csd` is **smoke / user helpers only** — not graphic E-Warranty.
- **Phase 1 (2026-10-06):** Converter + Distributor shells, Change Customer, request lists (Claims / Manage Customers hidden). Converter **Request New Warranty**:
  - **PPF:** legacy columns + Product 1 tables; multi-row film; Segment Leader; mount photos/PDF.
  - **Graphics:** all 6 `Warranty Template` host matrices; Dist→Converter invoice fragment; `assignTabsForProducts` (Swal confirm); per-slot header colors; product body = Project → Substrate → POI → Primary/Secondary Film → Overlaminate → Printing → Warranty Life; cascade with field loaders/errors; GCM includes `NA`; BWF/DI-NOC hide; **save metadata** for header/vinyl/sec/substrate/overlam/POI/addnl invoice.
- Living map: [EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md).
- Pending: graphics **file upload to mount** (invoice / POI pictures), approve actions, dist-agree upload UX, claims, end customer.

---

## Workflow and usage

### Personas (all in scope)

| Persona | Legacy shell | Active tabs | Role |
|---------|--------------|-------------|------|
| **Converter** | `ewarrantyconv.html` + `ewarrantyconv.js` | Warranty Requests, Request New Warranty, Claims, Manage Customers | Create/edit requests; list; customers; claims; open approval popup |
| **Distributor** | `ewarrantydist.html` + `ewarrantydist.js` | Warranty Requests, Claims | List/approve; **3M→Distributor invoice** docs; claims. **No** new-request tab |
| **End customer** | `WarrantyEndCust.html` + `ewarrantyEndCust.js` | Warranty Requests, Manage End Customers | View requests; manage end customers |

Commented-out nav still has HTML: applicators, converters, warranty deviation. Document them; build only if still required.

### Happy path

```mermaid
flowchart TD
  ConvCreate[Converter Request New Warranty]
  PickTemp[Pick wrty_template]
  FillProducts[Product pages hide show]
  Save[SaveEWNewRequest]
  List[Conv and Dist lists]
  Popup[EWReqPopup view approve]
  Chain[Approval matrix]
  Closed[Status Closed]
  Pdf[PDF per product]
  ConvCreate --> PickTemp --> FillProducts --> Save --> List --> Popup --> Chain --> Closed --> Pdf
```

1. Converter opens Request New Warranty and picks `wrty_template` (PPF / BWF / Di-NOC / MCS Printed / MCS Colored & Signage / Special Graphics).
2. UI loads **PPF screens** or shared product slots 1–5 with **hide/show**; cascading LOVs / autocompletes fill child fields.
3. Save via `EWReqWarranty/SaveEWNewRequest` (draft or submit) plus attachments.
4. Lists: Converter `EWConvertor/GetWarrantyRequestsByConvertor`; Distributor `EWDistributor/GetWarrantyRequestsForDist`; End customer `EWEndCustomer/GetWarrantyRequestsForEndCust`.
5. Open row → `EWReqPopup.ViewRequestData` (PPF popup HTML vs product 1–5 popups).
6. Approve / Reject in-portal: `EWReqPopup/UpdateApprovalPopUpData`. Distributor must upload agreement docs before Approve (`SaveDistAgreeDocs`). Status text such as **Pending With Distributor**; matrix uses `pending_with_type` / `pending_with_role`.
7. When **Closed**, each product tab: **Download Warranty Certificate** → PDF for that `prod_ref_code`.
8. Parallel: Claims (raise / list / claim popup). Deviation and masters later if still live.

---

## HTML modules (different pages per product + hide/show)

### Parent shells

| Shell | File | Router |
|-------|------|--------|
| Converter | `html/ewarrantyconv.html` | `CallProperModuleOnClick` `.load()` into tab divs |
| Distributor | `html/ewarrantydist.html` | Same pattern |
| End customer | `html/WarrantyEndCust.html` | Requests + manage end customers |

### Feature fragments (`html/`)

| File | Use |
|------|-----|
| `ew_conv_warranty_requests.html` | Converter list |
| `ew_dist_warranty_requests.html` | Distributor list |
| `ew_conv_request_new_warranty.html` | New/edit host (`#warr_temp`, product slot panels) |
| `ew_conv_manage_cust.html`, `ew_conv_req_new_cust.html` | Customers |
| `ew_claims.html`, `ew_raise_claim.html`, `ew_claim_popup.html` | Claims |
| `ew_my_approval_popup.html`, `ew_req_popup.html` | View/approve |
| `ew_dist_cust_graphics_invoice_details.html` | Non-PPF distributor invoice block |
| `warranty_end_cust_requests.html`, `manage_end_customers.html` | End customer |
| `ew_manage_applicators.html`, `ew_req_new_applicator.html` | Applicators (nav often commented) |
| `ew_manage_converters.html`, `ew_req_new_converter.html` | Converter master (dist) |
| `ew_warranty_deviation.html`, `ew_req_new_warr_deviation.html`, `ew_deviation_popup.html` | Deviation |

### Product pages

| HTML | When |
|------|------|
| `ew_req_product_1.html` … `ew_req_product_5.html` | Create/edit slots for **non-PPF** families |
| `ew_req_product_1_pop_up.html` … `ew_req_product_5_pop_up.html` | View popup slots (non-PPF) |
| **`ew_req_ppf_product1.html`** | **PPF-only** create/edit (single product) |
| **`ew_req_product_1_ppf_pop_up.html`** | **PPF-only** view popup |

**Slot show/hide:** `HandleProductsTabs` / `HandleProductsTabsPopup`; `EWReqWarranty.AssignTabsForProducts` shows `#product_li_1`…`N` from `no_of_products` (confirm if changing: *All entered Product Details will be deleted…*). PPF forces **1** product and hides `#no_of_products_div`.

**INPCV2:** `EwNewRequest.assignTabsForProducts(askConfirm)` on `#ew_no_of_products` change + template switch; tabs `Graphic ElementN / SignageN`.

**Family show/hide:** `#warr_temp` → `EWReqWarranty.ActionsOnChangeWarrantyTemplate` (all 6 lookup values)

| Template | Host | Product |
|----------|------|---------|
| MCS Warranty-Printed | Dist + Segment Leader + No. of products + Print Service; Address default; invoice fragment | Full graphics sections + color |
| MCS Warranty-Colored & Signage | same as MCS Printed | same as MCS Printed |
| Special Warranty - Graphics | same as MCS Printed | same as MCS Printed |
| Building Window Film Warranty | same host as MCS (Print Service **shown**) | `HideForBuildingOrDiNoc` + BWF labels; Application Substrate **stays** |
| Paint Protection Film | Applicator; Vehicle; hide Dist/invoice/print/multi-product | `ew_req_ppf.html` |
| DI-NOC Warranty | Dist + Segment Leader; **hide** No. of products + Print Service; tab “Di-Noc Installation” | same hide as BWF + DI-NOC labels |

**Non-PPF template change (legacy `ActionsOnChangeWarrantyTemplate`):** shows distributor; loads [`ew_dist_cust_graphics_invoice_details.html`](../src/main/resources/static/html_files/EWARRANTY/ew_dist_cust_graphics_invoice_details.html) into `#ew_dist_invoice_host`; product tabs = Graphic Element N / Signage N (or Di-Noc Installation); product body matches `ew_req_product_1.html` section order (Project → Substrate → Proof Of Installation → Primary Film → Secondary Film → Overlaminate → Printing → Warranty Life + Recheck).

**Vinyl rows:** legacy `AddVinylGroupRow` / `GetVinylGroupObj` apply to **all** families (not PPF-only). Extra rows copy+disable film; color / unique-lot / secondary film visibility is template-driven. INPCV2: PPF lines in `ew_req_ppf.html`; graphics multi-line primary (+ secondary where shown) in `ew_req_products.html`.

INPCV2 must keep **separate PPF screens** and template-driven hide/show — not one undifferentiated form.

**INPCV2 mapping (2026-10-06):** `#m_ew_new_request.is-ppf` toggles CSS (`.ew-nr-ppf` / `.ew-nr-gfx`). Host has billing + Applicator/Store + Segment Leader + Installation. `#ew_dist_invoice_host` loads graphics invoice on non-PPF. `ew_req_ppf.html` = PPF Product 1 tables. `ew_req_products.html` = legacy product section order + multi-row film; Project/Printing use `.ew-ppf-block-body` for closed borders. `assignTabsForProducts` = legacy `AssignTabsForProducts` (Swal confirm).

---

## Cascading filters, autocompletes, dependent dropdowns

### Cascade (non-PPF product slots 1–5)

`EWReqWarranty.GetCascadingFilterValues` → POST `EWReqWarranty/GetCascadingFilterValuesAjax` against **`ew_warranty_life`** → `FormFilteredCascadingLov` (replace options; auto-select + recurse if one real value). Downstream fields cleared each step.

Chain (per product):  
`fin_prod_info_app` → `graphic_conv_method` → `type_of_exposure` → `substrate_1` → `m_flexible_substrate_1` → `vinyl_1` → `overlaminate_1` → `printer_format` → `printing_hardware` → `ink_1`  
(`sec_vinyl_1` can feed overlaminate; `CalculateWarrantyLife` on substrate/ink.)

**INPCV2 (2026-10-06):** `POST /api/customer/ewarranty/new-request/cascade` + `/warranty-life`. UI: spinner on target field each request; errors beside the field (`.ew-nr-ac-error`). **GCM step** matches legacy `GetJsonArrayforCascading(fin_prod_info_app)` — filter by `warranty_type` only (no Application) so LOV can include **`NA`**; client also injects `NA` if missing.

**PPF:** no this cascade; `AssignProductMasterValues` / `AssignApplicationLookupValues` + vinyl AC.

### Autocompletes (`EWCommon`)

| Field | Endpoint |
|-------|----------|
| Distributor | `GetDistributorAutoComplete` — **INPCV2:** `ew_converter_distributor_mapping` has no `warranty_type`; filter by converter + phrase only |
| Customer | `GetCustomerAutoComplete` (+ `getProjectListForCustomer`) |
| Applicator | `GetApplicatorAutoComplete` |
| End customer | `GetEndCustomerAutoComplete` |
| Segment leader | `GetSegmentLeaderAutoComplete` |
| Vinyl / sec vinyl | `GetVinylAutoComplete` (filter JSON from cascade) |
| Vinyl color | `GetVinylColorAutoComplete` |
| Claims / deviation | warranty req id, AE quality, product, tech head |

AC/DB failures: show beside the input (not only page banner).

### Other populate-on-select

- Onload: `GetWarrReqScreenOnloadData` → lookup / product master arrays filtered by `wrty_template`
- `#warr_temp` / `#no_of_products` → tabs + LOVs
- `#asm_kam_approver` → `#segment_leader`
- `#proj_no` → `GetProjectDetails`
- State: `GetStateLOVData`

---

## Customer / Change Customer

Same portal logic as TSD/CIR/Rebate. See [getCustomer.md](./getCustomer.md) and [CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md).

**JS (every EW call, including Load):** `Common.GetProcedureCustomerContext()` → `custCode` + `loginId`. Labels: `GetCustCode` / `GetCustName`. Empty params = logged-in session.

**Java (every EW API):** `UserSessionSupport.resolveProcedureCustomerContext(session, custCode, loginId)`

1. Change Customer override if active  
2. Else login `cust_code`

Then map that customer onto **EW masters** (`ew_convertor` / `ew_distributor` / end customer) — **server** sets persona + `internal_code`. Never trust browser `convIntCode` / `DistCode` / `$g_source_int_code`. Do **not** reuse `tsd_conv_*` session keys; EW uses `EwContext`.

---

## Legacy API inventory

| Controller | Actions |
|------------|---------|
| `/EWConvertor` | `GetEWConvOnloadData`, `GetWarrantyRequestsByConvertor` |
| `/EWDistributor` | `GetDistOnloadData`, `GetWarrantyRequestsForDist` |
| `/EWEndCustomer` | `GetEWEndCustOnloadData`, `GetWarrantyRequestsForEndCust` |
| `/EWReqWarranty` | `GetWarrReqScreenOnloadData`, `GetWarrReqScreenEditData`, `SaveEWNewRequest`, `GetProjectDetails`, `CalculateWarrantyLife`, `GetCascadingFilterValuesAjax` |
| `/EWReqPopup` | `GetApprovalDetailsForPopup`, `UpdateApprovalPopUpData`, `SaveDistAgreeDocs`, `HardDeleteDistAgreeDoc` |
| `/EWCommon` | State, project list, all autocompletes, `GetBalancePPFQuantity` |
| `/EWCustomer` | Customer onload/save/view, contact groups |
| `/EWApplicator` | Applicator onload/save/view |
| `/EWConverterMasterSetup` | Converter master onload/save/view |
| `/EWClaims` | Raise-claim onload, list, warranty-for-claim, `SaveNewClaimRequest` |
| `/EWClaimPopup` | Claim approval get/update |
| `/EwDeviation` | Deviation onload/list/save |
| `/EWDeviationPopup` | Deviation approval get/update |
| `/ew_doc_upload` | `DownlodEWFilesFromServer` |
| `titpl/edr_doc_upload` | Legacy download duplicate |
| `/DownloadEWPDFAdmin` | `DownloadEWarrantyPDF` |

INPCV2 API base (target): **`/api/customer/ewarranty/...`**.

---

## Tables (representative)

Same SQL Server **`dINTWSYS`**. No DDL from app code.

| Area | Tables |
|------|--------|
| Header / products | `ew_new_request_header`, `ew_new_request_vinyl`, `ew_new_request_sec_vinyl`, `ew_new_request_subs_lot_no`, `ew_new_request_overlam_lot_no`, `ew_new_request_proof_inst` |
| Approval | `ew_new_request_approval_matrix` |
| Docs | `ew_new_request_conv_cust_inv_details`, `ew_new_request_addnl_inv_details`, `ew_new_request_dist_agree_doc` |
| Life / masters | `ew_warranty_life`, `ew_product_master`, `ew_convertor`, `ew_distributor`, `ew_applicator` |
| Claims | `ew_claim_*` attachment / request tables |
| Deviation | `ew_deviation_*` |

---

## PDF — one certificate per product

UI (Closed): `EWReqPopup.DownloadEwarrPDF(prod_ref_code)` →  
`GET DownloadEWPDFAdmin/DownloadEWarrantyPDF?intCode={header}&prod_ref_code={1..n}`

Dispatcher reads header **`wrty_template`**, then family builder. Line data filtered by `prod_ref_code`. Images: `resources/Ewarranty/csd_images/{PPF,BWF,DiNOC,MCS,SpecialWarranty,Common}`. Legacy stack: iText 5.

| `wrty_template` | Class |
|-----------------|-------|
| Special Warranty - Graphics | `DownloadEWPDF_PG` |
| MCS Warranty-Printed | `DownloadEWPDF_MCS_Printed` |
| MCS Warranty-Colored & Signage | `DownloadEWPDF_MCS_Non_Printed` |
| Building Window Film Warranty | `DownloadEWPDF_BWF` |
| Paint Protection Film | `DownloadEWPDF_PPF` (legacy hardcodes slot `"1"` — matches single-product PPF UI) |
| DI-NOC Warranty | `DownloadPDF_DiNOC` |

Shared SQL: `DownloadEWPDFCommon`.

**INPCV2:** `GET /api/customer/ewarranty/{converter|distributor}/requests/{id}/products/{prodRefCode}/warranty-pdf` — `EwWarrantyPdf` dispatches by exact `wrty_template`; PPF → `EwWarrantyPdfPpf`; graphics → `EwWarrantyPdfGraphics` (Family enum). Assets: `classpath:ewarranty/images/`. Do **not** call `TsdWarrantyPdf`.

| `wrty_template` | INPCV2 builder | Cover | Last page(s) | Filename prefix |
|-----------------|----------------|-------|--------------|-----------------|
| Paint Protection Film | `EwWarrantyPdfPpf` | `PPF/*` (product-based) | `PPF/*` terms | `PPF_warranty_certificate` |
| Special Warranty - Graphics | `EwWarrantyPdfGraphics` SPECIAL | `SpecialWarranty/sp_first_page.jpg` | `sp_last_page.jpg` | `Special_Warranty_Graphics` |
| MCS Warranty-Printed | MCS_PRINTED | `MCS/mcs_first_page_printed.jpg` | `mcs_printed_last_page.jpg` (+ `mcs_logo.png`) | `MCS_Printed_warranty` |
| MCS Warranty-Colored & Signage | MCS_COLORED | `MCS/mcs_car.jpg` | `mcs_last_page.jpg` (+ `mcs_logo.png`) | `MCS_Non_Printed_warranty` |
| Building Window Film Warranty | BWF | `BWF/bwf_page1.jpg` | `bwf_page_last.jpg` | `BuildingWindowFilmWarranty` |
| DI-NOC Warranty | DINOC | `DiNOC/di_noc_first_page.png` | `di_noc_last_page.png` | `Di_NOC_warranty` |

---

## Document files — mount path (no SMB)

Legacy / INPCV2: `{mount-root}/EWARANTY/{picture_path}` via `FileInputStream` (`GetImgFilesFromServer`).  
YAML: `inpc.ewarranty.mount-root` (= legacy `mmm.app.mount`). Default `\\usfile01.mmm.com\tender\TSD`. Override with `INPC_EWARRANTY_MOUNT_ROOT`. Console prints `new_path....`. **DB = metadata only**.

| Area | Groups | Metadata |
|------|--------|----------|
| New request | `ctc_docs`, `addnl_docs`, POI pictures | `ew_new_request_conv_cust_inv_details`, `ew_new_request_addnl_inv_details`, `ew_new_request_proof_inst` |
| Approval | `dist_agree_docs` (required before Approve) | `ew_new_request_dist_agree_doc` |
| Claims | failure photos + supporting | `ew_claim_request_attachment_dtl`, `ew_claim_request_supp_doc_dtl` |
| Later | converter/applicator/deviation | `ew_convertor`, `ew_applicator*`, `ew_deviation_*` |

Path shapes: `{year}/{month}/{requestNo}/…` for request docs; buckets `CLAIMS_DOC`, `CONVERTER_DOC`, etc.

**INPCV2 files:**

- Read: `EwFileStore` — YAML mount only; no SMB / CMW010S.
- Own class — never `TsdDocUpload`. Upload write path still pending (same mount join when built).
- Download: authenticated GET stream; no mount paths in the browser.

---

## Java / JS coding standards (INPCV2)

Follow TSD structure and:

- [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) — `Load` → context → `showTab` → `.load()` once → `Common.DataTable`; parent `m_ew_*_home`; `Module._$home()` / `Module._$("#id")`
- [Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md)
- [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md) — `NativeQuerySupport`, `HibernateFactoryRegistry.CSD`
- Dates: framework picker `dd/mm/yyyy` (`CallTarkaDatePickerNew`); never `<input type="date">`
- Loader: `showLoader` / `hideLoader` from `js/inpc_loader.js`; cascade/AC also use `EwCommon.ensureAcLoader` on the field
- Destructive confirms: SweetAlert2 (`Swal.fire`), not `window.confirm`
- Dark mode + mobile (≤767px) on shells, tabs, cards, modals, grids

**Plain Java, non-DDL, no wrapper layers:**

- Flat `com.mmm.ewarranty` (PDF builders in same package)
- No `dao` / `dto` / `repository` packages; no DTO/parameter-builder wrappers; no interface→impl for its own sake
- Local variables → bound `?` SQL in column order
- **Transaction:** `begin` → header/details/docs/history → **commit**. Any error → **rollback** (no partial data) + `ResponseDataGeneric` failure shown in UI
- No CREATE/ALTER/DROP from application code

---

## Target folder structure

### Java

```
src/main/java/com/mmm/ewarranty/
  EwContext.java
  EwConvertor.java
  EwDistributor.java
  EwEndCustomer.java
  EwReqWarranty.java
  EwCascading.java          # or methods on EwReqWarranty
  EwReqPopup.java
  EwCommonLov.java
  EwClaims.java
  EwCustomer.java
  EwMail.java
  EwDocUpload.java          # mount write (pending) — same as EwFileStore
  EwRequestsSql.java
  pdf/
    EwWarrantyPdf.java           # dispatch by wrty_template
    EwWarrantyPdfSql.java        # header / vinyl / gfx / proof / signatory
    EwWarrantyPdfPpf.java
    EwWarrantyPdfGraphics.java   # BWF / DiNOC / MCS / Special (Family enum)
```

### HTML `html_files/EWARRANTY/` (built)

```
ew_conv_home.html          # m_ew_conv_home
ew_dist_home.html          # m_ew_dist_home
ew_requests.html
ew_new_request.html        # m_ew_new_request; is-ppf; #ew_dist_invoice_host
ew_req_products.html       # graphics slots 1–5 (legacy section order)
ew_req_ppf.html            # PPF Product 1 (legacy table layout)
ew_dist_cust_graphics_invoice_details.html  # non-PPF Dist→Converter invoice
ew_req_popup.html
```

Later (not built): end-customer home, claims, manage customers.

### JS `custom_js/EWARRANTY/` (built)

```
ew_conv.js
ew_dist.js
ew_common.js               # date picker container:body; openModuleDate
ew_new_request.js          # ActionsOnChangeWarrantyTemplate + AssignTabsForProducts
ew_req_popup.js
csd_autocomplete.js        # list filters: show code-name, query code
```

### Key JS entry points (legacy → INPCV2)

| Legacy | INPCV2 |
|--------|--------|
| `EWReqWarranty.ActionsOnChangeWarrantyTemplate` | `EwNewRequest.onTemplateChange` (+ `loadGraphicsInvoice`) |
| `EWReqWarranty.AssignTabsForProducts` | `EwNewRequest.assignTabsForProducts(askConfirm)` |
| `HandleProductsTabs` | `EwNewRequest.activateSlot` |
| `EWReqWarranty.AddVinylGroupRow` | `addPpfLine` / `addGfxVinylLine` (copy+disable; no fill-before-add) |
| `EWReqWarranty.ChangeLabelsBasedOnWarranty` / `HideForBuildingOrDiNoc` | `EwNewRequest.applyFamilyLabels` |
| `GetCascadingFilterValues` / `CalculateWarrantyLife` | `/cascade`, `/warranty-life` + `cascadeField` / `calcLife` |
### PDF images

`static/images/EWARRANTY/csd_images/{Common,PPF,BWF,DiNOC,MCS,SpecialWarranty}/`

### Shells

| Persona | Home id | Entry |
|---------|---------|-------|
| Converter | `m_ew_conv_home` | `EwConv.Load()` |
| Distributor | `m_ew_dist_home` | `EwDist.Load()` |
| End customer | `m_ew_endcust_home` | `EwEndCust.Load()` |

---

## Phased build (coding later)

1. Converter + Distributor shells, lists, Change Customer / `EwContext` — done
2. New request: template switch, PPF vs shared product HTML, hide/show, cascade + AC, save — **PPF done**; **Graphics UI + metadata save done (2026-10-06)** — mount **file upload** for invoice/POI still pending
3. Approval popup (view done) + dist agreement docs upload (mount) — download API done; approve / dist-agree UX pending
4. Warranty PDF per product — **done** (all 6 templates when Closed; `EwWarrantyPdfGraphics` + popup `canPdf = closed`)
5. End customer shell + list
6. Claims
7. Masters / deviation if still required
8. Mail (legacy `SendEWMail`)

Keep [EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md) updated when APIs or files change.

---

- Risks: PPF is a **separate UI** and PDF path (single product tab; multi vinyl lines under `prod_ref_code=1`). Dist Approve blocked until 3M→Distributor invoice uploaded. Legacy `GetBalancePPFQuantity` short-circuits — confirm before porting. Do not conflate with TSD.