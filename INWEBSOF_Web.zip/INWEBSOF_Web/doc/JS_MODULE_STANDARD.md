# JS module standard (plain jQuery)

**Standing rule for all new portal module UI code.**  
Reference implementation: `src/main/resources/static/custom_js/TSD/tsd.js`  
Related: [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md), [TSD_SYSTEM.md](./TSD_SYSTEM.md)

Do **not** add heavy helpers (load-seq counters, module-tab refresh hooks, layered wrappers beyond the required home scope below) unless an existing module already requires them and you are only patching that module.

---

## Base flow (copy this shape)

```
1. Load            → get customer → bind tab clicks
2. loadContext     → $.ajax /context   (if the module has context)
3. showTab         → show / hide panels
4. .load()         → HTML fragment once per tab
5. loadRequests    → $.ajax /list      → Common.DataTable
```

| Step | What to do | Example (TSD) |
|------|------------|---------------|
| **Load** | Read customer (`Common.GetProcedureCustomerContext` / `GetCustCode`), reset “html loaded” flags, bind tab click handlers | `Tsd.Load` |
| **loadContext** | One `$.ajax` GET for module context (optional for modules that need none) | `Tsd.loadContext` → `/api/customer/tsd/context` |
| **showTab** | Toggle `aria-selected` + `d-none` on panels only | `Tsd.showTab` |
| **.load() once** | `$panel.load(html_files/...html)` first time; skip if fragment already in DOM | `Tsd.openRequestsTab` |
| **load list** | `$.ajax` list API → map rows → `Common.DataTable.init` / `setData` | `Tsd.loadRequests` |

---

## Multi-tab parent shell (required)

Portal tabs can keep several modules (or copies) in the DOM at once, so **duplicate ids collide** if you use bare `$("#id")` / `document.getElementById`.

| Rule | Detail |
|------|--------|
| **Parent id** | Shell root is always `m_<module>_home` (examples: `m_tsd_home`, `m_cir_home`, `m_ew_conv_home` / `m_ew_dist_home`). |
| **All HTML under parent** | Tabs, panels, forms, modals, messages — nest under that parent (or fragments loaded into panels under it). |
| **Scoped get/set** | Read/write with `$home.find("#id")` via small helpers `Module._$home()` / `Module._$(selector)` — never bare `$("#my_field").val()` for module fields. |
| **Id prefix** | Prefer module-prefixed ids (`tsd_…`, `my_…`) under the parent; still scope lookups through `_$`. |
| **Popup host on body** | If modals move to `document.body` (fixed positioning), use one host (e.g. `m_<module>_popup`) and **remove duplicate hosts** on Load when the menu reloads HTML — otherwise stale totals/fields can stick across opens. Reference: Rebate `_scrubOrphanPopups` / `_claimContent$`. |

Required helpers (keep them short — same shape as TSD/CIR):

```javascript
_$home: function () {
	try {
		if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
			var $pane = InpcTabs.$activePane();
			var $inPane = $pane && $pane.find ? $pane.find("#" + MyModule.HOME) : $();
			if ($inPane && $inPane.length) {
				return $inPane.first();
			}
		}
	} catch (ignore) { /* fall through */ }
	var $visible = $("#" + MyModule.HOME).filter(":visible");
	if ($visible.length) {
		return $visible.first();
	}
	return $("#" + MyModule.HOME).first();
},

_$: function (selector) {
	var $home = MyModule._$home();
	if (!$home.length) {
		return $(selector);
	}
	if (!selector) {
		return $home;
	}
	var $found = $home.find(selector);
	return $found.length ? $found : $(selector);
}
```

Usage:

```javascript
MyModule._$("#my_list_tab").on("click", …);
MyModule._$("#my_field").val(x);
var v = MyModule._$("input[name='my_radio']:checked").val();
var el = MyModule._$("#my_modal").get(0);
```

---

## Skeleton (new module)

```javascript
MyModule = {
	API: "api/customer/my-module",
	HOME: "m_my_module_home",
	TABLE_ROOT: "m_my_module_table_root",
	custCode: "",
	loginId: "",
	listHtmlLoaded: false,

	_$home: function () {
		try {
			if (window.InpcTabs && typeof InpcTabs.$activePane === "function") {
				var $pane = InpcTabs.$activePane();
				var $inPane = $pane && $pane.find ? $pane.find("#" + MyModule.HOME) : $();
				if ($inPane && $inPane.length) {
					return $inPane.first();
				}
			}
		} catch (ignore) { /* fall through */ }
		var $visible = $("#" + MyModule.HOME).filter(":visible");
		if ($visible.length) {
			return $visible.first();
		}
		return $("#" + MyModule.HOME).first();
	},

	_$: function (selector) {
		var $home = MyModule._$home();
		if (!$home.length) {
			return $(selector);
		}
		if (!selector) {
			return $home;
		}
		var $found = $home.find(selector);
		return $found.length ? $found : $(selector);
	},

	Load: function () {
		var ctx = Common.GetProcedureCustomerContext
			? (Common.GetProcedureCustomerContext() || {})
			: {};
		MyModule.custCode = String(ctx.custCode || Common.GetCustCode() || "").trim();
		MyModule.loginId = String(ctx.loginId || "").trim();
		MyModule.listHtmlLoaded = false;

		MyModule._$("#my_list_tab").off("click").on("click", function () {
			MyModule.showTab("list");
		});
		MyModule._$("#my_other_tab").off("click").on("click", function () {
			MyModule.showTab("other");
		});

		MyModule.loadContext(function () {
			MyModule.showTab("list");
		});
	},

	showTab: function (name) {
		var isList = name !== "other";
		MyModule._$("#my_list_tab").attr("aria-selected", isList ? "true" : "false");
		MyModule._$("#my_other_tab").attr("aria-selected", isList ? "false" : "true");
		MyModule._$("#my_list_panel").toggleClass("d-none", !isList);
		MyModule._$("#my_other_panel").toggleClass("d-none", isList);
		if (isList) {
			MyModule.openListTab();
		} else {
			MyModule.openOtherTab();
		}
	},

	openListTab: function () {
		if (MyModule.listHtmlLoaded && MyModule._$("#m_my_list").length) {
			return;
		}
		var url = (window.$app_url || "") + "html_files/MY/my_list.html?r=" + Date.now();
		showLoader("Loading...", MyModule.HOME);
		MyModule._$("#my_list_panel").load(url, function (_html, status) {
			hideLoader(MyModule.HOME);
			if (status !== "success") {
				return;
			}
			MyModule.listHtmlLoaded = true;
			MyModule.initTable();
			MyModule.loadList();
		});
	},

	loadContext: function (done) {
		$.ajax({
			url: (window.$app_url || "") + MyModule.API + "/context",
			method: "GET",
			data: { custCode: MyModule.custCode, loginId: MyModule.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			/* check errorCode / session; then */
			if (typeof done === "function") {
				done();
			}
		});
	},

	loadList: function () {
		showLoader("Loading...", MyModule.HOME);
		$.ajax({
			url: (window.$app_url || "") + MyModule.API + "/requests",
			method: "GET",
			data: { custCode: MyModule.custCode, loginId: MyModule.loginId },
			dataType: "json",
			xhrFields: { withCredentials: true }
		}).done(function (json) {
			/* map rows → Common.DataTable.setData(MyModule.TABLE_ROOT, rows) */
		}).always(function () {
			hideLoader(MyModule.HOME);
		});
	}
};
```

Home HTML: root `<section id="m_my_module_home">…</section>` (modals included), then call `MyModule.Load()` after insert (menu `js_path` loads the script). **Do not** start the load from `MainPage.js`.

---

## Must / must not

| Must | Must not |
|------|----------|
| Plain jQuery (`$`, `$.ajax`, `.load`, `.on`) | Heavy CIR-only extras (load-seq counters, module-tab refresh hooks) on **new** modules |
| Shell id `m_<module>_home`; all module HTML under it | Orphan modals/fields outside the parent shell |
| `Module._$("#id")` / `_$("input[name=…]")` for get/set | Bare `$("#id").val()` / `document.getElementById` for module fields |
| `Common.DataTable` for grids | Hand-built search / pager |
| Load each HTML fragment **once**; Refresh re-calls the list API | Reload HTML on every tab click |
| Pass `custCode` / `loginId` from `GetProcedureCustomerContext` when Change Customer applies | Trust a raw DistCode from the client for server scope |
| Keep function names readable (`Load`, `showTab`, `loadList`) | Opaque indirection beyond `_$home` / `_$` |
| **Loader** — shared `showLoader` / `hideLoader` from `js/inpc_loader.js` | Custom module spinners, inline “Loading…” HTML, or table overlay loaders |
| **Dark mode** via `html[data-theme-mode="dark"]` (shell, panels, modals, buttons) | Light-only hard-coded colors with no dark overrides |
| **Mobile** ≤767px: wrap headers, scrollable tabs, full-width modal actions, horizontal table scroll | Desktop-only fixed widths that clip on phone |
| **Dates** — framework picker (`dd/mm/yyyy`) like CIR / Rebate / COA | Native `<input type="date">` |

### Loader (required)

Use the shared INPC loader only (`src/main/resources/static/js/inpc_loader.js`) — same as TSD / CIR / Rebate.

```javascript
showLoader("Loading requests...", MyModule.HOME);   // or a panel / modal id
// … $.ajax / .load …
hideLoader(MyModule.HOME);
```

| Rule | Detail |
|------|--------|
| **API** | `showLoader(message, targetId)` / `hideLoader(targetId)` — always pair them (`complete` / `.always` / `.load` callback). |
| **Target** | Prefer the module home (`m_<module>_home`) for page-level work; use the panel or modal id when the wait is scoped (e.g. claim modal, detail content). |
| **Helpers** | Optional thin wrappers `_showLoader` / `_hideLoader` that call the globals (TSD/CIR/Rebate style) are fine. |
| **Must not** | Custom CSS spinners, “Loading…” row HTML, or module-only overlay loaders for ajax / `.load` waits. |

Reference: `Tsd.loadRequests`, `Cir._showLoader`, `RebateProgram._showLoader`.

### Dates (required)

Always use the shared Bootstrap Datepicker pattern (same as CIR, Rebate, COA, Account Status).  
On the server, convert UI `dd/mm/yyyy` with `com.mmm.titpl.CommonFunctions.sqlDate` before writing SQL datetime columns (never send slash dates raw).

HTML pattern:

```html
<div class="input-group input-group-sm">
  <input type="text" id="my_date" class="form-control form-control-sm date date-picker"
    placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" autocomplete="off">
  <span class="input-group-text">
    <i class="ri-calendar-2-line text-primary fs-15" role="button" style="cursor:pointer;"
      onclick="all_obj.CallTarkaDatePickerNew('my_module','my_date')"></i>
  </span>
</div>
```

After HTML load (and after any dynamic fields are injected), call `initDatePickers($root)` or bind `.datepicker({ format: "dd/mm/yyyy", container: "body", ... })`. Do **not** use browser native date inputs. Do **not** put `readonly` on the date field — `CallTarkaDatePickerNew` returns immediately when the input is readonly, so the calendar never opens. If the field sits in a panel with `overflow:auto`, set datepicker `container: "body"` (or the dropdown is clipped).

---

## Autocomplete loader (required)

Every AJAX autocomplete must show the shared **`ac_loader`** spinner while the request is in flight (same as Change Customer / TSD).

HTML:

```html
<div class="position-relative inpc-ac-field-wrap">
  <input id="my_ac" class="form-control pe-4 ac_loader" autocomplete="off">
  <span id="my_ac_ac_spinner" class="inpc-ac-spinner ac_loader" role="status" aria-hidden="true" hidden>
    <span class="spinner-border spinner-border-sm text-primary"></span>
  </span>
</div>
```

JS: `Common.ShowAcSpinner(homeSelector, spinnerId)` at the start of `source`, `Common.HideAcSpinner` in `.always()`. E-Warranty helper: `EwCommon.ensureAcLoader($txt)` (adds wrap + spinner if missing) then `showAcLoader` / `hideAcLoader`. Use the same spinner helper for cascading LOV / warranty-life AJAX on the target field. AC, cascade, and SQL failures that belong to one input: show beside that field (e.g. `.ew-nr-ac-error`), not only the page banner.

Destructive confirms (e.g. changing product count clears entered data): prefer **SweetAlert2** (`Swal.fire`) over `window.confirm`.

Do **not** ship an autocomplete that only uses the jQuery UI `ui-autocomplete-loading` class — users must see `ac_loader`.

Same responsive HTML works for phone and desktop (CIR/TSD style). Use Load Type **DeskMobile** + separate `mobile_file_name` only when the mobile layout is truly different ([DeskMobile.md](./DeskMobile.md)).

Customer context reminder: direct login, portal **Change Customer**, and (where designed) module-specific override are resolved on the **server**. JS only sends procedure customer params; see [getCustomer.md](./getCustomer.md) / module system doc.

---

## Where this applies

- All **new** modules under `custom_js/` and tabbed shells under `html_files/`
- TSD, CSD graphic E-Warranty ([EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md)), and any next customer module
- Existing heavy modules (CIR, etc.): leave as-is unless actively refactoring; new features in those modules may follow local style, but **new modules** use this standard
