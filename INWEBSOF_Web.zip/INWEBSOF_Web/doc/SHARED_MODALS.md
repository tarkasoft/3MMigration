# Shared modals (`inpc_modal_popup.html`)

Bootstrap modals used from MainPage and Framework Tools. Do **not** pile new modals into `MainPage.html`.

## Split

| Modal | Where | Why |
|-------|--------|-----|
| `#inpc_welcome_modal` | `MainPage.html` (inline) | Shell only. Body, acknowledgement, `ack_message`, `show_ack_prompt_even_acknowledged`, and `active` are in [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md). Preview (`PreviewWelcomeMessage`) fills the same modal from the form and closes with OK. |
| `#inpc_announce_modal` | `static/inpc_modal_popup.html` | Announcement detail (`Common.OpenAnnouncementPopup`) |
| `#fw_ref_pop_up_modal` | same | FW lookup (`POPUP.OpenFWPopup`) |
| `#change_customer_modal` | same | Change Customer Code |
| `#inpc_sync_layout_form_modal` | same | Sync Module Layout — params form |
| `#inpc_sync_layout_preview_modal` | same | Sync Module Layout — SQL preview (Go Back / Close / Proceed) |

## Load

`Common.LoadSharedModals()` runs **once** from `custom_js/common.js` on jQuery ready and appends the fragment to `document.body`.

Framework Tools and other modules run **after** full page load. They assume shared modals are already in the DOM and do **not** re-fetch or re-check. Welcome is the only exception and stays on MainPage.

## Cache bust

| Asset | Bump when |
|-------|-----------|
| `MainPage.html` → `custom_js/common.js?v=…` | loader / SyncModuleLayout JS changes |
| `LoadSharedModals` → `inpc_modal_popup.html?v=…` | modal markup changes |

## Related docs

- [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md)
- [Announcements.md](./Announcements.md)
- [CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md)
- [FRAMEWORK_TOOLS.md](./FRAMEWORK_TOOLS.md) — Sync Module Layout + Create Popup
