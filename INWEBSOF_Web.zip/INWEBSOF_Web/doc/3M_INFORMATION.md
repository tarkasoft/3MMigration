# 3M Information page

**File:** `html_files/INPC/3m_information.html`
**Module name:** 3m_information (dashboard HTML — skip FW schema init)

## Tab feel
Left dark **rail** with red active pill (not the old folder tabs). Content cards on the right.

## Tabs
1. NEW REBATE CLAIM PROCESS
2. New GST
3. Portal New Login Method
4. Communication Address Change
5. 3M Customer Portal Training
6. E INVOICE
7. Customer Service Enhancement (short placeholder — replace when source letter is available)
8. Cust Issue Resolution User Guide
9. Product HSN Code (sample rows — replace with official rate sheet)

## Wiring
- Load Type **Internal** (plain HTML). There is no `isDashboardModule` skip list anymore.
- `window.i3ActivateTab` is defined in `MainPage.js` (and inline) for jQuery `.load()`

Open via menu with `file_name` = `3m_information` (resolves to `html_files/INPC/3m_information.html`). Load Type Internal — no FW schema init.
