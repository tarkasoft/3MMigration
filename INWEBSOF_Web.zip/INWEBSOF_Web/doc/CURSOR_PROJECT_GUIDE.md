﻿# INWEBSOF_Web — Cursor Project Handoff Guide

> **Purpose:** Give any Cursor agent (or developer) enough context to continue work safely without rediscovering architecture, conventions, or past decisions.
>
> **Last updated:** 2026-10-06. Read [section 17](#17-status-on-1-oct-2026) before changing welcome, SQL dates, or CIR. Document I/O must use SMB 3.1.1 (section 14). CSD graphic E-Warranty is not TSD — [EWARRANTY_MIGRATION.md](./EWARRANTY_MIGRATION.md) · [EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md).
> **App:** INWEBSOF_Web (Spring Boot 3.5.16 WAR, Java 21) · context path `/inwebsof`
> **Ports:** Eclipse / embedded Tomcat `8080` (`application.yml`). JBoss EAP 8 HTTP is `standalone.xml` port **8090**.
> **Product framing:** **3M Customer Portal** — 3M provides portal access to customers. Demo customer display name is often **R.K Traders**.
> **Default app type:** `INPC` (`insba.app-type`, `window.$g_app_tye`).

Doc index: [README.md](./README.md). Update `doc/` in the same change set when behavior or structure changes.

---

## 1. What this project is

INWEBSOF_Web (formerly INPCV2) is a Java/Spring Boot modernization of a legacy **insba** ERP UI:

- **Backend:** Spring Boot 3.5.16, Java 21, Hibernate SessionFactory registry (multi-datasource), WAR for Eclipse Tomcat 10.1 and JBoss EAP 8 (Undertow). Boot 4.x needs Tomcat 11 — do not bump until the server runtime is upgraded (see `doc/DEPENDENCY_VAPT.md`).
- **Frontend:** Static HTML under `src/main/resources/static`, Bootstrap 5 + Remix icons + jqGrid + ApexCharts, shell `MainPage.html`.
- **Business UI:** DB-driven mini-framework (schema, save, edit, grids) for **Load Type = FrameWork**, plus HTML-only pages for **Load Type = Internal** (dashboards, home shells, information pages).

Do not treat this as a greenfield React app. Prefer `MainPage.js`, `MainPageNew.js`, `titpl` / `system` endpoints, and `html_files/INPC/`.

Live HTML is under **`html_files/INPC/`** and **`html_files/CUST_SERVICE/`**. There is no `html_files/Servicebilling/` tree in source. `moduleHtmlPath` still treats `SERVICEBILLING` as a sibling-root prefix so an old menu `file_name` does not get `INPC/` prepended twice.

---

## 2. Repository layout

```
INWEBSOF_Web/
├── doc/                              project docs (start here)
├── src/main/java/com/mmm/
│   ├── Inpcv2Application.java        WAR entry (ServletInitializer)
│   ├── authentication/               AuthController, AuthService, IMEXT, session interceptor
│   ├── config/                       datasources, PortalProperties, HibernateFactoryRegistry
│   ├── config/security/              SecurityConfig, IMEXT OAuth handlers
│   ├── system/                       FW generators, GetModuleDetails, menus helpers, announcements
│   ├── titpl/                        NativeQuerySupport, ResponseDataGeneric, CommonFunctions (text/sqlDate/…), theme, validation
│   ├── portal_common/                ChangeCustomer, WelcomeAck; session date is UserSessionSupport.sessionDate()
│   ├── customer/                     MyOrders, CustomerPayment, ContactUs
│   ├── csd/  cir/                    lazy remote SessionFactories + smoke APIs
│   └── web/                          HealthInfoController (/api/info)
├── src/main/resources/
│   ├── application.yml               server, datasources, IMEXT switch
│   ├── application-imext.yml         OAuth client (profile imext only)
│   ├── portal.properties             portal UI settings for the frontend
│   └── static/                       ALL front-end
│       ├── MainPage.html
│       ├── login.html / login1.html
│       ├── js/MainPage.js            menus, module load, home-by-user-type
│       ├── js/MainPageNew.js         FW schema / grid / save
│       ├── js/inpc-tabs.js           optional module tabs
│       ├── js/fw-globals.js          $host_url, $app_url, include-tabs default
│       ├── custom_js/                module scripts (common.js, CUST_SERVICE/, …)
│       └── html_files/
│           ├── INPC/                 home shells, dashboards, FW masters
│           └── CUST_SERVICE/         customer modules (my_orders, account_status, payment)
└── deploy-to-jboss                   Eclipse builder copies classes into EAP exploded WAR
```

**Workspace:** `C:\Users\A6GWBZZ\eclipse-workspace\INWEBSOF_Web\INWEBSOF_Web`

**EAP exploded WAR:** `C:\Users\A6GWBZZ\jboss-eap-8.1.0-dev\jboss-eap-8.1\standalone\deployments\INWEBSOF_Web.war` (`pom.xml` `inpc.jboss.war`, `portal.properties` `inpc.project.deploy-path`). Legacy checkout used only as a reference, never edited: `C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc`.

---

## 3. Run / deploy

| Where | URL |
|-------|-----|
| Eclipse Tomcat 10.1 | `http://localhost:8080/inwebsof/login.html` |
| JBoss EAP 8 | `http://localhost:8090/inwebsof/login.html` |
| Smoke | `/inwebsof/api/info` |

- **Static-only:** edit `src/main/resources/static/**`, then hard-refresh (Ctrl+F5). Eclipse WTP may also need a republish if `/html_files/**` 404s — see [STATIC_DEPLOY.md](./STATIC_DEPLOY.md).
- **Java / YAML / portal.properties:** restart the server. EAP auto-redeploy of classes: [AutoDeploy-JBoss.md](./AutoDeploy-JBoss.md).
- Cache bust: `MainPage.html` script tags use `?v=YYYYMMDDHHMM` — bump when changing `MainPage.js` or related shell scripts.

Maven: `mvn -DskipTests package`. `spring-boot-starter-tomcat` is `provided` for EAP.

---

## 4. Authentication and session

| Item | Detail |
|------|--------|
| Login pages | `login.html` (split panel), `login1.html` (centered card). Both post to the same API. |
| Branding | **3M Customer Portal**. Customer name is per session / portal config. |
| Login | `POST /api/auth/login` (`loginId`, `password`) then redirect `MainPage.html` |
| IMEXT bootstrap | `POST /api/auth/bootstrap-by-enl-id` (`enlId`) — same session as login |
| Logout | `POST /api/auth/logout` |
| Me / menus | `GET /api/auth/me`, `GET /api/auth/menus` |
| Package | `com.mmm.authentication` (`AuthController`, `AuthService`) |
| Local password | `insba.local-auth.password` in `application.yml` (blank = any password if the user exists, local/dev only) |
| Users | `ia_user_master` via `AuthService.loadUserByEnlId` / `bootstrapSessionByEnlId` |
| IMEXT | Off by default (`security.imext.enabled: false`, profile `imext` commented out). See [Imext.md](./Imext.md). |

Menus payload includes `cust_name`, `cust_code`, `see_other_cust_data`, `loginUserName`, `appType`, `portal`, and the welcome fields in [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md). Client cookies `fw_cust_*`, `fw_see_other_cust_data`, `fw_loginId`, `fw_login_user_type` — see [AUTHENTICATION.md](./AUTHENTICATION.md) and [CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md).

Login stores `inpc_hh` and `inpc_mm` from `dbo.inpc_configuration` (blank or missing is 0). SQL `getdate()` in Java is written as `UserSessionSupport.sessionDate()`, which is `dateadd(MINUTE, inpc_mm, dateadd(HOUR, inpc_hh, getdate()))`. The current configuration row is 10 hours and 30 minutes. There is no clock filter class.

---

## 5. Portal properties to the frontend

**File:** `src/main/resources/portal.properties`
**Import:** `application.yml` → `spring.config.import: optional:classpath:portal.properties`
**Binder:** `com.mmm.config.PortalProperties` (`prefix = portal`)
**Exposed by:** `GET /api/auth/menus` (`customerName`, `portal`, `menus`, …)

| In `portal.properties` | In Java / client |
|------------------------|------------------|
| `portal.customer-name` | `customerName` |
| `portal.portal-title` | `portalTitle` |
| `portal.extras.*` | `extras` map — no new Java field |

Current extras (2026-09-22): `theme=light`, `default-home=home_Page`, `include-tabs=false`, `tab-style=1`, `tab-icons=false`.

- Typed keys: add a field in `PortalProperties` and include it in `toClientMap()` if the UI should see it.
- Ad-hoc keys: `portal.extras.*` only.
- Header `#customer_name_display`: override cookies when `fw_customer_overridden=Yes`, otherwise menus `cust_name` / portal `customerName`.

---

## 6. MainPage shell and module loading

### Entry

- `MainPage.html` — layout, scripts, `#home_dashboard`, `#side-menu`.
- `js/MainPage.js` — menus, side menu, `moduleHtmlPath`, home-by-user-type, load types.
- `js/MainPageNew.js` — FrameWork schema / grid / save (`CallGetModuleDetailsNew`).
- `js/inpc-tabs.js` — optional tab strip when `include-tabs` is true. See [INCLUDE_TABS.md](./INCLUDE_TABS.md).

### How a menu leaf opens a module

1. Click → `onMenuClick`.
2. **Internal** (and Direct): `LoadHtmlFiles` → `moduleHtmlPath` → jQuery `.load()` into `#home_dashboard` (or the active tab pane). No schema init.
3. **FrameWork:** `getModulesDetailsNew` → HTML load, then `CallGetModuleDetailsNew`.
4. **DeskMobile:** desktop `file_name` vs `mobile_file_name` by viewport width (≤767). See [DeskMobile.md](./DeskMobile.md).

### Path resolution (`moduleHtmlPath` in `MainPage.js`)

| `file_name` | Resolves to |
|-------------|-------------|
| `ia_user_master` | `html_files/INPC/ia_user_master.html` (`$g_app_tye`, default INPC) |
| `common/foo` | `html_files/INPC/common/foo.html` |
| `INPC/foo`, `CUST_SERVICE/my_orders` | `html_files/{that path}.html` (sibling roots are not prefixed again) |
| Already `html_files/...` | left as-is (do not prefix again) |

Sibling roots: `INPC`, `CUST_SERVICE`, `CUSTOMER_SERVICE`, `SERVICEBILLING`. `..` is rejected.

Menu `data-file-name` should be the bare or sibling-relative name (`home_customer.html`, `CUST_SERVICE/my_orders`), not a second `html_files/INPC/` prefix.

---

## 7. Home by login type and landing dashboards

`MainPage.js` → `inpcHomeModuleForUserType`. User type from cookie `fw_login_user_type` / menus (`inpcGetLoginUserType`). Missing type defaults to Customer.

| Login user type | Home file |
|-----------------|-----------|
| Admin | `html_files/INPC/home_admin.html` (static landing, no dashboard tabs) |
| Customer | `html_files/INPC/home_customer.html` |
| Distributor | `html_files/INPC/home_distributor.html` |
| Customer Service | `html_files/INPC/home_customer_service.html` (static landing) |
| anything else | `home_customer.html` |

Include Tabs (off by default) still uses **one** Home tab; the HTML inside it follows this map. Full flow: [HOME_PAGES.md](./HOME_PAGES.md), short sheet: [HOME_LOGIN_TYPE.md](./HOME_LOGIN_TYPE.md).

### Landing dashboard load logic

1. `loadMasters` → menus → `openHome()` → `loadPage(moduleHtmlPath(home_*), "Home", null, "home")` into `#home_dashboard` (or Home InpcTabs pane).
2. **MainPage does not choose** `sb_dash_board_*.html`. The home shell HTML owns the tab strip.
3. Customer / Distributor / `home_Page`: tab `data-path` → `$("#home_dash_panel").load(…)`. Same path is not reloaded on re-click; Overview (`#home_tab_0`) loads on open.
4. CIR module Dashboard (`cir_dashboard.html`) is a different feature — [CIR_MIGRATION.md](./CIR_MIGRATION.md).

### Customer / Distributor / `home_Page` dashboard tabs

Overview is `html_files/INPC/home_overview.html`. Do not point Overview at root `home.html`.

| Tab | Fragment |
|-----|----------|
| 1 Overview | `home_overview.html` |
| 2 Sales | `sb_dash_board_1.html` |
| 3 Operations | `sb_dash_board_2.html` |
| 4 Accounts | `sb_dash_board_3.html` |
| 5 Sales Performance | `sb_dash_board_4.html` |
| 6 Sales Pulse | `sb_dash_board_5.html` |
| 7 Channel Sales | `sb_dash_board_6.html` |
| 8 Sales Insight | `sb_dash_board_7.html` — **customer home only** (not yet on distributor or `home_Page`) |

Aliases of boards 1–4: `Dashboard1.html` … `dashboard4.html` under `html_files/INPC/`.

Board notes: [SB_DASH_BOARD_4.md](./SB_DASH_BOARD_4.md), [SB_DASH_BOARD_5_6.md](./SB_DASH_BOARD_5_6.md), [SB_DASH_BOARD_7.md](./SB_DASH_BOARD_7.md).

- Demo / sample chart data (often 2026). ApexCharts is already on MainPage.
- Use `dd-fullwidth` so content uses the pane width.
- Prefer Remix icons (`ri-*`). Chart IDs must stay unique (`dd1_*` … `dd7r_*`).
- Fragments loaded with jQuery `.load()` should use `onclick` → a `window.*` function when listeners inside an IIFE do not bind.

`home_Page.html` has no page-header breadcrumb — tabs start under the top menu.

---

## 8. FrameWork modules (masters / transactions)

When editing FW modules (User Master, menu options, and similar):

1. Preserve framework field IDs and callbacks. Bootstrap restyles chrome only.
2. Schema / save / edit go through titpl/system endpoints and `MainPageNew.js`.
3. Grids: jqGrid + `css/jqgrid-bootstrap5.css`. MultiGrid: `css/fw-multigrid.css`.
4. Generators: Create HTML / Grid / Popup / Sync Module Layout — [FRAMEWORK_TOOLS.md](./FRAMEWORK_TOOLS.md), [HTML_CREATION.md](./HTML_CREATION.md).
5. With Include Tabs on, scope FW fields under `#m_{file_name}`.
6. Autocomplete / FW popup: `popup_new.js` + Bootstrap modal on MainPage.
7. Reference UI: `doc/sunstar_dev`.

Do not invent new ID schemes for FW forms without a schema plan.

**Load Type = Internal** pages (home, dashboards, `3m_information`, `account_status`, `sb_tab`, `my_orders`) do not call `CallGetModuleDetailsNew`. Optional page JS is the menu `js_path` (example: `custom_js/CUST_SERVICE/my_orders.js`). The HTML page script starts the load. MainPage does not.

**New module JS standard (global):** plain jQuery only — `Load` → get customer → bind tabs → `loadContext` (`$.ajax`) → `showTab` → `.load()` HTML once → list `$.ajax` → `Common.DataTable`. Reference `custom_js/TSD/tsd.js`. Docs: [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md), [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md). Cursor rule: `.cursor/rules/js-module-standard.mdc`.

---

## 9. Data access (Hibernate)

See [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md).

- Preferred Map reads: `NativeQuerySupport.executeQuery` (no scalars).
- Shared helpers: `com.mmm.titpl.CommonFunctions` (`text`, `sqlDate`, `longVal`, `intVal`, `capitalize`) — prefer `import static com.mmm.titpl.CommonFunctions.*` over private copies per class.
- After native INSERT, prefer lookup by business key (`req_id`, etc.) for identity — `SCOPE_IDENTITY()` is unreliable across separate `NativeQuerySupport` JDBC statements.
- Sessions: Spring-bound `withSession` — do not store a `Session` on a field. SessionFactories are singletons.
- Config: `insba.datasources.*` and `insba.menu-datasources` in `application.yml` (`InpcDatasourceProperties`).
- Registry: `HibernateFactoryRegistry.getSessionFactoryForMenu(menuKey)`.
- Named factories: `system` and `infoapps` (eager); `as400`, `as400ind`, `cir`, `csd`, `pos` (lazy). Menu map: `INPC → system`, `CIR → cir`, `CSD → csd`, `TSD → csd`, `SYSTEM → system`, `AS400 → as400`, `AS400IND → as400ind`, `INFOAPPS → infoapps`, `POS → pos`. `csd` is warranty SQL Server **`dINTWSYS`** on `PRODSQL445A\SQL445A` (shared by CSD + TSD; `HibernateFactoryRegistry.TSD` aliases `CSD`). `as400` is `US400IN`. `as400ind` is `US400IND`. `inpc.ship-and-debit.as400` chooses the pool for Ship and Debit and is set to `as400` (`US400IN`). `pos` is SQL Server `dINPOS` on `PRODSQL445A\SQL445A`. (Removed unused duplicate `sql1` pool — same DB as `system`.)
- Smoke: `/api/csd/*` ([CSD_DATASOURCE.md](./CSD_DATASOURCE.md)), `/api/cir/*`.

---

## 10. Frontend conventions

| Topic | Convention |
|-------|------------|
| Font | Inter (`css/app-font.css`) |
| Icons | Remix (`nuiassets/css/icons.css`) |
| Layout | `css/mainpage-overrides.css` |
| Searchable single-select | Locally bundled Choices.js; global small-control sizing and dropdown option height are defined in `css/mainpage-overrides.css`. |
| Globals | `$host_url` / `$app_url` in `js/fw-globals.js`. Do not redeclare a local `host` from `$host_url`. |
| Cookies | `inpcSetCookie` / `inpcClearCookie` from `MainPage.js` |
| Customer header | `#customer_name_display` |
| Logos | `images/company_logos/3m-logo*` unless a customer logo is supplied |
| Sidebar | [SIDEBAR_TOGGLE.md](./SIDEBAR_TOGGLE.md), [SIDEBAR_FLYOUT_LABELS.md](./SIDEBAR_FLYOUT_LABELS.md), [SIDEBAR_COLLAPSED_DOTS.md](./SIDEBAR_COLLAPSED_DOTS.md) |

---

## 11. Common pitfalls

1. **Doubled path:** do not set `data-file-name` to `html_files/INPC/...` if `moduleHtmlPath` also prefixes. Use a bare name, `common/foo`, or a sibling root (`CUST_SERVICE/...`).
2. **Home file:** use `inpcHomeModuleForUserType`. Do not hard-code `home_Page` or root `home.html` for Overview.
3. **Static not visible:** forgot Ctrl+F5, or WTP is serving an old `html_files/` copy ([STATIC_DEPLOY.md](./STATIC_DEPLOY.md)).
4. **Java / portal.properties:** needs a server restart (EAP: [AutoDeploy-JBoss.md](./AutoDeploy-JBoss.md)).
5. **FW broken after a restyle:** IDs or callbacks removed, or MultiGrid scripts out of order.
6. **Dashboard tabs after `.load()`:** prefer `onclick` to a global function.
7. **PowerShell:** `$HOME` is read-only — use another variable name.
8. **Wrong port:** Tomcat 8080 vs EAP 8090.
9. **IMEXT:** enabling it needs both `spring.profiles.active=imext` and `security.imext.enabled=true`.
10. **Document SMB:** do not add JCIFS or non-SMB3 dialects for upload/download. Use SMB 3.1.1 + encryption (see section 14).

---

## 12. Suggested Cursor workflow

1. Read this file and the topic doc from [README.md](./README.md).
2. Confirm the surface: static only vs Java/properties (restart).
3. Match the module style (FrameWork vs Internal HTML vs DeskMobile).
4. Edit under `src/main/resources/...`.
5. Keep FW field IDs. New portal toggles go in `portal.extras.*` unless a typed field is required.
6. Update the matching `doc/*.md` (and this guide if the architecture changed) in the same change.

---

## 13. Quick reference

| Concern | Where |
|---------|--------|
| Login API | `com.mmm.authentication.AuthController` |
| Menus + portal payload | `GET /api/auth/menus` |
| Menu SQL | `com.mmm.authentication.AuthService` |
| Portal config | `portal.properties` + `PortalProperties.java` |
| Datasources | `application.yml` + `InpcDatasourceProperties` |
| Shell / menus | `static/js/MainPage.js` |
| FW module JS | `static/js/MainPageNew.js` |
| Optional tabs | `static/js/inpc-tabs.js` |
| Home shells | `static/html_files/INPC/home_*.html` |
| Dashboards | `static/html_files/INPC/sb_dash_board_*.html` |
| Customer modules | `static/html_files/CUST_SERVICE/` + `com.mmm.customer` |
| Login UI | `static/login.html`, `static/login1.html` |
| Change Customer | `com.mmm.portal_common.ChangeCustomer` |
| Welcome popup | `com.mmm.portal_common.WelcomeAck` — [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md) |
| SQL local time | `UserSessionSupport.sessionDate()` |
| Health | `com.mmm.web.HealthInfoController` |

---

## 14. Product decisions (do not reverse casually)

**Document upload / download — SMB 3.1.1 only.** Any new or changed feature that
stores or retrieves files on a network share (CIR required docs, CIR additional
attachments, Rebate claim evidence, Ship and Debit claim docs, COA files,
Policies & Guidelines agreements, and any future module) must use **SMBJ with
encrypted SMB 3.1.1** (`SMB2Dialect.SMB_3_1_1`, `withEncryptData(true)`). Resolve
share host/credentials on the server (for example `CMW010S`). Do not use JCIFS,
SMB1/SMB2-only dialects, browser-visible `smb:` paths, or credentials in the
client. Local `mount` transport is an explicit config fallback only where a
module already documents it (CIR: `inpc.cir.file-transport=mount`).

- Portal brand = **3M Customer Portal**; customer org name is configurable (demo: R.K Traders).
- Two login designs stay (`login.html` / `login1.html`); both call `api/auth/login`.
- Home HTML depends on login user type. Customer and Distributor use tabbed dashboard shells. Admin and Customer Service are static landings.
- Distributor / customer dashboards are demo data until real APIs exist.
- Include Tabs defaults **off**.
- Prefer NativeQuerySupport + Spring sessions for new DB reads.
- Bootstrap 5 for module chrome; keep FW IDs.
- Stay on Spring Boot 3.5.x while servers are Servlet 6.0 (Tomcat 10.1 / EAP 8).

---

## 15. Checklist before finishing a task

- [ ] Correct folder (`html_files/INPC` vs `html_files/CUST_SERVICE`)
- [ ] Hard-refresh, or EAP/Tomcat republish if the static file 404s
- [ ] Cache-bust `?v=` bumped when MainPage JS/CSS changed
- [ ] Restart if Java, `application.yml`, or `portal.properties` changed
- [ ] No doubled `html_files/` paths
- [ ] Document upload/download uses SMB 3.1.1 + encryption (no JCIFS / SMB2-only)
- [ ] Home still chosen by `inpcHomeModuleForUserType`
- [ ] Internal pages do not call FW schema init; FrameWork pages still save/load
- [ ] Topic doc under `doc/` updated if behavior changed

---

## 16. Topic map (details live in their own files)

| Topic | Doc |
|-------|-----|
| Login, cookies, `$host_url` | [AUTHENTICATION.md](./AUTHENTICATION.md) |
| IMEXT / Azure B2C | [Imext.md](./Imext.md) |
| Change Customer | [CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md) |
| Pass customer / getCustomer | [getCustomer.md](./getCustomer.md) |
| Hibernate / SQL | [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md) |
| CSD remote DB | [CSD_DATASOURCE.md](./CSD_DATASOURCE.md) |
| Include Tabs | [INCLUDE_TABS.md](./INCLUDE_TABS.md) |
| Home by user type | [HOME_PAGES.md](./HOME_PAGES.md), [HOME_LOGIN_TYPE.md](./HOME_LOGIN_TYPE.md) |
| Dashboards 4–7 | [SB_DASH_BOARD_4.md](./SB_DASH_BOARD_4.md), [SB_DASH_BOARD_5_6.md](./SB_DASH_BOARD_5_6.md), [SB_DASH_BOARD_7.md](./SB_DASH_BOARD_7.md) |
| JS module standard (plain jQuery) | [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) |
| Portal module tabs (load once) | [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md) |
| My Orders | [MY_ORDERS.md](./MY_ORDERS.md) |
| Account Status | [ACCOUNT_STATUS.md](./ACCOUNT_STATUS.md) |
| Invoice / Credit Note Download | [INV_CR_DR_DOWNLOAD.md](./INV_CR_DR_DOWNLOAD.md) |
| 3M Information | [3M_INFORMATION.md](./3M_INFORMATION.md) |
| Announcements | [Announcements.md](./Announcements.md) |
| Welcome popup | [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md) |
| CIR | [CIR_MIGRATION.md](./CIR_MIGRATION.md) |
| TSD E-Warranty | [TSD_MIGRATION.md](./TSD_MIGRATION.md) · file/API map [TSD_SYSTEM.md](./TSD_SYSTEM.md) |
| CSD graphic E-Warranty | [EWARRANTY_MIGRATION.md](./EWARRANTY_MIGRATION.md) · [EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md) (not TSD) |
| Transactional Java save pattern | [Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md) |
| Ship and Debit | [SHIP_AND_DEBIT.md](./SHIP_AND_DEBIT.md) |
| DeskMobile | [DeskMobile.md](./DeskMobile.md) |
| Shared modals | [SHARED_MODALS.md](./SHARED_MODALS.md) |
| Tab UI lab (`sb_tab.html` under INPC) | [TAB_PATTERNS.md](./TAB_PATTERNS.md) |
| HTML / grid generators | [HTML_CREATION.md](./HTML_CREATION.md), [FRAMEWORK_TOOLS.md](./FRAMEWORK_TOOLS.md) |
| Sidebar | [SIDEBAR_TOGGLE.md](./SIDEBAR_TOGGLE.md), [SIDEBAR_FLYOUT_LABELS.md](./SIDEBAR_FLYOUT_LABELS.md), [SIDEBAR_COLLAPSED_DOTS.md](./SIDEBAR_COLLAPSED_DOTS.md) |
| Static 404 / WTP | [STATIC_DEPLOY.md](./STATIC_DEPLOY.md) |
| EAP class deploy | [AutoDeploy-JBoss.md](./AutoDeploy-JBoss.md) |
| Dependency / VAPT | [DEPENDENCY_VAPT.md](./DEPENDENCY_VAPT.md) |

## 17. Status on 1 Oct 2026

Continue from here. Do not reintroduce `InpcClock`, `InpcClockFilter`, or `InpcConfiguration`.

- **SQL time.** `dbo.inpc_configuration` (`internal_code`, `inpc_hh`, `inpc_mm`) is loaded in `AuthService.bootstrapSessionByEnlId` for both local login and iMEXT. Empty values are 0 and 0. Programs call `UserSessionSupport.sessionDate()` or replace `getdate()` with that string before execute. CIR folder paths still use Java Asia/Kolkata; that is not SQL `getdate()`.
- **Welcome.** Details in [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md). `active` blank means Yes. Customer notice `internal_code` 5 runs 1 Oct 2026–31 Dec 2026, `ack_required` No, board layout. September Customer row (`internal_code` 1, ack required) is still in the table and is not the one shown while row 5 is newer and in range. Preview does not save an acknowledgement. Cache query on MainPage scripts is `202610012216`.
- **CIR.** New code only under `com.mmm.cir` (`SaveCir`, `CirDocUpload`, `CirFileStore`, `CirDashboard` / `CirDashboardSql`, `CirRequests` / `CirRequestsSql`). Home tabs: Dashboard (first), New Request, My Requests. Dashboard year filter + ApexCharts; detail popup columns match legacy (invoice/lot/docs); additional attachments upload/download over **SMB 3.1.1** with extension-safe filenames; Approvals/History hidden when credit note issued; Total claimed excludes Rejected/Cancelled. Do not edit `CirHybernetUtil`, `CirSmokeController`, or `CirUserService`. Do not modify the legacy checkout. Approval routing mutations and email are not finished. See [CIR_MIGRATION.md](./CIR_MIGRATION.md).
- **TSD E-Warranty.** Plan/status [TSD_MIGRATION.md](./TSD_MIGRATION.md); **paths + each API → Java** [TSD_SYSTEM.md](./TSD_SYSTEM.md) (keep updated when coding). Warranty DB **`csd`** → `dINTWSYS`; `HibernateFactoryRegistry.TSD` aliases `CSD`. Portal largely complete: shell, My Requests, New Request Draft/Submit + edit, Warranty No AC, Signboard Excel, warranty PDF, Submit mail (`TsdMail` → approvers + `tsd_mail_history`; link `ew_backend_url`). Approvals stay in backend app. Menu: `file_name=TSD/tsd_home`, `js_path=custom_js/TSD/tsd.js`.
- **CSD graphic E-Warranty.** Separate from TSD. [EWARRANTY_MIGRATION.md](./EWARRANTY_MIGRATION.md) · keep [EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md) updated when coding. Do not edit TSD. Same pool `csd`/`dINTWSYS`, tables `ew_*`. Converter/Distributor shells + lists. New Request: **PPF** (6-col + Product 1) and **Graphics** (all 6 templates; Dist→Converter invoice; `assignTabsForProducts` + Swal; per-slot header colors; Project/Printing `.ew-ppf-block-body` closed borders; cascade with field loaders/errors + GCM `NA`; Dist AC without `warranty_type`; metadata save for vinyl/sec/substrate/overlam/POI/invoice). Pending: mount file upload, approve/dist-agree. View popup + warranty PDF for all 6 templates when Closed (`EwWarrantyPdfPpf` / `EwWarrantyPdfGraphics`, mount read). Menu: `EWARRANTY/ew_conv_home` + `custom_js/EWARRANTY/ew_conv.js` (and dist equivalents).
- **Rebate Programs.** Full migration doc [REBATE_PROGRAMS_MIGRATION.md](./REBATE_PROGRAMS_MIGRATION.md) (resume note at end). Shell `#m_rebate_programs` + `#m_rebate_programs_popup`; `_scrubOrphanPopups` / `_claimContent$()`; claim cards; `POST /claim/invoice-details` when files already on claim; read-only total via `data-total-incl` (not stale cross-claim); claim modal 85% / terms 80%; My Claims ends with Program Target + Final Achievement; money via `_money` (`en-IN`); Excel `GET /api/customer/rebate/claims/export` (`RebateExcel.java`). EAP: [AutoDeploy-JBoss.md](./AutoDeploy-JBoss.md) (Ant once; m2e skips Maven `dodeploy`).
- **Ship and Debit.** Study/implementation notes [SHIP_AND_DEBIT.md](./SHIP_AND_DEBIT.md). Legacy Java stays read-only. Calls are IBM i procedures in `SFLASH` and `BPCSLCLIN` on the existing `as400` datasource. Uses `CommonFunctions` for text/sqlDate where applicable; AS400 dates stay `yyyyMMdd`.
- **Startup log.** `ContactUs` prints its query text from the controller constructor when the bean is created. That is not a database call. Leave it unless asked.
- **Deploy.** Java changes copy into the EAP exploded WAR via Ant builder (Eclipse) or Maven CLI `process-classes`. Inside Eclipse, m2e skips the Maven JBoss deploy so refresh does not touch `dodeploy` twice — see [AutoDeploy-JBoss.md](./AutoDeploy-JBoss.md). Static files under the WAR also need a refresh (Ctrl+F5) or copy into `WEB-INF/classes/static`. After a class-file cleanup, delete stale `.class` files from `WEB-INF\classes` if a deleted source class was a Spring component.

*End of Cursor handoff. Prefer updating this file when architecture decisions change.*
