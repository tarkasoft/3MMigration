# Ship and Debit (Contract Claim Management)

Legacy study, plus the INPCV2 screens that are already in place. Do not edit the legacy checkout.

Live page: `https://inpc.3m.com/inpc/#/ShipandDebit`  
Legacy UI root: `inpc/src/main/webapp/resources/shipanddebit/`  
Legacy Java: `inpc/src/main/java/com/mmm/shipanddebit/`  
Checked 2 Oct 2026.

The page title is **Contract Claim Management**. Tabs are not hard-coded. `BPCSLCLIN.CMW000S` returns the menus for application code **CCM**, and `shipanddebit.properties` maps menu codes to route names.

## Screens

After the distributor has accepted terms, the header shows six tabs. Terms is the seventh page and is shown only until that acceptance. The default route after acceptance is **Pending PO for Acceptance**.

| Order | Live label (from AS/400 menu name) | Code | Route | HTML |
|------|--------------------------------------|------|--------|------|
| Gate | Terms and conditions | — | `termsCond` | `html/termsCond.html` |
| 1 | Create Claim | CCM01 | `newClaim` | `html/newClaim.html` |
| 2 | Edit Claim | CCM02 | `editClaim` | `html/editClaim.html` (`localStorage.HomePage = edit`) |
| 3 | Claim Status | CCM03 | `viewClaim` | `html/editClaim.html` (same file, status list) |
| 4 | Accepted Rate Contracts | CCM04 | `ApprovedRateContract` | `html/ApprovedRateContract.html` |
| 5 | Claim Report Download | CCM05 | `ClaimDownloadExcelReport` | `html/ClaimsExcelDownload.html` |
| 6 | Pending PO for Acceptance | CCM06 | `PendingRateContract` | `html/PendingRateContract.html` |

Menu wiring: `js/shipandDebitHome.js` (`SandDHomeCtrl`, `routeShipAndDebit`). Property keys are in `src/main/resources/shipanddebit.properties` (`CCM01` … `CCM06`).

## Data

Claim, contract, terms, and report calls are IBM i stored procedures. Library **SFLASH** holds the claim procedures. Library **BPCSLCLIN** holds the menu procedure `CMW000S`.

For the complete client API route inventory, request parameters, Java handlers, procedure parameter order, response examples, and runtime request-audit behavior, see [`SHIP_AND_DEBIT_API.md`](SHIP_AND_DEBIT_API.md).

INPCV2 has two IBM i pools with the same library list (`SFLASH`, `BPCSLCLIN`, and the others already on `as400`). `as400` is `US400IN`; `as400ind` is `US400IND`. Ship and Debit uses the name configured by `inpc.ship-and-debit.as400` in `application.yml` (currently `as400ind`, which points to `US400IND`). Each printed Ship and Debit procedure call includes `[datasource=<configured pool name>]`, so logs distinguish `as400` from `as400ind`. Payments and the other modules stay on `as400`. The call style is `com.mmm.customer.account_status`, especially `AccountSummary`: print the procedure and values, then `NativeQuerySupport.executeProcedure` for a result set or `executeProcedureWithOutputs` for output fields such as `DISTRTERMS` and `STATUS`. Parameters are local variables in `?` order. The pool name is the YAML value, because Account Status is hard-wired to `HibernateFactoryRegistry.AS400` (`US400IN`). Do not copy the legacy JNDI lookup `java:jboss/jdbc/sdin/sdin_datasource` or the hardcoded driver login in `JDBCAccessor`.

POS is a second database, SQL Server `dINPOS`, not AS/400. The Java method `GetMaxDistInvocieDate` uses the Spring bean `dataSource_pos` in `root-context.xml`. INPCV2 registers POS as `insba.datasources.pos`, registry key `HibernateFactoryRegistry.POS` (`pos`), lazy, database `dINPOS` on `PRODSQL445A\SQL445A`. A commented alternate host in `application.yml` is `DEVSQL56A.usac.mmm.com\SQL56A`. Do not put the password in docs or the browser. POS reads use bound parameters through that registry key.

Ship and Debit uses that connection in two places. Everything else in this module is AS/400 (`US400IN`, library `SFLASH`).

| When | SQL Server table | Used for |
|------|------------------|----------|
| Page load, with `PMS330S` | `dbo.Dealer` count for the session customer | `pos_dealer_exists`. `No` adds the POS registration note on the claim save and update messages |
| Validate a claim line (`getValidClaimDetails`, after `PMS355S`) | `dis_max_inv_date.max_date` for the session customer | `POS_INV_DATE`. If the distributor invoice date is later than this date, the screen blocks the line and asks for pending POS data |

Claim documents are not stored in AS/400. The insert path writes files to a claim-number subfolder on the SMB share. The folder and login come from the network-path row whose code is **CLAIMDOC** (`CreateSOFDAO.getExceliteWriteUpDetails` for app `CCM`). Do not put the share path or password in the browser. Transfers use encrypted SMB 3.1.1.

Create Claim supports multiple image, PDF, ZIP, and 7Z attachments. Each file may be up to 4.5 MiB; the client uploads files in sequential multipart batches whose combined payload is no more than 4.5 MiB, leaving room for multipart framing under the 5 MB request limit. There is no combined limit across the whole selection. Selected files appear in an inline table where users can preview or remove them before Submit. Edit Claim uses the same inline selection and review pattern; previously uploaded documents appear separately with view and permanent delete actions. Deletion requires confirmation and removes only the named file from the verified claim folder (or the legacy claim-prefixed root location). Submit first saves the claim and all of its lines as JSON; after receiving the claim number, the UI opens the existing progress popup and sends each document batch in a separate request. The server reuses one encrypted SMB connection for all files in each batch rather than reconnecting for every file. The progress popup shows each filename with its size and a larger status label (Waiting, In progress, Done, or Failed), and displays the active batch in its footer without covering the list with a page-blocking loader. It supports retrying failed batches without resaving the claim and confirms when uploads complete. The documents list and download links use the same SMB claim folder.

The Create Claim check that blocks a line when `RCPRICE` is 0 (`Rate Contract price is not valid for this period.`) is commented in `ship_and_debit_create.js` `_fillDetails`. Restore it when asked.

On Edit Claim, **Update** first saves the claim changes, then uses the shared progress popup to upload selected documents in sequential batches against the existing claim number. The supporting-document card is on the left and Comment, Late Submission Remarks, and Update are on the right. Each file may be up to 4.5 MiB; there is no combined limit across the selection, and each request batch stays within 4.5 MiB to leave room for multipart framing under the 5 MB request limit. Newly selected files can be viewed or removed before upload; existing stored documents remain view-only. During uploads, the footer reports progress and the list remains readable without a page-blocking loader. Failed uploads can be retried without repeating the claim update.

Edit Claim also has **Upload documents separately** for the exceptional case where a user needs to attach documents without changing claim data. It opens a dedicated popup showing the claim number prominently, a note that selected documents attach directly to that claim, and a selectable/reviewable multi-file queue where each file may be up to 4.5 MiB. There is no combined limit across the selection; files are sent in sequential batches capped at 4.5 MiB per request. When storing each file, the server adds a random three-digit suffix before its extension (for example, `invoice_222.pdf`) and creates the destination without overwriting an existing file. The server writes each batch through one SMB connection, requests SMBJ's negotiated maximum buffer size, and buffers writes in 1 MiB chunks. Share lookup, SMB connect/authentication, share connection, folder check, and each file's name, size, start time, finish time, and elapsed transfer time are logged to help identify any remaining bottleneck. The upload does not call the claim-update endpoint. Table headers are highlighted, and the progress popup shows an animated spinner with non-blocking upload status and retry behavior.

Application code passed into the procedures is **CCM**. The logged-in ENL id is upper-cased in the legacy calls. Customer / distributor code must come from the portal session (`UserSessionSupport`), not from a browser field, except where the user picks an end customer that the procedure validates.

## Stored procedures

| Procedure | Used by | Parameters (in order) |
|-----------|---------|------------------------|
| `BPCSLCLIN.CMW000S` | Menu list (`PortalDAO.menuList`, app CCM) | APPCODE, USERCODE, plus out parameters for name, role, email, group, sales rep, user type, error, user field |
| | `SFLASH.PMS330S` | Terms status | app name, login id, then out fields ROLE, EMAIL, NAME, DISTRTERMS. After the call returns, the console prints `CALL SFLASH.PMS330S` again with all six values |
| `SFLASH.PMS351S` | Accept terms | app name, login id. Response field `STATUS` = `Y` means accepted |
| `SFLASH.PMS341S` | Distributor / stock lookup | login id |
| `SFLASH.PMS362S` | Division list | app, user, distributor code |
| `SFLASH.PMS349S` | End customer list for a division | `ESOF`, blank user, distributor code, division. Same order as live `getEndUser`. The division is the last value; a longer customer code in that position is rejected as truncation |
| `SFLASH.PMS387S` | Late-submission flag for a group | division code, claim month (decimal) |
| `SFLASH.PMS387S` | Terms text for a group | app code, distributor code |
| `SFLASH.PMS350S` | SKU list | app, user, distributor, customer, division |
| `SFLASH.PMS333S` | Invoice list | app, user, distributor, SKU, claim month |
| `SFLASH.PMS355S` | Validate claim lines | app, user, SKU, invoice number, invoice date, distributor invoice number, distributor invoice date |
| `SFLASH.PMS337S` | Invoice line detail | app, user, customer, SKU, invoice number, invoice date, distributor invoice date, claim number |
| `SFLASH.PMS328S` | New claim number | app, user, status |
| `SFLASH.PMS334S` | Insert claim or add a line to an existing claim | app, user, claim number, customer, division, line payload, claim month, comments, late-submit remarks |
| `SFLASH.PMS361S` | Claim mail recipients | app, login, role, claim number |
| `SFLASH.PMS324S` | Claim list | app, login, role, one status per call. Status values seen in the UI: P, C, W, R |
| `SFLASH.PMS325S` | Open one claim for edit or view | app, login, claim number |
| `SFLASH.PMS360S` | Update or delete claim lines | app, login, claim number, comments, late-submit remarks, line payload, end user, division, claim month |
| `SFLASH.PMS261S` | Rate-contract list | app, login, flag, customer code, division (passed blank) |
| `SFLASH.PMS332S` | Rate-contract detail | app, contract number |
| `SFLASH.PMS262S` | Accept or update a pending contract | app, login, end customer, contract number, status flag |
| `SFLASH.PMS396S` | Claim Excel report | from date, to date, login customer internal code, distributor code |

`PMS387S` is registered twice with different parameter lists. Confirm on IBM i which signature is real before the first call from INPCV2. The Java log string in `insertClaimDetails` names `PMS328S`; the `SPUtil` target is `PMS334S`.

## Legacy HTTP entry points

Controllers have no class-level path except `SDCommon` (`/ShipAndDebitCommon`). The others sit on the portal root.

| Path | Role |
|------|------|
| `GET termsAndCondStatus` | Terms flag `DISTRTERMS` |
| `GET updateDistrTermsAndConditions` | Accept terms |
| `GET getMenuListSND` | CCM menus |
| `POST getDivisionList`, `getskuDetails`, `getDistributorCode` | Create Claim lookups |
| `GET getEndUser`, `getInvoiceList`, `GetLateSumbssionFlagforGroup`, `GetSDTermsAndCondForEachGroup`, `getValidClaimDetails`, `getInvoiceDetails` | Create Claim lookups |
| `POST createClaimNumber` | Allocate claim number |
| `POST insertClaimDetails` (`application/json`) | Save claim lines; after success, each document is sent individually to `POST /api/customer/ship-and-debit/documents` |
| `POST listPendingClaims` | Edit / status list |
| `POST updateClaims`, `updtDelClaims` | Save edits |
| `GET sddownload` | Download a claim file |
| `POST getRateContractsList`, `getRateContractDetails`, `updateRateContractFlag` | Both rate-contract tabs |
| `GET ShipAndDebitCommon/SDLoginUserDetails` | Login id, distributor code, POS dealer flag |
| `GET ShipAndDebitCommon/DownloadExcelClaimReport` | Excel (`FromDate`, `ToDate`, `login_cust_int_code`, `dist_code`) |

Create Claim filters on the live page: Division, End Customer, Claim Month, and a total claim value (net of tax, freight, and discount).

## Folders and files

Follow [Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md). One package, no `dao`, `daoImpl`, or `dto` folders. Values stay as local variables. A line total may be a small calculated-line class. Do not add a request wrapper only to carry parameters into SQL.

The AS/400 procedure already writes the related claim tables. Java does not split that into its own header and detail inserts. The Java flow for a save is: read inputs into locals, validate, begin one transaction, `CALL` the procedure with explicit `?` values, commit, then store files. A failed call rolls back. Files go on after the commit, one file per request, the same way CIR documents do.

```text
src/main/java/com/mmm/shipanddebit/
    ShipAndDebit.java         tabs, lookups, lists, terms, Excel
    ShipAndDebitSql.java      every CALL, parameters passed in order
    SaveClaim.java            create claim and edit claim transactions
    ShipAndDebitDocUpload.java upload and download claim files after the claim is saved

src/main/resources/static/html_files/SHIPANDDEBIT/
    ship_and_debit.html       tab strip, empty terms modal, the smaller tabs
    ship_debit_terms.html     terms letter, loaded into that modal on page load
    create_claim.html         new-claim form and client-side line entry
    edit_claim.html           claim list for Edit Claim and Claim Status

src/main/resources/static/custom_js/SHIPANDDEBIT/
    ship_and_debit.js         tab loads and Common.DataTable.init
    ship_and_debit_create.js  Create Claim form
```

`ship_and_debit.html` is the shell the menu opens. It holds the tab strip and an empty terms modal. The letter itself is `ship_debit_terms.html`, loaded into that modal the same way Create Claim loads `create_claim.html`. Accepted Rate Contracts and Pending PO for Acceptance stay in the shell as the rate-contract grid. The contract number in the grid opens the detail popup (`PMS332S`). Pending acceptance is the Submit button inside that popup (`PMS262S`). There is no contract-number box on the page.

Create Claim is its own file. The tab loads `create_claim.html` the first time it is opened, the same way CIR loads `cir_new_request.html` from `cir_home.html`. Edit Claim loads `edit_claim.html`. Claim Status stays in the shell and shows the four status buckets.

`ShipAndDebit.java` is the module controller (`/api/customer/ship-and-debit`). `ShipAndDebitSql` holds the procedure calls. `SaveClaim` owns create and edit. `ShipAndDebitDocUpload` owns claim files, the same role as `CirDocUpload`: one file per request, after the claim save has committed. The HTML does not copy Angular or the legacy Bootstrap 3 scripts. String trim uses `com.mmm.titpl.CommonFunctions.text` (`import static`), same as TSD. AS/400 claim/report dates stay `yyyyMMdd` — do not force `sqlDate` onto those procedure parameters.

- Customer and login follow Rebate and CIR. See Customer override below. The browser does not send a trusted distributor code on its own.
- Every procedure uses a bound `CALL`. Print the SQL and values to stdout the same way CIR does.
- Terms stay a blocking step. See Terms gate below. The six tabs are usable only after `PMS330S` says the distributor has accepted, or after `PMS351S` succeeds.
- Land on Pending PO for Acceptance, matching `$state.go('PendingRateContract')`. A page message belongs to the tab that raised it. Switching tabs hides that message, and coming back to the tab shows it again.
- Edit Claim lists status `P`. The claim number in the grid is a link. Clicking it hides that grid and shows the claim on the same tab (`PMS325S`). A single stock-entry form sits above the existing-line grid and is reused for adding and editing: product and invoice options are loaded for the claim's division, end customer, and month; Add validates the distributor invoice/date against `PMS355S` and the POS cutoff, loads prices and quantities from `PMS337S`, and checks quantity limits. When an existing row is selected, the same fields are populated and the button changes to Save; product and invoice remain fixed while distributor invoice number, distributor invoice date, and quantity can be edited. Added rows appear in the grid and can be removed before Update. Update calls `PMS334S` for each added line, using the existing claim header loaded server-side, `PMS360S` for each existing line, and `PMS360S` for each deleted existing line. The new-line insert is part of the same AS/400 transaction as updates and deletions. A Claim Status claim number opens a read-only popup from the same `PMS325S` call. It stays on Claim Status and has no Submit or Update. The popup shows the stock lines, including tax, freight, discount, and COFS order, plus Comment, Late Submission Remarks, and the Status and comments panel (BSG comments, DM comments when present, and Pending, In progress, Rejected, or Closed). The claim popup is 5% wider than the standard large dialog (1197px) so the stock table needs less sideways scrolling. The rate-contract popup and the claim popup keep the blue header, fact cards, and section bar on a phone. Those colors are written on the popup itself, not only in the page style block. Refresh on that screen returns to the grid. Claim Status loads `P`, `W`, `C`, and `R` in one call (`PMS324S` once per status). The four buttons are Submitted Claims, Work in Process, Closed Claims, and Rejected Claims. Clicking a button shows the list already returned for that status. It does not call the server again.
- Each grid tab asks the server the first time it is opened. A later click keeps that list. Opening the menu again clears that saved state, removes a terms popup left on the page, and loads the current customer's lists. The terms text is written into the popup that is shown. Refresh sits on the same row as Show entries, on the right. Claim Report Download has From Date, To Date, and Download Excel. It does not show the report on the page. The calendar is `dd/mm/yyyy` and opens from the field or the calendar icon, the same way Rebate My Claims does. The download sends `yyyyMMdd` to `PMS396S`.
- Documents stay server-side. Email stays server-side (`PMS361S` plus the existing mail path). Do not expose SMB credentials.

## Terms gate

The menu opens `ship_and_debit.html`. On that page load, one API runs both checks before the user can submit anything. It calls `SFLASH.PMS330S` with application code `CCM` and the session login id, and it counts `dbo.Dealer` for the session customer. The response carries the terms fields (`DISTRTERMS`, `ROLE`, `EMAIL`, `NAME`) and the session fields (`login id`, `login name`, `customer code`, `pos_dealer_exists`). The accepted flag and role are cached in the HTTP session for that login; subsequent data and document endpoints validate against this cache instead of calling `PMS330S` again. Opening the menu again rechecks current acceptance.

- `DISTRTERMS` trimmed equals `Y`: no popup. Load the CCM menus, show the six tabs, and land on Pending PO for Acceptance.
- Any other value, including blank: load `ship_debit_terms.html` into the modal. The letter is the current 3M Chargebacks text (revised 1 February 2026), the same wording as legacy `termsCond.html`. This follows the welcome acknowledgement modal: backdrop, Esc, and the close control stay locked (`data-ack-lock` = Yes) until acceptance succeeds. The Submit button stays disabled until the acknowledgement checkbox is checked. Claim save, rate-contract accept, and the other Ship and Debit submits stay disabled while the modal is locked. The rest of the portal is not locked.

Accepting terms stays its own call. Submit calls `SFLASH.PMS351S` with the same application code and login id. `STATUS` = `Y` clears the lock, closes the modal, and loads the tabs. Any other status leaves the modal up and shows the returned message inside the popup (`#sd_terms_msg`), including `STATUS=` when it is not `Y`. That failure also shows **Go to Home**, which unlocks the modal and opens the same Home page the main menu uses. There is no second acknowledgement once `DISTRTERMS` is `Y`. Do not treat `STATUS` other than `Y` as success.

The login id and customer code come from Customer override below. Acceptance is stored by `PMS351S` on IBM i. The next menu visit runs the same page-load call, so a later `N` brings the popup back. `pos_dealer_exists` is `Yes` when the dealer count is not zero. The claim save and update messages use it only to add the POS registration note when it is `No`.

## Customer override

Follow [getCustomer.md](./getCustomer.md). The page passes `custCode` and `loginId` from `Common.GetProcedureCustomerContext()`, and Java reads them with `UserSessionSupport.resolveProcedureCustomerContext`.

For Ship and Debit, `context.custCode()` is the distributor code passed into the `SFLASH` procedures and into the POS queries (`dbo.Dealer`, `dis_max_inv_date`). The end customer on a claim is the value the user picks from the list returned by `PMS349S`.

## Create Claim (current)

The first screen is Division, searchable End Customer, Claim Month (Bootstrap month-only picker, displayed as `MMM-YYYY` such as `Jul-2026` and sent to the API as `YYYYMM` such as `202607`), Total Claim Value, **Reset**, and **Add Details**, on one line. End Customer options load for the selected division and use the Choices search control, matching Role Rights. Division and End Customer are both narrow. **Total Claim Value** sits above the amount, and `Incl.of.Tax.Freight & Discount` sits under it. Add Details locks the header and shows Stock details. Opening the tab again keeps the same screen. Reset clears the lines and reloads division, end customer, and a blank stock form. If one of division, end customer, or claim month is still empty, the warning names only the empty ones. Filling the last empty field clears that warning.

Supporting-document type, empty-file, and per-file 4.5 MiB maximum validation is displayed inline in the relevant document card or Edit Claim upload modal instead of the page-level alert. The server assigns each stored filename its own random three-digit suffix to avoid duplicate-name collisions and prevents overwriting. Batch payloads are independently limited to 4.5 MiB to leave room for multipart framing beneath the 5 MB server request limit. Before Create Claim submit or Edit Claim update, the debit-note confirmation uses a SweetAlert popup with **OK** and **Cancel** actions instead of the browser-native confirmation dialog.

Stock details uses the same fields as legacy `newClaim.html`, in this order: Product Description, Sku Code, Inv Number, Inv Date, Dist Inv Number, Dist Inv Date, Avail Qty, Dist Qty, UOM, Sales Person, Contract Price, 3M Inv Price, VAT/CST/SGST/UGST, CGST, IGST, Freight%, Discount%, Claim Value, Add.

**Add** does not call the server. It copies the current line onto the grid (maximum 35), adds that claim value into the header total, then clears the entry fields so another SKU can be added. Dist Qty cannot be greater than Avail Qty for the same SKU and 3M invoice, including quantities already on the grid. If the quantity already on the grid equals Avail Qty, Add says the invoice quantity is exhausted. Duplicate lines are blocked for the same SKU, 3M invoice, distributor invoice number, and distributor invoice date. **Submit** posts every grid line in one JSON request. `SaveClaim` takes one claim number, then calls `PMS334S` once per line in the same transaction. After the claim is saved, a progress popup identifies the claim and uploads the selected documents together in one multipart request. The server reuses one encrypted SMB connection for the batch; the popup tracks each file, displays upload status without a blocking loader, permits retrying failed uploads without submitting the claim again, and reports when uploads complete. The supporting-document card sits on the left; Comment, conditional late-submission remarks, and Submit are arranged on the right. The file table has serial numbers and icon actions for viewing/removing selected files, without a selected-count badge. Comment and the file control appear after the first line. There is no document upload bundled with the claim save. Add names only the stock fields that are still empty: product, invoice, distributor invoice number, distributor invoice date, and distributor qty. Filling the last one clears that warning. The success banner uses the same weight, size, and left bar as the warning banner, in a soft green. Add Details and Add clear the page message in place so the banner stays under the title. The line table's Actions column has Edit and Delete. Edit loads that row into the entry form, temporarily limits Product and Invoice to the selected values, and allows changes only to distributor invoice number, distributor invoice date, and distributor quantity. Save checks the edited line, updates it in place (not as a new row), recalculates the line and claim totals, then restores Add mode and the full product list. Delete asks SweetAlert confirmation and removes the row only on OK; deleting the active edit row also exits edit mode.

Read-only inputs use the same gray background as a disabled header field. Fields the user can type stay white. On Edit Claim, Dist Inv Number, Dist Inv Date, and Dist Qty are editable while a line is being edited. Dist Qty remains a text input (with a decimal keyboard hint); non-numeric characters are filtered while typing and fractional input is limited to two digits, with the existing positive-quantity validation still applied on save. Stored-document lookup applies the claim filename prefix at the SMB directory query rather than scanning every root entry, keeps loading inline without the global blocking loader, and logs its connection/listing phases and each discovered document ordinal.

Submit blocks a total of 0. When the total is greater than 0 it asks the debit-note confirm, including the total. When `PMS387S` returns `Y`, the reason for late submission is shown and required. The message is "Please share the reason for late submission." That text is `lateRemarks` on the save. Create and Edit wait for the late-flag lookup; an unavailable or unrecognized flag blocks submission until it can be checked. The server rechecks `PMS387S` before saving, and Edit uses the division and claim month read from the existing claim.

Dates: Dist Inv Date is picker-only (`readonly` input, `dd/mm/yyyy`), constrained to the selected Claim Month (day 1 through month end, capped at today for the current month), and cannot precede the 3M invoice date. The datepicker opens only from its calendar icon, not when the input receives focus, so calendar navigation does not reopen/reset the picker. It is sent as `YYYYMMDD`; the server enforces the same date rules on Create and Edit saves. The namespaced `changeDate` handler is removed and rebound once when the picker is configured; selecting a date runs validation once, without keyboard blur/change duplicates. Programmatic date updates while loading an existing line are suppressed. On Create Claim, choosing a valid date calls `PMS355S` (`getValidClaimDetails`). On Edit Claim new-line entry, choosing a date runs `CheckNewEditLine`; while editing an existing line, it validates the date against the Claim Month, 3M invoice date, and today. When the claim is not already raised, `PMS337S` fills UOM, available quantity, sales person, prices, tax, freight, discount, CGST, and IGST. 3M Inv Date is read-only and is filled from the invoice list as `YYYYMMDD`.

Entering supply details calls `PMS387S` for the late-submission flag and `PMS350S` for the SKU list. Choosing a SKU calls `PMS333S` for that claim month's invoices. Choosing an invoice fills the 3M invoice date. If that date falls in a later month than the claim month, the invoice is cleared and the page asks for a different 3M invoice. The distributor invoice date must fall within the selected Claim Month and be on or after the 3M invoice date; for the current Claim Month, future days are unavailable.

On a phone, Dist Qty through Claim Value each take a full row, and Add is a full-width button. From the `xl` breakpoint they sit on one row again.

Claim Status and Edit Claim name the first nine `PMS324S` columns by position, the same way legacy `keyChangeAll` does: `DCCLNO`, `DCNAME`, `DCECNM`, `DCRQNM`, `DCRQDT`, `DCBSGS`, `DCDVMS`, `DCCLVL`, `DCCORD`. `STATUSLVL` stays the Pending With column.

Old Create Claim checks already on this screen: no invoice for the SKU, 3M invoice month later than the claim month, distributor date outside the Claim Month, distributor date after today, distributor date earlier than the 3M invoice date, POS cutoff date, claim already raised (`PMS355S`), Dist Qty against Avail Qty, duplicate line, 35 lines, total 0, late remarks when `PMS387S` is `Y`, and the debit-note confirm. Choosing Dist Inv Date calls claim-check once. A repeated date for the same SKU and invoices does not call it again.

The old alert "Selected 3M Invoice Date is greater than the Claim date" is commented out in legacy `datePopulate` and does not run. Do not add it unless asked.

Not wired yet:

- Claim email (`PMS361S`)
- Change Customer Code search error under the input. Typing a code calls `GET api/portal/change-customer/autocomplete?value=` and a 404 stays silent. Show that failure under the Customer Code box. The endpoint class is `ChangeCustomer` and the class is already in the WAR. The 404 itself was not fixed.

`create_claim.html` loads once per page visit. After an HTML change, reload the portal page before opening Create Claim again.

## INPCV2 status

**Multi-tab DOM (2026-10-04):** shell root is `#m_ship_and_debit` (`ShipAndDebit.ROOT`). Client get/set uses `ShipAndDebit._$home()` / `ShipAndDebit._$("#…")` / `_el` (create tab via the same helpers). Terms / rate / claim modals live under that shell and are **not** moved to `document.body`; supporting-document selection and upload-progress modals are moved to `document.body` to layer above portal navigation. Same rule as [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md).

Edit Claim saves changes through `PMS360S` and adds new stock lines through `PMS334S`. One stock-entry form above the lines grid handles both adding and editing. In Add mode it uses the claim's existing division, end customer, and claim month; it loads SKU and invoice lookups, checks the distributor invoice/date against `PMS355S` and the POS cutoff on blur, gets the prices and quantities from `PMS337S`, calculates Claim Value, and enforces the 35-line and available-quantity limits. Distributor invoice dates are restricted to the claim month and on/after the 3M invoice date, with future dates blocked. A newly added line can be deleted before Update, but its validated invoice details are not editable in the line table; delete and add it again to change them. Existing-line Edit copies the row into the same form and switches the button to Save. Product and invoice are fixed; distributor invoice number, distributor invoice date, and quantity can be changed. Save updates the grid only. Update sends existing remaining lines as `U`, deleted existing lines as `D`, and new lines as `I`; Java verifies the claim with `PMS325S`, sources the insert header values from that result, then calls `PMS334S` in the same transaction as updates/deletions. Delete asks SweetAlert and removes the row from the grid on OK. The claim number on the Edit Claim grid has an edit icon and opens the edit form. The Edit Claim list keeps its column titles frozen above the filter row. Full cell borders on a sticky grid use separate borders, and the filter row sits under the measured title height (`common_table.css` and `Common.DataTable._syncStickyOffsets`).

A Claim Status claim number opens a read-only popup. It does not open Edit Claim and it has no Submit or Update. The popup matches the live view at `updateClaims` with `Page` = view: stock lines include sales person, VAT/CST/SGST/UGST, CGST, IGST, freight, discount, claim value, and COFS order. Comment and Late Submission Remarks are locked boxes. Status and comments shows BSG's comments, DM's comments when the live page shows them, and Pending (yellow), In progress, Rejected, or Closed. The dialog is 1197px wide. The blue header, fact cards, and section bar are written on the popup so a phone keeps the same fill. Rate-contract and claim popups share that treatment.

Rate-contract detail is `PMS332S`. Accepting a pending contract sends status `A`. The report tab downloads `claim-report.xlsx`. Create Claim uses Reset instead of Refresh. Page messages on this module use a soft warning and a soft green success, same weight and left bar. A page message belongs to the tab that raised it. Switching tabs hides it. Create Claim and Reset clear it. Opening the menu again drops saved tab state and clears any orphan terms/rate/claim modals left on `document.body` from older builds, then loads the current customer. `ship_and_debit.js` and `common.js` load once per portal page. After either changes, reload the portal before testing. A menu row still has to point at HTML file name `SHIPANDDEBIT/ship_and_debit` and `js_path` `custom_js/SHIPANDDEBIT/ship_and_debit.js`. The claim list procedure is called with `inpc.ship-and-debit.claim-list-app-code` (`INPC`), matching the legacy list loop. Every other procedure uses `inpc.ship-and-debit.app-code` (`CCM`). `PMS325S` is called as application, claim number, login id. Legacy files were read only.

## Resume next session

The next login is a different account. Start from this file. Do not restore a paused item, and do not build the leftover checks, unless that login asks.

Restore only when asked:

- Zero rate-contract price. Uncomment the `RCPRICE === 0` block in `ship_and_debit_create.js` `_fillDetails`. The message is "Rate Contract price is not valid for this period."

Still to build when asked:
- Late Submission Remarks on Edit Claim Update. Create Claim already blocks when `PMS387S` `LSSTS` is `Y` and the reason is empty. The old edit save (`updateSkuDetails`) uses the same check and the same message.
- Duplicate stock line on Create Claim and Edit Claim. Same stock description, 3M invoice, distributor invoice number, and distributor invoice date.
- Change Customer Code: show a search failure under the Customer Code input. The call is `GET api/portal/change-customer/autocomplete?value=` and it has returned 404. The class is `ChangeCustomer` and it is already in the WAR.
- Claim email (`PMS361S`).
- The `ia_menu_options` row for this screen is still not inserted.

Paused 2 Oct 2026, night IST.
