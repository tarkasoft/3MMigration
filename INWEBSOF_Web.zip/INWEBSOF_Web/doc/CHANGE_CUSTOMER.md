# Change Customer Code (portal)

Concise reference for the **Change Customer Code** feature on MainPage. Source of truth: code under `static/custom_js/change_customer.js`, `MainPage.html` / `MainPage.js`, and `com.mmm.portal_common.ChangeCustomer`.

---

## 1. Permission â€” `see_other_cust_data`

| Layer | Detail |
|-------|--------|
| DB / user profile | `ia_user_master.see_other_cust_data` loaded in `AuthService` with cust fields |
| Session | `UserSessionSupport.SEE_OTHER_CUST_DATA` -> attribute `see_other_cust_data` |
| API | Included in `GET /api/auth/menus` and `/api/auth/me` client user map |
| Cookie | `fw_see_other_cust_data` set from menus via `inpcStoreUserCookiesFromMenus` |
| UI | Profile/Settings dropdown item `#change_customer_code_menu_item` (**Change Customer Code**, before Log Out) |

Visibility: `ChangeCustomer.ApplyVisibility(flag)` shows the item only when the flag is **`Yes`** (case-insensitive). Prefer the menus/me field; fall back to cookie `fw_see_other_cust_data`. Empty / `No` keeps `d-none`.

---

## 2. Client â€” `change_customer.js` on MainPage

- Included from `MainPage.html` **after** `MainPage.js` (needs `window.inpcSetCookie` / `inpcClearCookie`).
- Uses globals `$app_url` / `$host_url` from `static/js/fw-globals.js` â€” **do not** redefine host in this script.
- Modal: `#change_customer_modal` in `static/inpc_modal_popup.html` (appended once by `Common.LoadSharedModals` after page ready — see [SHARED_MODALS.md](./SHARED_MODALS.md)). Open → `ChangeCustomer.Open()`; primary button **Update** → `ChangeCustomer.Apply()`.
- Autocomplete is self-contained jQuery UI (not FW `POPUP` / `AssignJqueryAutoCompleteNew`). Query param is **only** `value` (typed term).

---

## 3. Cookies

Set/cleared with **`inpcSetCookie` / `inpcClearCookie` only** (no raw `document.cookie` in Change Customer).

| Cookie | Role |
|--------|------|
| `fw_cust_code` / `fw_cust_name` | Home (logged-in) customer from menus |
| `fw_see_other_cust_data` | Menu visibility |
| `fw_override_cust_code` / `fw_override_cust_name` | Active display / override target |
| `fw_customer_overridden` | `"Yes"` when user applied an override; cleared/empty when back to home |
| `fw_loginId` | Login id (menus) |

**Menus refresh when overridden:** `inpcStoreUserCookiesFromMenus` always refreshes `fw_cust_*` and `fw_see_other_cust_data`. If `fw_customer_overridden=Yes`, it **does not** overwrite `fw_override_cust_code` / `fw_override_cust_name` from `d.cust_*`.

**Header `#customer_name_display`:** `ChangeCustomer.RefreshHeaderDisplay` â€” if overridden -> override name (else override code); else -> `fw_cust_name` (then override name / menus fallback). Home customer cookies stay the "home" baseline; override cookies drive the header while overridden.

**Update (Apply):** decode -> `inpcSetCookie` override code/name -> `fw_customer_overridden=Yes` -> refresh header -> close modal.

**ResetToHomeCustomer:** copy `fw_cust_*` into override cookies, clear overridden flag, refresh header.

**Logout / leave to index:** `inpcClearUserCookies` (and `inpcClearAllDocumentCookies` on index/login arrival) clears cust / override / see_other / login cookies so override display does not stick.

**Common getters (`custom_js/common.js`):** `Common.GetCustCode` / `Common.GetCustName` / `Common.GetLoginId` (override-aware) — via `inpcGetCookie` from `inpc-portal-cookies.js`; spinners: `Common.ShowAcSpinner` / `Common.HideAcSpinner` (modules e.g. customer_payment.js, change_customer.js).

---

## 4. APIs â€” `com.mmm.portal_common.ChangeCustomer`

Base: `/api/portal/change-customer` (prefix with context, e.g. `/INPCV2`). Requires logged-in session.

| Method | Path | Notes |
|--------|------|--------|
| `GET` | `/autocomplete?value=` | **Production** â€” Hibernate named bind `:like` + scalars; queries `ia_user_master` (active, non-empty `cust_code`) |
| `GET` | `/autocomplete-without-map?value=` | **Test** â€” LIKE embedded in SQL (quote-escaped); `listAsMapsDirectQuery` + scalars |
| `GET` | `/autocomplete-without-map-no-scalars?value=` | **Test** â€” embedded LIKE; JDBC ResultSet labels via `listAsMapsDirectQueryNoScalars` (no scalars map) |

Client used by `change_customer.js`: `$app_url + "api/portal/change-customer/autocomplete"`.

### Response `data` shape (all three)

List of maps with **`code`**, **`name`**, **`value`** only (`value` = `"code - name"`). **No `internal_code`.**

Wrapped in `ResponseDataGeneric` JSON (`errorCode` / `message` / `data`).

> Legacy: `GET /api/auth/customers/autocomplete` still exists on `AuthController` (`sb_customer_master`, includes `internal_code`). The MainPage Change Customer UI does **not** call it; prefer portal endpoints above.

---

## 5. Autocomplete UX

- Menu appended to `#change_customer_modal .modal-body`; on `open`, widget `z-index: 2060` (above Bootstrap modal/backdrop ~1050/1055). CSS: `mainpage-overrides.css` (`.ui-autocomplete`, `#change_customer_modal .ui-autocomplete`).
- Right-side spinner: `#change_customer_ac_spinner` inside `.change-customer-code-wrap` â€” shown in AJAX `beforeSend`, hidden on `complete`.

---

## 6. Nested `file_name` / sibling `html_files` roots

Related MainPage path resolution (not Change Customer-specific, but required for portal menus):

- Nested under default app: `common/ia_menu_options` -> `html_files/{app}/common/ia_menu_options.html` (`app` = `$g_app_tye`, default **INPC**).
- Sibling roots (first path segment, case-insensitive) skip prepending the default app: **`INPC`**, **`CUST_SERVICE`**, **`CUSTOMER_SERVICE`**, **`SERVICEBILLING`** -> `html_files/{file_name}.html`.
- Already starting with `html_files/` is left as-is (no double prefix). `..` rejected.

See `moduleHtmlPath` / `HTML_FILES_SIBLING_ROOTS` in `static/js/MainPage.js`. On disk today: `static/html_files/INPC/`, `static/html_files/CUST_SERVICE/`.

---

## 7. Quick verify

1. User with `see_other_cust_data=Yes` sees **Change Customer Code**; others do not.
2. Open modal, type -> Network: `api/portal/change-customer/autocomplete?value=...` only; spinner on the right; suggestions above modal.
3. Select + **Update** -> `fw_override_*` + `fw_customer_overridden=Yes`; header shows override name.
4. Reload menus while overridden -> home `fw_cust_*` refresh; override cookies preserved; header still override.
5. Prefer portal autocomplete; do not document inventing new query params (`system_name`, etc.).

A module that calls the database with this customer follows [getCustomer.md](./getCustomer.md).
