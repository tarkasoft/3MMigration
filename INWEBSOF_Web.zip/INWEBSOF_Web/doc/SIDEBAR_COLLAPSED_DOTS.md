﻿# Collapsed vertical sidebar dots

When vertical menu is collapsed (icon rail), a **...** button appears at the bottom of the sidebar.
- Click **...** to hide the icon rail completely.
- A floating **...** on the left edge shows the rail again.
- Expanding via hamburger clears the hidden state.
