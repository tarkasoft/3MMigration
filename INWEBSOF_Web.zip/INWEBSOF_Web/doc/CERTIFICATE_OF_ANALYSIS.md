# Certificate of Analysis

Customer page under Information & Support. Enter a stock code and batch id. A matching file can be downloaded. If none is stored, the page asks for the invoice, a carton-label photocopy, and a message, then sends the existing COA mail.

Legacy source is read-only: `C:\Users\DELL\eclipse-workspace\inppc_old\main`. Current source is `INPCV2\src\main`. There is no dummy data on this page.

**Multi-tab DOM (2026-10-04):** shell root is `#m_certificate_of_analysis` (`CertificateOfAnalysis.ROOT`).
Client get/set uses `CertificateOfAnalysis._$home()` / `CertificateOfAnalysis._$("#…")` / `_el`. Same rule as [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md).

---

## Old code (`inpc`)

Live page: `https://inpc.3m.com/inpc/resources/coa/html/coa.html`

| Piece | Path |
|---|---|
| HTML | `webapp/resources/coa/html/coa.html` |
| JS | `webapp/resources/coa/js/coa.js` |
| Lookup and mail | `com.mmm.coa.COA` at `/coa/` |
| SQL helpers | `com.mmm.coa.COACommon` |
| Mail | `com.mmm.coa.SendMailToCOACustomer` |
| Reports | `com.mmm.coa.COA_Excel_Report` at `/COA_Excel_Report/` |

The SQL Server bean is `dataSource_sosr_qa`. The share lookup is a direct JT400 call, not that bean.

### Customer tab

1. `GetCOALoginCustomer` copies the session login, customer, user type, role, and email into hidden fields. The COA Reports tab is shown only when the user type is not `CUST`.
2. Stock code autocomplete is `GetSkuAutoComplete`. SQL is `SO_ItemMaster` joined to `SO_Sales`, top 10 `IPROD` values matching the typed text. For `CUST`, `OBMCUS` must be the customer code. `is_mandatory` is 1 when the stock code starts with `Im`, `Ie`, `Is`, or `IA`.
3. `GetBatchAutoComplete` exists (`EIL.ILOT`, optional `IPROD`). The page-load line that turns it on is commented out, so the live batch box does not suggest values. The customer filter is built and then not used in that SQL.
4. Submit calls `GetCOADocumentList`. SQL is `select top 1 file_name, sku_code, batch_code from coa_file_data where sku_code and batch_code match`.
5. A row inserts `coa_customer_log` with type `Valid Case` and remarks `File Found`, then the page shows one PDF link.
6. No row shows “COA NOT FOUND” and the invoice, date, carton-label upload, message, and Send Mail fields. Invoice suggestions are `GetInvoiceAutoComplete` on `SO_Sales.OBINV#`, excluding order types `1`, `C`, `D`, and `9`.
7. `DownloadCoADoc` calls `BPCSLCLIN.CMW010S('COAINPC','COA','COAINATTH')`. The last result row supplies `NWPATH`, `NWLID`, and `NWPWD`. JCIFS opens `smb:` plus that path plus the file name. Domain `MMM`. Content type is `application/octet-stream`.
8. `SendCOAmailtoCust` reads `coa_mail_setup.to_email`, mails the customer from `3msupport.in@mmm.com` through `mailserv.mmm.com`, copies the internal address, writes `coa_mail_history`, and inserts log type `InValid Case`. The carton file is attached when the SKU is mandatory.

The old SQL is concatenated. The download URL sends the file name only.

### Reports tab

Hidden for `CUST`. Three workbooks from jxl:

| Button | SQL |
|---|---|
| Success Report | `coa_customer_log` where `type = 'Valid Case'` |
| Error Report | `coa_customer_log` where `type = 'InValid Case'`, plus invoice number |
| Error Files | `coa_error_data` ordered by `file_created_date` |

Dates are optional. When both are set, `created_date` or `file_created_date` is between them.

---

## New code (`INPCV2`)

| Piece | Path |
|---|---|
| HTML | `html_files/CUST_SERVICE/certificate_of_analysis.html` |
| JS | `custom_js/CUST_SERVICE/certificate_of_analysis.js` |
| Java | `com.mmm.coa.COA`, `CoaReports`, `CoaSql` |
| Menu `file_name` | `CUST_SERVICE/certificate_of_analysis` |
| Menu `js_path` | `custom_js/CUST_SERVICE/certificate_of_analysis.js` |

The page script calls `CertificateOfAnalysis.Load()`. MainPage does not. The leaf is a menu row under Information & Support.

### Database

Tables stay on dINPC through the existing `infoapps` datasource (`HibernateFactoryRegistry.INFOAPPS`). That pool is already `jdbc:sqlserver://13.232.155.0:1433;databaseName=dINPC` with pool max 30 and min idle 5, and it is not lazy. No second copy of that connection was added. AS400 `CMW010S` still supplies the share.

Queries use the shared `NativeQuerySupport` methods on `HibernateFactoryRegistry.INFOAPPS`. Reads call the parameterized `executeQuery(registry, datasource, sql, values...)`; inserts/updates call `executeUpdate(...)`, which binds values, manages the transaction, and returns the affected-row count. User-provided values remain JDBC parameters and are not concatenated into SQL. AS400 share lookup uses `NativeQuerySupport.executeProcedure(...)`.

**COA query convention:** every database operation in this feature must use `NativeQuerySupport`—parameterized `executeQuery(...)` for reads, `executeUpdate(...)` for writes, and the appropriate `executeProcedure(...)` method for stored procedures. Do not add direct `PreparedStatement`, `Statement`, `createNativeQuery`, or feature-local connection/session execution in COA code. Keep all operations on their existing named datasource (`INFOAPPS` for SQL Server tables and `AS400` for `CMW010S`) and use bind parameters for runtime values.

COA prints rendered SQL with bound values to the application console for local troubleshooting. These values can contain customer identifiers, email addresses, and remarks; keep this diagnostic logging out of production logs.

The same tables are used: `SO_ItemMaster`, `SO_Sales`, `EIL`, `coa_file_data`, `coa_customer_log`, `coa_mail_setup`, `coa_mail_history`, `SO_CustomerMaster`, `coa_error_data`.

### What the screen does

Stock code suggests as you type. Batch suggests once a stock code is entered. Submit looks up `coa_file_data`.

- A file fills the grid: document, stock code, batch, Download. Download reads the share with SMBJ 0.15.0, SMB 3.1.1 only, encryption on. The browser receives the file, not the path or password.
- No file shows the red “COA NOT FOUND” line and the invoice, date, carton upload, message, and Send Mail fields. Upload is required when the stock code starts with `Im`, `Ie`, `Is`, or `IA`.

Mail uses the same host `mailserv.mmm.com` and the same from address `3msupport.in@mmm.com`. The customer address is the session email. The CC is `coa_mail_setup.to_email`. A successful send returns “Your Request is submitted successfully.”

The page uses `ShowErrorMsg()` for validation, lookup, autocomplete, and request errors, and `ShowSuccessMsg()` for a successful request. Do not use browser `alert()` dialogs in the COA module. Invoice Date uses the shared date picker with `dd/mm/yyyy` format; invoice autocomplete may populate the date, and the customer can adjust it before submitting.

The page header and tabs follow the Rebate Programs shell: a title and
supporting line centered on one row, then underline tabs. COA and COA Reports
keep their existing tab behavior.

### Reports

The COA Reports tab is hidden until the session role list contains `INPC_COA_REPORT_DOWNLOAD`. `CoaSql.canDownloadReports` reads `login_user_roles`. `GET /api/customer/coa/context` returns `reportTab`, and the page removes `d-none` from `#coa_report_tab` when that is true. The report downloads check the same role again. Reports are `.xlsx` (Apache POI). Columns match the old Success, Error, and Error Files sheets.

### APIs

`GET /api/customer/coa/context`

`GET /api/customer/coa/sku?phrase=`

`GET /api/customer/coa/batch?phrase=&stockCode=`

`GET /api/customer/coa/invoice?phrase=&stockCode=`

`GET /api/customer/coa/list?stockCode=&batchId=`

`GET /api/customer/coa/file?name=`

`POST /api/customer/coa/request` with stock, batch, invoice, date, message, and optional file

`GET /api/customer/coa/report/log?from=&to=&type=Success|Error`

`GET /api/customer/coa/report/errors?from=&to=`

`from` and `to` are normalized with `CommonFunctions.sqlDate` (accepts portal `dd/mm/yyyy` or `yyyy-MM-dd`; blank → no date filter). Trim elsewhere uses `CommonFunctions.text` (`import static`), same as TSD. Customer sales filters still apply for user type `CUST` or `Customer`. The batch query does not filter by customer, matching the old SQL.
