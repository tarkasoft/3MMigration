# Announcements (header megaphone)

Customer-facing notices from table `ia_announcement`, shown in the MainPage header megaphone dropdown.

## Data (`ia_announcement`)

| Column | Use |
| --- | --- |
| `a_user_type` | Audience. Stores `ia_user_type.internal_code`. `All` (code 5) is every login type. |
| `title` | List title |
| `description` | Short text / list snip; also popup body if `full_desc` is empty |
| `full_desc` | HTML body for the popup (preferred) |
| `sequence` | Sort order (numeric when possible) |
| `from_date` / `to_date` | Active window (inclusive); null = open-ended |

**Who sees what:** rows whose `ia_user_type.user_type_name` is `All`, or whose type name equals the logged-in user type. Ordered by `sequence`.

## Server

One class (no separate controller/service):

- `com.mmm.system.Announcements`
- Endpoint: `GET/POST system/getAnnouncements (client: $host_url + "system/getAnnouncements"; $host_url already ends with titpl/)`
- Uses session `loginUserType`

## Client

Filled after MenuLoad in `MainPage.js`:

```js
Common.FillAnnouncementsData();
```

| Function | Role |
| --- | --- |
| `Common.FillAnnouncementsData()` | `$.ajax` → `system/getAnnouncements`, then render list |
| `Common._renderAnnouncementsList(rows)` | jQuery: `$("#…").empty()`, `$("<button/>")`, `$.each`, `.append` / `.text` / `.show` / `.hide`. Rows use **`onclick="Common.OpenAnnouncementPopup(id)"`** (no `.on` bind). |
| `Common.OpenAnnouncementPopup(id)` | jQuery fills modal title / user type / body / dates; body = `full_desc` or fallback `description` |

Header list markup lives in `MainPage.html` (`#inpc_announce_*` list/badge). Detail modal `#inpc_announce_modal` is in `static/inpc_modal_popup.html` (loaded once via `Common.LoadSharedModals` — see [SHARED_MODALS.md](./SHARED_MODALS.md)). Admin module HTML: `html_files/INPC/ia_announcement.html` (LOV includes **All**).

## Admin tip

After adding announcements, hard-refresh MainPage (or re-login) so MenuLoad runs `FillAnnouncementsData` again.