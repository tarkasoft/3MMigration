# HTML creation (`CreateHtmlFiles`)

Auto-generates module HTML under `html_files/INPC` from menu + schema metadata.

## How to run

1. Mark the module in `ia_menu_options`: `generate_html = 'Yes'` and `active = 'Yes'`.
2. Ensure schema elements exist in `ia_s_user_schema_elements` for that module’s `internal_code`.
3. Call **`Common.CreateHtmlFiles()`** (browser console) or `GET/POST titpl/system/createHtmlFiles`.
4. Companion grids: **`Common.CreateGridFiles()`** / `titpl/system/createGridFiles` when `generate_grid = 'Yes'`.

Java: `com.mmm.system.CreateHtmlFiles`  
JS helper: `custom_js/common.js` → `Common.CreateHtmlFiles()`

## Output paths (dual-write)

Configured in `portal.properties` / `application.yml`:

```properties
inpc.project.base-path=C:/Users/DELL/eclipse-workspace/INPCV2
inpc.project.deploy-path=C:/Users/A6GWBZZ/jboss-eap-8.1.0-dev/jboss-eap-8.1/standalone/deployments/INPCV2.war
```

Each run writes to **all** of:

| Target | Path |
|--------|------|
| Eclipse static | `{base-path}/src/main/resources/static/html_files/INPC/{file_name}.html` |
| Exploded WAR | `{deploy-path}/WEB-INF/classes/static/html_files/INPC/{file_name}.html` |

Grid JS (`CreateGridFiles`) also dual-writes to base static plus `{deploy}/grid_display_files/INPC` and `{deploy}/WEB-INF/classes/static/grid_display_files/INPC`.

After the Java classes are deployed once (Maven clean install), regenerating HTML/JS does **not** need a full rebuild to appear on the running server.

## Module fields (`ia_menu_options`)

| Column | Role |
|--------|------|
| `file_name` | Output file stem (`ia_roles` → `ia_roles.html`) |
| `display_name` | Card title + breadcrumb leaf |
| `field_position` | `TopBottom` (label above) or `LeftRight` (label left / input right) |
| `grid_position` | `Bottom` / `Top` / `Left` / `Right` — form vs `#grid_{file_name}` layout |
| `html_width` / `grid_width` | Bootstrap column widths when side-by-side |
| `grid_height` | Min-height for side-by-side form card |
| `ref_menu_group_code` / `ref_menu_subgroup_code` | Joined for breadcrumb menu / submenu names |

## Generated page structure

Every page shares the same shell so **top spacing matches** across TopBottom and LeftRight:

```html
<div class="container-fluid px-0 inpc-gen-module">
  <nav id="breadcrumb_{file_name}" class="inpc-module-breadcrumb mb-2">
    <!-- Home > menu > submenu > display_name -->
  </nav>
  <div class="inpc-gen-body">
    <!-- form #m_{file_name} + #grid_{file_name} by grid_position -->
  </div>
</div>
```

### Top padding rule

### Short pages / no window scroll

Theme `.page` is `display:flex; justify-content:center; min-height:100vh`. Short modules (e.g. side-by-side Roles) do not overflow the viewport, so the flex centering adds empty space above the breadcrumb. Tall pages (form + grid stacked) scroll and look fine.

Override in `mainpage-overrides.css` (`INPC_PAGE_TOP_ALIGN`): `justify-content: flex-start` so every generated page sits tight under the top menu whether or not the window scrolls.

- Root `.inpc-gen-module` and the breadcrumb have **no extra top padding/margin**.
- Spacing under the horizontal menu is owned by MainPage / `mainpage-overrides.css` (`INPC_GEN_MODULE` block).
- Side-by-side uses `row gx-3 gy-0` (no vertical gutter pull).
- Do **not** add page-level `mt-*` / `pt-*` above the breadcrumb in the generator.

### Breadcrumb

- Unique id: `#breadcrumb_{file_name}`.
- Trail: Home → `menu_name` → `sub_menu_name` → `display_name`.
- Home link calls `LoadHtmlFiles` for the user-type home module.

### Form + grid

- Form host: `#m_{file_name}` inside a card (`card-body p-3`).
- Actions host: `#page_main_actions_div` (FrameWork buttons).
- `ia_menu_options.custom_links` is drawn there as extra buttons. Format: `Label~function();`, several separated by `|`. Optional third part is a Bootstrap color (`Preview~PreviewWelcomeMessage();~info`). A stored value that already contains an HTML tag and no `~` is inserted as-is.
- Grid host: `#grid_{file_name}` (jqGrid from generated `grid_display_files/INPC/{file_name}.js`).
- LeftRight labels: `col-sm-4` / inputs `col-sm-8`.
- Field columns use `mb-3` (theme overrides Bootstrap gutters).

### Element controls (`ia_s_user_schema_elements`)

| `data_type` | Control |
|-------------|---------|
| Text / default | text input |
| Number | number input |
| List Of Values | select (`list_of_values` split on `\|`) |
| Reference Data | Popup search when `is_ref_module_code_lov` is not 1. When it is 1, an empty `<select id="{system_name}">` (options loaded by AssignRefModuleLovValues). `populate_lov` is read with that flag. |
| Checkbox | checkbox |
| Date / Month | date / month inputs |
| TextArea / Text Area / Large Text | `<textarea>`. `rows` comes from `text_area_rows` on `ia_s_user_schema_elements`. Empty, null, or 0 uses **3**. |

`field_position` on elements: `Next Line` vs `NextColumn`. `optional` drives required `*`.

## CSS

`static/css/mainpage-overrides.css` — block `INPC_GEN_MODULE`.  
Bump `MainPage.html` cache query (`mainpage-overrides.css?v=…`) when changing it.

## Related

- Template reference: `html_files/INPC/ia_roles.html`
- Grids: `CreateGridFiles` / `STATIC_DEPLOY.md` for publish paths
- Menus API active filter: `mo.active = 'Yes'` (same as AuthService)

---

## Generated file header

Every generated HTML starts with `<!-- This file is created by Framework System -->`. Grid/Popup JS starts with `/* This file is created by Framework System */`.

## Related Framework Tools

See **[FRAMEWORK_TOOLS.md](./FRAMEWORK_TOOLS.md)** for:

- **Create Popup** (`CreatePopupFiles`) — `include_in_popup=1` → `pop_up_{file_name}.js`
- **Sync Module Layout** — update `ia_menu_options` + `ia_s_user_schema_elements` from form + existing HTML (preview / Go Back / Proceed)
- Create Grid also respects **`include_in_grid=1`** when filtering elements

Shared modals for Sync Layout: [SHARED_MODALS.md](./SHARED_MODALS.md).
