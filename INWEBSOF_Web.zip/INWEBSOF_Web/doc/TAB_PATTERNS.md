# Tab UI patterns (`sb_tab.html`)

**File:** `src/main/resources/static/html_files/INPC/sb_tab.html`  
**Open via:** menu `file_name` = `sb_tab` → loads `html_files/INPC/sb_tab.html`, or load from Home / module opener. Load Type Internal (no FW schema).

## Patterns included

1. Nav tabs (underline)  
2. Nav pills  
3. Fill + justified  
4. Nav underline  
5. Vertical pills  
6. Pill rail (Home-style dark active)  
7. Segmented control  
8. Soft / ghost pills  
9. Icons + badges  
10. Card header tabs  
11. Button-group tabs  
12. Themed active colors (blue / teal / amber)  
13. Disabled tab  
14. Nested tabs  

Uses Bootstrap 5 `data-bs-toggle="tab"` (already on MainPage). Content lines are one-liners for visual comparison only.

## Convention

When shipping product tabs, prefer **one** pattern from this lab (usually pill rail #6 or card header #10) for consistency — do not mix all styles on one screen.

## Home

`sb_tab.html` is a UI lab page only. It is **not** included as a Home tab (Home keeps Overview + dashboards 1–3 only).
