# Shop Order Return

The Shop Order Return page is under `html_files/SHOPORDER/shop_order.html`, with its interactions in `custom_js/SHOPORDER/shop_order.js`. It follows `JS_MODULE_STANDARD.md` and keeps the `m_shop_order_home` root.

The page header displays the effective Vendor No. from the active customer override, or the logged-in customer when there is no override. Tabs are provided for Shop Order Return Screen, My Request, and Report; My Request and Report remain placeholders until their data flows are implemented. The temporary request-number/vendor entry banner has been removed.

## Shop Order lookup

`application.yml` selects the configured AS/400 pool through `inpc.shop-order.as400` (`as400` = `US400IN`; `as400ind` = `US400IND`). Until the Shop Order procedure name and parameter/result contract are provided, the endpoints below return temporary sample records; they do not call AS/400. Selecting an autocomplete result loads the matching mock header and material items into the page; users cannot add extra material lines.

| Endpoint | Purpose |
|---|---|
| `GET /api/customer/shop-order/autocomplete?term=` | Search sample shop orders and return summary details for each suggestion |
| `GET /api/customer/shop-order/details/{shopOrder}` | Return the selected order's warehouse, finished good, requested quantity, and material items |

The warehouse, finished good, requested quantity, and material issue details are populated after selection. Each return line starts with Sl no. Child SKU, required quantity, and issue quantity are disabled. Replace the mock data in `com.mmm.shoporder.ShopOrder` with the agreed AS/400 calls when the procedure contract is available.

Header documents are limited to 3 MB per file in the browser; larger files are rejected with an error.

## Finished Good attachments

The Finished Good section has separate multiple-file pickers for required Invoice Copy, DC Copy, E-way Bill Copy, and optional Other Documents. Current file selection, viewing, and deletion are browser-local only; files are not uploaded or persisted. Upload handling and the claim save flow are not wired yet.
