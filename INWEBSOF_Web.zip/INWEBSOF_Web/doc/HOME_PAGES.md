# Home pages and landing dashboards

MainPage opens a **different Home HTML** depending on the logged-in user type. That mapping lives in `static/js/MainPage.js` as `inpcHomeModuleForUserType`. Customer and Distributor homes then load **dashboard fragments** into an inner panel; Admin and Customer Service homes are static landings (no dashboard tabs).

This is the **portal landing** (side-menu Home). It is separate from the **CIR module Dashboard** tab (`CIR/cir_home` → `cir_dashboard.html`). See [CIR_MIGRATION.md](./CIR_MIGRATION.md) for CIR.

## Mapping

| Login user type | Home file (`html_files/INPC/…`) | Dashboard tabs? |
|-----------------|----------------------------------|-----------------|
| Admin | `home_admin.html` | No (static landing) |
| Customer | `home_customer.html` | Yes (tabs 1–8) |
| Distributor | `home_distributor.html` | Yes (tabs 1–7) |
| Customer Service | `home_customer_service.html` | No (static landing) |
| (anything else / missing) | `home_customer.html` (default) | Yes |

User type comes from cookie `fw_login_user_type` / menus via `inpcGetLoginUserType()`.

## Load flow (MainPage → shell → board)

```
MainPage ready
  → loadMasters() → loadMenus()
  → openHome()
       loadPage(moduleHtmlPath(inpcHomeModuleForUserType(...)), "Home", null, "home")
  → jQuery .load() of home_*.html into #home_dashboard (or InpcTabs pane if include-tabs)
  → (Customer / Distributor / home_Page only)
       inline script on that shell:
         click tab → #home_dash_panel.load(data-path)
         first tab (Overview) loads on open
```

### Step detail

1. **`openHome()`** in `MainPage.js` resolves the home module name with `inpcHomeModuleForUserType(inpcGetLoginUserType())`, then `moduleHtmlPath` → `html_files/INPC/{name}.html`.
2. **`loadPage(path, "Home", null, "home")`** sanitizes the path, empties `#home_dashboard` (or opens the single Home tab when Include Tabs is on), then `$pane.load(path)`.
3. **Shell HTML** (`home_customer.html`, `home_distributor.html`, or legacy `home_Page.html`) owns the tab strip (`#homeDashTabs`) and panel (`#home_dash_panel`).
4. Each tab button has `data-path` (full URL under `html_files/INPC/…`) and `data-title`.
5. **`loadDashboard(btn)`** (inline IIFE on the shell):
   - Ignores clicks while a load is in progress.
   - Skips reload if the same `data-path` is already showing (and not the loading spinner).
   - Shows a spinner in `#home_dash_panel`, then `$panel.load(url?v=timestamp)`.
   - On success calls `initCommonWidgets` on the panel when available.
6. On shell open, **`#home_tab_0` (Overview)** is loaded automatically.

Dashboard board HTML is **not** selected inside `MainPage.js`. MainPage only loads the home shell; the shell script loads each board fragment.

## Dashboard tab → fragment

Overview is always `html_files/INPC/home_overview.html`. Do **not** point Overview at root `home.html`.

| Tab # | Label | Fragment | Customer | Distributor / `home_Page` |
|------:|-------|----------|:--------:|:-------------------------:|
| 1 | Overview | `home_overview.html` | ✓ | ✓ |
| 2 | Sales | `sb_dash_board_1.html` | ✓ | ✓ |
| 3 | Operations | `sb_dash_board_2.html` | ✓ | ✓ |
| 4 | Accounts | `sb_dash_board_3.html` | ✓ | ✓ |
| 5 | Sales Performance | `sb_dash_board_4.html` | ✓ | ✓ |
| 6 | Sales Pulse | `sb_dash_board_5.html` | ✓ | ✓ |
| 7 | Channel Sales | `sb_dash_board_6.html` | ✓ | ✓ |
| 8 | Sales Insight | `sb_dash_board_7.html` | ✓ | — |

Aliases of boards 1–4: `Dashboard1.html` … `dashboard4.html` under `html_files/INPC/`.

Board notes: [SB_DASH_BOARD_4.md](./SB_DASH_BOARD_4.md), [SB_DASH_BOARD_5_6.md](./SB_DASH_BOARD_5_6.md), [SB_DASH_BOARD_7.md](./SB_DASH_BOARD_7.md).

### Board conventions

- Demo / sample chart data until real APIs exist. ApexCharts is already on MainPage.
- Use `dd-fullwidth` so content uses the pane width.
- Prefer Remix icons (`ri-*`). Chart IDs must stay unique (`dd1_*` … `dd7r_*`).
- Fragments loaded with jQuery `.load()` should bind clicks with `onclick` → `window.*` when listeners inside an IIFE do not attach.

`home_Page.html` has no page-header breadcrumb — tabs start under the top menu.

## How Home is opened (menu / helpers)

1. Side/top **Home** leaf sets `data-file-name` from the user-type mapping and calls `LoadHtmlFiles(…)`.
2. Initial load: `loadMasters()` waits for menus, then `openHome()` as above.
3. Any “go Home” helper must use `inpcHomeModuleForUserType` — do not hard-code one home file.

## Include Tabs

When `include-tabs` is **true** (see [INCLUDE_TABS.md](./INCLUDE_TABS.md)):

- There is **one** Home tab (key `home`), not one tab per home file.
- That tab still loads the **correct** HTML for the current user type (`home_admin` vs `home_customer`, etc.).
- Admin does not get Customer Home content (and the reverse); only the tab label is shared (“Home”).

When `include-tabs` is **false**, Home replaces `#home_dashboard` with the mapped file.

## Manual edits

Home pages are mostly hand-built under `html_files/INPC/`. They often do **not** use `#m_{file_name}` (unlike CreateHtmlFiles masters). That is fine for Home. If a Home page later embeds FW forms, wrap those forms in `#m_…` as usual.

## Related

- [HOME_LOGIN_TYPE.md](./HOME_LOGIN_TYPE.md) — short mapping cheat sheet
- [INCLUDE_TABS.md](./INCLUDE_TABS.md) — optional module tabs
- [DeskMobile.md](./DeskMobile.md) — device-specific HTML (separate from Home mapping)
- [CIR_MIGRATION.md](./CIR_MIGRATION.md) — CIR module Dashboard (not landing Home)
