# SB Dash Board 7 — Sales Insight

**Fragment:** `src/main/resources/static/html_files/INPC/sb_dash_board_7.html`  
**Root id / class:** `#sb_dash_board_7` / `.dd7r` + `.dd-fullwidth`  
**Home tab label:** **Sales Insight**  
**Loads via:** same jQuery `.load()` pattern as boards 4–6 (`html_files/INPC/sb_dash_board_7.html`)

## Why this board is different

Boards 4–6 use a **2×3 equal card grid** (often with soft full-width header gradients). Board 7 uses a **new layout language**:

1. **Top KPI strip** — 4 equal tiles (YTD Sales, Current AR %, Total AR Exposure, ACH Bounce MTD) with left accent rails (sky / violet / teal / rose), dense numbers, delta chips, and mini sparklines.
2. **Asymmetric main band** — ~8-col Sales Trend (multi-hue area + YTD/MTD pills) + ~4-col stacked AR Composition (donut) and Collection Health (radialBar).
3. **Bottom band** — ~5-col Monthly Sales Mix (horizontal multi-color bars) + ~7-col Ops Pulse (table + ACH/DBT combo with thin divider).

Visual differences vs board 5:

- White cards + **left accent rail** (no lavender/sky full header bars on every panel)
- Multi-color palette: cyan / violet / teal / orange / pink (not single-hue theme)
- CSS dots instead of Remix icons (parent page may not expose remixicon inside fragment)

## Charts (`window.__dd7rCharts`)

| Id | Type | Notes |
|----|------|--------|
| `dd7r_spark_*` | area sparkline | KPI tiles |
| `dd7r_sales_chart` | multi-series area | YTD/MTD toggle via `dd7rSalesTab` |
| `dd7r_ar_donut` | donut | 1-30 / 31-60 / 61-90 / >90 (board-5 aligned totals) |
| `dd7r_collect_gauge` | radialBar | Collected % |
| `dd7r_mix_bars` | horizontal bar | % in 1–15 days |
| `dd7r_ops_chart` | column + area + line | ACH / DBT / instruments |

On reload, previous Apex instances in `window.__dd7rCharts` are destroyed.

## Sample data

Aligned with board 5 where sensible (sales series, AR exposure 28,640,500 split, ACH bounce, monthly 1–15 mix for 2026).

## Home wiring

**Current (2026-09-22):** tab **Sales Insight** (`home_tab_7`, number 8) is on `home_customer.html` only, after Channel Sales.

Not yet on `home_distributor.html` or `home_Page.html` (those stop at Channel Sales / board 6). Add the same button there when those shells should show Sales Insight.

Example button (match existing markup / `data-file` / folder prefix exactly):

```html
<button type="button" class="nav-link" id="home_tab_7" data-dash="7"
        data-file="sb_dash_board_7.html" data-title="Sales Insight" role="tab" aria-selected="false">
  <span class="tab-num">7</span> Sales Insight
</button>
```

Folder should remain whatever boards 5/6 use (typically `html_files/INPC/`).

## Deploy mirrors

Copy the same HTML into any of these if present:

- `html_files/INPC/` (non-src tree)
- `tmp0\wtpwebapps\INPCV2\html_files\INPC\`
- `target\classes\static\html_files\INPC\`
- `target\INPCV2\html_files\INPC\` (if used)

## Do not

- Rewrite boards 4–6
- Recolor the 2×3 grid and call it board 7
