# INPCV2 documentation

Start with **[CURSOR_PROJECT_GUIDE.md](./CURSOR_PROJECT_GUIDE.md)** (project handoff, refreshed 2026-10-03, section 17). Document upload/download uses SMB 3.1.1 (section 14).

**Standing rule:** update the matching doc in the same pass whenever project behavior or structure changes. If the architecture decision changes, update the handoff guide too.

**New module JS:** always follow [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) (plain jQuery; reference `custom_js/TSD/tsd.js`).

## Start here

| Doc | Use when |
|-----|----------|
| [CURSOR_PROJECT_GUIDE.md](./CURSOR_PROJECT_GUIDE.md) | Onboarding, architecture, paths, home, load types |
| [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) | **Any new module UI JS** — `Load` → context → tabs → `.load` once → DataTable |
| [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md) | Hibernate / NativeQuery / sessions |
| [Generic_Transactional_Module_Coding_Standard.md](./Generic_Transactional_Module_Coding_Standard.md) | Java save / multi-table transaction pattern (TSD, Ship and Debit, …) |
| [AUTHENTICATION.md](./AUTHENTICATION.md) | Login, session, cookies, `$host_url` / `$app_url` |
| [Imext.md](./Imext.md) | IMEXT / Azure B2C (off by default) |
| [STATIC_DEPLOY.md](./STATIC_DEPLOY.md) | Eclipse/Tomcat static 404 / publish paths |
| [AutoDeploy-JBoss.md](./AutoDeploy-JBoss.md) | Eclipse builder copies classes into EAP exploded WAR |
| [DEPENDENCY_VAPT.md](./DEPENDENCY_VAPT.md) | Maven dependency versions and VAPT notes |

## Portal UI

| Doc | Use when |
|-----|----------|
| [HOME_PAGES.md](./HOME_PAGES.md) | Landing Home by user type + dashboard tab load logic (`MainPage` → shell → `#home_dash_panel`) |
| [HOME_LOGIN_TYPE.md](./HOME_LOGIN_TYPE.md) | Short cheat sheet: home file + dashboard tabs |
| [INCLUDE_TABS.md](./INCLUDE_TABS.md) | Optional Home + module tabs (`include-tabs`, styles 1–6) |
| [CHANGE_CUSTOMER.md](./CHANGE_CUSTOMER.md) | Change Customer Code / portal autocomplete |
| [getCustomer.md](./getCustomer.md) | How a module passes the customer and how Java gets the customer code |
| [Announcements.md](./Announcements.md) | Header megaphone + announcement detail modal |
| [SHARED_MODALS.md](./SHARED_MODALS.md) | MainPage welcome vs `inpc_modal_popup.html` |
| [WELCOME_MESSAGE.md](./WELCOME_MESSAGE.md) | Login welcome popup, acknowledgement, active flag |
| [DeskMobile.md](./DeskMobile.md) | DeskMobile load type (desktop vs mobile HTML) |
| [SIDEBAR_TOGGLE.md](./SIDEBAR_TOGGLE.md) | Vertical sidebar hamburger |
| [SIDEBAR_FLYOUT_LABELS.md](./SIDEBAR_FLYOUT_LABELS.md) | Flyout / double-menu labels |
| [SIDEBAR_COLLAPSED_DOTS.md](./SIDEBAR_COLLAPSED_DOTS.md) | Collapsed icon-rail dots |
| [TAB_PATTERNS.md](./TAB_PATTERNS.md) | Bootstrap tab lab (`html_files/INPC/sb_tab.html`) |

## Modules and dashboards

| Doc | Use when |
|-----|----------|
| [SB_DASH_BOARD_4.md](./SB_DASH_BOARD_4.md) | Sales Performance tab (board 4) |
| [SB_DASH_BOARD_5_6.md](./SB_DASH_BOARD_5_6.md) | Sales Pulse / Channel Sales |
| [SB_DASH_BOARD_7.md](./SB_DASH_BOARD_7.md) | Sales Insight (customer home tab 8) |
| [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md) | **Global** new-module JS: plain jQuery `Load` → context → tabs → `.load` once → DataTable |
| [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md) | Tabbed pages + points at JS standard; load once, Refresh, Common.DataTable |
| [MY_ORDERS.md](./MY_ORDERS.md) | CUST_SERVICE My Orders |
| [ACCOUNT_STATUS.md](./ACCOUNT_STATUS.md) | Account Status tabs |
| [INV_CR_DR_DOWNLOAD.md](./INV_CR_DR_DOWNLOAD.md) | Invoice / Credit Note Download |
| [3M_INFORMATION.md](./3M_INFORMATION.md) | 3M Information page |
| [HTML_CREATION.md](./HTML_CREATION.md) | CreateHtmlFiles / CreateGridFiles generators |
| [CREATE_TABLES_AND_ELEMENTS.md](./CREATE_TABLES_AND_ELEMENTS.md) | Menu-option save creates the table; element save adds or renames the column |
| [FRAMEWORK_TOOLS.md](./FRAMEWORK_TOOLS.md) | Create HTML/Grid/Popup, Sync Module Layout |
| [CSD_DATASOURCE.md](./CSD_DATASOURCE.md) | Warranty DB `dINTWSYS` (`csd` / `TSD` alias) + CSD smoke APIs |
| [SHIP_AND_DEBIT.md](./SHIP_AND_DEBIT.md) | Contract Claim Management. First screens and APIs are in INPCV2 |
| [CIR_MIGRATION.md](./CIR_MIGRATION.md) | Customer Issue Resolution: Dashboard, New Request, My Requests, SMB 3.1.1 docs |
| [TSD_MIGRATION.md](./TSD_MIGRATION.md) | TSD E-Warranty: legacy discovery, `dINTWSYS`, phased INPCV2 plan |
| [TSD_SYSTEM.md](./TSD_SYSTEM.md) | TSD living map: HTML/JS/Java paths, each API + params → Java class |
| [EWARRANTY_MIGRATION.md](./EWARRANTY_MIGRATION.md) | CSD graphic E-Warranty (Converter/Distributor/End Customer) — **not TSD** |
| [EWARRANTY_SYSTEM.md](./EWARRANTY_SYSTEM.md) | EW living map: APIs, files, PPF + Graphics New Request (template / tabs / invoice / product sections) vs legacy |
| [REBATE_PROGRAMS_MIGRATION.md](./REBATE_PROGRAMS_MIGRATION.md) | Rebate programs / claims |
| [ROLE_RIGHTS.md](./ROLE_RIGHTS.md) | Role permissions and user-role Excel upload/download |
| [CERTIFICATE_OF_ANALYSIS.md](./CERTIFICATE_OF_ANALYSIS.md) | COA download (SMB 3.1.1) |
| [POLICIES_GUIDELINES.md](./POLICIES_GUIDELINES.md) | Agreements share download (SMB 3.1.1) |

## Other

| Doc | Use when |
|-----|----------|
| [owasp-suppressions.xml](./owasp-suppressions.xml) | OWASP Dependency-Check suppressions |
