# Invoice / Credit Note Download (CUST_SERVICE)

Follow [PORTAL_MODULE_TABS.md](./PORTAL_MODULE_TABS.md). One screen, not tabs. Reference: `customer_payment.js` for the load and session handling, `my_orders.js` for the grid and dates.

## Paths

- HTML: `html_files/CUST_SERVICE/inv_cr_dr_download.html`
- JS: `custom_js/CUST_SERVICE/inv_cr_dr_download.js`
- Java: one class, `com.mmm.customer.InvCrDrDownload`
- Menu `file_name`: `CUST_SERVICE/inv_cr_dr_download` (internal_code 1560)

The page script calls `InvCrDrDownload.Load()`. MainPage does not.

## Load

The page loads the grid once. Search and Refresh load again with the current document type and dates. The loaded flag is `$("#m_inv_cr_dr_download").data("listLoaded")`.

From Date defaults to the 1st of the month. To Date defaults to today (`dd/mm/yyyy`). Both dates are required. The difference must be less than 60 days. Search and the list API both reject a longer range.

Customer code is `Common.GetCustCode()`.

## APIs

Both are on the same class. Sample rows for now. The class keeps an AS400 session for the later procedure.

- `GET /api/customer/inv-cr-dr/list?custCode=&loginId=&docType=&fromDate=&toDate=`
- `GET /api/customer/inv-cr-dr/download?custCode=&docNo=&docType=`

`docType` is `SI` (Sales Invoice), `CN` (Credit Note), or `DN` (Debit Note). Dates on the list call are `yyyymmdd` from `DateFormatYYYYMMDD()`. The Download cell opens the download URL on that same class and returns a sample PDF.
