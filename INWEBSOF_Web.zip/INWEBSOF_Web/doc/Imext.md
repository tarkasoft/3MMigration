﻿# INPCV2 — IMEXT (IAMExt / Azure B2C) login flow

Reference for how Microsoft IAMExt OAuth2 is wired in this WAR.
Last updated: 2026-09-19.

---


## 0. Enable / disable IMEXT (cheat sheet)

| Action | Where | What to set |
|--------|--------|-------------|
| **Disable (default / local portal)** | `src/main/resources/application.yml` | `security.imext.enabled: false` **and** leave `spring.profiles.active=imext` **commented out** |
| **Enable** | `application.yml` | Uncomment `spring.profiles.active: imext` **and** set `security.imext.enabled: true` |
| OAuth client secrets / redirect | `src/main/resources/application-imext.yml` | Loaded **only** when profile `imext` is active. This file sets `security.imext.enabled: true` when loaded. |

**Right now (after this change):** IMEXT is **disabled** — profile `imext` is commented out, `security.imext.enabled: false`.

**Verify after redeploy:** `http://localhost:8090/INPCV2/api/info` → `"imextEnabled": false`  
Startup log should **not** say `The following 1 profile is active: "imext"`.

---

## 1. Quick URLs (local EAP)

| Step | URL | Who owns it |
|------|-----|-------------|
| Start IMEXT | `http://localhost:8090/INPCV2/api/auth/imext/start` | Our Java (`ImextAuthController`) |
| Spring → B2C | `http://localhost:8090/INPCV2/oauth2/authorization/iamext` | Spring Security (jar) |
| Azure callback (redirect URI) | `http://localhost:8090/INPCV2/login/oauth2/code/iamext` | Spring Security (jar) — **not** a `@RequestMapping` in our code |
| App response / gate | `http://localhost:8090/INPCV2/api/auth/imext/response` | Our Java (`ImextAuthController`) |
| Portal home | `http://localhost:8090/INPCV2/MainPage.html` | Static UI |
| Smoke status JSON | `http://localhost:8090/INPCV2/api/auth/imext/status` | Our Java |
| Info (imextEnabled flag) | `http://localhost:8090/INPCV2/api/info` | `HealthInfoController` |
| Optional manual bootstrap | `POST /INPCV2/api/auth/bootstrap-by-enl-id` | `AuthController` (backup API, not Azure redirect) |

**Prod Azure redirect already registered (legacy INPC):**  
`https://inpc.3m.com/inpc/login/oauth2/code/iamext`

**Local URI to ask the team to register in Azure:**  
`http://localhost:8090/INPCV2/login/oauth2/code/iamext`

---

## 2. End-to-end flow

```
Browser
   |
   | 1) GET /api/auth/imext/start
   v
ImextAuthController.start()
   |
   | 2) 302 → /oauth2/authorization/iamext
   v
Spring OAuth2 (jar)
   |
   | 3) 302 → mmmciam.b2clogin.com  (B2C_1A_3MA authorize)
   v
User signs in at Azure B2C / IAMExt
   |
   | 4) 302 → /login/oauth2/code/iamext?code=...&state=...
   |    (this path is Spring’s built-in callback — no Java @GetMapping in com.mmm)
   v
Spring exchanges code at token-uri, loads userinfo (upin claim)
   |
   | 5) ImextOAuth2LoginSuccessHandler.onAuthenticationSuccess()
   |      - read claim "upin" (= ENL_ID)
   |      - AuthService.bootstrapSessionByEnlId(request, enlId)
   |          → DB ia_user_master + roles
   |          → UserSessionSupport.store(session, user)
   |      - 302 → /api/auth/imext/response
   v
ImextAuthController.response()
   |
   | 6) if session logged in → 302 → /MainPage.html
   |    if ?error=...        → 302 → /login.html?error=...
   v
MainPage.html
   |
   | 7) UI calls /api/auth/me and /api/auth/menus (session already set)
   v
Portal ready
```

### Failure path

Errors are **plain text in the browser** (HTTP 401/500). They do **not** redirect to `login.html`
(`login.html` is local/dev login only).

```
OAuth / B2C fails
   → ImextOAuth2LoginFailureHandler
   → text/plain: "IMEXT error: oauth_failed" + exception detail
```

Success-handler / response errors (same plain-text style via `ImextErrorResponses`):
- `missing_upin` — no `upin` claim on the OAuth user
- `bootstrap_failed` — DB/exception during bootstrap
- `user_not_found` — ENL_ID not active in `ia_user_master`
- `imext_session_missing` — `/response` hit without a bootstrapped session
- `imext_disabled` — start called while IMEXT off

---

## 3. Where user details come from

| Step | Gets user from? |
|------|-----------------|
| `/api/auth/imext/response` | **No.** Only checks HttpSession, then redirects. |
| `ImextOAuth2LoginSuccessHandler` | **Yes.** OAuth claim `upin` → `AuthService.bootstrapSessionByEnlId` → SQL Server `ia_user_master`. |
| `/api/auth/me`, `/api/auth/menus` | Session (+ DB as needed) after bootstrap. |
| `POST /api/auth/bootstrap-by-enl-id` | Same bootstrap service, but via HTTP param `enlId` (manual/legacy style). |

**Important:** Azure redirect URL ≠ `bootstrap-by-enl-id`.  
Azure must call `/login/oauth2/code/iamext`. Bootstrap of portal session is done in the success handler (or optionally via the POST API).

---

## 4. How to enable

### `application.yml`
- `spring.profiles.active: imext`
- `security.imext.enabled: true` (also forced true in profile file)

### `application-imext.yml`
- OAuth client registration id: **`iamext`**
- Provider: B2C policy `B2C_1A_3MA` on `mmmciam.b2clogin.com`
- `user-name-attribute: upin`
- `redirect-uri: http://localhost:8090/INPCV2/login/oauth2/code/iamext` (explicit local)

### Maven
- `spring-boot-starter-oauth2-client` must **not** be `<optional>true</optional>`  
  (otherwise EAP gets `ClassNotFoundException: OAuth2AuthorizedClientRepository`)

### After deploy
1. Restart / redeploy WAR to EAP  
2. Open `/api/info` → `"imextEnabled": true`  
3. Open `/api/auth/imext/start` → browser should go to B2C  

---

## 5. Files involved (full list)

### Config
| File | Role |
|------|------|
| `src/main/resources/application.yml` | Default `security.imext.enabled`, `spring.profiles.active=imext` when testing |
| `src/main/resources/application-imext.yml` | IAMExt client-id/secret, scopes, redirect-uri, B2C endpoints, `upin` |
| `pom.xml` | `spring-boot-starter-oauth2-client` (required, packaged into WAR) |

### Security / OAuth wiring
| File | Role |
|------|------|
| `src/main/java/com/mmm/config/security/SecurityConfig.java` | If IMEXT on: `authorizeHttpRequests` + `.oauth2Login(...)`; login page = `/api/auth/imext/start`; wires success + failure handlers; permits `/login/oauth2/**`, `/oauth2/**`, `/api/auth/imext/**` |
| `src/main/java/com/mmm/config/security/ImextOAuth2LoginSuccessHandler.java` | After Spring callback: read `upin`, `bootstrapSessionByEnlId`, redirect to `/api/auth/imext/response` |
| `src/main/java/com/mmm/config/security/ImextOAuth2LoginFailureHandler.java` | On OAuth failure → `/api/auth/imext/response?error=oauth_failed` |
| `src/main/java/com/mmm/config/security/ImextSecurityProvision.java` | Logs IMEXT on/off; exposes tenant/policy to `/api/info` |

### Auth / session
| File | Role |
|------|------|
| `src/main/java/com/mmm/authentication/ImextAuthController.java` | `/api/auth/imext/start`, `/response`, `/status` |
| `src/main/java/com/mmm/authentication/AuthController.java` | Local `/api/auth/login`, optional `POST /api/auth/bootstrap-by-enl-id`, `/me`, `/menus`, `/logout` |
| `src/main/java/com/mmm/authentication/AuthService.java` | `bootstrapSessionByEnlId`, `loadUserByEnlId`, menus, theme |
| `src/main/java/com/mmm/authentication/UserSessionSupport.java` | Session attribute keys + `isLoggedIn` / `store` |
| `src/main/java/com/mmm/authentication/SessionLoginInterceptor.java` | Optional `/api/**` session gate (`security.session-check.enabled`) |
| `src/main/java/com/mmm/authentication/package-info.java` | Package notes for IMEXT vs local login |
| `src/main/java/com/mmm/config/WebMvcConfig.java` | Excludes `/api/auth/imext/**` from session interceptor when gate is on |

### Smoke / UI
| File | Role |
|------|------|
| `src/main/java/com/mmm/web/HealthInfoController.java` | `/api/info` returns `imextEnabled`, `imextPolicy` |
| `src/main/resources/static/MainPage.html` | Portal after login |
| `src/main/resources/static/login.html` | Local login / error landing |

### Not in our Java (framework)
| Path | Role |
|------|------|
| `/oauth2/authorization/iamext` | Spring starts authorization redirect to B2C |
| `/login/oauth2/code/iamext` | Spring receives Azure redirect, exchanges `code` |

---

## 6. Sequence (who calls whom)

1. **ImextAuthController.start** → redirect → Spring `/oauth2/authorization/iamext`  
2. **Spring** → B2C authorize URL (from `application-imext.yml` `authorization-uri`)  
3. **Azure** → browser → Spring `/login/oauth2/code/iamext`  
4. **Spring** → token + userinfo → builds `OAuth2User` (`upin`)  
5. **ImextOAuth2LoginSuccessHandler** → **AuthService.bootstrapSessionByEnlId** → **UserSessionSupport.store**  
6. **ImextAuthController.response** → **MainPage.html**  
7. **MainPage** → **AuthController** `/me` / `/menus`

---

## 7. Checklist for local test

- [ ] `security.imext.enabled=true` and profile `imext` active (see startup log: `The following 1 profile is active: "imext"`)
- [ ] WAR contains oauth2-client jars (no `OAuth2AuthorizedClientRepository` ClassNotFound)
- [ ] `application-imext.yml` redirect-uri = `http://localhost:8090/INPCV2/login/oauth2/code/iamext`
- [ ] Same URL registered in Azure app registration
- [ ] `/api/info` shows `imextEnabled: true`
- [ ] Open `/api/auth/imext/start` → lands on `mmmciam.b2clogin.com`
- [ ] After login, session bootstraps and MainPage loads
- [ ] User’s ENL_ID equals B2C `upin` and exists/active in `ia_user_master`

---

## 8. Common confusion

| Myth | Reality |
|------|---------|
| “We need `@GetMapping(\"/login/oauth2/code/iamext\")`” | No — Spring Security jar handles it |
| “Azure should redirect to `/bootstrap-by-enl-id`” | No — that is a POST API for ENL_ID bootstrap only |
| “`/api/auth/imext/response` loads the user from IMEXT” | No — success handler already did; response only checks session and redirects |
| “`{baseUrl}/login/oauth2/code/{registrationId}`” | Spring template form; we use the **explicit** local URL in YAML for clarity |

---

## 9. Related docs / build notes

- Root `README.md` — app URLs, build, datasources  
- EAP deploy path: `C:/Users/A6GWBZZ/jboss-eap-8.1.0-dev/jboss-eap-8.1/standalone/deployments/INPCV2.war` (`portal.properties` `inpc.project.deploy-path`)  
- HTTP port often **8090** on this EAP install (not 8080)

