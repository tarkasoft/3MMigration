# Portal module tabs + JS standard

Standing rule for **all new** customer / portal modules with tabs (and the preferred shape for any new module JS).

**JS standard (global):** [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md)  
**Reference implementation:** `src/main/resources/static/custom_js/TSD/tsd.js`

Older tabbed pages (My Orders, Account Status) remain valid examples for load-once flags; **new** modules should copy the **TSD plain-jQuery flow**, not CIR’s heavier helpers.

---

## Base JS flow (mandatory for new modules)

```
Load            → get customer → bind tab clicks
loadContext     → $.ajax /context
showTab         → show / hide panels
.load()         → HTML fragment once
loadRequests    → $.ajax /list → Common.DataTable
```

1. HTML page script calls `Module.Load()` after the shell is inserted (menu `js_path`).
2. Do **not** start the load from `MainPage.js`.
3. Each tab HTML is `.load()`’d **once**; switching tabs only shows/hides panels.
4. Refresh (or explicit Get) calls the list API again — not a full HTML reload.
5. Grids use `Common.DataTable` only.

Full skeleton and must/must-not: [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md).

---

## Files

- Shell HTML under `html_files/{AREA}/{module}_home.html` (tabs + empty panels)
- Tab fragments under the same folder (e.g. `*_requests.html`)
- One JS under `custom_js/{AREA}/{module}.js`
- Menu: `file_name` → shell (without `.html`), `js_path` → that JS, Load Type Internal
- Page root id `m_{module}_home` (or `m_{module}`) so loaders / date pickers can target it
- Customer: `Common.GetProcedureCustomerContext()` / `GetCustCode()` — server owns final resolve (login, Change Customer, module override)

---

## Load once, then only Refresh

Each tab’s **HTML** loads once. The **list API** runs on first open and again on Refresh.

Simple flags on the module object (TSD style):

```javascript
if (MyModule.listHtmlLoaded && $("#m_my_list").length) {
	return; // HTML already there — do not .load() again
}
```

Or jQuery `.data()` on the root (My Orders / Account Status style):

```javascript
var $root = $("#m_account_status");
if (!force && $root.data(key + "Loaded")) return;
$root.data(key + "Loaded", true);
```

| Action | Result |
|--------|--------|
| First open of a tab | Load HTML once (if needed), then call list API |
| Click same tab again | No HTML reload; no list API unless you choose to refresh |
| Refresh button | List API again (`force`) |

A failed list request should leave the user able to retry (do not treat failure as permanently loaded if you use a “data loaded” flag).

---

## Tables

Every grid uses `Common.DataTable` (`common.js` + `css/common_table.css`). Do not hand-build search, page size, or pager.

```html
<div id="m_as_payments_due">
  <div class="dt-table-wrap">
    <table class="dt-table" id="as_payments_due_table">
      <thead></thead>
      <tbody id="as_payments_due_tbody"></tbody>
    </table>
  </div>
</div>
```

```javascript
Common.DataTable.init({ rootId, tableId, tbodyId, columns, ... });
Common.DataTable.setData(rootId, rows);
```

---

## Dates

**Required for all modules** (CIR / Rebate / COA / TSD / new work): use the framework picker, never `<input type="date">`. See also [JS_MODULE_STANDARD.md](./JS_MODULE_STANDARD.md).

- `dd/mm/yyyy` + classes `date date-picker` + `data-date-format="dd/mm/yyyy"`
- Calendar icon: `all_obj.CallTarkaDatePickerNew('{module}','{fieldId}')`
- After fragment load / dynamic inject: `initDatePickers($root)` (or module `ensureDatePickers`)
- Empty From Date = 1st of the current month (list filters)
- Empty To Date = today (list filters)
- When an API needs `yyyymmdd`, convert with `DateFormatYYYYMMDD()` in `MainPage.js`

---

## Java (reminder)

Keep controllers thin; SQL in `*Sql` helpers with bound `?` params (`NativeQuerySupport`).  
Module-specific DB factory (e.g. TSD → `HibernateFactoryRegistry.TSD`).  
Customer/converter resolve on the **server** — see [getCustomer.md](./getCustomer.md) and the module system doc.
