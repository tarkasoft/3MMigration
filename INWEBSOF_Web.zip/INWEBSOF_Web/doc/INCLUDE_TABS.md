# Include Tabs (MainPage)

Optional multi-tab module layout. **Default is off** so production stays on the classic single-page behavior.

## Revert / turn off

Any of these restores the current single `#home_dashboard` replace behavior:

1. `portal.extras.include-tabs=false` in `portal.properties` (restart app / reload menus), or
2. In the browser console: `InpcTabs.setFlag(false)` / `window.INPC_INCLUDE_TABS = false`

## Turn on

1. Set `portal.extras.include-tabs=true` and reload MainPage (menus applies the flag), **or**
2. Console: `InpcTabs.setFlag(true)`

## Behavior

| Mode | Behavior |
|------|----------|
| Flag false | Classic: each open replaces `#home_dashboard` |
| Flag true + desktop | Tab strip: **Home** (pinned) + opened modules; max **6 tabs total** (including Home) |
| Over max | Alert: `Maximum of 6 tabs can be open.` |
| Same module again | Focuses existing tab (no duplicate) |
| Mobile width (≤767) | Always single page even if flag is true |

## `#m_{file_name}`

With multiple panes in the DOM, FW save/popup/grid scope fields under `#m_{file_name}` (CreateHtmlFiles already does this). Manual FW HTML should use the same root id. See [SHARED_MODALS.md](./SHARED_MODALS.md) / Framework docs.

## Files

- `static/js/inpc-tabs.js` — tab host
- `static/js/MainPage.js` — `loadPage` / `getModulesDetailsNew` / menus extras
- `static/js/fw-globals.js` — default `INPC_INCLUDE_TABS = false`
- `portal.properties` — `portal.extras.include-tabs=false`

## Home pages by user type

Different user types use different Home HTML (`home_admin`, `home_customer`, `home_distributor`, `home_customer_service`). See **[HOME_PAGES.md](./HOME_PAGES.md)**.

With tabs on, they share **one** Home tab; content is still chosen by `inpcHomeModuleForUserType` for the logged-in user.

## Closing a tab

Clicking **X** on a module tab shows a SweetAlert2 confirm: "Do you want to close …?". Home has no close button.

## Tab styles (`tab_style` / `tab-style`)

Visual themes only — open / close / max-6 / Home behavior stay the same.

| Value | Look |
|-------|------|
| **1** | Folder cards (current default) |
| **2** | Flat legacy strip (home icon, separators, light-blue active, red X) — matches classic ERP screenshot |
| **3** | Underline / modern |
| **4** | Pill / chip |
| **5** | Segmented bar + navy active pill (Account Status style) |
| **6** | Folder tabs merging into white content card |

Set via:

- `portal.extras.tab-style=2` in `portal.properties`, or
- Console: `InpcTabs.setTabStyle(2)` / `window.INPC_TAB_STYLE = 2`

CSS file: `static/css/inpc_tabs.css` (linked from MainPage).

## Theme Switcher

When Include Tabs is on, Theme Switcher → **Theme Styles** shows **Module Tab Styles** (1–6). Choice is stored in `localStorage.inpc_tab_style` and applied via `InpcTabs.setTabStyle`.

## Tab icons (`tab-icons`)

When `portal.extras.tab-icons=true` (or `window.INPC_TAB_ICONS = true`), each module tab shows the Remix icon from Menu Options (`icons` / `icons_color`) before the title. Home uses `ri-home-4-line`. Off = text-only labels (style 2 may still show its CSS home glyph).


- `INPC_MENU_ICONS` filled for Direct + folder menus; `tab-icons` extras parsed as sibling of `tab-style` (not nested).

