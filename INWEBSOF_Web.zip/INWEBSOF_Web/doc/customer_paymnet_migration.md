# Customer Payment Migration

## Scope

This document captures the migration from the legacy `inpc` customer payment summary flow to the current `INPCV2` implementation located in:

- `src/main/java/com/mmm/customer/CustomerPayment.java`
- `src/main/resources/static/custom_js/CUST_SERVICE/customer_payment.js`
- `src/main/resources/static/html_files/CUST_SERVICE/customer_payment.html`

No changes were made in the old repository under `C:\Users\A6GWBZZ\eclipse-workspace\inpc\inpc`.

---

## 1. Legacy reference reviewed

The old implementation is in the legacy project and uses the following patterns:

- `src/main/java/com/mmm/cparmod/CparmodSpCall.java`
- `src/main/webapp/resources/cparmod/js/cparmod.js`
- `src/main/webapp/resources/cparmod/html/AccountSummary.html`
- `src/main/java/com/mmm/myaccsts/MyPaymentsSPCall.java`
- `src/main/webapp/resources/myaccsts/html/AccSmmry.html`
- `src/main/webapp/resources/myaccsts/js/MyPaymentApp.js`

The legacy payment summary flow is built around:

1. A controller endpoint named `getPaymentSummHdr`
2. A DAO call `cparmoddao.getPaymentSummHdr(APPCODE, Uid, custCode)`
3. JSON shaped like a result-set map such as `{"#result-set-1":[...]}`
4. UI-side transformation in AngularJS that splits records into:
   - current month cycle
   - next month due
   - customer/company on-hold values
   - `ECCDT` + `AMT` rows

The legacy front-end logic explicitly treats `ECCDT == 0` as a hold-value marker and keeps the rest as payment dates.

---

## 2. Current implementation status

The current file is already structured as a single-file Spring controller and matching frontend shell:

### Java
`CustomerPayment.java`

- Controller route: `/api/customer/customer-payment/summary`
- Accepts `custCode`, `loginId`, and `dummy`
- Validates the authenticated user session and resolves any authorized customer override through `UserSessionSupport.resolveProcedureCustomerContext(...)`
- Loads system customer/company metadata from `ia_user_master`
- Calls the legacy AS400 procedure `BPCSLCLIN.COS015S` when dummy mode is disabled
- Uses in-code representative cycle rows when dummy mode is enabled
- Maps legacy `ECCDT` / `AMT` rows into the current response object:
  - `companyLevel`
  - `asOf`
  - `currency`
  - `currentMonth`
  - `nextMonth`
  - `rawRows`
  - `source` (`dummy` or `as400`)

`PaidInvoices.java` is the reference for the project-standard AS400 integration style:

- File: `src/main/java/com/mmm/customer/account_status/PaidInvoices.java`
- It uses `NativeQuerySupport.executeProcedure(...)` with `HibernateFactoryRegistry.AS400`
- It binds procedure inputs rather than constructing SQL with values

```java
List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
        hibernateRegistry,
        HibernateFactoryRegistry.AS400,
        "{call BPCSLCLIN.COS015S(?,?,?)}",
        appCode, loginId, "0");
```

The legacy CPAR screen requests `getPaymentSummHdr?custCode=0`; Customer Payment therefore passes the literal customer code `"0"` to `COS015S` for the company-level cycle summary. The selected customer's login ID is still passed as the second input. The date-input handling in `PaidInvoices` is specific to `COS009S` and does not apply to `COS015S`.

### JS
`customer_payment.js`

- Calls `/api/customer/customer-payment/summary`
- Sends `custCode`, `loginId`, and `dummy`
- Uses `window.inpcHandleSessionExpired(json)` for expired-session handling
- Renders the summary into `#m_customer_payment`
- Supports section-based rendering for current and next cycle
- Uses the same pattern as other modules in the project, with `Common.GetCustCode()` and `Common.GetLoginId()`

### HTML
`customer_payment.html`

- Contains the custom payment summary layout with:
  - header
  - company block
  - currency chip
  - current month and next month sections
  - date row cards
  - totals cards
- Starts with loading placeholders; sample values come from the Java dummy-data path rather than remaining hard-coded in the page

---

## 3. What the legacy screen really does

The legacy page uses a summary payload that is not a direct match for the new UI contract.

### Legacy JSON transformation pattern
In `cparmod.js`, the response is split and transformed like this:

- `data = JSON.parse(data)`
- `summaryHeaderDataRes = keyChangeAll(data, ['ECCDT', 'AMT'])['#result-set-1']`
- `summaryHeaderData = []`
- `customeronhold = ['', '']`
- Each record is processed with logic similar to:
  - if `ECCDT == 0` or `ECCDT == '0'` => treat it as a hold value
  - else => push to payment list
- The page then shows six rows in each section with `limitTo` slicing

The legacy UI uses the data shape:

```javascript
$scope.summaryHeaderData = [
  { ECCDT: '20240905', AMT: 12345.67 },
  ...
];
$scope.customeronhold = [ 'holdAmount1', 'holdAmount2' ];
```

### New UI contract
The current UI expects a more structured object:

```json
{
  "companyLevel": "ABC Ltd",
  "asOf": "17 September, 2026",
  "currency": "INR",
  "currentMonth": {
    "label": "September 2026",
    "payments": [
      { "date": "05-09-2026", "amount": 3131243.41 },
      ...
    ],
    "total": 119175942.86
  },
  "nextMonth": {
    "label": "October 2026",
    "payments": [ ... ],
    "total": 196031530.30
  }
}
```

This is a contract change from the legacy `ECCDT/AMT` list design to the new section-based summary.

---

## 4. Migration behavior and test focus

### 4.1 Legacy service contract and current controller contract
The legacy controller calls `COS015S` with `APPCODE`, `LOGINID`, and `CUSTCOD`. The current endpoint retains those procedure inputs while deriving them from the authenticated session or an authorized customer override. The legacy result is translated to the current section-based response in Java.

### 4.2 Dummy-data mode
The existing global switch is `window.as400_dummy_data_required` in `fw-globals.js` (currently `false`). The Customer Payment JavaScript sends it as the `dummy` query parameter. The controller selects between the sample and live paths:

- `@RequestParam(value = "dummy", defaultValue = "false") boolean dummy`
- `dummy ? buildDummyPaymentCycles(today) : loadPaymentCyclesFromAs400(login, code)`
- response includes `source: "dummy" | "as400"`

The flag is for local/demo rendering only. With the current default `false`, the live `COS015S` procedure path is selected. This follows the existing convention used by `PaidInvoices.java` and other AS400-backed endpoints.

### 4.3 Legacy row semantics
The old UI logic uses a result-set list rather than the new section-based contract. The Java mapping now reconstructs:

- current versus next month
- hold-values separation
- date formatting
- totals from payment rows
- payment-date count in the UI
- month labels

`ECCDDT` (with `ECCDT` accepted as an alternate label) is the payment date. The observed second result column is named `00007`; it is used as the amount when no `AMT` alias is present. This matches the two-column result shown for `CALL BPCSLCLIN.COS015S('INPC','005212IN','0')`. Date values of `0` (or the legacy `ecsDate == "-"` marker) are treated as the first and second hold rows for the current and next month respectively. Non-sentinel dates are parsed as `yyyyMMdd` (or ISO `yyyy-MM-dd`), formatted for display, and assigned to the current or next calendar month. Rows outside those two months and rows with invalid dates are logged and skipped. Hold amounts are exposed as `currentMonth.holdAmount` / `nextMonth.holdAmount`.

---

## 5. Implementation status

The implementation work is in place; live AS400 validation remains pending.

### AS400 procedure
The legacy payment summary uses `BPCSLCLIN.COS015S` with three character inputs in this order: `APPCODE`, `LOGINID`, `CUSTCOD`. For this company-level summary `CUSTCOD` is always `"0"`, matching the legacy CPAR request. The selected customer code remains available for page display and customer metadata, but is not passed as the third procedure input. `CustomerPayment.java` uses the shared `NativeQuerySupport.executeProcedure(...)` helper, following the AS400 integration pattern in `PaidInvoices.java`.

The corresponding call shape is:

```java
List<Map<String, Object>> rawRows = NativeQuerySupport.executeProcedure(
        hibernateRegistry,
        HibernateFactoryRegistry.AS400,
        "{call BPCSLCLIN.COS015S(?,?,?)}",
        configuredAppCode, loginId, "0");
```

`PaidInvoices.java` invokes a different procedure (`COS009S`) with date inputs; its numeric `yyyyMMdd` date conversion is not applicable to `COS015S`.

### Response mapping
The controller maps `ECCDDT` (or alternate `ECCDT`) and `00007` (or alternate `AMT`) fields into `currentMonth` and `nextMonth`. If the amount label is not recognized, the second result column is used, matching the observed two-column result set. Each section contains a month `label`, a `payments` array of `{date, amount}` items, a computed `total`, and an optional `holdAmount`. The JS renders both sections, including empty-state messaging and payment counts.

### Dummy switch
`window.as400_dummy_data_required` remains the global switch and currently defaults to `false` in `fw-globals.js`. The JS sends it as `dummy`; `true` uses representative in-code sample rows and `false` invokes `COS015S`. The response reports its selected path as `source: "dummy"` or `source: "as400"`.

## 6. Logging and live test plan

The controller logs the `COS015S` call with its three input values and, after execution, the returned row count and first row's column names. It does not currently log every returned row value. Review the server log during live testing to confirm that the expected procedure was invoked and to establish the actual result-set shape before relying on the field mapping.

### Test sequence

1. **Dummy path:** Set `window.as400_dummy_data_required = true` locally and load Customer Payment. Confirm the response has `source: "dummy"`, dates render in both sections, totals/counts match the displayed rows, and HTML placeholder values are replaced.
2. **AS400 path:** Restore the flag to `false` and load the page with a valid authenticated session. Confirm the server log shows `COS015S('INPC','005212IN','0')`; confirm the procedure returns rows and inspect the logged column names.
3. **Field mapping:** Verify the first result set exposes `ECCDDT` and `00007` (or confirm any environment-specific alias variants). Check that date values are valid `yyyyMMdd` or ISO dates and amounts are numeric/decimal.
4. **Business behavior:** Compare representative rows with the legacy `getPaymentSummHdr` display. Confirm the two `0`/`-` hold markers, if returned, are assigned to the correct current/next section; current- and next-month rows land in the correct month, are date-sorted, and totals equal the relevant payment amounts.
5. **Empty/error cases:** Confirm zero rows show empty-state UI, and an AS400 failure is returned as an API failure (not an empty successful summary). Confirm an expired session follows the existing session-expiry handler.

Record the test date/environment, `source`, procedure row count and column names, and any mapping corrections below after executing the tests:

| Test run | Environment/date | Dummy flag | Result / observations |
|---|---|---|---|
| Manual procedure call (user-provided result) | 2026-09-28 | `false` / direct call | `CALL BPCSLCLIN.COS015S('INPC','005212IN','0')` returned columns `ECCDDT`, `00007` and payment dates from `20260905` through `20261030`; endpoint/UI verification remains pending |

---

## 7. Suggested business mapping from legacy to new

| Legacy concept | Current target concept |
|---|---|
| `getPaymentSummHdr` | `/api/customer/customer-payment/summary` |
| `ECCDT` | `payment.date` |
| `AMT` | `payment.amount` |
| `customeronhold[0]` / `[1]` | `currentMonth.holdAmount` / `nextMonth.holdAmount` |
| Current month list | `currentMonth.payments` |
| Next month list | `nextMonth.payments` |
| `custCode` from query param | resolved session/customer context |
| Angular `limitTo` slices | JS iteration over payment arrays |

`COS015S` specifically takes the legacy `APPCODE, LOGINID, CUSTCOD` inputs. Do not transfer `COS009S`'s date parameters or numeric date conversion to this procedure.

---

## 8. Implementation pattern

The feature now follows the existing project rules:

- use shared helper methods from `NativeQuerySupport`
- avoid one-off ad hoc SQL execution in the controller
- convert AS400 rows to the front-end contract centrally
- use the `dummy` request parameter sourced from `window.as400_dummy_data_required`
- maintain session-aware customer resolution

---

## 9. Current status and verification notes

The controller calls `COS015S` when `dummy=false`, preserves the dummy-data path when `dummy=true`, and maps the legacy `ECCDT` / `AMT` data into the section-based UI contract. The existing global dummy flag defaults to `false`. The Java source has compiled successfully; this does not confirm live AS400 connectivity or production data/column mapping.

The legacy old-screen logic is still a useful source of truth for:

- date ordering
- current-versus-next-month split
- hold-value handling
- customer/company title logic

The live procedure output, result column names, hold-row ordering, and month assignment must be validated in an environment with the AS400 datasource available. Update the test table above with the observed results after that run.
