# Policies & Guidelines

Information & Support page. It lists documents on the common agreements share and downloads one file. The browser receives names only. The share path and password stay on the server.

Legacy source is read-only: `C:\Users\DELL\eclipse-workspace\inppc_old\main`. Current source is `INPCV2\src\main`.

Dummy data follows `window.as400_dummy_data_required` in `js/fw-globals.js`. It is `true` right now, so the grid shows five sample document names and Download does not open the share. Set it to `false` to list the live COMAGM folder.

---

## Old code (`inpc`)

Screen title: Policy/Agreements. Live pages:

- `https://inpc.3m.com/inpc/resources/agreements/html/index.html`
- `https://inpc.3m.com/inpc/portalFileContrlr/getAttachementFiles`

Route `/CustAgrmt` in `portalApp.js` loads the HTML and `agrmentController`. Menu property `CUSAGM=CustAgrmt`. App code property `APPCODEAGM=CUSAGM` in `portal.properties`.

| Piece | Path |
|---|---|
| HTML | `webapp/resources/agreements/html/index.html` |
| JS | `webapp/resources/agreements/js/AgreementsApp.js` |
| List API | `com.mmm.portal.PortalFileController` `GET portalFileContrlr/getAttachementFiles` |
| List files | `com.mmm.portal.utils.FileUtils.getAgreements` |
| Download | `com.mmm.websof.UtilController` `GET /websof/downloadagm?fname=` |
| Share lookup | `CreateSOFImpl.getExceliteWriteUpDetails` |

### What the old page did

1. `AgreementsApp.js` calls `portalFileContrlr/getAttachementFiles` with no extra parameters. The login comes from the session attribute `login`.
2. `PortalFileController` calls `BPCSLCLIN.CMW010S` through `getExceliteWriteUpDetails(APPCODEAGM, loginId, "")`.
3. The result set key is `#result-set-1`. Each row has `NWCODE`, `NWPATH`, `NWLID`, `NWPWD`.
4. The row `NWCODE=COMAGM` is the common share. The path used is `smb:` plus `NWPATH` plus `/`. Auth is `NWLID + ":" + NWPWD`.
5. `FileUtils.getAgreements` uses JCIFS `NtlmPasswordAuthentication("MMM", user, password)` and `SmbFile.listFiles()`. Files only. `Thumbs.db` is skipped. Each item is `{ name, url }`. The url is `websof/downloadagm?&fname=` plus the full `smb:` path and file name.
6. The HTML draws PDF tiles from `agrfiles` (`data[0]`). A click opens that url.
7. `downloadagm` calls `CMW010S` again, takes the `COMAGM` user and password, opens the `fname` `SmbFile`, and streams it as `application/pdf`.

SMB auth failure returns the text `"0"`. The page alerts "File server authentication failed". Any other failure alerts "unable to connect file server".

### Procedure

`{call BPCSLCLIN.CMW010S(?,?,?)}`

| Parameter | Type | Value on this screen |
|---|---|---|
| APPCODE | varchar | `CUSAGM` (`APPCODEAGM`) |
| LOGINCODE | varchar | session login id |
| SEARCHSTRING | varchar | empty string |

### Left unused in the old screen

- `folderNames` value `Agreements/cmnagrmnts` is declared and never used. The live folder is whatever `NWPATH` already contains.
- The `USRAGM` block that would list `Agreements/{custCode}` is commented out.
- The Customer Documents tiles (`useragrfiles` / `data[1]`) are commented out in the HTML.

### Old behaviour that the new page does not copy

- JCIFS and its older SMB dialect.
- Putting the full `smb:` path and the share credentials into the browser. The download url contained the path. `getAgreements` also printed the path and the `user:password` string.
- Returning `"0"` for an authentication failure.
- Splitting `NWLID:NWPWD` on the first colon, so a colon inside the password would break the user.

---

## New code (`INPCV2`)

| Piece | Path |
|---|---|
| HTML | `html_files/CUST_SERVICE/policies_guidelines.html` |
| JS | `custom_js/CUST_SERVICE/policies_guidelines.js` |
| Java | `com.mmm.customer.PoliciesGuidelines` |
| Library | `com.hierynomus:smbj:0.15.0` in `pom.xml` |
| Menu `file_name` | `CUST_SERVICE/policies_guidelines` |
| Menu `js_path` | `custom_js/CUST_SERVICE/policies_guidelines.js` |

The menu leaf under Information & Support is portal menu data. The page script calls `PoliciesGuidelines.Load()` after the fragment is inserted. MainPage does not start the load.

### APIs

`GET /api/customer/policies/list?custCode=&loginId=&dummy=`

`GET /api/customer/policies/file?name=&custCode=&loginId=&dummy=`

`dummy=true` returns sample names: Commercial_Agreement.pdf, Credit_Policy.pdf, GST_Guidelines.pdf, Dealer_Terms.pdf, Return_Policy.pdf. The page sends that flag from `window.as400_dummy_data_required`. `dummy=false` calls the share.

Session is required. Matched Change Customer sends both `custCode` and `loginId`. Otherwise both are empty and `UserSessionSupport.resolveProcedureCustomerContext` uses the session. `CMW010S` receives the resolved login only. It does not receive the customer code.

The call is `{call BPCSLCLIN.CMW010S(?,?,?)}` with app code `CUSAGM` (`inpc.policies.app-code`), the resolved login, and `""`. The `COMAGM` row supplies host, share, folder, user, and password. `NWPATH` is parsed from `smb://host/share/folder` or `\\host\share\folder`. Domain default is `MMM` (`inpc.policies.smb-domain`).

The list returns `{ name }` rows in `ResponseDataGeneric`. `source` is `smb`. A failure returns error code `-1` and "Unable to load policies and guidelines". It does not return `"0"`.

Download re-reads `COMAGM` on the server, then opens that one file. Names that contain `/`, `\`, `..`, or other path characters are rejected. Content type is PDF when the name ends in `.pdf`, otherwise a binary download. The password is not written to the log. The log line records host, share, and folder only.

The list is rendered as responsive document cards with a client-side name search and document count. A card shows a file-type icon, the complete document name, and a Download button. There is no customer-folder list.

### Share access

```java
SmbConfig config = SmbConfig.builder()
    .withDialects(SMB2Dialect.SMB_3_1_1)
    .withEncryptData(true)
    .build();
```

JCIFS is not a dependency. The client does not negotiate an older dialect.

---

## Same behaviour, different shape

| | Old | New |
|---|---|---|
| Screen | PDF tiles | Responsive document cards with search |
| List | `GET portalFileContrlr/getAttachementFiles` | `GET /api/customer/policies/list` |
| Download | `GET /websof/downloadagm?fname={full smb path}` | `GET /api/customer/policies/file?name={file name}` |
| Procedure | `BPCSLCLIN.CMW010S` | same procedure |
| App code | `CUSAGM` | `CUSAGM` |
| Share row | `NWCODE=COMAGM` | same row |
| Domain | `MMM` | `MMM` |
| Skip | `Thumbs.db` | `Thumbs.db` |
| Customer folder | commented out | not implemented |
| Library | JCIFS | SMBJ 0.15.0, SMB 3.1.1 only, encryption on |
| Auth failure | body `"0"` | session error or "Unable to load policies and guidelines" |
