﻿# Home load (login-type)

Short cheat sheet. Full landing-dashboard flow: [HOME_PAGES.md](./HOME_PAGES.md).

- Login type names come from `ia_user_type`. `ia_user_master.u_user_type` stores that table’s `internal_code`. Home still picks a file by the name (`MainPage.js` → `inpcHomeModuleForUserType`):
  - Admin → `home_admin.html`
  - Customer → `home_customer.html`
  - Distributor → `home_distributor.html`
  - Customer Service → `home_customer_service.html`
- **MainPage** only loads that shell into `#home_dashboard` (or the Home InpcTabs pane). It does **not** pick `sb_dash_board_*.html`.
- Customer / Distributor / `home_Page` shells own the tab strip. Each tab’s `data-path` is loaded into `#home_dash_panel` with jQuery `.load()`. Same path is not reloaded on re-click; Overview (`#home_tab_0`) loads on open.
- **Overview** → `html_files/INPC/home_overview.html` (not root `home.html`).
- Tabs 2–7: `sb_dash_board_1.html` … `sb_dash_board_6.html` (customer, distributor, and `home_Page.html`).
- Tab 8 **Sales Insight** → `sb_dash_board_7.html` is on **customer home only** (`home_customer.html`).
- Admin and Customer Service homes are static landings (no dashboard tabs).
- CIR’s in-module Dashboard is unrelated to these landing tabs — [CIR_MIGRATION.md](./CIR_MIGRATION.md).
