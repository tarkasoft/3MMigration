# Welcome message

Login popup on MainPage. The shell is `#inpc_welcome_modal` in `MainPage.html`. The body comes from `dbo.welcome_msg_module.html_body`. Acknowledgement is stored in `dbo.welcome_msg_ack`.

Layout reference for the body HTML is `static/html_files/INPC/welcome.html` (banner, section title, table, news strip, OK line). Class prefix `inpc-welcome-`.

## Who sees it

`WelcomeAck.welcomeFor` runs from `GET /api/auth/menus` and `/me`. It picks the newest `welcome_msg_module` row where:

- today is between `from_date` and `to_date` (SQL Server date, shifted by session `inpc_hh` / `inpc_mm`)
- `isnull(active,'Yes') = 'Yes'` (blank `active` stays on)
- `html_body` is not blank
- `w_user_type` matches the session user type name, or the `ia_user_type.internal_code` stored in `w_user_type`

Customer is `ia_user_type.internal_code` **1**.

## Module columns used by the popup

| Column | Effect |
|--------|--------|
| `from_date`, `to_date` | Date window. Both must be set. |
| `w_user_type` | User type internal code or type name. |
| `title` | Modal title. Blank becomes Welcome. |
| `html_body` | Modal body. |
| `active` | Shown when `isnull(active,'Yes') = 'Yes'`. Blank counts as Yes. `No` hides the row. |
| `ack_required` | `Yes` adds a checkbox and changes OK to Submit. The popup cannot be closed until the save succeeds. |
| `ack_message` | Checkbox label. Blank uses **I acknowledge**. |
| `show_ack_prompt_even_acknowledged` | `Yes` keeps the popup after this login and customer have already acknowledged. It shows **You have acknowledged on {dd/mm/yyyy hh:mm}.** and OK closes it. No second insert. |

Admin form: `static/html_files/INPC/welcome_msg_module.html`. Grid: `static/grid_display_files/INPC/welcome_msg_module.js` (includes Active).

Preview (`PreviewWelcomeMessage` in `custom_js/common.js`) fills the same modal from the open form and closes with OK. It does not save an acknowledgement.

## Acknowledgement table

`dbo.welcome_msg_ack`

| Column | Notes |
|--------|--------|
| `internal_code` | Identity primary key |
| `ref_welcome_int_code` | `welcome_msg_module.internal_code` |
| `title` | Title snapshot at acknowledgement |
| `user_id` | Session login id |
| `cust_code` | Session home customer. Blank for internal users. |
| `acknowledged_on` | `dateadd` of session `inpc_hh` / `inpc_mm` on `getdate()` |

Unique on `(ref_welcome_int_code, user_id, cust_code)`. Saving again does not insert a second row.

`POST /api/portal/welcome-ack` (`com.mmm.portal_common.WelcomeAck`) takes form field `welcomeInternalCode`. Login and customer come from the session, not the browser. The message must be the current active row and `ack_required` must be Yes.

Client: `Common.AcknowledgeWelcome` in `custom_js/common.js`. MainPage (`js/MainPage.js`) calls it from Submit and hides the modal only after success. Backdrop, Esc, and the button stay locked while `data-ack-lock` is Yes.

When `ack_required` is Yes and a row already exists, and `show_ack_prompt_even_acknowledged` is not Yes, menus return an empty body and the popup does not open.

## Menus fields

`welcome_title`, `welcome_msg`, `welcome_internal_code`, `ack_required`, `ack_message`, `show_ack_prompt_even_acknowledged`, `already_acknowledged`, `acknowledged_on`, `show_welcome` (`Yes` only when `welcome_msg` is not blank).

## Customer notice added 1 Oct 2026

`welcome_msg_module.internal_code` **5**, user type Customer (`1`), **1 Oct 2026** through **31 Dec 2026**, title **Welcome**, `active` **Yes**, `ack_required` **No**. Body is the Customer Incentive Plan TDS notice (Volume / Growth Rebates 2% → 10%, Market Development Funds 10% → 2%, effective 1 July 2026), using the welcome-board layout. It is the newest Customer row in that window, so it is the one shown. The September Customer row remains.
